var appConfig = {
    title: "CNAP",
    lang: "en",
    dateFormat: "mm/dd/yy",
    apiBase: 'http://localhost:8080/cnapws',
    apiImageServer: 'http://localhost:8080/cnapimageserver',
    apiTPBase : 'http://localhost:8080/cnaptp/fb',
	apiTwitterBase : 'http://localhost:8080/cnaptp/tw',
    networkAdAccountId: '101870703634673',
    networkAccessToken: 'EAAJ4OaibPkYBAFEzuYMtq7ax5dbZBHB85QM0D2okIZAQkGKssj80fDfIuPZC9Jnt9q2g2YIUtF6cZAoYI9yKkkZCZAXLC37o5Q0uLYWxPQDXpXuutqx6ZAhya5ZC2GiW8MhH8ZANfsXO7teJlZBgjOkjM34FrGUpulnyfx8g1lZB9Oq4AZDZD',
    theme: 'skin-purple',
    layout: "",
    fbNetwork :"https://www.facebook.com",
    twNetwork :"https://www.twitter.com",
    BREUrl:"http://localhost:8080/CNAP_UI_BRE_demo/indexFinal.html",
    loginSession: "",
    FbsyncRedirectUri : "http://localhost:8080/CNAP_UI_Repo/app/modules/dashboard/views/fblogin.html"
};



