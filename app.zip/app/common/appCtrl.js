app.controller("appCtrl", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', '$timeout','globalData','sharedService','netWorkData',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, $timeout, globalData, sharedService, netWorkData) {
        var apiBase = appSettings.apiBase;
        $rootScope.theme = appSettings.theme;
        $rootScope.layout = appSettings.layout;
        $scope.opensubmenu = false;
        $scope.right_arrow=true;
        $scope.up_arrow=true;
        $scope.down_arrow=true;
        var vm = this;
		sharedService.store = $scope;
        $scope.userRole = $window.localStorage.getItem("role");
        $scope.advertiserDetails = {};
        $scope.advertiserLogo = [];
		$scope.popupHeaderColor = "#9CCC65";
		$scope.currentPlan = "SMB";
		$scope.planDesc = "5";
		$scope.planId = "110001";
		$scope.totalAmount = '0.01';
		$scope.currencyCode="USD";
        if ($scope.userRole == "Account") {
            var menuTitle = "ACCOUNT HOME";
            var menuIcon = "images/accountDashboard/dashboard.svg";
            var menuIconSelected = "images/accountDashboard/dashboard.svg";
            var menuState = "accountdashboard";
            var menuperfSubmenu = "true";
            var menucampSubmenu = "true";
            var campState = "";
            var metricstate="metriccomparison";            
        }
        else if ($scope.userRole == "Advertiser") {
            var menuTitle = "ACCOUNT HOME";
            var menuIcon = "images/accountDashboard/dashboard.svg";
            var menuIconSelected = "images/accountDashboard/dashboard.svg";
            var menuState = "advertiserdashboard";
            var menuperfSubmenu = "true";
            var menucampSubmenu = "false";
            var campState = "parentcampaign";
            var metricstate="metriccomparison";            
        }
        else if ($scope.userRole == "Ops Team") {
            var menuTitle = "ACCOUNT HOME";
            var menuIcon = "images/accountDashboard/dashboard.svg";
            var menuIconSelected = "images/accountDashboard/dashboard.svg";
            var menuState = "opsteamdashboard";
            var menuperfSubmenu = "true";
            var menucampSubmenu = "false";
            var campState = "parentcampaign";
            var metricstate="metriccomparison";            
        }



    //function to go to update personal details page
    $scope.gotoUpdatePersonaldetails = function()
    {
        $state.go('app.editprofiledetails');
    }



        //avalilable themes
        vm.themes = [
            {
                theme: "black",
                color: "skin-black",
                title: "Dark - Black Skin",
                icon: ""
            },
            {
                theme: "purple",
                color: "skin-purple",
                title: "Dark - Purple Skin",
                icon: ""
            },
            {
                theme: "purple",
                color: "skin-purple-light",
                title: "Light - Purple Skin",
                icon: "-o"
            },
        ];

        //available layouts
        vm.layouts = [
            {
                name: "Boxed",
                layout: "layout-boxed"
            },
            {
                name: "Fixed",
                layout: "fixed"
            },
            {
                name: "Sidebar Collapse",
                layout: "sidebar-collapse"
            },
        ];



        //Main menu items of the dashboard
        if($scope.userRole=="Account")
        {
        vm.menuItems = [
            {
                title: menuTitle,
                icon: menuIcon,
                icon_selected: menuIconSelected,
                state: menuState,
                id:1,
                submenu: "false",
                 marginright: "34px"
            },
            {
                title: "AD DASHBOARD",
                icon: "images/accountDashboard/global_performance.svg",
                icon_selected: "images/accountDashboard/global_performance.svg",
                state: "adDashboard",
                id:2,
                submenu: "false",
                background: "#ec407a",
                marginright: "39px"

            },
            {
                title: "PERFORMANCE",
                icon: "images/accountDashboard/performance_summary.svg",
                icon_selected: "images/accountDashboard/performance_summary.svg",
                state: "performancecampaignsummary",
                id:3,
                submenu: menuperfSubmenu,
                background: "#29b6f6",
                marginright: "41px"
            },
            {
                title: "CAMPAIGNS",
                icon: "images/accountDashboard/campaign.svg",
                icon_selected: "images/accountDashboard/campaign.svg",
                state: campState,
                id:4,
                submenu: menucampSubmenu,
                background: "#ff8f00",
                marginright: "62px"

            },
            {
                title: "REPORTS",
                icon: "images/accountDashboard/reports.svg",
                icon_selected: "images/accountDashboard/reports.svg",
                state: "reportsLanding",
                id:5,
                submenu: "false",
                background: "#9c27b0",
                marginright: "81px"
            },
            {
                title: "BRE",
                icon: "images/accountDashboard/rule.svg",
                icon_selected: "images/accountDashboard/rule.svg",
                state: " ",
                id:6,
                submenu: "false",
                background: "#F1C40F",
                marginright: "113px"
            }];

        

    }
    else if($scope.userRole=="Advertiser")
    {
        vm.menuItems = [
            {
                title: menuTitle,
                icon: menuIcon,
                icon_selected: menuIconSelected,
                state: menuState,
                id:1,
                submenu: "false",
                marginright: "34px"
            },
            {
                title: "AD DASHBOARD",
                icon: "images/accountDashboard/global_performance.svg",
                icon_selected: "images/accountDashboard/global_performance.svg",
                state: "updatedadDashboardadv",
                id:2,
                submenu: "false",
                background: "#ec407a",
                marginright: "39px"

            },
            {
                title: "PERFORMANCE",
                icon: "images/accountDashboard/performance_summary.svg",
                icon_selected: "images/accountDashboard/performance_summary.svg",
                state: "performancecampaignsummary",
                id:3,
                submenu: menuperfSubmenu,
                background: "#29b6f6",
                marginright: "41px"
            },
            {
                title: "MY CAMPAIGNS",
                icon: "images/accountDashboard/campaign.svg",
                icon_selected: "images/accountDashboard/campaign.svg",
                state: campState,
                id:4,
                submenu: menucampSubmenu,
                background: "#ff8f00",
                marginright: "39px"
                

            },
            {
                title: "REPORTS",
                icon: "images/accountDashboard/reports.svg",
                icon_selected: "images/accountDashboard/reports.svg",
                state: "reportsLanding",
                id:5,
                submenu: "false",
                background: "#9c27b0",
                marginright: "81px"
            },
            {
                title: "BRE",
                icon: "images/accountDashboard/rule.svg",
                icon_selected: "images/accountDashboard/rule.svg",
                state: " ",
                id:6,
                submenu: "false",
                background: "#F1C40F",
                marginright: "113px"
            },
			{
                title: "CUSTOM PAGES",
                icon: "images/accountDashboard/rule.svg",
                icon_selected: "images/accountDashboard/rule.svg",
                state: "dynamicforms",
                id:7,
                submenu: "false",
                background: "#F1C40F",
                marginright: "113px"
            }];
    }
    
    else if($scope.userRole=="Ops Team")
    {
        vm.menuItems = [
            {
                title: menuTitle,
                icon: menuIcon,
                icon_selected: menuIconSelected,
                state: menuState,
                submenu: "false",
                 marginright: "34px"
            },
            {
                title: "PERFORMANCE",
                icon: "images/accountDashboard/performance_summary.svg",
                icon_selected: "images/accountDashboard/performance_summary.svg",
                state: "performancecampaignsummary",
                submenu: menuperfSubmenu,
                background: "#29b6f6",
                marginright: "41px"
            },
            {
                title: "MY CAMPAIGNS",
                icon: "images/accountDashboard/campaign.svg",
                icon_selected: "images/accountDashboard/campaign.svg",
                state: "parentcampaign",
                submenu: menucampSubmenu,
                background: "#ff8f00",
                marginright: "39px"

            },
            {
                title: "REPORTS",
                icon: "images/accountDashboard/reports.svg",
                icon_selected: "images/accountDashboard/reports.svg",
                state: "reportsLanding",
                submenu: "false",
                background: "#9c27b0", 
                marginright: "81px"
            },
            {
                title: "BRE",
                icon: "images/accountDashboard/rule.svg",
                icon_selected: "images/accountDashboard/rule.svg",
                state: " ",
                submenu: "false",
                background: "#F1C40F",
                marginright: "81px"
            }];
    }
        // submenu for PERFORMANCE
        
      vm.performanesubmenuItems = [
            {
                title: "Overall Budget",
                icon: "images/accountDashboard/currency_default.svg",
                icon_selected: "images/accountDashboard/all.svg",
                state: "overallbudget",
                right_icon: "",
                marginright:"-3px",
                margintop:"0px"
            },
            {
                title: "Campaign Summary",
                icon: "images/accountDashboard/campaign_perfomance_default.svg",
                icon_selected: "",
                state: "performancecampaignsummary",
                right_icon: "",
                marginright:"-3px",
                margintop:"-20px"
            },
            {
                title: "Expected vs Actual",
                icon: "images/accountDashboard/expected-actual_default.svg",
                icon_selected: "images/accountDashboard/expected-actual-default.svg",
                state: "expectedactual",
                right_icon: "",
                margintop:"1px"

            },
            {
                title: "Metric comparison",
                icon: "images/accountDashboard/metric_default.svg",
                icon_selected: "images/accountDashboard/metric_default.svg",
                state: metricstate,
                right_icon: "",
                margintop:"2px"
            }];

        //set the theme selected
        vm.setTheme = function (value) {
            $rootScope.theme = value;
        };


        //set the Layout in normal view
        vm.setLayout = function (value) {
            $rootScope.layout = value;
        };

        vm.setcollapse = function (value) {
            $("body").addClass('sidebar-collapse');
            $scope.arrow=false;
        }

        //controll sidebar open & close in mobile and normal view

        vm.sideBar = function (value) {

            if ($(window).width() <= 767) {
                if ($("body").hasClass('sidebar-open'))
                    $("body").removeClass('sidebar-open');
                else
                    $("body").addClass('sidebar-open');
            }
            else {
                if (value == 1) {
                    if ($("body").hasClass('sidebar-collapse')) {
                        $scope.right_arrow=true;
                        $scope.up_arrow=true;
                        $scope.down_arrow=true;
                        $("body").removeClass('sidebar-collapse');
                    }
                    else {
                        $scope.right_arrow=false;
                        $scope.up_arrow=false;
                        $scope.down_arrow=false;
                        $("body").addClass('sidebar-collapse');
                        
                    }

                }

            }
        };

        //navigate to search page
        vm.search = function () {
            $state.go('app.search');
        };

        $scope.activeMenu1 = function () {
            $('.navbar').css('background-color', '#ff8f00');
            $('.logo').css('background-color', '#ff8f00');
        };

        $scope.loadIn = function (elm) {
            $('.navbar').css('background-color', '#9ccc65');
            $('.logo').css('background-color', '#9ccc65');
            var pathname = $window.location.href;
            var lastElement = pathname.substring(pathname.lastIndexOf("/") + 1, pathname.length);
            if (lastElement == "campaignplan" || lastElement == "parentcampaign" || lastElement == "campaignaudience" || lastElement == "campaigndetails" || lastElement == "campaignsummary" || lastElement == "campaigncreative") {
                $('.navbar').css('background-color', '#ff8f00');
                $('.logo').css('background-color', '#ff8f00');
            }
            if (lastElement == "adDashboard") {
                $('.navbar').css('background-color', '#EC4074');
                $('.logo').css('background-color', '#EC4074');
            }

        }
        $scope.perf_submenu = false;
        $scope.camp_submenu = false;

		$scope.curMenuIndex = 1;

		$scope.lingBRE = function(){
			var BREUrl = appSettings.BREUrl;
			console.log(BREUrl);
				
			var url = BREUrl+"?userId="+$window.localStorage.getItem("userId")+"&accessToken="+$window.localStorage.getItem("accessToken");
			window.open(url);
		}
		
		$scope.loadScript = function(name) {
			alert('load Script')
		     var jsPath = 'app/modules/twitterReplicator/${ name }.js';
			var promisesCache = {};			
            var path = jsPath.replace('${ name }', name);			
            var promise = promisesCache[name];
			console.log(path);
			console.log(name);
          if (!promise) {
                promise = $http.get(name);
                promisesCache[name] = promise;
				console.log(promise);
                return promise.then(function(result) {
                  //  eval(result.data);
				  //console.log(result.data);
				  var heads = document.getElementsByTagName("ui-view");
                    console.log(angular.element('head'));
					angular.element("ui-view").append(result.data);
                });
            }
            return promise; 
        } 
        vm.activeMenu = function (_this, event) {
			$scope.curMenuIndex = event.currentTarget.id;
			console.log(_this.state);
            if($scope.userRole=="Advertiser"){
            if (_this.title == "ACCOUNT HOME") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#9ccc65');
                $('.logo').css('background-color', '#9ccc65');
				$scope.popupHeaderColor ='#9ccc65'
				$state.go('app.'+_this.state);
            } else if (_this.title == "AD DASHBOARD") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#ec407a');
                $('.logo').css('background-color', '#ec407a');
				$scope.popupHeaderColor ='#ec407a'
				$state.go('app.'+_this.state);
            } else if (_this.title == "PERFORMANCE") {
                $scope.perf_submenu = !$scope.perf_submenu;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#29b6f6');
                $('.logo').css('background-color', '#29b6f6');
				$scope.popupHeaderColor ='#29b6f6'
            } else if (_this.title == "MY CAMPAIGNS") {
				$scope.getAdvertiserDetails();
                $scope.camp_submenu = !$scope.camp_submenu;
                $scope.perf_submenu = false;
                $('.navbar').css('background-color', '#ff8f00');
                $('.logo').css('background-color', '#ff8f00');
				$scope.popupHeaderColor ='#ff8f00'
				$state.go('app.'+_this.state);
            } else if (_this.title == "REPORTS") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#9c27b0');
                $('.logo').css('background-color', '#9c27b0');
				$scope.popupHeaderColor ='#9c27b0'
                $state.go('app.'+_this.state);
                  
            } else if (_this.title == "BRE") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#F1C40F');
                $('.logo').css('background-color', '#F1C40F');
				$scope.popupHeaderColor ='#F1C40F'
                $scope.lingBRE();
            }
			else if (_this.title == "CUSTOM PAGES") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#F1C40F');
                $('.logo').css('background-color', '#F1C40F');
				$scope.popupHeaderColor ='#F1C40F';
				$state.go('app.'+_this.state);
			   //$state.go('app.dynamiccampaigndetails');
            }
			
        }
            if($scope.userRole=="Ops Team")
            {
                if (_this.title == "ACCOUNT HOME") {
					$scope.perf_submenu = false;
					$scope.camp_submenu = false;
					$('.navbar').css('background-color', '#9ccc65');
					$('.logo').css('background-color', '#9ccc65');
					$scope.popupHeaderColor ='#9ccc65'
					$state.go('app.'+_this.state);
				} else if (_this.title == "AD DASHBOARD") {
					$scope.perf_submenu = false;
					$scope.camp_submenu = false;
	//                $('.navbar').css('background-color', '#ec407a');
	//                $('.logo').css('background-color', '#ec407a');
						$scope.popupHeaderColor ='#ec407a'
						$state.go('app.'+_this.state);
				} else if (_this.title == "PERFORMANCE") {
	                $scope.perf_submenu = !$scope.perf_submenu;
	                $scope.camp_submenu = false;
	                $('.navbar').css('background-color', '#29b6f6');
	                $('.logo').css('background-color', '#29b6f6');
					$scope.popupHeaderColor ='#29b6f6'
				} else if (_this.title == "MY CAMPAIGNS") {
					$scope.getAdvertiserDetails();
					$scope.camp_submenu = !$scope.camp_submenu;
					$scope.perf_submenu = false;
					$('.navbar').css('background-color', '#ff8f00');
					$('.logo').css('background-color', '#ff8f00');
					$scope.popupHeaderColor ='#ff8f00'
					$state.go('app.'+_this.state);
				} else if (_this.title == "REPORTS") {
	                $scope.perf_submenu = false;
	                $scope.camp_submenu = false;
//	                $('.navbar').css('background-color', '#9c27b0');
//	                $('.logo').css('background-color', '#9c27b0');
					$scope.popupHeaderColor ='#9c27b0'
                        $state.go('app.'+_this.state);
					  
				} else if (_this.title == "BRE") {
					$scope.perf_submenu = false;
					$scope.camp_submenu = false;
					$('.navbar').css('background-color', '#F1C40F');
					$('.logo').css('background-color', '#F1C40F');
					$scope.popupHeaderColor ='#F1C40F'
				}
                
            }
			
			if($scope.userRole=="Account")
            {
                if (_this.title == "ACCOUNT HOME") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#9ccc65');
                $('.logo').css('background-color', '#9ccc65');
				$scope.popupHeaderColor ='#9ccc65'
				$state.go('app.'+_this.state);
            } else if (_this.title == "AD DASHBOARD") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#ec407a');
                $('.logo').css('background-color', '#ec407a');
				$scope.popupHeaderColor ='#ec407a'
				$state.go('app.'+_this.state);
            } else if (_this.title == "PERFORMANCE") {
                $scope.perf_submenu = !$scope.perf_submenu;
                $scope.camp_submenu = false;
                $('.navbar').css('background-color', '#29b6f6');
                $('.logo').css('background-color', '#29b6f6');
				$scope.popupHeaderColor ='#29b6f6'
            } else if (_this.title == "CAMPAIGNS") {
				$scope.getAdvertiserDetails();
                $scope.camp_submenu = !$scope.camp_submenu;
                $scope.perf_submenu = false;
                $('.navbar').css('background-color', '#ff8f00');
                $('.logo').css('background-color', '#ff8f00');
				$scope.popupHeaderColor ='#ff8f00'
				$state.go('app.'+_this.state);
            } else if (_this.title == "REPORTS") {
                $scope.perf_submenu = false;
                $scope.camp_submenu = false;
//                $('.navbar').css('background-color', '#9c27b0');
//                $('.logo').css('background-color', '#9c27b0');
				$scope.popupHeaderColor ='#9c27b0'
                $state.go('app.'+_this.state);
                  
            } else if (_this.title == "BRE") {
					$scope.perf_submenu = false;
					$scope.camp_submenu = false;
					$('.navbar').css('background-color', '#F1C40F');
					$('.logo').css('background-color', '#F1C40F');
					$scope.popupHeaderColor ='#F1C40F'					  
			}
  }
       

        };
        $scope.menusrc = ['currency', 'campaign_perfomance', 'expected-actual', 'metric'];

        $scope.click_perf_submenu = function (obj, _index, elm)
        {
             $scope.perf_submenu = false;
              
            $timeout(function () {
                var el = angular.element('#submenu' + _index);
                el.removeClass("submenu-sidebar-menu");
                el.addClass("active-bg");
                el[0].childNodes[1].children[0].src = "images/accountDashboard/" + $scope.menusrc[_index - 1] + "_selected.svg";
                el[0].childNodes[1].childNodes[4].src = "images/accountDashboard/menu-arrow-right.svg";
                el[0].childNodes[1].childNodes[4].style.visibility = "visible";
            }, 200)

        }
        $scope.getAdvertiserDetails = function () {
            //$scope.accountId = "100003"  // need to change from service integration
            $http({
                method: 'GET',
                url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $scope.advertiserDetails = response.data.advDataFetchResponse;
                } else {// failed
                    if(response.data.appStatus > 0 && response.data.errorMessage=='Access token is invalid or expired'){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                }
            });
        }
        
        $scope.downloadAdvertiserLogo = function (advertiserLogoUrl, loopKey) {


            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths": [advertiserLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer + '/downloadimages',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (resp) {
                $scope.advertiserLogo[loopKey] = resp.data.imageContent[advertiserLogoUrl];
            });
        }
        $scope.activeSubMenu = function (advObj, _index)
        {			
            $scope.camp_submenu = false;
            $window.localStorage.setItem("advertiserId", advObj.advertiserId);
			netWorkData.networkDataFetch()
			//$scope.subMenState = "parentcampaign";
			$state.go('app.parentcampaign');	
			sharedService.store.getData();
            $timeout(function () {
                var el = angular.element('#submenu' + _index);
                el.removeClass("submenu-sidebar-menu");
                el.addClass("active-bg");
                el[0].childNodes[1].childNodes[5].src = "images/accountDashboard/menu-arrow-right.svg";
                el[0].childNodes[1].childNodes[5].style.visibility = "visible";
            }, 200)
        }


        $scope.loadIn1 = function(elm){ 
	$timeout(function () {
		var parentSrc1  = $(".submenu-sidebar-menu li")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active-bg");
		if(activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/accountDashboard/"+$scope.menusrc[elm.$index]+"_selected.svg");
		}
	}, 100);
	
	
	};
	
	$scope.openNotification = function() {
			angular.element($('body').css("overflow-y", "hidden"))
			angular.element('#notificationContainer').hide();
			$scope.popupMessage = "Payment ID for this Payment is "
			var modalApproveReq = $(".notification_modalApprove");// Get the modal Approve req
			modalApproveReq.show();
			
		
			
		
	}
	$scope.hideNotification = function(){
		var modalApproveReq = $(".notification_modalApprove");// Get the modal Approve req
		modalApproveReq.hide();
		angular.element('#notificationContainer').hide();
		angular.element($('body').css("overflow-y", "scroll"))
	}
	
	$scope.hoverIn = function(elm){
		var parentSrc1  = $(".submenu-sidebar-menu li")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active-bg"); 
		if(!activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/accountDashboard/"+$scope.menusrc[elm.$index]+"_selected.svg");
		}
                //angular.element('#submenu1').addClass('disableElement');

//                angular.element('#submenu2').addClass('disableElement');
               
              // angular.element('#submenu3').addClass('disableElement');

	};

	$scope.hoverOut = function(elm){
		var parentSrc1  = $(".submenu-sidebar-menu li")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active-bg"); 
		if(!activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/accountDashboard/"+$scope.menusrc[elm.$index]+"_default.svg");
		}
	};

	  $("#feedbackLink").click(function () {
		var $newValue ='';	  
		var getUserID = $window.localStorage.getItem("userId");
		var getAccessToken = $window.localStorage.getItem("accessToken");
		var pathname = window.location.origin; 
		var url = window.location.href.split('#')[1]; 
        var $newValue = ''+pathname+'/cnaptest/feedback.jsp?userId='+getUserID+'&accessToken='+getAccessToken+'&pageURL='+url+'';
       // $(this).attr('href',$(this).attr('href').replace('http://10.142.129.35:8080/cnaptest/feedback.jsp', $newValue));		
		$(this).attr('href',$newValue);
    }); 
	
	 $scope.notificationItems = [{
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 2hrs ago",
                icon: "glyphicon glyphicon-search",
                state: false

            },
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 3hrs ago",
                icon: "\uf09a",
                state: false

            },
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 4hrs ago",
                icon: "\uf099",
                state: false

            }
        ];
	
	 $scope.notificationAlerts = [/* {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 2hrs ago",
                icon: "glyphicon glyphicon-search",
                state: false
			},
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 3hrs ago",
                icon: "\uf09a",
                state: false

            },
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 4hrs ago",
                icon: "\uf099",
                state: false

            },{
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 2hrs ago",
                icon: "glyphicon glyphicon-search",
                state: false
			},
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 3hrs ago",
                icon: "\uf09a",
                state: false

            },
            {
                content: "Your existing plan is getting expired in 3 days. Please renew/change your plan  to retain your exising accounts.",
                when: "Today 4hrs ago",
                icon: "\uf099",
                state: false

            } */
        ];
		/* $scope.showPopup = function(_data, actions){				
			$scope.popupTitle = "Your Payment was successful!";
			$timeout(function () {
			$scope.popupMessage = "Transaction ID for this Payment is "+$scope.paymentID+"."+" Confirmation email sent to your registered email id";
				var modalApproveReq = $(".paypal_success");// Get the modal Approve req
				modalApproveReq.show();
			}, 1500);
		
		}
		$scope.hidePayPalPopup = function(){
			var modalApproveReq = $(".paypal_modalApproveRenew");// Get the modal Approve req
			modalApproveReq.hide();
		}
		//---------------------------------------------------------------------------------------------
			// Render the PayPal button
			paypal.Button.render({
				// Set your environment
				env: 'production', // sandbox | production
				// PayPal Client IDs - replace with your own
				// Create a PayPal app: https://developer.paypal.com/developer/applications/create
				 style: {
					label: 'checkout', // checkout || credit
					size:  'small',    // tiny | small | medium
					shape: 'rect',     // pill | rect
					color: 'silver'      // gold | blue | silver
					
				},
				client: {
					sandbox:    'AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PiV8e1GWU6liB2CUXlkA59kJXE7M6R',
					production: 'Aco85QiB9jk8Q3GdsidqKVCXuPAAVbnqm0agscHCL2-K2Lu2L6MxDU2AwTZa-ALMn_N0z-s2MXKJBxqJ'
				},
				// Wait for the PayPal button to be clicked
				payment: function() {
					// Make a client-side call to the REST api to create the payment
					return paypal.rest.payment.create(this.props.env, this.props.client, {
						transactions: [
							{
								"amount": { 
									"total": $scope.totalAmount, 
									"currency": $scope.currencyCode,
									"details": {
										"subtotal": $scope.totalAmount
									}
								},
								"item_list": {
									"items": [
									  {
									  "name": $scope.currentPlan,
									  "description": "Brown color hat",
									  "quantity": "1",
									  "price": $scope.totalAmount,
									  "sku": $scope.planId,
									  "currency": $scope.currencyCode
								}]}
      
							}
						]
					});
				},
				// Wait for the payment to be authorized by the customer
				onAuthorize: function(data, actions) {
					// Execute the payment
					$scope.hidePayPalPopup();
					//console.log(data);
					//console.log(actions);
					return actions.payment.execute().then(function(resp) {
						//console.log(resp);
						$scope.paymentID = data.paymentID;
						$scope.showPopup(data, actions);					
						//$scope.paypalSuccessPopup = "block";

					   // document.querySelector('#paypal-button-container').innerText = 'Payment Complete!';
					});
				}

			}, '#paypal-button-container');
		
			
			//---------------------------------------------------------------------------------------------
		$scope.gotoPayPal = function(){
			var modalApproveReq = $(".notification_modalApprove");// Get the modal Approve req
			modalApproveReq.hide();	
			$("#notificationContainer").hide();
			$scope.popupTitle = "Confirm Plan Details";
			$timeout(function () {
			$scope.popupMessage = "You are about to upgrade your plan from SMB to Enterprise. To confirm, please click on PayPal button and proceed with the payment.";
				var modalApproveReq = $(".paypal_modalApproveRenew");// Get the modal Approve req
				modalApproveReq.show();
			}, 0);
			
		}
		 $scope.loadCurrencyCode = function(){
			$http.get("localData/currencyData.json").success(function (data){
				$scope.currencyList = data.currencyList;
				//console.log($scope.currencyList);
			});
		}  */ 
		
		$scope.dismissAlert = function(_content){
			
			$rootScope.progressLoader = "block";
			var modalApproveReq = $(".notification_modalApprove");// Get the modal Approve req
			modalApproveReq.hide();			
			var parameters ={};
			if($window.localStorage.getItem("role")== "Account"){
				 parameters = {
					'userId': $window.localStorage.getItem("userId"),
					'accessToken': $window.localStorage.getItem("accessToken"),
					"alertType":"ACCOUNT",
					"alertMessage":_content.alertMessage,
					"pageNavigationEnum":"BILLING",
					"alertId":_content.alertId,
					"status":"INACTIVE"
				}
			} else {
				 parameters = {
					'userId': $window.localStorage.getItem("userId"),
					'accessToken': $window.localStorage.getItem("accessToken"),
					"userNetworkMapId": $window.localStorage.getItem('userNetworkMapId'),
					"adCampaignId":_content.campaignId,
					"alertType":"BRE",
					"alertMessage":_content.alertMessage,
					"pageNavigationEnum":"NULL",
					"alertId":_content.alertId,
					"status":"INACTIVE"
				}
			}
            $http({
                method: 'POST',
                url: apiBase + '/user/savealert',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (resp) {
                console.log(resp);
				if(resp.data.appStatus==0) {
					$scope.popupTitle = "Alert Dismiss";
					$scope.popupMessage=resp.data.successMessage;
					$scope.showDismissPopup();
					$scope.init();
				} else {
					$scope.popupTitle = "Alert Dismiss";
					$scope.popupMessage=resp.data.errorMessage;
					$scope.showDismissPopup();
				}
				
            });
		}
		$scope.hideDismissPopup = function(){
			var modalApproveReq = $(".update_modal_Approve");// Get the modal Approve req
			modalApproveReq.hide();
		}
		$scope.showDismissPopup = function(){
			$("#notificationContainer").hide();
			$rootScope.progressLoader = "none";			
			angular.element($('body').css("overflow-y", "scroll"))			
			
			var modalApproveReq = $(".update_modal_Approve");// Get the modal Approve req
			modalApproveReq.show();
			
			
		}
	
		$scope.init = function(){
			if($window.localStorage.getItem("role")!= "Account"){
				$scope.isAccount = false;
			} else {
				$scope.isAccount = true;
			}
			 $http({
                method: 'GET',
                url: apiBase + '/user/readalerts?dataFetchType=LATEST',
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success 
					console.log(response.data.readNotificationResponse);
					$scope.alertCount = 0;	
					$scope.notificationAlerts = [];
					angular.forEach(response.data.readNotificationResponse, function (value, key) {
						var JsonObj = response.data.readNotificationResponse[key]
						var array = [];
						for (var i in JsonObj) {
							if (JsonObj.hasOwnProperty(i)) {
								array[+i] = JsonObj[i];
								$scope.alertCount++;
								console.log(array[+i]);
								
							}
							$scope.notificationAlerts.push(array[+i]);
						}
					})
					console.log($scope.alertCount);
                } else {// failed
                    if(response.data.appStatus > 0 && response.data.errorMessage=='Access token is invalid or expired'){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                }
            });
		}
		$scope.init();
	//	$scope.loadCurrencyCode();
		
		
        console.log('getting in to the app controller');
    }]);
