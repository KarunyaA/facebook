app.controller("appCtrladmin", ['$rootScope', '$scope',  '$timeout', '$state', '$location', 'Flash','appSettings',
function ($rootScope, $scope,  $timeout, $state, $location, Flash,appSettings) {

    $rootScope.theme = appSettings.theme;
    $rootScope.layout = appSettings.layout;

    var vm = this;

    //avalilable themes
    vm.themes = [
        {
            theme: "black",
            color: "skin-black",
            title: "Dark - Black Skin",
            icon:""
        },
        {
            theme: "black",
            color: "skin-black-light",
            title: "Light - Black Skin",
            icon:"-o"
        },
        {
            theme: "blue",
            color: "skin-blue",
            title: "Dark - Blue Skin",
            icon:""
        },
        {
            theme: "blue",
            color: "skin-blue-light",
            title: "Light - Blue Skin",
            icon:"-o"
        },
        {
            theme: "green",
            color: "skin-green",
            title: "Dark - Green Skin",
            icon:""
        },
        {
            theme: "green",
            color: "skin-green-light",
            title: "Light - Green Skin",
            icon:"-o"
        },
        {
            theme: "yellow",
            color: "skin-yellow",
            title: "Dark - Yellow Skin",
            icon:""
        },
        {
            theme: "yellow",
            color: "skin-yellow-light",
            title: "Light - Yellow Skin",
            icon:"-o"
        },
        {
            theme: "red",
            color: "skin-red",
            title: "Dark - Red Skin",
            icon: ""
        },
        {
            theme: "red",
            color: "skin-red-light",
            title: "Light - Red Skin",
            icon: "-o"
        },
        {
            theme: "purple",
            color: "skin-purple",
            title: "Dark - Purple Skin",
            icon: ""
        },
        {
            theme: "purple",
            color: "skin-purple-light",
            title: "Light - Purple Skin",
            icon: "-o"
        },
    ];

    //available layouts
    vm.layouts = [
        {
            name: "Boxed",
            layout: "layout-boxed"
        },
        {
            name: "Fixed",
            layout: "fixed"
        },
        {
            name: "Sidebar Collapse",
            layout: "sidebar-collapse"
        },
    ];


    //Main menu items of the dashboard
    vm.menuItems = [
        {
            title: "Admin Dashboard",
            icon: "images/global/dashboard_default.svg",
			icon_selected: "images/global/dashboard_default.svg",
            state: "adminhomedashboard",
            marginright: "30px",
            
        },
        {
            title: "User Details",
            icon: "images/global/user_default.svg",
			icon_selected: "images/global/user_default.svg",
            state: "adminuserdetails",
            marginright: "68px"
        },
        {
            title: "Network Details",
            icon: "images/global/network_summary_default.svg",
			icon_selected: "images/global/network_default.svg",
            state: "adminnetworkdetails",
            marginright: "44px"
        },
        {
            title: "Currency Details",
            icon: "images/global/currency_default.svg",
			icon_selected: "images/global/currency_default.svg",
            state: "admincurrencydetails",
            marginright: "42px"
        },
        {
            title: "Currency Conversion",
            icon: "images/global/currency_conversion_default.svg",
			icon_selected: "images/global/currency_conversion_default.svg",
            state: "admincurrencyconversion",
            marginright: "15px"
        }];
   
   
   
    //set the theme selected
    vm.setTheme = function (value) {
        $rootScope.theme = value;
    };


    //set the Layout in normal view
    vm.setLayout = function (value) {
        $rootScope.layout = value;
    };

        //controll sidebar open & close in mobile and normal view

    vm.sideBar = function (value) {
        if($(window).width()<=767){
        if ($("body").hasClass('sidebar-open'))
            $("body").removeClass('sidebar-open');
        else
            $("body").addClass('sidebar-open');
        }
        else {   
            if(value==1){
				if ($("body").hasClass('sidebar-collapse')){
					$(".fa-angle .fa-angle-left").show();
					$(".fa-angle .fa-angle-right").hide();
					$("body").removeClass('sidebar-collapse');
				}
				else{ 
					$(".fa-angle .fa-angle-right").show();
					$(".fa-angle .fa-angle-left").hide();
					$("body").addClass('sidebar-collapse');
				}
            }
        }
    };
	
	$scope.menusrc = ['dashboard','user','network','currency','currency_conversion'];
	
	$scope.loadIn = function(elm){ 
	$timeout(function () {
		var parentSrc1  = $(".sidebar-menu li")[elm.$index];
                var parentSrc2  = $(".circleiconadmin")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active");
		if(activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/global/"+$scope.menusrc[elm.$index]+"_default.svg");
                        $(parentSrc2).css("background-color","#00b698");
		}
	}, 100);
	
	
	};
	$scope.hoverIn = function(elm){
		var parentSrc1  = $(".sidebar-menu li")[elm.$index];
                var parentSrc2  = $(".circleiconadmin")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active"); 
		if(!activeMenuCls){
		$(parentSrc1).find("a img").attr("src","images/global/"+$scope.menusrc[elm.$index]+"_default.svg");
                $(parentSrc2).css("background-color","#00b698");
            }
	};

	$scope.hoverOut = function(elm){
		var parentSrc1  = $(".sidebar-menu li")[elm.$index];
                var parentSrc2  = $(".circleiconadmin")[elm.$index];
		var activeMenuCls = $(parentSrc1).hasClass("active"); 
		if(!activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/global/"+$scope.menusrc[elm.$index]+"_default.svg");
                        $(parentSrc2).css("background-color"," #383b47");

            }
	};

	
	vm.activeMenu = function(elm){ 
		var menuLength = $(".sidebar-menu li").length;
                
		for(var i=0;i<=menuLength;i++){
			var parentSrc  = $(".sidebar-menu li")[i];
                        var parentSrc2  = $(".circleiconadmin")[i];
			$(parentSrc).find("a img").attr("src","images/global/"+$scope.menusrc[i]+"_default.svg");
                       $(parentSrc2).css("background-color"," #383b47");
                      
                }
                
		var parentSrc1  = $(".sidebar-menu li")[elm.$index];
                var parentSrc2  = $(".circleiconadmin")[elm.$index];
		$(parentSrc1).find("a img").attr("src","images/global/"+$scope.menusrc[elm.$index]+"_default.svg");
                $(parentSrc2).css("background-color","#383b47");
                var activeMenuCls = $(parentSrc1).hasClass("active");
                for(var i=0;i<=menuLength;i++){
			if($(".sidebar-menu li")[i] != activeMenuCls){
			$(parentSrc1).find("a img").attr("src","images/global/"+$scope.menusrc[elm.$index]+"_default.svg");
                        $(parentSrc2).css("background-color"," #00b698");
            }
                }


	}
	
	
   
    vm.search = function () {
        $state.go('app.search');
    };
	

}]);
