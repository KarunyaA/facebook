/* var replicatorApp=angular.module('replicator',['app']);

replicatorApp.controller("parserController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings','facebookGetPost', 'twitterGetPost', 'apiService', '$q','parser', '$timeout',
    function($rootScope, $scope, $state, catalyst, $location, Flash, $window, $http, $filter, $compile, appSettings, facebookGetPost, twitterGetPost, apiService, $q, parser, $timeout) {
		
		console.log(parser);
		console.log(field_mapping);
		alert('parser parser')
		
		
    }
]); */


app.factory('parser', ['$q', '$http','$timeout','$rootScope','$window','facebookGetPost', 'twitterGetPost', '$state', '$filter', function($q, $http, $timeout, $rootScope, $window, facebookGetPost, twitterGetPost, $state, $filter){
	var obj = {};
	//-------------------------------------------------------------------------------
	
	obj.routeFromHere = function(redirect) {
		if(redirect == "audience"){
			$state.go('app.fbBYPReplicatorAudienceDetails');
		}
	}
	
	
	//-------------------------------------------------------------------------------
	//var file = location.pathname.split( "/" ).pop();
	
	obj.loadjscssfile = function(filename, filetype) {
		console.log('loadjscssfile');
	  if (filetype == "js") { //if filename is a external JavaScript file
		// alert('called');
		var fileref = document.createElement('script')
		fileref.setAttribute("type", "text/javascript")
		fileref.setAttribute("src", filename)
		
	  } else if (filetype == "css") { //if filename is an external CSS file
		var fileref = document.createElement("link")
		fileref.setAttribute("rel", "stylesheet")
		fileref.setAttribute("type", "text/css")
		fileref.setAttribute("href", filename)
	  }
	  if (typeof fileref != "undefined") {
		  var head  = document.getElementsByTagName('ui-view')[0];
		  head.appendChild(fileref);
		  console.log('updated')
	  }
	}
	
	//-------------------------------------------------------------------------------------
	obj.getParsedObject = function(userData ,category){
		  var obj;				
			function traverse(jsonObj, category) {
				if( typeof jsonObj == "object" ) {
					try {
					$.each(jsonObj, function(k,v) {
						if(k == category){
							obj = v;
						} else {
							traverse(v,category);
						}
						
					});
					} catch(err){
						console.log('error')
					}
				}
				else {
					// jsonOb is a number or string
				}
			}
			traverse(userData,category)
			console.log(obj)
			return obj;
	  }
	//-------------------------------------------------------------------------------------	
	obj.dynamicLoader = function(name, type){
		var jsPath = 'app/modules/twitterReplicator/${ name }.js';
		var promisesCache = {};
		var path = jsPath.replace('${ name }', name);
		var promise = promisesCache[name];
		if (!promise) {
			if(type !='css') {
				promise = $http.get(name);
				promisesCache[name] = promise;
			
				
				return promise.then(function(result) {
					//  eval(result.data);
					// console.log(result.data);		
						var head  = document.getElementsByTagName('ui-view')[0];
						var link  = document.createElement('script');
						link.rel  = 'js';
						link.type = 'text/javascript';
						link.href = name;
						link.media = 'all';
						head.appendChild(link);
						console.log(head);
					});
			} else {
				promise = $http.get(name);
				promisesCache[name] = promise;
			
				return promise.then(function(result) {
				//  eval(result.data);
				// console.log(result.data);		
					var head  = document.getElementsByTagName('ui-view')[0];
					var link  = document.createElement('link');
					link.rel  = 'stylesheet';
					link.type = 'text/css';
					link.href = name;
					link.media = 'all';
					head.appendChild(link);
					console.log(head);
				});
			}
			
		}
		return promise; 		
	}
	//--------------------------------------------------------------------------------------
	obj.getSetParser = function(cNetwork, campaignObjective, targetedNetwork){
		$rootScope.currentNetwork = cNetwork;
		$rootScope.campaignObjective = campaignObjective;
		$rootScope.targetedNetwork = targetedNetwork;
		var twcampaignObjective;
		var fbcampaignObjective =[];
		console.log($rootScope.currentNetwork + "--current network--" + $rootScope.campaignObjective + "--camp obj--" + $rootScope.targetedNetwork + "---target nw" );
		console.log($rootScope.campaignData);		
		console.log(objectiveMapping);
		if($rootScope.targetedNetwork == "Twitter"){
			console.log('Target is twitter network');
			angular.forEach(objectiveMapping, function (value, key) {
			console.log(objectiveMapping[key].facebook.length);
			for(var i=0;i<=objectiveMapping[key].facebook.length;i++){
					if ($rootScope.campaignObjective == objectiveMapping[key].facebook[i]) {
					twcampaignObjective = objectiveMapping[key].twitter;
					console.log(objectiveMapping[key].facebook[i]);
					}
			}
			}) 
			
			console.log(twcampaignObjective);
		
		//Campaign Name
		var campaignName = obj.getParsedObject($rootScope.campaignData, 'campaignDetails');
		
		//Gender Value
		var genderValue = obj.getParsedObject($rootScope.campaignData, 'genders');	
		console.log(genderValue);		
		if(genderValue == "1"){
			genderValue = "men";
		}
		else if(genderValue == "2"){
			genderValue = "women";
		}
		else{
			genderValue = "all";
		}
		
		//Location value fetch
		var getlocationValue = obj.getParsedObject($rootScope.campaignData, 'countries');
		var getcitiesValue = obj.getParsedObject($rootScope.campaignData, 'cities');
		var getregionsValue = obj.getParsedObject($rootScope.campaignData, 'regions');
		var locationValue = [];
		var networkAccessToken = $window.localStorage.getItem("networkAccessToken");		
		if (getlocationValue != '' && getlocationValue != undefined) {
			angular.forEach(getlocationValue, function (val, key) {
				var querystr = 'search?type=adgeolocationmeta&countries=["' + val + '"]&access_token=' + networkAccessToken;
				facebookGetPost.getfacebookgraph(querystr).then(function (response) {
					var FBCountryDetails = response.data.data;					
					locationValue.push(FBCountryDetails.countries[val].name);
				})

			});
			
		}
		
		if (getcitiesValue != '' && getcitiesValue != undefined) {
		angular.forEach(getcitiesValue, function (val, key) {
			var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + networkAccessToken;
			facebookGetPost.getfacebookgraph(querystr).then(function (response) {
				var FBCountryDetails = response.data.data;				
				locationValue.push(val.name + ' / ' + val.region + ' / ' + FBCountryDetails.countries[val.country].name);				
			})
			});
	    }
		
		if (getregionsValue != '' && getregionsValue != undefined) {
		angular.forEach(getregionsValue, function (val, key) {
			var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + networkAccessToken;
			facebookGetPost.getfacebookgraph(querystr).then(function (response) {
				var FBCountryDetails = response.data.data;				
				locationValue.push(val.name + ' / '  + FBCountryDetails.countries[val.country].name);				
			})
			});
	    }
		
		console.log(locationValue);
		
		//Language Value fetch
		var getlanguage = obj.getParsedObject($rootScope.campaignData, 'locales');
		var languageValue = [];
		if (getlanguage != '' && getlanguage != undefined) {
		var querystr = "search?access_token=" + networkAccessToken + "&type=adlocale";
		facebookGetPost.getfacebookgraph(querystr).then(function (response) {
			var FBLanguageDetails = response.data.data;
			angular.forEach(getlanguage, function (val) {
				var sObj = $filter('filter')(FBLanguageDetails, function (d) {
					return d.key == val;
				})[0];
				//$scope.campaignAudienceLanguageKeyArr.push(sObj.key);
				languageValue.push(sObj.name);
			});
		})
		}
		console.log(languageValue);
		
		
		var device_platforms = (obj.getParsedObject($rootScope.campaignData, 'device_platforms') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'device_platforms');
		console.log(device_platforms);
		var ageMinValue = (obj.getParsedObject($rootScope.campaignData, 'age_min') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'age_min');	
		console.log(ageMinValue);		
		var ageMaxValue = (obj.getParsedObject($rootScope.campaignData, 'age_max') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'age_max');	
		console.log(ageMaxValue);		
		var dailyBudget = (obj.getParsedObject($rootScope.campaignData, 'daily_budget') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'daily_budget');
		console.log(dailyBudget);		
		var lifetimeBudget = (obj.getParsedObject($rootScope.campaignData, 'lifetime_budget') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'lifetime_budget');		
		var isautobid = (obj.getParsedObject($rootScope.campaignData, 'is_autobid') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'is_autobid');		
		var pacing_type = (obj.getParsedObject($rootScope.campaignData, 'pacing_type') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'pacing_type');
		var schedule_start = (obj.getParsedObject($rootScope.campaignData, 'start_time') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'start_time');		
		var end_time = (obj.getParsedObject($rootScope.campaignData, 'end_time') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'end_time');		
		var targeting = (obj.getParsedObject($rootScope.campaignData, 'targeting') == undefined) ? "" : obj.getParsedObject($rootScope.campaignData, 'targeting');		
		if(targeting.behaviors == undefined){
			targeting.behaviors = "";			
		}
		else if(targeting.interests == undefined){
			targeting.interests = "";
			
		}
		
			
		}
		
		else if($rootScope.targetedNetwork == "Facebook"){
                                                var locationValue =[];
                                                var languageValue=[];
                                                var platformArray =[];
                                                var interestArray = [];
                                                var behaviourArray = [];
                                                var genderValue;
                                                var ageValue;
                                                console.log(objectiveMapping)                                  
                                                angular.forEach(objectiveMapping, function (value, key) {
                                                    console.log(objectiveMapping[key]);
                                                                angular.forEach(objectiveMapping[key],function(objName){
                                                                                console.log(objName);
                                                                                if($rootScope.campaignObjective == objName){
                                                                                                fbcampaignObjective.push(objectiveMapping[key].facebook);
                                                                                }
                                                                                
                                                                })                                                             
                                                })             
                                var campaignName = obj.getParsedObject($rootScope.campaignData, 'twCampaignDetails');

                                console.log($rootScope.campaignData);
                                angular.forEach($rootScope.campaignData,function(targetKey,targetVal){
                                
                                                var checkType = obj.getParsedObject(targetKey, 'targeting_type');
                        var checkStatus = obj.getParsedObject(targetKey, 'twTargetingCriteriaStatus');
                                                if(checkType == "LOCATION" && checkStatus != "DELETED"){
                                                                var locValue = obj.getParsedObject(targetKey, 'name');                                                  
                                                                if(locationValue.indexOf(locValue) == -1){
                                                                                locationValue.push(locValue);   
                                                                }
                                                }
                                                else if(checkType == "LANGUAGE" && checkStatus != "DELETED"){                                                                                             
                                                                var lanValue = obj.getParsedObject(targetKey, 'name');                                                  
                                                                if(languageValue.indexOf(lanValue) == -1){
                                                                                languageValue.push(lanValue); 
                                                                }
                                                }
                                                else if(checkType == "GENDER" && checkStatus != "DELETED"){
                                                                                var gender = obj.getParsedObject(targetKey, 'gender');
                                                                                if(gender != undefined){
                                                                                                if(gender.targeting_value == "0"){
                                                                                                genderValue = "all";
                                                                                                }
                                                                                                else if(gender.targeting_value == "1"){
                                                                                                                genderValue = "men";
                                                                                                }
                                                                                                else if(gender.targeting_value == "2"){
                                                                                                                genderValue = "women";
                                                                                                }
                                                                                }
                                                                                
                                                }
                                                else if(checkType == "PLATFORM" && checkStatus != "DELETED"){
                                                                var platformValue = obj.getParsedObject(targetKey, 'name');                                                      
                                                                if(platformArray.indexOf(platformValue) == -1){
                                                                                platformArray.push(platformValue);       
                                                                }
                                                }
                                                else if(checkType == "INTEREST" && checkStatus != "DELETED"){
                                                                var interestValue = obj.getParsedObject(targetKey, 'name');
                                                                if(interestArray.indexOf(interestValue) == -1){
                                                                                interestArray.push(interestValue);           
                                                                }
                                                                
                                                }
                                                else if(checkType == "BEHAVIOUR" && checkStatus != "DELETED"){
                                                                var behaviourValue = obj.getParsedObject(targetKey, 'name');                                                    
                                                                if(behaviourArray.indexOf(behaviourValue) == -1){
                                                                                behaviourArray.push(behaviourValue); 
                                                                }
                                                }
                
                                })
                                
                                
                                var ageMinValue = obj.getParsedObject($rootScope.campaignData, 'age_min');                 
                                var ageMaxValue = obj.getParsedObject($rootScope.campaignData, 'age_max');                
                                var dailyBudget = obj.getParsedObject($rootScope.campaignData, 'daily_budget_amount_local_micro');                    
                                var lifetimeBudget = obj.getParsedObject($rootScope.campaignData, 'total_budget_amount_local_micro');                     
                                var isautobid = obj.getParsedObject($rootScope.campaignData, 'automatically_select_bid');
                                var pacing_type = obj.getParsedObject($rootScope.campaignData, 'standard_delivery');                 
                                var schedule_start = obj.getParsedObject($rootScope.campaignData, 'start_time');           
                                var end_time = obj.getParsedObject($rootScope.campaignData, 'end_time');
                                var bid_amount = obj.getParsedObject($rootScope.campaignData,'bid_amount_local_micro');
                                var targeting = {
                                                behaviors :"",
                                                interests :""
                                }                              
                                var device_platforms = "";
                                var user_device = "";
                                }

		
		
		
		
		
		
		$rootScope.fieldMapping = [
		{			
			"id": "twitter",
			"data":[
			{
				"campaign_name" : campaignName.name,
				"objective" : twcampaignObjective,
				"Gender": genderValue,	
				"Location": locationValue,
				"Language": languageValue,
				"AgeMin": ageMinValue,
				"AgeMax": ageMaxValue,
				"daily_budget" : dailyBudget,			
				"Bid Amount" : "",		
				"lifetime_budget": lifetimeBudget,
				"is_autobid" : isautobid,
				"schedule_start": schedule_start,
				"schedule_end": end_time,
				"pacing": pacing_type,
				"targeting_interest": targeting.interests,
				"targeting_behaviors": targeting.behaviors,
				"device_platforms": device_platforms
			}
			]
		},
		{
			"id": "facebook",
			"data":[
			{
				"campaign_name" : campaignName.name,
				"objective" : fbcampaignObjective,
				"daily_budget" : dailyBudget,
				"lineItem_name" :"",	//no line item name					
				"Gender": genderValue,	
				"Location": locationValue,
				"Language": languageValue,
				"Bid Amount" : bid_amount,	
				"lifetime_budget": lifetimeBudget,
				"is_autobid" : isautobid,
				"schedule_start": schedule_start,
				"schedule_end": end_time,					
				"AgeMin": ageMinValue,
				"AgeMax": ageMaxValue,
				"pacing": pacing_type,						
				"targeting_interest": interestArray,
				"targeting_behaviors":behaviourArray,
				"targeting_platform": platformArray 
			}
			

		]
		}
		
		
		]  
		
	}	
	
	
	
	//--------------------------------------------------------------------------------------
	obj.facebookParser = function(currentNetwork, targetNetwork){		
		console.log("replicator is in");
		var campData = $rootScope.campaignData;
		console.log(campData);
                if(currentNetwork =="Twitter" && targetNetwork == "Twitter"){
                    $rootScope.sameNetwork = true;
                }
                else{
                    $rootScope.sameNetwork = false;
                }
		$state.go('app.twReplicatorCampaignDetails');
		
	}
	//------------------------------------------------------------------------------------------------
	obj.twitterParser = function(currentNetwork, targetNetwork){
		var campData = $rootScope.campaignData;
		console.log(campData);
                if(currentNetwork == "facebook" && targetNetwork == "facebook"){
                    $rootScope.sameNetwork = true;
                }
                else{
                    $rootScope.sameNetwork = false;
                }
		$state.go('app.fbReplicatorCampaignDetails');	
	}
	return obj;
}]);
	


