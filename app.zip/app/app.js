var app = angular.module('app', ['ui.router', 'ui.bootstrap', 'ui.select', 'ngResource', 'flash',
    //main modules
    'login', 'dashboard', 'admindashboard','ngDraggableImage', 'replicator', 'ngSanitize','dynform']);

app.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', function ($stateProvider, $locationProvider, $urlRouterProvider, $modalInstance) {
    
    //IdleScreenList
    $stateProvider
       .state('app', {
           url: '/app',
           templateUrl: 'app/common/app.html',
           controller: 'appCtrl',
           controllerAs: 'vm',
           data: {
               pageTitle: 'Login'
           }
       })
	   .state('appAdmin', {
           url: '/appAdmin',
           templateUrl: 'app/common/appAdmin.html',
           controller: 'appCtrladmin',
           controllerAs: 'vm',
           data: {
               pageTitle: 'Login Admin'
           }
       });

    $urlRouterProvider.otherwise('login');

    //$urlRouterProvider.otherwise('app/dashboard');
    //$urlRouterProvider.otherwise('/app/dashboard');
}]);


app.factory('lazyService', [ '$http', function($http) {
    var jsPath = 'js/${ name }.js';
    var promisesCache = {};

    return {
        loadScript: function(name) {
            var path = jsPath.replace('${ name }', name);
            var promise = promisesCache[name];
            if (!promise) {
                promise = $http.get(path);
                promisesCache[name] = promise;

                return promise.then(function(result) {
                    eval(result.data);
                    console.info('Loaded: ' + path);
                });
            }

            return promise;
        }
    }
}]);

app.factory('httpApi', ['$q', '$http','$timeout','$rootScope','$window',  function($q, $http, $timeout, $rootScope, $window){
	
    var _config = {};
    _config.cache = false;
    _config.async = false;
    var obj = {};
	var defaultHeaders = {
		"Content-Type": "application/json"
	}
	//console.log('Before')
	//console.log(defaultHeaders)
	
	function uppendHeader(_headers){
		var obj= {}
		angular.forEach(_headers, function(value, key){			
			defaultHeaders[key] =value;
			
			angular.forEach(defaultHeaders, function(value1, key1){
			//console.log(value1[key1]+' same header '+value[key])				
				if(defaultHeaders[key1] == _headers[key]){
					//console.log('same header')
				}  else {
					defaultHeaders[key] =value;
				}
			});
		});
		
		return defaultHeaders;
	}
	
	
	
	
    obj.get = function(_url,_param) {  
		var configHeader = {
			'userId': $window.localStorage.getItem("userId"),
			'accessToken': $window.localStorage.getItem("accessToken")
		}
		
        var deffered = $q.defer();
        var resolved = false;
        _config.timeout = deffered.promise;  
		var data = {			
			dataType: 'json',
			method: 'GET',
			data : _param,
			headers: configHeader
		}	
		
        $http.get(_url, data, _config).then(function(response) { 
			//console.log(response);
            deffered.resolve(response);
            resolved = true;
        }, function(_err) {
        	deffered.resolve(_err);
        })
        
        $timeout(function() {
            if(!resolved){
                deffered.reject("Timeout Error");   
            }
        },60000) 

        return deffered.promise
    }
	
	obj.post = function(_url,_parameters){
        var deffered = $q.defer();
        var resolved = false;
        _config.timeout = deffered.promise;
		
		var data = _parameters;
		
        $http.post(_url,data,_config).then(function(response) {
			//console.log(data);
            deffered.resolve(response);
            resolved = true;
        }, function(_err) {
        	deffered.resolve(_err);
        })

        $timeout(function() {
            if(!resolved){
                deffered.reject("Timeout Error");
            }
        },60000) 

        return deffered.promise   
    }
    
    obj.delete = function(_url,_param) {  
		var configHeader = {
			'userId': $window.localStorage.getItem("userId"),
			'accessToken': $window.localStorage.getItem("accessToken")
		}
		
        var deffered = $q.defer();
        var resolved = false;
        _config.timeout = deffered.promise;  
		var data = {			
			dataType: 'json',
			method: 'GET',
			data : _param,
			headers: configHeader
		}	
		
        $http.delete(_url, data, _config).then(function(response) { 
			//console.log(response);
            deffered.resolve(response);
            resolved = true;
        }, function(_err) {
        	deffered.resolve(_err);
        })
        
        $timeout(function() {
            if(!resolved){
                deffered.reject("Timeout Error");   
            }
        },60000) 

        return deffered.promise
    }
	
	
	
    return obj;
		
}]);

//FB Factory for image and video upload

app.factory('transformData', ['$http', '$q', '$timeout', '$rootScope','$window', 'appSettings','$state','Flash','apiService', function($http, $q, timeout, $rootScope, $window, appSettings, $state, Flash, apiService){ 
				var obj = {};

				obj.uploadFileToUrl = function(url,_parameters,headers){
					return $http({
					url: url,
					method: 'POST',
					data: _parameters,		
					headers: headers,					
					transformRequest: angular.identity
	});
			
	}
	return obj;
	}])


app.constant('catalyst', {

})

app.factory('sharedService', function ($rootScope) {
    var mem = {}; 
    return {
        store: function (key, value) {
            $rootScope.$emit('scope.stored', key);
            mem[key] = value;
        },
        get: function (key) {
            return mem[key];
        }
    };
});
app.factory('sharedService1', function ($rootScope) {
    var mem = {}; 
    return {
        store: function (key, value) {
            $rootScope.$emit('scope.stored', key);
            mem[key] = value;
        },
        get: function (key) {
            return mem[key];
        }
    };
});



// set global configuration of application and it can be accessed by injecting appSettings in any modules
app.constant('appSettings', appConfig);

app.factory('netWorkData', ['$http', '$q', '$timeout', '$rootScope','$window', 'appSettings','$state','Flash','apiService', function($http, $q, timeout, $rootScope, $window, appSettings, $state, Flash, apiService){ 
	    var fbNetwork = appSettings.fbNetwork;
		var twNetwork = appSettings.twNetwork;
		HandleBackFunctionality();
        function HandleBackFunctionality()
        {            
            /* $rootScope.$on('$locationChangeStart', function(event, next, current){
                //alert('Sorry ! Back Button is disabled');
                event.preventDefault();
            }); */
            if(window.event)
            {
                if(window.event.clientX < 40 && window.event.clientY < 0)
                {
                  //alert("Browser back button is clicked...");
                  $window.localStorage.setItem("PageRefreshed",true);
                  //Flash.create('danger', 'Page Refreshed', 'large-text');
                  $state.go('login');  

                }
                else
                {
                  $window.localStorage.setItem("PageRefreshed",true);
                  //Flash.create('danger', 'Page Refreshed', 'large-text');
                  $state.go('login');  
                  //alert("Browser refresh button is clicked...");
                }
             }
             else
             {
                if(event.currentTarget.performance.navigation.type == 1)
                {
                    $window.localStorage.setItem("PageRefreshed",true);
                    $state.go('login');  
                    //alert("Browser refresh button is clicked...");
                }
                if(event.currentTarget.performance.navigation.type == 2)
                {
                    $window.localStorage.setItem("PageRefreshed",true);
                    $state.go('login');  
                    //alert("Browser back button is clicked...");
                }
             }
           
        }
    
    
        var obj = {};
	var apiBase = appSettings.apiBase;
	var allnetworksarray;
	var advertiserdetails;
	var accountNetworkDetails=[];
	var networksarrayforadvertiser = [];
	$rootScope.userNetworkMapIdArray = [];
	var duplicateCampaignStep=[];
	$rootScope.formChangeCount=0;
	$rootScope.overLayAudience = false;
	$rootScope.chartChange = false;
	$rootScope.freezeFlag  = false;
	var networksarrayforacc=[];
	obj.networkDataFetch = function(){
		//-----------get Advertiser details
            $rootScope.campaignSteps = [false,false,false,false,false];
            $rootScope.serviceResponses = {};
            var obj;
		$http({
			method: 'GET',
			url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
			headers: {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			}
		}).then(function (response) {
			if (response.data.appStatus == '0') {// success
				advertiserdetails = response.data.advDataFetchResponse;
				//console.log(advertiserdetails);
				fetchallnetwork();
			} else {// failed
                            if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                                $window.localStorage.setItem("TokenExpired",true);
                                $state.go('login');
                            }
			}
		});
		//-----------get fetchallnetwork details
		function fetchallnetwork(){
			$http({
			method: 'GET',
			url: apiBase + "/user/fetchallnetwork",
			headers: {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			}
			}).then(function (response) {
				if (response.data.appStatus == '0') {
					allnetworksarray = response.data.networkList;
					fetchadvertisernetwork();
					//console.log(allnetworksarray)
				}else{
					if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
						$window.localStorage.setItem("TokenExpired",true);
						$state.go('login');
					}
				}
			});
		}
		
		//-----------get fetchadvertisernetwork details
		function fetchadvertisernetwork() {
			$http({
				method: 'GET',
				url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
				headers: {
					'userId': $window.localStorage.getItem("userId"),
					'accessToken': $window.localStorage.getItem("accessToken")
				}
				}).then(function (response) {
					if (response.data.appStatus == '0') {// success
					   accountNetworkDetails = response.data.advertiserNetworkList;
					   networksarrayforacc = response.data.advertiserNetworkList;
					   //console.log(accountNetworkDetails);
						for (i = 0; i < accountNetworkDetails.length; i++){
							angular.forEach(allnetworksarray, function (val, key){
								if (accountNetworkDetails[i].networkId == val.networkId){
									networksarrayforadvertiser.push(val);
								}
							});
							if(i==(accountNetworkDetails.length-1)){
								//fetchUserNetWorkMapId();
								getusernetworkmapids();
							}
						}
						
					}else{
						if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
							$window.localStorage.setItem("TokenExpired",true);
							$state.go('login');
						}
					}
				});
		}
		
		function getusernetworkmapids(){
			console.log('************55555*********');
            var promises = [];
			var networkmaparray=[];
            angular.forEach(advertiserdetails, function (val, key){
                var networkdetailobj=[];
                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
				console.log(allnetworksarray);
                for (i = 0; i < networksarrayforacc.length; i++){   
                    if (val.advertiserEmail ==networksarrayforacc[i].userId){
                        for(var j = 0; j<allnetworksarray.length; j++){
                            if(allnetworksarray[j].networkId==networksarrayforacc[i].networkId){   
                                var obj2={
                                    "networkId" : allnetworksarray[j].networkId,
                                    "networkName" :allnetworksarray[j].networkName,
									"networkUrl" :allnetworksarray[j].networkUrl,
                                    "userNetworkMapId" : networksarrayforacc[i].userNetworkMapId
                                };
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                networkmaparray.push(obj);
				//getAdvertiserIdfromopsteam(); 
            });
          for (i = 0; i < networkmaparray.length; i++)
            {
                if (networkmaparray[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< networkmaparray[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
							if(networkmaparray[i].networkDetails[j].networkUrl == fbNetwork) {
								var module = '/readadaccounts?networkMapId=' + networkmaparray[i].networkDetails[j].userNetworkMapId;
								$window.localStorage.setItem("userNetworkMapId",networkmaparray[i].networkDetails[j].userNetworkMapId);
								getAccessToken(networkmaparray[i].networkDetails[j].userNetworkMapId);
							} else {
								var module = '/readadaccounts?userNetworkMapId=' + networkmaparray[i].networkDetails[j].userNetworkMapId;
								$window.localStorage.setItem("twUserNetworkMapId",networkmaparray[i].networkDetails[j].userNetworkMapId);
								getAccessTokenTw(networkmaparray[i].networkDetails[j].userNetworkMapId);
							}
                            
                            var header = {
                                headers: {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                }
                            };
							console.log(module,header,networkmaparray[i].networkDetails[j].networkUrl);
                            promises.push(apiService.getTw(module,header,networkmaparray[i].networkDetails[j].networkUrl).then(function(response)
                            {    
								console.log(response);
                                if(response.appStatus == 0)
                                {
									 if (response.hasOwnProperty('adAccounts')) {											
										angular.forEach(response.adAccounts, function (value, key) 
										{
											var json = response.adAccounts[key];
											console.log(json);
											var array = [];
											for(var i in json) {
												if (json.hasOwnProperty(i)) {
													array[+i] = json[i];
													var twAdAccountId = array[+i].twAdAccountId
													console.log(twAdAccountId);
													$window.localStorage.setItem("twNetworkAdAccountId",twAdAccountId)
												}
											}
										});
									} 
									if (response.hasOwnProperty('fbReadAdAccountResponse')) {											
										angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
										{
											var json = response.fbReadAdAccountResponse[key];
											console.log(json.fbAdAccountId);
											$window.localStorage.setItem("networkAdAccountId",json.fbAdAccountId)
											
										});
									} 
									
								}
                            }));
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
				
                    function(){
                      console.log('promises');
                    });

        };
		
		
		function fetchUserNetWorkMapId() {
			for (var i = 0; i < accountNetworkDetails.length; i++){
				angular.forEach(advertiserdetails, function (val, key) {
					if (val.advertiserEmail == accountNetworkDetails[i].userId){                              
						$rootScope.userNetworkMapIdArray.push(accountNetworkDetails[i].userNetworkMapId);
						$window.localStorage.setItem("userNetworkMapId", $rootScope.userNetworkMapIdArray[0]);
						readadAccountId($rootScope.userNetworkMapIdArray[0]);
						getAccessToken($rootScope.userNetworkMapIdArray[0]);
					}
				});
			}
                        
		}
		function readadAccountId(userNetworkMapId) {
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccounts?networkMapId=' + userNetworkMapId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
				console.log(response);
                if (response.data.appStatus == '0') {// success
                    angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {
                        var adaccountid = response.data.fbReadAdAccountResponse[key].fbAdAccountId;
                        $window.localStorage.setItem("networkAdAccountId", adaccountid);
                    });                   
                } else {// failed
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                }

            });

        };
		
		
		function getAccessToken(userNetworkMapId){
			console.log('getAccessToken');
			$http({
				method: 'GET',
				url: apiBase + '/user/readnetworktoken?userNetworkMapId=' + userNetworkMapId,
				headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
			}).then(function(response) {
				console.log(response);
						var jsonObj = response.data.networkTokenDetails;
                        angular.forEach(jsonObj, function(value, key) {
                            var JsonObj = jsonObj[key];
                            console.log(JsonObj);
                            var array = [];
                            for (var i in JsonObj) {
                                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                    array[+i] = JsonObj[i];
                                    var networkDetails = array[+i];
									console.log(networkDetails.accessToken);
                                    $window.localStorage.setItem("networkAccessToken", networkDetails.accessToken);
                                }
                            }
                        });				
				
			})
			return obj;
		}
		function getAccessTokenTw(userNetworkMapId){
			console.log('getAccessToken');
			$http({
				method: 'GET',
				url: apiBase + '/user/readnetworktoken?userNetworkMapId=' + userNetworkMapId,
				headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
			}).then(function(response) {
				console.log(response);
						var jsonObj = response.data.networkTokenDetails;
                        angular.forEach(jsonObj, function(value, key) {
                            var JsonObj = jsonObj[key];
                            console.log(JsonObj);
                            var array = [];
                            for (var i in JsonObj) {
                                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                    array[+i] = JsonObj[i];
                                    var networkDetails = array[+i];
									console.log(networkDetails.accessToken);
                                    $window.localStorage.setItem("twNetworkAccessToken", networkDetails.accessToken);
                                }
                            }
                        });				
				
			})
			return obj;
		}
	
		return obj;
	}
	
         function getAdvertiserIdfromopsteam() {
            $rootScope.progressLoader = "block";
            //$scope.accountId = "100003"  // need to change from service integration
            $http({
                method: 'GET',
                url: apiBase + '/user/opsteamdatafetch?opsteamId=' + $window.localStorage.getItem("OpsTeamId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    var opsteamdetails = response.data.fetchOpsteamResponse;
                    var advertiserId= opsteamdetails.advertiserId;
                    console.log(advertiserId);
                    $window.localStorage.setItem("advertiserId",advertiserId);

                } 
            });
        }
        
	obj.freezeNav = function(){
		duplicateCampaignStep=[];
		angular.forEach($rootScope.campaignSteps, function(value, key){
			if($rootScope.campaignSteps[key] ==true){
				duplicateCampaignStep[key] = true;
			}
			$rootScope.campaignSteps[key] = false;					
		});
	}
	obj.unFreezeNav = function(){		
		angular.forEach(duplicateCampaignStep, function(value, key){
			if(duplicateCampaignStep[key] ==true){
				$rootScope.campaignSteps[key] = true;
			}
							
		});
		console.log($rootScope.campaignSteps);
		$rootScope.formChangeCount=0;
	}
	return obj;
}])


app.factory('globalData', ['$http', '$q', '$timeout', '$rootScope','$window','$state', function(http, q, timeout, $rootScope, $window, $state){ 
        
	$rootScope.globalState =""
	$rootScope.adsetSchedule =[];
	$rootScope.chartArray=[];
	$rootScope.campaignState = "create";
	$rootScope.step = 0;
	$rootScope.currentCampaignNetwork='Facebook';
	$window.localStorage.setItem("campaignState",$rootScope.campaignState)
   $rootScope.isChildCampaignEdit = false;
   $rootScope.campaignSteps = [false,false,false,false,false];
   $rootScope.faceBookFormData;
   $rootScope.twitterFormData;
   $rootScope.campaignGoLive = true;
   $rootScope.campaignDetails = [];
   $rootScope.campaignData = {};
   $rootScope.draftCampaignData = {};
   $rootScope.progressLoader = "none";
   $rootScope.currentNetwork = "Facebook";
   $rootScope.targetedNetwork = "";
   $rootScope.accountId= "";
   $rootScope.campaignId="";
   $rootScope.adSetId="";
   $rootScope.adId="";
   $rootScope.adCreativeId="";
   $rootScope.campaignId="";
   $rootScope.campaignStatus="";
   $rootScope.noEdit = false;
   var userData = null;
   var obj = {};
   var initObj = {}
   //Global variable to hold the JSON object
	var g_objJSON;
	var Draftg_objJSON;
	var v_aJSON = [];
	var v_hObject = {};
	var v_hTempHash = {};
   var networkJSON;
   var draftNetworkJSON;
   var keyVal;
   $rootScope.flag = false;
   var userDetails = {
	"Facebook": [],
	"Twitter": []
}
var draftUserDetails = {
	"Facebook": [],
	"Twitter": []
}

		obj.getKeyValues = function(userData ,category){
		  var obj;
				
			function traverse(jsonObj, category) {
				if( typeof jsonObj == "object" ) {
					$.each(jsonObj, function(k,v) {
						if(k == category){
							obj = v;
						} else {
							traverse(v,category);
						}
						
					});
				}
				else {
					// jsonOb is a number or string
				}
			}
			traverse(userData,category)
			console.log(obj)
			return obj;
	  }
	  
	  obj.getLocal = function(category){
		  var obj;
		  var cNetwork = $rootScope.currentNetwork;
		   try {
				userData = JSON.parse($window.localStorage.getItem("campaignData")); 
			} catch (e) {
				userData = $window.localStorage.getItem("campaignData");
			}
			traverse(userData,category)
			
			function traverse(jsonObj, category) {
				if( typeof jsonObj == "object" ) {
					$.each(jsonObj, function(k,v) {
						if(k == category){
							//console.log(v)
							obj = v;
						} else {
							traverse(v,category);
						}
						
					});
				}
				else {
					// jsonOb is a number or string
				}
			}
			
			return obj;
	  }
	  
		
	  
	  obj.addValueInObject = function(value, object, key){
		/*
		//var addMoreOptions = eval('{"'  + key + '":' +  value + '}');
		var addMoreOptions = {[key]:value};
	//	console.log(addMoreOptions)
        if(addMoreOptions != null) {
            var textObject = JSON.stringify(object);
			//console.log(textObject)
            textObject = textObject.substring(1,textObject.length-1);
			//console.log(textObject)
            var AddElement = JSON.stringify(addMoreOptions);
		//	console.log(AddElement)
			var tempObj = AddElement.substring(1,AddElement.length-1)
		//	console.log(tempObj)
        }
		var myObj = function(){
			this.property = 'foo';			
		}
		myObj.prototype.objProp = true;
		var newObj = new myObj();
		console.log(newObj)
        return object;*/
	  }
	 
		function isEmpty(val) {
			var len = val.length,
				i;

			if (len > 0) {
				for (i = 0; i < len; ++i) {
					if (!emptyObject(val[i])) {
						return false;
					}
				}
			}
			return true;
		}

		function emptyObject(o) {
			for (var key in o) {
				if (o.hasOwnProperty(key)) {
					return false;
				}
			}
			return true;
		}
	 
	 obj.createObject = function(category, parameter, paramValue){
		
	 }
	 var tmp2;
	 
	 function isEmpty(obj) {
		for(var key in obj) {
			if(obj.hasOwnProperty(key))
				return false;
		}
		return true;
	}
	checkIfExistOrNot = function(object, value) {
		
		for (var x in object) {
			if (object.hasOwnProperty(x)) {
				if (typeof object[x] == 'object') {	
					//console.log(x+" :: "+value)
					if(x == value) {
						//console.log('true')	
						$rootScope.flag = true;
					} else {
						checkIfExistOrNot(object[x], value);
					}
				}
			}
		 
		}
		 return $rootScope.flag;
	}
	 obj.setLocal = function(category, parameter, paramValue){
		var paramValue = {"data":paramValue};
		var cNetwork = $window.localStorage.getItem("networkName")
		if ($window.localStorage.getItem("isChildCampaignEdit") == "true") {
			try {
				networkJSON = JSON.parse($window.localStorage.getItem("campaignData")); 
			} catch (e) {
				networkJSON = $window.localStorage.getItem("campaignData");
			}
			g_objJSON = networkJSON[cNetwork]
			if(g_objJSON) {	
				if(category =="account"){
					$rootScope.accountId= parameter;				
						tmp2 = ObjectInject(g_objJSON, parameter, paramValue, function(pk, pv, nk, nv){ 
					});
					g_objJSON = tmp2;
					
				} else if(category =="campaign"){
					$rootScope.campaignId= parameter;
					var flag = checkIfExistOrNot(g_objJSON, parameter, function(){ 
					});	
					if(flag) {
						var tmp2 = findAndReplace(g_objJSON, parameter, paramValue, function(){ 
										});	
						console.log(tmp2)
					} else {
						var _obj=g_objJSON[$rootScope.accountId]
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON[$rootScope.accountId]= tmp2
					}
					//
				} else if(category =="adset"){
					$rootScope.adSetId= parameter;
					var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId]
						tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
					});
					g_objJSON[$rootScope.accountId][$rootScope.campaignId]= tmp2
				
				} else if(category =="adCreativeId"){
					console.log(parameter);
					$rootScope.adCreativeId= parameter;
					var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId]
						
						try {
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
							});
						} catch(e) {
								
						}
								
					g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId]= tmp2
									
				} else if(category =="adId"){
					$rootScope.adId= parameter;
					var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId][$rootScope.adCreativeId]
						tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
					});
					g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId][$rootScope.adCreativeId] = tmp2
				}
			}
		} else {
			
			
			try {
				networkJSON = JSON.parse($window.localStorage.getItem("campaignData")); 
			} catch (e) {
				networkJSON = $window.localStorage.getItem("campaignData");
			}
			g_objJSON = networkJSON[cNetwork]
			console.log($rootScope.currentNetwork);
			if(cNetwork == "Facebook") {
				if(g_objJSON) {					
					if(category =="account"){
						$rootScope.accountId= parameter;				
							tmp2 = ObjectInject(g_objJSON, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON = tmp2;
						
					} else if(category =="campaign"){
						$rootScope.campaignId= parameter;
						$rootScope.accountId = $window.localStorage.getItem("accountId")
						var flag = checkIfExistOrNot(g_objJSON, parameter, function(){ 
						});	
						console.log(flag)
						if(flag) {
							console.log(flag)
							var tmp2 = findAndReplace(g_objJSON, parameter, paramValue, function(){ 
											});	
							console.log(tmp2)
						} else {
							var _obj=g_objJSON[$rootScope.accountId]
								tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
							});
							g_objJSON[$rootScope.accountId]= tmp2
						}
						
						
						/* var _obj=g_objJSON[$rootScope.accountId]	
							console.log(_obj)
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON[$rootScope.accountId]= tmp2	 */			
						
					}  else if(category =="adset"){
						$rootScope.adSetId= parameter;
						$rootScope.campaignId = $window.localStorage.getItem("campaignId")
						console.log(flag)
						if(flag) {
							console.log(flag)
							var tmp2 = findAndReplace(g_objJSON, parameter, paramValue, function(){ 
											});	
							console.log(tmp2)
						} else {
							var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId]
								tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
							});
							g_objJSON[$rootScope.accountId][$rootScope.campaignId]= tmp2 
						}
						
						
						/* 
						var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId]
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON[$rootScope.accountId][$rootScope.campaignId]= tmp2 */
					
					}  else if(category =="adId"){
						console.log(paramValue)
						$rootScope.adId= parameter;
						$rootScope.campaignId = $window.localStorage.getItem("campaignId")
						$rootScope.adSetId = $window.localStorage.getItem("adsetId")
						console.log($rootScope.adSetId)
						var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId]
						console.log(_obj)
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});				
						console.log(tmp2)
						g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId]= tmp2
						console.log(g_objJSON)
					} else if(category =="adCreativeId"){
						$rootScope.adId= parameter;
						$rootScope.adId= $window.localStorage.getItem("adId")
						$rootScope.campaignId = $window.localStorage.getItem("campaignId")
						$rootScope.adSetId = $window.localStorage.getItem("adsetId")
						var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId][$rootScope.adId]
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON[$rootScope.accountId][$rootScope.campaignId][$rootScope.adSetId][$rootScope.adId] = tmp2
						
					}
				}
			}
			if(cNetwork == "Twitter") {
				if(g_objJSON) {					
					if(category =="account"){
						$rootScope.accountId= parameter;				
							tmp2 = ObjectInject(g_objJSON, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						g_objJSON = tmp2;
						
					} else if(category =="campaign"){
						$rootScope.campaignId= parameter;
						$rootScope.accountId = $window.localStorage.getItem("accountId")
						var flag = checkIfExistOrNot(g_objJSON, parameter, function(){ 
						});	
						if(flag) {
							var tmp2 = findAndReplace(g_objJSON, parameter, paramValue, function(){ 
											});	
						} else {
							var _obj=g_objJSON[$rootScope.accountId]
								tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
							});
							g_objJSON[$rootScope.accountId]= tmp2
						}		
						
					} else if(category =="lineItem"){
						
						$rootScope.campaignId = $window.localStorage.getItem("twCampaignId")
						var flag = checkIfExistOrNot(g_objJSON, parameter, function(){ 
						});
						console.log(flag)						
						if(flag) {							
							var tmp2 = findAndReplace(g_objJSON, parameter, paramValue, function(){ 
						});	
							console.log(tmp2)
						} else {
							var _obj=g_objJSON[$rootScope.accountId][$rootScope.campaignId]
								tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
							});
							g_objJSON[$rootScope.accountId][$rootScope.campaignId]= tmp2 
						}
					} 
				}
			}
			
		}
		networkJSON[cNetwork]=g_objJSON;
		console.log(networkJSON)
		$window.localStorage.setItem("campaignData", JSON.stringify(networkJSON));
   }
	   ObjectInject = function(object, newKey, newVal, fn, bind){
		var prevKey=null, prevVal=null, inserted=false, newobject={};
		//console.log(object)
		for(var currKey in object){
			if (object.hasOwnProperty(currKey)){
				var currVal = object[currKey];
				//console.log(currKey)
				if( !inserted && fn.call(bind, prevKey, prevVal, currKey, currVal) ){
					newobject[newKey] = newVal;
					inserted=true;
				}
				newobject[currKey] = currVal;
				prevKey = currKey;
				prevVal = currVal;
			} 
		}
		if(!inserted) {
			
			newobject[newKey] = newVal;
		}
		return newobject;
	};
	
	 ObjectInjectDraft = function(object, newKey, newVal, fn, bind){
		var prevKey=null, prevVal=null, inserted=false, newobject={};
		//console.log(object)
		for(var currKey in object){
			if (object.hasOwnProperty(currKey)){
				var currVal = object[currKey];
				//console.log(currKey)
				if( !inserted && fn.call(bind, prevKey, prevVal, currKey, currVal) ){
					newobject[newKey] = newVal;
					inserted=true;
				}
				newobject[currKey] = currVal;
				prevKey = currKey;
				prevVal = currVal;
			} 
		}
		if(!inserted) {
			
			newobject[newKey] = newVal;
		}
		return newobject;
	};
	
	findAndReplace = function(object, value, replacevalue){
			//console.log(object)
		for (var x in object) {
			if (object.hasOwnProperty(x)) {
			  if (typeof object[x] == 'object') {				 
				  if(x == value) {	
					//console.log(object[x])
					//console.log(replacevalue.data)
					object[x]['data'] = replacevalue.data
					//object = JSON.stringify(object[x])					
					//console.log(object)	
					//object[value] = replacevalue;
					//g_objJSON = object	
					break; // uncomment to stop after first replacement
				  } else {
						findAndReplace(object[x], value, replacevalue);
				  }
				 
			  } else {
				 
			  }
			  
			  
			/*   if (object[x] == value) { 			
				object[value] = replacevalue;
				console.log(object)
				return object;
				// break; // uncomment to stop after first replacement
			  } */
			}
		}
		return object;
	};
	
   function mix(source, target) {
	   for(var key in source) {
		 if (source.hasOwnProperty(key)) {
			target[key] = source[key];
		 }
	   }

	}
	
	obj.setDraftLocal = function(category, parameter, paramValue){
		console.log(category)
		 var paramValue = {"data":paramValue};
		var cNetwork = $rootScope.currentNetwork;
		//console.log($window.localStorage.getItem("isChildCampaignEdit"))
		//if ($window.localStorage.getItem("isChildCampaignEdit") == "true") {
			try {
				draftNetworkJSON = JSON.parse($window.localStorage.getItem("draftCampaignData")); 
			} catch (e) {
				draftNetworkJSON = $window.localStorage.getItem("draftCampaignData");
			}
			Draftg_objJSON = draftNetworkJSON[cNetwork]
			if(Draftg_objJSON) {	
				if(category =="account"){
					$rootScope.accountId= parameter;				
						tmp2 = ObjectInjectDraft(Draftg_objJSON, parameter, paramValue, function(pk, pv, nk, nv){ 
					});
					console.log(tmp2);
					Draftg_objJSON = tmp2;
					
				} else if(category =="campaign"){
					$rootScope.campaignId= parameter;
					var flag = checkIfExistOrNot(Draftg_objJSON, parameter, function(){ 
					});	
					if(flag) {
						var tmp2 = findAndReplace(Draftg_objJSON, parameter, paramValue, function(){ 
										});	
						console.log(tmp2)
					} else {
						var _obj=Draftg_objJSON[$rootScope.accountId]
							tmp2 = ObjectInject(_obj, parameter, paramValue, function(pk, pv, nk, nv){ 
						});
						Draftg_objJSON[$rootScope.accountId]= tmp2
					}
					//
				} 
			}
		//}
		console.log(Draftg_objJSON)
		draftNetworkJSON[cNetwork]=Draftg_objJSON;
		$window.localStorage.setItem("draftCampaignData", JSON.stringify(draftNetworkJSON));
   }
   
	 obj.campaignDataUpdate = function(){
		 $rootScope.flag = false;
		$window.localStorage.removeItem("campaignData")
		$window.localStorage.setItem("campaignData", JSON.stringify(userDetails));   
		console.log('campagsdgsd')
	 }
   obj.initialUpdate = function(){
	  
	   try {
			networkJSON = JSON.parse($window.localStorage.getItem("campaignData")); 
		} catch (e) {
			networkJSON = $window.localStorage.getItem("campaignData");
		}
		
		if(networkJSON == null){
			$window.localStorage.removeItem("campaignData")
			$window.localStorage.setItem("campaignData", JSON.stringify(userDetails));  
		} 
		
		 try {
			draftNetworkJSON = JSON.parse($window.localStorage.getItem("draftCampaignData")); 
		} catch (e) {
			draftNetworkJSON = $window.localStorage.getItem("draftCampaignData");
		}
		if(draftNetworkJSON == null){
			$window.localStorage.removeItem("draftCampaignData")
			$window.localStorage.setItem("draftCampaignData", JSON.stringify(draftUserDetails));  
		} 
   }

   return obj;
   
      
   
}])

