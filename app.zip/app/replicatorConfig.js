var replicator = angular.module('replicator', ['ui.router', 'oc.lazyLoad', 'ui.bootstrap', 'ngResource', 'flash']);

replicator.config(['$stateProvider', '$controllerProvider', '$locationProvider', '$ocLazyLoadProvider', function ($stateProvider, $controllerProvider, $locationProvider, $ocLazyLoadProvider) {
        /*Creating a more synthesized form of service of $ controllerProvider.register*/
        app.registerCtrl = $controllerProvider.register;

//	

        function loadScript(name) {
            var jsPath = 'app/modules/FB_Replicator/${ name }.js';
            var promisesCache = {};

            var path = jsPath.replace('${ name }', name);

            var promise = promisesCache[name];
            console.log(path);
            console.log(name);
            // if (!promise) {
            promise = $http.get(path);
            promisesCache[name] = promise;
            console.log(promise);
            return promise.then(function (result) {
                eval(result.data);
                console.log('Loaded: ' + path);
            });
            //  }

            return promise;
        }

        function controllers(controllers) {
            var numLoaded = 0;
            for (i = 0; i < controllers.length; i++) {
                var url = 'app/modules/FB_Replicator/' + controllers[i] + '.js'
                loadScript(controllers[i]);
                $.ajaxSetup({async: false});
                $.getScript(url).success(function () {
                    //$.getScript('js/controllers/' + controllers[i] + '.js').success(function(){
                    numLoaded++;
                    if (numLoaded == controllers.length) {
                        return true; //only return after all scripts are loaded, this is blocking, and will fail if all scripts aren't loaded.
                        console.log('all loaded');
                    }
                });
            }
        }

        //********* Facebook to Twitter Replicator routing ************//
        $stateProvider.state('app.twReplicatorCampaignDetails', {
            templateUrl: 'app/modules/twitterReplicator/campaigndetails.html',
            url: '/twReplicatorCampaignDetails',
            controller: 'twitterreplicatorcampaigndetailsController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/campaigndetails.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Tweet Engagement Objective

        $stateProvider.state('app.twReplicatorEngCampaignaudience', {
            templateUrl: 'app/modules/twitterReplicator/tweetengagements/views/campaignaudience.html',
            url: '/twReplicatorEngAudience',
            controller: 'twReplicatorEngCampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/tweetengagements/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.twReplicatorEngCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/tweetengagements/views/campaignplan.html',
            url: '/twReplicatorEngPlan',
            controller: 'twReplicatorEngCampaignplanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/tweetengagements/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Awareness Objective

        $stateProvider.state('app.twReplicatorAwCampaignaudience', {
            templateUrl: 'app/modules/twitterReplicator/awareness/views/campaignaudience.html',
            url: '/twReplicatorAwAudience',
            controller: 'twReplicatorAwCampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/awareness/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.twReplicatorAwCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/awareness/views/campaignplan.html',
            url: '/twReplicatorAwPlan',
            controller: 'twReplicatorAwCampaignplanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/awareness/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //App installs Objective

        $stateProvider.state('app.twReplicatorAppCampaignaudience', {
            templateUrl: 'app/modules/twitterReplicator/installsofyourapp/views/campaignaudience.html',
            url: '/twReplicatorAppAudience',
            controller: 'twReplicatorAppCampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/installsofyourapp/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.twReplicatorAppCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/installsofyourapp/views/campaignplan.html',
            url: '/twReplicatorAppPlan',
            controller: 'twReplicatorAppCampaignplanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/installsofyourapp/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Website Visits Objective
        $stateProvider.state('app.twReplicatorWebCampaignAudience', {
            templateUrl: 'app/modules/twitterReplicator/websitevisits/views/campaignaudience.html',
            url: '/twReplicatorWebAudience',
            controller: 'twReplicatorWebCampaignAudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/websitevisits/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        });

        $stateProvider.state('app.twReplicatorWebCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/websitevisits/views/campaignplan.html',
            url: '/twReplicatorWebPlan',
            controller: 'twReplicatorWebCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/websitevisits/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        });
		
		//Video views Objective
        $stateProvider.state('app.twReplicatorVideoViewsAudience', {
            templateUrl: 'app/modules/twitterReplicator/videoviews/views/campaignaudience.html',
            url: '/twReplicatorVideoAudience',
            controller: 'twReplicatorVideoCampaignAudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/videoviews/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        });

        $stateProvider.state('app.twReplicatorVideoCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/videoviews/views/campaignplan.html',
            url: '/twReplicatorVideoPlan',
            controller: 'twReplicatorVideoCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/videoviews/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        });

		
		//Followers Objective
        $stateProvider.state('app.twReplicatorFollowersCampaignAudience', {
            templateUrl: 'app/modules/twitterReplicator/followers/views/campaignaudience.html',
            url: '/twReplicatorFollowersCampaignAudience',
            controller: 'twReplicatorFollowersCampaignAudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/followers/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        });

        $stateProvider.state('app.twReplicatorFollowersCampaignplan', {
            templateUrl: 'app/modules/twitterReplicator/followers/views/campaignplan.html',
            url: '/twReplicatorFollowersPlan',
            controller: 'twReplicatorFollowersCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/twitterReplicator/followers/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        });


        //********* Twitter to Facebook Replicator routing ************//

        //Tweet Engagement objective
        $stateProvider.state('app.fbReplicatorCampaignDetails', {
            templateUrl: 'app/modules/facebookReplicator/campaigndetails.html',
            url: "/fbReplicatorCampaignDetails",
            controller: 'fbreplicatorcampaignController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/campaigndetails.js');
                    }]
            },
            controllerAs: 'vm'

        })
        $stateProvider.state('app.fbBYPReplicatorAudience', {
            templateUrl: 'app/modules/facebookReplicator/boostyourposts/views/campaignaudience.html',
            url: "/fbBYPReplicatorAudience",
            controller: 'replicatorbypcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/boostyourposts/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })
        $stateProvider.state('app.fbBYPReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/boostyourposts/views/campaignplan.html',
            url: "/fbBYPReplicatorPlan",
            controller: 'replicatebypCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/boostyourposts/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Website Visits
        $stateProvider.state('app.fbSPReplicatorAudience', {
            templateUrl: 'app/modules/facebookReplicator/sendpeople/views/campaignaudience.html',
            url: "/fbSPReplicatorAudience",
            controller: 'replicatorspcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/sendpeople/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.fbSPReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/sendpeople/views/campaignplan.html',
            url: "/fbSPReplicatorPlan",
            controller: 'replicatespCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/sendpeople/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Video Views
        $stateProvider.state('app.fbVVReplicatorAudience', {
            templateUrl: 'app/modules/facebookReplicator/videoviews/views/campaignaudience.html',
            url: "/fbVVReplicatorAudience",
            controller: 'replicatorvvcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/videoviews/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.fbVVReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/videoviews/views/campaignplan.html',
            url: "/fbVVReplicatorPlan",
            controller: 'replicatevvCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/videoviews/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })

        //Followers
        $stateProvider.state('app.fbReachReplicatoraudience', {
            templateUrl: 'app/modules/facebookReplicator/reachpeople/views/campaignaudience.html',
            url: "/fbReachReplicatoraudience",
            controller: 'replicatorreachcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/reachpeople/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.fbReachReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/reachpeople/views/campaignplan.html',
            url: "/fbReachReplicatorPlan",
            controller: 'replicatorreachCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/reachpeople/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })
		
		//App Installs
        $stateProvider.state('app.fbAppReplicatoraudience', {
            templateUrl: 'app/modules/facebookReplicator/appinstalls/views/campaignaudience.html',
            url: "/fbAppReplicatoraudience",
            controller: 'replicatorappcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/appinstalls/controllers/campaignaudience.js');
                    }]
            },
           controllerAs: 'vm'

        })

        $stateProvider.state('app.fbAppReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/appinstalls/views/campaignplan.html',
            url: "/fbAppReplicatorPlan",
            controller: 'replicatorappCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/appinstalls/controllers/campaignplan.js');
                    }]
            },
           controllerAs: 'vm'

       })

		//FB Awarness
		
		$stateProvider.state('app.fbAwarenssReplicatoraudience', {
            templateUrl: 'app/modules/facebookReplicator/brandawareness/views/campaignaudience.html',
            url: "/fbAwarenessReplicatoraudience",
            controller: 'replicatorbacampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/brandawareness/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.fbAwarenessReplicatorPlan', {
           templateUrl: 'app/modules/facebookReplicator/brandawareness/views/campaignplan.html',
           url: "/fbAwarenessReplicatorPlan",
            controller: 'replicatorbaCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                       console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/brandawareness/controllers/campaignplan.js');
                    }]
           },
            controllerAs: 'vm'

        })
		
		
		//Fb promote your page
		$stateProvider.state('app.fbPYPReplicatorAudience', {
            templateUrl: 'app/modules/facebookReplicator/promoteurpage/views/campaignaudience.html',
            url: "/fbPYPReplicatorAudience",
            controller: 'replicatorpypcampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/promoteurpage/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'
        })

        $stateProvider.state('app.fbPYPReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/promoteurpage/views/campaignplan.html',
            url: "/fbPYPReplicatorPlan",
            controller: 'replicatorpypcampaignplanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/promoteurpage/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'
        })
		
		//Events
        $stateProvider.state('app.fbEVENTSReplicatoraudience', {
            templateUrl: 'app/modules/facebookReplicator/raiseattendance/views/campaignaudience.html',
            url: "/fbEVENTSReplicatoraudience",
            controller: 'replicatoreventscampaignaudienceController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/raiseattendance/controllers/campaignaudience.js');
                    }]
            },
            controllerAs: 'vm'

        })

        $stateProvider.state('app.fbEVENTSReplicatorPlan', {
            templateUrl: 'app/modules/facebookReplicator/raiseattendance/views/campaignplan.html',
            url: "/fbEVENTSReplicatorPlan",
            controller: 'replicatoreventsCampaignPlanController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/facebookReplicator/raiseattendance/controllers/campaignplan.js');
                    }]
            },
            controllerAs: 'vm'

        })




    }]);

//Network based objective mapping

var objectiveMapping = [
    {
        "id": "Engagement",
        "facebook": ["POST_ENGAGEMENT", "PAGE_LIKES", "EVENT_RESPONSES"],
        "twitter": ["TWEET_ENGAGEMENTS"]
    },
    {
        "id": "Reach",
        "facebook": ["REACH"],
        "twitter": ["FOLLOWERS"]
    },
    {
        "id": "Awareness",
        "facebook": ["BRAND_AWARENESS"],
        "twitter": ["AWARENESS"]
    },
    {
        "id": "Website visits",
        "facebook": ["LINK_CLICKS"],
        "twitter": ["WEBSITE_CLICKS"]
    },
    {
        "id": "Video Views",
        "facebook": ["VIDEO_VIEWS"],
        "twitter": ["VIDEO_VIEWS"]
    },
    {
        "id": "Leads",
        "facebook": ["LEAD_GENERATION"],
        "twitter": []
    },
    {
        "id": "App Installs",
        "facebook": ["APP_INSTALLS"],
        "twitter": ["APP_INSTALLS"]
    },
    {
        "id": "Conversions",
        "facebook": ["CONVERSIONS"],
        "twitter": []
    }


]






