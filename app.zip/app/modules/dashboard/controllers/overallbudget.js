dashboard.controller("overallbudget", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', '$sce', 'appSettings', '$timeout','$filter','apiService','performanceServices',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout, $filter, apiService,performanceServices) 
    {
        var errorboolean=true;
        $rootScope.progressLoader = "block";
        var apiBase = appSettings.apiBase;
        $scope.userRole;
        $scope.plotvaluesOnLoad;
        var apiTPBase = appSettings.apiTPBase;
        var doughnutChart;
        $scope.datedifference = 0;
        $scope.todayDate = new Date().toISOString().slice(0,10);
        $scope.campaignInsightsUnavailableCount = 0;
        $scope.totalBudget;
        $scope.selectedParentChildCampaign;
        $scope.onloadParentSelection = false;
        $scope.onloadChildSelection = false;
        $scope.firstImage = true;
        $scope.accountRole = true;
        $scope.wholeParentArrayOnLoad = [];
        $scope.wholeChildArrayOnLoad = [];
        $scope.percentageOfSpend;
        $scope.percentageOfBudget;
        $scope.totalSpend;
        $scope.totalSpendforAllNetwork = 0;
        $scope.currency;
        $scope.currencyList = {};
        $scope.currencyCode;
        $scope.graphPlotted = false;
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.campaignDropDown = [];
        $scope.toDate = localDateTimetoUTCDateTime(new Date());
        $scope.fromDate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
        $scope.dateArray = [];
        $scope.plotvalues = [];
        $scope.transpos = [];
        $scope.arrow_pos = [];
        $scope.dateDiff = 0;
        $scope.breakdown = "DAILY";
        $scope.monthDiff = 0;
        $scope.yearDiff = 0;
        $scope.countNetMapId = 0;
        $scope.countAdaccountId = 0;
        $scope.chartData = [
                {"Budget": "45%", "contribution": 45}, 
                {"Spend": "55%", "contribution": 55} 
            ];
        $scope.networksforaccount = [];
        $scope.dates = [];
        $scope.advertiserdetails = {};
        $scope.bool = [];
        $scope.networksarrayforacc = [];
        $scope.wholeParentArray = [];
        $scope.wholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkmaparray = [];
        $scope.networkmaparrayonload = [];
        $scope.spendComparison = [];
        $scope.spendComparisonOnLoad = [];
        $scope.networkforadv = false;
        $scope.parenttoggle = false;
        $scope.fromDateChange = false;
        $scope.toDateChange = false;
        $scope.error=[];
         $scope.advertisername=[];
        var errorHeader = [];
        var errorString = [];
        var errornetwork=[];    
        $scope.errorpopup2Heading="We're sorry something went wrong!";
        var completionstatus=false;
        angular.element($window).bind('resize', function(){

//        console.log("window completionstatus got resized");
//        $timeout(function () {
//            
//        }, 0);
        

         // manuall $digest required as resize event
         // is outside of angular
         
        });

        
        $scope.nocampaignselection = function()
        {
            $scope.selectedvalue = "";
            $scope.selectedParentChildCampaign = "";
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
                    $scope.selectnetwork();
                }
                else
                {
                    $scope.selectadvertiser();
                }
            }
            else
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
                    $scope.selectnetwork();
                }
                else
                {
                    $scope.checkInsightsAvailability();
                }
            }
        };
        $scope.networkClick = function(network)
        {
//            networkWiseSpendPercentage
//            console.log(network);
            var id;
            if(network == "Facebook")
            {
                id = 0;
                $scope.totalBudgetforAllNetwork = $scope.totalfbbudget + $scope.totaltwbudget;
                        
//                        console.log($scope.totalfbbudget);
//                        console.log($scope.totalfbspend);
                var per;
                if($scope.totalBudgetforAllNetwork != 0)
                {
                    per = Math.round(($scope.totalfbbudget/$scope.totalBudgetforAllNetwork)*100);
                }
                else 
                {
                    per = 0;    
                }
                $scope.networkWiseSpendPercentage = per;
            }
            else if(network == "Twitter")
            {
                id = 1;
                var per;
                if($scope.totalBudgetforAllNetwork != 0)
                {
                    per = Math.round(($scope.totaltwbudget/$scope.totalBudgetforAllNetwork)*100);
                }
                else 
                {
                    per = 0;    
                }
                $scope.networkWiseSpendPercentage = per;
            }
            for(i=0;i<$scope.rowCollapse.length;i++)
            {
                if(i==id)
                {
                    $scope.rowCollapse[i] = true;   
                }
                else
                {
                    $scope.rowCollapse[i] = false;
                }
            }
//            console.log($scope.rowCollapse);
//            console.log($scope.networkWiseSpendPercentage);
//            var div = angular.element("#scrollTable");
//            console.log(div);
//            console.log(div[0].scrollHeight);
//            console.log(div[0].clientHeight);
//            var hasVerticalScrollbar = div[0].scrollHeight > div[0].clientHeight;
//            console.log(hasVerticalScrollbar);
//            if(!hasVerticalScrollbar)
//            {
//                if(network=="Facebook")
//                {
//                    angular.element("#FacebookSelect").css("left","98%");
//                }
//                else if(network == "Twitter")
//                {
//                    angular.element("#TwitterSelect").css("left","98%");
//                }
//            }
//            else
//            {
//                if(network=="Facebook")
//                {
//                    angular.element("#FacebookSelect").css("left","99%");
//                }
//                else if(network == "Twitter")
//                {
//                    angular.element("#TwitterSelect").css("left","99%");
//                }
//            }
        };
        
        $scope.arrowDirectionChange = function (parentobj, _index) 
        {

            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                {
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        };
        
        function localDateTimetoUTCDateTime(date)
        {
            var d = new Date(date);
            var utcDate = d.toUTCString();
            return new Date(utcDate).toISOString().slice(0,10);
        }
        
        $scope.fromAndToChanged = function()
        {
//            console.log("something");
//            console.log("from " + $scope.from1);
//            console.log("to "+ $scope.to1);
            $scope.mindate = $filter('date')($scope.from1,'yyyy-MM-dd');
            $scope.from = $filter('date')($scope.from1,'yyyy-MM-dd');
            $scope.to = $filter('date')($scope.to1,'yyyy-MM-dd');
            if($scope.from != undefined && $scope.to != undefined && $scope.from != "" && $scope.to != "")
            {
                if(new Date($scope.from) <= new Date($scope.to))
                {
                    $rootScope.progressLoader = "block";
//                    console.log("from and to changed");
                    var date = new Date();
                    var hour = date.getHours(); var hour1 = hour > 10 ? '0'+hour : hour;
                    var min = date.getMinutes(); var min1 = min > 10 ? '0'+min : min;
                    var sec = date.getSeconds();  var sec1 = sec > 10 ? '0'+sec : sec;
                    var fromDateTime = $scope.from +" "+hour1 +":"+min1+":"+sec1;
                    var toDateTime = $scope.to +" "+hour1 +":"+min1+":"+sec1; 
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.calculateDateDiffAndBreakDown($scope.UTCFromDate,$scope.UTCToDate);
                }
                else
                {
                    $scope.from = "";
                    $scope.to = "";
                    $scope.from1 = "";
                    $scope.to1 = "";
                }
            }
        };
        
        $scope.updateNetworkDropDown = function()
        {
//            console.log("netowrk drop down");
//            console.log($scope.advertiserId);
            var networkArray = [];
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
//                console.log("netowrk drop down - advertiser selected");
                for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                    {
                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    var obj = {
                                        "networkId":$scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                        "networkName":$scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                        "networkURL":$scope.networkmaparrayonload[i].networkDetails[j].networkURL  
                                    };
                                    networkArray.push(obj);
                                }
                            }
                        }
                    }
                }
//                console.log(networkArray);
                $scope.networkDropDown = angular.copy(networkArray);
            }
            else
            {
                $scope.networkDropDown = angular.copy($scope.networkDropDownOnLoad);
            }
        };
        
        $scope.updateCampaignDropDown = function()
        {
            $scope.wholeParentArray = [];
            $scope.wholechildArray = [];
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
                    
//                    console.log("both advertiser and network selected");
//                    console.log($scope.advertiserId);
//                    console.log($scope.networkId);
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                    
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparrayonload[i].networkDetails[j].networkId == $scope.networkId)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent",
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                }
                                            }
                                        }
                                        
                                }
                            }
                        }
                    }

                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
            //                                                        if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
            //                                                        {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                            "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                            "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                            "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                            };
                                                        $scope.wholechildArray.push(obj);
                                                    }
            //                                                        }

                                                }
                                            }
                                        }
                                }
                            }
                        }
                    }
                }
                else
                {
//                    console.log("advertiser selected but no network");
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                    
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent"
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                }
                                            
                                        }
                                        
                                }
                            }
                        }
                    }

                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
            //                                                        if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
            //                                                        {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id
                                                            };
                                                        $scope.wholechildArray.push(obj);
                                                    }
            //                                                        }

                                                }
                                            
                                        }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
//                    console.log("network selected but no advertiser");
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                    
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkId == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent"
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                }
                                            }
                                        }
                                        
                                }
                            }
                        
                    }

                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkId == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
            //                                                        if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
            //                                                        {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id
                                                            };
                                                        $scope.wholechildArray.push(obj);
                                                    }
            //                                                        }

                                                }
                                            }
                                        }
                                }
                            }
                        
                    }
                }
                else
                {
//                    console.log("no advertiser and no network selected");
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
                    $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
                }
            }
        };
        
        $scope.selectadvertiser = function ()
        {
            console.log(JSON.stringify($scope.networkmaparray,null,2));
            $scope.status = "";
            $scope.selectedParentChildCampaign = "";
            $scope.selectedvalue = "";
            $scope.networkId = "";
            $scope.updateNetworkDropDown();
            $scope.updateCampaignDropDown();
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
//                console.log("check advertiser insights availability");
//                console.log($scope.advertiserId);
//                console.log(JSON.stringify($scope.networkmaparray, null, 2));
                var noInsights = true;
                for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                    {
                        noInsights = true;
                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount != 0)
                                            {
                                                noInsights = false;
                                            }
                                        }
                                        if(noInsights == false)
                                        {
                                            break;
                                        }
                                    }
                                }
                                if(noInsights == false)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                if(noInsights)
                {
//                    console.log("no table");
                    $scope.noTable = true;
                    $rootScope.progressLoader = "none";
                    $scope.graphPlotted = false;
                    $scope.spendComparison = [];
                }
                else
                {
    //                $rootScope.progressLoader = "none";
//                    console.log("table");
                    $scope.noTable = false;
                    $scope.graphPlotted = true;
                    $scope.prepareForPlottingForAdvertiser();
                }
            }
            else
            {
                $scope.checkInsightsAvailability();
            }
        };
        $scope.prepareForPlottingForAdvertiserNetwork = function()
        {
//            console.log("advertiser preparation");
            var obj = [];
            var zero_count = 0;
            var spendcount = 0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                            {    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                        {
                                            for(l=0;l<obj.length;l++)
                                            {
                                                if(obj[l].region == "Spend")
                                                {
                                                    if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                    {
                                                        obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                    }
                                                }
                                            }
                                        }
                                        else if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Budget")
                                        {
                                            for(l=0;l<obj.length;l++)
                                            {
                                                if(obj[l].region == "Budget")
                                                {
                                                    if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                    {
                                                        obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendcount++;
                    spendTemp.push(obj[i]);
                    if(obj[i].amount == 0)
                    {
                        zero_count++;
                    }
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(spendcount == zero_count)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj);
            }
            
            
        };
        
        $scope.prepareForPlottingForAdvertiser = function()
        {
//            console.log("advertiser preparation");
            var obj = [];
            var zero_count = 0;
            var spendcount =0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                    {
                                        for(l=0;l<obj.length;l++)
                                        {
                                            if(obj[l].region == "Spend")
                                            {
                                                if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                {
                                                    obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                }
                                            }
                                        }
                                    }
                                    else if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Budget")
                                    {
                                        for(l=0;l<obj.length;l++)
                                        {
                                            if(obj[l].region == "Budget")
                                            {
                                                if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                {
                                                    obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendTemp.push(obj[i]);
                    spendcount++;
                    if(obj[i].amount == 0)
                    {
                        zero_count++;
                    }

                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(spendcount == zero_count)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj);
            }
        };
        
        $scope.selectnetwork = function()
        {
            $scope.status = "";
            $scope.selectedParentChildCampaign = "";
            $scope.selectedvalue = "";
            $scope.updateCampaignDropDown();
            if($scope.networkId != "" && $scope.networkId != undefined)
            {
                if($scope.advertiserId != "" && $scope.advertiserId != undefined)
                {
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                                    {
                                        var noInsights = true;
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount != 0)
                                                    {
                                                        noInsights = false;
                                                    }
                                                }
                                                if(noInsights == false)
                                                {
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    if(noInsights == false)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        if(noInsights == false)
                        {
                            break;
                        }
                    }
                    if(noInsights == true)
                    {
//                        console.log("no table");
                        $scope.noTable = true;
                        $scope.graphPlotted = false;
//                        console.log("no details for this network");
                        $scope.spendComparison = [];
                    }
                    else
                    {
                        $scope.noTable = false;
//                        console.log("convertForAdvertiserNetwork");
                        $scope.graphPlotted = true;
                        $scope.prepareForPlottingForAdvertiserNetwork();
//                        console.log("table");
                    }
                }
                else if($scope.advertiserId == "" || $scope.advertiserId == undefined)
                {
                    var noInsights = true;
                    var noInsightsForAdvertiser = 0;
                    var noOfAdvertiserWithSelectedNetworkLinked = 0;
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                                {
                                    noOfAdvertiserWithSelectedNetworkLinked++;
                                }
                            }
                        }
                    }
//                    console.log("noOfAdvertiserWithSelectedNetworkLinked " + noOfAdvertiserWithSelectedNetworkLinked);
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        noInsights = true;
                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                                {
                                    noInsights = true;
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                            {
//                                                console.log($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount);
                                                if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount != 0)
                                                {
//                                                    console.log("1");
                                                    noInsights = false;
                                                }
                                            }
                                            if(noInsights == false)
                                            {
//                                                console.log("2");
                                                break;
                                            }
                                        }
                                    }
                                }
                                if(noInsights == false)
                                {
//                                    console.log("3");
                                    break;
                                }
                            }
                        }
                        if(noInsights)
                        {
//                            console.log("4");
                            noInsightsForAdvertiser++;
                        }
                    }
//                    console.log(noInsightsForAdvertiser);
//                    console.log(JSON.stringify($scope.networkmaparray , null ,2));
                    if(noInsightsForAdvertiser == $scope.networkmaparray.length)
                    {
//                        console.log("no table");
                        $scope.noTable = true;
                        $rootScope.progressLoader = "none";
                        $scope.graphPlotted = false;
                        $scope.spendComparison = [];
                    }
                    else
                    {
//                        console.log("table");
                        $scope.noTable = false;
//                        console.log("convertForNetwork");
                        $scope.prepareForPlottingForNetwork();
                    }
                }
            }
            else if($scope.networkId == "" || $scope.networkId == undefined)
            {
                if($scope.advertiserId != "" && $scope.advertiserId != undefined)
                {
                    $scope.selectadvertiser();
                }
                else if($scope.advertiserId == "" || $scope.advertiserId == undefined)
                {
                    $scope.checkInsightsAvailability();
                }
            }
        };
        
        $scope.prepareForPlottingForNetwork = function()
        {
//            console.log("network preparation");
            var obj = [];
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
//                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
//                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                            {    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                        {
                                            for(l=0;l<obj.length;l++)
                                            {
                                                if(obj[l].region == "Spend")
                                                {
                                                    if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                    {
                                                        obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                    }
                                                }
                                            }
                                        }
                                        else if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Budget")
                                        {
                                            for(l=0;l<obj.length;l++)
                                            {
                                                if(obj[l].region == "Budget")
                                                {
                                                    if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                                    {
                                                        obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
//                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendTemp.push(obj[i]);
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.plotlinechart(obj);
            $scope.spendComparison = angular.copy(spendTemp);
                           

        };
        
        $scope.parentselection = function (_obj)
        {
            //console.log($scope.networkmaparray);
//            console.log(_obj);
            $scope.status = "";
            $scope.parentChildShow = !$scope.parentChildShow;
//            console.log("parent selection", _obj);
            $scope.selectedParentChildCampaign = _obj;
            $scope.selectedvalue = _obj.name;
//            console.log(JSON.stringify($scope.networkmaparray, null, 2));
            var noInsights = true;
            if($scope.networkId != "" && $scope.networkId != undefined)
            {
//                console.log("parent selection - network selected");
                 for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == _obj.id)
                                        {
                                            noInsights = true;
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                    {
        //                                                console.log($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount);
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount != 0)
                                                        {
        //                                                    console.log("1");
                                                            noInsights = false;
                                                        }
                                                    }
                                                    if(noInsights == false)
                                                    {
        //                                                console.log("2");
                                                        break;
                                                    }

                                                }
                                                
                                            }
                                        }
                                        if(noInsights == false)
                                        {
        //                                    console.log("3");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if(noInsights == true)
                {
//                    console.log("network selected - no insights for parent in this network");
//                    console.log("no table");
                    $scope.noTable = true;
                    $rootScope.progressLoader = "none";
                    $scope.graphPlotted = false;
                    $scope.spendComparison = [];
                }
                else
                {
//                    console.log("network selected - insights available for parent in this network");
//                    console.log("table");
                    $scope.noTable = false;
                    $scope.graphPlotted = true;
                    $scope.prepareForPlottingForNetworkParent(_obj);
                }
            }
            else
            {
//                console.log("parent selection - no network selected");
                for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].id == _obj.id)
                                    {
                                        noInsights = true;
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                {
    //                                                console.log($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount);
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount != 0)
                                                    {
    //                                                    console.log("1");
                                                        noInsights = false;
                                                    }
                                                }
                                                if(noInsights == false)
                                                {
    //                                                console.log("2");
                                                    break;
                                                }

                                            }
                                            
                                        }
                                    }
                                    if(noInsights == false)
                                    {
    //                                    console.log("3");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                if(noInsights == true)
                {
//                    console.log("no insights for parent in any network");
//                    console.log("no table");
                    $scope.noTable = true;
                    $rootScope.progressLoader = "none";
                    $scope.graphPlotted = false;
                    $scope.spendComparison = [];
                }
                else
                {
//                    console.log("insights available for parent");
//                    console.log("table");
                    $scope.noTable = false;
                    $scope.graphPlotted = true;
                    $scope.prepareForPlottingForParent(_obj);
                }
            }
        };
        $scope.prepareForPlottingForNetworkParent = function(parentobj)
        {
//            console.log("network preparation");
//            console.log(parentobj);
            var obj = [];
            var zero_count =0;
            var spendcount = 0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
//                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
//                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                            {    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == parentobj.id)
                                        {
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                    {
                                                        for(n=0;n<obj.length;n++)
                                                        {
                                                            if(obj[n].region == "Spend")
                                                            {
                                                                if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                {
                                                                    obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Budget")
                                                    {
                                                        for(n=0;n<obj.length;n++)
                                                        {
                                                            if(obj[n].region == "Budget")
                                                            {
                                                                if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                {
                                                                    obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
//                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendcount++;
                    spendTemp.push(obj[i]);
                    if(obj[i].amount == 0)
                    {
                       zero_count++; 
                    }
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(spendcount == zero_count)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj);
            }
        };
        
        $scope.prepareForPlottingForParent = function(parentobj)
        {
//            console.log("network preparation");
//            console.log(parentobj)
            var obj = [];
            var zero_count = 0;
            var spendcount = 0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
//                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
//                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
//                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
//                            {    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == parentobj.id)
                                        {
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                    {
                                                        for(n=0;n<obj.length;n++)
                                                        {
                                                            if(obj[n].region == "Spend")
                                                            {
                                                                if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                {
                                                                    obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Budget")
                                                    {
                                                        for(n=0;n<obj.length;n++)
                                                        {
                                                            if(obj[n].region == "Budget")
                                                            {
                                                                if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                {
                                                                    obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
//                                }
                            }
                        }
                    }
//                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendcount++;
                    spendTemp.push(obj[i]);
                    if(obj[i].amount ==0)
                    {
                        zero_count++;
                    }
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(spendcount == zero_count)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj);
            }
        };
        
        
        $scope.childselection = function (_obj)
        {
            $scope.status = "";
            $scope.parentChildShow = !$scope.parentChildShow;
//            console.log("child selection", _obj);
            $scope.selectedParentChildCampaign = _obj;
            $scope.selectedvalue = _obj.name;
            var noInsights = true;
           // console.log(JSON.stringify($scope.networkmaparray , null ,2));
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                            {
                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                {
//                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
//                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == _obj.id)
                                        {
                                           // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l])
                                           // noInsights = true;
                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                            {
                                              //  console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails);
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                    {
        //                                                console.log($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount);
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount != 0)
                                                        {
                                                          //  console.log("1");
                                                            noInsights = false;
                                                        }
                                                    }
                                                    if(noInsights == false)
                                                    {
                                                       // console.log("2");
                                                        break;
                                                    }
                                            } 
                                        }
//                                        if(noInsights == false)
//                                        {
//        //                                    console.log("3");
//                                            break;
//                                        }
//                                    }
                                }
                            }
                        }
                    }
                }
            }
            noInsights = false;
            if(noInsights == true)
            {
//                console.log("no insights for child");
//                console.log("no table");
                $scope.noTable = true;
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
//                console.log("insights available for child");
//                console.log("table");
                $scope.noTable = false;
                $scope.graphPlotted = true;
                $scope.prepareForPlottingForChild(_obj);
            }
        };
        
        $scope.prepareForPlottingForChild = function(childobj)
        {
//            console.log("network preparation");
//            console.log(childobj);
            var obj = [];
            var zero_count = 0;
            var spendcount = 0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
//                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
//                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
//                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
//                            {    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
//                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == childobj.id)
//                                        {
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == childobj.id)
                                                {
                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.length;m++)
                                                    {
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Spend")
                                                        {
                                                            //console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails);
                                                            for(n=0;n<obj.length;n++)
                                                            {
                                                                if(obj[n].region == "Spend")
                                                                {
                                                                    if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                    {
                                                                        obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].region == "Budget")
                                                        {
                                                            for(n=0;n<obj.length;n++)
                                                            {
                                                                if(obj[n].region == "Budget")
                                                                {
                                                                    if(obj[n].date == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].date)
                                                                    {
                                                                        obj[n].amount = obj[n].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails[m].amount));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
//                                        }
                                    }
//                                }
                            }
                        }
                    }
//                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spendcount++;
                    spendTemp.push(obj[i]);
                    if(obj[i].amount == 0)
                    {
                        zero_count++;
                    }
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(spendcount == zero_count)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj);
            }
        };
        
        $scope.getaccountdetails = function ()
        {
            $scope.userRole = $window.localStorage.getItem("role");
            if($scope.userRole != "Account")
            {
                $scope.accountRole = false;
            }
            var promises = [];
            var getAccountDetailsSuccess = false;
            $scope.accountId = $window.localStorage.getItem("accountId");
            $scope.advertiserDetails = {};
            $scope.adverDetails = [];
            $rootScope.progressLoader = "block";
            promises.push(performanceServices.getaccountdetails($scope.accountId).then(function (response) {
                if (response.appStatus == '0') {// success
                    $scope.accountName = response.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.accountFetchResponse.logoUrl;
                    getAccountDetailsSuccess = true;
                } else {
                    $rootScope.progressLoader = "none";// failed
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(getAccountDetailsSuccess)
                        {
                            $scope.downloadAccountLogo($scope.accountLogoUrl);
                        }
                    });
        };

        $scope.downloadAccountLogo = function (accountLogoUrl)
        {
            var promises = [];
            promises.push(performanceServices.downloadimages(accountLogoUrl).then(function(response){
                if (response.appStatus == '0'){
                    $scope.accountLogo = response.imageContent[$scope.accountLogoUrl];
                }
                else{ 
                  //   $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                     
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.imageContent[$scope.accountLogoUrl].errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
//                        if(downloadImageSuccess)
//                        {
                            $scope.getAdvertiserDetails();
//                        }
                    });
        };
        
        $scope.getAdvertiserDetails = function ()
        {
            var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                } 
                else{
                     $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(getAdvertiserDetails)
                        {
                            $scope.allnetworks();
//                            $scope.networksforacc();
                        }
                    });
        };
        
        $scope.allnetworks = function ()
        {
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response){
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                }
                else{
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(allnetworks)
                        {
//                            $scope.allnetworks();
                            $scope.networksforacc();
                        }
                    });
        };
        
        $scope.networksforacc = function ()
        {
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                    for (i = 0; i < $scope.networksarrayforacc.length; i++){
                        angular.forEach($scope.allnetworksarray, function (val, key){
                            if ($scope.networksarrayforacc[i].networkId == val.networkId){
                                if(!$scope.networksforaccount.includes(val.networkName)){
                                    var obj = {
                                        "networkName":val.networkName,
                                        "networkId":val.networkId
                                    };
                                    $scope.networksforaccount.push(obj);
                                }
                            }
                        });
                    }
                   
                }
                else{
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(networksforaccount)
                        {
//                            $scope.allnetworks();
                             $scope.getusernetworkmapids();
                        }
                    });
        };
        
        $scope.getusernetworkmapids = function ()
        {
            var promises = [];
//            console.log($scope.allnetworksarray);
            angular.forEach($scope.advertiserdetails, function (val, key){
                var networkdetailobj=[];
                
                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){   
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){   
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl
                                };
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.networkmaparrayonload.push(obj);
            });
            for (i = 0; i < $scope.networkmaparrayonload.length; i++)
            {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.networkmaparrayonload[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                        if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function(response)
                            {    
                                if(response.appStatus == 0)
                                {
                                    angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
                                    {
                                        var parent = [];
                                        var plotDetails = [];
                                        $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                        $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                        $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                        $scope.networkmaparrayonload[i].networkDetails[j]["plotDetails"] = plotDetails;
                                        $scope.currency = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                    });
                                }
                                else{
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                           
                                //    $rootScope.progressLoader = "none";
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                        } else {
                                                  
                                            //    $rootScope.progressLoader = "none";
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                        errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                        }
                                }}
                            }));
                        }
                        else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
                            promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function(response)
                            {
                                if(response.appStatus == 0)
                                {
                                    angular.forEach(response.adAccounts,function(value,key)
                                    {
                                        angular.forEach(value,function(value2,key2)
                                        {
//                                                console.log(value2,key2);
                                            var parent = [];
                                            var plotDetails = [];
                                            $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=value2.twAdAccountId;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = "";
                                            $scope.networkmaparrayonload[i].networkDetails[j]["plotDetails"] = plotDetails;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                        });
                                    });
                                }
                                else
                                {
                                //    $rootScope.progressLoader = "none";
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                    {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } 
                                    else 
                                    {
                                      //     $rootScope.progressLoader = "none";
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                        errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                    }
                                }
                            }));
                        }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
//                        console.log("first");
//                        console.log($scope.networkmaparrayonload);
                        //$scope.readaccountinsights();
                        $scope.checkCurrencyCode($scope.currency);
                        $scope.fillDropDowns();
                    });
        };
        
        $scope.fillDropDowns = function()
        {
            var promises = [];
//            console.log(JSON.stringify($scope.networkmaparrayonload, null, 2));
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                var obj = {
                    "advertiserName":$scope.networkmaparrayonload[i].advertiserName,
                    "advertiserId":$scope.networkmaparrayonload[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
            }
//            console.log($scope.allnetworksarray);
//===========================================================Network Drop Down==================================================================
            var allnetworkswithduplicate = [];
            var allnetworkswithoutduplicate = [];
            var allnetworkswithduplicateobjects = [];
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            var obj = {
                                "networkId":$scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                "networkName":$scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                "networkURL":$scope.networkmaparrayonload[i].networkDetails[j].networkURL
                            };
                            allnetworkswithduplicate.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                            allnetworkswithduplicateobjects.push(obj);
                        }
                    }
                }
            }
            allnetworkswithoutduplicate = allnetworkswithduplicate.filter(function(elem, index, self) {
                return index == self.indexOf(elem);
            });
//            console.log(allnetworkswithduplicate);
//            console.log(allnetworkswithoutduplicate);
//            console.log(allnetworkswithduplicateobjects);
            for(i=0;i<allnetworkswithoutduplicate.length;i++)
            {
                var obj = {
                    "networkId":"",
                    "networkName":allnetworkswithoutduplicate[i],
                    "networkURL":""
                };
                $scope.networkDropDown.push(obj);
            }
            for(i=0;i<$scope.networkDropDown.length;i++)
            {
                for(j=0;j<allnetworkswithduplicateobjects.length;j++)
                {
                    if($scope.networkDropDown[i].networkName == allnetworkswithduplicateobjects[j].networkName)
                    {
                        $scope.networkDropDown[i].networkId = allnetworkswithduplicateobjects[j].networkId;
                        $scope.networkDropDown[i].networkURL = allnetworkswithduplicateobjects[j].networkURL;
                    }
                }
            }
            $scope.networkDropDownOnLoad = angular.copy($scope.networkDropDown);
//==============================================================================================================================================           
             



                for(i=0;i<$scope.networkmaparrayonload.length;i++)
                {
        //                console.log("1");
                    if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                    {
        //                    console.log("2");
                        (function(i)
                        {
                            promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.networkmaparrayonload[i].advertiserId).then(function(response)
                            {
                                if (response.appStatus == '0') 
                                {// success
                                    $scope.campaigndetails = response.parentCampaigns;
                                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for (var k = 0; k < $scope.campaigndetails.length; k++)
                                            {
                                                var _obj = {
                                                    "id": $scope.campaigndetails[k].parentCampaignId,
                                                    "name": $scope.campaigndetails[k].parentCampaignName,
                                                    "type": "parent",
                                                    "userNetworkMapId": $scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,
                                                    "networkUrl":$scope.networkmaparrayonload[i].networkDetails[j].networkURL
                                                };
                                                $scope.wholeParentArray.push(_obj);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                             //       $rootScope.progressLoader = "none";
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                             //                 $rootScope.progressLoader = "none";
                           //                 $scope.editAdsetErrorMsg = 'block';
                                        if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {

                                                     errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                     errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                            } else {

                                                    errorHeader.push(response.networkError.error_user_title);
                                                    errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);

                                            }
                                        } else {

                                                errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);

                                        }
                                    }
                                }
                            }));
                        })(i);
                    }
                };

            $q.all(promises).finally(
                function()
                {
    //                        console.log("before fetch child and push");
//    console.log(JSON.stringify($scope.wholeParentArray, null, 2));
                     for(a=0;a<$scope.wholeParentArray.length;a++)
                    {
                        for(i=0;i<$scope.networkmaparrayonload.length;i++)
                        {
    //                               console.log("3");
                            if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                            {
    //                                    console.log("4");
                                for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                {
    //                                        console.log("5");
                                    if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
    //                                            console.log("6");
                                        if($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholeParentArray[a].userNetworkMapId)
                                        {
    //                                                    console.log("7");
//                                            if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("parent"))
//                                            {
                                                var campaigns = [];
                                                var obj = {
                                                    "id":$scope.wholeParentArray[a].id,
                                                    "name":$scope.wholeParentArray[a].name,
                                                    "type":"Parent",
                                                    "campaigns":campaigns
                                                };
//                                                            console.log($scope.networkmaparray[i].networkDetails[j]);
//                                                            console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                                                $scope.networkmaparrayonload[i].networkDetails[j].parent.push(obj);
//                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
//                     console.log(JSON.stringify($scope.networkmaparrayonload, null, 2));
                    $scope.fetchallchildandpush();
                });
        };
      
        $scope.fetchallchildandpush = function()
        {
        //    console.log(JSON.stringify($scope.networkmaparrayonload, null, 2));
//            console.log("fetch all child and push");
            var promises = [];
            
             
            
            for(i=0;i<$scope.wholeParentArray.length;i++)
            {
                
                (function(i)
                {
                   
               var k=0;
                   for(k;k<$scope.networkmaparrayonload.length;k++)
                        {
                              
                              if($scope.networkmaparrayonload[k].hasOwnProperty("networkDetails"))
                                
                                    {
                                          
                                        for(j=0;j<$scope.networkmaparrayonload[k].networkDetails.length;j++)
                                    {
                                         
                                   for(l=0;l<$scope.networkmaparrayonload[k].networkDetails[j].parent.length;l++)
                                    {
                                        
                                    
                                    if($scope.networkmaparrayonload[k].networkDetails[j].parent[l].id==$scope.wholeParentArray[i].id)
                                        {
                                            
                                           $scope.advertisername[i]= $scope.networkmaparrayonload[k].advertiserName;
                                            
                                        }
                                    
                                    }}
                            }
                        }
                            
                            
                            
                         
                
                
                
                
                    //checking whether the parent network is Fb or twitter
                    if($scope.wholeParentArray[i].networkUrl == appSettings.fbNetwork)
                    {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) {
                            if (response.appStatus == '0') {
                                $scope.childCampaigns = response.adcampaigns;
                                var count = 0;
                                angular.forEach($scope.childCampaigns, function (value, key) {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) {
                                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].campaignId,
                                                "name": array[+j].campaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": array[+j].campaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                        }
                                    }
                                });
                            } else {
                              //   $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                            //           $rootScope.progressLoader = "none";
                                           //     $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                             errornetwork.push("Facebook");
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.wholeParentArray[i].name );
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                              errornetwork.push("Facebook");
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        errornetwork.push("Facebook");
                                                        errorHeader.push(" Advertiser:<b>"+ $scope.advertisername[i]+ "</b><br> Parent Campaign: <b>"+$scope.wholeParentArray[i].name+"</b>" );
                                                        errorString.push(response.errorMessage);
                                                }
                                    }
                            }
                        }));
                        
                    }    
                    else if($scope.wholeParentArray[i].networkUrl == appSettings.twNetwork)
                    {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork,undefined).then(function (response) 
                        {
                            if (response.appStatus == '0') 
                            {
                                angular.forEach(response.campaign,function(value,key)
                                {
                                    angular.forEach(value,function(value2,key2)
                                    {
                                        var _obj = {
                                                "id": value2.twCampaignDetails.id,
                                                "name": value2.twCampaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": value2.twCampaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            $scope.wholechildArray.push(_obj);
                                    });
                                });
//                              console.log(JSON.stringify($scope.wholechildArray, null , 2));
                            }
                            else 
                            {
                             //    $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                }
                                else 
                                {   //           $rootScope.progressLoader = "none";
                                           //     $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                             errornetwork.push("Twitter");
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.wholeParentArray[i].name );
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                              errornetwork.push("Twitter");
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        errornetwork.push("Twitter");
                                                        errorHeader.push(" Advertiser:<b>"+$scope.advertisername[i]+ "</b><br> Parent Campaign: <b>"+$scope.wholeParentArray[i].name+"</b>" );
                                                        errorString.push(response.errorMessage);
                                                }
                                }
                            }
                        }));
                    }
                })(i);
            }
            $q.all(promises).finally(
                    function(){
//                        console.log(JSON.stringify($scope.networkmaparray, null, 2));
//                        $scope.wholeParentArrayOnLoad = $scope.wholeParentArray;
//                        $scope.wholeChildArrayOnLoad = $scope.wholechildArray;
                        //console.log(JSON.stringify($scope.wholechildArray,null , 2));
                        for(a=0;a<$scope.wholechildArray.length;a++)
                        {
                            for(i=0;i<$scope.networkmaparrayonload.length;i++)
                            {
                                
                                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                                {
                                    
                                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                    {
                                        
//                                        (function(i,j,a)
//                                        {
                                          
                                            if($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholechildArray[a].userNetworkMapId)
                                            {
//                                                if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == $scope.wholeParentArray[i].networkUrl)
//                                                {
                                                    //pushing FB campaigns into struct array
                                                    if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        for(k=0;k<$scope.networkmaparrayonload[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid)
                                                            {
                                                                var plotDetails = [];
                                                                var obj = {
                                                                    "id":$scope.wholechildArray[a].id,
                                                                    "name":$scope.wholechildArray[a].name,
                                                                    "parentId":$scope.wholechildArray[a].parentid,
                                                                    "type":"child",
                                                                    "status":$scope.wholechildArray[a].status,
                                                                    "plotDetails":plotDetails
                                                                };
                                                                $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns.push(obj);
                                                           }
                                                        }
                                                    }
//                                                }
                                            }
//                                        })(i,j,a);
                                    }
                                }
                            }
                        }
                        var nonUniqueParentArray = [];
                        var uniqueParentArray = [];
                        var uniqueParentObjects = [];
                        for(i=0;i<$scope.wholeParentArray.length;i++)
                        {
                            nonUniqueParentArray.push($scope.wholeParentArray[i].id);
                        }
                        uniqueParentArray = nonUniqueParentArray.filter(function(elem, index, self) {
                            return index == self.indexOf(elem);
                        });
                        for(i=0;i<uniqueParentArray.length;i++)
                        {
                            var obj = {
                                "id":uniqueParentArray[i],
                                "name":"",
                                "type":"parent"
                            };
                            uniqueParentObjects.push(obj);
                        }
//                        console.log(uniqueParentObjects);
                        for(i=0;i<uniqueParentObjects.length;i++)
                        {
                            for(j=0;j<$scope.wholeParentArray.length;j++)
                            {
                                if($scope.wholeParentArray[j].id == uniqueParentObjects[i].id)
                                {
                                    uniqueParentObjects[i].name = $scope.wholeParentArray[j].name;
                                }
                            }
                        }
//                        console.log(uniqueParentArray);
//                        console.log(uniqueParentObjects);
                        $scope.wholeParentArray = angular.copy(uniqueParentObjects);
                        $scope.wholeParentArrayOnLoad = angular.copy($scope.wholeParentArray);
                        $scope.wholeChildArrayOnLoad = angular.copy($scope.wholechildArray);
//                        $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
                        $scope.getOverallSpend();
                    });
        };

        $scope.getOverallSpend = function()
        {
            var promises = [];
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                    {
//                        console.log('here');
                        if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
//                            console.log('here2');
                            if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                (function(i,j)
                                {
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId,undefined,undefined,undefined,appSettings.fbNetwork,true).then(function(response){
                                        if(response.appStatus == 0)
                                        {
                                            var resp = response.adAccountInsights;
//                                            console.log(resp);
                                            angular.forEach(resp, function(value,key){
//                                                console.log(value,key);
                                                angular.forEach(value, function(val2,key2){
//                                                    console.log(val2,key2);
//                                                    console.log(val2.spend);
                                                    $scope.networkmaparrayonload[i].networkDetails[j]['OverallSpend'] = Math.round(val2.spend);
//                                                    $scope.totalSpendforAllNetwork = $scope.totalSpendforAllNetwork + val2.spend;
                                                });
                                            });
                                        }
                                        else{
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                        } else {  //  $rootScope.progressLoader = "none";
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                       errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            }
                                        }
                                    }));
                                })(i,j);
                            }
                        }
                        else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
                            if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                (function(i,j)
                                {
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId,undefined,undefined,undefined,appSettings.twNetwork,true).then(function(response)
                                    {
                                        if(response.appStatus == 0)
                                        {
//                                            console.log(response.adAccountInsights);
                                            angular.forEach(response.adAccountInsights,function(value,key)
                                            {
                                                angular.forEach(value,function(value2,key2)
                                                {
//                                                    console.log(value2.spend);
                                                    $scope.networkmaparrayonload[i].networkDetails[j]['OverallSpend'] = Math.round(value2.spend);
                                                });
                                            });
                                        }
                                        else{
                                            
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                           
                                            else 
                                            {
                                                  
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                         errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            }
                                            
                                        
                                                        errorString.push(response.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            
                                        
                                    }));
                                })(i,j);
                            }
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        $scope.getOverallBudget();
                    });
        };
        
        $scope.getOverallBudget = function()
        {
            $scope.progressLoader="block";
            var promises = [];
            for (i = 0; i < $scope.networkmaparrayonload.length; i++)
            {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails'))
                {
                    for(j=0; j< $scope.networkmaparrayonload[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                            if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId,undefined,undefined,undefined,appSettings.fbNetwork,true).then(function(resp)
                                    {
                                         if(resp.appStatus == 0)
                                        {
                                            angular.forEach(resp.adaccountbudget , function(value2, key2)
                                            {
                                                angular.forEach(value2, function(value3, key3)
                                                {
                                                    $scope.networkmaparrayonload[i].networkDetails[j]['OverallBudget'] = Math.round(parseFloat(value3.budget));
                                                });
                                            });
                                        }
                                    }));
                                }
                            }
                            else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId,undefined,undefined,undefined,appSettings.twNetwork,true).then(function(resp)
                                    {
//                                        console.log(resp.adAccountBudget);
                                        if(resp.appStatus == 0)
                                        {
                                            angular.forEach(resp.adAccountBudget , function(value2, key2)
                                            {
                                                angular.forEach(value2, function(value3,key3)
                                                {
                                                    $scope.networkmaparrayonload[i].networkDetails[j]['OverallBudget'] = Math.round(parseFloat(value3.budget));
                                                });
                                            });
                                        }
                                    }));
                                }
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    
                    function(){
                        $scope.progressLoader="none";
//                        $scope.getOverallBudget();
                        $scope.budget = [];
                        $scope.totalfbbudget = 0;
                        $scope.totalfbspend = 0;
                        $scope.totaltwbudget = 0;
                        $scope.totaltwspend = 0;
                        for (i = 0; i < $scope.networkmaparrayonload.length; i++)
                        {
                            if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails'))
                            {
                                for(j=0; j< $scope.networkmaparrayonload[i].networkDetails.length; j++)
                                {
                                    if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                    {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("OverallBudget") )
                                        {
                                            $scope.totalfbbudget += $scope.networkmaparrayonload[i].networkDetails[j].OverallBudget;
                                            
                                        }
                                        if( $scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("OverallSpend"))
                                        {
                                            $scope.totalfbspend += $scope.networkmaparrayonload[i].networkDetails[j].OverallSpend;
                                        }
                                    }
                                    else if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                    {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("OverallBudget"))
                                        {
                                            $scope.totaltwbudget += $scope.networkmaparrayonload[i].networkDetails[j].OverallBudget;
                                           
                                        }
                                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("OverallSpend"))
                                        {
                                             $scope.totaltwspend += $scope.networkmaparrayonload[i].networkDetails[j].OverallSpend;
                                        }
                                    }
                                }
                            }
                        }    
                        $scope.budget = [
                            {id:"0", image: "images/global/facebook.svg", network: "Facebook", currentBudget: $scope.totalfbbudget},
                            {id:"1", image: "images/global/twitter.svg", network: "Twitter", currentBudget: $scope.totaltwbudget}
//                            ,{id:"2", image: "images/global/twitter.svg", network: "Twitter", currentBudget: $scope.totaltwbudget}
                        ];
                        $scope.rowCollapse = [true,false];
                        $scope.totalBudgetforAllNetwork = $scope.totalfbbudget + $scope.totaltwbudget;
                        
//                        console.log($scope.totalfbbudget);
//                        console.log($scope.totalfbspend);
                        var per;
                        if($scope.totalBudgetforAllNetwork != 0)
                        {
                            per = Math.round(($scope.totalfbbudget/$scope.totalBudgetforAllNetwork)*100);
                        }
                        else 
                        {
                            per = 0;    
                        }                        
//                        console.log(per);
//                        console.log($scope.totalfbbudget);
//                        console.log($scope.totaltwbudget);
                        $scope.networkWiseSpendPercentage = per;
                        
//                        var div = angular.element("#scrollTable");
//                        var hasVerticalScrollbar = div[0].scrollHeight > div[0].clientHeight;
//                        console.log("here");
//                        console.log(div);
//                        console.log(div[0].scrollHeight);
//                        console.log(div[0].clientHeight);
//                        console.log(hasVerticalScrollbar)
//                        if(!hasVerticalScrollbar)
//                        {
//                            console.log("if");
//                            console.log(angular.element("#FacebookSelect"));
//                            angular.element("#FacebookSelect").css("left","98%");
//                            console.log(angular.element("#FacebookSelect"));
//                        }
//                        else
//                        {
//                            console.log("else");
//                            angular.element("#FacebookSelect").css("left","96%");
//                        }
                        

                       // console.log(JSON.stringify($scope.networkmaparrayonload, null, 2));
                        $scope.calculateDateDiffAndBreakDown($scope.fromDate, $scope.toDate);
                    });
        };

        $scope.calculateDateDiffAndBreakDown = function(from,to)
        {
            $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
            $scope.currentDate = new Date(from);
            $scope.toDateNumber = new Date(to).getDate();
            $scope.toMonth = new Date(to).getMonth() + 1;
            $scope.toYear = new Date(to).getFullYear();
            $scope.fromDateNumber = new Date(from).getDate();
            $scope.fromMonth = new Date(from).getMonth() + 1;
            $scope.fromYear = new Date(from).getFullYear();
            $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
            $scope.yearDiff = $scope.toYear - $scope.fromYear;
            $scope.dateArray = [];
            $scope.spendComparison = [];
            $scope.breakdown = "";
            $scope.datedifference = 0;
            while ($scope.currentDate <= new Date(to))
            {
                
                $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                $scope.datedifference = $scope.datedifference+1;
            }
            
            if($scope.datedifference >=1 && $scope.datedifference <=7)
                    {
                        $scope.breakdown = "DAILY";
                    }
                    else if($scope.yearDiff>=1){
                        $scope.breakdown = "YEARLY";
                    }
                    else if($scope.datedifference>=8 && $scope.datedifference<=31 && $scope.monthDiff <= 1){
                        $scope.breakdown = "WEEKLY";
                    }
                    else if($scope.datedifference>=8 && $scope.datedifference<=31 && $scope.monthDiff > 1){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if($scope.monthDiff >= 1 && $scope.monthDiff <=3){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if ($scope.monthDiff>3 && $scope.monthDiff <= 6){
                        $scope.breakdown = "QUARTERLY";
                    }
                    else if ($scope.monthDiff > 6  && $scope.monthDiff <=12){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff <2){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff>=2){
                        $scope.breakdown = "YEARLY";
                    }
//            console.log($scope.breakdown);
//            console.log(from);
//            console.log(to);
//            console.log($scope.datedifference);
//            console.log($scope.monthDiff);
            if($scope.breakdown == "DAILY")
            {
                $scope.currentDate = new Date(from);
                while ($scope.currentDate <= new Date(to))
                {
                    $scope.dateArray.push($scope.currentDate.toISOString().slice(0,10));
                    var obj = {
                        'date':$scope.currentDate.toISOString().slice(0,10),
                        'spend':0
                    };
                    $scope.spendComparison.push(obj);
                    $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }
//                console.log($scope.dateArray);
//                console.log($scope.spendComparison);
            }
            $rootScope.progressLoader = "none";
            $scope.readaccountinsights();
        };

        $scope.resetCalender = function()
        {
            $scope.from = "";
            $scope.to = "";
            $scope.from1 = "";
            $scope.to1 = "";
            $scope.mindate = "";
            $rootScope.progressLoader = "block";
            $scope.breakdown = "DAILY";
            $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
            $scope.calculateDateDiffAndBreakDown($scope.fromDate, $scope.toDate);
        };


        $scope.readaccountinsights = function()
        {
//            console.log(JSON.stringify($scope.networkmaparray,null,2));
//console.log($scope.fromDate);
//console.log($scope.toDate);
            
            var spendArray = [];
            var promises = [];
            var dates = [];
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    var fDate;
                                    var tDate;
                                    var saveDecider;
                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                    {
                                        fDate = $scope.fromDate;
                                        tDate = $scope.toDate;
                                        saveDecider = true;
                                    }
                                    else
                                    {
                                        fDate = $scope.UTCFromDate;
                                        tDate = $scope.UTCToDate;
                                        saveDecider = false;
                                    }
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fDate,tDate,$scope.breakdown,appSettings.fbNetwork,saveDecider).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            spendArray = [];
                                            resp = resp.adAccountInsights;
                                            angular.forEach(resp,function(value,key)
                                            {
                                                angular.forEach(value,function(value2,key2)
                                                {
                                                    angular.forEach(value2,function(value3,key3)
                                                    {
                                                        if($scope.breakdown != "DAILY"){
                                                            var keyValue2 = key3.split('_').join(' ');
                                                            var obj = {
                                                               "date":keyValue2,
                                                               "region":"Spend",
                                                               "amount":value3.spend
                                                            };
                                                            spendArray.push(obj);
                                                            dates.push(keyValue2);
                                                        }
                                                        else if($scope.breakdown == "DAILY"){
                                                            if(key3.length== 10 )
                                                            {
                                                                //timestamp is in seconds
                                                                //converting to milliseconds
                                                                var timest=key3.concat("000");
                                                                var d = $filter('date')(timest,'yyyy-MM-dd');
                                                            }
                                                            else
                                                            {
                                                                d = $filter('date')(key3,'yyyy-MM-dd');
                                                            }
                                                            var obj={
                                                                "date":d,
                                                                "region":"Spend",
                                                                "amount":value3.spend
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    });
                                                });
                                            });
                                            angular.forEach(spendArray,function(v1,k1)
                                            {
                                                $scope.networkmaparray[i].networkDetails[j].plotDetails.push(v1);
                                            });
//                                            $scope.networkmaparray[i].networkDetails[j].plotDetails.push(spendArray);
                                        }
                                        else 
                                        {
                                             $rootScope.progressLoader = "none";
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                            else 
                                            {
                                             $rootScope.progressLoader = "none";
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                           
                                            else 
                                            {
                                                  
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( resp.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(resp.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                         errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparray[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(resp.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            }
                                            
                                        }
                                        }
                                    }));
                                }
                            }
                            else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) 
                            {
                                //twitter readad account insights
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    var fDate;
                                    var tDate;
                                    var saveDecider;
                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                    {
                                        fDate = $scope.fromDate;
                                        tDate = $scope.toDate;
                                        saveDecider = true;
                                    }
                                    else
                                    {
                                        fDate = $scope.UTCFromDate;
                                        tDate = $scope.UTCToDate;
                                        saveDecider = false;
                                    }
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fDate,tDate,$scope.breakdown,appSettings.twNetwork,saveDecider).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            spendArray = [];
                                            resp = resp.adAccountInsights;
                                            angular.forEach(resp,function(value,key)
                                            {
                                                angular.forEach(value,function(value2,key2)
                                                {
                                                    angular.forEach(value2,function(value3,key3)
                                                    {
                                                        if($scope.breakdown != "DAILY"){
                                                            var keyValue2 = key3.split('_').join(' ');
                                                            var obj = {
                                                               "date":keyValue2,
                                                               "region":"Spend",
                                                               "amount":value3.spend
                                                            };
                                                            spendArray.push(obj);
                                                            dates.push(keyValue2);
                                                        }
                                                        else if($scope.breakdown == "DAILY"){
                                                            if(key3.length== 10 )
                                                            {
                                                                //timestamp is in seconds
                                                                //converting to milliseconds
                                                                var timest=key3.concat("000");
                                                                var d = $filter('date')(timest,'yyyy-MM-dd');
                                                            }
                                                            else
                                                            {
                                                                d = $filter('date')(key3,'yyyy-MM-dd');
                                                            }
                                                            var obj={
                                                                "date":d,
                                                                "region":"Spend",
                                                                "amount":value3.spend
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    });
                                                });
                                            });
                                            angular.forEach(spendArray,function(v1,k1)
                                            {
                                                $scope.networkmaparray[i].networkDetails[j].plotDetails.push(v1);
                                            });
//                                          $scope.networkmaparray[i].networkDetails[j].plotDetails.push(spendArray);
                                        }
                                        else 
                                        {
                                             $rootScope.progressLoader = "none";
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                           
                                            else 
                                            {
                                                  
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( resp.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(resp.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                         errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparray[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(resp.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            }
                                            
                                        }
                                    }));
                                }
                            
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                   function(){
                        var uniqueDates = [];
//                       console.log(JSON.stringify($scope.networkmaparray,null,2));
                        if($scope.breakdown != "DAILY")
                        {
                            uniqueDates = dates.filter(function(elem, index, self) {
                                return index == self.indexOf(elem);
                            });
//                            console.log(uniqueDates);
//                            console.log(dates);
                            $scope.dateArray = angular.copy(uniqueDates);
                            for(a=0;a<uniqueDates.length;a++)
                            {
                                var obj = {
                                    "date":uniqueDates[a],
                                    "spend": 0
                                };
                                $scope.spendComparison.push(obj);
                            }
                        }
                        $scope.getAccountBudget();
                   });
        };

        $scope.getAccountBudget = function()
        {
             $scope.progressLoader="block";
            var promises = [];
            var budget = 0;
            //console.log($scope.networkmaparray);
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    var fDate;
                                    var tDate;
                                    var saveDecider;
                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                    {
                                        fDate = $scope.fromDate;
                                        tDate = $scope.toDate;
                                        saveDecider = true;
                                    }
                                    else
                                    {
                                        fDate = $scope.UTCFromDate;
                                        tDate = $scope.UTCToDate;
                                        saveDecider = false;
                                    }
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fDate,tDate,$scope.breakdown,appSettings.fbNetwork,saveDecider).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            budget = 0;
                                            resp = resp.adaccountbudget;
                                            angular.forEach(resp,function(value,key)
                                            {
                                                var dateKey = "";
                                                angular.forEach(value, function(val2,key2)
                                                {
                                                    if($scope.breakdown != "DAILY")
                                                    {
                                                        dateKey = key2.split("_").join(" ");
                                                    }
                                                    else
                                                    {
                                                        dateKey = key2;
                                                    }
                                                    budget = parseFloat(val2.budget);
                                                });
//                                                budget = budget + parseFloat(value.budget);
                                                var obj={
                                                   "date":dateKey,
                                                   "region":"Budget",
                                                   "amount":Math.round(parseFloat(budget))
                                                };
                                                $scope.networkmaparray[i].networkDetails[j].plotDetails.push(obj);
                                            });
                                        }
                                        else 
                                        {
                                           //  $rootScope.progressLoader = "none";
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                            else 
                                            {
                                                  
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( resp.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(resp.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                        errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparray[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(resp.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                            }
                                        }
                                    }));
                                }
                            }
                            else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    var fDate;
                                    var tDate;
                                    var saveDecider;
                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                    {
                                        fDate = $scope.fromDate;
                                        tDate = $scope.toDate;
                                        saveDecider = true;
                                    }
                                    else
                                    {
                                        fDate = $scope.UTCFromDate;
                                        tDate = $scope.UTCToDate;
                                        saveDecider = false;
                                    }
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fDate,tDate,$scope.breakdown,appSettings.twNetwork,saveDecider).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            budget = 0;
                                            resp = resp.adAccountBudget;
                                            angular.forEach(resp,function(value,key)
                                            {
                                                var dateKey = "";
                                                angular.forEach(value, function(val2,key2)
                                                {
                                                    if($scope.breakdown != "DAILY")
                                                    {
                                                        dateKey = key2.split("_").join(" ");
                                                    }
                                                    else
                                                    {
                                                        dateKey = key2;
                                                    }
                                                    budget = parseFloat(val2.budget);
                                                });
//                                                budget = budget + parseFloat(value.budget);
                                                var obj={
                                                   "date":dateKey,
                                                   "region":"Budget",
                                                   "amount":Math.round(parseFloat(budget))
                                                };
                                                $scope.networkmaparray[i].networkDetails[j].plotDetails.push(obj);
                                            });
                                        }
                                        else 
                                        {
                                         //    $rootScope.progressLoader = "none";
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                            else 
                                            {          
                                                
                                           //     $rootScope.progressLoader = "none";
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( resp.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(resp.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                        errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Ad accountId:<b>" + $scope.networkmaparray[i].networkDetails[j].adAccountId+"</b>");
                                                        errorString.push(resp.errorMessage); errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        
                                                }
                                                            
                                            }
                                        }
                                    }));
                                }
                            }
                        })(i,j);
                    }
                }
            }
            
            $q.all(promises).finally(
                   function(){
                        $scope.progressLoader="none";
//                        console.log(JSON.stringify($scope.networkmaparray,null,2));
                        $scope.readcampaigninsights();
                   });
        };

        $scope.readcampaigninsights = function()
        {  $scope.progressLoader="block";
//            var allmetrics = [];
            var spendArray = [];
//            $scope.allMetricNamesWithDuplicate = [];
            var promises = [];
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
//                                if($scope.networkmaparray[i].networkDetails[j].parent.length != 0)
//                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
//                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].length != 0)
//                                        {
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                (function(i,j,k,l)
                                                {
                                                    var fDate;
                                                    var tDate;
                                                    var saveDecider;
                                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                                    {
                                                        fDate = $scope.fromDate;
                                                        tDate = $scope.toDate;
                                                        saveDecider = true;
                                                    }
                                                    else
                                                    {
                                                        fDate = $scope.UTCFromDate;
                                                        tDate = $scope.UTCToDate;
                                                        saveDecider = false;
                                                    }
                                                    promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,fDate,tDate,undefined,$scope.breakdown,appSettings.fbNetwork,saveDecider).then(function(response)
                                                    {
                                                         spendArray = [];
                                                        if(response.appStatus == 0)
                                                        {
        //                                                    allmetrics = [];
                                                            var resp = response.adCampaignInsights;
        //                                                                    console.log(JSON.stringify(resp, null, 2));
                                                            angular.forEach(resp, function(value,key)
                                                            {
                                                                angular.forEach(value, function(value2,key2)
                                                                {
                                                                    var obj = {};
                                                                    angular.forEach(value2, function(value3,key3)
                                                                    {
                                                                         if($scope.breakdown != "DAILY"){
                                                                            var keyValue2 = key3.split('_').join(' ');
                                                                            var obj = {
                                                                               "date":keyValue2,
                                                                               "region":"Spend",
                                                                               "amount":value3.spend
                                                                            };
                                                                            spendArray.push(obj);
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                        }
                                                                        else if($scope.breakdown == "DAILY"){
                                                                            if(key3.length== 10 )
                                                                            {
                                                                                //timestamp is in seconds
                                                                                //converting to milliseconds
                                                                                var timest=key3.concat("000");
                                                                                var d = $filter('date')(timest,'yyyy-MM-dd');
                                                                            }
                                                                            else
                                                                            {
                                                                                d = $filter('date')(key3,'yyyy-MM-dd');
                                                                            }
                                                                            var obj={
                                                                                "date":d,
                                                                                "region":"Spend",
                                                                                "amount":value3.spend
                                                                            };
                                                                            spendArray.push(obj);
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                        }
                                                                    });
                                                                });
                                                            });
                                                        
                                                        
                                                        }
                                                        else{
                                                     //       $rootScope.progressLoader = "none";
                                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                $window.localStorage.setItem("TokenExpired", true);
                                                                $state.go('login');
                                                            } else {
                                             
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg)
                                                            ;errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> parentcampaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].parent[j].name+"</b> <br> childcampaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns[l].name+"</b>");
                                                        errorString.push(response.errorMessage); 
                                                        errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);//  completionstatus=true;
                                                          //   $scope.errorhandeler();
                                                       // 
                                                }
                                                            }
                                                        }
                                                    }));
                                                })(i,j,k,l);
                                            }
//                                        }
                                    }
//                                }
                            }
                        }
                        else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
//                            console.log("twitter here");
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
//                                if($scope.networkmaparray[i].networkDetails[j].parent.length != 0)
//                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
//                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].length != 0)
//                                        {
                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                            {
                                                (function(i,j,k,l)
                                                {
                                                    var fDate;
                                                    var tDate;
                                                    var saveDecider;
                                                    if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                                                    {
                                                        fDate = $scope.fromDate;
                                                        tDate = $scope.toDate;
                                                        saveDecider = true;
                                                    }
                                                    else
                                                    {
                                                        fDate = $scope.UTCFromDate;
                                                        tDate = $scope.UTCToDate;
                                                        saveDecider = false;
                                                    }
                                                    promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,fDate,tDate,undefined,$scope.breakdown,appSettings.twNetwork,saveDecider).then(function(response)
                                                    {
                                                         spendArray = [];
                                                        if(response.appStatus == 0)
                                                        {
        //                                                    allmetrics = [];
                                                            var resp = response.adCampaignInsights;
        //                                                                    console.log(JSON.stringify(resp, null, 2));
                                                            angular.forEach(resp, function(value,key)
                                                            {
                                                                angular.forEach(value, function(value2,key2)
                                                                {
                                                                    var obj = {};
                                                                    angular.forEach(value2, function(value3,key3)
                                                                    {
                                                                         if($scope.breakdown != "DAILY"){
                                                                            var keyValue2 = key3.split('_').join(' ');
                                                                            var obj = {
                                                                               "date":keyValue2,
                                                                               "region":"Spend",
                                                                               "amount":value3.spend
                                                                            };
                                                                            spendArray.push(obj);
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                        }
                                                                        else if($scope.breakdown == "DAILY"){
                                                                            if(key3.length== 10 )
                                                                            {
                                                                                //timestamp is in seconds
                                                                                //converting to milliseconds
                                                                                var timest=key3.concat("000");
                                                                                var d = $filter('date')(timest,'yyyy-MM-dd');
                                                                            }
                                                                            else
                                                                            {
                                                                                d = $filter('date')(key3,'yyyy-MM-dd');
                                                                            }
                                                                            var obj={
                                                                                "date":d,
                                                                                "region":"Spend",
                                                                                "amount":value3.spend
                                                                            };
                                                                            spendArray.push(obj);
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                        }
                                                                    });
                                                                });
                                                            });
                                                        }
                                                        else{
                                                         
                                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                $window.localStorage.setItem("TokenExpired", true);
                                                                $state.go('login');
                                                            } else {
                                              
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                           
                                                             errorHeader.push($scope.networkmaparrayonload[i].advertiserName + " : " + $scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             
                                                    } else {
                                                            
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        
                                                        errorHeader.push(" Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> parentcampaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].parent[j].name+"</b> <br> childcampaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns[l].name+"</b>");
                                                        errorString.push(response.errorMessage);errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);// $scope.errorhandeler();
                                                          //  completionstatus=true;
                                                          //   $scope.errorhandeler();
                                                }
                                                            }
                                                        }
                                                    }));
                                                })(i,j,k,l);
                                            }
//                                        }
                                    }
//                                }
                            }
                        }
                    }
                }
            }
            $q.all(promises).finally(function(){
                 $scope.progressLoader="none";
                $scope.getcampaignbudget();
                
            });
        };
        
        $scope.getcampaignbudget = function()
        {
            $scope.progressLoader="block";
//            console.log($scope.dateArray);
			var promises = [];
            var budgetCalls = [];
			var budget = 0;
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            var campaignIds = "";
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        campaignIds = campaignIds + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id + ",";
                                    }
                                }
                            }
                            var obj = {
                                "userNetworkMapId":$scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                "networkURL":$scope.networkmaparray[i].networkDetails[j].networkURL,
                                "campaignIds":campaignIds
                            };
                            budgetCalls.push(obj);
                        }
                        else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
                            var campaignIds = "";
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        campaignIds = campaignIds + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id + ",";
                                    }
                                }
                            }
                            var obj = {
                                "userNetworkMapId":$scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                "networkURL":$scope.networkmaparray[i].networkDetails[j].networkURL,
                                "campaignIds":campaignIds
                            };
                            budgetCalls.push(obj);
                        }
                    }
                }
            }
//            console.log(JSON.stringify(budgetCalls,null,2));
            for(a=0;a<budgetCalls.length;a++)
            {
                if(budgetCalls[a].networkURL == appSettings.fbNetwork)
                {
                    (function(a)
                    {
                        var fDate;
                        var tDate;
                        var saveDecider;
                        if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                        {
                            fDate = $scope.fromDate;
                            tDate = $scope.toDate;
                            saveDecider = true;
                        }
                        else
                        {
                            fDate = $scope.UTCFromDate;
                            tDate = $scope.UTCToDate;
                            saveDecider = false;
                        }
                        promises.push(performanceServices.getcampaignbudget(budgetCalls[a].userNetworkMapId,budgetCalls[a].campaignIds,fDate,tDate,$scope.breakdown,appSettings.fbNetwork,saveDecider).then(function(response)
                        {
                            if(response.appStatus == 0)
                            {
//                                console.log(response.adcampaignbudget);
                                angular.forEach(response.adcampaignbudget,function(value,key)
                                {
                                    angular.forEach(value,function(value2,key2)
                                    {
//                                        console.log(key2);
                                        angular.forEach(value2,function(value3,key3)
                                        {
//                                            console.log(key3);
                                            angular.forEach(value3, function(value4,key4)
                                            {
//                                                console.log(key4);
//                                                console.log(value4);
//                                                console.log(value4.budget);
//                                    console.log(value.budget,key);
                                                for(i=0;i<$scope.networkmaparray.length;i++)
                                                {
                                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                                    {
                                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                                        {
                                                            if($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId)
                                                            {
                                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                                {
                                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                                    {
                                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                                        {
                                                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2)
                                                                            {
                                                                                budget = 0;
                                                                                budget = budget + parseFloat(value4.budget);
                                                                                var obj = {
                                                                                    "date":key4.split("_").join(" "),
                                                                                    "region":"Budget",
                                                                                    "amount":Math.round(parseFloat(value4.budget))
                                                                                };
                                                                                $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            });    
                                        });       
                                    });
                                });
                            }
                        }));
                    })(a);
                }
                else if(budgetCalls[a].networkURL == appSettings.twNetwork)
                {
                    (function(a)
                    {
                        var fDate;
                        var tDate;
                        var saveDecider;
                        if(($scope.from1 == undefined || $scope.from1 == "") && ($scope.to1 == undefined || $scope.to1 == ""))
                        {
                            fDate = $scope.fromDate;
                            tDate = $scope.toDate;
                            saveDecider = true;
                        }
                        else
                        {
                            fDate = $scope.UTCFromDate;
                            tDate = $scope.UTCToDate;
                            saveDecider = false;
                        }
                        promises.push(performanceServices.getcampaignbudget(budgetCalls[a].userNetworkMapId,budgetCalls[a].campaignIds,fDate,tDate,$scope.breakdown,appSettings.twNetwork,saveDecider).then(function(response)
                        {
                            if(response.appStatus == 0)
                            {
                                angular.forEach(response.adCampaignBudget,function(value,key)
                                {
                                    angular.forEach(value,function(value2,key2)
                                    {
                                        angular.forEach(value2,function(value3,key3)
                                        {
                                            angular.forEach(value3,function(value4,key4)
                                            {
                                                for(i=0;i<$scope.networkmaparray.length;i++)
                                                {
                                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                                    {
                                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                                        {
                                                            if($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId)
                                                            {
                                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                                {
                                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                                    {
                                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                                        {
            //                                                                console.log();
                                                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2)
                                                                            {
                                                                                budget = 0;
                                                                                budget = budget + parseFloat(value4.budget);
                                                                                var obj = {
                                                                                    "date":key4.split("_").join(" "),
                                                                                    "region":"Budget",
                                                                                    "amount":Math.round(parseFloat(value4.budget))
                                                                                };
                                                                                $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].plotDetails.push(obj);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            });
                                        });
                                    });
                                });
                            }
                        }));
                    })(a);
                }
            }
            $q.all(promises).finally(function()
            {
//               console.log(JSON.stringify($scope.networkmaparray, null, 2));
                completionstatus=true;
                $scope.progressLoader="none";
                $scope.errorhandeler();
                $scope.checkDropDownSelections();
               
//                $scope.checkInsightsAvailability();
            });
        };
        
        $scope.checkDropDownSelections = function()
        {
//            console.log(JSON.stringify($scope.networkmaparray, null, 2));
//            console.log("checking drop down selections");
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
                    if($scope.selectedParentChildCampaign != "" && $scope.selectedParentChildCampaign != undefined)
                    {
                        if($scope.selectedParentChildCampaign.type == "parent")
                        {
//                            console.log("adv, net, parent selected, ");
                            $scope.parentselection($scope.selectedParentChildCampaign);
                        }
                        else if($scope.selectedParentChildCampaign.type == "child")
                        {
//                            console.log("adv, net, child selected,");
                            $scope.childselection($scope.selectedParentChildCampaign);
                        }
                    }
                    else
                    {
//                        console.log("adv, net selected,");
                        $scope.selectnetwork();
                    }
                }
                else
                {
                    if($scope.selectedParentChildCampaign != "" && $scope.selectedParentChildCampaign != undefined)
                    {
                        if($scope.selectedParentChildCampaign.type == "parent")
                        {
//                            console.log("adv, parent selected, ");
                            $scope.parentselection($scope.selectedParentChildCampaign);
                        }
                        else if($scope.selectedParentChildCampaign.type == "child")
                        {
//                            console.log("adv, child selected,");
                            $scope.childselection($scope.selectedParentChildCampaign);
                        }
                    }
                    else
                    {
//                        console.log("adv selected,");
                        $scope.selectadvertiser();
                    }
                }
            }
            else
            {
                if($scope.networkId != "" && $scope.networkId != undefined)
                {
                    if($scope.selectedParentChildCampaign != "" && $scope.selectedParentChildCampaign != undefined)
                    {
                        if($scope.selectedParentChildCampaign.type == "parent")
                        {
//                            console.log("net, parent selected, ");
                            $scope.parentselection($scope.selectedParentChildCampaign);
                        }
                        else if($scope.selectedParentChildCampaign.type == "child")
                        {
//                            console.log("net, child selected,");
                            $scope.childselection($scope.selectedParentChildCampaign);
                        }
                    }
                    else
                    {
//                        console.log("net selected,");
                        $scope.selectnetwork();
                    }
                }
                else
                {
                    if($scope.selectedParentChildCampaign != "" && $scope.selectedParentChildCampaign != undefined)
                    {
                        if($scope.selectedParentChildCampaign.type == "parent")
                        {
//                            console.log("parent selected, ");
                            $scope.parentselection($scope.selectedParentChildCampaign);
                        }
                        else if($scope.selectedParentChildCampaign.type == "child")
                        {
//                            console.log("child selected,");
                            $scope.childselection($scope.selectedParentChildCampaign);
                        }
                    }
                    else
                    {
//                        console.log("nothing selected, not redirecting");
                        $scope.checkInsightsAvailability();
                    }
                }
            }
        };
        
        $scope.checkInsightsAvailability = function()
        {
//            console.log("check insights availability");
//            console.log(JSON.stringify($scope.networkmaparray, null, 2));
            var noInsightsForAdvertiser = 0;            
            var noInsights = true;
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                noInsights = true;
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount != 0)
                                    {
                                        noInsights = false;
                                    }
                                }
                                if(noInsights == false)
                                {
                                    break;
                                }
                            }
                        }
                        if(noInsights == false)
                        {
                            break;
                        }
                    }
                }
                if(noInsights == true)
                {
                    noInsightsForAdvertiser++;
                }
//                console.log("noInsightsForAdvertiser " + noInsightsForAdvertiser);
//                console.log($scope.networkmaparray.length);
            }
            
            if(noInsightsForAdvertiser == $scope.networkmaparray.length)
            {
//                console.log("no table");
                $scope.noTable = true;
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
//                $rootScope.progressLoader = "none";
//                console.log("table");
                $scope.noTable = false;
                $scope.graphPlotted = true;
                $scope.prepareForPlotting();
            }
        };
        
        $scope.prepareForPlotting = function()
        {
            var obj = [];
            var zero_count = 0;
            var spentcount = 0;
            for(var i=0;i<$scope.dateArray.length;i++)
            {
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Spend",
                    "amount":0
                };
                obj.push(o);
                var o = {
                    "date":$scope.dateArray[i],
                    "region":"Budget",
                    "amount":0
                };
                obj.push(o);
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].plotDetails.length;k++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Spend")
                                {
                                    for(l=0;l<obj.length;l++)
                                    {
                                        if(obj[l].region == "Spend")
                                        {
                                            if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                            {
                                                obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                            }
                                        }
                                    }
                                }
                                else if($scope.networkmaparray[i].networkDetails[j].plotDetails[k].region == "Budget")
                                {
                                    for(l=0;l<obj.length;l++)
                                    {
                                        if(obj[l].region == "Budget")
                                        {
                                            if(obj[l].date == $scope.networkmaparray[i].networkDetails[j].plotDetails[k].date)
                                            {
                                                obj[l].amount = obj[l].amount + Math.round(parseFloat($scope.networkmaparray[i].networkDetails[j].plotDetails[k].amount));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if($scope.breakdown == "DAILY")
            {
                for(i=0;i<obj.length;i++)
                {
                    var d = obj[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    obj[i].date = d;
                }
            }
//            console.log(obj);
            var spendTemp = [];
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].region == "Spend")
                {
                    spentcount++;
                    spendTemp.push(obj[i]);
                    if(obj[i].amount == 0)
                    {
                        zero_count++;
                    }
                }
            }
            for(i=spendTemp.length-1;i>=0;i--)
            {
                if(spendTemp[i-1] != undefined)
                {
                    if(spendTemp[i].amount > spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/up.svg";
                    }
                    else if(spendTemp[i].amount < spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/down.svg";
                    }
                    else if(spendTemp[i].amount == spendTemp[i-1].amount)
                    {
                        spendTemp[i]['image'] = "images/global/equal.svg";
                    }
                }
            }
//            console.log(spendTemp);
            $scope.spendComparison = angular.copy(spendTemp);
            if(zero_count == spentcount)
            {
                $rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
            }
            else
            {
                $scope.plotlinechart(obj); 
            }
             
        };
        
        $scope.setUserIdAndAccessToken = function() {
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.getaccountdetails();
        };
        
        $scope.loadCurrencyCode = function()
        {
            performanceServices.loadcurrencydata().then(function(response) {
                $scope.currencyList = response.currencyList;
                $scope.setUserIdAndAccessToken();
            });
        };
        
        
        $scope.checkCurrencyCode = function(_code) 
        {
//            console.log(_code);
                angular.forEach($scope.currencyList, function(value, key) {				
                        if($scope.currencyList[key].currency == _code){
                                $scope.currencyValue = $scope.currencyList[key].currencyCode;
                                return $scope.currencyList[key].currencyCode;

                        }
                });
//                 console.log($scope.currencyValue);
                $scope.currencyCode = $scope.currencyValue;
//                console.log($scope.currencyCode);
        };
        
        $scope.plotDoughnutChart = function (val)
        {  
            if(doughnutChart == undefined || doughnutChart == "undefined")
            {
                var chartOptions = {
                    id: "1",
                    container: {
                        id: "#doughnutChart",
                        width: 230,
                        height: 230,
                        title: " ",
                        titlePos: 15
                    },
                    startAngle: 90,
                    gloss: 'yes',
                    bindings: {pie: "Spend", value: "contribution"},
                    radius: {inner: 0.8, outer: 1.0},
                    tooltip: {
                        container: "#doughnutChart", width: 120, height: 200,
                        bindings: [{label: "Budget", bindWith: "Budget"},
                            {label: "Spend", bindWith: "Spend"}]
                    }
                };

                doughnutChart = cviz.widget.DoughnutChart.Runner(chartOptions).graph();
                $rootScope.progressLoader = "none";
                doughnutChart.render(val);
                $(".arc path").css("fill-opacity", "1");
                $(".arc path").eq(0).css("fill", "rgb(144,211,205)");
                $(".arc path").eq(0).css("stroke", "rgb(255,255,255)");
                $(".arc path").eq(3).css("fill", "rgb(3,100,244)");
                $(".arc path").eq(2).css("fill", "rgb(109,195,234)");
                $(".arc path").eq(1).css("fill", "rgb(85,165,158)");
                $(".arc text").hide();
            }
            else
            {
                doughnutChart.update(val);
                $(".arc path").css("fill-opacity", "1");
                $(".arc path").eq(0).css("fill", "rgb(144,211,205)");
                $(".arc path").eq(0).css("stroke", "rgb(255,255,255)");
                $(".arc path").eq(3).css("fill", "rgb(3,100,244)");
                $(".arc path").eq(2).css("fill", "rgb(109,195,234)");
                $(".arc path").eq(1).css("fill", "rgb(85,165,158)");
                $(".arc text").hide();
            }
        };
        
        $scope.calculateValueForDoughnut = function(val)
        {
//            console.log("calculate value for doughnut");
//            console.log(val);
//            console.log(JSON.stringify(val, null, 2));
//            console.log(JSON.stringify($scope.spendComparison, null, 2));
//            console.log("total budget");
//            console.log($scope.totalBudget);
            $rootScope.progressLoader = "none";
            $scope.totalSpend = 0;
            $scope.totalBudget = 0;
            for(var i=0;i<val.length;i++){
                if(val[i].region == "Spend"){
                    $scope.totalSpend = $scope.totalSpend + val[i].amount;
                }
                else if (val[i].region == "Budget"){
                   $scope.totalBudget = $scope.totalBudget + val[i].amount;
                }
            }
//            if($scope.breakdown=="DAILY")
//            {
//                $scope.totalBudget = $scope.totalBudget * $scope.datedifference;
//            }
            $scope.totalSpend = Math.round($scope.totalSpend);
            $scope.totalBudget = Math.round($scope.totalBudget);
            
            if($scope.totalBudget != 0)
            {
                $scope.percentageOfSpend = ($scope.totalSpend/$scope.totalBudget)*100;
            }
            else if($scope.totalBudget == 0 && $scope.totalSpend == 0)
            {
                $scope.percentageOfSpend = 0;
            }
            else if($scope.totalBudget == 0 && $scope.totalSpend != 0)
            {
                $scope.percentageOfSpend = 100;
            }
            $scope.percentageOfSpend = Math.round($scope.percentageOfSpend);
            $scope.percentageOfBudget = 100 - $scope.percentageOfSpend;
            var chartvalues = [
                {"Budget": $scope.percentageOfBudget + "%", "contribution": $scope.percentageOfBudget}, 
                {"Spend": $scope.percentageOfSpend +"%", "contribution": $scope.percentageOfSpend} 
            ];
            
            $scope.plotDoughnutChart(chartvalues);
        };
        
        $scope.plotlinechart = function (val) 
        {
            $scope.arrow_pos = [];
            $scope.transpos = [];
            if(val.length == 2)
            {
                var val2 = val;
                angular.forEach(val2,function(value,key)
                {
                    val.push(value);
                });
            }
//            console.log(JSON.stringify(val, null, 2));
            if(val.length == 0)
            {
                $scope.graphPlotted = false;
            }
            else
            {
                $scope.graphPlotted = true;
                $scope.calculateValueForDoughnut(val);
                var sampleData = val;
                $("#lineChart").empty();
                var options = {
                    id: "1",
                    container: {
                        id: "#lineChart", 
                        title: " ", 
                        showDataLabels: 'no', 
                        titlePos: 24, 
                        contextBrush: "no",
                        showGrid : 'yes',
                        width:800,
                        height:300
                    },
                    markerRadius: 3,
                    bindings: {x: "date", y: "amount", category: "region", marker: ''},
                    labels: {x: " ", y: " "},
                    margin: {top: 10, right: 30, bottom: 30, left: 30},
                    colors: {"Spend": "rgb(85, 165, 158)", "Budget": "rgb(144, 211, 205)"},

                    axisRange: {
                        y: {
                            min: 0
                        }
                    },
                    scaling: {x: 4, y: 1},
                    tickerAngle: {x: 0},
                    tooltip: {
                        width: 250,
                        bindings: [{label: $scope.currencyCode, bindWith: "amount"}]
                    }
                };

                var bar_graph = cviz.widget.LineChart.Runner(options).graph();

                bar_graph.render(sampleData);
                for (var i = 0; ; i++)
                {
                    if (document.getElementById("lineChart").children[0].children[0].children[1].children[i].hasChildNodes())
                        document.getElementById("lineChart").children[0].children[0].children[1].children[i].children[1].setAttribute("opacity","0");
                    else
                        break;
                }
                for (var i = 0; ; i++)
                {
                    if (document.getElementById("lineChart").children[0].children[0].children[3].children[i].hasChildNodes())
                    {
                        if(document.getElementById("lineChart").children[0].children[0].children[3].children[i].getAttribute("transform") != null)
                        $scope.transpos.push(document.getElementById("lineChart").children[0].children[0].children[3].children[i].getAttribute("transform"));
                    }
                    else
                    {
                        break;
                    }
                }
                
                for(var i=0;i<$scope.transpos.length;i++)
                {
                    var s=$scope.transpos[i].split('(')[1];
                    var str=s.split(',')[0];
                    $scope.arrow_pos.push(str);
                }
                
//                console.log($scope.arrow_pos);
                for(i=0;i<$scope.arrow_pos.length;i++)
                {
                    $scope.arrow_pos[i] = parseFloat($scope.arrow_pos[i]);
                }
                document.getElementById("lineChart").children[0].children[0].children[0].setAttribute("opacity","0");
               // document.getElementById("lineChart").children[0].children[0].children[1].setAttribute("opacity","0");
                document.getElementById("lineChart").children[0].children[0].children[3].setAttribute("transform","translate(0,270)");
            }
            
        };
        
        $scope.loadCurrencyCode();

                    //resetting the pop up
          $scope.resetPopup = function() {
                       $scope.campSumErrors = "none";
                       $scope.editAdsetErrorMsg="none";
                        angular.element("#errorScroll").scrollTop(0);
                      
        };
        
        

        $scope.resetPopup1 = function() {
                       $scope.campSumErrors = "none";$scope.editAdsetErrorMsg="none";
                        angular.element("#errorScroll").scrollTop(0);
                        errorcount=false;
                        angular.element($('body').css("overflow-y", "scroll"));
                         var errorHeader = [];    
                        var errorString = [];
                        var errornetwork =[];
        };
         var p=0;
        $scope.errorhandeler =function()
        {
            $rootScope.progressLoader = "none";
          //  if(errorcount)
            {
                
                if((errorHeader.length)>0)
                {
                    
                   angular.element("#campSumErrors").empty();			
          angular.element("#errorScroll").css("height","100px");
          angular.element("#errorScroll").css("overflow-y","hidden");
          angular.element("#lessErrors").css("display","none");	
	  angular.element("#moreErrors").css("display","flex");
          angular.element($('body').css("overflow-y", "none"));
          angular.element("#errorScroll").scrollTop(0);
             
                    $scope.campSumErrors = 'block';
                          for(p;p<errorHeader.length;p++)
                {
                    var image;
                 
                   
                 if(errornetwork[p]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                            
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
                     
                    );
       
                    }else
                    if(errornetwork[p]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                               "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
        
                    );
                }
                }
               
                }
            }
          
           
              
            };
       //"<img style='width: 30%;height: 30%;src='images/accountDashboard/facebook.svg'>"+
       //  $scope.campSumErrors='block';
           $scope.viewMoreErrors = function()
        {  var pp=0;
            angular.element("#campSumErrors").empty();	
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
             for(pp;pp<errorHeader.length;pp++)
                {
                    var image;
                    var a=70,b=20;
                  //  console.log(errorHeader[pp].indexOf('<br>'));
                  //  console.log(errorHeader[pp]);
                    if( errorHeader[pp].indexOf("childcampaign") > -1)
                        a=90;b=30;
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: "+a+"px; border-right: 1px solid #c5c5c5;float: left;padding-top: "+b+"px;'>"+								
                                                                
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp]
                                 +"</div>" +"</div>"+ "</div>" 

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: "+a+"px; border-right: 1px solid #c5c5c5;float: left;padding-top: "+b+"px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp] +
                               								
                                "</div>" +    "</div>" + "</div>" 
        
                    );
                }
                }  
    
        };
    
        $scope.viewLessErrors = function()
        {
            var pp;
         angular.element("#campSumErrors").empty();			
          angular.element("#errorScroll").css("height","100px");
          angular.element("#errorScroll").css("overflow-y","hidden");
          angular.element("#lessErrors").css("display","none");	
	  angular.element("#moreErrors").css("display","flex");
          angular.element($('body').css("overflow-y", "none"));
          angular.element("#errorScroll").scrollTop(0);
            
          
           
            
            
            for(pp=0;pp<errorHeader.length;pp++)
                {
                    var image;
                 console.log(errornetwork[pp]);
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                             
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[pp] +                               						
                                "</div>" +                              
                                "</div>"

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[pp] +                               						
                                "</div>" +                              
                                "</div>"
        
                    );
                }
                } 
        };
        
        
        PubSub.subscribe('1-doughnut-chart-render-complete', function(event, eventObject) {
            $(".arc path").css("fill-opacity", "1");
            $(".arc path").eq(0).css("fill", "rgb(144,211,205)");
            $(".arc path").eq(0).css("stroke", "rgb(255,255,255)");
            $(".arc path").eq(3).css("fill", "rgb(3,100,244)");
            $(".arc path").eq(2).css("fill", "rgb(109,195,234)");
            $(".arc path").eq(1).css("fill", "rgb(85,165,158)");
            $(".arc text").hide();
        });
    }]);