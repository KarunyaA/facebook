dashboard.controller("expectedvsactualController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', '$sce', 'appSettings', '$timeout','$filter','apiService','performanceServices',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout, $filter, apiService,performanceServices) 
    {
        $rootScope.progressLoader = "block";
        var apiBase = appSettings.apiBase;
        $scope.userRole;
        $scope.plotvaluesOnLoad;
        var apiTPBase = appSettings.apiTPBase;        
        var datedifference = 7;
        $scope.todayDate = new Date().toISOString().slice(0,10);
        $scope.campaignInsightsUnavailableCount = 0;
        $scope.totalBudget;
        $scope.selectedParentChildCampaign;
        $scope.onloadParentSelection = false;
        $scope.onloadChildSelection = false;       
        $scope.accountRole = true;
        $scope.wholeParentArrayOnLoad = [];
        $scope.wholeChildArrayOnLoad = [];        
        $scope.totalSpend;
        $scope.totalSpendforAllNetwork = 0;
        $scope.currency;
        $scope.currencyList = {};
        $scope.currencyCode;
        $scope.graphPlotted = false;
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.campaignDropDown = [];
        $scope.expectedright = [];
        $scope.actualright = [];
         $scope.expectedleft = [];
        $scope.actualleft = [];
        $scope.toDate = localDateTimetoUTCDateTime(new Date());
        $scope.fromDate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000)));
        $scope.dateArray = [];
        $scope.plotvalues = [];
        $scope.dateDiff = 0;
        $scope.breakdown = "DAILY";
        $scope.monthDiff = 0;
        $scope.yearDiff = 0;
        $scope.countNetMapId = 0;
        $scope.countAdaccountId = 0;        
        $scope.networksforaccount = [];
        $scope.dates = [];
        $scope.advertiserdetails = {};
        $scope.bool = [];
        $scope.networksarrayforacc = [];
        $scope.wholeParentArray = [];
        $scope.wholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkmaparray = [];
        $scope.spendComparison = [];
        $scope.spendComparisonOnLoad = [];
        $scope.networkforadv = false;
        $scope.parenttoggle = false;
        $scope.fromDateChange = false;
        $scope.toDateChange = false;
        $scope.kpi = 'clicks';
        $scope.message = "Graph";
        $scope.status = false;
        $scope.lineplotted = true;
        
		$scope.errors = [];	
		$scope.errorCheck = false;
		$scope.errorHeader = [];
		$scope.errorString = [];
		$scope.networkLogo = [];
	      $scope.handlingErrors = function(){
		
		 angular.forEach($scope.errors,function(value){
			 
			 if(value.category == "advertiser"){							
				            $scope.errorCheck = true;
							if($scope.errorHeader.indexOf("Advertiser : " + value.network.advertiserName) == -1){
								$scope.errorHeader.push("Advertiser : " + value.network.advertiserName);
								$scope.errorString.push(value.errorMsg);
								console.log(value.advertiserDetails.networkName);
								if(value.advertiserDetails.networkName == "Facebook"){
									var src = "images/accountDashboard/facebook.svg";
									$scope.networkLogo.push(src);
								}else if(value.advertiserDetails.networkName == "Twitter"){									
									var src = "images/accountDashboard/twitter.svg";
									$scope.networkLogo.push(src);
								}
								
							}
							
							//FOR NW URL : console.log(value.advertiserDetails.networkURL);
						
			 }else if(value.category == "networkLevel"){

				// adver name  , net logo , parent camp name
			 }
			 else if(value.category == "parentCampaign") {
				 console.log(value);
				 angular.forEach($scope.wholeParentArray,function(checkID){
					 if(checkID.id == value.parentID){
						    console.log(value);
				            $scope.errorCheck = true;	
							if($scope.errorHeader.indexOf("Advertiser : " + value.network.advertiserName + '\<br>' + "Parent Campaign:" + checkID.name+ '\<br>' + "Child Campaign : " + value.campaignDetails.name) == -1){
								$scope.errorHeader.push("Advertiser : " + value.network.advertiserName + '\<br>' + "Parent Campaign:" + checkID.name+ '\<br>' + "Child Campaign : " + value.campaignDetails.name);
								$scope.errorString.push(value.errorMsg);	
								if(value.advertiserDetails.networkName == "Facebook"){
									var src = "images/accountDashboard/facebook.svg";
									$scope.networkLogo.push(src);
								}else if(value.advertiserDetails.networkName == "Twitter"){									
									var src = "images/accountDashboard/twitter.svg";
									$scope.networkLogo.push(src);
								}
							}							
							//FOR NW URL : console.log(value.advertiserDetails.networkURL);
					 }
					 
				 })
			 } else if(value.category == "childCamp") {
				 
				 angular.forEach($scope.wholeParentArray,function(checkID){
					 if(checkID.id == value.parentID){
						    console.log(value);
				            $scope.errorCheck = true;	
							if($scope.errorHeader.indexOf("Advertiser :" + value.network.advertiserName  + '\<br>'+ "Parent Campaign : " + checkID.name) == -1){
								$scope.errorHeader.push("Advertiser :" + value.network.advertiserName  + '\<br>'+ "Parent Campaign : " + checkID.name);
								$scope.errorString.push(value.errorMsg);	
								if(value.advertiserDetails.networkName == "Facebook"){
									var src = "images/accountDashboard/facebook.svg";
									$scope.networkLogo.push(src);
								}else if(value.advertiserDetails.networkName == "Twitter"){									
									var src = "images/accountDashboard/twitter.svg";
									$scope.networkLogo.push(src);
								}
							}							

							//FOR NW URL : console.log(value.advertiserDetails.networkURL);
					 }
					 
				 })

			 }
		 })
		 
		    if($scope.errorCheck)
            {
			    angular.element("#errorScroll").css("height","100px");
                angular.element("#errorScroll").css("overflow-y","hidden");
                angular.element("#moreErrors").css("display","flex");
				angular.element("#lessErrors").css("display","none");
                $scope.campSumErrors = 'block';
                for(a=0;a<$scope.errorString.length;a++)
                {					 
                        angular.element("#campSumErrors").append(
                                "<div style='background:white;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 30px;' src='"+$scope.networkLogo[a]+"'>"+
								"</div>"+                               
                               "<div style='font-weight: bold;width:100%;color:red;padding-top: 12px;margin-left: 45px;'>" +
                                $scope.errorString[a] +                               						
                                "</div>" +                              
                                "</div>");		          
                }
			}
            else
            {
                console.log("no errors");
            }
		 $scope.errors = [];	
	 }
	
    
		    $scope.viewMoreErrors = function()
        {
		    angular.element("#campSumErrors").empty();			
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");	
			angular.element("#lessErrors").css("display","flex");
			$scope.campSumErrors = 'block';
                for(a=0;a<$scope.errorHeader.length;a++)
                {					 
                        angular.element("#campSumErrors").append(
                                "<div style='background:white;height:110px;'>" +								    
								"<div style='width: 40px;height: 62px; border-right: 1px solid #c5c5c5;float: left;padding-top: 12px;'>"+								
								"<img style='width: 30px;' src='"+$scope.networkLogo[a]+"'>"+
								"</div>"+
                                "<div style='width: 92%;font-weight: bold; margin-left: 48px; height: 75px;'>" + 								    
                                $scope.errorHeader[a]+   
                                "<div style='width:100%;color:red;'>" +
                                $scope.errorString[a] +
                                "</div>" +								
                                "</div>" +                              
                                "</div>");		          
                }					
        };

		
		   $scope.viewLessErrors = function()
        {
            angular.element("#campSumErrors").empty();			
            angular.element("#errorScroll").css("height","100px");
            angular.element("#errorScroll").css("overflow-y","hidden");
            angular.element("#lessErrors").css("display","none");	
			angular.element("#moreErrors").css("display","flex");
			$scope.campSumErrors = 'block';
            for(a=0;a<$scope.errorString.length;a++)
                {					 
                        angular.element("#campSumErrors").append(
                                "<div style='background:white;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 30px;' src='"+$scope.networkLogo[a]+"'>"+
								"</div>"+                               
                                "<div style='font-weight: bold;width:100%;color:red;padding-top: 12px;margin-left: 45px;'>" +
                                $scope.errorString[a] +                               						
                                "</div>" +                              
                                "</div>");		          
                }			
			
        };

        $scope.resetErrorPopup = function() {
            $scope.editAdsetErrorMsg = 'none';
            $scope.campSumErrors = "none";
            angular.element("#errorScroll").scrollTop(0);
			angular.element("#campSumErrors").empty();
		
		    $scope.errorCheck = false;
            $scope.errorHeader = [];
            $scope.errorString = [];
			$scope.networkLogo = [];
            //$rootScope.progressLoader = "block";
			$scope.errors = [];
        };
        
        $scope.nocampaignselection = function ()
        {
            $scope.selectedvalue = "Select Campaign";
            $scope.selectedParentChildCampaign = "";
            $rootScope.progressLoader = "block";
            if (($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == ""))
            {
                if ($scope.advertiserId == undefined || $scope.advertiserId == "")
                {
                    if ($scope.networkId == "" || $scope.networkId == undefined)
                    {
                        $scope.breakdown = "DAILY";
                        datedifference = 7;
                        $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                        $scope.wholeChildArray = $scope.wholeChildArrayOnLoad;
                        $scope.plotvalues = $scope.plotvaluesOnLoad;
                        $scope.expectedleft = $scope.expectedleftOnLoad;
                        $scope.expectedright = $scope.expectedrightOnLoad;
                        $scope.actualleft = $scope.actualleftOnLoad;
                        $scope.actualright = $scope.actualrightOnLoad;
                        $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
                    } else
                    {
                        $scope.selectnetwork();
                    }
                } else
                {
//                    console.log("no from and to but advertiser is there");
                    if ($scope.networkId == "" || $scope.networkId == undefined)
                    {
                        $scope.breakdown = "DAILY";
                        datedifference = 7;
                        $scope.selectadvertiser();
                    } else
                    {
                        $scope.selectnetwork();
                    }


                }
            } else
            {
                $scope.fromAndToChanged();
            }
        };
        
        $scope.checkCurrencyCode = function (_code)
        {
            angular.forEach($scope.currencyList, function (value, key) {
                if ($scope.currencyList[key].currency == _code) {
                    $scope.currencyValue = $scope.currencyList[key].currencyCode;
                    return $scope.currencyList[key].currencyCode;

                }
            });

            $scope.currencyCode = $scope.currencyValue;
        };
        
        $scope.getShortDate = function (d) {
            d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', {month: "short"});
            return d;
        };
        function localDateTimetoUTCDateTime(date) {
            var d = new Date(date);
            var utcDate = d.toUTCString();
            return new Date(utcDate).toISOString().slice(0, 10);
        }
        $scope.fromAndToChanged = function () {
            $scope.mindate = $filter('date')($scope.from1, 'yyyy-MM-dd');
            $scope.from = $filter('date')($scope.from1, 'yyyy-MM-dd');
            $scope.to = $filter('date')($scope.to1, 'yyyy-MM-dd');
            $scope.btnText = 'Calculate';
            $scope.textbx = "";
            $scope.Isvisible = false;                      
            if ($scope.from != undefined && $scope.to != undefined)
            {
                if (new Date($scope.from) <= new Date($scope.to))
                {
                    $rootScope.progressLoader = "block";
                    datedifference = 0;
                    $scope.breakdown = "";
                    var date = new Date();
                    var hour = date.getHours();
                    var hour1 = hour > 10 ? '0' + hour : hour;
                    var min = date.getMinutes();
                    var min1 = min > 10 ? '0' + min : min;
                    var sec = date.getSeconds();
                    var sec1 = sec > 10 ? '0' + sec : sec;
                    var fromDateTime = $scope.from + " " + hour1 + ":" + min1 + ":" + sec1;
                    var toDateTime = $scope.to + " " + hour1 + ":" + min1 + ":" + sec1;
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.currentDate = new Date($scope.UTCFromDate);
                    $scope.toDateNumber = new Date($scope.UTCToDate).getDate();
                    $scope.toMonth = new Date($scope.UTCToDate).getMonth() + 1;
                    $scope.toYear = new Date($scope.UTCToDate).getFullYear();
                    $scope.fromDateNumber = new Date($scope.UTCFromDate).getDate();
                    $scope.fromMonth = new Date($scope.UTCFromDate).getMonth() + 1;
                    $scope.fromYear = new Date($scope.UTCFromDate).getFullYear();
                    if (($scope.toMonth - $scope.fromMonth) >= 0)
                    {
                        $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
                    } else if (($scope.toMonth - $scope.fromMonth) < 0)
                    {
                        $scope.monthDiff = 12 - ($scope.fromMonth - $scope.toMonth);
                    }
                    $scope.yearDiff = $scope.toYear - $scope.fromYear;
                    while ($scope.currentDate <= new Date($scope.to)) {
                        $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                        datedifference = datedifference + 1;
                    }
                    if (datedifference >= 1 && datedifference <= 7)
                    {
                        $scope.breakdown = "DAILY";
                    } else if ($scope.yearDiff >= 1) {
                        $scope.breakdown = "YEARLY";
                    } else if (datedifference >= 8 && datedifference <= 30 && $scope.monthDiff <= 1) {
                        $scope.breakdown = "WEEKLY";
                    } else if (datedifference >= 8 && datedifference <= 30 && $scope.monthDiff > 1) {
                        $scope.breakdown = "MONTHLY";
                    } else if ($scope.monthDiff >= 1 && $scope.monthDiff <= 3) {
                        $scope.breakdown = "MONTHLY";
                    } else if ($scope.monthDiff > 3 && $scope.monthDiff <= 6) {
                        $scope.breakdown = "QUARTERLY";
                    } else if ($scope.monthDiff > 6 && $scope.monthDiff <= 12) {
                        $scope.breakdown = "HALFYEARLY";
                    } else if ($scope.monthDiff > 12 && $scope.yearDiff < 2) {
                        $scope.breakdown = "HALFYEARLY";
                    } else if ($scope.monthDiff > 12 && $scope.yearDiff >= 2) {
                        $scope.breakdown = "YEARLY";
                    }
                    if ($scope.advertiserId != undefined && $scope.advertiserId != "")//ADVERTISER SELECTED
                    {
                        if ($scope.networkId == "" || $scope.networkId == undefined)//ADVERTISER SELECTED AND NETWORK NOT SELECTED
                        {
                            if ($scope.selectedParentChildCampaign == "" || $scope.selectedParentChildCampaign == undefined)//ADVERTISER SELECTED AND NETWORK,CAMPAIGN NOT SELECTED
                            {
                                $scope.selectadvertiser();
                            } else//NOTHING SELECTED
                            {
                                if ($scope.selectedParentChildCampaign.type == "parent")
                                {
                                    console.log("parent selected");
                                    $scope.parentselection($scope.selectedParentChildCampaign);
                                } else if ($scope.selectedParentChildCampaign.type == "child")
                                {
                                    console.log("child selected");
                                    $scope.childselection($scope.selectedParentChildCampaign);
                                }
                            }
                        } else//NETWORK AND ADVERTISER SELECTED
                        {
                            if ($scope.selectedParentChildCampaign == "" || $scope.selectedParentChildCampaign == undefined)//NETWORK,ADVERTISER SELECTED AND NO CAMPAIGN
                            {
                                console.log("into network selection");
                                $scope.selectnetwork($scope.networkId);
                            } else
                            {
                                if ($scope.selectedParentChildCampaign.type == "parent")//PARENT SELECTED
                                {
                                    console.log("parent selected");
                                    $scope.parentselection($scope.selectedParentChildCampaign);
                                } else if ($scope.selectedParentChildCampaign.type == "child")//CHILD SELECTED
                                {
                                    console.log("child selected");
                                    $scope.childselection($scope.selectedParentChildCampaign);
                                }
                            }

                        }
                    } else
                    {
                        if ($scope.networkId == "" || $scope.networkId == undefined)
                        {
                            if ($scope.selectedParentChildCampaign == "" || $scope.selectedParentChildCampaign == undefined)
                            {
                                $scope.readAccountBudgetByCategory();

                            } else
                            {
                                if ($scope.selectedParentChildCampaign.type == "parent")
                                {
                                    console.log("parent selected no advertiser");
                                    $scope.parentselection($scope.selectedParentChildCampaign);
                                } else if ($scope.selectedParentChildCampaign.type == "child")
                                {
                                    console.log("child selected no advertiser");
                                    $scope.childselection($scope.selectedParentChildCampaign);
                                }
                            }
                        } else//NETWORK SELECTED AND NO ADVERTISER SELECTED
                        {
                            if ($scope.selectedParentChildCampaign == "" || $scope.selectedParentChildCampaign == undefined)//NETWORK,ADVERTISER SELECTED AND NO CAMPAIGN
                            {
                                console.log("into network selection");
                                $scope.selectnetwork($scope.networkId);
                            } else
                            {
                                if ($scope.selectedParentChildCampaign.type == "parent")//PARENT SELECTED
                                {
                                    console.log("parent selected");
                                    $scope.parentselection($scope.selectedParentChildCampaign);
                                } else if ($scope.selectedParentChildCampaign.type == "child")//CHILD SELECTED
                                {
                                    console.log("child selected");
                                    $scope.childselection($scope.selectedParentChildCampaign);
                                }
                            }

                        }
                    }
                }
            }
        };
        
        $scope.readAccountBudgetByCategory = function () {
            var promises = [];
            var budget = 0;
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function (i, j)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function (resp)
                                    {
                                        if (resp.appStatus == 0)
                                        {
                                            resp = resp.adaccountbudget;
                                            var array = [];
                                            angular.forEach(resp, function (value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        } else {
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
                                               $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                        }
                                    }));
                                }
                            }
                            else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function (resp)
                                    {
                                        if (resp.appStatus == 0)
                                        {
                                            resp = resp.adAccountBudget;
                                            var array = [];
                                            angular.forEach(resp, function (value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        } else {
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                        }
                                    }));
                                }
                            }
                        })(i, j);
                    }
                }
            }
            $q.all(promises).finally(
                    function ()
                    {
                        if ($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        } else if ($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        } else if ($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        } else if ($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        } else if ($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }
                        $scope.readaccountinsightsByCategory($scope.UTCFromDate, $scope.UTCToDate, $scope.breakdown, budget);
                    });
        };

        $scope.calculateDates = function (from, to) {
            var totalBudget = 0;
            var cpa = 0;
            var cpm = 0;
            var cpc = 0;
            var expectedclicks = 0;
            var expectedimp = 0;
            var expectedactions = 0;
            $scope.expectedright = [];
            $scope.actualright = [];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            $scope.graphPlotted = false;
            $scope.currentDate = new Date(from);
            $scope.toDateNumber = new Date($scope.toDate).getDate();
            $scope.toMonth = new Date($scope.toDate).getMonth() + 1;
            $scope.toYear = new Date().getFullYear();
            $scope.fromDateNumber = new Date($scope.fromDate).getDate();
            $scope.fromMonth = new Date($scope.fromDate).getMonth() + 1;
            $scope.fromYear = new Date($scope.fromDate).getFullYear();
            $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
            $scope.yearDiff = $scope.toYear - $scope.fromYear;
            $scope.dateArray = [];
            while ($scope.currentDate <= new Date(to)) {
                $scope.dateArray.push($scope.currentDate.toISOString().slice(0, 10));
                var obj = {
                    'date': $scope.currentDate.toISOString().slice(0, 10),
                    'spend': 0,
                    'impressions': 0,
                    'clicks': 0,
                    'actions': 0
                };
                $scope.spendComparison.push(obj);
                $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                $scope.dateDiff = $scope.dateDiff + 1;
            }
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                        if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('spenddetails')) {
                            for (l = $scope.spendComparison.length - 1; l >= 0; l--) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].spenddetails.length; k++) {
                                    if ($scope.spendComparison[l].date == $scope.networkmaparray[i].networkDetails[j].spenddetails[k].date) {
                                        $scope.spendComparison[l].spend = $scope.spendComparison[l].spend + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].spend;
                                        $scope.spendComparison[l].impressions = $scope.spendComparison[l].impressions + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].impressions;
                                        $scope.spendComparison[l].clicks = $scope.spendComparison[l].clicks + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].clicks;
                                        $scope.spendComparison[l].actions = $scope.spendComparison[l].actions + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].actions;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('budgetdetails'))
                        {
                            totalBudget = totalBudget + parseInt($scope.networkmaparray[i].networkDetails[j].budgetdetails);
                        }
                    }
                }
            }
            for (i = 0; i < $scope.spendComparison.length; i++)
            {
                var d = $scope.spendComparison[i].date;
                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', {month: "short"});
                $scope.spendComparison[i].date = d;
            }
            $scope.spendComparisonOnLoad = $scope.spendComparison;
            for (i = 1; i < $scope.spendComparison.length; i++) {
                var obj = {
                    "date": $scope.spendComparison[i].date,
                    "region": "actions",
                    "amount": $scope.spendComparison[i].actions
                };
                $scope.plotvalues.push(obj);
                var object = {
                    "date": $scope.spendComparison[i].date,
                    "name": "spend",
                    "amount": $scope.spendComparison[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date": $scope.spendComparison[i].date,
                    "name": "budget",
                    "amount": totalBudget
                };
                $scope.expectedleft.push(_object);
                cpc = $scope.spendComparison[i].spend / $scope.spendComparison[i].clicks;
                if (isNaN(cpc)) {
                    expectedclicks = 0;
                } else {
                    expectedclicks = totalBudget / cpc;
                }
                var _obj = {
                    "date": $scope.spendComparison[i].date,
                    "name": "expectedclicks",
                    "amount": expectedclicks
                }
                var _act = {
                    "date": $scope.spendComparison[i].date,
                    "name": "clicks",
                    "amount": $scope.spendComparison[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);                
                cpm = $scope.spendComparison[i].spend / ($scope.spendComparison[i].impressions / 1000);
                if (isNaN(cpm)) {
                    expectedimp = 0;
                } else {
                    expectedimp = totalBudget / cpm;
                }
                var _obj = {
                    "date": $scope.spendComparison[i].date,
                    "name": "expectedimp",
                    "amount": expectedimp
                }
                var _act = {
                    "date": $scope.spendComparison[i].date,
                    "name": "impressions",
                    "amount": $scope.spendComparison[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = $scope.spendComparison[i].spend / $scope.spendComparison[i].actions;
                if (isNaN(cpa)) {
                    expectedactions = 0;
                } else {
                    expectedactions = totalBudget / cpa;
                }
                var _obj = {
                    "date": $scope.spendComparison[i].date,
                    "name": "expectedactions",
                    "amount": expectedactions
                }
                var _act = {
                    "date": $scope.spendComparison[i].date,
                    "name": "actions",
                    "amount": $scope.spendComparison[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date": $scope.spendComparison[i].date,
                    "region": "spend",
                    "amount": $scope.spendComparison[i].spend
                };
                $scope.plotvalues.push(obj);
            }
            if ($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
            {
                $scope.advertiserId = $window.localStorage.getItem("advertiserId");
                $scope.selectadvertiser();
				
            } else
            {
                $scope.plotvaluesOnLoad = $scope.plotvalues;
                $scope.expectedleftOnLoad = $scope.expectedleft;
                $scope.expectedrightOnLoad = $scope.expectedright;
                $scope.actualleftOnLoad = $scope.actualleft;
                $scope.actualrightOnLoad = $scope.actualright;
                $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
            }
			//$scope.handlingErrors();
        };

        $scope.getaccountdetails = function () {
            var promises = [];
            var getAccountDetailsSuccess = false;
            $scope.accountId = $window.localStorage.getItem("accountId");
            $scope.advertiserDetails = {};
            $scope.adverDetails = [];
            promises.push(performanceServices.getaccountdetails($scope.accountId).then(function (response) {
                if (response.appStatus == '0') {// success
                    $scope.accountName = response.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.accountFetchResponse.logoUrl;
                    getAccountDetailsSuccess = true;
                } else {// failed
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        //$rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (getAccountDetailsSuccess)
                        {
                            $scope.downloadAccountLogo($scope.accountLogoUrl);
                        }
                    });
        };

        $scope.downloadAccountLogo = function (accountLogoUrl){
            var promises = [];
            
            promises.push(performanceServices.downloadimages(accountLogoUrl).then(function(response){
                if (response.appStatus == '0'){
                    $scope.accountLogo = response.imageContent[$scope.accountLogoUrl];
                }
                else{ 
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                                        $scope.errorMsg = response.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.errorMessage;
                                                }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
//                        if(downloadImageSuccess)
//                        {
                            $scope.getAdvertiserDetails();
//                        }
                    });
        };
        
        $scope.getAdvertiserDetails = function (){
            var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                } 
                else{
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                                        $scope.errorMsg = response.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.errorMessage;
                                                }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(getAdvertiserDetails)
                        {
                            $scope.allnetworks();

                        }
                    });
        };
        
        $scope.allnetworks = function (){
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response){
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                }
                else{
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(allnetworks)
                        {
                            $scope.networksforacc();
                        }
                    });
        };
        
        $scope.networksforacc = function (){
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                    for (i = 0; i < $scope.networksarrayforacc.length; i++){
                        angular.forEach($scope.allnetworksarray, function (val, key){
                            if ($scope.networksarrayforacc[i].networkId == val.networkId){
                                if(!$scope.networksforaccount.includes(val.networkName)){
                                    var obj = {
                                        "networkName":val.networkName,
                                        "networkId":val.networkId
                                    };
                                    $scope.networksforaccount.push(obj);
                                }
                            }
                        });
                    }
                   
                }
                else{
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(networksforaccount)
                        {
                            $scope.getusernetworkmapids();
                        }
                    });
        };
        
        $scope.getusernetworkmapids = function (){
            var promises = [];
            angular.forEach($scope.advertiserdetails, function (val, key){
                var networkdetailobj=[];
                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){   
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){ 
                                if($scope.allnetworksarray[j].networkUrl == appSettings.fbNetwork || $scope.allnetworksarray[j].networkUrl == appSettings.twNetwork ){
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl,
                                  
                                };
                                networkdetailobj.push(obj2);
                            }
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.networkmaparray.push(obj); 
            });
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                        if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            promises.push(performanceServices.readadaccounts($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function(response)
                            {    
                                if(response.appStatus == 0)
                                {
                                    angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
                                    {
                                        $scope.networkmaparray[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                        $scope.networkmaparray[i].networkDetails[j]["currency"] = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                        $scope.currency = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                    });
                                }
                                else{
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
						
						
						
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                        }
                                }
                            }));
                        }
                        else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
                            promises.push(performanceServices.readadaccounts($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function(response)
                            {    
                                if(response.appStatus == 0)
                                {                                    
                                    for(i=0;i<response.adAccounts.length;i++){
                                        angular.forEach(response.adAccounts[i],function(key,val){
                                           $scope.networkmaparray[i].networkDetails[j]["adAccountId"]=response.adAccounts[i][val].twAdAccountId;
                                        })
                                    }
                                }
                                else{
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                        }
                                }
                            }));
                        }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){                        
                        $scope.readaccountinsights();
                    });
        };
        
        $scope.readaccountinsightsByCategory = function(fromDate,toDate,breakDown,budget){            
            var promises = [];
            var spendArray= [];
            var spendUnique = [];
            var flag = 0;
            var dates=[];                       
            if($scope.breakdown == "DAILY")
            {   
                var currentDate = new Date(fromDate);
                while (currentDate <= new Date(toDate))
                {
                    var d = new Date(currentDate);
                    var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                    var obj = {
                       "date":currentDate1,
                       "spend":0,
                       "clicks":0,
                       "impressions":0,
                       "actions":0                       
                    };                    
                    dates.push(obj);
                    currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));                   
                }
            }
            for (var i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(var j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)//FOR FACEBOOK
                            {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fromDate,toDate,breakDown,appSettings.fbNetwork,false).then(function(resp){
                                    if(resp.appStatus == 0){
                                        angular.forEach(resp.adAccountInsights, function(value, key){
                                            angular.forEach(value, function(value2, key2){
                                                angular.forEach(value2, function(value3, key3){
                                                    if($scope.breakdown == "DAILY")
                                                    {
                                                        var d;
                                                        if(key3.length == 10)
                                                        {
                                                          d = $filter('date')(key3*1000,'yyyy-MM-dd');   
                                                        }
                                                        else
                                                        {
                                                           d = $filter('date')(key3,'yyyy-MM-dd');
                                                        }                                                                                                            
                                                        for(i=0;i<dates.length;i++)
                                                        {
                                                            if(dates[i].date==d)
                                                            {   
                                                                var obj={
                                                                    "date":dates[i].date,
                                                                    "spend":value3.spend,
                                                                    "clicks":value3.clicks,
                                                                    "impressions":value3.impressions,
                                                                    "actions" : value3.callToAction
                                                                };
                                                                spendArray.push(obj);
                                                            }
                                                            else
                                                            {
                                                                var obj={
                                                                    "date":dates[i].date,
                                                                    "spend":0,
                                                                    "clicks":0,
                                                                    "impressions":0,
                                                                    "actions" : 0
                                                                };
                                                                spendArray.push(obj);
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {                                                       
                                                        var keyValue21 = key3.split('_').join(' ');
                                                        var obj = {
                                                            "date":keyValue21,
                                                            "spend":0,
                                                            "clicks":0,
                                                            "impressions":0,
                                                            "actions" : 0
                                                        };
                                                        for(i = 0 ;i<spendUnique.length;i++)
                                                        {
                                                            if(obj.date == spendUnique[i].date)
                                                            {
                                                                flag=1;
                                                            }
                                                        }
                                                        if(spendUnique.length == 0 || flag==0)
                                                        {
                                                            spendUnique.push(obj);
                                                        }                                                        
                                                        var obj2={
                                                            "date":keyValue21,
                                                            "spend":value3.spend,
                                                            "clicks":value3.clicks,
                                                            "impressions":value3.impressions,
                                                            "actions" : value3.callToAction
                                                        };                                                        
                                                        spendArray.push(obj2);
                                                    }
                                                });
                                            });
                                        });  
                                    }
                                    else{
                                        if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
//                                             //   $rootScope.progressLoader = "none";
                                               $scope.graphPlotted = false;
                                                $scope.spendComparison = [];
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                    }
                                }));
                            }
                            }
                            else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)//FOR TWITTER
                            {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,fromDate,toDate,breakDown,appSettings.twNetwork,false).then(function(resp){
                                    if(resp.appStatus == 0){
                                        angular.forEach(resp.adAccountInsights, function(value, key){
                                            angular.forEach(value, function(value2, key2){
                                                angular.forEach(value2, function(value3, key3){
                                                    if($scope.breakdown == "DAILY")
                                                    {
                                                        var d;
                                                         if(key3.length == 10)
                                                        {
                                                          d = $filter('date')(key3*1000,'yyyy-MM-dd');   
                                                        }
                                                        else
                                                        {
                                                             d = $filter('date')(key3,'yyyy-MM-dd');
                                                        }                                                        
                                                        for(i=0;i<dates.length;i++)
                                                        {
                                                            if(dates[i].date==d)
                                                            {                                                 
                                                                var obj={
                                                                    "date":dates[i].date,
                                                                    "spend":value3.spend,
                                                                    "clicks":value3.clicks,
                                                                    "impressions":value3.impressions,
                                                                    "actions" : value3.callToAction
                                                                };
                                                                spendArray.push(obj);
                                                            }
                                                            else
                                                            {
                                                                var obj={
                                                                    "date":dates[i].date,
                                                                    "spend":0,
                                                                    "clicks":0,
                                                                    "impressions":0,
                                                                    "actions" : 0
                                                                };
                                                                spendArray.push(obj);
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {                                                       
                                                        var keyValue21 = key3.split('_').join(' ');
                                                        var obj = {
                                                            "date":keyValue21,
                                                            "spend":0,
                                                            "clicks":0,
                                                            "impressions":0,
                                                            "actions" : 0
                                                        };
                                                        for(i = 0 ;i<spendUnique.length;i++)
                                                        {
                                                            if(obj.date == spendUnique[i].date)
                                                            {
                                                                flag=1;
                                                            }
                                                        }
                                                        if(spendUnique.length == 0 || flag==0)
                                                        {
                                                            spendUnique.push(obj);
                                                        }                                                        
                                                        var obj2={
                                                            "date":keyValue21,
                                                            "spend":value3.spend,
                                                            "clicks":value3.clicks,
                                                            "impressions":value3.impressions,
                                                            "actions" :  value3.callToAction
                                                        };                                                        
                                                        spendArray.push(obj2);
                                                    }
                                                });
                                            });
                                        });  
                                    }
                                    else{
                                        if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
//                                             //   $rootScope.progressLoader = "none";
                                                $scope.graphPlotted = false;
                                                $scope.spendComparison = [];
													$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                    }
                                }));
                            }
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                   function(){                      
                       if($scope.breakdown != "DAILY")
                       {
                            var spend = [];
                            var obj = {
                                 "date":0,
                                 "spend":0,
                                 "clicks":0,
                                 "impressions":0,
                                 "actions" : 0
                            };
                            spend.push(obj);
                            for(i =0 ;i<spendUnique.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(spendUnique[i].date == spendArray[j].date)
                                    {
                                        spendUnique[i].spend = parseInt(spendUnique[i].spend) + parseInt(spendArray[j].spend);
                                        spendUnique[i].clicks = parseInt(spendUnique[i].clicks) + parseInt(spendArray[j].clicks);
                                        spendUnique[i].impressions = parseInt(spendUnique[i].impressions) + parseInt(spendArray[j].impressions);
                                        spendUnique[i].actions = parseInt(spendUnique[i].actions) + parseInt(spendArray[j].actions);
                                        
                                    }
                                }
                            }
                            for(i=0;i<spendUnique.length;i++)
                            {
                                spend.push(spendUnique[i]);
                            }                            
                            var zero_count = 0;
                            var plot = [];
                            var cpc = 0;
                            var cpm =0;
                            var cpa =0;
                            var expectedactions =0 ;
                            var expectedimp =0;
                            var expectedclicks =0;
                            $scope.expectedleft =[];
                            $scope.expectedright = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];                            
                            for(i = 1; i < spend.length; i++){
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"actions",
                                    "amount":spend[i].actions
                                };
                                plot.push(obj);
                                var object = {
                                    "date":spend[i].date,
                                    "name":"spend",
                                    "amount":spend[i].spend
                                };
                                $scope.actualleft.push(object);
                                var _object = {
                                    "date":spend[i].date,
                                    "name":"budget",
                                    "amount":budget
                                };
                                $scope.expectedleft.push(_object);
                                cpc = spend[i].spend / spend[i].clicks;
                                if(isNaN(cpc)){
                                    expectedclicks = 0;
                                }
                                else{
                                    expectedclicks= budget/cpc;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedclicks",
                                    "amount":expectedclicks
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"clicks",
                                    "amount":spend[i].clicks
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                cpm = spend[i].spend / (spend[i].impressions/1000);
                                if(isNaN(cpm)){
                                    expectedimp = 0;
                                }
                                else{
                                    expectedimp= budget/cpm;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedimp",
                                    "amount":expectedimp
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"impressions",
                                    "amount":spend[i].impressions
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                cpa = spend[i].spend / spend[i].actions;
                                if(isNaN(cpa)){
                                    expectedactions = 0;
                                }
                                else{
                                    expectedactions = budget/cpa;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedactions",
                                    "amount":expectedactions
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"actions",
                                    "amount":spend[i].actions
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"spend",
                                    "amount":spend[i].spend
                                };
                                plot.push(obj);
                            }
                            $scope.spendComparison = spend;
                            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                            $scope.plotvalues = plot;
                        }
                        else
                        {
                            var spend = [];
                            var cpc = 0;
                            var cpm =0;
                            var cpa =0;
                            var expectedactions =0 ;
                            var expectedimp =0;
                            var expectedclicks =0;
                            $scope.expectedright =[];
                            $scope.expectedleft = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            var obj = {
                                 "date":0,
                                 "spend":0,
                                 "actions":0,
                                 "impressions":0,
                                 "clicks":0
                            };
                            spend.push(obj);
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(dates[i].date == spendArray[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spendArray[j].spend);
                                        dates[i].clicks =parseInt(dates[i].clicks) + parseInt(spendArray[j].clicks);
                                        dates[i].impressions =parseInt(dates[i].impressions) + parseInt(spendArray[j].impressions);
                                        dates[i].actions =parseInt(dates[i].actions) + parseInt(spendArray[j].actions);
                                    }
                                }
                            }                             
                            for(i=0;i<dates.length;i++)
                            {
                                spend.push(dates[i]);
                            }                            
                            var zero_count = 0;
                            var plot = [];
                            for(i = 1; i < spend.length; i++) {
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"actions",
                                    "amount":spend[i].actions
                                };
                                plot.push(obj);
                                var object = {
                                    "date":spend[i].date,
                                    "name":"spend",
                                    "amount":spend[i].spend
                                };
                                $scope.actualleft.push(object);
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"spend",
                                    "amount":spend[i].spend
                                };
                                plot.push(obj);
                                var _object = {
                                    "date":spend[i].date,
                                    "name":"budget",
                                    "amount":budget
                                };
                                $scope.expectedleft.push(_object);
                                var obj = {
                                    "date":spend[i].date,
                                    "name":"clicks",
                                    "amount":spend[i].clicks
                                };
                                $scope.actualright.push(obj);
                                cpc = spend[i].spend/ spend[i].clicks;
                                if(isNaN(cpc)){
                                    expectedclicks = 0;
                                }
                                else{
                                    expectedclicks = budget / cpc;
                                }
                                var object = {
                                    "date":spend[i].date,
                                    "name":"expectedclicks",
                                    "amount":expectedclicks
                                };
                                $scope.expectedright.push(object);
                                var obj = {
                                    "date":spend[i].date,
                                    "name":"impressions",
                                    "amount":spend[i].impressions
                                };
                                $scope.actualright.push(obj);
                                cpm = spend[i].spend/ (spend[i].impressions/1000);
                                if(isNaN(cpm)){
                                    expectedimp = 0;
                                }
                                else{
                                    expectedimp= budget / cpm;
                                }
                                var object = {
                                    "date":spend[i].date,
                                    "name":"expectedimp",
                                    "amount":expectedimp
                                };
                                $scope.expectedright.push(object);
                                var obj = {
                                    "date":spend[i].date,
                                    "name":"actions",
                                    "amount":spend[i].actions
                                };
                                $scope.actualright.push(obj);
                                cpa = spend[i].spend/ spend[i].actions;
                                if(isNaN(cpc)){
                                    expectedactions = 0;
                                }
                                else{
                                    expectedactions = budget / cpa;
                                }
                                var object = {
                                    "date":spend[i].date,
                                    "name":"expectedactions",
                                    "amount":expectedactions
                                };
                                $scope.expectedright.push(object);
                            }
                            for(i = 1;i<spend.length;i++){
                                if(spend[i].spend == 0){
                                    zero_count++;
                                }
                            }
                            for(i=0;i<spend.length;i++)
                            {
                                var d = spend[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                                spend[i].date = d;
                            }
                            $scope.spendComparison = spend;                           
                            $scope.plotvalues = plot;
                            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                        }
                    });
                };
        
        $scope.readaccountinsights = function(){
            
            var promises = [];
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'DAILY',appSettings.fbNetwork,true).then(function(resp){
                                    if(resp.appStatus == 0){
                                        resp = resp.adAccountInsights;
                                        var array = [];
                                        angular.forEach(resp, function(value, key){
                                            var JSONobject = resp[key];
                                            angular.forEach(JSONobject, function(value, key){
                                                    var spend = "";
                                                    var impressions = "";
                                                    var clicks = "";
                                                    var actions = "";
                                                    var date;
                                                    if (Object.keys(JSONobject[key])[0].length == 10)
                                                    {
                                                       date  = $filter('date')(Object.keys(JSONobject[key])[0] * 1000, 'yyyy-MM-dd');
                                                    } else
                                                    {
                                                         date = $filter('date')(Object.keys(JSONobject[key])[0], 'yyyy-MM-dd');
                                                    }                               
                                                angular.forEach(JSONobject[key], function(value, key2){
                                                    spend = JSONobject[key][key2].spend;
                                                    impressions= JSONobject[key][key2].impressions;
                                                    clicks=JSONobject[key][key2].clicks;
                                                    actions = JSONobject[key][key2].callToAction
                                                });
                                                var obj = {
                                                    'date':date,
                                                    'spend':spend,
                                                    'impressions':impressions,
                                                    'clicks':clicks,
                                                    'actions':actions
                                                };
                                                array.push(obj);
                                            });
                                        });
                                        $scope.networkmaparray[i].networkDetails[j]['spenddetails']=array;                                        
                                        
                                    }
                                    else{
                                        if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {

											console.log("INSIGHTS FOR ADACCOUNT");
											console.log($scope.networkmaparray);
											console.log(resp.errorMessage);
											$scope.errors.push({"category":"advertiser","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"errorMsg":resp.errorMessage});
											console.log($scope.errors);
											
												/*$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                $scope.message = 'No Graph';										                                               
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }*/
								      }
								  }
                                }));
                            }
                            }
                           else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'DAILY',appSettings.twNetwork,true).then(function(resp){
                                    if(resp.appStatus == 0){
                                        resp = resp.adAccountInsights;                            
                                        var array = [];
                                        angular.forEach(resp, function(value, key){
                                            var JSONobject = resp[key];
                                            angular.forEach(JSONobject, function(value, key){
                                                    var spend = "";
                                                    var impressions = "";
                                                    var clicks = "";
                                                    var actions = "";
                                                    var date;
                                                    if (Object.keys(JSONobject[key])[0].length == 10)
                                                    {
                                                       date  = $filter('date')(Object.keys(JSONobject[key])[0] * 1000, 'yyyy-MM-dd');
                                                    } else
                                                    {
                                                         date = $filter('date')(Object.keys(JSONobject[key])[0], 'yyyy-MM-dd');
                                                    }                                               
                                                angular.forEach(JSONobject[key], function(value, key2){
                                                    spend = JSONobject[key][key2].spend;
                                                    impressions= JSONobject[key][key2].impressions;
                                                    clicks=JSONobject[key][key2].clicks; 
                                                    actions =JSONobject[key][key2].callToAction
                                                });
                                                var obj = {
                                                    'date':date,
                                                    'spend':spend,
                                                    'impressions':impressions,
                                                    'clicks':clicks,
                                                    'actions':actions
                                                };
                                                array.push(obj);
                                            });
                                        });                                        
                                        $scope.networkmaparray[i].networkDetails[j]['spenddetails']=array;                                        
                                        
                                    }
                                    else{
                                      if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
											
													
											console.log("INSIGHTS FOR ADACCOUNT");
											console.log($scope.networkmaparray);
											console.log(resp.errorMessage);
											$scope.errors.push({"category":"advertiser","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"errorMsg":resp.errorMessage});
											console.log($scope.errors);
											
                                               /* $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                $scope.message = 'No Graph';										                                               
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }*/
                                            }
	
											
									}                                
                                }));
                            }
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){                        
                        $scope.readAccountBudget();
                       
                    });
        }; 
        $scope.readAccountBudget = function()
        {
            var promises = [];
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function (i, j)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.fbNetwork,true).then(function (resp)
                                    {
                                        if (resp.appStatus == 0)
                                        {
                                            var budget = 0;
                                            resp = resp.adaccountbudget;
                                            var array = [];
                                            angular.forEach(resp, function (value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                            $scope.networkmaparray[i].networkDetails[j]['budgetdetails'] = budget;
                                        } else {
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                        }
                                    }));
                                }
                            }
                            else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.twNetwork,true).then(function (resp)
                                    {
                                        if (resp.appStatus == 0)
                                        {
                                            var budget = 0;
                                            resp = resp.adAccountBudget;
                                            var array = [];
                                            angular.forEach(resp, function (value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                            $scope.networkmaparray[i].networkDetails[j]['budgetdetails'] = budget;
                                        } else {
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                        }
                                    }));
                                }
                            }
                        })(i, j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){                        
                        $scope.calculateDates($scope.fromDate, $scope.toDate);                        
                        $scope.fillDropDowns();
						//$scope.handlingErrors();
                    });
					// console.log("ERROR1");
					// $scope.handlingErrors();
        };
        $scope.readAccountBudgetFromToAdvertiserFB = function(){
            console.log('budget advertiser');
            var promises = [];
            var budget = 0;
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId){
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                        for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                            (function(i,j){                                
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {                                    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            resp = resp.adaccountbudget;
                                            angular.forEach(resp, function(value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                        }
                                    }));
                                }
                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        if($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        }
                        else if($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        }
                        else if($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        }
                        else if($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        }
                        else if($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }
                      $scope.accountInsightsforAllCategoryFB(budget);
                    });
        };
        $scope.readAccountBudgetFromToAdvertiserTW = function(){
            console.log('budget advertiser');
            var promises = [];
            var budget = 0;
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId){
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                        for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                            (function(i,j){                                
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {                                    
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function(resp)
                                    {
                                        if(resp.appStatus == 0)
                                        {
                                            resp = resp.adAccountBudget;
                                            angular.forEach(resp, function(value, key)
                                            {
                                                angular.forEach(value, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                        }
                                    }));
                                }
                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        if($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        }
                        else if($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        }
                        else if($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        }
                        else if($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        }
                        else if($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }
                      $scope.accountInsightsforAllCategoryTW(budget);
                    });
        };
        $scope.readAccountBudgetFromToAdvertiser = function(){
            console.log('budget advertiser');
            var promises = [];
            var budget = 0;
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                {
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                    {
                        for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                        {
                            (function (i, j)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                    {
                                        promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function (resp)
                                        {
                                            if (resp.appStatus == 0)
                                            {
                                                resp = resp.adaccountbudget;
                                                angular.forEach(resp, function (value, key) 
                                                {
                                                    angular.forEach(value, function (value2, key2)
                                                    {
                                                        budget = budget + parseInt(value2.budget);
                                                    });
                                                });
                                            } else {
                                                if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                            }
                                        }));
                                    }
                                }
                                else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                    {
                                        promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function (resp)
                                        {
                                            if (resp.appStatus == 0)
                                            {
                                                resp = resp.adAccountBudget;
                                                angular.forEach(resp, function (value, key) 
                                                {
                                                    angular.forEach(value, function (value2, key2)
                                                    {
                                                        budget = budget + parseInt(value2.budget);
                                                    });
                                                });
                                            } else {
                                                if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                            }
                                        }));
                                    }
                                }
                            })(i, j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        if($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        }
                        else if($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        }
                        else if($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        }
                        else if($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        }
                        else if($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }
                      $scope.accountInsightsforAllCategory(budget);
                    });
        };
        
        $scope.readadaccountinsightsforFbNetwork = function(){
            if(($scope.from == undefined || $scope.from == "")  && ($scope.to == undefined || $scope.to =="")){
            var promises = [];                     
            var spend = [];
             for(i=0;i<$scope.dateArray.length;i++){
                    var obj = {
                        "date":$scope.dateArray[i],
                        "spend":0,
                        "actions":0,
                        "clicks":0,
                        "impressions":0
                    };
                    spend.push(obj);
                }
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'DAILY',appSettings.fbNetwork,true).then(function(resp){
                                    if(resp.appStatus == 0){
                                        resp = resp.adAccountInsights;
                                        angular.forEach(resp,function(val,key){
                                    angular.forEach(val,function(val2,key2){
                                        angular.forEach(val2,function(val3,key3){
                                            for (j = 0; j < $scope.dateArray.length; j++) {
                                                 var date;
                                                if ((Object.keys(val2)[0]).length == 10)
                                                {
                                                 date = $filter('date')((Object.keys(val2)[0]) * 1000, 'yyyy-MM-dd');
                                                } else
                                                {
                                                     date = $filter('date')((Object.keys(val2)[0]), 'yyyy-MM-dd');
                                                }                                                
                                                if($scope.dateArray[j] == date){
                                                    for(l=0;l<spend.length;l++){
                                                        if($scope.dateArray[j] == spend[l].date){                                                             
                                                            spend[l].spend = spend[l].spend + val3.spend;
                                                            spend[l].impressions = spend[l].impressions + val3.impressions;
                                                            spend[l].clicks = spend[l].clicks + val3.clicks;
                                                            spend[l].actions = spend[l].actions +val3.callToAction;
                                                        }
                                                    }
                                                }
                                            }
                                        });
                                    });
                                });
                            }
                                    else{
                                        if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
	
					console.log("readadaccountsinsights for FACEBOOK");
					console.log($scope.networkmaparray);
					console.log(resp.errorMessage);
					$scope.errors.push({"category":"networkLevel","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"errorMsg":resp.errorMessage});
					console.log($scope.errors);
	
                                                $scope.message = 'No Graph';
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                    }
                                }));
                            }
                        }
                    })(i,j);
                }
            }
        }
        $q.all(promises).finally(
                function(){                   
                    $scope.calculateDatesNetwork($scope.fromDate,$scope.toDate);
                });
            }
            else//FROM TO DATES SELECTED
            {               
                var spendUnique = [];
                var spendAll = [];
                var flag = 0;
                var dates = [];              
                var promises = [];
                if($scope.breakdown == "DAILY")
                {
                    var currentDate = new Date($scope.UTCFromDate);
                    while (currentDate <= new Date($scope.UTCToDate))
                    {
                        var d = new Date(currentDate)
                        var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                        var obj = {
                           "date":currentDate1,
                           "spend":0,
                           "impressions":0,
                           "clicks":0,
                           "actions":0
                        };
                        dates.push(obj);
                        currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                    }
                }              
                for (i = 0; i < $scope.networkmaparray.length; i++)
                {
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                    {
                        for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++)
                        {
                            (function(i,j)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                    {
                                        promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.fbNetwork,false).then(function(response)
                                        {
                                            if(response.appStatus == 0)
                                            {
                                                var resp = response.adAccountInsights;
                                                angular.forEach(resp,function(val,key)
                                                {
                                                    angular.forEach(val,function(val2,key2)
                                                    {
                                                        angular.forEach(val2,function(val3,key3)
                                                        {
                                                            if($scope.breakdown != "DAILY")
                                                            {
                                                                actions = 0;
                                                                var keyValue21 = key3.split('_').join(' ');
                                                                var obj = {
                                                                    "date": keyValue21,
                                                                    "spend": 0,
                                                                    "impressions": 0,
                                                                    "clicks": 0,
                                                                    "actions": 0
                                                                }
                                                                for (i = 0; i < spendUnique.length; i++)
                                                                {
                                                                    if (obj.date == spendUnique[i].date)
                                                                    {
                                                                        flag = 1;
                                                                    }
                                                                }
                                                                if (spendUnique.length == 0 || flag == 0)
                                                                {
                                                                    spendUnique.push(obj);
                                                                }                                                                
                                                                var obj2 = {
                                                                    "date": keyValue21,
                                                                    "spend": val3.spend,
                                                                    "impressions": val3.impressions,
                                                                    "clicks": val3.clicks,
                                                                    "actions": val3.callToAction
                                                                };
                                                                spendAll.push(obj2);
                                                            }
                                                            else if ($scope.breakdown == "DAILY") {
                                                                var d;
                                                                if(key3.length == 10){
                                                                  d = $filter('date')(key3 * 1000, 'yyyy-MM-dd');   
                                                                }
                                                                else{
                                                                   d = $filter('date')(key3, 'yyyy-MM-dd');   
                                                                }                                                                
                                                                for (i = 0; i < dates.length; i++)
                                                                {
                                                                    if (dates[i].date == d)
                                                                    {                                                                       
                                                                        var obj = {
                                                                            "date": dates[i].date,
                                                                            "spend": val3.spend,
                                                                            "impressions": val3.impressions,
                                                                            "clicks": val3.clicks,
                                                                            "actions": val3.callToAction
                                                                        };
                                                                        spendAll.push(obj);
                                                                    } else
                                                                    {
                                                                        var obj = {
                                                                            "date": dates[i].date,
                                                                            "spend": 0,
                                                                            "impressions": 0,
                                                                            "clicks": 0,
                                                                            "actions": 0
                                                                        };
                                                                        spendAll.push(obj);
                                                                    }
                                                                }
                                                            }
                                                        });
                                                    });
                                                });
                                            }
                                            else {
                                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
                                               //     $rootScope.progressLoader = "none";
                                                    $scope.editAdsetErrorMsg = 'block';
                                                    if (response.networkError != '' && response.networkError != undefined) {
                                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                            $scope.errorMsg = response.networkError.message;
                                                        } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                            $scope.errorMsg = response.networkError.error_user_msg;
                                                        }
                                                    } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.errorMessage;
                                                    }
                                                }
                                            }
                                        }));
                                    }
                                }
                            }(i, j)
                                    )
                        }
                    }
                }
                $q.all(promises).finally(
                        function () {                           
                            if ($scope.breakdown != "DAILY")
                            {
                                for (i = 0; i < spendUnique.length; i++)
                                {
                                    for (j = 0; j < spendAll.length; j++)
                                    {
                                        if (spendUnique[i].date == spendAll[j].date)
                                        {
                                            spendUnique[i].spend = parseInt(spendUnique[i].spend) + parseInt(spendAll[j].spend);
                                            spendUnique[i].clicks = parseInt(spendUnique[i].clicks) + parseInt(spendAll[j].clicks);
                                            spendUnique[i].impressions = parseInt(spendUnique[i].impressions) + parseInt(spendAll[j].impressions);
                                            spendUnique[i].actions = parseInt(spendUnique[i].actions) + parseInt(spendAll[j].actions);
                                        }
                                    }
                                }                               
                                $scope.readAccountBudgetforFbNetwork(spendUnique);
                            } else if ($scope.breakdown == "DAILY")
                            {
                                for (i = 0; i < dates.length; i++)
                                {
                                    for (j = 0; j < spendAll.length; j++)
                                    {
                                        if (dates[i].date == spendAll[j].date)
                                        {
                                            dates[i].spend = parseInt(dates[i].spend) + parseInt(spendAll[j].spend);
                                            dates[i].actions = parseInt(dates[i].actions) + parseInt(spendAll[j].actions);
                                            dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendAll[j].impressions);
                                            dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendAll[j].clicks);
                                        }
                                    }
                                }                                
                                $scope.readAccountBudgetforFbNetwork(dates);
                            }
                        }
                );
            }
        };

        $scope.readAccountBudgetforFbNetwork = function (spend)
        {
            var spendTemp = [];
            var obj = {
                "date": 0,
                "spend": 0,
                "impressions": 0,
                "clicks": 0,
                "actions": 0
            };
            spendTemp.push(obj);
            for (i = 0; i < spend.length; i++)
            {
                spendTemp.push(spend[i]);
            }
            var budget = 0;
            var promises = [];           
            for (var i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (var j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function (i, j)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function (response)
                                    {
                                        if (response.appStatus == 0)
                                        {

                                            var resp = response.adaccountbudget;
                                            angular.forEach(resp, function (val, key)
                                            {
                                                angular.forEach(val, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        } else {
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                            }
                                        }
                                    }));

                                }
                            }
                        }(i, j)
                                );
                    }

                }
            }

            $q.all(promises).finally(
                    function ()
                    {
                        if ($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        } else if ($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        } else if ($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        } else if ($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        } else if ($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }
                        var zero_count = 0;
                        var plot = [];
                        $scope.actualright = [];
                        $scope.actualleft = [];
                        $scope.expectedleft = [];
                        $scope.expectedright = [];
                        var expectedclicks = 0;
                        var expectedactions = 0;
                        var expectedimp = 0;
                        var cpc = 0;
                        var cpa = 0;
                        var cpm = 0;                       
                        for (i = 1; i < spendTemp.length; i++)
                        {
                            var obj = {
                                "date": spendTemp[i].date,
                                "region": "actions",
                                "amount": spendTemp[i].actions
                            };
                            plot.push(obj);
                            var obj = {
                                "date": spendTemp[i].date,
                                "region": "spend",
                                "amount": spendTemp[i].spend
                            };
                            plot.push(obj);
                            var _object = {
                                "date": spendTemp[i].date,
                                "name": "budget",
                                "amount": budget
                            };
                            $scope.expectedleft.push(_object);
                            var _object = {
                                "date": spendTemp[i].date,
                                "name": "spend",
                                "amount": spendTemp[i].spend
                            };
                            $scope.actualleft.push(_object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "clicks",
                                "amount": spendTemp[i].clicks
                            };
                            $scope.actualright.push(obj);
                            cpc = spendTemp[i].spend / spendTemp[i].clicks;
                            if (isNaN(cpc)) {
                                expectedclicks = 0;
                            } else {
                                expectedclicks = budget / cpc;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedclicks",
                                "amount": expectedclicks
                            };
                            $scope.expectedright.push(object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "impressions",
                                "amount": spendTemp[i].impressions
                            };
                            $scope.actualright.push(obj);
                            cpm = spendTemp[i].spend / (spendTemp[i].impressions / 1000);
                            if (isNaN(cpm)) {
                                expectedimp = 0;
                            } else {
                                expectedimp = budget / cpm;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedimp",
                                "amount": expectedimp
                            };
                            $scope.expectedright.push(object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "actions",
                                "amount": spendTemp[i].actions
                            };
                            $scope.actualright.push(obj);
                            cpa = spendTemp[i].spend / spendTemp[i].actions;
                            if (isNaN(cpc)) {
                                expectedactions = 0;
                            } else {
                                expectedactions = budget / cpa;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedactions",
                                "amount": expectedactions
                            };
                            $scope.expectedright.push(object);
                        }
                        if ($scope.breakdown == "DAILY")
                        {
                            for (i = 0; i < spendTemp.length; i++)
                            {
                                var d = spendTemp[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', {month: "short"});
                                spendTemp[i].date = d;
                            }
                        }
                        $scope.spendComparison = spendTemp;
                        $scope.plotvalues = plot;
                        $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
                    }
            );

            if ($scope.onloadParentSelection)
            {
                console.log("clearing parent selection advertiser Id");
                $scope.onloadParentSelection = false;
                delete $scope.advertiserId;
            }
        };
        
         $scope.readAccountBudgetforTwNetwork = function (spend)
        {
            var spendTemp = [];
            var obj = {
                "date": 0,
                "spend": 0,
                "impressions": 0,
                "clicks": 0,
                "actions": 0
            };
            spendTemp.push(obj);
            for (i = 0; i < spend.length; i++)
            {
                spendTemp.push(spend[i]);
            }
            var budget = 0;
            var promises = [];            
            for (var i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (var j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        (function (i, j)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {
                                    promises.push(performanceServices.getadaccountbudget($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function (response)
                                    {
                                        if (response.appStatus == 0)
                                        {

                                            var resp = response.adAccountBudget;
                                            angular.forEach(resp, function (val, key)
                                            {
                                                angular.forEach(val, function (value2, key2)
                                                {
                                                    budget = budget + parseInt(value2.budget);
                                                });
                                            });
                                        } else {
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
                                                $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                                       $scope.errorMsg = response.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.errorMessage;
                                                }
                                            }
                                        }
                                    }));

                                }
                            }
                        }(i, j)
                                );
                    }

                }
            }

            $q.all(promises).finally(
                    function ()
                    {
                        if ($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        } else if ($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        } else if ($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        } else if ($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        } else if ($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }                       
                        var plot = [];
                        $scope.actualright = [];
                        $scope.actualleft = [];
                        $scope.expectedleft = [];
                        $scope.expectedright = [];
                        var expectedclicks = 0;
                        var expectedactions = 0;
                        var expectedimp = 0;
                        var cpc = 0;
                        var cpa = 0;
                        var cpm = 0;                        
                        for (i = 1; i < spendTemp.length; i++)
                        {
                            var obj = {
                                "date": spendTemp[i].date,
                                "region": "actions",
                                "amount": spendTemp[i].actions
                            };
                            plot.push(obj);
                            var obj = {
                                "date": spendTemp[i].date,
                                "region": "spend",
                                "amount": spendTemp[i].spend
                            };
                            plot.push(obj);
                            var _object = {
                                "date": spendTemp[i].date,
                                "name": "budget",
                                "amount": budget
                            };
                            $scope.expectedleft.push(_object);
                            var _object = {
                                "date": spendTemp[i].date,
                                "name": "spend",
                                "amount": spendTemp[i].spend
                            };
                            $scope.actualleft.push(_object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "clicks",
                                "amount": spendTemp[i].clicks
                            };
                            $scope.actualright.push(obj);
                            cpc = spendTemp[i].spend / spendTemp[i].clicks;
                            if (isNaN(cpc)) {
                                expectedclicks = 0;
                            } else {
                                expectedclicks = budget / cpc;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedclicks",
                                "amount": expectedclicks
                            };
                            $scope.expectedright.push(object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "impressions",
                                "amount": spendTemp[i].impressions
                            };
                            $scope.actualright.push(obj);
                            cpm = spendTemp[i].spend / (spendTemp[i].impressions / 1000);
                            if (isNaN(cpm)) {
                                expectedimp = 0;
                            } else {
                                expectedimp = budget / cpm;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedimp",
                                "amount": expectedimp
                            };
                            $scope.expectedright.push(object);
                            var obj = {
                                "date": spendTemp[i].date,
                                "name": "actions",
                                "amount": spendTemp[i].actions
                            };
                            $scope.actualright.push(obj);
                            cpa = spendTemp[i].spend / spendTemp[i].actions;
                            if (isNaN(cpc)) {
                                expectedactions = 0;
                            } else {
                                expectedactions = budget / cpa;
                            }
                            var object = {
                                "date": spendTemp[i].date,
                                "name": "expectedactions",
                                "amount": expectedactions
                            };
                            $scope.expectedright.push(object);
                        }
                        if ($scope.breakdown == "DAILY")
                        {
                            for (i = 0; i < spendTemp.length; i++)
                            {
                                var d = spendTemp[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', {month: "short"});
                                spendTemp[i].date = d;
                            }
                        }
                        $scope.spendComparison = spendTemp;
                        $scope.plotvalues = plot;
                        $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
                    }
            );
        };


        //CALCULATING DATES FOR NETWORK SELECTION WHEN NO DATE SELECTED
        $scope.calculateDatesNetwork = function (from, to)
        {
            var totalBudget = 0;
            var cpa = 0;
            var cpm = 0;
            var cpc = 0;
            var expectedclicks = 0;
            var expectedimp = 0;
            var expectedactions = 0;
            $scope.expectedright = [];
            $scope.actualright = [];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            $scope.spendComparison1 = [];
            $scope.graphPlotted = false;
            $scope.currentDate = new Date(from);
            $scope.toDateNumber = new Date($scope.toDate).getDate();
            $scope.toMonth = new Date($scope.toDate).getMonth() + 1;
            $scope.toYear = new Date().getFullYear();
            $scope.fromDateNumber = new Date($scope.fromDate).getDate();
            $scope.fromMonth = new Date($scope.fromDate).getMonth() + 1;
            $scope.fromYear = new Date($scope.fromDate).getFullYear();
            $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
            $scope.yearDiff = $scope.toYear - $scope.fromYear;
            $scope.dateArray = [];
            while ($scope.currentDate <= new Date(to)) {
                $scope.dateArray.push($scope.currentDate.toISOString().slice(0, 10));
                var obj = {
                    'date': $scope.currentDate.toISOString().slice(0, 10),
                    'spend': 0,
                    'impressions': 0,
                    'clicks': 0,
                    'actions': 0
                };
                $scope.spendComparison1.push(obj);
                $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                $scope.dateDiff = $scope.dateDiff + 1;
            }
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        if ($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('spenddetails'))
                            {
                                for (l = $scope.spendComparison1.length - 1; l >= 0; l--)
                                {
                                    for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].spenddetails.length; k++)
                                    {
                                        if ($scope.spendComparison1[l].date == $scope.networkmaparray[i].networkDetails[j].spenddetails[k].date)
                                        {
                                            $scope.spendComparison1[l].spend = $scope.spendComparison1[l].spend + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].spend;
                                            $scope.spendComparison1[l].impressions = $scope.spendComparison1[l].impressions + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].impressions;
                                            $scope.spendComparison1[l].clicks = $scope.spendComparison1[l].clicks + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].clicks;
                                            $scope.spendComparison1[l].actions = $scope.spendComparison1[l].actions + $scope.networkmaparray[i].networkDetails[j].spenddetails[k].actions;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (i = 0; i < $scope.networkmaparray.length; i++)
            {
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                    {
                        if ($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                        {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('budgetdetails'))
                            {
                                totalBudget = totalBudget + parseInt($scope.networkmaparray[i].networkDetails[j].budgetdetails);
                            }
                        }

                    }
                }
            }
            for (i = 0; i < $scope.spendComparison1.length; i++)
            {
                var d = $scope.spendComparison1[i].date;
                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', {month: "short"});
                $scope.spendComparison1[i].date = d;
            }
            //$scope.spendComparisonOnLoad = $scope.spendComparison;  
            var plot = []
            for (i = 1; i < $scope.spendComparison1.length; i++) {
                var obj = {
                    "date": $scope.spendComparison1[i].date,
                    "region": "actions",
                    "amount": $scope.spendComparison1[i].actions
                };
                plot.push(obj);
                var object = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "spend",
                    "amount": $scope.spendComparison1[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "budget",
                    "amount": totalBudget
                };
                $scope.expectedleft.push(_object);
                cpc = $scope.spendComparison1[i].spend / $scope.spendComparison1[i].clicks;
                if (isNaN(cpc)) {
                    expectedclicks = 0;
                } else {
                    expectedclicks = totalBudget / cpc;
                }
                var _obj = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "expectedclicks",
                    "amount": expectedclicks
                }
                var _act = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "clicks",
                    "amount": $scope.spendComparison1[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpm = $scope.spendComparison1[i].spend / ($scope.spendComparison1[i].impressions / 1000);
                if (isNaN(cpm)) {
                    expectedimp = 0;
                } else {
                    expectedimp = totalBudget / cpm;
                }
                var _obj = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "expectedimp",
                    "amount": expectedimp
                }
                var _act = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "impressions",
                    "amount": $scope.spendComparison1[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = $scope.spendComparison1[i].spend / $scope.spendComparison1[i].actions;
                if (isNaN(cpa)) {
                    expectedactions = 0;
                } else {
                    expectedactions = totalBudget / cpa;
                }
                var _obj = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "expectedactions",
                    "amount": expectedactions
                }
                var _act = {
                    "date": $scope.spendComparison1[i].date,
                    "name": "actions",
                    "amount": $scope.spendComparison1[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date": $scope.spendComparison1[i].date,
                    "region": "spend",
                    "amount": $scope.spendComparison1[i].spend
                };
                plot.push(obj);
            }            
            $scope.spendComparison = $scope.spendComparison1;
            $scope.plotvalues = plot;
            $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);

        };

        $scope.readadaccountinsightsforTwNetwork = function () {
            if (($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == "")) {
                var promises = [];
                var spend = [];
                for (i = 0; i < $scope.dateArray.length; i++) {
                    var obj = {
                        "date": $scope.dateArray[i],
                        "spend": 0,
                        "actions": 0,
                        "clicks": 0,
                        "impressions": 0
                    };
                    spend.push(obj);
                }

                for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            (function (i, j) {
                                if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')) {
                                        promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,'DAILY',appSettings.twNetwork,true).then(function (resp) {
                                            if (resp.appStatus == 0) {
                                                resp = resp.adAccountInsights;
                                                angular.forEach(resp, function (val, key) {
                                                    angular.forEach(val, function (val2, key2) {
                                                        angular.forEach(val2, function (val3, key3) {
                                                            for (j = 0; j < $scope.dateArray.length; j++) {
                                                                var date;
                                                                if((Object.keys(val2)[0]).length == 10){
                                                                    date = $filter('date')(((Object.keys(val2)[0]) * 1000), 'yyyy-MM-dd'); 
                                                                }
                                                                else{
                                                                  date = $filter('date')((Object.keys(val2)[0]), 'yyyy-MM-dd');   
                                                                }                                                                                                                                       
                                                                if ($scope.dateArray[j] == date) {
                                                                    for (l = 0; l < spend.length; l++) {
                                                                        if ($scope.dateArray[j] == spend[l].date) {
                                                                            spend[l].spend = spend[l].spend + val3.spend;
                                                                            spend[l].impressions = spend[l].impressions + val3.impressions;
                                                                            spend[l].clicks = spend[l].clicks + val3.clicks;
                                                                            spend[l].actions = spend[l].actions + val3.callToAction;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        });
                                                    });
                                                });

                                            } else {
                                                if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
													
													
					console.log("readadaccountsinsights for TWITTER");
					console.log($scope.networkmaparray);
					console.log(resp.errorMessage);
					$scope.errors.push({"category":"networkLevel","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"errorMsg":resp.errorMessage});
					console.log($scope.errors);

                                                   $scope.message = 'No Graph';
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                            }
                                        }));
                                    }
                                }
                            })(i, j);
                        }
                    }
                }
                $q.all(promises).finally(
                        function () {
                            $scope.calculateDatesNetwork($scope.fromDate, $scope.toDate);
                        });
            } 
            else//FROM TO SELECTED
            {
                var promises = [];
                var spendUnique = [];
                var spendAll = [];
                var flag = 0;
                var dates = [];               
                if ($scope.breakdown == "DAILY")
                {
                    var currentDate = new Date($scope.UTCFromDate);
                    while (currentDate <= new Date($scope.UTCToDate))
                    {
                        var d = new Date(currentDate)
                        var currentDate1 = d.getFullYear() + '-' + ((d.getMonth() + 1) > 9 ? (d.getMonth() + 1) : "0" + (d.getMonth() + 1)) + '-' + (d.getDate() > 9 ? d.getDate() : "0" + d.getDate());
                        var obj = {
                            "date": currentDate1,
                            "spend": 0,
                            "impressions": 0,
                            "clicks": 0,
                            "actions": 0
                        };
                        dates.push(obj);
                        currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                    }
                }
                for (i = 0; i < $scope.networkmaparray.length; i++)
                {
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                    {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                        {
                            (function (i, j)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                    {
                                        promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.twNetwork,false).then(function (resp) {
                                            if (resp.appStatus == 0) {
                                                var resp = resp.adAccountInsights;
                                                angular.forEach(resp, function (val, key) {
                                                    angular.forEach(val, function (val2, key2) {
                                                        angular.forEach(val2, function (val3, key3) {
                                                            if ($scope.breakdown != "DAILY") {
                                                                actions = 0;
                                                                var keyValue21 = key3.split('_').join(' ');
                                                                var obj = {
                                                                    "date": keyValue21,
                                                                    "spend": 0,
                                                                    "impressions": 0,
                                                                    "clicks": 0,
                                                                    "actions": 0
                                                                }
                                                                for (i = 0; i < spendUnique.length; i++)
                                                                {
                                                                    if (obj.date == spendUnique[i].date)
                                                                    {
                                                                        flag = 1;
                                                                    }
                                                                }
                                                                if (spendUnique.length == 0 || flag == 0)
                                                                {
                                                                    spendUnique.push(obj);
                                                                }
                                                                var obj2 = {
                                                                    "date": keyValue21,
                                                                    "spend": val3.spend,
                                                                    "impressions": val3.impressions,
                                                                    "clicks": val3.clicks,
                                                                    "actions": val3.callToAction
                                                                };
                                                                spendAll.push(obj2);
                                                            } else if ($scope.breakdown == "DAILY") {
                                                                var d;
                                                                if(key3.length == 10)
                                                                {
                                                                  d = $filter('date')(key3 * 1000, 'yyyy-MM-dd');  
                                                                }
                                                                else
                                                                {
                                                                   d = $filter('date')(key3, 'yyyy-MM-dd');  
                                                                }                                                                
                                                                for (i = 0; i < dates.length; i++)
                                                                {
                                                                    if (dates[i].date == d)
                                                                    {

                                                                        var obj = {
                                                                            "date": dates[i].date,
                                                                            "spend": val3.spend,
                                                                            "impressions": val3.impressions,
                                                                            "clicks": val3.clicks,
                                                                            "actions":val3.callToAction
                                                                        };
                                                                        spendAll.push(obj);
                                                                    } else
                                                                    {
                                                                        var obj = {
                                                                            "date": dates[i].date,
                                                                            "spend": 0,
                                                                            "impressions": 0,
                                                                            "clicks": 0,
                                                                            "actions": 0
                                                                        };
                                                                        spendAll.push(obj);
                                                                    }
                                                                }
                                                            }
                                                        });
                                                    });
                                                });
                                            } else {
                                                if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                }
                                            }
                                        }));
                                    }
                                }
                            }(i, j)
                                    )
                        }
                    }
                }
                $q.all(promises).finally(
                        function () {
                            if ($scope.breakdown != "DAILY")
                            {
                                for (i = 0; i < spendUnique.length; i++)
                                {
                                    for (j = 0; j < spendAll.length; j++)
                                    {
                                        if (spendUnique[i].date == spendAll[j].date)
                                        {
                                            spendUnique[i].spend = parseInt(spendUnique[i].spend) + parseInt(spendAll[j].spend);
                                            spendUnique[i].clicks = parseInt(spendUnique[i].clicks) + parseInt(spendAll[j].clicks);
                                            spendUnique[i].impressions = parseInt(spendUnique[i].impressions) + parseInt(spendAll[j].impressions);
                                            spendUnique[i].actions = parseInt(spendUnique[i].actions) + parseInt(spendAll[j].actions);
                                        }
                                    }
                                }                                
                                $scope.readAccountBudgetforTwNetwork(spendUnique);
                            } else if ($scope.breakdown == "DAILY")
                            {
                                for (i = 0; i < dates.length; i++)
                                {
                                    for (j = 0; j < spendAll.length; j++)
                                    {
                                        if (dates[i].date == spendAll[j].date)
                                        {
                                            dates[i].spend = parseInt(dates[i].spend) + parseInt(spendAll[j].spend);
                                            dates[i].actions = parseInt(dates[i].actions) + parseInt(spendAll[j].actions);
                                            dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendAll[j].impressions);
                                            dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendAll[j].clicks);
                                        }
                                    }
                                }                                
                                $scope.readAccountBudgetforTwNetwork(dates);
                            }
                        }
                );
            }
        };
        $scope.fillDropDowns = function()
        { 
            var promises = [];
            $scope.wholeParentArray = [];
            $scope.wholeParentArray1= [];
            var usernetworkMapId;
            $scope.networkDropDown = [];
            
            $scope.arr1 = [];
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                var obj = {
                    "advertiserName":$scope.networkmaparray[i].advertiserName,
                    "advertiserId":$scope.networkmaparray[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
            }          
            if($scope.userRole == "Account")
            {
                for(i=0;i<$scope.allnetworksarray.length;i++)
                {
                    var obj = {
                        "networkId":$scope.allnetworksarray[i].networkId,
                        "networkName":$scope.allnetworksarray[i].networkName,
                        "networkURL":$scope.allnetworksarray[i].networkUrl
                    };
                    if(obj.networkURL == appSettings.fbNetwork || obj.networkURL == appSettings.twNetwork)
                    {
                        $scope.networkDropDown.push(obj);
                    }
                }
                for(i=0;i<$scope.networkmaparray.length;i++)
                {       
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {                     
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            (function(i,j)
                            {
                                
                                    if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork || $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                    {
                                        promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.networkmaparray[i].advertiserId).then(function(response)
                                        {
                                            if (response.appStatus == '0') {// success
                                                $scope.campaigndetails = response.parentCampaigns;
                                                for (var k = 0; k < $scope.campaigndetails.length; k++){
                                                    var _obj = {
                                                        "id": $scope.campaigndetails[k].parentCampaignId,
                                                        "name": $scope.campaigndetails[k].parentCampaignName,
                                                        "type": "parent",
                                                        "networkArray":[{
                                                        "userNetworkMapId":$scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkURL":$scope.networkmaparray[i].networkDetails[j].networkURL,
                                                        "networkId":$scope.networkmaparray[i].networkDetails[j].networkId,
                                                        "netwrokName":$scope.networkmaparray[i].networkDetails[j].networkName
                                                        }]                                                        
                                                    };
                                                    usernetworkMapId=$scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                                                    $scope.wholeParentArray1.push(_obj);
                                                    
                                                    if ($scope.arr1.indexOf(_obj.id) == - 1) {
                                                        $scope.arr1.push(_obj.id);                                                        
                                                        $scope.wholeParentArray.push(_obj);                                                      
                                                     } 
                                                     else{
                                                        angular.forEach($scope.wholeParentArray,function(val,key){
                                                           if(val.id == _obj.id){                                                              
                                                              val.networkArray[1] ={
                                                        "userNetworkMapId":$scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkURL":$scope.networkmaparray[i].networkDetails[j].networkURL,
                                                        "networkId":$scope.networkmaparray[i].networkDetails[j].networkId,
                                                        "networkName":$scope.networkmaparray[i].networkDetails[j].networkName
                                                        };
                                                             
                                                           }
                                                        });                                                           
                                                        }
                                                    }
                                                }
                                            else
                                            {
                                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                                    }
                                            }
                                        }));
                                    }
//                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){                        
                        $scope.fetchallchildandpush();
                    });
        };
        
        $scope.fetchallchildandpush = function()
        {
            console.log("fetch all child and push");
            var promises = [];
            var count = 0;
            $scope.wholechildArray = [];
            for(i=0;i<$scope.wholeParentArray.length;i++)
            {  
                for(j=0;j<$scope.wholeParentArray[i].networkArray.length;j++)
                {
                    (function(i,j)
                    {
                        if($scope.wholeParentArray[i].networkArray[j].networkURL == appSettings.fbNetwork)
                        {
                            promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].networkArray[j].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) {
                                if (response.appStatus == '0') {
                                  //  $rootScope.progressLoader = "none";
                                    $scope.childCampaigns = response.adcampaigns;
                                    var count = 0;
                                    angular.forEach($scope.childCampaigns, function (value, key) {
                                        var JsonObj = $scope.childCampaigns[key];
                                        var array = [];
                                        for (var a in JsonObj) {
                                            if (JsonObj.hasOwnProperty(a) && !isNaN(+a)) {
                                                array[+a] = JsonObj[a];
                                                var _obj = {
                                                    "id": array[+a].campaignId,
                                                    "name": array[+a].campaignDetails.name,
                                                    "type": "child",
                                                    "parentid": $scope.wholeParentArray[i].id,
                                                    "userNetworkMapId": $scope.wholeParentArray[i].networkArray[j].userNetworkMapId,
                                                    "networkURL":$scope.wholeParentArray[i].networkArray[j].networkURL
                                                };
                                                count++;
                                                $scope.wholechildArray.push(_obj);
                                            }
                                        }
                                    });
                                }
                                else {
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    }
                                    else
                                    {
                                       $rootScope.progressLoader = "none";
                                        $scope.editAdsetErrorMsg = 'block';
                                        if (response.networkError != '' && response.networkError != undefined)
                                        {
                                            if (response.networkError.message != '' && response.networkError.message != undefined)
                                            {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                            }
                                           else
                                            {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                        }
                                        else 
                                        {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                        }
                                    }
                                }
                            }));
                        }
                        else{
                            promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].networkArray[j].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork,undefined).then(function (response) {
                                if (response.appStatus == '0') {
                                    $scope.childCampaigns = response.campaign;
                                    var count = 0;
                                    for(var k=0;k<$scope.childCampaigns.length;k++){
                                        var JsonObj = $scope.childCampaigns[k];
                                        var array = [];
                                        for (var a in JsonObj) { 
                                            if (JsonObj.hasOwnProperty(a)) {
                                                array[+a] = JsonObj[a]; 
                                                var _obj = {
                                            "id": array[+a].twCampaignId,
                                            "name": array[+a].twCampaignDetails.name,
                                            "type": "child",
                                            "parentid": $scope.wholeParentArray[i].id,
                                            "userNetworkMapId": $scope.wholeParentArray[i].networkArray[j].userNetworkMapId,
                                            "networkURL":$scope.wholeParentArray[i].networkArray[j].networkURL
                                        };
                                        count++;
                                        $scope.wholechildArray.push(_obj);
                                    }
                                }
                            };
                        } 
                        else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                }
                        }
                    }));
                }                
                })(i,j);
                        }
            }            
            $q.all(promises).finally(
                    function(){
                        $scope.wholeParentArrayOnLoad = $scope.wholeParentArray;                       
                        $scope.wholeChildArrayOnLoad = $scope.wholechildArray;                        
                    });
        };
         $scope.fetchallnetworkchildandpush = function()
        {
            console.log("fetch all child and push");
            var promises = [];            
            $scope.wholechildArray = [];         
            for(i=0;i<$scope.wholeParentArray.length;i++)
            {  
                for(j=0;j<$scope.wholeParentArray[i].networkArray.length;j++)
                {
                    (function(i,j)
                    {
                        if($scope.wholeParentArray[i].networkArray[j].networkURL == appSettings.fbNetwork){                        
                    promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].networkArray[j].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) {
                        if (response.appStatus == '0') {
                           // $rootScope.progressLoader = "none";
                            $scope.childCampaigns = response.adcampaigns;
                            var count = 0;
                            angular.forEach($scope.childCampaigns, function (value, key) {
                                var JsonObj = $scope.childCampaigns[key];
                                var array = [];
                                for (var a in JsonObj) {
                                    if (JsonObj.hasOwnProperty(a) && !isNaN(+a)) {
                                        array[+a] = JsonObj[a];
                                        var _obj = {
                                            "id": array[+a].campaignId,
                                            "name": array[+a].campaignDetails.name,
                                            "type": "child",
                                            "parentid": $scope.wholeParentArray[i].id,
                                            "userNetworkMapId": $scope.wholeParentArray[i].networkArray[j].userNetworkMapId,
                                            "networkURL":$scope.wholeParentArray[i].networkArray[j].networkURL
                                        };
                                        count++;
                                        $scope.wholechildArray.push(_obj);
                                    }
                                }
                            });
                        } else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
								console.log("No campaign error");
	                                           $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                }
                        }
                    }));
                }
                else{ //if($scope.wholeParentArray.networkArray[j].networkURL== appSettings.twNetwork){
                    promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].networkArray[j].userNetworkMapId,$scope.wholeParentArray1[i].id,appSettings.twNetwork,undefined).then(function (response) {
                        if (response.appStatus == '0') {
                          //  $rootScope.progressLoader = "none";
                            $scope.childCampaigns = response.campaign;                            
                            var count = 0;
                            for(var k=0;k<$scope.childCampaigns.length;k++){
                                var JsonObj = $scope.childCampaigns[k];                                
                                var array = [];
                                for (var a in JsonObj) {                                    
                                    if (JsonObj.hasOwnProperty(a)) {
                                        array[+a] = JsonObj[a];                                       
                                        var _obj = {
                                            "id": array[+a].twCampaignId,
                                            "name": array[+a].twCampaignDetails.name,
                                            "type": "child",
                                            "parentid": $scope.wholeParentArray[i].id,
                                            "userNetworkMapId": $scope.wholeParentArray[i].networkArray[j].userNetworkMapId,
                                            "networkURL":$scope.wholeParentArray[i].networkArray[j].networkURL
                                        };
                                        count++;
                                        $scope.wholechildArray.push(_obj);
                                    }
                                }
                            };
                        } 
                        else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
								          console.log("No campaign error");
	                                        $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                                }
                        }
                    }));
                }                
                })(i,j);
                        }
            }         
            
        };
        $scope.plotlinechart = function (val) 
        {
            if(val.length == 2)
            {
                var val2 = val;
                angular.forEach(val2,function(value,key)
                {                    
                    val.push(value);
                });
            }
            else
            {
                for(i=0;i<val.length;i++)
                {
                    val[i].amount = Math.round(val[i].amount);
                }              
                $scope.checkCurrencyCode($scope.currency);                
                var sampleData = val;
                $("#sampleChart").empty();
                var options = {
                id: "1",
                container: {
                    id: "#sampleChart",
                    title: " ",
                    showDataLabels: 'no',
                    titlePos: 24,
                    contextBrush: "no",
                    width: 3400,
                    height: 340
                },
                markerRadius: 3,
                linewidth: 10,
                axisRange:
                    {
                  y:
                  {
                      min: 0
                  }
                    
                },
                bindings: {
                    x: "date",
                    y: "amount",
                    category: "region",
                    marker: ''
                },
                labels: {
                    x: " ",
                    y: " "
                },
                colors: {"actions":"rgb(229,87,134)", "spend": "rgb(144,211,205)"},
                scaling: {
                    x: 4,
                    y: 1
                },
                 ticks: {
                    x: 7,
                    y: 7
                },
                tickerAngle: {
                    x: 0
                },
                legend: {
                    position: 'right', //used available => right || bottom
                    height: 18,
                    width: 60, //considered while position is bottom & right (optional for bottom) * DEFAULT: daWidth 
                    itemsPerRow: 1, //used 1 => vertical(right); >1 => horizontal(bottom)
                    itemDimension: 10
                },
                tooltip: {
                    width: 50,
                    bindings: [{
                        label: $scope.currencyCode,
                        bindWith: "amount"
                    }],
                }
            };

                var bar_graph = cviz.widget.LineChart.Runner(options).graph();

                bar_graph.render(sampleData);
                for (var i = 0; ; i++)
                {
                   var a = document.getElementById("sampleChart").children[0];
                   if (document.getElementById("sampleChart").children[0].children[0].children[4].children[i].hasChildNodes())
                            {    
                                document.getElementById("sampleChart").children[0].children[0].children[4].children[i].innerHTML = "<line x1='-200' y1='0' x2='350%' y2='0'></line>";
                            }else
                            {
                                 break;
                            }
                            
                             document.getElementById("sampleChart").children[0].children[0].children[3].setAttribute("transform","translate(10,320)");              
                }
            }
        };
        
        $scope.selectadvertiser = function (){
            $rootScope.progressLoader = "block";            
           // $scope.graphPlotted = false;
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            { 
                $scope.selectedvalue = '';
                $scope.networkId = '';
                $scope.wholeParentArray = [];
                $scope.networkDropDown = [];                
                $window.localStorage.setItem("advertiserId", $scope.advertiserId);
                performanceServices.fetchparentcampaignsbyadvertiser($scope.advertiserId).then(function (response){
                    if (response.appStatus == '0') {// success
                        for (i = 0; i < $scope.networkmaparray.length; i++)
                        {
                          if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){ 
                             if($scope.advertiserId == $scope.networkmaparray[i].advertiserId){
                              for(var k=0;k<$scope.networkmaparray[i].networkDetails.length;k++){
                                  var obj = {
                                      "networkName":$scope.networkmaparray[i].networkDetails[k].networkName,
                                      "networkURL":$scope.networkmaparray[i].networkDetails[k].networkURL,
                                      "networkId":$scope.networkmaparray[i].networkDetails[k].networkId
                                  }
                                  $scope.networkDropDown.push(obj);
                              }
                          }
                      }
                  }
                  $scope.campaigndetails = response.parentCampaigns;                 
                        for (var i = 0; i < $scope.campaigndetails.length; i++){
                            var _obj = {
                                "id": $scope.campaigndetails[i].parentCampaignId,
                                "name": $scope.campaigndetails[i].parentCampaignName,
                                "type": "parent"
                            };
                            if($scope.networkDropDown.length != 0){
                                $scope.wholeParentArray.push(_obj);
                            }
                        }
					
						
                      //angular.forEach($scope.wholeParentArray, function (val, key){
                            $scope.fetchChildAndPush();
                        //});						
						  
					
					             
						
						
					//	$scope.fetchChildAndPush();
                        $scope.checkNetworkforadvertiser($scope.advertiserId);
                        for(i = 0; i<$scope.networkmaparray.length; i++){
                            if($scope.advertiserId == $scope.networkmaparray[i].advertiserId){
                                if($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                                    for(j = 0;j<$scope.networkmaparray[i].networkDetails.length; j++){
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("spenddetails")){
                                                $scope.filterPlot($scope.advertiserId);
                                            }
                                            else{                                               
                                                $scope.plotvalues=[];
                                                $scope.expectedleft = [];
                                                $scope.expectedright = [];
                                                $scope.actualleft = [];
                                                $scope.actualright = [];
                                                $scope.spendComparison = []; 
                                                $scope.Isvisible=false;
                                                $scope.textbx = "";
                                                $scope.btnText = 'Calculate';
                                                $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft, $scope.actualright,'');
                                                $scope.graphPlotted = false;
                                               // $rootScope.progressLoader = "none";                                                
                                            }
//                                        });
                                    }
                                }
                                else{
                                    $scope.plotvalues=[];
                                    $scope.expectedleft = [];
                                    $scope.expectedright = [];
                                    $scope.actualleft = [];
                                    $scope.actualright = [];
                                    $scope.spendComparison = [];
                                    $scope.Isvisible=false;
                                    $scope.textbx = "";
                                    $scope.btnText = 'Calculate';
                                    $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft, $scope.actualright,'');
                                    $scope.graphPlotted = false;
                                    $rootScope.progressLoader = "none";                                  
                                }
                            }   
                        }
                    }
                    else {// failed
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
						
						
						
											console.log("PARENT CAMPAIGN");
											console.log($scope.networkmaparray);
											console.log(resp.errorMessage);
											$scope.errors.push({"category":"parentCampaign","network":$scope.networkmaparray,"advertiserID":$scope.advertiserId,"errorMsg":resp.errorMessage});
											console.log($scope.errors);
											
											
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
                        }
                    }
                });
				//console.log("ERROR1");
					//$scope.handlingErrors();
            }            
            else{                
                if(($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == ""))
                {
                    $scope.Isvisible=false;
                    $scope.textbx = "";
                    $scope.btnText = 'Calculate';
                    $scope.networkId = "";
                    $scope.lineplotted = true;
                    $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                    $scope.wholechildArray = $scope.wholeChildArrayOnLoad;
                    $scope.plotvalues = $scope.plotvaluesOnLoad;
                    $scope.expectedleft = $scope.expectedleftOnLoad;
                    $scope.expectedright = $scope.expectedrightOnLoad;
                    $scope.actualleft = $scope.actualleftOnLoad ;
                    $scope.actualright = $scope.actualrightOnLoad;
                    $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                }
                else
                {
                    if(($scope.from != undefined || $scope.from != "") && ($scope.to != undefined || $scope.to != ""))
                    {
                        $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                        $scope.wholechildArray = $scope.wholeChildArrayOnLoad;
                        $scope.fromAndToChanged();
                    }
                }
            }
			      //   console.log("ERROR2");
				//	$scope.handlingErrors();
            if($scope.advertiserId == "")
            {
                $scope.selectedvalue = "Select Campaign";
            }
			
        };
        
        $scope.selectnetwork = function (obj)
        {            
            $rootScope.progressLoader = "block";
            $scope.userRole = $window.localStorage.getItem("role"); 
            $scope.textbx = "";
            $scope.btnText = 'Calculate';
            $scope.Isvisible = false;
            if($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
            {
                $scope.advertiserId = $window.localStorage.getItem("advertiserId");
            }            
            if($scope.networkId == "" || $scope.networkId == undefined)
            {
                $scope.lineplotted = true;
                if (($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == ""))
                {
                    if ($scope.advertiserId == "" || $scope.advertiserId == undefined)
                    {
                        $scope.breakdown = "DAILY";
                        datedifference = 7;
                        $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                        $scope.wholechildArray = $scope.wholeChildArrayOnLoad;
                        $scope.plotvalues = $scope.plotvaluesOnLoad;
                        $scope.expectedleft = $scope.expectedleftOnLoad;
                        $scope.expectedright = $scope.expectedrightOnLoad;
                        $scope.actualleft = $scope.actualleftOnLoad;
                        $scope.actualright = $scope.actualrightOnLoad;                        
                        $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
                    }
                    else
                    {
                        $scope.selectadvertiser();
                    }
                }
                else
                {
                    if (($scope.from != undefined || $scope.from != "") && ($scope.to != undefined || $scope.to != ""))
                    {
                        if ($scope.advertiserId == "" || $scope.advertiserId == undefined)
                        {
                            $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                            $scope.wholechildArray = $scope.wholeChildArrayOnLoad;
                            $scope.fromAndToChanged();
                        } else
                        {
                            $scope.selectadvertiser();
                        }

                    }
                }                
                
            }
            if ($scope.networkId != "" && $scope.networkId != undefined)
            {
                if ($scope.advertiserId == "" || $scope.advertiserId == undefined)
                {
                    $scope.selectedvalue = '';
                    $scope.wholeParentArray1 = $scope.wholeParentArrayOnLoad;
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    var networkURL;
                    for (var k = 0; k < $scope.wholeParentArray1.length; k++)
                    {
                        for (i = 0; i < $scope.wholeParentArray1[k].networkArray.length; i++)
                        {
                            if ($scope.wholeParentArray1[k].networkArray[i].networkId == $scope.networkId)
                            {
                                var _obj = {
                                    "id": $scope.wholeParentArray1[k].id,
                                    "name": $scope.wholeParentArray1[k].name,
                                    "type": "parent",
                                    "networkArray": [{
                                            "userNetworkMapId": $scope.wholeParentArray1[k].networkArray[i].userNetworkMapId,
                                            "networkURL": $scope.wholeParentArray1[k].networkArray[i].networkURL,
                                            "networkId": $scope.wholeParentArray1[k].networkArray[i].networkId,
                                            "networkName": $scope.wholeParentArray1[k].networkArray[i].netwrokName
                                        }]
                                };
                                networkURL = $scope.wholeParentArray1[k].networkArray[i].networkURL;
                                $scope.wholeParentArray.push(_obj);
                            }
                        }
                    }
                    $scope.fetchallnetworkchildandpush();
                    if (networkURL == appSettings.fbNetwork)//FB NETWORK
                    {
                        $scope.lineplotted = true;                        
                        $scope.readadaccountinsightsforFbNetwork();
                    } else//TWITTER NETWORK
                    {
                        $scope.lineplotted = false;
                        if($scope.status == true){
                            $scope.kpi = 'clicks';
                            $scope.legentText = "clicks";
                        }
                        $scope.readadaccountinsightsforTwNetwork();
                    }
                } 
                else
                {
                    var networkURL;
                    var userNetworkId;
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    $scope.selectedvalue = '';
                    $window.localStorage.setItem("advertiserId", $scope.advertiserId);
                    performanceServices.fetchparentcampaignsbyadvertiser($scope.advertiserId).then(function (response) {
                        if (response.appStatus == '0') {
                            $scope.campaigndetails = response.parentCampaigns;
                            for (var i = 0; i < $scope.campaigndetails.length; i++) {
                                var _obj = {
                                    "id": $scope.campaigndetails[i].parentCampaignId,
                                    "name": $scope.campaigndetails[i].parentCampaignName,
                                    "type": "parent"
                                };
                                $scope.wholeParentArray.push(_obj);
                            }
                            angular.forEach($scope.wholeParentArray, function (val, key)
                            {
                                for (i = 0; i < $scope.networkmaparray.length; i++)
                                {
                                    if ($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                                    {
                                        if ($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                                        {
                                            for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                                            {
                                                (function (i, j)
                                                {
                                                    if ($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId) {
                                                        networkURL = $scope.networkmaparray[i].networkDetails[j].networkURL;
                                                        userNetworkId = $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
														$scope.networkURL = networkURL;
														$scope.userNetworkId = userNetworkId;
                                                    }
                                                })(i, j);
                                            }
                                        }
                                    }
                                }
                               
                                if (networkURL == appSettings.twNetwork){
                                   $scope.lineplotted = false;
                                if($scope.status == true){
                                        $scope.kpi = 'clicks';
                                        $scope.legentText = "clicks";
                                } 
                              }
                              else{
                                 $scope.lineplotted = true; 
                              }
                                    
                            });
							 $scope.fetchNetworkChildAndPush($scope.wholeParentArray,$scope.networkURL , $scope.userNetworkId);
                            $scope.networkFilterPlot($scope.advertiserId, networkURL, userNetworkId);
                        }else{
							
											console.log("FETCH PARENT ");
											console.log($scope.networkmaparray);
											console.log(resp.networkError.message);
											$scope.errors.push({"category":"parentCampaign","networkAc":$scope.networkmaparray,"advertiserID":$scope.advertiserId,"errorMsg":resp.networkError.message});
											console.log($scope.errors);
										
												$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
							
						}
						
                    });
                  //  $rootScope.progressLoader = "none";
                }
            }
			//console.log("Error2");
			// $scope.handlingErrors();
        };
            
        
        
        $scope.filterPlot = function(advertiserId)
        {   
            $scope.Isvisible=false;            
            $scope.textbx = "";
            $scope.btnText = 'Calculate';
            var spend = [];
            var budget = 0;
            var userNetMapId;  
            var expectedclicks = 0;
            var expectedactions = 0;
            var expectedimp =0;
            var cpa = 0;
            var cpc = 0;
            var cpm = 0;  
            $scope.expectedright = [];
            $scope.actualright = [];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            if(($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == ""))
            {
                $scope.currentDate = new Date($scope.fromDate);
                $scope.dateArray = [];
                while ($scope.currentDate <= new Date($scope.toDate))
                {
                    $scope.dateArray.push($scope.currentDate.toISOString().slice(0,10));
                    var obj = {
                        'date':$scope.currentDate.toISOString().slice(0,10),
                        'spend':0,
                        'impressions':0,
                        'clicks':0,
                        'actions':0
                    };
                    spend.push(obj);                    
                    $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }               
                for(i =0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].advertiserId == advertiserId)
                    {
                        if($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                        {

                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('spenddetails'))
                                {
                                    for(l = spend.length-1; l >= 0;l--)
                                    {
                                        for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].spenddetails.length;k++)
                                        {
                                            if(spend[l].date == $scope.networkmaparray[i].networkDetails[j].spenddetails[k].date)
                                            {                                               
                                                spend[l].spend =spend[l].spend+$scope.networkmaparray[i].networkDetails[j].spenddetails[k].spend;
                                                spend[l].clicks = spend[l].clicks+$scope.networkmaparray[i].networkDetails[j].spenddetails[k].clicks;
                                                spend[l].impressions = spend[l].impressions+$scope.networkmaparray[i].networkDetails[j].spenddetails[k].impressions;
                                                spend[l].actions = spend[l].actions+$scope.networkmaparray[i].networkDetails[j].spenddetails[k].actions;
                                                
                                        }
                                        }
                                    }         
                                }
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('budgetdetails'))
                                {                                    
                                    budget = budget + parseInt($scope.networkmaparray[i].networkDetails[j].budgetdetails);
                                }
                            }
                        }
                    }
                }               
                for(i=0;i<spend.length;i++)
                {
                    var d = spend[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    spend[i].date = d;
                }
                $scope.spendComparison = spend;
                var plot = [];
                for(i = 1; i < spend.length; i++){               
                var obj = {
                    "date":spend[i].date,
                    "region":"actions",
                    "amount":spend[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spend[i].date,
                    "name":"spend",
                    "amount":spend[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date":spend[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);
                cpc = spend[i].spend / spend[i].clicks;
                if(isNaN(cpc)){
                    expectedclicks = 0;
                }
                else{
                    expectedclicks= budget/cpc;
                }
                var _obj={
                    "date":spend[i].date,
                    "name":"expectedclicks",
                    "amount":expectedclicks
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"clicks",
                    "amount":spend[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpm = spend[i].spend / (spend[i].impressions/1000);
                    if(isNaN(cpm)){
                        expectedimp = 0;
                    }
                    else{
                        expectedimp= budget/cpm;
                    }
                    var _obj={
                    "date":spend[i].date,
                    "name":"expectedimp",
                    "amount":expectedimp
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"impressions",
                    "amount":spend[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = spend[i].spend / spend[i].actions;
                   if(isNaN(cpa)){
                       expectedactions = 0;
                   }
                   else{
                       expectedactions = budget/cpa;
                   }
                  var _obj={
                    "date":spend[i].date,
                    "name":"expectedactions",
                    "amount":expectedactions
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"actions",
                    "amount":spend[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date":spend[i].date,
                    "region":"spend",
                    "amount":spend[i].spend
                };
                plot.push(obj);                
            }            
            $scope.plotvalues = plot;            
            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,'DAILY');
            }
            else
            {               
               $scope.readAccountBudgetFromToAdvertiser();
            }
        };
        
        $scope.networkFilterPlot = function(advertiserId,networkURL,userNetworkId)
        {   
            $scope.Isvisible=false;            
            $scope.textbx = "";
            $scope.btnText = 'Calculate';
            var spend = [];
            var budget = 0;
            var userNetMapId;  
            var expectedclicks = 0;
            var expectedactions = 0;
            var expectedimp =0;
            var cpa = 0;
            var cpc = 0;
            var cpm = 0;  
            $scope.expectedright = [];
            $scope.actualright = [];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            if(($scope.from == undefined || $scope.from == "") && ($scope.to == undefined || $scope.to == ""))
            {
                $scope.currentDate = new Date($scope.fromDate);
                $scope.dateArray = [];
                while ($scope.currentDate <= new Date($scope.toDate))
                {
                    $scope.dateArray.push($scope.currentDate.toISOString().slice(0,10));
                    var obj = {
                        'date':$scope.currentDate.toISOString().slice(0,10),
                        'spend':0,
                        'impressions':0,
                        'clicks':0,
                        'actions':0
                    };
                    spend.push(obj);
                    $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }                
                for(i =0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].advertiserId == advertiserId)
                    {
                        if($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                        {

                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkId)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('spenddetails'))
                                    {
                                        for(l = spend.length-1; l >= 0;l--)
                                        {
                                            for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].spenddetails.length;k++)
                                            {
                                                if(spend[l].date == $scope.networkmaparray[i].networkDetails[j].spenddetails[k].date)
                                                {
                                                    spend[l].spend = $scope.networkmaparray[i].networkDetails[j].spenddetails[k].spend;
                                                    spend[l].clicks = $scope.networkmaparray[i].networkDetails[j].spenddetails[k].clicks;
                                                    spend[l].impressions = $scope.networkmaparray[i].networkDetails[j].spenddetails[k].impressions;
                                                    spend[l].actions =$scope.networkmaparray[i].networkDetails[j].spenddetails[k].actions;
                                                }
                                            }
                                        }
                                    }
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('budgetdetails'))
                                    {
                                        budget = parseInt($scope.networkmaparray[i].networkDetails[j].budgetdetails);
                                    }
                                }
                            }
                        }
                    }
                }                
                for(i=0;i<spend.length;i++)
                {
                    var d = spend[i].date;
                    d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                    spend[i].date = d;
                }                
                $scope.spendComparison = spend;
                var plot = [];
                for(i = 1; i < spend.length; i++){               
                var obj = {
                    "date":spend[i].date,
                    "region":"actions",
                    "amount":spend[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spend[i].date,
                    "name":"spend",
                    "amount":spend[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date":spend[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);
                cpc = spend[i].spend / spend[i].clicks;
                if(isNaN(cpc)){
                    expectedclicks = 0;
                }
                else{
                    expectedclicks= budget/cpc;
                }
                var _obj={
                    "date":spend[i].date,
                    "name":"expectedclicks",
                    "amount":expectedclicks
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"clicks",
                    "amount":spend[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpm = spend[i].spend / (spend[i].impressions/1000);
                    if(isNaN(cpm)){
                        expectedimp = 0;
                    }
                    else{
                        expectedimp= budget/cpm;
                    }
                    var _obj={
                    "date":spend[i].date,
                    "name":"expectedimp",
                    "amount":expectedimp
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"impressions",
                    "amount":spend[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = spend[i].spend / spend[i].actions;
                   if(isNaN(cpa)){
                       expectedactions = 0;
                   }
                   else{
                       expectedactions = budget/cpa;
                   }
                  var _obj={
                    "date":spend[i].date,
                    "name":"expectedactions",
                    "amount":expectedactions
                }
                var _act = {
                    "date":spend[i].date,
                    "name":"actions",
                    "amount":spend[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date":spend[i].date,
                    "region":"spend",
                    "amount":spend[i].spend
                };
                plot.push(obj);                
            }            
            $scope.plotvalues = plot;            
            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,'DAILY');
            }
            else
            {                              
                if(networkURL == appSettings.fbNetwork){                   
                    $scope.readAccountBudgetFromToAdvertiserFB();
                }
                else{                   
                   $scope.readAccountBudgetFromToAdvertiserTW();
                   
                }
            }
        };
        
        $scope.accountInsightsforAllCategory = function(budget){            
            var promises = [];
            var spendArray = [];            
            var dates = [];    
            var flag =0;
            var spendUnique =[];
            if($scope.breakdown == "DAILY")
            {
                var currentDate = new Date($scope.UTCFromDate);
                while (currentDate <= new Date($scope.UTCToDate))
                {
                    var d = new Date(currentDate)
                    var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                    var obj = {
                       "date":currentDate1,
                       "spend":0,
                       "clicks":0,
                       "impressions":0,
                       "actions":0
                    };
                    dates.push(obj);
                    currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }
            }           
            for (var i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].advertiserId == $scope.advertiserId){
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                        for(var j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                            (function(i,j){
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)//FOR FACEBOOK
                                {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.fbNetwork,false).then(function(resp){
                                        if(resp.appStatus == 0){
                                            angular.forEach(resp.adAccountInsights, function(value, key){
                                                angular.forEach(value, function(value2, key2){
                                                    angular.forEach(value2, function(value3, key3){                                                       
                                                        if($scope.breakdown != "DAILY"){
                                                        var keyValue2 = key3.split('_').join(' ');
                                                        var obj = {
                                                            "date":keyValue2,
                                                            "spend":0,
                                                            "clicks":0,
                                                            "impressions":0,
                                                            "actions" : 0
                                                        };
                                                        for(i = 0 ;i<spendUnique.length;i++)
                                                        {
                                                            if(obj.date == spendUnique[i].date)
                                                            {
                                                                flag=1;
                                                            }
                                                        }
                                                        if(spendUnique.length == 0 || flag==0)
                                                        {
                                                            spendUnique.push(obj);
                                                        }                                                       
                                                       var obj = {
                                                               "date":keyValue2,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction                                                               
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else if($scope.breakdown == "DAILY"){
                                                            var d;
                                                            if(key3.length == 10){
                                                              d = $filter('date')(key3 * 1000,'yyyy-MM-dd');   
                                                            }
                                                            else{
                                                               d = $filter('date')(key3,'yyyy-MM-dd');  
                                                            }                                                    
                                                            for(i=0;i<dates.length;i++)
                                                            {
                                                                if(dates[i].date==d)
                                                                {
                                                                    var obj = {
                                                               "date":dates[i].date,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else
                                                        {
                                                            var obj = {
                                                                "date":dates[i].date,
                                                                "name":"all",
                                                                "spend":0,
                                                                "clicks":0,
                                                                "impressions":0,
                                                                "actions":0
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    }
                                                }
                                            });
                                        });
                                    });
                                }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                           if (resp.networkError != '' && resp.networkError != undefined) {
                                if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = resp.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                       $scope.errorMsg = resp.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = resp.errorMessage;
                            }
                        }
                                        }
                                    }));    
                                }
                                }
                                else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)//FOR TWITTER
                                {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.twNetwork,false).then(function(resp){
                                        if(resp.appStatus == 0){
                                            angular.forEach(resp.adAccountInsights, function(value, key){
                                                angular.forEach(value, function(value2, key2){
                                                    angular.forEach(value2, function(value3, key3){                                                       
                                                        if($scope.breakdown != "DAILY"){                                                          
                                                        var keyValue2 = key3.split('_').join(' ');
                                                        var obj = {
                                                            "date":keyValue2,
                                                            "spend":0,
                                                            "clicks":0,
                                                            "impressions":0,
                                                            "actions" : 0
                                                        };
                                                        for(i = 0 ;i<spendUnique.length;i++)
                                                        {
                                                            if(obj.date == spendUnique[i].date)
                                                            {
                                                                flag=1;
                                                            }
                                                        }
                                                        if(spendUnique.length == 0 || flag==0)
                                                        {
                                                            spendUnique.push(obj);
                                                        }                                                        
                                                       var obj = {
                                                               "date":keyValue2,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction                                                               
                                                            };
                                                            spendArray.push(obj);
                                                        }                                                       
                                                        else if($scope.breakdown == "DAILY"){
                                                             var d;
                                                            if(key3.length == 10){
                                                              d = $filter('date')(key3 * 1000,'yyyy-MM-dd');   
                                                            }
                                                            else{
                                                               d = $filter('date')(key3,'yyyy-MM-dd');  
                                                            }
                                                            for(i=0;i<dates.length;i++)
                                                            {
                                                                if(dates[i].date==d)
                                                                {
                                                                    var obj = {
                                                               "date":dates[i].date,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else
                                                        {
                                                            var obj = {
                                                                "date":dates[i].date,
                                                                "name":"all",
                                                                "spend":0,
                                                                "clicks":0,
                                                                "impressions":0,
                                                                "actions":0
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    }
                                                }
                                            });
                                        });
                                    });
                                }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (resp.networkError != '' && resp.networkError != undefined) {
                                if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = resp.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = resp.errorMessage;
                           }
                        }
                                        }
                                    }));    
                                }
                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        
                        if($scope.breakdown == "DAILY")
                        {  
                            var spend = [];
                            var obj = {
                                "date":0,
                                "spend":0,
                                "clicks":0,
                                "actions":0,
                                "impressions":0
                            };
                            spend.push(obj);                           
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(dates[i].date == spendArray[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spendArray[j].spend);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendArray[j].clicks);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendArray[j].impressions);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spendArray[j].actions);
                                    }
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                var d = dates[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                                dates[i].date = d;
                            }
                            for(i = 0;i<dates.length;i++){
                                if(dates[i].spend == 0 && budget == 0){
                                    zero_count++;
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                spend.push(dates[i]);
                            }                            
                            var zero_count = 0;
                            var plot = [];
                            var cpc = 0;
                            var cpa = 0;
                            var cpm = 0;
                            var expectedclicks = 0;
                            var expectedimp =0 ;
                            var expectedactions = 0;
                            $scope.expectedleft = [];
                            $scope.expectedright = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            for(i = 1; i < spend.length; i++){
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"actions",
                                    "amount":spend[i].actions
                                };
                                plot.push(obj);
                                var object = {
                                    "date":spend[i].date,
                                    "name":"spend",
                                    "amount":spend[i].spend
                                };
                                $scope.actualleft.push(object);
                                var _object = {
                                    "date":spend[i].date,
                                    "name":"budget",
                                    "amount":budget
                                };
                                $scope.expectedleft.push(_object);
                                cpc = spend[i].spend / spend[i].clicks;
                                if(isNaN(cpc)){
                                    expectedclicks = 0;
                                }
                                else{
                                    expectedclicks= budget/cpc;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedclicks",
                                    "amount":expectedclicks
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"clicks",
                                    "amount":spend[i].clicks
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                cpm = spend[i].spend / (spend[i].impressions/1000);
                               if(isNaN(cpm)){
                                   expectedimp = 0;
                               }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                    "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;                          
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                      else if($scope.breakdown != "DAILY")
                      {
                          var spend = [];
                          var obj = {
                              "date":0,
                              "spend":0,
                              "clicks":0,
                              "actions":0,
                              "impressions":0
                          };
                          spend.push(obj);                        
                          for(i =0 ;i<spendUnique.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(spendUnique[i].date == spendArray[j].date)
                                    {
                                        spendUnique[i].spend = parseInt(spendUnique[i].spend) + parseInt(spendArray[j].spend);
                                        spendUnique[i].clicks = parseInt(spendUnique[i].clicks) + parseInt(spendArray[j].clicks);
                                        spendUnique[i].impressions = parseInt(spendUnique[i].impressions) + parseInt(spendArray[j].impressions);
                                        spendUnique[i].actions = parseInt(spendUnique[i].actions) + parseInt(spendArray[j].actions);
                                        
                                    }
                                }
                            }
                          
                          for(i=0;i<spendUnique.length;i++){
                              spend.push(spendUnique[i]);
                          }                          
                          var zero_count = 0;
                          var plot = [];
                          var cpc = 0;
                          var cpa = 0;
                          var cpm = 0;
                          var expectedclicks = 0;
                          var expectedimp =0 ;
                          var expectedactions = 0;
                          $scope.expectedleft = [];
                          $scope.actualleft = [];
                          $scope.actualright = [];
                          for(i = 1; i < spend.length; i++){
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"actions",
                                  "amount":spend[i].actions
                              };
                              plot.push(obj);
                              var object = {
                                  "date":spend[i].date,
                                  "name":"spend",
                                  "amount":spend[i].spend
                              };
                              $scope.actualleft.push(object);
                              var _object = {
                                  "date":spend[i].date,
                                  "name":"budget",
                                  "amount":budget
                              };
                              $scope.expectedleft.push(_object);
                              cpc = spend[i].spend / spend[i].clicks;
                              if(isNaN(cpc)){
                                  expectedclicks = 0;
                              }
                              else{
                                  expectedclicks= budget/cpc;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedclicks",
                                  "amount":expectedclicks
                              }
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"clicks",
                                  "amount":spend[i].clicks
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpm = spend[i].spend / (spend[i].impressions/1000);
                              if(isNaN(cpm)){
                                  expectedimp = 0;
                              }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                  "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                  });
              };
        $scope.accountInsightsforAllCategoryFB = function(budget){            
            var promises = [];
            var spendArray = [];            
            var dates = [];  
            if($scope.breakdown == "DAILY")
            {
                var currentDate = new Date($scope.UTCFromDate);
                while (currentDate <= new Date($scope.UTCToDate))
                {
                    var d = new Date(currentDate)
                    var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                    var obj = {
                       "date":currentDate1,
                       "spend":0,
                       "clicks":0,
                       "impressions":0,
                       "actions":0
                    };
                    dates.push(obj);
                    currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }
            }           
            for (var i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].advertiserId == $scope.advertiserId){
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                        for(var j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                            (function(i,j){
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)//FOR FACEBOOK
                                {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.fbNetwork,false).then(function(resp){
                                        if(resp.appStatus == 0){
                                            angular.forEach(resp.adAccountInsights, function(value, key){
                                                angular.forEach(value, function(value2, key2){
                                                    angular.forEach(value2, function(value3, key3){                                                       
                                                        if($scope.breakdown != "DAILY"){                                                          
                                                            var keyValue2 = key3.split('_').join(' ');
                                                            var obj = {
                                                               "date":keyValue2,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction                                                               
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else if($scope.breakdown == "DAILY"){
                                                             var d;
                                                            if(key3.length == 10){
                                                              d = $filter('date')(key3 * 1000,'yyyy-MM-dd');   
                                                            }
                                                            else{
                                                               d = $filter('date')(key3,'yyyy-MM-dd');  
                                                            }
                                                            for(i=0;i<dates.length;i++)
                                                            {
                                                                if(dates[i].date==d)
                                                                {
                                                                    var obj = {
                                                               "date":dates[i].date,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else
                                                        {
                                                            var obj = {
                                                                "date":dates[i].date,
                                                                "name":"all",
                                                                "spend":0,
                                                                "clicks":0,
                                                                "impressions":0,
                                                                "actions":0
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    }
                                                }
                                            });
                                        });
                                    });
                                }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (resp.networkError != '' && resp.networkError != undefined) {
                                if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                      $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = resp.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = resp.errorMessage;
                            }
                        }
                                        }
                                    }));    
                                }
                                }
                                
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        
                        if($scope.breakdown == "DAILY")
                        {  
                            var spend = [];
                            var obj = {
                                "date":0,
                                "spend":0,
                                "clicks":0,
                                "actions":0,
                                "impressions":0
                            };
                            spend.push(obj);                           
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(dates[i].date == spendArray[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spendArray[j].spend);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendArray[j].clicks);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendArray[j].impressions);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spendArray[j].actions);
                                    }
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                var d = dates[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                                dates[i].date = d;
                            }
                            for(i = 0;i<dates.length;i++){
                                if(dates[i].spend == 0 && budget == 0){
                                    zero_count++;
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                spend.push(dates[i]);
                            }                            
                            var zero_count = 0;
                            var plot = [];
                            var cpc = 0;
                            var cpa = 0;
                            var cpm = 0;
                            var expectedclicks = 0;
                            var expectedimp =0 ;
                            var expectedactions = 0;
                            $scope.expectedleft = [];
                            $scope.expectedright = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            for(i = 1; i < spend.length; i++){
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"actions",
                                    "amount":spend[i].actions
                                };
                                plot.push(obj);
                                var object = {
                                    "date":spend[i].date,
                                    "name":"spend",
                                    "amount":spend[i].spend
                                };
                                $scope.actualleft.push(object);
                                var _object = {
                                    "date":spend[i].date,
                                    "name":"budget",
                                    "amount":budget
                                };
                                $scope.expectedleft.push(_object);
                                cpc = spend[i].spend / spend[i].clicks;
                                if(isNaN(cpc)){
                                    expectedclicks = 0;
                                }
                                else{
                                    expectedclicks= budget/cpc;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedclicks",
                                    "amount":expectedclicks
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"clicks",
                                    "amount":spend[i].clicks
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                cpm = spend[i].spend / (spend[i].impressions/1000);
                               if(isNaN(cpm)){
                                   expectedimp = 0;
                               }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                    "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                      else if($scope.breakdown != "DAILY")
                      {
                          var spend = [];
                          var obj = {
                              "date":0,
                              "spend":0,
                              "clicks":0,
                              "actions":0,
                              "impressions":0
                          };
                          spend.push(obj);
                          for(i=0;i<spendArray.length;i++){
                              spend.push(spendArray[i]);
                          }
                          var zero_count = 0;
                          var plot = [];
                          var cpc = 0;
                          var cpa = 0;
                          var cpm = 0;
                          var expectedclicks = 0;
                          var expectedimp =0 ;
                          var expectedactions = 0;
                          $scope.expectedleft = [];
                          $scope.actualleft = [];
                          $scope.actualright = [];
                          for(i = 1; i < spend.length; i++){
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"actions",
                                  "amount":spend[i].actions
                              };
                              plot.push(obj);
                              var object = {
                                  "date":spend[i].date,
                                  "name":"spend",
                                  "amount":spend[i].spend
                              };
                              $scope.actualleft.push(object);
                              var _object = {
                                  "date":spend[i].date,
                                  "name":"budget",
                                  "amount":budget
                              };
                              $scope.expectedleft.push(_object);
                              cpc = spend[i].spend / spend[i].clicks;
                              if(isNaN(cpc)){
                                  expectedclicks = 0;
                              }
                              else{
                                  expectedclicks= budget/cpc;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedclicks",
                                  "amount":expectedclicks
                              }
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"clicks",
                                  "amount":spend[i].clicks
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpm = spend[i].spend / (spend[i].impressions/1000);
                              if(isNaN(cpm)){
                                  expectedimp = 0;
                              }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                  "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                  });
              };
        $scope.accountInsightsforAllCategoryTW = function(budget){            
            var promises = [];
            var spendArray = [];            
            var dates = [];      
            if($scope.breakdown == "DAILY")
            {
                var currentDate = new Date($scope.UTCFromDate);
                while (currentDate <= new Date($scope.UTCToDate))
                {
                    var d = new Date(currentDate)
                    var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                    var obj = {
                       "date":currentDate1,
                       "spend":0,
                       "clicks":0,
                       "impressions":0,
                       "actions":0
                    };
                    dates.push(obj);
                    currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                }
            }           
            for (var i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].advertiserId == $scope.advertiserId){
                    if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                        for(var j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                            (function(i,j){                                
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)//FOR TWITTER
                                {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId')){
                                    promises.push(performanceServices.readadaccountsinsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].adAccountId,$scope.UTCFromDate,$scope.UTCToDate,$scope.breakdown,appSettings.twNetwork,false).then(function(resp){
                                        if(resp.appStatus == 0){
                                            angular.forEach(resp.adAccountInsights, function(value, key){
                                                angular.forEach(value, function(value2, key2){
                                                    angular.forEach(value2, function(value3, key3){                                                       
                                                        if($scope.breakdown != "DAILY"){                                                          
                                                            var keyValue2 = key3.split('_').join(' ');
                                                            var obj = {
                                                               "date":keyValue2,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction                                                               
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else if($scope.breakdown == "DAILY"){
                                                             var d;
                                                            if(key3.length == 10){
                                                              d = $filter('date')(key3 * 1000,'yyyy-MM-dd');   
                                                            }
                                                            else{
                                                               d = $filter('date')(key3,'yyyy-MM-dd');  
                                                            }
                                                            for(i=0;i<dates.length;i++)
                                                            {
                                                                if(dates[i].date==d)
                                                                {
                                                                    var obj = {
                                                               "date":dates[i].date,
                                                               "name":"all",
                                                               "spend":value3.spend,
                                                               "clicks":value3.clicks,                                                               
                                                               "impressions":value3.impressions,
                                                               "actions":value3.callToAction
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                        else
                                                        {
                                                            var obj = {
                                                                "date":dates[i].date,
                                                                "name":"all",
                                                                "spend":0,
                                                                "clicks":0,
                                                                "impressions":0,
                                                                "actions":0
                                                            };
                                                            spendArray.push(obj);
                                                        }
                                                    }
                                                }
                                            });
                                        });
                                    });
                                }
                                        else{
                                            if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                          $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (resp.networkError != '' && resp.networkError != undefined) {
                                if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                       $scope.errorMsg = resp.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = resp.errorMessage;
                            }
                        }
                                        }
                                    }));    
                                }
                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        
                        if($scope.breakdown == "DAILY")
                        {  
                            var spend = [];
                            var obj = {
                                "date":0,
                                "spend":0,
                                "clicks":0,
                                "actions":0,
                                "impressions":0
                            };
                            spend.push(obj);                           
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spendArray.length;j++)
                                {
                                    if(dates[i].date == spendArray[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spendArray[j].spend);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendArray[j].clicks);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendArray[j].impressions);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spendArray[j].actions);
                                    }
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                var d = dates[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                                dates[i].date = d;
                            }
                            for(i = 0;i<dates.length;i++){
                                if(dates[i].spend == 0 && budget == 0){
                                    zero_count++;
                                }
                            }
                            for(i=0;i<dates.length;i++)
                            {
                                spend.push(dates[i]);
                            }                            
                            var zero_count = 0;
                            var plot = [];
                            var cpc = 0;
                            var cpa = 0;
                            var cpm = 0;
                            var expectedclicks = 0;
                            var expectedimp =0 ;
                            var expectedactions = 0;
                            $scope.expectedleft = [];
                            $scope.expectedright = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            for(i = 1; i < spend.length; i++){
                                var obj = {
                                    "date":spend[i].date,
                                    "region":"actions",
                                    "amount":spend[i].actions
                                };
                                plot.push(obj);
                                var object = {
                                    "date":spend[i].date,
                                    "name":"spend",
                                    "amount":spend[i].spend
                                };
                                $scope.actualleft.push(object);
                                var _object = {
                                    "date":spend[i].date,
                                    "name":"budget",
                                    "amount":budget
                                };
                                $scope.expectedleft.push(_object);
                                cpc = spend[i].spend / spend[i].clicks;
                                if(isNaN(cpc)){
                                    expectedclicks = 0;
                                }
                                else{
                                    expectedclicks= budget/cpc;
                                }
                                var _obj={
                                    "date":spend[i].date,
                                    "name":"expectedclicks",
                                    "amount":expectedclicks
                                };
                                var _act = {
                                    "date":spend[i].date,
                                    "name":"clicks",
                                    "amount":spend[i].clicks
                                };
                                $scope.expectedright.push(_obj);
                                $scope.actualright.push(_act);
                                cpm = spend[i].spend / (spend[i].impressions/1000);
                               if(isNaN(cpm)){
                                   expectedimp = 0;
                               }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                    "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                      else if($scope.breakdown != "DAILY")
                      {
                          var spend = [];
                          var obj = {
                              "date":0,
                              "spend":0,
                              "clicks":0,
                              "actions":0,
                              "impressions":0
                          };
                          spend.push(obj);
                          for(i=0;i<spendArray.length;i++){
                              spend.push(spendArray[i]);
                          }
                          var zero_count = 0;
                          var plot = [];
                          var cpc = 0;
                          var cpa = 0;
                          var cpm = 0;
                          var expectedclicks = 0;
                          var expectedimp =0 ;
                          var expectedactions = 0;
                          $scope.expectedleft = [];
                          $scope.actualleft = [];
                          $scope.actualright = [];
                          for(i = 1; i < spend.length; i++){
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"actions",
                                  "amount":spend[i].actions
                              };
                              plot.push(obj);
                              var object = {
                                  "date":spend[i].date,
                                  "name":"spend",
                                  "amount":spend[i].spend
                              };
                              $scope.actualleft.push(object);
                              var _object = {
                                  "date":spend[i].date,
                                  "name":"budget",
                                  "amount":budget
                              };
                              $scope.expectedleft.push(_object);
                              cpc = spend[i].spend / spend[i].clicks;
                              if(isNaN(cpc)){
                                  expectedclicks = 0;
                              }
                              else{
                                  expectedclicks= budget/cpc;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedclicks",
                                  "amount":expectedclicks
                              }
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"clicks",
                                  "amount":spend[i].clicks
                              };
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpm = spend[i].spend / (spend[i].impressions/1000);
                              if(isNaN(cpm)){
                                  expectedimp = 0;
                              }
                              else{
                                  expectedimp= budget/cpm;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedimp",
                                  "amount":expectedimp
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"impressions",
                                  "amount":spend[i].impressions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              cpa = spend[i].spend / spend[i].actions;
                              if(isNaN(cpa)){
                                  expectedactions = 0;
                              }
                              else{
                                  expectedactions = budget/cpa;
                              }
                              var _obj={
                                  "date":spend[i].date,
                                  "name":"expectedactions",
                                  "amount":expectedactions
                              };
                              var _act = {
                                  "date":spend[i].date,
                                  "name":"actions",
                                  "amount":spend[i].actions
                              }
                              $scope.expectedright.push(_obj);
                              $scope.actualright.push(_act);
                              var obj = {
                                  "date":spend[i].date,
                                  "region":"spend",
                                  "amount":spend[i].spend
                              };
                              plot.push(obj);
                          }
                          $scope.spendComparison = spend;
                          $scope.plotvalues = plot;
                          $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                      }
                  });
              };
        
        $scope.fetchChildAndPush = function () 
        { 
		  
            console.log("child fetch");            
            $scope.wholechildArray = [];
            var userNetMapIdFB = ""; 
            var userNetMapIdTW = ""; 
			var promises = [];	

 for(a=0;a<$scope.wholeParentArray.length;a++){
	 var _id = $scope.wholeParentArray[a].id;
	         for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                {
                    if($scope.networkmaparray[i].hasOwnProperty('networkDetails'))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            (function(i,j,a)
                            {                               
                                if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {
                                    userNetMapIdFB = $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                                    promises.push(performanceServices.readadcampaign(userNetMapIdFB,$scope.wholeParentArray[a].id,appSettings.fbNetwork,undefined).then(function (response) {
                                        if (response.appStatus == '0') {
                                            $scope.childCampaigns = response.adcampaigns;
                                            var count = 0;
                                            angular.forEach($scope.childCampaigns, function (value, key) {
                                                var JsonObj = $scope.childCampaigns[key];
                                                var array = [];
                                                for (var j in JsonObj) {
                                                    if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                                        array[+j] = JsonObj[j];                                                        
                                                        var _obj = {
                                                            "id": array[+j].campaignId,
                                                            "name": array[+j].campaignDetails.name,
                                                            "type": "child",
                                                            "parentid": $scope.wholeParentArray[a].id,
                                                            "userNetworkMapId":userNetMapIdFB,
                                                            "networkURL":appSettings.fbNetwork
                                                        };
                                                        count++;
                                                        $scope.wholechildArray.push(_obj);
                                                    }
                                                }
                                            });
                                        } else {
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
	
						
					console.log("CHILD CAMPAIGN FOR ADACCOUNT");
					console.log("advertiserDetails");	

$scope.errors.push({"category":"childCamp","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"networkURL":appSettings.fbNetwork,"parentID":$scope.wholeParentArray[a].id,"parentCamp":$scope.wholeParentArray,"errorMsg": response.errorMessage});
					console.log($scope.errors);

                          /*  $rootScope.progressLoader = "none";
                             $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                        $scope.errorMsg = response.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }*/
                        }
                    }
                }));
            }
            else if( $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork){
                userNetMapIdTW = $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                promises.push(performanceServices.readadcampaign(userNetMapIdTW,$scope.wholeParentArray[a].id,appSettings.twNetwork,undefined).then(function (response) {
                    if (response.appStatus == '0') {
                        $scope.childCampaigns = response.campaign;
                        var count = 0;
                        for(var k=0;k<$scope.childCampaigns.length;k++){
                            var JsonObj = $scope.childCampaigns[k];
                            var array = [];
                            for (var val in JsonObj) { 
                                if (JsonObj.hasOwnProperty(val)) {
                                    array[+val] = JsonObj[val]; 
                                    var _obj = {
                                        "id": array[+val].twCampaignId,                                        
                                        "name": array[+val].twCampaignDetails.name,
                                        "type": "child",
                                        "parentid": $scope.wholeParentArray[a].id,
                                        "userNetworkMapId": userNetMapIdTW,                                        
                                        "networkURL":appSettings.twNetwork
                                    };
                                    count++;
                                    $scope.wholechildArray.push(_obj);
                                }
                            }
                        };
                    } else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
								
		
								
					console.log("CHILD CAMPAIGN FOR ADACCOUNT");	
					$scope.errors.push({"category":"childCamp","network":$scope.networkmaparray[i],"advertiserDetails":$scope.networkmaparray[i].networkDetails[j],"networkURL":appSettings.fbNetwork,"parentID":$scope.wholeParentArray[a].id,"parentCamp":$scope.wholeParentArray,"errorMsg": response.errorMessage});
					console.log($scope.errors);
                  					
						/*  $rootScope.progressLoader = "none";
                             $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                        $scope.errorMsg = response.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }*/
                                }
                           }
                    }));
					
                }
				      
                            })(i,j,a);
							
							
                        }
						
                    }
                }
            } 
 }
			$q.all(promises).finally(function()
            {
                 console.log("ERROR!");   
               console.log($scope.errors);
			   $scope.handlingErrors();   				 
			});
			
 
        };
         $scope.fetchNetworkChildAndPush = function (_id,networkURL,userNetMapId) 
        {  
		var promises = [];
		for(m=0;m<$scope.wholeParentArray.length;m++){
            $scope.wholechildArray = [];    
         (function(m){			
            if(networkURL == appSettings.fbNetwork)
            {
                promises.push(performanceServices.readadcampaign(userNetMapId,$scope.wholeParentArray[m].id,appSettings.fbNetwork,undefined).then(function (response) {
                   if (response.appStatus == '0') {
                       $scope.childCampaigns = response.adcampaigns;
                       var count = 0;
                       angular.forEach($scope.childCampaigns, function (value, key) {
                           var JsonObj = $scope.childCampaigns[key];
                           var array = [];
                           for (var j in JsonObj) {
                               if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                   array[+j] = JsonObj[j];
                                   var _obj = {
                                       "id": array[+j].campaignId,
                                       "name": array[+j].campaignDetails.name,
                                       "type": "child",
                                       "parentid":  $scope.wholeParentArray[m].id,
                                       "userNetworkMapId":userNetMapId,
                                       "networkURL":networkURL
                                   };
                                   count++;
                                   $scope.wholechildArray.push(_obj)
                               }
                           }
                       });
                   } else {
                       if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
						
					console.log("CHILD CAMPAIGN FOR FACEBOOK");
					console.log($scope.networkmaparray);
					console.log(response.errorMessage);
					 console.log($scope.wholeParentArray[m]);
					console.log($scope.wholeParentArray[m].id);
					angular.forEach($scope.networkmaparray,function(value){
						for(k=0;k<value.networkDetails.length;k++){
							
							if(value.networkDetails[k].userNetworkMapId == userNetMapId){
								$scope.adDetails = value.networkDetails[k];
								$scope.networkDetails = value ;
							}
						}
					})
					console.log("AD DETAILS");
					console.log($scope.adDetails);
					$scope.errors.push({"category":"childCamp","network":$scope.networkDetails,"advertiserDetails":$scope.adDetails,"parentID": $scope.wholeParentArray[m].id,"parentCamp":$scope.wholeParentArray,"errorMsg": response.errorMessage,"networkURL":networkURL});
					console.log($scope.errors);
						
                            /*&$rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.networkError.message;
                                } else {
                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                        $scope.errorMsg = response.networkError.error_user_msg;
                                }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }*/
                        }
                    }
                }));
            }
            else{
                promises.push(performanceServices.readadcampaign(userNetMapId,$scope.wholeParentArray[m].id,appSettings.twNetwork,undefined).then(function (response) {
                    if (response.appStatus == '0') {
                        $scope.childCampaigns = response.campaign;
                        var count = 0;
                        for(var k=0;k<$scope.childCampaigns.length;k++){
                            var JsonObj = $scope.childCampaigns[k];
                            var array = [];
                            for (var j in JsonObj) { 
                                if (JsonObj.hasOwnProperty(j)) {
                                    array[+j] = JsonObj[j]; 
                                    var _obj = {
                                        "id": array[+j].twCampaignId,                                        
                                        "name": array[+j].twCampaignDetails.name,
                                        "type": "child",
                                        "parentid":  $scope.wholeParentArray[m].id,
                                        "userNetworkMapId": userNetMapId,
                                        "networkURL":networkURL
                                    };
                                    count++;
                                    $scope.wholechildArray.push(_obj);
                                }
                            }
                        };
                    } else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
								
					console.log("CHILD CAMPAIGN FOR TWITTER");
					console.log($scope.networkmaparray);

					angular.forEach($scope.networkmaparray,function(value){
						for(k=0;k<value.networkDetails.length;k++){
							
							if(value.networkDetails[k].userNetworkMapId == userNetMapId){
								
								$scope.adDetails = value.networkDetails[k];
								$scope.networkDetails = value ;
							}
						}
					})
					console.log("AD DETAILS");
					console.log($scope.adDetails);
					$scope.errors.push({"category":"childCamp","network":$scope.networkDetails,"advertiserDetails":$scope.adDetails,"parentID": $scope.wholeParentArray[m].id,"parentCamp":$scope.wholeParentArray,"errorMsg": response.errorMessage,"networkURL":networkURL});
					console.log($scope.errors);
					
					
                                  /*  $rootScope.progressLoader = "none";
                                   $scope.editAdsetErrorMsg = 'block';
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                        } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                        }
                                    } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                    }*/
                                }
                        }
                    }));
                }
            
		})(m);
		}
			$q.all(promises).finally(function()
            {
               console.log("Network wise error");   
               console.log($scope.errors);
			   $scope.handlingErrors();   				 
			});
	
		};
        
        
        $scope.checkNetworkforadvertiser = function (advertiserId)
        {
            console.log('network check');
            $scope.networkforadv = true;
            $scope.networksarrayforadvertiser = [];
            for (i = 0; i < $scope.networksarrayforacc.length; i++)
            {
                angular.forEach($scope.advertiserdetails, function (val, key) 
                {
                    if (advertiserId == val.advertiserId)
                    {
                        if (val.advertiserEmail == $scope.networksarrayforacc[i].userId)
                        {
                            $scope.networkid = $scope.networksarrayforacc[i].networkId;
                            angular.forEach($scope.allnetworksarray, function (val, key)
                            {
                                if ($scope.networkid == val.networkId)
                                {
                                    $scope.networksarrayforadvertiser.push(val);
                                }
                            });
                        }
                    }
                });
            }            
        };
        
        $scope.parentselection = function (_obj)
        {            
            $rootScope.progressLoader = "block";
            $scope.graphPlotted = false;
             $scope.Isvisible=false;
             $scope.textbx = "";
             $scope.btnText = 'Calculate';             
            var currentParentChildren = [];
            $scope.selectedvalue = '';           
            $scope.selectedvalue = _obj.name;
            $scope.selectedParentChildCampaign = _obj;
            if(_obj.hasOwnProperty("networkArray"))
            {
                $scope.onloadParentSelection = true;
                console.log("onload parent selection");                
                for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            for(k=0;k<_obj.networkArray.length;k++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == _obj.networkArray[k].userNetworkMapId)
                                {                                    
                                    $scope.advertiserId = $scope.networkmaparray[i].advertiserId;
									$scope.advertiserDetails = $scope.networkmaparray[i].networkDetails[j];
                                }
                            }
                        }
                    }
                }                
            }           
            else
            {
                console.log("advertiser parent selection");
                $scope.advertiserId=$window.localStorage.getItem("advertiserId");
            }
            for(i = 0;i<$scope.wholechildArray.length;i++)
            {
                if(_obj.id == $scope.wholechildArray[i].parentid)
                {
                    currentParentChildren.push($scope.wholechildArray[i]);
                }
            }
            if(currentParentChildren.length != 0)
            {
				
                $scope.readadcampaigninsightsforParent(currentParentChildren);
            }
            else
            {
                //$rootScope.progressLoader = "none";
                $scope.graphPlotted = false;
                $scope.spendComparison = [];
                $scope.plotvalues=[];
                $scope.expectedleft = [];
                $scope.expectedright = [];
                $scope.actualleft = [];
                $scope.actualright = [];
                $scope.Isvisible=false;
                $scope.textbx = "";
                $scope.btnText = 'Calculate';
                $scope.plotvalues = [];                
                $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft, $scope.actualright,'');
                $scope.graphPlotted = false;
                if($scope.onloadParentSelection)
                {
                    $scope.onloadParentSelection = false;
                    delete $scope.advertiserId;
                    console.log("clearing parent selection advertiserId - no child");
                }
                console.log("No Child");
            }
			
        };

        $scope.readadcampaigninsightsforParent = function(currentParentChildren){  
            if(($scope.from == undefined || $scope.from == "")  && ($scope.to == undefined || $scope.to =="")){
                var promises = [];               
                $scope.campaignInsightsUnavailableCount = 0;                               
                var spend = [];                
                for(i=0;i<$scope.dateArray.length;i++){
                    var obj = {
                        "date":$scope.dateArray[i],
                        "spend":0,
                        "actions":0,
                        "clicks":0,
                        "impressions":0
                    };
                    spend.push(obj);
                }
                for(i=0;i<currentParentChildren.length;i++){
                    (function(i){
                        if(currentParentChildren[i].networkURL == appSettings.fbNetwork){
                        promises.push(performanceServices.readadcampaigninsights(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.fromDate,$scope.toDate,undefined,'DAILY',appSettings.fbNetwork,true).then(function(response){
                            if(response.appStatus == 0){
                               // $rootScope.progressLoader = "none";
                                var resp = response.adCampaignInsights;
                                angular.forEach(resp,function(val,key){
                                    angular.forEach(val,function(val2,key2){
                                        angular.forEach(val2,function(val3,key3){
                                                for (j = 0; j < $scope.dateArray.length; j++) {
                                                    var date;
                                                    if ((Object.keys(val2)[0]).length == 10) {
                                                        date = $filter('date')((Object.keys(val2)[0]) * 1000, 'yyyy-MM-dd');
                                                    } else {
                                                        date = $filter('date')((Object.keys(val2)[0]), 'yyyy-MM-dd');
                                                    }
                                                    if ($scope.dateArray[j] == date) {
                                                        for (l = 0; l < spend.length; l++) {
                                                            if ($scope.dateArray[j] == spend[l].date) {
                                                                spend[l].spend = spend[l].spend + val3.spend;
                                                                spend[l].impressions = spend[l].impressions + val3.impressions;
                                                                spend[l].clicks = spend[l].clicks + val3.clicks;
                                                                spend[l].actions = spend[l].actions + val3.callToAction;
                                                            }
                                                        }
                                                    }
                                                }
                                        });
                                    });
                                });
                            }
                            else
                            {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                               /* $rootScope.progressLoader = "none";
                                $scope.editAdsetErrorMsg = 'block';
                                if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                        } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                        }
                                } else {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.errorMessage;
                                }*/
								angular.forEach($scope.networkmaparray,function(key){
								       for(k=0;k<key.networkDetails.length;k++){
										   if(currentParentChildren[i].userNetworkMapId == key.networkDetails[k].userNetworkMapId){
												 $scope.adDetails = key.networkDetails[k];
												  $scope.networkDetails = key;												
										   }
									   }
								})

								console.log("NO CHILD ")
                               $scope.errors.push({"category":"parentCampaign","network":$scope.networkDetails,"advertiserDetails": $scope.adDetails,"campaignDetails":currentParentChildren[i],"networkURL":appSettings.fbNetwork,"parentID":currentParentChildren[i].parentid,"parentCamp":$scope.wholeParentArray,"errorMsg":response.errorMessage});
                               console.log($scope.errors);
							   }
                            }
                        }));
                    }
                   else if(currentParentChildren[i].networkURL == appSettings.twNetwork){
                        promises.push(performanceServices.readadcampaigninsights(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.fromDate,$scope.toDate,undefined,'DAILY',appSettings.twNetwork,true).then(function(response){
                            if(response.appStatus == 0){
                               // $rootScope.progressLoader = "none";
                                var resp = response.adCampaignInsights;
                                angular.forEach(resp,function(val,key){
                                    angular.forEach(val,function(val2,key2){
                                        angular.forEach(val2,function(val3,key3){
                                                for (j = 0; j < $scope.dateArray.length; j++) {
                                                    var date;
                                                    if ((Object.keys(val2)[0]).length == 10) {
                                                        date = $filter('date')((Object.keys(val2)[0]) * 1000, 'yyyy-MM-dd');
                                                    } else {
                                                        date = $filter('date')((Object.keys(val2)[0]), 'yyyy-MM-dd');
                                                    }
                                                    if ($scope.dateArray[j] == date) {
                                                        for (l = 0; l < spend.length; l++) {
                                                            if ($scope.dateArray[j] == spend[l].date) {
                                                                spend[l].spend = spend[l].spend + val3.spend;
                                                                spend[l].impressions = spend[l].impressions + val3.impressions;
                                                                spend[l].clicks = spend[l].clicks + val3.clicks;
                                                                spend[l].actions = spend[l].actions + val3.callToAction;
                                                            }
                                                        }
                                                    }
                                                }
                                        });
                                    });
                                });
                            }
                            else
                            {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
							
								angular.forEach($scope.networkmaparray,function(key){
								       for(q=0;q<key.networkDetails.length;q++){
										   if(currentParentChildren[i].userNetworkMapId == key.networkDetails[q].userNetworkMapId){
												 $scope.adDetails = key.networkDetails[q];
												  $scope.networkDetails = key;												
										   }
									   }
								})

								console.log("NO INSIGHTS TWITTER")
                               $scope.errors.push({"category":"parentCampaign","network":$scope.networkDetails,"advertiserDetails": $scope.adDetails,"campaignDetails":currentParentChildren[i],"networkURL":appSettings.twNetwork,"parentID":currentParentChildren[i].parentid,"parentCamp":$scope.wholeParentArray,"errorMsg":response.errorMessage});
                               console.log($scope.errors);
							
                             /*   $rootScope.progressLoader = "none";
                                $scope.editAdsetErrorMsg = 'block';
                                if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                        } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                        }
                                } else {
                                       $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.errorMessage;
                                }*/
                        }
                            }
                        }));
                    }
                    })(i);
                }
                $q.all(promises).finally(
                    function(){
                        $scope.readAccountBudgetforParent(currentParentChildren,spend);
						$scope.handlingErrors();
                    }
                );
            }
            else{//FROM AND TO DATES SELECTED
                var promises = [];
                var userNetMapId;
                var spendUnique = [];
                var spendAll = [];
                var flag = 0;
                var dates = [];                
                if($scope.breakdown == "DAILY")
                {
                    var currentDate = new Date($scope.UTCFromDate);
                    while (currentDate <= new Date($scope.UTCToDate))
                    {
                        var d = new Date(currentDate)
                        var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                        var obj = {
                           "date":currentDate1,
                           "spend":0,
                           "impressions":0,
                           "clicks":0,
                           "actions":0
                        };
                        dates.push(obj);
                        currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                    }
                }               
                for(var i=0;i<currentParentChildren.length;i++){
                    (function(i){
                        if(currentParentChildren[i].networkURL == appSettings.fbNetwork)
                        {
                        promises.push(performanceServices.readadcampaigninsights(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.UTCFromDate,$scope.UTCToDate,undefined,$scope.breakdown,appSettings.fbNetwork,false).then(function(response){
                            if(response.appStatus == 0){                                                               
                                var resp = response.adCampaignInsights;                                
                                angular.forEach(resp,function(val,key){
                                    angular.forEach(val,function(val2,key2){
                                        angular.forEach(val2,function(val3,key3){
                                            if($scope.breakdown != "DAILY"){
                                                actions = 0;                                              
                                                var keyValue21 = key3.split('_').join(' ');
                                                var obj = {
                                                    "date":keyValue21,
                                                    "spend":0,
                                                    "impressions":0,
                                                    "clicks":0,
                                                    "actions":0
                                                }
                                                for(i = 0 ;i<spendUnique.length;i++)
                                                {
                                                    if(obj.date == spendUnique[i].date)
                                                    {
                                                        flag=1;
                                                    }
                                                }
                                                if(spendUnique.length == 0 || flag==0)
                                                {
                                                    spendUnique.push(obj);
                                                }                                                
                                                var obj2 = {
                                                    "date":keyValue21,
                                                    "spend":val3.spend,
                                                    "impressions":val3.impressions,
                                                    "clicks":val3.clicks,
                                                    "actions":val3.callToAction
                                                };
                                                spendAll.push(obj2);
                                            }
                                            else if($scope.breakdown == "DAILY"){                                    
                                                var d;
                                                    if ((Object.keys(val2)[0]).length == 10) {
                                                        d = $filter('date')(key3 * 1000, 'yyyy-MM-dd');
                                                    } else {
                                                        d = $filter('date')(key3, 'yyyy-MM-dd');
                                                    }
                                                for(i=0;i<dates.length;i++)
                                                {
                                                    if(dates[i].date==d)
                                                    {                                                         
                                                        var obj={
                                                            "date":dates[i].date,
                                                            "spend":val3.spend,
                                                            "impressions":val3.impressions,
                                                            "clicks":val3.clicks,
                                                            "actions":val3.callToAction
                                                        };
                                                        spendAll.push(obj);
                                                    }
                                                    else
                                                    {
                                                        var obj={
                                                            "date":dates[i].date,
                                                            "spend":0,
                                                            "impressions":0,
                                                            "clicks":0,
                                                            "actions":0
                                                        };
                                                        spendAll.push(obj);
                                                    }
                                                }
                                            }
                                        });
                                    });
                                });
                            }
                            else{
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                            } else {
								
								angular.forEach($scope.networkmaparray,function(key){
								       for(i=0;i<key.networkDetails.length;i++){
										   if(currentParentChildren[i].userNetworkMapId == key.networkDetails[i].userNetworkMapId){
												 $scope.adDetails = key.networkDetails[i];
												  $scope.networkDetails = key;												
										   }
									   }
								})

								 $scope.errors.push({"category":"parentCampaign","network":$scope.networkDetails,"advertiserDetails": $scope.adDetails,"campaignDetails":currentParentChildren[i],"networkURL":appSettings.fbNetwork,"parentID":currentParentChildren[i].parentid,"parentCamp":$scope.wholeParentArray,"errorMsg":response.errorMessage});
								
                                  /*  $rootScope.progressLoader = "none";
                                    $scope.editAdsetErrorMsg = 'block';
                                    if (response.networkError != '' && response.networkError != undefined) {
                                           if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    $scope.errorpopupHeading = 'Error';
                                                   $scope.errorMsg = response.networkError.message;
                                            } else {
                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                    $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                    } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                    }*/
                            }
                            }
                        }));
                    }
                    else if(currentParentChildren[i].networkURL == appSettings.twNetwork)
                    {
                        promises.push(performanceServices.readadcampaigninsights(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.UTCFromDate,$scope.UTCToDate,undefined,$scope.breakdown,appSettings.twNetwork,false).then(function(response){
                            if(response.appStatus == 0){                                                               
                                var resp = response.adCampaignInsights;                                
                                angular.forEach(resp,function(val,key){
                                    angular.forEach(val,function(val2,key2){
                                        angular.forEach(val2,function(val3,key3){
                                            if($scope.breakdown != "DAILY"){
                                                actions = 0;                                              
                                                var keyValue21 = key3.split('_').join(' ');
                                                var obj = {
                                                    "date":keyValue21,
                                                    "spend":0,
                                                    "impressions":0,
                                                    "clicks":0,
                                                    "actions":0
                                                }
                                                for(i = 0 ;i<spendUnique.length;i++)
                                                {
                                                    if(obj.date == spendUnique[i].date)
                                                    {
                                                        flag=1;
                                                    }
                                                }
                                                if(spendUnique.length == 0 || flag==0)
                                                {
                                                    spendUnique.push(obj);
                                                }                                               
                                                var obj2 = {
                                                    "date":keyValue21,
                                                    "spend":val3.spend,
                                                    "impressions":val3.impressions,
                                                    "clicks":val3.clicks,
                                                    "actions":val3.callToAction
                                                };
                                                spendAll.push(obj2);
                                            }
                                            else if($scope.breakdown == "DAILY"){                                               
                                                var d;
                                                    if ((Object.keys(val2)[0]).length == 10) {
                                                        d = $filter('date')(key3 * 1000, 'yyyy-MM-dd');
                                                    } else {
                                                        d = $filter('date')(key3, 'yyyy-MM-dd');
                                                    }
                                                for(i=0;i<dates.length;i++)
                                                {
                                                    if(dates[i].date==d)
                                                    {
                                                        var obj={
                                                            "date":dates[i].date,
                                                            "spend":val3.spend,
                                                            "impressions":val3.impressions,
                                                            "clicks":val3.clicks,
                                                            "actions":val3.callToAction
                                                        };
                                                        spendAll.push(obj);
                                                    }
                                                    else
                                                    {
                                                        var obj={
                                                            "date":dates[i].date,
                                                            "spend":0,
                                                            "impressions":0,
                                                            "clicks":0,
                                                            "actions":0
                                                        };
                                                        spendAll.push(obj);
                                                    }
                                                }
                                            }
                                        });
                                    });
                                });
                            }
                            else{
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                            } else {
									angular.forEach($scope.networkmaparray,function(key){
								       for(i=0;i<key.networkDetails.length;i++){
										   if(currentParentChildren[i].userNetworkMapId == key.networkDetails[i].userNetworkMapId){
												 $scope.adDetails = key.networkDetails[i];
												  $scope.networkDetails = key;												
										   }
									   }
								})

								 $scope.errors.push({"category":"parentCampaign","network":$scope.networkDetails,"advertiserDetails": $scope.adDetails,"campaignDetails":currentParentChildren[i],"networkURL":appSettings.twNetwork,"parentID":currentParentChildren[i].parentid,"parentCamp":$scope.wholeParentArray,"errorMsg":response.errorMessage});
								
								
								/*$rootScope.progressLoader = "none";
                                    $scope.editAdsetErrorMsg = 'block';
                                    if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.networkError.message;
                                            } else {
                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                    $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                    } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                    }*/
                            }
                            }
                        }));
                    }
                    })(i);
                }
                $q.all(promises).finally(
                    function(){                       
                        if($scope.breakdown != "DAILY")
                        {                          
                            for(i =0 ;i<spendUnique.length;i++)
                            {
                                for(j=0;j<spendAll.length;j++)
                                {
                                    if(spendUnique[i].date == spendAll[j].date)
                                    {
                                        spendUnique[i].spend = parseInt(spendUnique[i].spend) + parseInt(spendAll[j].spend);
                                        spendUnique[i].clicks = parseInt(spendUnique[i].clicks) + parseInt(spendAll[j].clicks);
                                        spendUnique[i].impressions = parseInt(spendUnique[i].impressions) + parseInt(spendAll[j].impressions);
                                        spendUnique[i].actions = parseInt(spendUnique[i].actions) + parseInt(spendAll[j].actions);
                                    }
                                }
                            }
                            $scope.readAccountBudgetforParent(currentParentChildren,spendUnique);
                        }
                        else if($scope.breakdown == "DAILY")
                        {                            
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spendAll.length;j++)
                                {
                                    if(dates[i].date == spendAll[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spendAll[j].spend);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spendAll[j].actions);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spendAll[j].impressions);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spendAll[j].clicks);                              
                                    }
                                }
                            }
                            $scope.readAccountBudgetforParent(currentParentChildren,dates);
                        }
							$scope.handlingErrors();
                    }
                );
            }
        };

        $scope.readAccountBudgetforParent = function(currentParentChildren,spend)
        {
            if(($scope.from == undefined || $scope.from == "")  && ($scope.to == undefined || $scope.to =="")){
                var budget = 0;
                var promises = [];
                for(i=0;i<currentParentChildren.length;i++)
                {
                    (function(i)
                    {
                        if(currentParentChildren[i].networkURL == appSettings.fbNetwork)
                        {
                        promises.push(performanceServices.getcampaignbudget(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.fbNetwork,true).then(function(response)
                        {
                            if(response.appStatus == 0)
                            {
                               // $rootScope.progressLoader = "none";
                                var resp = response.adcampaignbudget;
                                angular.forEach(resp,function(val,key)
                                {
                                    angular.forEach(val,function(val2,key2)
                                    {
                                        angular.forEach(val2,function(val3,key3)
                                        {
                                            angular.forEach(val3,function(val4,key4)
                                            {
                                                budget = budget + parseInt(val4.budget);
                                            });
                                        });
                                    });
                                });
                            }
                            else{
                               // $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                            } else {
                                   // $rootScope.progressLoader = "none";
                                    $scope.editAdsetErrorMsg = 'block';
                                    if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.networkError.message;
                                            } else {
                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                    $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                    } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                    }
                            }
                            }
                        }));
                    }
                    else if(currentParentChildren[i].networkURL == appSettings.twNetwork)
                    {
                        promises.push(performanceServices.getcampaignbudget(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.twNetwork,true).then(function(response)
                        {
                            if(response.appStatus == 0)
                            {
                                //$rootScope.progressLoader = "none";
                                var resp = response.adCampaignBudget;
                                angular.forEach(resp,function(val,key)
                                {
                                    angular.forEach(val,function(val2,key2)
                                    {
                                        angular.forEach(val2,function(val3,key3)
                                        {
                                            angular.forEach(val3,function(val4,key4)
                                            {
                                                budget = budget + parseInt(val4.budget);
                                            });
                                        });
                                    });
                                });
                            }
                            else{
                              //  $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                            } else {
                                  //  $rootScope.progressLoader = "none";
                                    $scope.editAdsetErrorMsg = 'block';
                                    if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = response.networkError.message;
                                            } else {
                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                    $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                    } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                    }
                            }
                            }
                        }));
                    }
                    })(i);
                }
                $q.all(promises).finally(
                    function()
                    {                        
                        var zero_count = 0;
                        var plot = [];
                        var expectedclicks = 0;
                        var expectedactions = 0;
                        var expectedimp = 0;
                        var cpc=0;
                        var cpa =0;
                        var cpm =0;
                        $scope.actualright = [];
                        $scope.actualleft = [];
                        $scope.expectedleft = [];
                        $scope.expectedright = [];
                        for(i = 1; i < spend.length; i++)
                        {
                            var obj = {
                                "date":spend[i].date,
                                "region":"actions",
                                "amount":spend[i].actions
                            };
                            plot.push(obj);
                            var obj = {
                                "date":spend[i].date,
                                "region":"spend",
                    "amount":spend[i].spend
                            };
                            plot.push(obj);
                            var _object = {
                    "date":spend[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);
                  var _obj = {
                    "date":spend[i].date,
                    "name":"spend",
                    "amount":spend[i].spend
                };
                $scope.actualleft.push(_obj)
                var obj = {
                    "date":spend[i].date,
                    "name":"clicks",
                    "amount":spend[i].clicks
                };
                $scope.actualright.push(obj);
                cpc = spend[i].spend/ spend[i].clicks;
                if(isNaN(cpc)){
                    expectedclicks = 0;
                }
                else{
                    expectedclicks = budget / cpc;
                }
                var object = {
                    "date":spend[i].date,
                    "name":"expectedclicks",
                    "amount":expectedclicks
                };
                $scope.expectedright.push(object);
                var obj = {
                    "date":spend[i].date,
                    "name":"impressions",
                    "amount":spend[i].impressions
                };
                $scope.actualright.push(obj);
                cpm = spend[i].spend/ (spend[i].impressions/1000);
                if(isNaN(cpm)){
                    expectedimp = 0;
                }
                else{
                                expectedimp= budget / cpm;
                            }
                            var object = {
                                "date":spend[i].date,
                                "name":"expectedimp",
                                "amount":expectedimp
                            };
                            $scope.expectedright.push(object);
                            var obj = {
                                "date":spend[i].date,
                                "name":"actions",
                                "amount":spend[i].actions
                            };
                            $scope.actualright.push(obj);
                            cpa = spend[i].spend/ spend[i].actions;
                            if(isNaN(cpc)){
                                expectedactions = 0;
                            }
                            else{
                                expectedactions = budget / cpa;
                            }
                            var object = {
                                "date":spend[i].date,
                                "name":"expectedactions",
                                "amount":expectedactions
                            };
                            $scope.expectedright.push(object);
                        }
                                               
                        for(i=0;i<spend.length;i++)
                        {
                            var d = spend[i].date;
                            d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                            spend[i].date = d;
                        }
                        $scope.spendComparison = spend;                        
                        $scope.plotvalues = plot;            
                        $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                    }
                );
            }
            else{              
                var spendTemp= [];
                var obj ={
                         "date":0,
                         "spend":0,
                         "impressions":0,
                         "clicks":0,
                         "actions":0
                };
                spendTemp.push(obj);
                for(i=0;i<spend.length;i++)
                {
                    spendTemp.push(spend[i]);
                }               
                var budget = 0;
                var promises = [];
                for(i=0;i<currentParentChildren.length;i++)
                {
                    (function(i)
                    {
                        if (currentParentChildren[i].networkURL == appSettings.fbNetwork)
                        {
                            promises.push(performanceServices.getcampaignbudget(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function (response)
                            {
                                if (response.appStatus == 0)
                                {

                                    var resp = response.adcampaignbudget;
                                    angular.forEach(resp, function (val, key)
                                    {
                                        angular.forEach(val,function(val2,key2)
                                        {
                                            angular.forEach(val2,function(val3,key3)
                                            {
                                                angular.forEach(val3,function(val4,key4)
                                                {
                                                    budget = budget + parseInt(val4.budget);
                                                });
                                            });
                                        });
                                    });
                                } else {
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                                     //   $rootScope.progressLoader = "none";
                                        $scope.editAdsetErrorMsg = 'block';
                                        if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                            } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                        } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                        }
                                    }
                                }
                            }));
                        }
                        else if (currentParentChildren[i].networkURL == appSettings.twNetwork)
                        {
                            promises.push(performanceServices.getcampaignbudget(currentParentChildren[i].userNetworkMapId,currentParentChildren[i].id,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function (response)
                            {
                                if (response.appStatus == 0)
                                {

                                    var resp = response.adCampaignBudget;
                                    angular.forEach(resp, function (val, key)
                                    {
                                        angular.forEach(val,function(val2,key2)
                                        {
                                            angular.forEach(val2,function(val3,key3)
                                            {
                                                angular.forEach(val3,function(val4,key4)
                                                {
                                                    budget = budget + parseInt(val4.budget);
                                                });
                                            });
                                        });
                                    });
                                } else {
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                                      //  $rootScope.progressLoader = "none";
                                        $scope.editAdsetErrorMsg = 'block';
                                        if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                            } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                        } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                        }
                                    }
                                }
                            }));
                        }
                    })(i);
                }
                $q.all(promises).finally(
                    function()
                    {
                        if($scope.breakdown == "WEEKLY")
                        {
                            budget = budget * 7;
                        }
                        else if($scope.breakdown == "MONTHLY")
                        {
                            budget = budget * 30;
                        }
                        else if($scope.breakdown == "QUARTERLY")
                        {
                            budget = budget * 90;
                        }
                        else if($scope.breakdown == "HALFYEARLY")
                        {
                            budget = budget * 180;
                        }
                        else if($scope.breakdown == "YEARLY")
                        {
                            budget = budget * 365;
                        }                        
                        var zero_count = 0;
                        var plot = []; 
                        $scope.actualright = [];
                        $scope.actualleft = [];
                        $scope.expectedleft = [];
                        $scope.expectedright = [];
                        var expectedclicks = 0;
                        var expectedactions = 0;
                        var expectedimp = 0;
                        var cpc=0;
                        var cpa =0;
                        var cpm =0;                        
                        for(i = 1; i < spendTemp.length; i++)
                         {
                            var obj = {
                                "date":spendTemp[i].date,
                                "region":"actions",
                                "amount":spendTemp[i].actions
                            };
                            plot.push(obj);
                            var obj = {
                                "date":spendTemp[i].date,
                                "region":"spend",
                                "amount":spendTemp[i].spend
                            };
                            plot.push(obj);
                            var _object = {
                    "date":spendTemp[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);
                 var _object = {
                    "date":spendTemp[i].date,
                    "name":"spend",
                    "amount":spendTemp[i].spend
                };
                $scope.actualleft.push(_object);
                var obj = {
                    "date":spendTemp[i].date,
                   "name":"clicks",
                   "amount":spendTemp[i].clicks
               };
               $scope.actualright.push(obj);
               cpc = spendTemp[i].spend/ spendTemp[i].clicks;
               if(isNaN(cpc)){
                   expectedclicks = 0;
               }
               else{
                   expectedclicks = budget / cpc;
               }
               var object = {
                   "date":spendTemp[i].date,
                   "name":"expectedclicks",
                   "amount":expectedclicks
               };
               $scope.expectedright.push(object);
               var obj = {
                   "date":spendTemp[i].date,
                   "name":"impressions",
                   "amount":spendTemp[i].impressions
               };
               $scope.actualright.push(obj);
               cpm = spendTemp[i].spend/ (spendTemp[i].impressions/1000);
               if(isNaN(cpm)){
                   expectedimp = 0;
               }
               else{
                   expectedimp= budget / cpm;
               }
               var object = {
                   "date":spendTemp[i].date,
                   "name":"expectedimp",
                   "amount":expectedimp
               };
               $scope.expectedright.push(object);
               var obj = {
                   "date":spendTemp[i].date,
                   "name":"actions",
                   "amount":spendTemp[i].actions
               };
               $scope.actualright.push(obj);
               cpa = spendTemp[i].spend/ spendTemp[i].actions;
               if(isNaN(cpc)){
                   expectedactions = 0;
               }
               else{
                   expectedactions = budget / cpa;
               }
               var object = {
                   "date":spendTemp[i].date,
                   "name":"expectedactions",
                   "amount":expectedactions
               };
               $scope.expectedright.push(object);
           } 
           if($scope.breakdown == "DAILY")
           {
               for(i=0;i<spendTemp.length;i++)
                            {
                                var d = spendTemp[i].date;
                                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                                spendTemp[i].date = d;
                            }
                        }
                        $scope.spendComparison = spendTemp;
                         $scope.plotvalues = plot;            
                        $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                    }
                );   
            }
            if($scope.onloadParentSelection)
            {
                console.log("clearing parent selection advertiser Id");
                $scope.onloadParentSelection = false;
                delete $scope.advertiserId;
            }
        };
        $scope.arrowDirectionChange = function (parentobj, _index) {

            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                {
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        };

        $scope.childselection = function (_obj)
        {            
            if(_obj.networkURL == appSettings.twNetwork){
                $scope.lineplotted = false;
            }
            
            $scope.selectedParentChildCampaign = _obj;
            $rootScope.progressLoader = "block";
             $scope.Isvisible=false;
             $scope.textbx = "";
             $scope.btnText = 'Calculate';   
            $scope.bool[_obj.parentid] = true;            
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != _obj.parentid)
                {
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.selectedvalue = '';
            $scope.selectedvalue = _obj.name;
            $scope.readadcampaignbudgetforchild(_obj);
        };
        
        $scope.readadcampaignbudgetforchild = function(_obj)
        {
          if(($scope.from == undefined || $scope.from == "")  && ($scope.to == undefined || $scope.to =="")){
              if(_obj.networkURL == appSettings.fbNetwork)
              {
               var budget = 0;
                performanceServices.getcampaignbudget(_obj.userNetworkMapId,_obj.id,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.fbNetwork,true).then(function(response)
                {
                    if(response.appStatus == 0)
                    {
                        var resp = response.adcampaignbudget;
                        angular.forEach(resp,function(val,key)
                        {
                            angular.forEach(val,function(val2,key2)
                            {
                                angular.forEach(val2,function(val3,key3)
                                {
                                    angular.forEach(val3,function(val4,key4)
                                    {
                                        budget = budget + parseInt(val4.budget);
                                    });
                                });
                            });
                        });
                        $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId,_obj,budget);
                    }
                    else{
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                           // $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.networkError.message;
                                    } else {
                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                            $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }
                        }
                        budget = 0;
                        $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId,_obj,budget);
                    }
                });
            }
             else if(_obj.networkURL == appSettings.twNetwork)
              {
               var budget = 0;
                performanceServices.getcampaignbudget(_obj.userNetworkMapId,_obj.id,$scope.fromDate,$scope.toDate,'YEARLY',appSettings.twNetwork,true).then(function(response)
                {
                    if(response.appStatus == 0)
                    {
                        var resp = response.adCampaignBudget;
                        angular.forEach(resp,function(val,key)
                        {
                            angular.forEach(val,function(val2,key2)
                            {
                                angular.forEach(val2,function(val3,key3)
                                {
                                    angular.forEach(val3,function(val4,key4)
                                    {
                                        budget = budget + parseInt(val4.budget);
                                    });
                                });
                            });
                        });
                        $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId,_obj,budget);
                    }
                    else{
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                           // $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.networkError.message;
                                    } else {
                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                            $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }
                        }
                        budget = 0;
                        $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId,_obj,budget);
                    }
                });
            }
            }
            else{
                if (_obj.networkURL == appSettings.fbNetwork)
                {
                    var budget = 0;
                    performanceServices.getcampaignbudget(_obj.userNetworkMapId,_obj.id,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.fbNetwork,false).then(function (response)
                    {
                        if (response.appStatus == 0)
                        {
                            var resp = response.adcampaignbudget;
                            angular.forEach(resp, function (val, key)
                            {
                                angular.forEach(val,function(val2,key2)
                                {
                                    angular.forEach(val2,function(val3,key3)
                                    {
                                        angular.forEach(val3,function(val4,key4)
                                        {
                                            budget = budget + parseInt(val4.budget);
                                        });
                                    });
                                });
                            });
                            if ($scope.breakdown == "WEEKLY")
                            {
                                budget = budget * 7;
                            } else if ($scope.breakdown == "MONTHLY")
                            {
                                budget = budget * 30;
                            } else if ($scope.breakdown == "QUARTERLY")
                            {
                                budget = budget * 90;
                            } else if ($scope.breakdown == "HALFYEARLY")
                            {
                                budget = budget * 180;
                            } else if ($scope.breakdown == "YEARLY")
                            {
                                budget = budget * 365;
                            }
                            $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId, _obj, budget);
                        } else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
                                $rootScope.progressLoader = "none";
                                $scope.editAdsetErrorMsg = 'block';
                                if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.networkError.message;
                                    } else {
                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                        $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                                } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                                }
                            }
                            budget = 0;
                            $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId, _obj, budget);
                        }
                    });
                }
                if (_obj.networkURL == appSettings.twNetwork)
                {
                    var budget = 0;
                    performanceServices.getcampaignbudget(_obj.userNetworkMapId,_obj.id,$scope.UTCFromDate,$scope.UTCToDate,'YEARLY',appSettings.twNetwork,false).then(function (response)
                    {
                        if (response.appStatus == 0)
                        {
                            var resp = response.adCampaignBudget;
                            angular.forEach(resp, function (val, key)
                            {
                                angular.forEach(val,function(val2,key2)
                                {
                                    angular.forEach(val2,function(val3,key3)
                                    {
                                        angular.forEach(val3,function(val4,key4)
                                        {
                                            budget = budget + parseInt(val4.budget);
                                        });
                                    });
                                });
                            });
                            if ($scope.breakdown == "WEEKLY")
                            {
                                budget = budget * 7;
                            } else if ($scope.breakdown == "MONTHLY")
                            {
                                budget = budget * 30;
                            } else if ($scope.breakdown == "QUARTERLY")
                            {
                                budget = budget * 90;
                            } else if ($scope.breakdown == "HALFYEARLY")
                            {
                                budget = budget * 180;
                            } else if ($scope.breakdown == "YEARLY")
                            {
                                budget = budget * 365;
                            }
                            $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId, _obj, budget);
                        } else {
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
                                $rootScope.progressLoader = "none";
                                $scope.editAdsetErrorMsg = 'block';
                                if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                        $scope.errorpopupHeading = 'Error';
                                        $scope.errorMsg = response.networkError.message;
                                    } else {
                                        $scope.errorpopupHeading = response.networkError.error_user_title;
                                        $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                                } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                              }
                            }
                            budget = 0;
                            $scope.readadcampaigninsightsforchild(_obj.userNetworkMapId, _obj, budget);
                        }
                    });
                }
            }
        };
        
        $scope.readadcampaigninsightsforchild = function(userNetMapId,_obj,budget)
        {   
            console.log("read campaign insights for child here");
            if(($scope.from == undefined || $scope.from == "")  && ($scope.to == undefined || $scope.to =="")){
                var spend = [];
                var zero_count = 0;                              
                for(i=0;i<$scope.dateArray.length;i++)
                {
                    var obj = {
                        "date":$scope.dateArray[i],
                        "spend":0,
                        "clicks":0,
                        "actions":0,
                        "impressions":0
                    };
                    spend.push(obj);
                }               
                if(_obj.networkURL == appSettings.fbNetwork)
                {
                    performanceServices.readadcampaigninsights(userNetMapId,_obj.id,$scope.fromDate,$scope.toDate,undefined,'DAILY',appSettings.fbNetwork,true).then(function(response)
                    {
                        if(response.appStatus == 0)
                        {
                            var resp = response.adCampaignInsights;
                            angular.forEach(resp,function(val,key)
                            {
                                angular.forEach(val,function(val2,key2)
                                {
                                    angular.forEach(val2,function(val3,key3)
                                    {
                                        for(j=0;j<$scope.dateArray.length;j++)
                                        {
                                            var date = $filter('date')(((Object.keys(val2)[0])*1000),'yyyy-MM-dd');
                                            var date;
                                                    if ((Object.keys(val2)[0]).length == 10) {
                                                        d = $filter('date')((Object.keys(val2)[0]) * 1000, 'yyyy-MM-dd');
                                                    } else {
                                                        d = $filter('date')((Object.keys(val2)[0]), 'yyyy-MM-dd');
                                                    }
                                            if($scope.dateArray[j] == date)
                                            {
                                                for(l=0;l<spend.length;l++)
                                                {
                                                    if($scope.dateArray[j] == spend[l].date)
                                                    {                                                             
                                                            spend[l].spend = spend[l].spend + val3.spend;
                                                            spend[l].impressions = spend[l].impressions + val3.impressions;
                                                            spend[l].clicks = spend[l].clicks+ val3.clicks;
                                                            spend[l].actions = spend[l].actions +val3.callToAction;
                                                }
                                            }
                                        }
                                    }
                                });
                            });
                        });
                    }
                        
                    else{
//                        
                        $rootScope.progressLoader = "none";
                        $scope.graphPlotted = false;
                        $scope.spendComparison = [];
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.networkError.message;
                                    } else {
                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                            $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }
                        }
                    }
                    var plot = [];
                        var cpc = 0;
                        var cpm =0;
                        var cpa =0;
                        var expectedactions =0 ;
                        var expectedimp =0;
                        var expectedclicks =0;
                        $scope.expectedleft =[];
                        $scope.expectedright = [];
                        $scope.actualleft = [];
                        $scope.actualright = [];
                        for(i = 1; i < spend.length; i++){
                            var obj = {
                                "date":spend[i].date,
                                "region":"actions",
                                "amount":spend[i].actions
                            };
                            plot.push(obj);
                            var object = {
                                "date":spend[i].date,
                                "name":"spend",
                                "amount":spend[i].spend
                            };
                            $scope.actualleft.push(object);
                            var _object = {
                                "date":spend[i].date,
                                "name":"budget",
                                "amount":budget
                            };
                            $scope.expectedleft.push(_object);
                            cpc = spend[i].spend / spend[i].clicks;
                            if(isNaN(cpc)){ 
                                expectedclicks = 0;
                            }
                            else{ 
                                expectedclicks= budget/cpc;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedclicks",
                                "amount":expectedclicks
                            }
                            var _act = {
                                "date":spend[i].date,
                                "name":"clicks",
                                "amount":spend[i].clicks
                            }
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            cpm = spend[i].spend / (spend[i].impressions/1000);
                            if(isNaN(cpm)){
                                expectedimp = 0;
                            }
                            else{
                                expectedimp= budget/cpm;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedimp",
                                "amount":expectedimp
                            }
                            var _act = {
                                "date":spend[i].date,
                                "name":"impressions",
                                "amount":spend[i].impressions
                            }
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            cpa = spend[i].spend / spend[i].actions;
                            if(isNaN(cpa)){
                                expectedactions = 0;
                            }
                            else{
                                expectedactions = budget/cpa;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedactions",
                                "amount":expectedactions
                            }
                            var _act = {
                                "date":spend[i].date,
                                "name":"actions",
                                "amount":spend[i].actions
                            }
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            var obj = {
                                "date":spend[i].date,
                                "region":"spend",
                                "amount":spend[i].spend
                            };
                            plot.push(obj); 
                        } 
                        $scope.spendComparison = spend; 
                        $scope.plotvalues = plot;                        
                        $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                    
                });
            }
            else // FOR TWITTER CAMPAIGNS(WHEN FROM AND TO DATES NOT SELECTED
            {
                performanceServices.readadcampaigninsights(userNetMapId,_obj.id,$scope.fromDate,$scope.toDate,undefined,'DAILY',appSettings.twNetwork,true).then(function(response)
                {
                    if(response.appStatus == 0)
                    {
                        var resp = response.adCampaignInsights;
                        angular.forEach(resp,function(val,key)
                        {
                            angular.forEach(val,function(val2,key2)
                            {
                                angular.forEach(val2,function(val3,key3)
                                {
                                    for(j=0;j<$scope.dateArray.length;j++)
                                    {
                                        var date;
                                        if((Object.keys(val2)[0]).length == 10)
                                        {
                                          date = $filter('date')(((Object.keys(val2)[0])*1000),'yyyy-MM-dd');  
                                        }
                                        else{
                                           date = $filter('date')((Object.keys(val2)[0]),'yyyy-MM-dd'); 
                                        }                                       
                                        if($scope.dateArray[j] == date)
                                        {
                                            for(l=0;l<spend.length;l++)
                                            {
                                                if($scope.dateArray[j] == spend[l].date)
                                                {
                                                    spend[l].spend = spend[l].spend + val3.spend;
                                                    spend[l].impressions = spend[l].impressions + val3.impressions;
                                                    spend[l].clicks = spend[l].clicks + val3.clicks;
                                                    spend[l].actions = spend[l].actions + val3.callToAction;
                                                }
                                            }
                                        }
                                    }
                                });
                            });
                        });                        
                    }
                    else{
                     //   $rootScope.progressLoader = "none";
                        $scope.graphPlotted = false;
                        $scope.spendComparison = [];
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.networkError.message;
                                    } else {
                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                            $scope.errorMsg = response.networkError.error_user_msg;
                                    }
                            } else {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.errorMessage;
                            }
                        }
                    }
                    var plot = [];
                        var cpc = 0;
                        var cpm =0;
                        var cpa =0;
                        var expectedactions =0 ;
                        var expectedimp =0;
                        var expectedclicks =0;
                        $scope.expectedleft =[];
                        $scope.expectedright = [];
                        $scope.actualleft = [];
                        $scope.actualright = [];                        
                        for(i = 1; i < spend.length; i++){ 
                            var obj = {
                                "date":spend[i].date,
                                "region":"actions",
                                "amount":spend[i].actions
                            };
                            plot.push(obj);
                            var object = {
                                "date":spend[i].date,
                                "name":"spend",
                                "amount":spend[i].spend
                            };
                            $scope.actualleft.push(object);
                            var _object = {
                                "date":spend[i].date,
                                "name":"budget",
                                "amount":budget
                            };
                            $scope.expectedleft.push(_object);
                            cpc = spend[i].spend / spend[i].clicks;
                            if(isNaN(cpc)){ 
                                expectedclicks = 0;
                            }
                            else{ 
                                expectedclicks= budget/cpc;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedclicks",
                                "amount":expectedclicks
                            }
                            var _act = {
                                "date":spend[i].date,
                                "name":"clicks",
                                "amount":spend[i].clicks
                            };
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            cpm = spend[i].spend / (spend[i].impressions/1000);
                            if(isNaN(cpm)){
                                expectedimp = 0;
                            }
                            else{
                                expectedimp= budget/cpm;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedimp",
                                "amount":expectedimp
                            };
                            var _act = {
                                "date":spend[i].date,
                                "name":"impressions",
                                "amount":spend[i].impressions
                            }
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            cpa = spend[i].spend / spend[i].actions;
                            if(isNaN(cpa)){
                                expectedactions = 0;
                            }
                            else{
                                expectedactions = budget/cpa;
                            }
                            var _obj={
                                "date":spend[i].date,
                                "name":"expectedactions",
                                "amount":expectedactions
                            }
                            var _act = {
                                "date":spend[i].date,
                                "name":"actions",
                                "amount":spend[i].actions
                            }
                            $scope.expectedright.push(_obj);
                            $scope.actualright.push(_act);
                            var obj = {
                                "date":spend[i].date,
                                "region":"spend",
                                "amount":spend[i].spend
                            };
                            plot.push(obj); 
                        } 
                        $scope.spendComparison = spend; 
                        $scope.plotvalues = plot;              
                        $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                });
            }  
            }
            
            else{//FROM AND TO SELECTED
                var spend = [];
                var zero_count = 0;
                var dates = [];
                if($scope.breakdown == "DAILY")
                {
                    var currentDate = new Date($scope.UTCFromDate);
                    while (currentDate <= new Date($scope.UTCToDate))
                    {
                        var d = new Date(currentDate)
                        var currentDate1 =  d.getFullYear() + '-' + ((d.getMonth()+1)>9?(d.getMonth()+1) :"0"+ (d.getMonth()+1)) + '-'+ (d.getDate()>9?d.getDate() : "0"+d.getDate());
                        var obj = {
                           "date":currentDate1,
                           "spend":0,
                           "clicks":0,
                           "actions":0,
                           "impressions":0
                        };
                        dates.push(obj);
                        currentDate = new Date(new Date(currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                    }                   
                }
                if(_obj.networkURL == appSettings.fbNetwork)//FB FOR FROM AND TO DATES
                {
                performanceServices.readadcampaigninsights(userNetMapId,_obj.id,$scope.UTCFromDate,$scope.UTCToDate,undefined,$scope.breakdown,appSettings.fbNetwork,false).then(function(response){
                    if(response.appStatus == 0){
                        var resp = response.adCampaignInsights;                       
                        angular.forEach(resp,function(val,key){
                            angular.forEach(val,function(val2,key2){
                                angular.forEach(val2,function(val3,key3){
                                    if($scope.breakdown != "DAILY")
                                    {                                        
                                        var keyValue2 = key3.split('_').join(' ');
                                        var obj = {
                                            'date':keyValue2,
                                            'spend':val3.spend,
                                            'clicks':val3.clicks,
                                            'impressions':val3.impressions,
                                            'actions':val3.callToAction
                                        };
                                        spend.push(obj);
                                    }
                                    else if($scope.breakdown == "DAILY")
                                    {
                                        var d;
                                        if(key3.length == 10){
                                           d = $filter('date')(key3*1000,'yyyy-MM-dd');  
                                        }
                                        else{
                                             d = $filter('date')(key3,'yyyy-MM-dd');
                                        }
                                        for(i=0;i<dates.length;i++)
                                        {
                                            if(dates[i].date==d)
                                            {                                                 
                                                var obj={
                                                    "date":dates[i].date,
                                                    "spend":val3.spend,
                                                    'clicks':val3.clicks,
                                                   'impressions':val3.impressions,
                                                   'actions':val3.callToAction
                                                };
                                                spend.push(obj);
                                            }
                                            else
                                            {
                                                var obj={
                                                    "date":dates[i].date,
                                                    "spend":0,
                                                    "clicks":0,
                                                    "impressions":0,
                                                    "actions":0
                                                };
                                                spend.push(obj);
                                            }
                                        }
                                    }
                                });
                            });
                        });
                        if($scope.breakdown == "DAILY")
                        {
                            zero_count = 0;
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spend.length;j++)
                                {
                                    if(dates[i].date == spend[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spend[j].spend);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spend[j].clicks);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spend[j].impressions);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spend[j].actions);
                                    }
                                }
                            }                            
                            var spendTemp = [];
                            var obj = {
                                "date":0,
                                "spend":0,
                                "clicks":0,
                                "impresssions":0,
                                "actions":0
                            };
                            spendTemp.push(obj);
                            for(i=0;i<dates.length;i++)
                            {
                                spendTemp.push(dates[i]);
                            }                           
                            var plot = [];                                                  
                            var cpc = 0;
                            var cpm =0;
                            var cpa =0;
                            var expectedactions =0 ;
                            var expectedimp =0;
                            var expectedclicks =0;
                            $scope.expectedright =[];
                            $scope.expectedleft = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            for(i = 1; i < spendTemp.length; i++){               
                var obj = {
                    "date":spendTemp[i].date,
                    "region":"actions",
                    "amount":spendTemp[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spendTemp[i].date,
                    "name":"spend",
                    "amount":spendTemp[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date":spendTemp[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);                
                cpc = spendTemp[i].spend / spendTemp[i].clicks;                
                if(isNaN(cpc)){                    
                    expectedclicks = 0;
                }
                else{                    
                    expectedclicks= budget/cpc;
                }
                var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedclicks",
                    "amount":expectedclicks
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"clicks",
                    "amount":spendTemp[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpm = spendTemp[i].spend / (spendTemp[i].impressions/1000);
                    if(isNaN(cpm)){
                        expectedimp = 0;
                    }
                    else{
                        expectedimp= budget/cpm;
                    }
                    var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedimp",
                    "amount":expectedimp
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"impressions",
                    "amount":spendTemp[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = spendTemp[i].spend / spendTemp[i].actions;
                   if(isNaN(cpa)){
                       expectedactions = 0;
                   }
                   else{
                       expectedactions = budget/cpa;
                   }
                  var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedactions",
                    "amount":expectedactions
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"actions",
                    "amount":spendTemp[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date":spendTemp[i].date,
                    "region":"spend",
                    "amount":spendTemp[i].spend
                };
                plot.push(obj);                
            }            
            for(i=0;i<spendTemp.length;i++)
            {
                var d = spendTemp[i].date;
                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                spendTemp[i].date = d;
            }
            $scope.spendComparison = spendTemp;
            $scope.plotvalues = plot;
            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
        }
        else if($scope.breakdown != "DAILY")
        {
            zero_count = 0;
            var spendTemp = [];
            var obj = {
                "date":0,
                "spend":0,
                "clicks":0,
                "impressions":0,
                "actions":0
            };
            spendTemp.push(obj);
            var plot = [];
            var cpc = 0;
            var cpm =0;
            var cpa =0;
            var expectedactions =0 ;
            var expectedimp =0;
            var expectedclicks =0;
            $scope.expectedright =[];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            $scope.actualright = [];
            for(i=0;i<spend.length;i++)
            {
                spendTemp.push(spend[i]);
            }
            for(i = 1; i < spendTemp.length; i++)
            {
                var obj = {
                    "date":spendTemp[i].date,
                    "region":"actions",
                    "amount":spendTemp[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spendTemp[i].date,
                    "name":"spend",
                    "amount":spendTemp[i].spend
                     };
                     $scope.actualleft.push(object);
                     var _object = {
                         "date":spendTemp[i].date,
                         "name":"budget",
                         "amount":budget
                     };
                     $scope.expectedleft.push(_object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "region":"spend",
                         "amount":spendTemp[i].spend
                     };
                     plot.push(obj);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"clicks",
                         "amount":spendTemp[i].clicks
                     };
                     $scope.actualright.push(obj);
                     cpc = spendTemp[i].spend/ spendTemp[i].clicks;
                     if(isNaN(cpc)){
                         expectedclicks = 0;
                     }
                     else{
                         expectedclicks = budget / cpc;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedclicks",
                         "amount":expectedclicks
                     };
                     $scope.expectedright.push(object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"impressions",
                         "amount":spendTemp[i].impressions
                     };
                     $scope.actualright.push(obj);
                     cpm = spendTemp[i].spend/ (spendTemp[i].impressions/1000);
                     if(isNaN(cpm)){
                         expectedimp = 0;
                     }
                     else{
                         expectedimp= budget / cpm;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedimp",
                         "amount":expectedimp
                     };
                     $scope.expectedright.push(object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"actions",
                         "amount":spendTemp[i].actions
                     };
                     $scope.actualright.push(obj);
                     cpa = spendTemp[i].spend/ spendTemp[i].actions;
                     if(isNaN(cpc)){
                         expectedactions = 0;
                     }
                     else{
                         expectedactions = budget / cpa;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedactions",
                         "amount":expectedactions
                     };
                     $scope.expectedright.push(object);
                 }
                 for(i = 1;i<spendTemp.length;i++)
                 {
                     if(spendTemp[i].spend == 0)
                     {
                         zero_count++;
                     }
                 }
                 $scope.spendComparison = spendTemp; 
                 $scope.plotvalues = plot;
                 $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
             }
         }
         else{
             $scope.spendComparison = [];
            $scope.plotvalues = [];
            $scope.expectedleft = [];
            $scope.expectedright = [];
            $scope.actualleft = [];
            $scope.actualright = [];
            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
//             $scope.spendComparison = [];
            // $rootScope.progressLoader = "none";
             $scope.linePlotted = false;
             if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                 $window.localStorage.setItem("TokenExpired", true);
                 $state.go('login');
             } else {
                 $rootScope.progressLoader = "none";
                 $scope.editAdsetErrorMsg = 'block';
                 if (response.networkError != '' && response.networkError != undefined) {
                     if (response.networkError.message != '' && response.networkError.message != undefined) {
                         $scope.errorpopupHeading = 'Error';
                         $scope.errorMsg = response.networkError.message;
                     } else {
                         $scope.errorpopupHeading = response.networkError.error_user_title;
                         $scope.errorMsg = response.networkError.error_user_msg;
                     }
                 } else {
                     $scope.errorpopupHeading = 'Error';
                    $scope.errorMsg = response.errorMessage;
                 }
             }
         }
     });
 }
 else//(_obj.networkURL == appSettings.twNetwork)//TW FOR FROM AND TO DATES
 {
                performanceServices.readadcampaigninsights(userNetMapId,_obj.id,$scope.UTCFromDate,$scope.UTCToDate,undefined,$scope.breakdown,appSettings.twNetwork,false).then(function(response){
                    if(response.appStatus == 0){
                        var resp = response.adCampaignInsights;                       
                        angular.forEach(resp,function(val,key){
                            angular.forEach(val,function(val2,key2){
                                angular.forEach(val2,function(val3,key3){
                                    if($scope.breakdown != "DAILY")
                                    {
                                        var keyValue2 = key3.split('_').join(' ');
                                        var obj = {
                                            'date':keyValue2,
                                            'spend':val3.spend,
                                            'clicks':val3.clicks,
                                            'impressions':val3.impressions,
                                            'actions':val3.callToAction
                                        };
                                        spend.push(obj);
                                    }
                                    else if($scope.breakdown == "DAILY")
                                    {
                                       var d;
                                        if(key3.length == 10){
                                           d = $filter('date')(key3*1000,'yyyy-MM-dd');  
                                        }
                                        else{
                                             d = $filter('date')(key3,'yyyy-MM-dd');
                                        }
                                        for(i=0;i<dates.length;i++)
                                        {
                                            if(dates[i].date==d)
                                            {
                                                var obj={
                                                    "date":dates[i].date,
                                                    "spend":val3.spend,
                                                    'clicks':val3.clicks,
                                                   'impressions':val3.impressions,
                                                   'actions':val3.callToAction
                                                };
                                                spend.push(obj);
                                            }
                                            else
                                            {
                                                var obj={
                                                    "date":dates[i].date,
                                                    "spend":0,
                                                    "clicks":0,
                                                    "impressions":0,
                                                    "actions":0
                                                };
                                                spend.push(obj);
                                            }
                                        }
                                    }
                                });
                            });
                        });
                        if($scope.breakdown == "DAILY")
                        {
                            zero_count = 0;
                            for(i =0 ;i<dates.length;i++)
                            {
                                for(j=0;j<spend.length;j++)
                                {
                                    if(dates[i].date == spend[j].date)
                                    {
                                        dates[i].spend = parseInt(dates[i].spend) + parseInt(spend[j].spend);
                                        dates[i].clicks = parseInt(dates[i].clicks) + parseInt(spend[j].clicks);
                                        dates[i].impressions = parseInt(dates[i].impressions) + parseInt(spend[j].impressions);
                                        dates[i].actions = parseInt(dates[i].actions) + parseInt(spend[j].actions);
                                    }
                                }
                            }                            
                            var spendTemp = [];
                            var obj = {
                                "date":0,
                                "spend":0,
                                "clicks":0,
                                "impresssions":0,
                                "actions":0
                            };
                            spendTemp.push(obj);
                            for(i=0;i<dates.length;i++)
                            {
                                spendTemp.push(dates[i]);
                            }                           
                            var plot = [];                                                  
                            var cpc = 0;
                            var cpm =0;
                            var cpa =0;
                            var expectedactions =0 ;
                            var expectedimp =0;
                            var expectedclicks =0;
                            $scope.expectedright =[];
                            $scope.expectedleft = [];
                            $scope.actualleft = [];
                            $scope.actualright = [];
                            for(i = 1; i < spendTemp.length; i++){               
                            var obj = {
                    "date":spendTemp[i].date,
                    "region":"actions",
                    "amount":spendTemp[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spendTemp[i].date,
                    "name":"spend",
                    "amount":spendTemp[i].spend
                };
                $scope.actualleft.push(object);
                var _object = {
                    "date":spendTemp[i].date,
                    "name":"budget",
                    "amount":budget
                };
                $scope.expectedleft.push(_object);                
                cpc = spendTemp[i].spend / spendTemp[i].clicks;                
                if(isNaN(cpc)){                    
                    expectedclicks = 0;
                }
                else{                    
                    expectedclicks= budget/cpc;
                }
                var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedclicks",
                    "amount":expectedclicks
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"clicks",
                    "amount":spendTemp[i].clicks
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpm = spendTemp[i].spend / (spendTemp[i].impressions/1000);
                    if(isNaN(cpm)){
                        expectedimp = 0;
                    }
                    else{
                        expectedimp= budget/cpm;
                    }
                    var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedimp",
                    "amount":expectedimp
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"impressions",
                    "amount":spendTemp[i].impressions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                cpa = spendTemp[i].spend / spendTemp[i].actions;
                   if(isNaN(cpa)){
                       expectedactions = 0;
                   }
                   else{
                       expectedactions = budget/cpa;
                   }
                  var _obj={
                    "date":spendTemp[i].date,
                    "name":"expectedactions",
                    "amount":expectedactions
                }
                var _act = {
                    "date":spendTemp[i].date,
                    "name":"actions",
                    "amount":spendTemp[i].actions
                }
                $scope.expectedright.push(_obj);
                $scope.actualright.push(_act);
                var obj = {
                    "date":spendTemp[i].date,
                    "region":"spend",
                    "amount":spendTemp[i].spend
                };
                plot.push(obj);                
            }
            for(i = 1;i<spendTemp.length;i++)
            {
                if(spendTemp[i].spend == 0)
                {
                    zero_count++;
                }
            }
            for(i=0;i<spendTemp.length;i++)
            {
                var d = spendTemp[i].date;
                d = new Date(d).getDate() + "-" + new Date(d).toLocaleString('en-us', { month: "short" });
                spendTemp[i].date = d;
            }
            $scope.spendComparison = spendTemp;
            $scope.plotvalues = plot;
            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
        }
        else if($scope.breakdown != "DAILY")
        {
            zero_count = 0;
            var spendTemp = [];
            var obj = {
                "date":0,
                "spend":0,
                "clicks":0,
                "impressions":0,
                "actions":0
            };
            spendTemp.push(obj);
            var plot = [];
            var cpc = 0;
            var cpm =0;
            var cpa =0;
            var expectedactions =0 ;
            var expectedimp =0;
            var expectedclicks =0;
            $scope.expectedright =[];
            $scope.expectedleft = [];
            $scope.actualleft = [];
            $scope.actualright = [];
            for(i=0;i<spend.length;i++)
            {
                spendTemp.push(spend[i]);
            }
            for(i = 1; i < spendTemp.length; i++)
            {
                var obj = {
                    "date":spendTemp[i].date,
                    "region":"actions",
                    "amount":spendTemp[i].actions
                };
                plot.push(obj);
                var object = {
                    "date":spendTemp[i].date,
                    "name":"spend",
                    "amount":spendTemp[i].spend
                     };
                     $scope.actualleft.push(object);
                     var _object = {
                         "date":spendTemp[i].date,
                         "name":"budget",
                         "amount":budget
                     };
                     $scope.expectedleft.push(_object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "region":"spend",
                    "amount":spendTemp[i].spend
                     };
                     plot.push(obj);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"clicks",
                         "amount":spendTemp[i].clicks
                     };
                     $scope.actualright.push(obj);
                     cpc = spendTemp[i].spend/ spendTemp[i].clicks;
                     if(isNaN(cpc)){
                         expectedclicks = 0;
                     }
                     else{
                         expectedclicks = budget / cpc;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedclicks",
                         "amount":expectedclicks
                     };
                     $scope.expectedright.push(object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"impressions",
                         "amount":spendTemp[i].impressions
                     };
                     $scope.actualright.push(obj);
                     cpm = spendTemp[i].spend/ (spendTemp[i].impressions/1000);
                     if(isNaN(cpm)){
                         expectedimp = 0;
                     }
                     else{
                         expectedimp= budget / cpm;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedimp",
                         "amount":expectedimp
                     };
                     $scope.expectedright.push(object);
                     var obj = {
                         "date":spendTemp[i].date,
                         "name":"actions",
                         "amount":spendTemp[i].actions
                     };
                     $scope.actualright.push(obj);
                     cpa = spendTemp[i].spend/ spendTemp[i].actions;
                     if(isNaN(cpc)){
                         expectedactions = 0;
                     }
                     else{
                         expectedactions = budget / cpa;
                     }
                     var object = {
                         "date":spendTemp[i].date,
                         "name":"expectedactions",
                         "amount":expectedactions
                     };
                     $scope.expectedright.push(object);
                 }
                 for(i = 1;i<spendTemp.length;i++)
                 {
                     if(spendTemp[i].spend == 0)
                     {
                         zero_count++;
                     }
                 }
                 $scope.spendComparison = spendTemp; 
                 $scope.plotvalues = plot;
                 $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
             }
         }
         else{
             $scope.spendComparison = [];
            // $rootScope.progressLoader = "none";
             $scope.graphPlotted = false;
             if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                 $window.localStorage.setItem("TokenExpired", true);
                 $state.go('login');
             } else {
	$rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'block';
                                                if (resp.networkError != '' && resp.networkError != undefined) {
                                                    if (resp.networkError.message != '' && resp.networkError.message != undefined) {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = resp.networkError.message;
                                                    } else {
                                                        $scope.errorpopupHeading = resp.networkError.error_user_title;
                                                        $scope.errorMsg = resp.networkError.error_user_msg;
                                                    }
                                                } else {
                                                    $scope.errorpopupHeading = 'Error';
                                                    $scope.errorMsg = resp.errorMessage;
                                                }
             }
         }
     });
 }
 }
 if($scope.onloadChildSelection)
 {
     console.log("clearing child selection advertiser Id");
     $scope.onloadChildSelection = false;
     delete $scope.advertiserId;
 }
 };
 
$scope.setUserIdAndAccessToken = function() {
    performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
    $scope.getaccountdetails();
};
 
        $scope.loadCurrencyCode = function()
        {
            performanceServices.loadcurrencydata().then(function(response) {
                $scope.currencyList = response.currencyList;
                $scope.setUserIdAndAccessToken();
            });
        };
        $scope.plotbulletchart = function(expectedleft,expectedright,actualleft,actualright,breakdown)
        { 
             var flag=0;
             var set =0;
			 console.log("RIGHT DATA");
			 console.log(actualright);
            if(expectedleft.length == 0){
               $scope.graphPlotted = false;
               $("#bulletChartLeft1").empty();
               $("#bulletChartRight1").empty();
               $("#bulletDate").empty();
               $("#bulletChartLeft").empty();
               $("#bulletChartRight").empty();           
            }            
            else{
                 $scope.graphPlotted = true;
            
               // $rootScope.progressLoader = "block";
                $scope.leftactualData = [];
                $scope.rightactualData = [];
                $scope.rightexpData = [];
                $scope.leftexpData = []; 
                if($scope.breakdown == 'DAILY'){
                 if($scope.kpi == 'clicks'){
                      angular.forEach(actualright, function (val, key) {                    
                        var d_date;
                        if(val.name == 'clicks'){
                        d_date =$filter('date')(val.date,'MMM-dd');                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedclicks'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });
                     
                 }else if($scope.kpi == 'impressions'){
                      angular.forEach(actualright, function (val, key) {                    
                        var d_date;
                        if(val.name == 'impressions'){
                        d_date = $filter('date')(val.date,'MMM-dd');                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedimp'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });
                     
                 }else{
                      angular.forEach(actualright, function (val, key) {                   
                        var d_date;
                        if(val.name == 'actions'){
                         d_date =$filter('date')(val.date,'MMM-dd');                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedactions'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });                  
                 }   
             }
              else{
                 if($scope.kpi == 'clicks'){
                      
                      angular.forEach(actualright, function (val, key) {                    
                        var d_date;
                        if(val.name == 'clicks'){
                        d_date = val.date;                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedclicks'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });
                     
                 }else if($scope.kpi == 'impressions'){
                      angular.forEach(actualright, function (val, key) {                    
                        var d_date;
                        if(val.name == 'impressions'){
                        d_date = val.date;                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedimp'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });
                     
                 }else{
                      angular.forEach(actualright, function (val, key) {                   
                        var d_date;
                        if(val.name == 'actions'){
                        d_date = val.date;                       
                        var r_obj = [{"rightactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.rightactualData.push(r_obj);
                        }
                        });
                        
                        angular.forEach(expectedright, function (val, key) {
                            if(val.name == 'expectedactions'){
                         var r_obj = [{"rightexpdata": Math.round(val.amount)},{"rightoldexpdata": Math.round(val.amount)}];
                            $scope.rightexpData.push(r_obj);
                        }
                        });                  
                 }   
             }
                        
                //taking spend value        
            angular.forEach(actualleft, function (val, key) {                            
                             var d_date;
                             d_date = val.date;                       
                        var r_obj = [{"leftactualdata": Math.round(val.amount)}, {"validdate": d_date}];
                            $scope.leftactualData.push(r_obj);
                        });                    
            
            //taking budget value         
            angular.forEach(expectedleft, function (val, key) {
                         var r_obj = [{"leftexpdata": Math.round(val.amount)},{"leftoldexpdata": Math.round(val.amount)}];
                            $scope.leftexpData.push(r_obj);
                        });
                //GREEN GRAPH
                $("#bulletChartLeft").empty();
                $("#bulletChartLeft1").empty();
                $("#bulletChartRight1").empty();                
               // $rootScope.progressLoader = "block";
                for (var i = 0; i < $scope.leftactualData.length; i++) {                    
                    
                    if($scope.leftactualData[i][0].leftactualdata == 0 && $scope.leftexpData[i][0].leftexpdata == 0){
                        set++;
                    try{
                        var bar_graph = cviz.widget.BulletChart.Runner({
                        id : '1',
                        container : {
                              id : '#bulletChartLeft', 
                              title : "",//$scope.leftactualData[i][1].validdate,
                              titleWidth : 80,
                              textToChart : 0.4, 
                              width : 323, 
                              height : 50
                             },   
                         bindings : {performanceMeasure :'leftactualdata'}, 
                         margin : {
                              top : 10,
                              right : 25,
                              bottom : 25,
                              left : 25
                            },
                          qualitativeMeasures: {
                               low : 1,
                               mid :0.001,
                               high : 0.001,
                               comparitive : 0.001
                             },
                           qualitativeMeasuresColors: {
                               low : '#90D3CD',
                               mid : '#90D3CD',
                               high : '#90D3CD'
                              
                              },
                           tooltip: {
                              comparitiveTitle : 'LeftTarget'
                             }
                            }).graph().render($scope.leftactualData[i]);
                            var length = $scope.rightactualData.length;
//                        $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("rect").attr("opacity","0");
//                        $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("line").attr("opacity","0"); 
//                        $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find(".tick").css("opacity","0"); 
                      //  $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("rect").css("opacity","0");
                       $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("rect").attr("opacity","0").attr("class", "range bad opacityStatus");
                        $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("line").attr("opacity","0").attr("class", "marker opacityStatus"); 
                        $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find(".tick").css("opacity","0").attr("class", "tick opacityStatus"); 
                        
                        }
                        catch(err){
                        console.log("budget zero = "+err);
                        }
                    var divText = $("#bulletChartLeft1").html();
                  $("#bulletChartLeft1").html(divText+"<div style='width:50%;height:55px;left:150px;font:12px Roboto-Light bold; top:15px; position:relative'>"+"No insights available!"+"</div>" );   
             
                }
                else{
                     var divText = $("#bulletChartLeft1").html();
               $("#bulletChartLeft1").html(divText+"<div style='width:50%;height:55px;left:150px;font:12px Roboto-Light bold; top:15px; position:relative'>"+" "+"</div>" );   
             
                    var max =0;
                    if($scope.leftexpData[i][0].leftexpdata > $scope.leftactualData[i][0].leftactualdata){
                        max = $scope.leftexpData[i][0].leftexpdata;
                    }
                    else{
                        max = $scope.leftactualData[i][0].leftactualdata;
                    }
                    if($scope.leftexpData[i][0].leftexpdata == 0){
                       $scope.leftexpData[i][0].leftexpdata=0.001;
                        $scope.leftexpData[i][1].leftoldexpdata = 0.001;//$scope.leftactualData[i][0].leftactualdata ;
                    }
                    if($scope.leftactualData[i][0].leftactualdata == 0){
                       $scope.leftactualData[i][0].leftactualdata=0.001;
//                        $scope.leftexpData[i][1].leftoldexpdata = 0.001;//$scope.leftactualData[i][0].leftactualdata ;
                    }                    
                    try{
                        var bar_graph = cviz.widget.BulletChart.Runner({
                        id : '1',
                        container : {
                              id : '#bulletChartLeft', 
                              title : "",
                              titleWidth : 80,
                              textToChart : 0.4, 
                              width : 323, 
                              height : 50
                             },   
                         bindings : {performanceMeasure :'leftactualdata'}, 
                         margin : {
                              top : 10,
                              right : 25,
                              bottom : 25,
                              left : 25
                            },
                          qualitativeMeasures: {
                               low : 1,
                               mid :$scope.leftexpData[i][0].leftexpdata,
                               high :max,
                               comparitive : $scope.leftexpData[i][1].leftoldexpdata
                             },
                           qualitativeMeasuresColors: {
                               low : '#90D3CD',
                               mid : '#90D3CD',
                               high : '#90D3CD'
                              
                              },
                           tooltip: {
                              comparitiveTitle : 'LeftTarget'
                             }
                            }).graph().render($scope.leftactualData[i]);                             
                            }catch(err){
                        console.log("budget zero = "+err);
                    }
                   $("#bulletChartLeft svg.bullet-chart").eq(i).find("g").find("rect").removeClass("opacityStatus");      
                }                
                  
            }
                 //DATE DATA
                $("#bulletDate").empty();
                $rootScope.progressLoader = "block";
                for (var j = 0; j < $scope.rightactualData.length; j++){
//                    if($scope.leftactualData[j][0].leftactualdata == 0 && $scope.leftexpData[j][0].leftexpdata == 0 && $scope.rightactualData[j][0].rightactualdata == 0 && $scope.rightexpData[j][0].rightexpdata == 0){
//                         var divText = $("#bulletDate").html();
//                    $("#bulletDate").html(divText+"<div style='width:100%;height:55px;font:15px Roboto-Light; top:15px; position:relative'>"+''+"</div>" );
//                }
//                    else{
                    var divText = $("#bulletDate").html();
                    $("#bulletDate").html(divText+"<div style='width:100%;height:55px;font:15px Roboto-Light; top:15px; position:relative'>"+$scope.rightactualData[j][1].validdate+"</div>" );
//                }
            }
              //  $rootScope.progressLoader = "none";
                 //END OF DATE DATA
            
            
            
           
                //PURPLE GRAPH
                $("#bulletChartRight").empty();
                $rootScope.progressLoader = "block";
                for (var j = 0; j < $scope.rightactualData.length; j++) {
                     if($scope.rightactualData[j][0].rightactualdata == 0 && $scope.rightexpData[j][0].rightexpdata == 0){
                         set++;
                    try{
                        var bar_graph = cviz.widget.BulletChart.Runner({
                        id : '2',
                        container : {
                              id : '#bulletChartRight', 
                              title : "",//$scope.rightactualData[j][1].validdate,
                              titleWidth : 80,
                              textToChart : 0.4, 
                              width : 323, 
                              height : 50
                             },   
                        bindings : {performanceMeasure :'rightactualdata'}, 
                        margin : {
                             top : 10, 
                             right : 25, 
                             bottom : 25, 
                             left : 25
                           },
                        qualitativeMeasures: {
                             low : 1,
                             mid : 0.001,//$scope.rightexpData[j][0].rightexpdata, 
                             high : 0.001,//$scope.rightexpData[j][0].rightexpdata,
                             comparitive :0.001
                           },
                         qualitativeMeasuresColors: {
                             low : '#c9aaff',
                             mid : '#c9aaff' ,
                             high : '#c9aaff'
                            },
                         tooltip: {
                            comparitiveTitle : 'RightTarget'
                           }
                          }).graph().render($scope.rightactualData[j]);
                          
                         $("#bulletChartRight svg.bullet-chart").eq(j).find("g").find("rect").attr("opacity","0").attr("class", "range bad opacityStatus");
                        $("#bulletChartRight svg.bullet-chart").eq(j).find("g").find("line").attr("opacity","0").attr("class", "marker opacityStatus"); 
                        $("#bulletChartRight svg.bullet-chart").eq(j).find("g").find(".tick").css("opacity","0").attr("class", "tick opacityStatus"); 
                        
                        
                       
                        
                  }catch(err){
                      console.log("budget zero = "+err);
                  }
                   var divText1 = $("#bulletChartRight1").html();
                  $("#bulletChartRight1").html(divText1+"<div style='width:50%;height:55px;left:150px;font:12px Roboto-Light bold; top:15px; position:relative'>"+"No insights available!"+"</div>" );   
              }
                
                else{
                     var divText1 = $("#bulletChartRight1").html();
                  $("#bulletChartRight1").html(divText1+"<div style='width:50%;height:55px;left:150px;font:12px Roboto-Light bold; top:15px; position:relative'>"+" "+"</div>" );   
              
                    var max =0;
                    if($scope.rightexpData[j][0].rightexpdata > $scope.rightactualData[j][0].rightactualdata){
                        max = $scope.rightexpData[j][0].rightexpdata;
                    }
                    else{
                        max = $scope.rightactualData[j][0].rightactualdata;
                    }
                                              
                        if($scope.rightexpData[j][0].rightexpdata == 0){
                       $scope.rightexpData[j][0].rightexpdata=0.001;
                        $scope.rightexpData[j][1].rightoldexpdata = 0.001;
                    }
                     if($scope.rightactualData[j][0].rightactualdata == 0){
                       $scope.rightactualData[j][0].rightactualdata=0.001;
                        $scope.rightexpData[j][1].rightoldexpdata = 0.001;
                    }                    
                    try{
                        var bar_graph = cviz.widget.BulletChart.Runner({
                        id : '2',
                        container : {
                              id : '#bulletChartRight', 
                              title :"",//$scope.rightactualData[j][1].validdate,
                              titleWidth : 80,
                              textToChart : 0.4, 
                              width : 323, 
                              height : 50
                             },   
                        bindings : {performanceMeasure :'rightactualdata'}, 
                        margin : {
                             top : 10, 
                             right : 25, 
                             bottom : 25, 
                             left : 25
                           },
                        qualitativeMeasures: {
                             low : 1,
                             mid : $scope.rightexpData[j][0].rightexpdata, 
                             high : max,
                             comparitive :$scope.rightexpData[j][1].rightoldexpdata
                           },
                         qualitativeMeasuresColors: {
                             low : '#c9aaff',
                             mid : '#c9aaff' ,
                             high : '#c9aaff'
                            },
                         tooltip: {
                            comparitiveTitle : 'RightTarget'
                           }
                          }).graph().render($scope.rightactualData[j]);
                          $("div.cviz-common.tool-tip").eq(j);
                      }catch(err){
                      console.log("budget zero = "+err);
                  }
                  
                  $("#bulletChartRight svg.bullet-chart").eq(j).find("g").find("rect").removeClass("opacityStatus");
                }
            }
                
            }
			if($scope.rightactualData){
            if(set == 2*$scope.rightactualData.length){
              $("#bulletChartLeft1").empty();
                $("#bulletChartRight1").empty();
                $("#bulletDate").empty();
            $scope.graphPlotted = false;
           // $scope.lineplotted = false;
			}
			}
        $rootScope.progressLoader = "none";        
        };
        $scope.btnchng = function(){
            $scope.btnText = 'Calculate';
        }
        $scope.resetCalender = function(param){
            $rootScope.progressLoader = "block";
            $scope.from = "";
            $scope.to = "";
            $scope.from1 = "";
            $scope.to1 = "";
            $scope.mindate = "";
            $scope.Isvisible = false;
            $scope.btnText = 'Calculate';
            $scope.textbx = "";
                                 
            if($scope.from == "" && $scope.to == ""){
                if($scope.advertiserId == undefined || $scope.advertiserId == "")
                {
                    if($scope.networkId == "" || $scope.networkId == undefined)
                    {
                        if($scope.selectedParentChildCampaign == undefined || $scope.selectedParentChildCampaign == "")
                        {
                             $rootScope.progressLoader = "block";
                            $scope.breakdown = "DAILY";
                            datedifference = 7;
                            $scope.wholeParentArray = $scope.wholeParentArrayOnLoad;
                            $scope.wholechildArray = $scope.wholeChildArrayOnLoad;
                            $scope.spendComparison = $scope.spendComparisonOnLoad;
                            $scope.plotvalues = $scope.plotvaluesOnLoad;
                            $scope.expectedleft = $scope.expectedleftOnLoad;
                            $scope.expectedright = $scope.expectedrightOnLoad;
                            $scope.actualleft = $scope.actualleftOnLoad ;
                            $scope.actualright = $scope.actualrightOnLoad;
                            $scope.plotbulletchart($scope.expectedleft,$scope.expectedright,$scope.actualleft,$scope.actualright,$scope.breakdown);
                            //$rootScope.progressLoader = 'none';
                        }
                        else
                        {
                            if($scope.selectedParentChildCampaign.type=="parent")
                            {
                                $scope.parentselection($scope.selectedParentChildCampaign);
                            }
                            else if($scope.selectedParentChildCampaign.type=="child")
                            {
                                $scope.childselection($scope.selectedParentChildCampaign);
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaign == undefined || $scope.selectedParentChildCampaign == "")
                        {
                            $scope.selectnetwork($scope.networkId);
                        }
                        else 
                        {
                            if($scope.selectedParentChildCampaign.type=="parent")
                            {
                                $scope.parentselection($scope.selectedParentChildCampaign);
                            }
                            else if($scope.selectedParentChildCampaign.type=="child")
                            {
                                $scope.childselection($scope.selectedParentChildCampaign);
                            } 
                        }
                        
                    }
                }
                else
                {
                    if($scope.networkId == "" || $scope.networkId == undefined)
                    {
                        if($scope.selectedParentChildCampaign == undefined || $scope.selectedParentChildCampaign == "")
                        {
                            $scope.breakdown = "DAILY";
                            datedifference = 7; 
                            $scope.selectadvertiser();
                        }
                        else
                        {
                            if($scope.selectedParentChildCampaign.type=="parent")
                            {
                                $scope.parentselection($scope.selectedParentChildCampaign);
                            }
                            else if($scope.selectedParentChildCampaign.type=="child")
                            {
                                $scope.childselection($scope.selectedParentChildCampaign);
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaign == undefined || $scope.selectedParentChildCampaign == "")
                        {
                            $scope.breakdown = "DAILY";
                            datedifference = 7; 
                            $scope.selectnetwork();
                        }
                        else
                        {
                            if($scope.selectedParentChildCampaign.type=="parent")
                            {
                                $scope.parentselection($scope.selectedParentChildCampaign);
                            }
                            else if($scope.selectedParentChildCampaign.type=="child")
                            {
                                $scope.childselection($scope.selectedParentChildCampaign);
                            }
                        } 
                    }
                }
            }
        };
        $scope.ondefaultload = function ()
        {
             $rootScope.progressLoader = "block";
            $scope.userRole = $window.localStorage.getItem("role");          
            if($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
            {
                $scope.accountRole = false;
            }
            $scope.loadCurrencyCode();
        };
        $scope.ondefaultload();
        $scope.resetPopup = function() {
            $scope.editAdsetErrorMsg = 'none';
        };
         $scope.textbx = "";
        $scope.novalue = false;
        $scope.btnText = 'Calculate';
        $scope.Isvisible = false;
         $scope.linevalues = [];       
        $scope.ShowHide = function() { 
           
            var amount=0;
            if ($scope.btnText == 'Calculate') {
                if ($scope.textbx == "") {
                    $scope.btnText = 'Calculate';
                } else {                    
                    angular.forEach($scope.plotvalues, function(key,val){ 
                       
                       amount= key.amount * $scope.textbx;

                        if(key.region == 'actions'){                             
                            $scope.final={
                                "date" :$filter('date')(key.date,'MMM-dd'),
                                "region":"actions",
                                "amount" : amount
                            };
                        }
                        else{
                            $scope.final={
                                "date" :$filter('date')(key.date,'MMM-dd'),
                                "region":"spend",
                                "amount" : key.amount
                            };
                        }
                        $scope.linevalues.push($scope.final);
                    });                   
                    $scope.plotlinechart($scope.linevalues);             
                    $scope.Isvisible = true;
                    $scope.btnText = 'Reset';
                    $scope.novalue = false;
                    $scope.linevalues = [];
                }
            } else if ($scope.btnText == 'Reset') {
                $scope.textbx = "";
                $scope.btnText = 'Calculate';
                $scope.Isvisible = false;
            }

        };
         $scope.legentText = "clicks";
        $scope.chooseKPI = function(kpi) {            
            $rootScope.progressLoader = "block";
            $scope.kpi = kpi;
            $scope.legentText = kpi;
            $scope.graphPlotted=false;
            $scope.spendComparison = [];             
            $scope.status = true;
            if($scope.selectedParentChildCampaign == "" || $scope.selectedParentChildCampaign == undefined){
                 $scope.selectnetwork();
            }
            else
            {
                if ($scope.selectedParentChildCampaign.type == "parent")
                {
                    console.log("parent selected no advertiser");
                    $scope.parentselection($scope.selectedParentChildCampaign);
                } else if ($scope.selectedParentChildCampaign.type == "child")
                {
                    console.log("child selected no advertiser");
                    $scope.childselection($scope.selectedParentChildCampaign);
                }
            }
        };


        
        //HANDLING ZOOMING EVENT FOR BULLET CHART
        var zoom = document.documentElement.clientWidth / window.innerWidth;
        $(window).resize(function () {
            var zoomNew = document.documentElement.clientWidth / window.innerWidth;
            if (zoom != zoomNew) {
                zoom = zoomNew;
                $("svg .bullet-chart").attr("width", "323");
                $("svg .bullet-chart").attr("height", "50");
                var a = $(".opacityStatus").attr("opacity", "0");
                $scope.plotbulletchart($scope.expectedleft, $scope.expectedright, $scope.actualleft, $scope.actualright, $scope.breakdown);
            }
        });
    }]).filter('capitalize', function() {
  return function(token) {
      return token.charAt(0).toUpperCase() + token.slice(1);
  };
});
dashboard.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                var clean = val.replace(/[^0-9]+/g, '');
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });
            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});