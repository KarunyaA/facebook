dashboard.controller("dashboardController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', '$timeout','performanceServices',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, $timeout,performanceServices) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;
        $scope.parenttoggle = true  ;
        $scope.noingightsparenttoday = false;
        $scope.noinsightsalladvToaday = false;
        $scope.noinsightsalladvOverall = false;
        $scope.noinsightsadvToaday = false;
        $scope.noinsightsadvOverall = false;
        $scope.noingightsoveralltoday = false;
        $scope.noingightschildtoday = false;
        $scope.noingightschildoverall = false;
        $scope.noingightsparentoverall=false;
        $scope.img = false;
        $scope.display=false;$scope.network=false;
        $scope.woserivce = false;
        $scope.wserivce = false;
        $scope.wcampaignserivceoverall = false;
        $scope.overallAllAdv = false;
        $scope.filldiv=true; $scope.network=false;
        $scope.arrowshow=true;
       var screenWidth= 1920
        $scope.accountRole=true;
        $scope.selectedParentCampaign="";
        $scope.selectedChildCampaign="";
        $scope.selectedcampaign = '';
        $scope.wholeParentArrayOnLoad = [];
        $scope.wholeChildArrayOnLoad = [];
        $scope.totalSpendforAllNetwork = 0;
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.networkDropDownOnLoad = [];
        $scope.campaignDropDown = [];
        $scope.advertiserSelect = [];
        $scope.Advertisers = [];
        $scope.dateArray = [];
        $scope.dateDiff = 0;
        $scope.monthDiff = 0;
        $scope.yearDiff = 0;
        $scope.networksforaccount = [];
        $scope.advertiserdetails = {};
        $scope.bool = [];
        $scope.networksarrayforacc =[];
        $scope.wholeParentArray = [];
        $scope.wholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkmaparray = [];
        $scope.networkmaparrayonload = [];
        var pieChart1, pieChart2, pieChart3, pieChart4;
        $scope.errors = [];
        var piechartrendercount = 0;
        //$scope.childselected = false;
        $scope.show=false;
        $scope.editAdsetErrorMsg = 'none';
        $scope.networkmaparrayonload = [];
        $scope.graphfacebook = true;
        $scope.count = 0;
         $scope.networksforaccount = [];
        $scope.closePopupDetails = function () {
            $scope.editAdsetErrorMsg = "none";
        }
         $scope.parentselect=false;
         $scope.overallData = false;
         $scope.currentData = true;
         $scope.flag=false;
         $scope.advertiser="";
        $scope.morecontibution=0;
        $scope.moreimpressions=0;
        $scope.moreclicks=0;
        $scope.moreactions=0;
        $scope.morespend=0;
        $scope.nettabselection = true;  
         $scope.overallAllAdv = false;
          $scope.woserivce = true;
        //NAV TABS VALIDATION
        $('.nav.nav-tabs > li').on('click', function (e) {
            $('.nav.nav-tabs > li').removeClass('active');
            $(this).addClass('active');

        });
        //NAV TABS VALIDATION

        //websql
         angular.element('#overall').css('background', '#ffffff');
              angular.element('#overall').css('color', '#000000');
              angular.element('#today').css('background', '#009688');
     //   var db = openDatabase('Insightsmapping', '1.0', 'LOCAL DB', 2 * 1024 * 1024);



            
     
        $scope.chartfacebookGraph = function ()
        {
            $scope.graphfacebook = true;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
        
           $(document).ready(function () {
    
        $('#tw').removeClass('selective');
        $('#twa').css("background", "#f0f0f0");
         $('#fba').css("background", "#e1e1e1");
   
        $('#fb').addClass('selective');
        
            });
             //  $scope.actualfacebookoverall($scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend);
            //$scope.graphtwitter=true;

        }
        $scope.charttwitterGraph = function ()
        {
            // console.log("twitter call is happening");
            $scope.graphfacebook = false;
            $scope.graphtwitter = true;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
            //$scope.graphtwitter=true;
           //  $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totalclicks, $scope.totaltwactions, $scope.totaltwspend);
      
           //     $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend);
           $(document).ready(function () {
  
        $('#fb').removeClass('selective');
        //   $('#a').css("background", "#e1e1e1");
        $('#tw').addClass('selective');
        $('#twa').css("background", "#e1e1e1");
         $('#fba').css("background", "#f0f0f0");
            });
        }

        $scope.chartinstagramGraph = function ()
        {
            $scope.graphfacebook = false;
            $scope.graphtwitter = false;
            $scope.graphinstagram = true;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
            //$scope.graphtwitter=true;

        }

        $scope.chartgoogleGraph = function () {
            $scope.graphfacebook = false;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = true;
            $scope.graphbing = false;
        }

        $scope.chartbingGraph = function () {
            $scope.graphfacebook = false;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = true;

        }
    
        //Handle errors
        
       $scope.handleErrors = function ()
        {
            var errorCheck = false;
            $scope.errorHeader = [];
            $scope.errorString = [];
            // console.log("lenght  " +$scope.errors.length);
         
           
           for (a = 0; a < $scope.errors.length; a++)
            {
                if ($scope.errors[a].hasOwnProperty("networkDetails"))
                {
                    for (b = 0; b < $scope.errors[a].networkDetails.length; b++)
                    {
                        var netLogo = "";
                        if ($scope.errors[a].networkDetails[b].networkURL == appSettings.fbNetwork)
                        {
                            netLogo = "images/accountDashboard/facebook.svg";
                        } else if ($scope.errors[a].networkDetails[b].networkURL == appSettings.twNetwork)
                        {
                            netLogo = "images/accountDashboard/twitter.svg";
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("adAccountIdError"))
                        {
                            
                            // console.log("adAccountIdError ");
                            errorCheck = true;
                            var obj = {
                                "Advertiser": "Advertiser: ",
                                "AdvertiserValue": $scope.errors[a].advertiserName,
                                "NetworkLogo": netLogo,
                                "ParentCampaign": "",
                                "ParentCampaignValue": "",
                                "ChildCampaign": "",
                                "ChildCampaignValue": ""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].adAccountIdError.ErrorMessage);
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("parentCampaignError"))
                        {
                            // console.log("parentCampaignError ");
                            errorCheck = true;
                            var obj = {
                                "Advertiser": "Advertiser: ",
                                "AdvertiserValue": $scope.errors[a].advertiserName,
                                "NetworkLogo": netLogo,
                                "ParentCampaign": "",
                                "ParentCampaignValue": "",
                                "ChildCampaign": "",
                                "ChildCampaignValue": ""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].parentCampaignError.ErrorMessage);
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("parent"))
                        {
                            for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++)
                            {
                                if ($scope.errors[a].networkDetails[b].parent[c].hasOwnProperty("childCampaignError"))
                                {
                                      // console.log("childCampaignError ");
                                    errorCheck = true;
                                    var obj = {
                                        "Advertiser": "Advertiser: ",
                                        "AdvertiserValue": $scope.errors[a].advertiserName,
                                        "NetworkLogo": netLogo,
                                        "ParentCampaign": "Parent Campaign: ",
                                        "ParentCampaignValue": $scope.errors[a].networkDetails[b].parent[c].name,
                                        "ChildCampaign": "",
                                        "ChildCampaignValue": ""
                                    };
                                    $scope.errorHeader.push(obj);
                                    $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].childCampaignError.ErrorMessage);
                                }
                                for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++)
                                {
                                    if ($scope.errors[a].networkDetails[b].parent[c].campaigns[d].hasOwnProperty("campaignInsightsError"))
                                    {
                                           // console.log("campaignInsightsError ");
                                        errorCheck = true;
                                        var obj = {
                                            "Advertiser": "Advertiser: ",
                                            "AdvertiserValue": $scope.errors[a].advertiserName,
                                            "NetworkLogo": netLogo,
                                            "ParentCampaign": "Parent Campaign: ",
                                            "ParentCampaignValue": $scope.errors[a].networkDetails[b].parent[c].name,
                                            "ChildCampaign": "Child Campaign: ",
                                            "ChildCampaignValue": $scope.errors[a].networkDetails[b].parent[c].campaigns[d].name
                                        };
                                        $scope.errorHeader.push(obj);
                                        $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].campaigns[d].campaignInsightsError.ErrorMessage);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (errorCheck)
            {
                angular.element("#errorScroll").css("height", "auto");
                angular.element("#errorScroll").css("overflow-y", "hidden");
                angular.element("#moreErrors").css("display", "flex");
                angular.element("#lessErrors").css("display", "none");
                $scope.campEffectReportErrors = 'block';
                angular.element("#campEffectReportErrors").empty();
                for (a = 0; a < $scope.errorHeader.length && a < 2; a++)
                {
                    angular.element("#campEffectReportErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:20px;background:#F5F5F5'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                            "</div>" +
                            "</div>" +
                            "</div>"
                            );
                }
            } else {
                // console.log("no errors");
            }
        };
        $scope.resetPopup = function () {
            $scope.editAdsetErrorMsg = 'none';
            $scope.campEffectReportErrors = "none";
            angular.element("#errorScroll").scrollTop(0);
        };
        


      //   $scope.campEffectReportErrors='block';
        
        //GET ACCOUNT DETAILS
        $scope.init = function () {
            var promises = [];
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.userRole = $window.localStorage.getItem("role");
            if($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
            {
                $scope.accountRole = false;
            }
            
            
            $scope.accountId = $window.localStorage.getItem("accountId");
            $scope.advertiserDetails = {};
            $scope.adverDetails = [];
            promises.push(performanceServices.getaccountdetails($scope.accountId).then(function (response) {
                if (response.appStatus == '0') {// success
                    $scope.accountName = response.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.accountFetchResponse.logoUrl;
                    $scope.downloadAccountLogo($scope.accountLogoUrl);

                } else {// failed
                    // console.log("failed");
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
        }
        $timeout(function () {
            $scope.init();
        }, 1500);


               //download accountlogo on load
        $scope.downloadAccountLogo = function (accountLogoUrl){
            var promises = [];
            promises.push(performanceServices.downloadimages(accountLogoUrl).then(function(response){
                if (response.appStatus == '0'){
                //    $rootScope.progressLoader = "none";
                    $scope.accountLogo = response.imageContent[$scope.accountLogoUrl];
                }
                else{
               //     $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        
                        
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.imageContent[$scope.accountLogoUrl].errorMessage;
                                    }
                                    $scope.errors["imageIdError"] = obj;
                                }
                        
                        
                
                    }
                }
            }));
            $q.all(promises).finally(
                function(){
                    $scope.getAdvertiserDetails();
                });
        };
        //GET ACCOUNT DETAILS
        //FetchAdvertiser
      
       $scope.getAdvertiserDetails = function () {
            $rootScope.progressLoader ="block";
           var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response) {
                if (response.appStatus == '0') { // success
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (getAdvertiserDetails)
                        {
                                $rootScope.progressLoader =false;
                            $scope.allnetworks();
                        }
                    });
        };

        $scope.allnetworks = function () {
            var allnetworks = false;
                $rootScope.progressLoader ="block";
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response) {
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (allnetworks)
                        {
                                $rootScope.progressLoader ="none";
                            $scope.networksforacc();
                        }
                    });
        };
        $scope.networksforacc = function ()
               {
           // // console.log("network networksforacc");
            var networksforaccount = false;
                $rootScope.progressLoader ="block";
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response) {
                if (response.appStatus == '0') { // success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                    for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                        angular.forEach($scope.allnetworksarray, function (val, key) {
                            if ($scope.networksarrayforacc[i].networkId == val.networkId) {
                                if (!$scope.networksforaccount.includes(val.networkName)) {
                                    var obj = {
                                        "networkName": val.networkName,
                                        "networkId": val.networkId
                                    };
                                    $scope.networksforaccount.push(obj);
                                }
                            }
                        });
                    }
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (networksforaccount)
                        {
                                $rootScope.progressLoader ="none";
                            // console.log("getusernetworkmapids call is happening");
                            $scope.getusernetworkmapids();
                        }
                    });
        };


        $scope.getusernetworkmapids = function ()
              {
                      $rootScope.progressLoader ="block";
            var promises = [];
            var readAdAccountSuccess = false;
            angular.forEach($scope.advertiserdetails, function (val, key) {
                var networkdetailobj = [];
                var i = 0;
                var obj = {
                    "advertiseremail": val.advertiserEmail,
                    "advertiserId": val.advertiserId,
                    "advertiserName": val.advertiserName
                };
             
                for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId) {
                        for (var j = 0; j < $scope.allnetworksarray.length; j++) {
                            if ($scope.allnetworksarray[j].networkId == $scope.networksarrayforacc[i].networkId) {
                                var obj2 = {
                                    "networkId": $scope.allnetworksarray[j].networkId,
                                    "networkName": $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId": $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL": $scope.allnetworksarray[j].networkUrl
                                    
                                };
                                networkdetailobj.push(obj2);
                            }
                        }
                        ;
                        obj['networkDetails'] = networkdetailobj;
                    }
                }
                $scope.networkmaparrayonload.push(obj);
            });
            $scope.errors = angular.copy($scope.networkmaparrayonload);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails')) {
                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                        (function (i, j) {
                            if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function (response) {
                                    if (response.appStatus == 0) {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.fbReadAdAccountResponse, function (value, key) {
                                            var parent = [];
                                            $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"] = response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                            $scope.errors[i].networkDetails[j]["adAccountId"] = response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.errors[i].networkDetails[j]["parent"] = angular.copy(parent);
                                        });
                                    } else {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.networkError.message;
                                                } else {
                                                    obj["Error"] = response.networkError.error_user_title;
                                                    obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } else {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            } else if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function (response) {
                                    if (response.appStatus == 0) {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.adAccounts, function (value, key) {
                                            angular.forEach(value, function (value2, key2) {
                                                //                                                // console.log(value2,key2);
                                                var parent = [];
                                                $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"] = value2.twAdAccountId;
                                                $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = "";
                                                $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                                $scope.errors[i].networkDetails[j]["adAccountId"] = value2.twAdAccountId;
                                                $scope.errors[i].networkDetails[j]["parent"] = angular.copy(parent);
                                            });
                                        });
                                    } else {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.networkError.message;
                                                } else {
                                                    obj["Error"] = response.networkError.error_user_title;
                                                    obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } else {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                        })(i, j);
                    }
                }
            }
            $q.all(promises).finally(
                    function () {
                               
                        if (readAdAccountSuccess) {
                            // console.log("fillDropDown call is happening");
                            $scope.fillDropDowns();
                             $rootScope.progressLoader ="none";
                        } else {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };



        $scope.fillDropDowns = function () {
            var promises = [];
              $rootScope.progressLoader ="block";
            //// console.log($scope.networkmaparrayonload.length);
            //($scope.networkmaparrayonload.length);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                
          var obj = {
                    "advertiserName": $scope.networkmaparrayonload[i].advertiserName,
                    "advertiserId": $scope.networkmaparrayonload[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
                
               // $scope.multiselectadvertiserDropDown.push(obj);
            }
          // // console.log($scope.advertiserDropDown);
            //===========================================================Network Drop Down==================================================================
      
            
            var parentSuccess = false;
         //   // console.log($scope.networkmaparrayonload.length);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                    (function (i) {
                        promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.networkmaparrayonload[i].advertiserId).then(function (response) {
                            if (response.appStatus == '0') { // success
                                parentSuccess = true;
                                $scope.campaigndetails = response.parentCampaigns;
                                for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                    if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                        for (var k = 0; k < $scope.campaigndetails.length; k++) {
                                            var _obj = {
                                                "id": $scope.campaigndetails[k].parentCampaignId,
                                                "name": $scope.campaigndetails[k].parentCampaignName,
                                                "type": "parent",
                                                "userNetworkMapId": $scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,
                                                "networkUrl": $scope.networkmaparrayonload[i].networkDetails[j].networkURL
                                            };
                                            $scope.wholeParentArray.push(_obj);
                                        }
                                    }
                                }
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    $scope.errors[i].networkDetails[j]['parentCampaignError'] = obj;
                                }
                            }
                        }));
                    })(i);
                }
            }
            ;
            $q.all(promises).finally(
                    function () {
                        for (a = 0; a < $scope.wholeParentArray.length; a++) {
                            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                        if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                            if ($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholeParentArray[a].userNetworkMapId) {
                                                var campaigns = [];
                                                var obj = {
                                                    "id": $scope.wholeParentArray[a].id,
                                                    "name": $scope.wholeParentArray[a].name,
                                                    "type": "Parent",
                                                    "campaigns": []
                                                };
                                                $scope.networkmaparrayonload[i].networkDetails[j].parent.push(obj);
                                                $scope.errors[i].networkDetails[j].parent.push(angular.copy(obj));
                                                //                                            }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                       // // console.log(parentSuccess.toString()); 
                        if (parentSuccess) {
                            //("fetchallchildandpush call is happening")
                             $rootScope.progressLoader ="none";
                            $scope.fetchallchildandpush();
                            
                        } else {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };
        
        
        $scope.wholechildArrayDropdown =[];
        var forchild=[];
        $scope.fetchallchildandpush = function () {
            var wholechildArray=[]; 
              $rootScope.progressLoader ="block";
            var promises = [];
            var campaignSuccess = false;
          //  // console.log($scope.wholeParentArray);
            for (i = 0; i < $scope.wholeParentArray.length; i++) {

                (function (i) {
                    //checking whether the parent network is Fb or twitter
                    if ($scope.wholeParentArray[i].networkUrl == appSettings.fbNetwork) {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork).then(function (response) {
                            if (response.appStatus == '0') {
                                campaignSuccess = true;
                                $scope.childCampaigns = response.adcampaigns;
                                var count = 0;
                                angular.forEach($scope.childCampaigns, function (value, key) {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) {
                                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].campaignId,
                                                "name": array[+j].campaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": array[+j].campaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl": $scope.wholeParentArray[i].networkUrl,
                                                "startDate": $filter('date')(array[+j].campaignDetails.start_time, 'yyyy-MMM-dd'),
                                                "endDate": $filter('date')(array[+j].campaignDetails.end_time, 'yyyy-MMM-dd'),
                                                "Objective": array[+j].campaignDetails.objective

                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                          //  $scope.wholechildArrayDropdown.push(_obj);
                                        }
                                    }
                                });
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for (a = 0; a < $scope.errors.length; a++) {
                                        if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                            for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId) {
                                                    for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                        if ($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id) {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    } 
                    else if ($scope.wholeParentArray[i].networkUrl == appSettings.twNetwork) {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork).then(function (response) {
                            if (response.appStatus == '0') {
                                campaignSuccess = true;
                                angular.forEach(response.campaign, function (value, key) {
                                    angular.forEach(value, function (value2, key2) {
                                        var _obj = {
                                            "id": value2.twCampaignDetails.id,
                                            "name": value2.twCampaignDetails.name,
                                            "type": "child",
                                            "parentid": $scope.wholeParentArray[i].id,
                                            "status": value2.twCampaignStatus,
                                            "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                            "networkUrl": $scope.wholeParentArray[i].networkUrl,
                                            "startDate": $filter('date')(value2.twCampaignDetails.start_time, 'yyyy-MMM-dd'),
                                            "endDate": $filter('date')(value2.twCampaignDetails.end_time, 'yyyy-MMM-dd'),
                                            "Objective": value2.twCampaignDetails.objective
                                        };
                                        $scope.wholechildArray.push(_obj);
                                    //     $scope.wholechildArrayDropdown.push(_obj);
                                    });
                                });
                                //                                $scope.wholechildArray.push(_obj);
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for (a = 0; a < $scope.errors.length; a++) {
                                        if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                            for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId) {
                                                    for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                        if ($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id) {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    }
                })(i);
            }
           
            $q.all(promises).finally(
                    function () {

                        if (campaignSuccess) {
                              $rootScope.progressLoader ="none";
                            forchild=angular.copy($scope.wholechildArray);
                            $scope.wholechildArrayDropdown=angular.copy($scope.wholechildArray);
                            for (a = 0; a < $scope.wholechildArray.length; a++) {
                                for (i = 0; i < $scope.networkmaparrayonload.length; i++) {

                                    if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {

                                        for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                            if ($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholechildArray[a].userNetworkMapId) {
                                                //pushing FB campaigns into struct array
                                                if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                    for (k = 0; k < $scope.networkmaparrayonload[i].networkDetails[j].parent.length; k++) {
                                                        if ($scope.networkmaparrayonload[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid) {
                                                           if($scope.wholechildArray[a].status!="DELETED") 
                                                            {
                                                            var insights = [];
                                                            var todayinsights=[];
                                                            var yesterdayinsight=[];
                                                            var obj = {
                                                                "id": $scope.wholechildArray[a].id,
                                                                "name": $scope.wholechildArray[a].name,
                                                                "parentId": $scope.wholechildArray[a].parentid,
                                                                "type": "child",
                                                                "campStartDate": $scope.wholechildArray[a].startDate,
                                                                "campEndDate": $scope.wholechildArray[a].endDate,
                                                                "objective": $scope.wholechildArray[a].Objective,
                                                                "status": $scope.wholechildArray[a].status,
                                                                "insights": insights,
                                                                "todayinsights":todayinsights,
                                                                "yesterdayinsight":yesterdayinsight
                                                            };
                                                            $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns.push(obj);
                                                            $scope.errors[i].networkDetails[j].parent[k].campaigns.push(angular.copy(obj));
                                                        }
                                                    }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            var nonUniqueParentArray = [];
                            var uniqueParentArray = [];
                            var uniqueParentObjects = [];
                            for (i = 0; i < $scope.wholeParentArray.length; i++) {
                                nonUniqueParentArray.push($scope.wholeParentArray[i].id);
                            }
                            uniqueParentArray = nonUniqueParentArray.filter(function (elem, index, self) {
                                return index == self.indexOf(elem);
                            });
                            for (i = 0; i < uniqueParentArray.length; i++) {
                                var obj = {
                                    "id": uniqueParentArray[i],
                                    "name": "",
                                    "type": "parent"
                                };
                                uniqueParentObjects.push(obj);
                            }
                            for (i = 0; i < uniqueParentObjects.length; i++) {
                                for (j = 0; j < $scope.wholeParentArray.length; j++) {
                                    if ($scope.wholeParentArray[j].id == uniqueParentObjects[i].id) {
                                        uniqueParentObjects[i].name = $scope.wholeParentArray[j].name;
                                    }
                                }
                            }
                            $scope.wholeParentArray = angular.copy(uniqueParentObjects);
                            $scope.wholeParentArrayOnLoad = angular.copy($scope.wholeParentArray);
                            $scope.wholeChildArrayOnLoad = angular.copy($scope.wholechildArray);
                            $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
                         //   // console.log($scope.wholechildArray);
                           //  // console.log($scope.wholechildArray.length+"  these are the child campaign"+JSON.stringify($scope.wholechildArray,null,2));
                         $scope.readcampaigninsights();
                        } else
                        {
                            
                           $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                     
                    }
                             );
           //          // console.log(JSON.stringify($scope.networkmaparrayonload,null,2));
                   // // console.log(JSON.stringify());
                 //   // console.log($scope.wholechildArray);
        };
        
        
                
      
        $scope.readcampaigninsights = function ()
        {
             
               $rootScope.progressLoader ="block";
         var insights = [];
         var promises = [];
       
           m=0;
          for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                          //  // console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                        if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                   
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                       
                                             // console.log("facebook is working");
                                             (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,undefined,undefined,appSettings.fbNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                            angular.forEach(value2, function (value3, key3) {
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                            insight[key2] = obj;
                                                        });
                                                    });
                                                    insights.push(insight);
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                    
                                }
                                }
                            }
                        } else if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                            // console.log("getting into the twitter network");   
                           
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                     
                                      m++;
                                          // console.log("twitter is working");
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,undefined,undefined,appSettings.twNetwork,true).then(function (response) {
                                                var insight = {};
                                               
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                            angular.forEach(value2, function (value3, key3) {
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                   //         // console.log(key2);
                                                            insight[key2] = obj;
                                                        });
                                                    });
                                                    insights.push(insight);
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                      
                                        }
                                }
                            }
                        }
                    }
                }
            }
        
        $q.all(promises).finally(function () {
                for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        angular.forEach(insights, function (value, key) {
                                            angular.forEach(value, function (value2, key2) {
                                             //   // console.log(key2);
                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                    $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.push(value2);
                                                }
                                            });
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
              // // console.log(JSON.stringify($scope.networkmaparray,null,2));
               // $scope.getcampaignbudget();
                 $rootScope.progressLoader ="none";
             $scope.readcampaigninsightsToday();
            });
        };
        
        
        $scope.readcampaigninsightsToday =function()
       
        {
              m=0;
                $rootScope.progressLoader ="block";
            var date = new Date();
            var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
           // // console.log(_utc);
            $scope.formattedtodaydate = $filter('date')(_utc, 'yyyy-MM-dd');
             var insights = [];
            var promises = [];
            
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                        if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    //                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].length != 0)
                                    //                                        {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        
                                            m++;
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,$scope.formattedtodaydate,undefined,appSettings.fbNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                            angular.forEach(value2, function (value3, key3) {
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                            insight[key2] = obj;
                                                        });
                                                    });
                                                    insights.push(insight);
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                   
                                }
                                }
                            }
                        } else if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                       m++;
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,$scope.formattedtodaydate,undefined,appSettings.twNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                      //  // console.log(value);
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                       //     // console.log(value2);
                                                             angular.forEach(value2, function (value5, key5) {
                                                            angular.forEach(value5, function (value3, key3) {
                                                                 //// console.log(value3);
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                            insight[key5] = obj;
                                                        });});
                                                    });
                                                    insights.push(insight);
                                                 } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                   
                                }
                                }
                            }
                        }
                    }
                }
            }
            
        $q.all(promises).finally(function () {
                for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        angular.forEach(insights, function (value, key) {
                                          //  // console.log(JSON.stringify(value,null,2)+"   "+key)
                                            angular.forEach(value, function (value2, key2) {
                                             //  // console.log(key2)
                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                   $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.push(value2);
                                                }
                                            });
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
          //  // console.log(JSON.stringify($scope.networkmaparray,null,2));
               // $scope.getcampaignbudget();
                 $rootScope.progressLoader ="none";
              $scope.readcampaigninsightsYesterday();
            });
        };

           
        $scope.readcampaigninsightsYesterday =function()
       
        {
            m=0;
              $rootScope.progressLoader ="block";
            $scope.tomorrow = new Date();
            $scope.tomorrow.setDate($scope.tomorrow.getDate() - 1);
            $scope.formattedtodaydate = $filter('date')($scope.tomorrow, 'yyyy-MM-dd');
            
            //$scope.formattedtodaydate = $filter('date')(_utc, 'yyyy-MM-dd');
             var insights = [];
            var promises = [];
            
           
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                        if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    //                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].length != 0)
                                    //                                        {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                      
                                        m++;
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,$scope.formattedtodaydate,undefined,appSettings.fbNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                            angular.forEach(value2, function (value3, key3) {
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                            insight[key2] = obj;
                                                        });
                                                    });
                                                    insights.push(insight);
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                      
                                }
                                }
                            }
                        } else if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                       m++;
                                        (function (i, j, k, l) {
                                               promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,$scope.formattedtodaydate,undefined,appSettings.twNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function (value, key) {
                                                      //  // console.log(value);
                                                        angular.forEach(value, function (value2, key2) {
                                                            var obj = {};
                                                       //     // console.log(value2);
                                                             angular.forEach(value2, function (value5, key5) {
                                                            angular.forEach(value5, function (value3, key3) {
                                                                 //// console.log(value3);
                                                                if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                    var newchar = ' ';
                                                                    key3 = key3.split('_').join(newchar);
                                                                    if (key3 == "callToAction") {
                                                                        obj['actions'] = Math.round(parseFloat(value3));
                                                                    } else {
                                                                        obj[key3] = Math.round(parseFloat(value3));
                                                                    }
                                                                }
                                                            });
                                                            insight[key5] = obj;
                                                        });});
                                                    });
                                                    insights.push(insight);
                                                 } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                    }
                                }
                            }
                        }
                    }
                }
            }
          
            $q.all(promises).finally(function () {
                for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        angular.forEach(insights, function (value, key) {
                                            angular.forEach(value, function (value2, key2) {
                                                
                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                    $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.push(value2);
                                                }
                                            });
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
             // // console.log(JSON.stringify($scope.networkmaparray,null,2));
               
                           
                          $rootScope.progressLoader ="none";
                           $scope.handleErrors();
                       $scope.onloadoverallaccount();
            });
        };
     
        
        
        
         $scope.onloadoverallaccount =function()
         {
     //      console.log("onload is working");
    //console.log(JSON.stringify($scope.networkmaparray,null,2));
        $scope.display=true;
        $scope.doublecampaigns=0;
        $scope.singlecampaigns=0;
        $scope.totalcampaigns=0;
        $scope.filldiv=false;
        $scope.noingightsparenttoday = false;
        $scope.noinsightsalladvToaday = false;
        $scope.noinsightsalladvOverall = false;
        $scope.noinsightsadvToaday = false;
        $scope.noinsightsadvOverall = false;
        $scope.noingightsoveralltoday = false;
        $scope.noingightschildtoday = false;
        $scope.noingightschildoverall = false;
         $scope.noingightsparentoverall=false;
           
           
           $scope.onloadhasinsightsoverall=false;
           $scope.onloadhasinsightstoday=false;
           
            $("#pieChart1all").show();
            $("#pieChart2all").show();
            $("#pieChart3all").show();
            $("#pieChart4all").show(); 
  // 
            $scope.totalfbspend=0;
            $scope.totalfbimpression=0;
            $scope.totalfbclicks=0;
            $scope.totalfbactions=0;
            $scope.totaltwspend=0;
            $scope.totaltwimpression=0;
            $scope.totaltwclicks=0;
            $scope.totaltwactions=0;
            $scope.totalfbtodayspend=0;
            $scope.totalfbtodayimpression=0;
            $scope.totalfbtodayclicks=0;
            $scope.totalfbtodayactions=0;
            $scope.totaltwtodayspend=0;
            $scope.totaltwtodayimpression=0;
            $scope.totaltwtodayclicks=0;
            $scope.totaltwtodayactions=0;
            $scope.totalfbyesterdayspend=0;
            $scope.totalfbyesterdayimpression=0;
            $scope.totalfbyesterdayclicks=0;
            $scope.totalfbyesterdayactions=0;
            $scope.totaltwyesterdayspend=0;
            $scope.totaltwyesterdayimpression=0;
            $scope.totaltwyesterdayclicks=0;
            $scope.totaltwyesterdayactions=0;
            
            $scope.totalsinglenetworkspend=0;
            $scope.totalsinglenetworkimpression=0;
            $scope.totalsinglenetworkclicks=0;
            $scope.totalsinglenetworkactions=0;
            $scope.totaldoublenetworkspend=0;
            $scope.totaldoublenetworkimpression=0;
            $scope.totaldoublenetworkclicks=0;
            $scope.totaldoublenetworkactions=0;
            
            $scope.todaysinglenetworkspend=0;
            $scope.todaysinglenetworkimpression=0;
            $scope.todaysinglenetworkclicks=0;
            $scope.todaysinglenetworkactions=0;
            $scope.todaydoublenetworkspend=0;
            $scope.todaydoublenetworkimpression=0;
            $scope.todaydoublenetworkclicks=0;
            $scope.todaydoublenetworkactions=0;
            
            
            
            
            $scope.yesterdaysinglenetworkspend=0;
            $scope.yesterdaysinglenetworkimpression=0;
            $scope.yesterdaysinglenetworkclicks=0;
            $scope.yesterdaysinglenetworkactions=0;
            $scope.yesterdaydoublenetworkspend=0;
            $scope.yesterdaydoublenetworkimpression=0;
            $scope.yesterdaydoublenetworkclicks=0;
            $scope.yesterdaydoublenetworkactions=0;
            $scope.arrowshow=true;
            var m=0;
            
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                     if($scope.networkmaparray[i].networkDetails.length > 1)
                     {
                         
                         $scope.FbNetworkmaparray =angular.copy($scope.networkmaparray[i].networkDetails[0]);
                         $scope.TwNetworkmaparray =angular.copy($scope.networkmaparray[i].networkDetails[1]);
                         //console.log(JSON.stringify($scope.FbNetworkmaparray.parent,null,2));
                         //console.log(JSON.stringify($scope.TwNetworkmaparray,null,2));
                        
                         if($scope.FbNetworkmaparray.hasOwnProperty("parent"))
                         {
                                for(l=0;l<$scope.FbNetworkmaparray.parent.length;l++)
                                {
                                    if($scope.TwNetworkmaparray.hasOwnProperty("parent"))
                                    {
                                        for(x=0;x<$scope.TwNetworkmaparray.parent.length;x++)
                                        {
                                            if($scope.TwNetworkmaparray.parent[x].id == $scope.FbNetworkmaparray.parent[l].id)
                                            {
                                                if($scope.TwNetworkmaparray.parent[x].hasOwnProperty("campaigns") && $scope.FbNetworkmaparray.parent[l].hasOwnProperty("campaigns"))
                                                {
                                                    if($scope.TwNetworkmaparray.parent[x].campaigns.length > 0 && $scope.FbNetworkmaparray.parent[l].campaigns.length > 0)
                                                    {
                                                        //adding fb campaigns insights
                                                        for(k=0;k<$scope.FbNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.doublecampaigns=$scope.doublecampaigns+1;
                                                            console.log($scope.doublecampaigns);
                                                             if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.totaldoublenetworkspend=$scope.totaldoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.totaldoublenetworkimpression=$scope.totaldoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.totaldoublenetworkclicks=$scope.totaldoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.totaldoublenetworkactions=$scope.totaldoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].actions;


                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                       $scope.graphfacebook = true;
                                                                        $scope.graphtwitter = false;
                                                                        $scope.graphinstagram = false;
                                                                        $scope.graphgoogle = false;
                                                                        $scope.graphbing = false;
                                                                        $scope.filldiv=false;
                                                                        $scope.nettabselection = true;  
                                                                        $scope.onloadhasinsightsoverall=true;
                                                                }


                                                            }


                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.todaydoublenetworkspend=$scope.todaydoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.todaydoublenetworkimpression=$scope.todaydoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.todaydoublenetworkclicks=$scope.todaydoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.todaydoublenetworkactions=$scope.todaydoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.onloadhasinsightstoday=true;
                                                                  }

                                                              }

                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.yesterdaysinglenetworkspend=$scope.yesterdaydoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.yesterdaysinglenetworkimpression=$scope.yesterdaydoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.yesterdaysinglenetworkclicks=$scope.yesterdaydoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.yesterdaysinglenetworkactions=$scope.yesterdaydoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                        
                                                        
                                                        
                                                        
                                                        //adding tw campaigns insights 
                                                        for(k=0;k<$scope.TwNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.doublecampaigns=$scope.doublecampaigns+1;

                                                             if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.totaldoublenetworkspend=$scope.totaldoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.totaldoublenetworkimpression=$scope.totaldoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.totaldoublenetworkclicks=$scope.totaldoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.totaldoublenetworkactions=$scope.totaldoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].actions;


                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                       $scope.graphfacebook = true;
                                                                        $scope.graphtwitter = false;
                                                                        $scope.graphinstagram = false;
                                                                        $scope.graphgoogle = false;
                                                                        $scope.graphbing = false;
                                                                        $scope.filldiv=false;
                                                                        $scope.nettabselection = true;  
                                                                        $scope.onloadhasinsightsoverall=true;
                                                                }
                                                            }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.todaydoublenetworkspend=$scope.todaydoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.todaydoublenetworkimpression=$scope.todaydoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.todaydoublenetworkclicks=$scope.todaydoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.todaydoublenetworkactions=$scope.todaydoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.onloadhasinsightstoday=true;
                                                                  }

                                                              }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.yesterdaysinglenetworkspend=$scope.yesterdaydoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.yesterdaysinglenetworkimpression=$scope.yesterdaydoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.yesterdaysinglenetworkclicks=$scope.yesterdaydoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.yesterdaysinglenetworkactions=$scope.yesterdaydoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                    
                                                    }
                                                    else
                                                    {
                                                        
                                                        //adding fb campaigns insights
                                                        for(k=0;k<$scope.FbNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.singlecampaigns=$scope.singlecampaigns+1;
                                                            console.log($scope.singlecampaigns);
                                                             if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.totalsinglenetworkspend=$scope.totalsinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.totalsinglenetworkimpression=$scope.totalsinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.totalsinglenetworkclicks=$scope.totalsinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.totalsinglenetworkactions=$scope.totalsinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].actions;


                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                       $scope.graphfacebook = true;
                                                                        $scope.graphtwitter = false;
                                                                        $scope.graphinstagram = false;
                                                                        $scope.graphgoogle = false;
                                                                        $scope.graphbing = false;
                                                                        $scope.filldiv=false;
                                                                        $scope.nettabselection = true;  
                                                                        $scope.onloadhasinsightsoverall=true;
                                                                }


                                                            }


                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.todaysinglenetworkspend=$scope.todaysinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.todaysinglenetworkimpression=$scope.todaysinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.todaysinglenetworkclicks=$scope.todaysinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.todaysinglenetworkactions=$scope.todaysinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.onloadhasinsightstoday=true;
                                                                  }

                                                              }

                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.yesterdaysinglenetworkspend=$scope.yesterdaysinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.yesterdaysinglenetworkimpression=$scope.yesterdaysinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.yesterdaysinglenetworkclicks=$scope.yesterdaysinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.yesterdaysinglenetworkactions=$scope.yesterdaysinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                        
                                                        
                                                        
                                                        
                                                        //adding tw campaigns insights 
                                                        for(k=0;k<$scope.TwNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.singlecampaigns=$scope.singlecampaigns+1;

                                                             if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.totalsinglenetworkspend=$scope.totalsinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.totalsinglenetworkimpression=$scope.totalsinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.totalsinglenetworkclicks=$scope.totalsinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.totalsinglenetworkactions=$scope.totalsinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].actions;


                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                       $scope.graphfacebook = true;
                                                                        $scope.graphtwitter = false;
                                                                        $scope.graphinstagram = false;
                                                                        $scope.graphgoogle = false;
                                                                        $scope.graphbing = false;
                                                                        $scope.filldiv=false;
                                                                        $scope.nettabselection = true;  
                                                                        $scope.onloadhasinsightsoverall=true;
                                                                }
                                                            }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.todaysinglenetworkspend=$scope.todaysinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.todaysinglenetworkimpression=$scope.todaysinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.todaysinglenetworkclicks=$scope.todaysinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.todaysinglenetworkactions=$scope.todaysinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.onloadhasinsightstoday=true;
                                                                  }

                                                              }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.yesterdaysinglenetworkspend=$scope.yesterdaysinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.yesterdaysinglenetworkimpression=$scope.yesterdaysinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.yesterdaysinglenetworkclicks=$scope.yesterdaysinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.yesterdaysinglenetworkactions=$scope.yesterdaysinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                    }
                                                }    
                                            }
                                        }
                                    }
                                }
                         }
                        
                            
                    
                         }
                      else
                     {
                         
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    {
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                             $scope.singlecampaigns=$scope.singlecampaigns+1;;
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                  // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                       $scope.totalsinglenetworkspend=$scope.totalsinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                      $scope.totalsinglenetworkimpression=$scope.totalsinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.totalsinglenetworkclicks=$scope.totalsinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                      $scope.totalsinglenetworkactions=$scope.totalsinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                   
                                                        $("#pieChart1all").show();$scope.display=true;$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                    $scope.graphfacebook = true;
                                                    $scope.graphtwitter = false;
                                                    $scope.graphinstagram = false;
                                                    $scope.graphgoogle = false;
                                                    $scope.graphbing = false;
                                                    $scope.filldiv=false;
                                                    $scope.nettabselection = true;  
                                                      $scope.onloadhasinsightsoverall=true;
                                                }
                                                
                                            }
                                            
                                        
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("todayinsights"))
                                            {
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                 //   // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.todaysinglenetworkspend=$scope.todaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].spend;
                                                     $scope.todaysinglenetworkimpression=$scope.todaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].impressions;
                                                      $scope.todaysinglenetworkclicks=$scope.todaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].clicks;
                                                     $scope.todaysinglenetworkactions=$scope.todaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].actions;
                                                     $scope.onloadhasinsightstoday=true;
                                                }
                                                
                                            }
                                            
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("yesterdayinsight"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                    
                                                    
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.yesterdaysinglenetworkspend=$scope.yesterdaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].spend;
                                                     $scope.yesterdaysinglenetworkimpression=$scope.yesterdaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].impressions;
                                                      $scope.yesterdaysinglenetworkclicks=$scope.yesterdaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].clicks;
                                                     $scope.yesterdaysinglenetworkactions=$scope.yesterdaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].actions;
                                                 //   // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);
                                                    
                                                }
                                                
                                            }
                                            
                                         
                                         
                                         
                                         }
                                        
                                        
                                    }
                                    
                                    
                                }
                                
                                
                                
                                
                            }
                            
                         
                         }
                     
                     }   
                         
                     } }
   
              // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
              // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
              // console.log(  "single today spend :"  +$scope.todaysinglenetworkspend+"      "+" today impression  "+ $scope.todaysinglenetworkimpression+"     today clicks  "+$scope.todaysinglenetworkclicks +"     today actions "+ $scope.todaysinglenetworkactions);  
              // console.log(  "double today spend :"  +$scope.todaydoublenetworkspend+"      "+" today impression  "+ $scope.todaydoublenetworkimpression+"     today clicks  "+$scope.todaydoublenetworkclicks +"     today actions "+ $scope.todaydoublenetworkactions);
              // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);  
              // console.log(  "double yesterday spend :"  +$scope.yesterdaydoublenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaydoublenetworkimpression+"     yesterday clicks  "+$scope.yesterdaydoublenetworkclicks +"     yesterday actions "+ $scope.yesterdaydoublenetworkactions);
           
             $scope.todaytotalnetworkspend=$scope.todaysinglenetworkspend+$scope.todaydoublenetworkspend;
             $scope.todaytotalnetworkimpression=$scope.todaysinglenetworkimpression+ $scope.todaydoublenetworkimpression;       
             $scope.todaytotalnetworkclicks=$scope.todaysinglenetworkclicks+$scope.todaydoublenetworkclicks;
             $scope.todaytotalnetworkactions=$scope.todaysinglenetworkactions+$scope.todaydoublenetworkactions;
           
            console.log($scope.singlecampaigns);
            console.log($scope.doublecampaigns);
             
             
            $scope.totalyesterdaynetworkspend= $scope.yesterdaysinglenetworkspend+ $scope.yesterdaydoublenetworkspend;
            $scope.totalyesterdaynetworkimpression=  $scope.yesterdaysinglenetworkimpression+ $scope.yesterdaydoublenetworkimpression;
            $scope.totalyesterdaynetworkclicks=$scope.yesterdaysinglenetworkclicks+$scope.yesterdaydoublenetworkclicks;
            $scope.totalyesterdaynetworkactions=$scope.yesterdaysinglenetworkactions+$scope.yesterdaydoublenetworkactions;
             
             $scope.totalcampaigns=  $scope.singlecampaigns+  $scope.doublecampaigns;
           
            $scope.onloadsinglecampper=( $scope.singlecampaigns/$scope.totalcampaigns)*80;
            $scope.onloaddoublecampper= 80-$scope.onloadsinglecampper;
            
             
             // console.log("single camp no: "+ $scope.onloadsinglecampper+"       doublecampper"+$scope.onloaddoublecampper);
             $scope.network = true;
           
         
        
         
                                     
        
          for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                           //calculation for overall spend fb
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("networkName")) {
                                
                                if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                                    
                                    {
                            //   // console.log("facebook cal")
                               if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                               {
                         
                              
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       
                                        
                                
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                          
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                // console.log("facebook graph calculation is working")
                                                
                                         $scope.totalfbspend=$scope.totalfbspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                         $scope.totalfbimpression=  $scope.totalfbimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                         $scope.totalfbclicks= $scope.totalfbclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                         $scope.totalfbactions= $scope.totalfbactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                             // console.log(  "fb   total spend :"  +$scope.totalfbspend+"      "+" total impression  "+ $scope.totalfbimpression+"     total clicks  "+$scope.totalfbclicks +"     total actions "+ $scope.totalfbactions);   
                                          
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                     
                                                     }}
                                        }
                                    }
                                }
                            }
                               
                               
                       }
                       
                           
                           else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                                  {
                           
                           
                             if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                               {
                         
                              
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       
                                        
                                
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                          
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                 if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                 // console.log("Twitter graph calculation is working")
                                         $scope.totaltwspend=$scope.totaltwspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                         $scope.totaltwimpression=  $scope.totaltwimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                         $scope.totaltwclicks= $scope.totaltwclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                         $scope.totaltwactions= $scope.totaltwactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                            }
                                        }}
                                    }
                                }
                            }
                           
                           
                           
                       }
                                
                                 
                                 }
                              
                             }
                         }
                     }
                   //   $scope.facebook($scope.adimpressions, $scope.adclicks, $scope.adcallToAction, $scope.adspend, overall);
              
            // console.log(  "fb   total spend :"  +$scope.totalfbspend+"      "+" total impression  "+ $scope.totalfbimpression+"     total clicks  "+$scope.totalfbclicks +"     total actions "+ $scope.totalfbactions);
            // console.log(  "tw   total spend :"  +$scope.totaltwspend+"      "+" total impression  "+ $scope.totaltwimpression+"     total clicks  "+$scope.totaltwclicks +"     total actions "+ $scope.totaltwactions);
           
        // $scope.totalimpressions=$scope.totalsinglenetworkimpression+$scope.totaldoublenetworkimpression;
       //  $scope.totalclicks=$scope.totalsinglenetworkclicks+$scope.totaldoublenetworkclicks;
        // $scope.totalaction=$scope.totalsinglenetworkactions+$scope.totaldoublenetworkactions;
       //  $scope.totalspend=$scope.totalsinglenetworkspend+$scope.totaldoublenetworkspend;
        
           
        // $scope.adimpressionstoday=   $scope.todaytotalnetworkimpression;
       //  $scope.adclickstoday = $scope.todaytotalnetworkclicks;
       //  $scope.adspendtoday= $scope.todaytotalnetworkspend;
       //  $scope.adcallToActiontoday=  $scope.todaytotalnetworkactions;
          // $scope.nettabselection = true;  
             if($scope.flag)
             {
                 
                 
                 if( $scope.onloadhasinsightsoverall)
                 {
                     $scope.display=true;
             plotValuesPiechart($scope.totalsinglenetworkimpression,$scope.totalsinglenetworkspend,$scope.totalsinglenetworkclicks,$scope.totalsinglenetworkactions,$scope.totaldoublenetworkimpression, $scope.totaldoublenetworkclicks   , $scope.totaldoublenetworkactions, $scope.totaldoublenetworkspend, $scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.onloadsinglecampper,$scope.onloaddoublecampper,    $scope.morecontibution);
                   $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend,$scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend);
                   $scope.actualfacebookoverall($scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend,$scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend);
               }
           else
           {
               $scope.nettabselection = false;  
                  $scope.noinsightsalladvOverall = true;
            
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                 $scope.filldiv=true; $scope.network=false;
                 $scope.arrowshow=false;
                  $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
               
           }
             
             }
             if(!$scope.flag)           
             {
                   if($scope.onloadhasinsightstoday)
                   {
                   
                $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.filldiv=false;
                $scope.nettabselection = true;  
                $scope.network = true;  
                $scope.img = true;
                 $scope.display=true;
                // console.log($scope.todaysinglenetworkimpression,$scope.todaysinglenetworkspend,$scope.todaysinglenetworkclicks,$scope.todaysinglenetworkactions,$scope.todaydoublenetworkimpression, $scope.todaydoublenetworkclicks   , $scope.todaydoublenetworkactions, $scope.todaydoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.onloadsinglecampper,$scope.onloaddoublecampper,    $scope.morecontibution);
                   plotValuesPiechart($scope.todaysinglenetworkimpression,$scope.todaysinglenetworkspend,$scope.todaysinglenetworkclicks,$scope.todaysinglenetworkactions,$scope.todaydoublenetworkimpression, $scope.todaydoublenetworkclicks   , $scope.todaydoublenetworkactions, $scope.todaydoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.onloadsinglecampper,$scope.onloaddoublecampper,    $scope.morecontibution);
                   $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend,$scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend);
                   $scope.actualfacebookoverall($scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend,$scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend);
          
                      if ($scope.totalyesterdaynetworkimpression > $scope.todaytotalnetworkimpression)
                        {
                            $scope.uparrow = false;
                            $scope.downarrow = true;
                            $scope.equalarrow = false;

                        }
                        else if ($scope.totalyesterdaynetworkimpression < $scope.todaytotalnetworkimpression)
                        {
                            $scope.uparrow = true;

                            $scope.downarrow = false;
                            $scope.equalarrow = false;
                        }
                        else
                        {   //alert('hi')
                            $scope.uparrow = false;
                            $scope.downarrow = false;
                            $scope.equalarrow = true;
                        }
                        
                        
                        
                        if ($scope.totalyesterdaynetworkclicks > $scope.todaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = true;
                            $scope.equalarrow2 = false;
                        }

                        else if ($scope.totalyesterdaynetworkclicks < $scope.todaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = true;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = false;
                        }
                        else {
                            // alert('hi')
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = true;
                        }

                        
                        
                        if ($scope.totalyesterdaynetworkspend > $scope.todaytotalnetworkspend)
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = true;
                            $scope.equalarrow4 = false;
                        }
                        else if ($scope.totalyesterdaynetworkspend < $scope.todaytotalnetworkspend)
                        {
                            $scope.uparrow4 = true;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = false;
                        }
                        else
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = true;
                            //alert('hi')
                        }
                 
                 
                        if ($scope.totalyesterdaynetworkactions > $scope.todaytotalnetworkactions)
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = true;
                            $scope.equalarrow3 = false;
                        }

                        else if ($scope.totalyesterdaynetworkactions < $scope.todaytotalnetworkactions)
                        {
                            $scope.uparrow3 = true;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = false;
                        }
                        else
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = true;
                            // alert('hi')
                        }

                       
                   
                   
                     

                    
                      
                    
                   
                   
               }
           else
           {
               $scope.nettabselection = false;  
                  $scope.noinsightsalladvOverall = true;
            
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                 $scope.filldiv=true; $scope.network=false;
                 $scope.arrowshow=false;
                  $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
               
           }
       }
               
          
         
         
         }
        
      
 
      //     
//   /*  $scope.getAdvertiserDetails();
       //FETCHPARENTCAMPAIGN
        $scope.selectadvertiser = function (advertiserId)
        {
            console.log("advertiser  is working");
        $scope.noingightsparenttoday = false;
        $scope.noinsightsalladvToaday = false;
        $scope.noinsightsalladvOverall = false;
        $scope.noinsightsadvToaday = false;
        $scope.noinsightsadvOverall = false;
        $scope.noingightsoveralltoday = false;
        $scope.noingightschildtoday = false;
        $scope.noingightschildoverall = false;
        $scope.noingightsparentoverall=false;
           $scope.arrowshow=true;
            $scope.advertiser=advertiserId;
            $scope.advdualcampaign=0;
            $scope.advsinglecampign=0;
            $scope.advtotalsinglenetworkspend=0;
            $scope.advtotalsinglenetworkimpression=0;
            $scope.advtotalsinglenetworkclicks=0;
            $scope.advtotalsinglenetworkactions=0;
            $scope.advtotaldoublenetworkspend=0;
            $scope.advtotaldoublenetworkimpression=0;
            $scope.advtotaldoublenetworkclicks=0;
            $scope.advtotaldoublenetworkactions=0;
            $scope.childselect=false;
             $scope.parentselect=false;
            $scope.advtodaysinglenetworkspend=0;
            $scope.advtodaysinglenetworkimpression=0;
            $scope.advtodaysinglenetworkclicks=0;
            $scope.advtodaysinglenetworkactions=0;
            $scope.advtodaydoublenetworkspend=0;
            $scope.advtodaydoublenetworkimpression=0;
            $scope.advtodaydoublenetworkclicks=0;
            $scope.advtodaydoublenetworkactions=0;
            
             $scope.filldiv=false;
            
            
            $scope.advyesterdaysinglenetworkspend=0;
            $scope.advyesterdaysinglenetworkimpression=0;
            $scope.advyesterdaysinglenetworkclicks=0;
            $scope.advyesterdaysinglenetworkactions=0;
            $scope.advyesterdaydoublenetworkspend=0;
            $scope.advyesterdaydoublenetworkimpression=0;
            $scope.advyesterdaydoublenetworkclicks=0;
            $scope.advyesterdaydoublenetworkactions=0; 
            
            
            $scope.advfboverallspend=0
            $scope.advfboverallclicks=0;
            $scope.advfboverallactions=0;
            $scope.advfboverallimpression=0;
            
            $scope.advtwoverallspend=0
            $scope.advtwoverallclicks=0;
            $scope.advtwoverallactions=0;
            $scope.advtwoverallimpression=0;
            
            $scope.advertiserhasoverallinsights=false;
            $scope.advertiserhastodayinsights=false; 
            $scope.FbNetworkmaparray=[];
            $scope.TwNetworkmaparray=[];
            
            // console.log(advertiserId);
            
            $scope.updateCampaignDropDown();
            if(advertiserId!="")
            {
                
           
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if($scope.networkmaparray[i].advertiserId==advertiserId)
                {
                    // console.log("enter the advertiser ");
                    
                
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                     if($scope.networkmaparray[i].networkDetails.length > 1)
                     {
                         
                         $scope.FbNetworkmaparray =angular.copy($scope.networkmaparray[i].networkDetails[0]);
                         $scope.TwNetworkmaparray =angular.copy($scope.networkmaparray[i].networkDetails[1]);
                         //console.log(JSON.stringify($scope.FbNetworkmaparray.parent,null,2));
                         //console.log(JSON.stringify($scope.TwNetworkmaparray,null,2));
                        
                         if($scope.FbNetworkmaparray.hasOwnProperty("parent"))
                         {
                                for(l=0;l<$scope.FbNetworkmaparray.parent.length;l++)
                                {
                                    if($scope.TwNetworkmaparray.hasOwnProperty("parent"))
                                    {
                                        for(x=0;x<$scope.TwNetworkmaparray.parent.length;x++)
                                        {
                                            if($scope.TwNetworkmaparray.parent[x].id == $scope.FbNetworkmaparray.parent[l].id)
                                            {
                                                if($scope.TwNetworkmaparray.parent[x].hasOwnProperty("campaigns") && $scope.FbNetworkmaparray.parent[l].hasOwnProperty("campaigns"))
                                                {
                                                    if($scope.TwNetworkmaparray.parent[x].campaigns.length > 0 && $scope.FbNetworkmaparray.parent[l].campaigns.length > 0)
                                                    {
                                                        //adding fb campaigns insights
                                                        for(k=0;k<$scope.FbNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.advdualcampaign=$scope.advdualcampaign+1;
                                                            console.log($scope.advdualcampaign);
                                                             if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.advtotaldoublenetworkspend=$scope.advtotaldoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.advtotaldoublenetworkimpression=$scope.advtotaldoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.advtotaldoublenetworkclicks=$scope.advtotaldoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.advtotaldoublenetworkactions=$scope.advtotaldoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].actions;

                                                                     $scope.advertiserhasoverallinsights=true;
                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                }


                                                            }


                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.advtodaydoublenetworkspend=$scope.advtodaydoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.advtodaydoublenetworkimpression=$scope.advtodaydoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.advtodaydoublenetworkclicks=$scope.advtodaydoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.advtodaydoublenetworkactions=$scope.advtodaydoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.advertiserhastodayinsights=true; 
                                                                  }

                                                              }

                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.advyesterdaydoublenetworkspend=$scope.advyesterdaydoublenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.advyesterdaydoublenetworkimpression=$scope.advyesterdaydoublenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.advyesterdaydoublenetworkclicks=$scope.advyesterdaydoublenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.advyesterdaydoublenetworkactions=$scope.advyesterdaydoublenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                        
                                                        
                                                        
                                                        
                                                        //adding tw campaigns insights 
                                                        for(k=0;k<$scope.TwNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.advdualcampaign=$scope.advdualcampaign+1;

                                                             if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.advtotaldoublenetworkspend=$scope.advtotaldoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.advtotaldoublenetworkimpression=$scope.advtotaldoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.advtotaldoublenetworkclicks=$scope.advtotaldoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.advtotaldoublenetworkactions=$scope.advtotaldoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].actions;

                                                                     $scope.advertiserhasoverallinsights=true; 
                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                }
                                                            }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.advtodaydoublenetworkspend=$scope.advtodaydoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.advtodaydoublenetworkimpression=$scope.advtodaydoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.advtodaydoublenetworkclicks=$scope.advtodaydoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.advtodaydoublenetworkactions=$scope.advtodaydoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.advertiserhastodayinsights=true; 
                                                                  }

                                                              }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.advyesterdaydoublenetworkspend=$scope.advyesterdaydoublenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.advyesterdaydoublenetworkimpression=$scope.advyesterdaydoublenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.advyesterdaydoublenetworkclicks=$scope.advyesterdaydoublenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.advyesterdaydoublenetworkactions=$scope.advyesterdaydoublenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                    
                                                    }
                                                    else
                                                    {
                                                        
                                                        //adding fb campaigns insights
                                                        for(k=0;k<$scope.FbNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.advsinglecampign=$scope.advsinglecampign+1;
                                                            console.log($scope.advsinglecampign);
                                                             if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.advtotalsinglenetworkspend=$scope.advtotalsinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.advtotalsinglenetworkimpression=$scope.advtotalsinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.advtotalsinglenetworkclicks=$scope.advtotalsinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.advtotalsinglenetworkactions=$scope.advtotalsinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].insights[0].actions;

                                                                     $scope.advertiserhasoverallinsights=true; 
                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                }


                                                            }


                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.advtodaysinglenetworkspend=$scope.advtodaysinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.advtodaysinglenetworkimpression=$scope.advtodaysinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.advtodaysinglenetworkclicks=$scope.advtodaysinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.advtodaysinglenetworkactions=$scope.advtodaysinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.advertiserhastodayinsights=true; 
                                                                  }

                                                              }

                                                              if($scope.FbNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.advyesterdaysinglenetworkspend=$scope.advyesterdaysinglenetworkspend+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.advyesterdaysinglenetworkimpression=$scope.advyesterdaysinglenetworkimpression+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.advyesterdaysinglenetworkclicks=$scope.advyesterdaysinglenetworkclicks+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.advyesterdaysinglenetworkactions=$scope.advyesterdaysinglenetworkactions+$scope.FbNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                        
                                                        
                                                        
                                                        
                                                        //adding tw campaigns insights 
                                                        for(k=0;k<$scope.TwNetworkmaparray.parent[l].campaigns.length;k++)
                                                        {
                                                            $scope.advsinglecampign=$scope.advsinglecampign+1;

                                                             if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("insights"))
                                                            {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].insights.length > 0)
                                                                {
                                                                     $scope.advtotalsinglenetworkspend=$scope.advtotalsinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].spend;
                                                                     $scope.advtotalsinglenetworkimpression=$scope.advtotalsinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].impressions;
                                                                     $scope.advtotalsinglenetworkclicks=$scope.advtotalsinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].clicks;
                                                                     $scope.advtotalsinglenetworkactions=$scope.advtotalsinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].insights[0].actions;

                                                                     $scope.advertiserhasoverallinsights=true; 
                                                                      $("#pieChart1all").show();$scope.display=true;
                                                                      $("#pieChart2all").show();
                                                                      $("#pieChart3all").show();
                                                                      $("#pieChart4all").show(); 
                                                                }
                                                            }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("todayinsights"))
                                                              {
                                                                if($scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights.length > 0)
                                                                  {
                                                                       $scope.advtodaysinglenetworkspend=$scope.advtodaysinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].spend;
                                                                       $scope.advtodaysinglenetworkimpression=$scope.advtodaysinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].impressions;
                                                                       $scope.advtodaysinglenetworkclicks=$scope.advtodaysinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].clicks;
                                                                       $scope.advtodaysinglenetworkactions=$scope.advtodaysinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].todayinsights[0].actions;
                                                                       $scope.advertiserhastodayinsights=true; 
                                                                  }

                                                              }

                                                              if($scope.TwNetworkmaparray.parent[l].campaigns[k].hasOwnProperty("yesterdayinsight"))
                                                              {
                                                                  if($scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight.length > 0)
                                                                  {                                                                
                                                                       $scope.advyesterdaysinglenetworkspend=$scope.advyesterdaysinglenetworkspend+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].spend;
                                                                       $scope.advyesterdaysinglenetworkimpression=$scope.advyesterdaysinglenetworkimpression+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].impressions;
                                                                       $scope.advyesterdaysinglenetworkclicks=$scope.advyesterdaysinglenetworkclicks+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].clicks;
                                                                       $scope.advyesterdaysinglenetworkactions=$scope.advyesterdaysinglenetworkactions+$scope.TwNetworkmaparray.parent[l].campaigns[k].yesterdayinsight[0].actions;                                                               

                                                                  }

                                                              }

                                                        }
                                                    }
                                                }    
                                            }
                                        }
                                    }
                                }
                         }
                        
                            
                    
                         
                     }
                      else
                     {
                         
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    {
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            $scope.advsinglecampign=$scope.advsinglecampign+1;
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                      $scope.advtotalsinglenetworkspend=$scope.advtotalsinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                      $scope.advtotalsinglenetworkimpression=$scope.advtotalsinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.advtotalsinglenetworkclicks=$scope.advtotalsinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                      $scope.advtotalsinglenetworkactions=$scope.advtotalsinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                //     // console.log(  "Single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                      $scope.advertiserhasoverallinsights=true;
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                }
                                                
                                            }
                                            
                                        
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("todayinsights"))
                                            {
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                 //   // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.advtodaysinglenetworkspend=$scope.advtodaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].spend;
                                                     $scope.advtodaysinglenetworkimpression=$scope.advtodaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].impressions;
                                                      $scope.advtodaysinglenetworkclicks=$scope.advtodaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].clicks;
                                                     $scope.advtodaysinglenetworkactions=$scope.advtodaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].actions;
                                                      $scope.advertiserhastodayinsights=true; 
                                                }
                                                
                                            }
                                            
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("yesterdayinsight"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                    
                                                    
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.advyesterdaysinglenetworkspend=$scope.advyesterdaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].spend;
                                                     $scope.advyesterdaysinglenetworkimpression=$scope.advyesterdaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].impressions;
                                                      $scope.advyesterdaysinglenetworkclicks=$scope.advyesterdaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].clicks;
                                                     $scope.advyesterdaysinglenetworkactions=$scope.advyesterdaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].actions;
                                                 //   // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);
                                                    
                                                }
                                                
                                            }
                                            
                                         
                                         
                                         
                                         }
                                        
                                        
                                    }
                                    
                                    
                                }
                                
                                
                                
                                
                            }
                            
                         
                         }
                     
                     }   
                         
                        } 
                 
             }
            }            //calculation for pie graph
             
                
                
             for (i = 0; i < $scope.networkmaparray.length; i++) {
                if($scope.networkmaparray[i].advertiserId==advertiserId)
                {
                    // console.log("enter the advertiser bar grap");
                    
                
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                   
                       
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                            {
                      if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                 for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                   if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        { if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                               if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                    $scope.advfboverallspend=$scope.advfboverallspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                     $scope.advfboverallimpression=$scope.advfboverallimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.advfboverallclicks=$scope.advfboverallclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                     $scope.advfboverallactions=$scope.advfboverallactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                     
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                }
                                                
                                            }
                                            
                                       }
                                      
                                        
                                    }
                                    
                                     
                                }
                                
                              
                                }
                            }
                        
                          else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                        {
                           if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent);
                              
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       
                                        
                                
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]);
                                            
                                        //      $scope.advdualcampaign=   $scope.advdualcampaign+1;
                                            //// console.log("lenght of the campaign  "+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length);
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                  //  // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.advtwoverallspend=$scope.advtwoverallspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                     $scope.advtwoverallimpression=$scope.advtwoverallimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.advtwoverallclicks=$scope.advtwoverallclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                     $scope.advtwoverallactions=$scope.advtwoverallactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                 //   // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                
                                                }
                                                
                                            }
                                            
                                      
                                        
                                         
                                         
                                         
                                         
                                         }
                                      
                                        
                                    }
                                    
                                     
                                }
                                
                                
                              
                                
                            
                                } 
                        }
                    
                         
                        
                         
                        } 
                 
             }
            }       //calcution for bar graph
                
          
               }
                
                
                
                
                
             $scope.advtodaytotalnetworkspend=$scope.advtodaysinglenetworkspend+$scope.advtodaydoublenetworkspend;
             $scope.advtodaytotalnetworkimpression=$scope.advtodaysinglenetworkimpression+ $scope.advtodaydoublenetworkimpression;       
             $scope.advtodaytotalnetworkclicks=$scope.advtodaysinglenetworkclicks+$scope.advtodaydoublenetworkclicks;
             $scope.advtodaytotalnetworkactions=$scope.advtodaysinglenetworkactions+$scope.advtodaydoublenetworkactions;
             
            $scope.advtotalyesterdaynetworkspend= $scope.advyesterdaysinglenetworkspend+ $scope.advyesterdaydoublenetworkspend;
            $scope.advtotalyesterdaynetworkimpression=  $scope.advyesterdaysinglenetworkimpression+ $scope.advyesterdaydoublenetworkimpression;
            $scope.advtotalyesterdaynetworkclicks=$scope.advyesterdaysinglenetworkclicks+$scope.advyesterdaydoublenetworkclicks;
            $scope.advtotalyesterdaynetworkactions=$scope.advyesterdaysinglenetworkactions+$scope.advyesterdaydoublenetworkactions;
             
    
                
             $scope.advtotalcampaign=$scope.advsinglecampign+$scope.advdualcampaign;  
              
              
              $scope.dualpercamp=($scope.advdualcampaign/$scope.advtotalcampaign)*80;
              $scope.advsinglepercamp=80-$scope.dualpercamp;
                
              // console.log("Advertiser data");
              // console.log(  "single total spend :"  +$scope.advtotalsinglenetworkspend+"      "+" total impression  "+ $scope.advtotalsinglenetworkimpression+"     total clicks  "+$scope.advtotalsinglenetworkclicks +"     total actions "+ $scope.advtotalsinglenetworkactions);
              // console.log(  "double total spend :"  +$scope.advtotaldoublenetworkspend+"      "+" total impression  "+ $scope.advtotaldoublenetworkimpression+"     total clicks  "+$scope.advtotaldoublenetworkclicks +"     total actions "+ $scope.advtotaldoublenetworkactions);
              // console.log(  "single today spend :"  +$scope.advtodaysinglenetworkspend+"      "+" today impression  "+ $scope.advtodaysinglenetworkimpression+"     today clicks  "+$scope.advtodaysinglenetworkclicks +"     today actions "+ $scope.advtodaysinglenetworkactions);  
              // console.log(  "double today spend :"  +$scope.advtodaydoublenetworkspend+"      "+" today impression  "+ $scope.advtodaydoublenetworkimpression+"     today clicks  "+$scope.advtodaydoublenetworkclicks +"     today actions "+ $scope.advtodaydoublenetworkactions);
              // console.log(  "single yesterday spend :"  +$scope.advyesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.advyesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.advyesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.advyesterdaysinglenetworkactions);  
              // console.log(  "double yesterday spend :"  +$scope.advyesterdaydoublenetworkspend+"      "+" yesterday impression  "+ $scope.advyesterdaydoublenetworkimpression+"     yesterday clicks  "+$scope.advyesterdaydoublenetworkclicks +"     yesterday actions "+ $scope.advyesterdaydoublenetworkactions);
              
          
               // console.log(  "fb   total spend :"  +$scope.totalfbspend+"      "+" total impression  "+ $scope.totalfbimpression+"     total clicks  "+$scope.totalfbclicks +"     total actions "+ $scope.totalfbactions);
               // console.log(  "tw   total spend :"  +$scope.totaltwspend+"      "+" total impression  "+ $scope.totaltwimpression+"     total clicks  "+$scope.totaltwclicks +"     total actions "+ $scope.totaltwactions);
           
               
                
                if($scope.flag)
                {
                 $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                 $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.filldiv=false;
                $scope.nettabselection = true;  
            if(!$scope.advertiserhasoverallinsights)
            {
                $scope.nettabselection = false;  
                  $scope.noinsightsalladvOverall = true;
            
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                 $scope.filldiv=true; $scope.network=false;
                 $scope.arrowshow=false;
                  $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                
            }
                    
                    
                    
                    $scope.totalimpressions=$scope.advtotalsinglenetworkimpression+$scope.advtotaldoublenetworkimpression;
                    $scope.totalclicks=$scope.advtotalsinglenetworkclicks+$scope.advtotaldoublenetworkclicks;
                    $scope.totalaction=$scope.advtotalsinglenetworkactions+$scope.advtotaldoublenetworkactions;
                    $scope.totalspend=$scope.advtotalsinglenetworkspend+$scope.advtotaldoublenetworkspend;
        
           
                   
                    
                 //    $scope.network = true;
                  //   $scope.nettabselection = true;  
                      plotValuesPiechart($scope.advtotalsinglenetworkimpression,$scope.advtotalsinglenetworkspend,$scope.advtotalsinglenetworkclicks,$scope.advtotalsinglenetworkactions,$scope.advtotaldoublenetworkimpression, $scope.advtotaldoublenetworkclicks   , $scope.advtotaldoublenetworkactions, $scope.advtotaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend,  $scope.advsinglepercamp, $scope.dualpercamp,    $scope.morecontibution);
                   
                     $scope.actualtwitteroverall($scope.advtwoverallimpression, $scope.advtwoverallclicks, $scope.advtwoverallactions, $scope.advtwoverallspend,$scope.advfboverallimpression, $scope.advfboverallclicks, $scope.advfboverallactions, $scope.advfboverallspend);
                     $scope.actualfacebookoverall($scope.advfboverallimpression, $scope.advfboverallclicks, $scope.advfboverallactions, $scope.advfboverallspend,$scope.advtwoverallimpression, $scope.advtwoverallclicks, $scope.advtwoverallactions, $scope.advtwoverallspend);
                }
                else
                {
                $scope.arrowshow=true;
                $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.nettabselection = true;
                 $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                if(!$scope.advertiserhastodayinsights)
                {
                
                  $scope.noinsightsadvToaday = true;
            
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                $scope.filldiv=true; $scope.network=false;
                $scope.arrowshow=false;
                $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.nettabselection = false;  
                  
                 
            }
                  //  $scope.adimpressionstoday=$scope.advtodaytotalnetworkimpression;
                  //  $scope.adclickstoday = $scope.advtodaytotalnetworkclicks;
                  //  $scope.adspendtoday= $scope.advtodaytotalnetworkspend;
                  //  $scope.adcallToActiontoday=  $scope.advtodaytotalnetworkactions;
              
                   $scope.img = true;
                    $scope.actualtwitteroverall($scope.advtwoverallimpression, $scope.advtwoverallclicks, $scope.advtwoverallactions, $scope.advtwoverallspend,$scope.advfboverallimpression, $scope.advfboverallclicks, $scope.advfboverallactions, $scope.advfboverallspend);
                     $scope.actualfacebookoverall($scope.advfboverallimpression, $scope.advfboverallclicks, $scope.advfboverallactions, $scope.advfboverallspend,$scope.advtwoverallimpression, $scope.advtwoverallclicks, $scope.advtwoverallactions, $scope.advtwoverallspend);
               
                   plotValuesPiechart($scope.advtodaysinglenetworkimpression,$scope.advtodaysinglenetworkspend,$scope.advtodaysinglenetworkclicks,$scope.advtodaysinglenetworkactions,$scope.advtodaydoublenetworkimpression, $scope.advtodaydoublenetworkclicks   , $scope.advtodaydoublenetworkactions, $scope.advtodaydoublenetworkspend, $scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.advsinglepercamp, $scope.dualpercamp ,   $scope.morecontibution);
                  
                   
                        if ($scope.advtotalyesterdaynetworkspend > $scope.advtodaytotalnetworkspend)
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = true;
                            $scope.equalarrow4 = false;
                        }
                        else if ($scope.advtotalyesterdaynetworkspend < $scope.advtodaytotalnetworkspend)
                        {
                            $scope.uparrow4 = true;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = false;
                        }
                        else
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = true;
                            //alert('hi')
                        }
                 
             //     // console.log("$scope.advtotalyesterdaynetworkactions  "+$scope.advtotalyesterdaynetworkactions+ " $scope.advtodaytotalnetworkactions "+  $scope.advtodaytotalnetworkactions);
                        if ($scope.advtotalyesterdaynetworkactions > $scope.advtodaytotalnetworkactions)
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = true;
                            $scope.equalarrow3 = false;
                        }

                        else if ($scope.advtotalyesterdaynetworkactions < $scope.advtodaytotalnetworkactions)
                        {
                            $scope.uparrow3 = true;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = false;
                        }
                        else
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = true;
                            // alert('hi')
                        }

                       if ($scope.advtotalyesterdaynetworkclicks > $scope.advtodaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = true;
                            $scope.equalarrow2 = false;
                        }

                        else if ($scope.advtotalyesterdaynetworkclicks < $scope.advtodaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = true;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = false;
                        }
                        else {
                            // alert('hi')
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = true;
                        }

                   
                   
                        if ($scope.advtotalyesterdaynetworkimpression > $scope.advtodaytotalnetworkimpression)
                        {
                            $scope.uparrow = false;
                            $scope.downarrow = true;
                            $scope.equalarrow = false;

                        }
                        else if ($scope.advtotalyesterdaynetworkimpression < $scope.advtodaytotalnetworkimpression)
                        {
                            $scope.uparrow = true;

                            $scope.downarrow = false;
                            $scope.equalarrow = false;
                        }
                        else
                        {   //alert('hi')
                            $scope.uparrow = false;
                            $scope.downarrow = false;
                            $scope.equalarrow = true;
                        }

                    
                      
                    
                   
                   
               }
            
        }
               
        else{
              $scope.selectedcampaign="";
                 if($scope.flag)
                {
                 $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                   $scope.graphfacebook = true;
                    $scope.graphtwitter = false;
                    $scope.graphinstagram = false;
                    $scope.graphgoogle = false;
                    $scope.graphbing = false;
                    $scope.filldiv=false;
                    $scope.nettabselection = true;  
                    $scope.totalimpressions=$scope.totalsinglenetworkimpression+$scope.totaldoublenetworkimpression;
                    $scope.totalclicks=$scope.totalsinglenetworkclicks+$scope.totaldoublenetworkclicks;
                    $scope.totalaction=$scope.totalsinglenetworkactions+$scope.totaldoublenetworkactions;
                    $scope.totalspend=$scope.totalsinglenetworkspend+$scope.totaldoublenetworkspend;

           
        
                    
                   $scope.nettabselection = true;  
                   plotValuesPiechart($scope.totalsinglenetworkimpression,$scope.totalsinglenetworkspend,$scope.totalsinglenetworkclicks,$scope.totalsinglenetworkactions,$scope.totaldoublenetworkimpression, $scope.totaldoublenetworkclicks   , $scope.totaldoublenetworkactions, $scope.totaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.onloadsinglecampper,$scope.onloaddoublecampper  ,  $scope.morecontibution);
                   $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend,$scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend);
                   $scope.actualfacebookoverall($scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend,$scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend);
               }
               else             
               {
                   
                     $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                   
                  //     $scope.adimpressionstoday=   $scope.todaytotalnetworkimpression;
                   //     $scope.adclickstoday =  $scope.todaytotalnetworkclicks;
                   //     $scope.adspendtoday=$scope.todaytotalnetworkspend;
                   //     $scope.adcallToActiontoday=  $scope.todaytotalnetworkactions;

                    $scope.filldiv=false;
                  $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.arrowshow=true;
                   $scope.nettabselection = true;  
                   $scope.img = true;
                      $scope.actualtwitteroverall($scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend,$scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend);
                   $scope.actualfacebookoverall($scope.totalfbimpression, $scope.totalfbclicks, $scope.totalfbactions, $scope.totalfbspend,$scope.totaltwimpression, $scope.totaltwclicks, $scope.totaltwactions, $scope.totaltwspend);
           
                   plotValuesPiechart($scope.todaysinglenetworkimpression,$scope.todaysinglenetworkspend,$scope.todaysinglenetworkclicks,$scope.todaysinglenetworkactions,$scope.todaydoublenetworkimpression, $scope.todaydoublenetworkclicks   , $scope.todaydoublenetworkactions, $scope.todaydoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.onloadsinglecampper,$scope.onloaddoublecampper,    $scope.morecontibution);
                  
                   
                        if ($scope.totalyesterdaynetworkspend > $scope.todaytotalnetworkspend)
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = true;
                            $scope.equalarrow4 = false;
                        }
                        else if ($scope.totalyesterdaynetworkspend < $scope.todaytotalnetworkspend)
                        {
                            $scope.uparrow4 = true;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = false;
                        }
                        else
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = true;
                            //alert('hi')
                        }
                 
                 
                        if ($scope.totalyesterdaynetworkactions > $scope.todaytotalnetworkactions)
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = true;
                            $scope.equalarrow3 = false;
                        }

                        else if ($scope.totalyesterdaynetworkactions < $scope.todaytotalnetworkactions)
                        {
                            $scope.uparrow3 = true;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = false;
                        }
                        else
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = true;
                            // alert('hi')
                        }

                       if ($scope.totalyesterdaynetworkclicks > $scope.todaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = true;
                            $scope.equalarrow2 = false;
                        }

                        else if ($scope.totalyesterdaynetworkclicks < $scope.todaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = true;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = false;
                        }
                        else {
                            // alert('hi')
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = true;
                        }

                   
                   
                        if ($scope.totalyesterdaynetworkimpression > $scope.todaytotalnetworkimpression)
                        {
                            $scope.uparrow = false;
                            $scope.downarrow = true;
                            $scope.equalarrow = false;

                        }
                        else if ($scope.totalyesterdaynetworkimpression < $scope.todaytotalnetworkimpression)
                        {
                            $scope.uparrow = true;

                            $scope.downarrow = false;
                            $scope.equalarrow = false;
                        }
                        else
                        {   //alert('hi')
                            $scope.uparrow = false;
                            $scope.downarrow = false;
                            $scope.equalarrow = true;
                        }

                    
                      
                    
                   
                   
               }
                   

        }
        }
        //FETCHPARENTCAMPAIGN

        $scope.parentselection = function (_obj)
        {
            $scope.arrowshow=true;
        $scope.noingightsparenttoday = false;
        $scope.noingightsparentoverall=false;
        
        $scope.noinsightsalladvToaday = false;
        $scope.noinsightsalladvOverall = false;
       
        $scope.noinsightsadvToaday = false;
        $scope.noinsightsadvOverall = false;
       
        $scope.noingightschildtoday = false;
        $scope.noingightschildoverall = false;
            
            
            $scope.parentselect=true;
            $scope.childselect=false;
            //// console.log(JSON.stringify($scope.networkmaparray,null,2));
        //    // console.log(_obj);
            $scope.childids=[];
            $scope.status = "";
            $scope.parentChildShow = !$scope.parentChildShow;
//            // console.log("parent selection", _obj);
            $scope.selectedParentChildCampaign = _obj;
           $scope.selectedcampaign  = _obj.name;
           $scope.selectedparent=_obj;
      //    // console.log(JSON.stringify($scope.networkmaparray, null, 2));
        //    var noInsights = true;
            
            // console.log(_obj);
            $scope.parenttotalsinglenetworkspend=0;
            $scope.parenttotalsinglenetworkimpression=0;
            $scope.parenttotalsinglenetworkclicks=0;
            $scope.parenttotalsinglenetworkactions=0;
            $scope.parenttotaldoublenetworkspend=0;
            $scope.parenttotaldoublenetworkimpression=0;
            $scope.parenttotaldoublenetworkclicks=0;
            $scope.parenttotaldoublenetworkactions=0;
            
            $scope.parenttodaysinglenetworkspend=0;
            $scope.parenttodaysinglenetworkimpression=0;
            $scope.parenttodaysinglenetworkclicks=0;
            $scope.parenttodaysinglenetworkactions=0;
            $scope.parenttodaydoublenetworkspend=0;
            $scope.parenttodaydoublenetworkimpression=0;
            $scope.parenttodaydoublenetworkclicks=0;
            $scope.parenttodaydoublenetworkactions=0;
            
            
            
            
            $scope.parentyesterdaysinglenetworkspend=0;
            $scope.parentyesterdaysinglenetworkimpression=0;
            $scope.parentyesterdaysinglenetworkclicks=0;
            $scope.parentyesterdaysinglenetworkactions=0;
            $scope.parentyesterdaydoublenetworkspend=0;
            $scope.parentyesterdaydoublenetworkimpression=0;
            $scope.parentyesterdaydoublenetworkclicks=0;
            $scope.parentyesterdaydoublenetworkactions=0; 
                
            $scope.parentsinglecamp=0;
            $scope.parentdoublecamp=0;
            $scope.totalcmp=0;
            
            
            $scope.parfboverallspend=0
            $scope.parfboverallclicks=0;
            $scope.parfboverallactions=0;
            $scope.parfboverallimpression=0;
            
            $scope.partwoverallspend=0
            $scope.partwoverallclicks=0;
            $scope.partwoverallactions=0;
            $scope.partwoverallimpression=0;
          
           $scope.parenthasoverallinsights=false;
            $scope.parenthastodayinsights=false;
          
           $scope.filldiv=false;
          
            $scope.twittercamp=0;
            $scope.facebookcamp=0;
           
            
          
          
          
          
          
          
          
          
          
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                
                
                  
            {
                
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                     if($scope.networkmaparray[i].networkDetails.length > 1)
                     {
                       
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                         //   // console.log($scope.networkmaparray[i].networkDetails[j]);
                      if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent);
                              
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].id==_obj.id)
                                    {
                                    
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       
                                        
                                
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]);
                                            if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                                            {
                                            $scope.facebookcamp=$scope.facebookcamp+1;
                                            }
                                            else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                                            {
                                                
                                             $scope.twittercamp=$scope.twittercamp+1;   
                                            }
                                                        //// console.log("lenght of the campaign  "+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length);
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                  //  // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.parenttotaldoublenetworkspend=$scope.parenttotaldoublenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                     $scope.parenttotaldoublenetworkimpression=$scope.parenttotaldoublenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.parenttotaldoublenetworkclicks=$scope.parenttotaldoublenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                     $scope.parenttotaldoublenetworkactions=$scope.parenttotaldoublenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                 //   // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                     $scope.parenthasoverallinsights=true;
                                                    
                                                    
                                                }
                                                
                                            }
                                            
                                      
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("todayinsights"))
                                            {
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                 //   // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.parenttodaydoublenetworkspend=$scope.parenttodaydoublenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].spend;
                                                     $scope.parenttodaydoublenetworkimpression=$scope.parenttodaydoublenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].impressions;
                                                      $scope.parenttodaydoublenetworkclicks=$scope.parenttodaydoublenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].clicks;
                                                     $scope.parenttodaydoublenetworkactions=$scope.parenttodaydoublenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].actions;
                                                     $scope.parenthastodayinsights=true;
                                                }
                                                
                                            }
                                            
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("yesterdayinsight"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.parentyesterdaydoublenetworkspend=$scope.parentyesterdaydoublenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].spend;
                                                     $scope.parentyesterdaydoublenetworkimpression=$scope.parentyesterdaydoublenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].impressions;
                                                      $scope.parentyesterdaydoublenetworkclicks=$scope.parentyesterdaydoublenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].clicks;
                                                     $scope.parentyesterdaydoublenetworkactions=$scope.parentyesterdaydoublenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].actions;
                                                 //   // console.log(  "double yesterday spend :"  +$scope.yesterdaydoublenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaydoublenetworkimpression+"     yesterday clicks  "+$scope.yesterdaydoublenetworkclicks +"     yesterday actions "+ $scope.yesterdaydoublenetworkactions);
                                                    
                                                }
                                                
                                            }
                                            
                                         
                                         
                                         
                                         
                                         }
                                      
                                        
                                    }
                                
                                        }
                                     
                                }
                                
                                
                              
                                
                            
                                }}
                            
                    
                         }
                      else
                     {
                         
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                     if($scope.networkmaparray[i].networkDetails[j].parent[k].id===_obj.id)
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    {
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                                            {
                                            $scope.facebookcamp=$scope.facebookcamp+1;
                                            }
                                            else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                                            {
                                                
                                             $scope.twittercamp=$scope.twittercamp+1;   
                                            }
                                            
                                            
                                             $scope.parentsinglecamp= $scope.parentsinglecamp+1;
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                      $scope.parenttotalsinglenetworkspend=$scope.parenttotalsinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                      $scope.parenttotalsinglenetworkimpression=$scope.parenttotalsinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.parenttotalsinglenetworkclicks=$scope.parenttotalsinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                      $scope.parenttotalsinglenetworkactions=$scope.parenttotalsinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                //     // console.log(  "Single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                    
                                                    $scope.parenthasoverallinsights=true;
                                                    
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                  
                                                }
                                                
                                            }
                                            
                                        
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("todayinsights"))
                                            {
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                 //   // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.parenttodaysinglenetworkspend=$scope.parenttodaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].spend;
                                                     $scope.parenttodaysinglenetworkimpression=$scope.parenttodaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].impressions;
                                                      $scope.parenttodaysinglenetworkclicks=$scope.parenttodaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].clicks;
                                                     $scope.parenttodaysinglenetworkactions=$scope.parenttodaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].actions;
                                                    
                                                    $scope.parenthastodayinsights=true;
                                                }
                                                
                                            }
                                            
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("yesterdayinsight"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                    
                                                    
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.parentyesterdaysinglenetworkspend=$scope.parentyesterdaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].spend;
                                                     $scope.parentyesterdaysinglenetworkimpression=$scope.parentyesterdaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].impressions;
                                                      $scope.parentyesterdaysinglenetworkclicks=$scope.parentyesterdaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].clicks;
                                                     $scope.parentyesterdaysinglenetworkactions=$scope.parentyesterdaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].actions;
                                                 //   // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);
                                                    
                                                }
                                                
                                            }
                                            
                                         
                                         
                                         
                                         }
                                        
                                        
                                    }
                                    
                                    
                                }
                                
                                
                                
                                
                            }
                            
                         
                         }
                     
                     }   
                         
                     } }}          //pie chart value
    
             for (i = 0; i < $scope.networkmaparray.length; i++) {
                
                    // console.log("enter the parent bar grap");
                     if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                   
                       
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                            {
                      if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                 for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                   if($scope.networkmaparray[i].networkDetails[j].parent[k].id==_obj.id)
                                   if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        { if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                               if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                    $scope.parfboverallspend=$scope.parfboverallspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                     $scope.parfboverallimpression=$scope.parfboverallimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.parfboverallclicks=$scope.parfboverallclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                     $scope.parfboverallactions=$scope.parfboverallactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                          
                                                
                                                     
                                                
                                                }
                                                
                                            }
                                            
                                       }
                                      
                                        
                                    }
                                    
                                     
                                }
                                
                              
                                }
                            }
                        
                          else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                        {
                           if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent);
                              
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    { 
                                       
                                        
                                
                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id==_obj.id)
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]);
                                            
                                        //      $scope.advdualcampaign=   $scope.advdualcampaign+1;
                                            //// console.log("lenght of the campaign  "+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length);
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                  //  // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.partwoverallspend=$scope.partwoverallspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                     $scope.partwoverallimpression=$scope.partwoverallimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.partwoverallclicks=$scope.partwoverallclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                     $scope.partwoverallactions=$scope.partwoverallactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                 //   // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                
                                                
                                                
                                                     
                                                
                                                }
                                                
                                            }
                                            
                                      
                                        
                                         
                                         
                                         
                                         
                                         }
                                      
                                        
                                    }
                                    
                                     
                                }
                                
                                
                              
                                
                            
                                } 
                        }
                    
                         
                        
                         
                        } 
                 
             }
            }      //calcution for bar graph
                
          
                      //bar chart cal
              // console.log("parent data");
            //  // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
            //  // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
            ///  // console.log(  "single today spend :"  +$scope.todaysinglenetworkspend+"      "+" today impression  "+ $scope.todaysinglenetworkimpression+"     today clicks  "+$scope.todaysinglenetworkclicks +"     today actions "+ $scope.todaysinglenetworkactions);  
           //   // console.log(  "double today spend :"  +$scope.todaydoublenetworkspend+"      "+" today impression  "+ $scope.todaydoublenetworkimpression+"     today clicks  "+$scope.todaydoublenetworkclicks +"     today actions "+ $scope.todaydoublenetworkactions);
            //  // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);  
            //  // console.log(  "double yesterday spend :"  +$scope.yesterdaydoublenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaydoublenetworkimpression+"     yesterday clicks  "+$scope.yesterdaydoublenetworkclicks +"     yesterday actions "+ $scope.yesterdaydoublenetworkactions);
           
            
             $scope.partodaytotalnetworkspend=$scope.parenttodaysinglenetworkspend+$scope.parenttodaydoublenetworkspend;
             $scope.partodaytotalnetworkimpression=$scope.parenttodaysinglenetworkimpression+ $scope.parenttodaydoublenetworkimpression;       
             $scope.partodaytotalnetworkclicks=$scope.parenttodaysinglenetworkclicks+$scope.parenttodaydoublenetworkclicks;
             $scope.partodaytotalnetworkactions=$scope.parenttodaysinglenetworkactions+$scope.parenttodaydoublenetworkactions;
             
            $scope.partotalyesterdaynetworkspend= $scope.parentyesterdaysinglenetworkspend+ $scope.parentyesterdaydoublenetworkspend;
            $scope.partotalyesterdaynetworkimpression=  $scope.parentyesterdaysinglenetworkimpression+ $scope.parentyesterdaydoublenetworkimpression;
            $scope.partotalyesterdaynetworkclicks=$scope.parentyesterdaysinglenetworkclicks+$scope.parentyesterdaydoublenetworkclicks;
            $scope.partotalyesterdaynetworkactions=$scope.parentyesterdaydoublenetworkclicks+$scope.parentyesterdaydoublenetworkactions;
             
           
            
            
            console.log($scope.parentsinglecamp , $scope.parentdoublecamp);
            if(($scope.twittercamp>0)&&($scope.facebookcamp>0))
            {
                $scope.parentdoublecamp=$scope.twittercamp+$scope.facebookcamp; 
            }
            else
            {
                if($scope.twittercamp>0)
                {
                 $scope.parentsinglecamp =$scope.twittercamp;
                }else if($scope.facebookcamp>0)
                {
                 $scope.parentsinglecamp =$scope.facebookcamp;
                }
                   
                
            }
          //   console.log("After "+ $scope.twittercamp , $scope.facebookcamp);
           //   console.log("After "+ $scope.parentsinglecamp , $scope.parentdoublecamp);
          
          
            $scope.totalcmp= $scope.parentsinglecamp+   $scope.parentdoublecamp;
            $scope.singlecampper=($scope.parentsinglecamp/$scope.totalcmp)*80;
            $scope.doublecampper=80-$scope.singlecampper;
            
            
        
            
            
            if($scope.flag)
            {
                
            if($scope.parenthasoverallinsights)
            {  $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.filldiv=false;
                $scope.nettabselection = true;  
            }
            else
            {
                $scope.noingightsparentoverall=true;
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                 $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                $scope.filldiv=true; $scope.network=false;
                $scope.arrowshow=false;
                $scope.nettabselection = false;  
            }
                
                
                
                
                
                $scope.totalimpressions=$scope.parenttotalsinglenetworkimpression+$scope.parenttotaldoublenetworkimpression;
                $scope.totalclicks=$scope.parenttotalsinglenetworkclicks+$scope.parenttotaldoublenetworkclicks;
                $scope.totalaction=$scope.parenttotalsinglenetworkactions+$scope.parenttotaldoublenetworkactions;
                $scope.totalspend=$scope.parenttotalsinglenetworkspend+$scope.parenttotaldoublenetworkspend;


                
            $scope.network = true;
            plotValuesPiechart($scope.parenttotalsinglenetworkimpression,$scope.parenttotalsinglenetworkspend,$scope.parenttotalsinglenetworkclicks,$scope.parenttotalsinglenetworkactions,$scope.parenttotaldoublenetworkimpression, $scope.parenttotaldoublenetworkclicks   , $scope.parenttotaldoublenetworkactions, $scope.parenttotaldoublenetworkspend, $scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.singlecampper, $scope.doublecampper,    $scope.morecontibution);
            $scope.actualtwitteroverall($scope.partwoverallimpression, $scope.partwoverallclicks, $scope.partwoverallactions, $scope.partwoverallspend,$scope.parfboverallimpression, $scope.parfboverallclicks, $scope.parfboverallactions, $scope.parfboverallspend);
            $scope.actualfacebookoverall($scope.parfboverallimpression, $scope.parfboverallclicks, $scope.parfboverallactions, $scope.parfboverallspend,$scope.partwoverallimpression, $scope.partwoverallclicks, $scope.partwoverallactions, $scope.partwoverallspend);
            }
            else
          {
              
            if($scope.parenthastodayinsights)
            {
                  $("#pieChart1all").show();$scope.display=true;
                $("#pieChart2all").show();
                $("#pieChart3all").show();
                $("#pieChart4all").show();
                 $scope.actualtwitteroverall($scope.partwoverallimpression, $scope.partwoverallclicks, $scope.partwoverallactions, $scope.partwoverallspend,$scope.parfboverallimpression, $scope.parfboverallclicks, $scope.parfboverallactions, $scope.parfboverallspend);
            $scope.actualfacebookoverall($scope.parfboverallimpression, $scope.parfboverallclicks, $scope.parfboverallactions, $scope.parfboverallspend,$scope.partwoverallimpression, $scope.partwoverallclicks, $scope.partwoverallactions, $scope.partwoverallspend);
           $scope.filldiv=false;
                  $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                 $scope.nettabselection = true; 
                 $scope.network=true;
            
                  $scope.adimpressionstoday=   $scope.partodaytotalnetworkimpression;
                    $scope.adclickstoday = $scope.partodaytotalnetworkclicks;
                    $scope.adspendtoday= $scope.partodaytotalnetworkspend;
                    $scope.adcallToActiontoday=  $scope.partodaytotalnetworkactions;

                //   $scope.nettabselection = false;  
                   $scope.img = true;
                   plotValuesPiechart($scope.parenttodaysinglenetworkimpression,$scope.parenttodaysinglenetworkspend,$scope.parenttodaysinglenetworkclicks,$scope.parenttodaysinglenetworkactions,$scope.parenttodaydoublenetworkimpression, $scope.parenttodaydoublenetworkclicks   , $scope.parenttodaydoublenetworkactions, $scope.parenttodaydoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend, $scope.singlecampper,$scope.doublecampper,$scope.morecontibution);
                  
                   
                        if ($scope.partotalyesterdaynetworkspend > $scope.partodaytotalnetworkspend)
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = true;
                            $scope.equalarrow4 = false;
                        }
                        else if ($scope.partotalyesterdaynetworkspend < $scope.partodaytotalnetworkspend)
                        {
                            $scope.uparrow4 = true;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = false;
                        }
                        else
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = true;
                            //alert('hi')
                        }
                 
                 
                        if ($scope.partotalyesterdaynetworkactions > $scope.partodaytotalnetworkactions)
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = true;
                            $scope.equalarrow3 = false;
                        }

                        else if ($scope.partotalyesterdaynetworkactions < $scope.partodaytotalnetworkactions)
                        {
                            $scope.uparrow3 = true;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = false;
                        }
                        else
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = true;
                            // alert('hi')
                        }

                       if ($scope.partotalyesterdaynetworkclicks > $scope.partodaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = true;
                            $scope.equalarrow2 = false;
                        }

                        else if ($scope.partotalyesterdaynetworkclicks < $scope.partodaytotalnetworkclicks)
                        {
                            $scope.uparrow2 = true;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = false;
                        }
                        else {
                            // alert('hi')
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = true;
                        }

                   
                   
                        if ($scope.partotalyesterdaynetworkimpression > $scope.partodaytotalnetworkimpression)
                        {
                            $scope.uparrow = false;
                            $scope.downarrow = true;
                            $scope.equalarrow = false;

                        }
                        else if ($scope.partotalyesterdaynetworkimpression < $scope.partodaytotalnetworkimpression)
                        {
                            $scope.uparrow = true;

                            $scope.downarrow = false;
                            $scope.equalarrow = false;
                        }
                        else
                        {   //alert('hi')
                            $scope.uparrow = false;
                            $scope.downarrow = false;
                            $scope.equalarrow = true;
                        }
                
                
                }
            else
            {
                $scope.noingightsparenttoday=true;
                 $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                $("#pieChart2all").hide();
                $("#pieChart3all").hide();
                $("#pieChart4all").hide();
                 $scope.filldiv=true; 
                 $scope.arrowshow=false;
                  $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                 $scope.nettabselection = false; 
                  $scope.network=false;
            }
                
               
              
                  

                    
                      
                    
                   
                   
               }
            
            
        };
      
      
         //FETCHCHILDCAMPAIGNSERVICETODAY
        $scope.childselection = function (_index,_obj)
        { $scope.filldiv=false;
            $scope.arrowshow=true;
        $scope.noingightsparenttoday = false;
        $scope.noinsightsalladvToaday = false;
        $scope.noinsightsalladvOverall = false;
        $scope.noinsightsadvToaday = false;
        $scope.noinsightsadvOverall = false;
        $scope.noingightsoveralltoday = false;
        $scope.noingightschildtoday = false;
        $scope.noingightschildoverall = false;
         $scope.noingightsparentoverall=false;   
          // console.log(_obj);
            $scope.selectedcampaign  = _obj.name;
            $scope.childidseleted=_obj;
           $scope.childinsig=false;
            $scope.childtodayin=false;
            $scope.childselect=true;
            $scope.childtotalsinglenetworkspend=0;
            $scope.childtotalsinglenetworkimpression=0;
            $scope.childtotalsinglenetworkclicks=0;
            $scope.childtotalsinglenetworkactions=0;
            $scope.childtotaldoublenetworkspend=0;
            $scope.childtotaldoublenetworkimpression=0;
            $scope.childtotaldoublenetworkclicks=0;
            $scope.childtotaldoublenetworkactions=0;
            
            $scope.childtodaysinglenetworkspend=0;
            $scope.childtodaysinglenetworkimpression=0;
            $scope.childtodaysinglenetworkclicks=0;
            $scope.childtodaysinglenetworkactions=0;
            $scope.childtodaydoublenetworkspend=0;
            $scope.childtodaydoublenetworkimpression=0;
            $scope.childtodaydoublenetworkclicks=0;
            $scope.childtodaydoublenetworkactions=0;
            
            
            
            
            $scope.childyesterdaysinglenetworkspend=0;
            $scope.childyesterdaysinglenetworkimpression=0;
            $scope.childyesterdaysinglenetworkclicks=0;
            $scope.childyesterdaysinglenetworkactions=0;
            $scope.childyesterdaydoublenetworkspend=0;
            $scope.childyesterdaydoublenetworkimpression=0;
            $scope.childyesterdaydoublenetworkclicks=0;
            $scope.childyesterdaydoublenetworkactions=0; 
         
         
            $scope.childfboverallspend=0
            $scope.childfboverallclicks=0;
            $scope.childfboverallactions=0;
            $scope.childfboverallimpression=0;
            
            $scope.childtwoverallspend=0
            $scope.childtwoverallclicks=0;
            $scope.childtwoverallactions=0;
            $scope.childtwoverallimpression=0;
          
             $scope.noingightschildoverall=false;
         
         
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                       
                   
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                            {
                                
                                for(k = 0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    
                                    
                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
                                    {
                                        
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id==_obj.id)
                                            {
                                                // console.log("enter child campaign");
                                                
                                                
                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("insights"))
                                            {
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length > 0)
                                                {
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                      $scope.childtotalsinglenetworkspend=$scope.childtotalsinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].spend;
                                                      $scope.childtotalsinglenetworkimpression=$scope.childtotalsinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].impressions;
                                                      $scope.childtotalsinglenetworkclicks=$scope.childtotalsinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].clicks;
                                                      $scope.childtotalsinglenetworkactions=$scope.childtotalsinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[0].actions;
                                                //     // console.log(  "Single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                   
                                                   if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.fbNetwork)
                                                   {
                                                        $scope.childfboverallspend= $scope.childtotalsinglenetworkspend;
                                                        $scope.childfboverallclicks=$scope.childtotalsinglenetworkclicks;
                                                        $scope.childfboverallactions=$scope.childtotalsinglenetworkactions;
                                                        $scope.childfboverallimpression=  $scope.childtotalsinglenetworkimpression;
            
                                                       
                                                   }
                                                   else if($scope.networkmaparray[i].networkDetails[j].networkURL==appSettings.twNetwork)
                                                   {
                                                       
                                                            $scope.childtwoverallspend=$scope.childtotalsinglenetworkspend
                                                            $scope.childtwoverallclicks=$scope.childtotalsinglenetworkclicks;
                                                            $scope.childtwoverallactions=$scope.childtotalsinglenetworkactions;
                                                            $scope.childtwoverallimpression=$scope.childtotalsinglenetworkimpression;
          
                                                       
                            
                                                   }
                                                  
                                                       $("#pieChart1all").show();$scope.display=true;
                                                      $("#pieChart2all").show();
                                                      $("#pieChart3all").show();
                                                      $("#pieChart4all").show();
                                                      $scope.graphfacebook = true;
                                                      $scope.graphtwitter = false;
                                                      $scope.graphinstagram = false;
                                                      $scope.graphgoogle = false;
                                                      $scope.graphbing = false;
                                                      $scope.nettabselection = true;
                                                      $scope.filldiv=false;
                                                }
                                                else
                                                {
                                                     $scope.childinsig=true;
                                                  //  $scope.noingightschildoverall=true;
                                                 
                                                        
                                                }
                                                
                                            }
                                            
                                        
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("todayinsights"))
                                            {
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "double total spend :"  +$scope.totaldoublenetworkspend+"      "+" total impression  "+ $scope.totaldoublenetworkimpression+"     total clicks  "+$scope.totaldoublenetworkclicks +"     total actions "+ $scope.totaldoublenetworkactions);
                                                    
                                                    
                                                 //   // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.childtodaysinglenetworkspend=$scope.childtodaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].spend;
                                                     $scope.childtodaysinglenetworkimpression=$scope.childtodaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].impressions;
                                                      $scope.childtodaysinglenetworkclicks=$scope.childtodaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].clicks;
                                                     $scope.childtodaysinglenetworkactions=$scope.childtodaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].todayinsights[0].actions;
                                                    
                                                }
                                                
                                            }
                                            else
                                            {
                                                      $scope.childtodayin=true;
                                                       $scope.graphfacebook = false;
                                                    $scope.graphtwitter = false;
                                                    $scope.graphinstagram = false;
                                                    $scope.graphgoogle = false;
                                                    $scope.graphbing = false;
                                                    $scope.filldiv=true; $scope.network=false;
                                                    $scope.arrowshow=false;
                                                    $scope.nettabselection = false;  
                                                      
                                               
                                            }
                                            
                                              if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].hasOwnProperty("yesterdayinsight"))
                                            {
                                                
                                
                                                
                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight.length > 0)
                                                {
                                                  //   // console.log($scope.networkmaparray[i].networkDetails[j])
                                                    //    // console.log(  "single total spend :"  +$scope.totalsinglenetworkspend+"      "+" total impression  "+ $scope.totalsinglenetworkimpression+"     total clicks  "+$scope.totalsinglenetworkclicks +"     total actions "+ $scope.totalsinglenetworkactions);
                                                    
                                                    
                                                   // // console.log($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights);
                                                     $scope.childyesterdaysinglenetworkspend=$scope.childyesterdaysinglenetworkspend+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].spend;
                                                     $scope.childyesterdaysinglenetworkimpression=$scope.childyesterdaysinglenetworkimpression+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].impressions;
                                                      $scope.childyesterdaysinglenetworkclicks=$scope.childyesterdaysinglenetworkclicks+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].clicks;
                                                     $scope.childyesterdaysinglenetworkactions=$scope.childyesterdaysinglenetworkactions+$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].yesterdayinsight[0].actions;
                                                 //   // console.log(  "single yesterday spend :"  +$scope.yesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.yesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.yesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.yesterdaysinglenetworkactions);
                                                    
                                                }
                                                
                                            }
                                            
                                         
                                            }
                                         
                                         }
                                        
                                        
                                    }
                                    
                                    
                                }
                                
                                
                                
                                
                            }
                            
                         
                         }
                     
                       
                         
                     } }
         
         
         
         
              // console.log("child selection");
              // console.log(  "single total spend :"  +$scope.childtotalsinglenetworkspend+"      "+" total impression  "+ $scope.childtotalsinglenetworkimpression+"     total clicks  "+$scope.childtotalsinglenetworkclicks +"     total actions "+ $scope.childtotalsinglenetworkactions);
          //    // console.log(  "double total spend :"  +$scope.childtotaldoublenetworkspend+"      "+" total impression  "+ $scope.childtotaldoublenetworkimpression+"     total clicks  "+$scope.childtotaldoublenetworkclicks +"     total actions "+ $scope.childtotaldoublenetworkactions);
              // console.log(  "single today spend :"  +$scope.childtodaysinglenetworkspend+"      "+" today impression  "+ $scope.childtodaysinglenetworkimpression+"     today clicks  "+$scope.childtodaysinglenetworkclicks +"     today actions "+ $scope.childtodaysinglenetworkactions);  
         //     // console.log(  "double today spend :"  +$scope.childtodaydoublenetworkspend+"      "+" today impression  "+ $scope.childtodaydoublenetworkimpression+"     today clicks  "+$scope.childtodaydoublenetworkclicks +"     today actions "+ $scope.childtodaydoublenetworkactions);
              // console.log(  "single yesterday spend :"  +$scope.childyesterdaysinglenetworkspend+"      "+" yesterday impression  "+ $scope.childyesterdaysinglenetworkimpression+"     yesterday clicks  "+$scope.childyesterdaysinglenetworkclicks +"     yesterday actions "+ $scope.childyesterdaysinglenetworkactions);  
            //  // console.log(  "double yesterday spend :"  +$scope.childyesterdaydoublenetworkspend+"      "+" yesterday impression  "+ $scope.childyesterdaydoublenetworkimpression+"     yesterday clicks  "+$scope.childyesterdaydoublenetworkclicks +"     yesterday actions "+ $scope.childyesterdaydoublenetworkactions);
              
         
         if($scope.flag)
         {
         //    $scope.totalimpressions=$scope.childtotalsinglenetworkimpression+$scope.childtotaldoublenetworkimpression;
          //      $scope.totalclicks=$scope.childtotalsinglenetworkclicks+$scope.childtotaldoublenetworkclicks;
          //      $scope.totalaction=$scope.childtotalsinglenetworkactions+$scope.childtotaldoublenetworkactions;
          //      $scope.totalspend=$scope.childtotalsinglenetworkspend+$scope.childtotaldoublenetworkspend;

             if($scope.childinsig==true)
             {
                    $scope.graphfacebook = false;
                    $scope.graphtwitter = false;
                    $scope.graphinstagram = false;
                    $scope.graphgoogle = false;
                    $scope.graphbing = false;
                    $scope.nettabselection = false;  
                  //  $scope.img = true;

                        $("#pieChart1all").hide();$scope.display=false;$scope.network=false;
                       $("#pieChart2all").hide();
                       $("#pieChart3all").hide();
                       $("#pieChart4all").hide();
                       $scope.filldiv=true; $scope.network=false;
                       $scope.arrowshow=false;
                        $scope.noingightschildoverall=true;
                 
             }else
             {
                  $scope.graphfacebook = true;
                    $scope.graphtwitter = false;
                    $scope.graphinstagram = false;
                    $scope.graphgoogle = false;
                    $scope.graphbing = false;
                    $scope.nettabselection = true; 
                     $scope.filldiv=false;
                      $("#pieChart1all").show();$scope.display=true;
                       $("#pieChart2all").show();
                       $("#pieChart3all").show();
                       $("#pieChart4all").show();
             }
          $scope.network = true;
          plotValuesPiechart( $scope.childtotalsinglenetworkimpression,$scope.childtotalsinglenetworkspend,$scope.childtotalsinglenetworkclicks,$scope.childtotalsinglenetworkactions,$scope.childtotaldoublenetworkimpression, $scope.childtotaldoublenetworkclicks   , $scope.childtotaldoublenetworkactions, $scope.childtotaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend,80,0,    $scope.morecontibution);
          $scope.actualtwitteroverall($scope.childtwoverallimpression, $scope.childtwoverallclicks, $scope.childtwoverallactions, $scope.childtwoverallspend,$scope.childfboverallimpression, $scope.childfboverallclicks, $scope.childfboverallactions, $scope.childfboverallspend);
          $scope.actualfacebookoverall($scope.childfboverallimpression, $scope.childfboverallclicks, $scope.childfboverallactions, $scope.childfboverallspend,$scope.childtwoverallimpression, $scope.childtwoverallclicks, $scope.childtwoverallactions, $scope.childtwoverallspend);
          }else
            {
                 $scope.filldiv=false;
                  $scope.graphfacebook = true;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                 $scope.nettabselection = true;
                 $scope.network=true;
                  $("#pieChart1all").show();$scope.display=true;
                       $("#pieChart2all").show();
                       $("#pieChart3all").show();
                       $("#pieChart4all").show();
                       
                if($scope.childtodayin==true)
                {
                //  plotValuesPiechart( '',$scope.childtotalsinglenetworkspend,$scope.childtotalsinglenetworkclicks,$scope.childtotalsinglenetworkactions,$scope.childtotaldoublenetworkimpression, $scope.childtotaldoublenetworkclicks   , $scope.childtotaldoublenetworkactions, $scope.childtotaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend,80,0,    $scope.morecontibution);
         
                    $scope.noingightschildtoday=true;
                     $("#pieChart1all").hide();$scope.display=false;
                       $("#pieChart2all").hide();
                       $("#pieChart3all").hide();
                       $("#pieChart4all").hide();
                       $scope.filldiv=true; 
                  $scope.graphfacebook = false;
                $scope.graphtwitter = false;
                $scope.graphinstagram = false;
                $scope.graphgoogle = false;
                $scope.graphbing = false;
                 $scope.nettabselection = false;
                 $scope.network=false;
                }
                
                    $scope.adimpressionstoday=   $scope.childtodaysinglenetworkimpression;
                    $scope.adclickstoday = $scope.childtodaysinglenetworkclicks;
                    $scope.adspendtoday= $scope.childtodaysinglenetworkspend;
                    $scope.adcallToActiontoday=  $scope.childtodaysinglenetworkactions;

                
                
                   $scope.nettabselection = true;  
                   $scope.img = true;
                    plotValuesPiechart( $scope.childtotalsinglenetworkimpression,$scope.childtotalsinglenetworkspend,$scope.childtotalsinglenetworkclicks,$scope.childtotalsinglenetworkactions,$scope.childtotaldoublenetworkimpression, $scope.childtotaldoublenetworkclicks   , $scope.childtotaldoublenetworkactions, $scope.childtotaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend,80,0,    $scope.morecontibution);
          $scope.actualtwitteroverall($scope.childtwoverallimpression, $scope.childtwoverallclicks, $scope.childtwoverallactions, $scope.childtwoverallspend,$scope.childfboverallimpression, $scope.childfboverallclicks, $scope.childfboverallactions, $scope.childfboverallspend);
          $scope.actualfacebookoverall($scope.childfboverallimpression, $scope.childfboverallclicks, $scope.childfboverallactions, $scope.childfboverallspend,$scope.childtwoverallimpression, $scope.childtwoverallclicks, $scope.childtwoverallactions, $scope.childtwoverallspend);
        
                    plotValuesPiechart( $scope.childtodaysinglenetworkimpression,$scope.childtodaysinglenetworkspend,$scope.childtodaysinglenetworkclicks,$scope.childtodaysinglenetworkactions,$scope.childtotaldoublenetworkimpression, $scope.childtotaldoublenetworkclicks   , $scope.childtotaldoublenetworkactions, $scope.childtotaldoublenetworkspend,$scope.moreimpressions,  $scope.moreclicks, $scope.moreactions,$scope.morespend,80,0,    $scope.morecontibution);
                   
                        if ($scope.childyesterdaysinglenetworkspend > $scope.childtodaysinglenetworkspend)
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = true;
                            $scope.equalarrow4 = false;
                        }
                        else if ($scope.childyesterdaysinglenetworkspend < $scope.childtodaysinglenetworkspend)
                        {
                            $scope.uparrow4 = true;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = false;
                        }
                        else
                        {
                            $scope.uparrow4 = false;
                            $scope.downarrow4 = false;
                            $scope.equalarrow4 = true;
                            //alert('hi')
                        }
                 
                 
                        if ($scope.childyesterdaysinglenetworkactions > $scope.childtodaysinglenetworkactions)
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = true;
                            $scope.equalarrow3 = false;
                        }

                        else if ($scope.childyesterdaysinglenetworkactions < $scope.childtodaysinglenetworkactions)
                        {
                            $scope.uparrow3 = true;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = false;
                        }
                        else
                        {
                            $scope.uparrow3 = false;
                            $scope.downarrow3 = false;
                            $scope.equalarrow3 = true;
                            // alert('hi')
                        }

                       if ($scope.childyesterdaysinglenetworkclicks > $scope.childtodaysinglenetworkclicks)
                        {
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = true;
                            $scope.equalarrow2 = false;
                        }

                        else if ($scope.childyesterdaysinglenetworkclicks < $scope.childtodaysinglenetworkclicks)
                        {
                            $scope.uparrow2 = true;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = false;
                        }
                        else {
                            // alert('hi')
                            $scope.uparrow2 = false;
                            $scope.downarrow2 = false;
                            $scope.equalarrow2 = true;
                        }

                   
                   
                        if ($scope.childyesterdaysinglenetworkimpression > $scope.childtodaysinglenetworkimpression)
                        {
                            $scope.uparrow = false;
                            $scope.downarrow = true;
                            $scope.equalarrow = false;

                        }
                        else if ($scope.childyesterdaysinglenetworkimpression < $scope.childtodaysinglenetworkimpression)
                        {
                            $scope.uparrow = true;

                            $scope.downarrow = false;
                            $scope.equalarrow = false;
                        }
                        else
                        {   //alert('hi')
                            $scope.uparrow = false;
                            $scope.downarrow = false;
                            $scope.equalarrow = true;
                        }

                    
                      
                    
                   
                   
               }
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         }
      
         $scope.updateCampaignDropDown = function()
        {
            $scope.wholeParentArray = [];
            $scope.wholechildArray = [];
            if($scope.advertiserId != "" && $scope.advertiserId != undefined)
            {
                $scope.selectedcampaign="";
//                    // console.log("advertiser selected but no network");
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.advertiserId == $scope.networkmaparray[i].advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                    
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent"
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                }
                                            
                                        }
                                        
                                }
                            }
                        }
                    }

                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].advertiserId == $scope.advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
            //                                                        if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].hasOwnProperty("campaigns"))
            //                                                        {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id
                                                            };
                                                        $scope.wholechildArray.push(obj);
                                                    }
            //                                                        }

                                                }
                                            
                                        }
                                }
                            }
                        }
                    }
                
            }else
                {
//                    // console.log("no advertiser and no network selected");
                    $scope.wholeParentArray = [];
                   $scope.wholechildArray = [];
                  
                  // console.log("empty advertiser is working fine")
                    $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
                   $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
                
            }
        };
 
 
              //if no campaign is selected
        $scope.nocampaignselection = function()
        {   $scope.childselect=false;
            $scope.selectedcampaign="";
         //   $scope.selectedcampbool = false;
         
         if($scope.advertiser!=="")
         {
             
                $scope.selectadvertiser($scope.advertiser); 
                
              
         }
         else
         {
              $scope.onloadoverallaccount();
          
         }
         
        }

   
   
   
        //onload function
        $scope.readCorrespondingInsightsOverall = function ()
        { $scope.filldiv=false;
      
            $scope.overall = true;
            $scope.today =false;
            $scope.overallData = true;
            $scope.currentData = false;
            
            $scope.nettabselection = true;  
            $scope.flag=true;
             $scope.graphfacebook = true;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
            $scope.network = false;
            $scope.nettabselection = true; 
             $scope.overallAllAdv = true;
             $scope.woserivce = false;
              angular.element('#today').css('background', '#ffffff');
              angular.element('#today').css('color', '#000000');
              angular.element('#overall').css('background', '#009688');
         
       //   plotValuesPiechart($scope.totaldoublenetworkimpression, $scope.totaldoublenetworkclicks   , $scope.totaldoublenetworkactions, $scope.totaldoublenetworkspend, $scope.totalsinglenetworkimpression,$scope.totalsinglenetworkspend,$scope.totalsinglenetworkclicks,$scope.totalsinglenetworkactions);
         
          $scope.arrow();
      if($scope.advertiser=="" && $scope.selectedcampaign=="" && !$scope.childselect)
      {
          $scope.onloadoverallaccount();
        
          
      }
      else{
           if($scope.childselect)
         {
      
              $scope.childselection(1,$scope.childidseleted);
         }
         else
         {
             if($scope.selectedcampaign!="" &&  $scope.parentselect)
             {
                 
                  $scope.parentselection($scope.selectedparent);
          
             }
             else 
                 if($scope.advertiser!="")
             {
              
             $scope.selectadvertiser($scope.advertiser);
                 
             }
          }
          }
         
         
        };
        $scope.readCorrespondingInsightsToday = function ()
        {
            $scope.filldiv=false;
            $scope.flag=false;
            $scope.overall = false;
            $scope.today =true;
            $scope.overallData = false;
            $scope.currentData = true;
            $scope.graphfacebook = true;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
            $scope.network = true;
            $scope.nettabselection = true;  
             $scope.overallAllAdv = false;
             $scope.woserivce = true;
              angular.element('#today').css('background', '#009688');
           angular.element('#today').css('color', '#ffffff');
           angular.element('#overall').css('background', '#ffffff');
         
            if($scope.advertiser=="" && $scope.selectedcampaign=="" && !$scope.childselect)
      {
          $scope.onloadoverallaccount();
    
      }
      else{
           if($scope.childselect)
         {
    
              $scope.childselection(1,$scope.childidseleted);
         }
         else
         {
             if($scope.selectedcampaign!="" &&  $scope.parentselect)
             {
                 
                  $scope.parentselection($scope.selectedparent);
          
                 
             }
             else 
                 if($scope.advertiser!="")
             {
                 
         
             $scope.selectadvertiser($scope.advertiser);
                 
             }
          }
          }
            
            
           
            
        };


   
        $scope.arrow =function()
            {
        $scope.uparrow = false;
        $scope.downarrow = false;
        $scope.equalarrow = false;
         $scope.uparrow2 = false;
        $scope.downarrow2 = false;
        $scope.equalarrow2 = false;
         $scope.uparrow3 = false;
        $scope.downarrow3 = false;
        $scope.equalarrow3 = false;
         $scope.uparrow4 = false;
        $scope.downarrow4 = false;
        $scope.equalarrow4 = false;
        
       
       
            }
   
   
   
        $scope.totalallparentimpressions = 0;
        $scope.totalallparentclicks = 0;
        $scope.totalallparentspend = 0;
        $scope.totalallparentaction = 0;

     

        //ChildArrowClick
        $scope.test = function (parentobj, _index) {

            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                //angular.element('#parent' + (i+1)).removeClass('selectparent');
                var el = angular.element('#parent' + (i + 1));
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        };
        //ChildArrowClick

   //Facebook Graph
        //angular.element('#overall').addClass('disabled');
        


        $scope.actualfacebookoverall = function (_impressions, _clicks, _action, _spend,tw_impressions, tw_clicks, tw_action, tw_spend)
        {
            $scope.graphtoverall=true;
            $scope.overall = true;
            $scope.today = false;
           $("#barGraph").empty();
           
              $(document).ready(function () {
    
        $('#tw').removeClass('selective');
          $('#tw').removeClass('active');
        $('#twa').css("background", "#f0f0f0");
         $('#fba').css("background", "#e1e1e1");
   
        $('#fb').addClass('selective');
        
            });
            
            // console.log("actual call is happening");
            // console.log("facebook bar grap  "+_impressions, _clicks, _action, _spend,tw_impressions, tw_clicks, tw_action, tw_spend);
           if(_impressions===0 && _clicks===0 && _action===0 && _spend===0 &&tw_impressions==0 && tw_clicks==0 && tw_action==0 && tw_spend==0)
           {
              // // console.log("if case working");
                var sampleData1 = [
                    
                 {"quarter": "Facebook", "metrics": "Impressions", "count":0, "me": 100},
                {"quarter": "Facebook", "metrics": "Clicks", "count":0, "me": 0},
                {"quarter": "Facebook", "metrics": "Actions", "count":0, "me": 0},
                {"quarter": "Facebook", "metrics": "Spend", "count":0    , "me": 0},
                {"quarter": "Twitter", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0},   
                
            ];
                     var options = {
                container: {
                    id: "#barGraph",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                 axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "me",                //affects the line
                    item: "metrics"
                    

                },
                scaling: {
                    x: 4,
                  columny: 1,
                    liney: 1
              },
           //   scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " "
                }
              
               
            };
              var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);
            // console.log();
             document.getElementById("barGraph").children[0].style.marginLeft="7px";
            document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[0].style.opacity = 0.0;
            document.getElementById("barGraph").children[0].children[0].children[4].children[0].style.fill ="#ffffff" ;
            document.getElementById("barGraph").children[0].children[0].children[4].children[0].style.stroke ="#ffffff" ;
            document.getElementById("barGraph").children[0].children[0].children[3].children[0].style.opacity ="#ffffff" ;
            document.getElementById("barGraph").children[0].children[0].children[3].children[0].children[0].style.stroke ="#ffffff"
            }
            else
            {
            
            
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count":_impressions, "me": _impressions},
                {"quarter": "Facebook", "metrics": "Clicks", "count":_clicks, "me": _clicks},
                {"quarter": "Facebook", "metrics": "Actions", "count":_action, "me": _action},
                {"quarter": "Facebook", "metrics": "Spend", "count":_spend    , "me": _spend},
                {"quarter": "Twitter", "metrics": "Impressions", "count": tw_impressions, "me": tw_impressions},
                {"quarter": "Twitter", "metrics": "Clicks", "count": tw_clicks, "me": tw_clicks},
                {"quarter": "Twitter", "metrics": "Actions", "count": tw_action, "me": tw_action},
                {"quarter": "Twitter", "metrics": "Spend", "count": tw_spend, "me": tw_spend},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0}
                        
            ];
            
            
            
             // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#barGraph",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "count",                //affects the line
                    item: "metrics"
                    

                },
                scaling: {
                    x: 4,
                  columny: 1,
                    liney: 1
              },
           //   scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " "
                },
                tooltip: {
                    container: "#barGraph",
                    //width : 240,
                    bindings: [
                        {label: "Metrics", bindWith: "metrics"},
                        {label: "Count", bindWith: "me"}
                    ]
                }

               
            };
              var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);
            // console.log( );
//            document.getElementById("barGraph").children[0].children[0].children[2].children[1].children[0]
//            // console.log( document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[0]);
//            document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[0].style.opacity = 0.0;
            
           document.getElementById("barGraph").children[0].children[0].children[2].children[1].children[0].style.fill="#ffffff";
           document.getElementById("barGraph").children[0].children[0].children[2].children[1].children[1].style.fill="#ffffff";
           document.getElementById("barGraph").children[0].children[0].children[2].children[1].children[2].style.fill="#ffffff";
           document.getElementById("barGraph").children[0].children[0].children[2].children[1].children[3].style.fill="#ffffff";
           document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[0].style.fill="#03a9f4";
           document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[1].style.fill="#ffc107";
           document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[2].style.fill="#b388ff";
           document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[3].style.fill="#80cbc4";
          
            document.getElementById("barGraph").children[0].children[0].children[3].children[2].children[0].style.stroke="#b388ff";
            document.getElementById("barGraph").children[0].children[0].children[3].children[3].children[0].style.stroke="#80cbc4";
            document.getElementById("barGraph").children[0].children[0].children[3].children[0].children[0].style.stroke="#03a9f4";
            document.getElementById("barGraph").children[0].children[0].children[3].children[1].children[0].style.stroke="#ffc107";

            
             document.getElementById("barGraph").children[0].children[0].children[4].children[6].style.fill="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[7].style.fill="#80cbc4";
             document.getElementById("barGraph").children[0].children[0].children[4].children[6].style.stroke="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[7].style.stroke="#80cbc4";
            
             document.getElementById("barGraph").children[0].children[0].children[4].children[6].style.fill="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[7].style.fill="#80cbc4";
             document.getElementById("barGraph").children[0].children[0].children[4].children[6].style.stroke="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[7].style.stroke="#80cbc4";
             
              document.getElementById("barGraph").children[0].children[0].children[4].children[2].style.fill="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[3].style.fill="#80cbc4";
             document.getElementById("barGraph").children[0].children[0].children[4].children[2].style.stroke="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[3].style.stroke="#80cbc4";
            
             document.getElementById("barGraph").children[0].children[0].children[4].children[2].style.fill="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[3].style.fill="#80cbc4";
             document.getElementById("barGraph").children[0].children[0].children[4].children[2].style.stroke="#b388ff";
             document.getElementById("barGraph").children[0].children[0].children[4].children[3].style.stroke="#80cbc4";
            document.getElementById("barGraph").children[0].style.marginLeft="7px";
           //  $(document.getElementById("barGraph").children[0].css("margin-left","0px"));
            
            }  
          }
        
        $scope.actualtwitteroverall = function (_impressions, _clicks, _action, _spend,fb_impressions, fb_clicks, fb_action, fb_spend)
        {
          
            
            if(_impressions===0 && _clicks===0 && _action===0 && _spend===0 && fb_impressions===0 && fb_clicks===0 && fb_action===0 && fb_spend===0)
           {
               // console.log("actualtwitter gbar is working")
               $scope.graphtoverall=true;
            $scope.overall = true;
            //$scope.today = false;
           //    $scope.today = true;
             $("#barGraphtw").empty();
            // console.log("actual call is happening twitter");
            // console.log(_impressions, _clicks, _action, _spend,fb_impressions, fb_clicks, fb_action, fb_spend);
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count": 0, "me": 100},
                {"quarter": "Facebook", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Facebook", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Facebook", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Impressions", "count":0, "me": 0},
                {"quarter": "Twitter", "metrics": "Clicks", "count":0, "me": 0},
                {"quarter": "Twitter", "metrics": "Actions", "count":0, "me": 0},
                {"quarter": "Twitter", "metrics": "Spend", "count":0    , "me": 0},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0},
               

            ];
            // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#barGraphtw",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                 axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "me",
              //      linex: "me",
                    item: "metrics"

                },
                scaling: {
                    x: 4,
                    columny: 1,
                    liney: 1,
            //        linex: 4
                },
           //   scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10,
           //         linex:5,
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " ",
           //         linex:" "
                }
                


            };
          
        //    document.getElementById("barGraph").children[0].children[0].children[2].children[0].children[0].style.opacity = 0.0;
            
            var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);
              document.getElementById("barGraphtw").children[0].style.marginLeft="7px";
              document.getElementById("barGraphtw").children[0].children[0].children[2].children[0].children[0].style.opacity = 0.0;
              document.getElementById("barGraphtw").children[0].children[0].children[4].children[0].style.fill ="#ffffff" ;
              document.getElementById("barGraphtw").children[0].children[0].children[4].children[0].style.stroke ="#ffffff" ;
               document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].children[0].style.stroke ="#ffffff"
            }
           
           else
           {
            $scope.graphtoverall=true;
            $scope.overall = true;
            //$scope.today = false;
           //    $scope.today = true;
             $("#barGraphtw").empty();
            // console.log("actual call is happening twitter");
            // console.log(_impressions, _clicks, _action, _spend,fb_impressions, fb_clicks, fb_action, fb_spend);
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count": fb_impressions, "me": fb_impressions},
                {"quarter": "Facebook", "metrics": "Clicks", "count": fb_clicks, "me": fb_clicks},
                {"quarter": "Facebook", "metrics": "Actions", "count": fb_action, "me": fb_action},
                {"quarter": "Facebook", "metrics": "Spend", "count": fb_spend, "me": fb_spend},
                {"quarter": "Twitter", "metrics": "Impressions", "count":_impressions, "me": _impressions},
                {"quarter": "Twitter", "metrics": "Clicks", "count":_clicks, "me": _clicks},
                {"quarter": "Twitter", "metrics": "Actions", "count":_action, "me": _action},
                {"quarter": "Twitter", "metrics": "Spend", "count":_spend    , "me": _spend},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0}

            ];
            // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#barGraphtw",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "count",
              //      linex: "me",
                    item: "metrics"

                },
                scaling: {
                    x: 4,
                    columny: 1,
                    liney: 1,
            //        linex: 4
                },
           //   scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10,
           //         linex:5,
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " ",
           //         linex:" "
                },
                tooltip: {
                    container: "#barGraphtw",
                    //width : 240,
                    bindings: [
                       {label: "Metrics", bindWith: "metrics"},
                       {label: "Count", bindWith: "me"}
                    ]
                }


            };

            var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);
            
            
            
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[0].children[0].style.fill="#ffffff";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[0].children[1].style.fill="#ffffff";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[0].children[2].style.fill="#ffffff";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[0].children[3].style.fill="#ffffff";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[1].children[0].style.fill="#03a9f4";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[1].children[1].style.fill="#ffc107";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[1].children[2].style.fill="#b388ff";
           document.getElementById("barGraphtw").children[0].children[0].children[2].children[1].children[3].style.fill="#80cbc4";
         
          // document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].style
        //   document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].children[0].style.stroke="#03a9f4";
       //    document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].children[1].style.stroke="#ffc107";
         //  // console.log(document.getElementById("barGraphtw").children[0].children[0].children[3].children[0]);
           //// console.log(document.getElementById("barGraphtw").children[0].children[0].children[3].children[1]);
              document.getElementById("barGraphtw").children[0].children[0].children[3].children[2].children[0].style.stroke="#b388ff";
              document.getElementById("barGraphtw").children[0].children[0].children[3].children[3].children[0].style.stroke="#80cbc4";
              document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].children[0].style.stroke="#03a9f4";
              document.getElementById("barGraphtw").children[0].children[0].children[3].children[1].children[0].style.stroke="#ffc107";
                //    document.getElementById("barGraphtw").children[0].children[0].children[3].children[0].children[3].style.stroke="#80cbc4"; 
            
            
            document.getElementById("barGraphtw").children[0].children[0].children[4].children[6].style.fill="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[7].style.fill="#80cbc4";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[6].style.stroke="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[7].style.stroke="#80cbc4";
            
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[6].style.fill="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[7].style.fill="#80cbc4";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[6].style.stroke="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[7].style.stroke="#80cbc4";
             
              document.getElementById("barGraphtw").children[0].children[0].children[4].children[2].style.fill="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[3].style.fill="#80cbc4";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[2].style.stroke="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[3].style.stroke="#80cbc4";
            
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[2].style.fill="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[3].style.fill="#80cbc4";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[2].style.stroke="#b388ff";
             document.getElementById("barGraphtw").children[0].children[0].children[4].children[3].style.stroke="#80cbc4";
            
        //     document.getElementById("barGraphtw").children[0].style.marginLeft="7px";
             document.getElementById("barGraphtw").children[0].style.marginLeft="7px";
            
          //  console.log(document.getElementById("svg").style);
            
            
            
            }
           
        
        
        }
        
    
        $scope.viewMoreErrors = function()
        {
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
            angular.element("#campEffectReportErrors").empty();
            for(a=0;a<$scope.errorHeader.length;a++)
            {
                if($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign != "")
                {
                    angular.element("#campEffectReportErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;background:#F5F5F5'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ChildCampaign + "<b>" + $scope.errorHeader[a].ChildCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
                else if($scope.errorHeader[a].ParentCampaign == "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#campEffectReportErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;background:#F5F5F5'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
                else if($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#campEffectReportErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;background:#F5F5F5'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
            }
        };
        
        $scope.viewLessErrors = function()
        {
            angular.element("#errorScroll").css("height","auto");
            angular.element("#errorScroll").css("overflow-y","hidden");
            angular.element("#moreErrors").css("display","flex");
            angular.element("#lessErrors").css("display","none");
            angular.element("#campEffectReportErrors").empty();
            for(a=0;a<$scope.errorHeader.length && a<2;a++)
            {
                angular.element("#campEffectReportErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:20px;background:#F5F5F5'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
            }
        };


              //Pie Chart One\
    var piechartrendercount = 0;
    var count = 0;
    

   


  angular.element($window).bind('resize', function()
        {
pieChart1="undefined";
pieChart2="undefined";
pieChart3="undefined";
pieChart4="undefined";

$("#pieChart1all").empty();
$("#pieChart2all").empty();
$("#pieChart3all").empty();
$("#pieChart4all").empty();

if($scope.flag)
{
    
     $scope.readCorrespondingInsightsOverall();
  
}
else
{
      $scope.readCorrespondingInsightsToday();
   
}
        });

    // function plotValues(_impressions,_clicks,_action,_spend,_count){
     function plotValuesPiechart(_impressions,_spend, _clicks, _action,double_impressions, double_clicks, double_action, double_spend,moreimpressions,  moreclicks, moreactions,morespend,singlecontribution,doublecontribution,morecontribution) 
     {
         
         
          
     // console.log(angular.element('#piewidth').width());
     //     console.log(angular.element('#piechart').height());
         
         $scope.totalimpressions=_impressions+double_impressions;
         $scope.totalclicks=_clicks+double_clicks;
         $scope.totalaction=_action+double_action;
         $scope.totalspend=_spend+double_spend;
             
             
             
             
            $scope._impressions=_impressions;
             $scope._spend=_spend;
             $scope._clicks=_clicks;
             $scope._action=_action;
             $scope.double_impressions=double_impressions;
             $scope.double_clicks=double_clicks;
             $scope.double_action=double_action;
             $scope.double_spend=double_spend;
             $scope.singlecontribution=singlecontribution;
             $scope.doublecontribution=doublecontribution;
            widt=300;
             heig=300;
       /*      WidthChange(mq);
         if (matchMedia) {
                 var mq = window.matchMedia("all and (min-width: 1920px)");
                mq.addListener(WidthChange);
           WidthChange(mq);
                      }
         */        //    // console.log($scope._impressions,$scope._spend, $scope._clicks, $scope._action,$scope.double_impressions, $scope.double_clicks, $scope.double_action, $scope.double_spend,0, 0, 0,0,$scope.singlecontribution,$scope.doublecontribution,0);
                       
         
         
         
         var mq = window.matchMedia("all and (min-width: 1920px)");
      
           
                          // console.log(mq.matches);
                           if (mq.matches) {
                               screenWidth=1920;
                        widt=300;
                         heig=300;
                 //        angular.element('#pieChart1all').css('margin-left', '15%');
                       //  angular.element('#arrow3').css('right', '11%');
                        angular.element('#wo4').css('margin-left', '-2%');
                           angular.element('#wo4').css('margin-top', '310px');
                        
                       //  angular.element('#rupee').css('bottom', '150%');
                         angular.element('#fb').css('margin-left', '3%');
                        //  angular.element('#button').css('float', 'left');
                      //     angular.element('#button').css('left', '6%');
                         
                                                                     //                pieChart1.update(); pieChart2.update(); pieChart3.update(); pieChart4.update();
                  //       plotValuesPiechart($scope._impressions,$scope._spend, $scope._clicks, $scope._action,$scope.double_impressions, $scope.double_clicks, $scope.double_action, $scope.double_spend,0,  0, 0,0,$scope.singlecontribution,$scope.doublecontribution,0);
                    
                             angular.element('#img11').css('margin-top', '310px');
                           angular.element('#img12').css('margin-top', '310px');
                           angular.element('#img13').css('margin-top', '310px');
                           angular.element('#img14').css('margin-top', '310px');
                            
                             angular.element('#img11').css('margin-left', '-11%');
                           angular.element('#img12').css('margin-left', '-9%');
                         //  angular.element('#img13').css('margin-left', '262px');
                         //  angular.element('#img14').css('margin-left', '262px');
                          
                           angular.element('#wo1').css('margin-top', '310px');
                          angular.element('#wo2').css('margin-top', '310px');
                          angular.element('#wo3').css('margin-top', '310px');
                          angular.element('#wo4').css('margin-top', '310px'); 
                          
                 
                
                          angular.element('#wo1').css('margin-left', '-9%'); 
                          angular.element('#wo3').css('margin-left', '-4%'); 
                          angular.element('#wo4').css('margin-left', '-2%'); 
                           
                 
                          angular.element('#oo1').css('margin-top', '310px');
                          angular.element('#oo2').css('margin-top', '310px');
                          angular.element('#oo3').css('margin-top', '310px');
                          angular.element('#oo4').css('margin-top', '310px'); 
                           
                          angular.element('#oo1').css('margin-left', '-10%');
                          angular.element('#oo2').css('margin-left', '-8%');
                          angular.element('#oo3').css('margin-left', '-5%');
                          angular.element('#oo4').css('margin-left', '-3%');     
                        
                          angular.element('#imc1').css('margin-top', '226px');
                          angular.element('#imc2').css('margin-top', '226px');
                          angular.element('#imc3').css('margin-top', '226px');
                          angular.element('#imc4').css('margin-top', '226px'); 
                          
                          angular.element('#rupee').css('bottom', '12%');
                          angular.element('#imc1').css('margin-left', '-185px');
                          angular.element('#imc2').css('margin-left', '-125px');
                          angular.element('#imc4').css('margin-left', '-48px');
                          angular.element('#imc3').css('margin-left', '-95px');
                         
                         angular.element('#arrow1').css('top', '143px');
                          angular.element('#arrow2').css('top', '143px');
                           angular.element('#arrow3').css('top', '143px');
         
         
         
         }else {
                         var mq = window.matchMedia("all and (min-width: 1366px)");
                         // console.log(mq.matches);
                      if (mq.matches) {
                        widt=250;
                         heig=250;
                         screenWidth=1366;
                 
                 
                            angular.element('#arrow1').css('top', '112px');
                           angular.element('#arrow2').css('top', '112px');
                           angular.element('#arrow3').css('top', '112px');
                 
                 
                           angular.element('#img11').css('margin-top', '262px');
                           angular.element('#img12').css('margin-top', '262px');
                           angular.element('#img13').css('margin-top', '262px');
                           angular.element('#img14').css('margin-top', '262px');
                            
                             angular.element('#img11').css('margin-left', '-13%');
                           angular.element('#img12').css('margin-left', '-10%');
                         //  angular.element('#img13').css('margin-left', '262px');
                         //  angular.element('#img14').css('margin-left', '262px');
                          
                           angular.element('#wo1').css('margin-top', '262px');
                          angular.element('#wo2').css('margin-top', '262px');
                          angular.element('#wo3').css('margin-top', '262px');
                          angular.element('#wo4').css('margin-top', '262px'); 
                          
                 
                
                          angular.element('#wo1').css('margin-left', '-10%'); 
                          angular.element('#wo3').css('margin-left', '-3%'); 
                          angular.element('#wo4').css('margin-left', '-1%'); 
                           
                 
                          angular.element('#oo1').css('margin-top', '262px');
                          angular.element('#oo2').css('margin-top', '262px');
                          angular.element('#oo3').css('margin-top', '262px');
                          angular.element('#oo4').css('margin-top', '262px'); 
                           
                          angular.element('#oo1').css('margin-left', '-13%');
                          angular.element('#oo2').css('margin-left', '-9%');
                          angular.element('#oo3').css('margin-left', '-5%');
                          angular.element('#oo4').css('margin-left', '-4%'); 
                 
                          angular.element('#imc1').css('margin-top', '188px');
                          angular.element('#imc2').css('margin-top', '188px');
                          angular.element('#imc3').css('margin-top', '188px');
                          angular.element('#imc4').css('margin-top', '188px'); 
                          
                          angular.element('#rupee').css('bottom', '22%');
                          angular.element('#imc1').css('margin-left', '-156px');
                          angular.element('#imc2').css('margin-left', '-98px');
                          angular.element('#imc3').css('margin-left', '-68px');
                          angular.element('#imc4').css('margin-left', '-25px');
         
               } else {
                       var mq = window.matchMedia("all and (min-width: 1280px)");
                 // console.log(mq.matches);
                     if (mq.matches) {
                        widt=200;
                        heig=200;
                        screenWidth=1024;
              //    plotValuesPiechart($scope._impressions,$scope._spend, $scope._clicks, $scope._action,$scope.double_impressions, $scope.double_clicks, $scope.double_action, $scope.double_spend,0,  0, 0,0,$scope.singlecontribution,$scope.doublecontribution,0);
            
            
                          angular.element('#imc1').css('margin-left', '-135px');
                          angular.element('#imc4').css('margin-left', '0px');
                          angular.element('#imc3').css('margin-left', '-42px');
                        //  angular.element('#imc4').css('margin-left', '-25px');
                          angular.element('#imc1').css('margin-top', '154px');
                          angular.element('#imc2').css('margin-top', '154px');
                          angular.element('#imc3').css('margin-top', '154px');
                          angular.element('#imc4').css('margin-top', '154px');
                          angular.element('#rupee').css('bottom', '30%');
                              
                              
                              
                              
                          angular.element('#wo1').css('margin-top', '210px');
                          angular.element('#wo2').css('margin-top', '210px');
                          angular.element('#wo3').css('margin-top', '210px');
                          angular.element('#wo4').css('margin-top', '210px'); 
                          
                 
                 
                          angular.element('#wo1').css('margin-left', '-8%'); 
                          angular.element('#wo3').css('margin-left', '-2%'); 
                          angular.element('#wo4').css('margin-left', '-1%'); 
                          
                          
                          angular.element('#oo1').css('margin-top', '210px');
                          angular.element('#oo2').css('margin-top', '210px');
                          angular.element('#oo3').css('margin-top', '210px');
                          angular.element('#oo4').css('margin-top', '210px'); 
                       
                     
                     
                          angular.element('#oo1').css('margin-left', '-13%');
                          angular.element('#oo2').css('margin-left', '-9%');
                          angular.element('#oo3').css('margin-left', '-5%');
                          angular.element('#oo4').css('margin-left', '-4%');    
                         
                     
                           angular.element('#img11').css('margin-top', '210px');
                           angular.element('#img12').css('margin-top', '210px');
                           angular.element('#img13').css('margin-top', '210px');
                           angular.element('#img14').css('margin-top', '210px');
               
                  
                  
                  
                  
                        angular.element('#arrow1').css('top', '80px');
                           angular.element('#arrow2').css('top', '80px');
                           angular.element('#arrow3').css('top', '80px');
            
                   } 
                    }
           
                    }
                      
                        $scope.adimpressionstoday=  $scope.totalimpressions;
                        $scope.adclickstoday = $scope.totalclicks;
                        $scope.adspendtoday=    $scope.totalspend;
                        $scope.adcallToActiontoday= $scope.totalaction;                     

                                // console.log("width : "+widt+"         heigth:"+heig+"       screenwidth:"+screenWidth);

                                                    if (pieChart1 === undefined || pieChart1 === "undefined"){
                                                    //("first time draw of chart 1");
                                                    //start of chart 1 
                                                    // Sample Data for this Bar chart demo.                                                                       
                                                    var chart1Data = [{"campaignType": " ", "impressions": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "impressions": _impressions, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "impressions": double_impressions, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "impressions": moreimpressions, "contribution": morecontribution}];
                                                            // drawDoughnutChart(sampleData);

                                                            // Defining options for rendering Bar chart.
                                                            var chart1Options = {
                                                            id: "1",
                                                                    container: {
                                                                    id: "#pieChart1all",
                                                                            width: widt,
                                                                            height: heig,
                                                                            title: "Impressions",
                                                                            titlePos: 15,
                                                                            viewBox : "0 0 100 100"
                                                                    },
                                                                    startAngle: 90,
                                                                    gloss: 'no',
                                                                    margin: {
                                                                    top: 28,
                                                                    left: 0,
                                                                    right: 1,
                                                                    bottom: 28,
                                                                    
                                                               
                                                                    
                                                                    },
                                                                    bindings: {pie: "campaignType", value: "contribution", color: "campaignType"},
                                                                    radius: {inner: 0.8, outer: 1.0},
                                                                    tooltip: {
                                                                    container: "#pieChart1all", width: 120,
                                                                            bindings: [{label: "Campaign Type", bindWith: "campaignType"},
                                                                            {label: "Impressions", bindWith: "impressions"}]
                                                                    }
                                                            };
                                                            //("pie1 before render" +pieChart1);
                                                            pieChart1 = cviz.widget.DoughnutChart.Runner(chart1Options).graph();
                                                            //Actual function call to render the Bar graph    


                                                            pieChart1.render(chart1Data);
//                                                            var doughnutLength = $("#pieChart1all").find("svg").length;
//                                                            if (doughnutLength > 1) {
//                                                    $("#pieChart1all").find("svg").not('svg:first').remove()
//                                                    }



                                                         //    $("#pieChart1all").find("circle").css("fill","#ebe9e9");
                                                         
                                                             $("#pieChart1all").find("circle").css("fill"," #e1e1e1");
                                                            $("#pieChart1all").find("circle").css("fill-opacity", "0.4");
                                                                // console.log("graph is first renderning is working now with value "+angular.element('#pieChart1all').height);
                                                            $("#pieChart1all .arc path").css("fill-opacity", "1");
                                                               $("#pieChart1all .arc path").css("stroke", "rgb(240,240,240)");
                                                            $("#pieChart1all .arc path").eq(0).css("fill", "rgb(240,240,240)");
                                                            $("#pieChart1all .arc path").eq(0).css("stroke", "rgb(255,255,255)");
                                                            $("#pieChart1all .arc path").eq(3).css("fill", "rgb(3,169,244)");
                                                            $("#pieChart1all .arc path").eq(2).css("fill", "rgb(109,195,234)");
                                                            $("#pieChart1all .arc path").eq(1).css("fill", "rgb(136,218,255)");
                                                            $("#pieChart1all .arc text").hide();
                                                            //end of chart 1 code
                                                           
                                                    } else
                                                    {
                                                  var chart1Data = [{"campaignType": " ", "impressions": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "impressions": _impressions, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "impressions": double_impressions, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "impressions": moreimpressions, "contribution": morecontribution}];
                                                      
             
                                                                // console.log("update is working");
                                                           //     pieChart1.update(chart1Options);                                          
                                                               pieChart1.update(chart1Data);
                                                       
                                                        // console.log(pieChart1);
                                                    }
                                                    if (pieChart2 === undefined || pieChart2 === "undefined"){
                                                    //("first time draw of chart 1");
                                                    //start of chart 1 
                                                    // Sample Data for this Bar chart demo.                                                                       
                                                    var chart2Data = [{"campaignType": " ", "clicks": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "clicks": _clicks, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "clicks": double_clicks, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "clicks": moreclicks, "contribution": morecontribution}];
                                                            // drawDoughnutChart(sampleData);

                                                            // Defining options for rendering Bar chart.
                                                            var chart2Options = {
                                                            id: "2",
                                                                    container: {
                                                                    id: "#pieChart2all",
                                                                            width: widt,
                                                                            height: heig,
                                                                            title: "Impressions",
                                                                            titlePos: 15
                                                                    },
                                                                    startAngle: 90,
                                                                    gloss: 'no',
                                                                    margin: {
                                                                     top: 28,
                                                                    left: 0,
                                                                    right: 1,
                                                                    bottom: 28
                                                                    },
                                                                    bindings: {pie: "campaignType", value: "contribution", color: "campaignType"},
                                                                    radius: {inner: 0.8, outer: 1.0},
                                                                    tooltip: {
                                                                    container: "#pieChart2all", width: 120,
                                                                            bindings: [{label: "Campaign Type", bindWith: "campaignType"},
                                                                            {label: "clicks", bindWith: "clicks"}]
                                                                    }
                                                            };
                                                            //("pie1 before render" +pieChart1);
                                                            pieChart2 = cviz.widget.DoughnutChart.Runner(chart2Options).graph();
                                                            //Actual function call to render the Bar graph    


                                                            pieChart2.render(chart2Data);
//                                                            var doughnutLength = $("#pieChart1all").find("svg").length;
//                                                            if (doughnutLength > 1) {
//                                                    $("#pieChart1all").find("svg").not('svg:first').remove()
//                                                    }




                                                          //   $("#pieChart2all").find("circle").css("fill","#ebe9e9");
                                                             $("#pieChart2all").find("circle").css("fill"," #e1e1e1");;
                                                            $("#pieChart2all").find("circle").css("fill-opacity", "0.4");
                                                            $("#pieChart2all .arc path").css("fill-opacity", "1");
                                                            $("#pieChart2all .arc path").eq(0).css("fill", "rgb(240,240,240)");
                                                            $("#pieChart2all .arc path").eq(0).css("stroke", "rgb(255,255,255)");
                                                            $("#pieChart2all .arc path").eq(3).css("fill", "rgb(255,193,7)");
                                                            $("#pieChart2all .arc path").eq(2).css("fill", "rgb(255,208,69)");
                                                            $("#pieChart2all .arc path").eq(1).css("fill", "rgb(255,234,173)");
                                                            $("#pieChart2all .arc text").hide();
                                                            //end of chart 1 code
                                                            //$("#pieChart1").find("circle").css("fill","url(#img1");
                                                    } else
                                                    {
                                                  var chart2Data = [{"campaignType": " ", "clicks": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "clicks": _clicks, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "clicks": double_clicks, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "clicks": moreclicks, "contribution": morecontribution}];
                                                            pieChart2.update(chart2Data);
                                                    }

                                                    if (pieChart3 === undefined || pieChart3 === "undefined"){
                                                    var chart3Data = [{"campaignType": " ", "actions": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns ", "actions": _action, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "actions": double_action, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "actions": moreactions, "contribution": morecontribution}];
                                                            // Defining options for rendering pie chart 2.
                                                            var chart3Options = {
                                                            id: "3",
                                                                    container: {
                                                                    id: "#pieChart3all",
                                                                           width: widt,
                                                                            height: heig,
                                                                            title: "Actions",
                                                                            titlePos: 15
                                                                    },
                                                                    gloss: 'yes',
                                                                    margin: {
                                                                       top: 28,
                                                                    left: 0,
                                                                    right: 1,
                                                                    bottom: 28
                                                                    },
                                                                    bindings: {pie: "campaignType", value: "contribution", color: "campaignType"},
                                                                    radius: {inner: 0.8, outer: 1.0},
                                                                    tooltip: {
                                                                    container: "#pieChart3all", width: 120,
                                                                            bindings: [{label: "CampaignType", bindWith: "campaignType"},
                                                                            {label: "Actions", bindWith: "actions"}]
                                                                    }
                                                            };
                                                            
                                                            pieChart3 = cviz.widget.DoughnutChart.Runner(chart3Options).graph();
                                                            //Actual function call to render the Bar graph
                                                              //    $("#pieChart3all").find("circle").css("fill","#ebe9e9");
                                                            pieChart3.render(chart3Data);
//                                                            var doughnutLength3 = $("#pieChart3all").find("svg").length;
//                                                            if (doughnutLength3 > 1) {
//                                                    $("#pieChart3all").find("svg").not('svg:first').remove()
//                                                    }
                                                             $("#pieChart3all").find("circle").css("fill"," #e1e1e1");;
                                                            $("#pieChart3all").find("circle").css("fill-opacity", "0.4");
                                                            $("#pieChart3all .arc path").css("fill-opacity", "1");
                                                            $("#pieChart3all .arc path").eq(0).css("fill", "rgb(240,240,240)");
                                                            $("#pieChart3all .arc path").eq(0).css("stroke", "rgb(255,255,255)");
                                                            $("#pieChart3all .arc path").eq(3).css("fill", "rgb(179,136,255)");
                                                            $("#pieChart3all .arc path").eq(2).css("fill", "rgb(201,170,255)");
                                                            $("#pieChart3all .arc path").eq(1).css("fill", "rgb(229,214,255)");
                                                            $("#pieChart3all .arc text").hide();
                                                    }
                                                    else
                                                    {
                                                      var chart3Data = [{"campaignType": " ", "actions": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns ", "actions": _action, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns", "actions": double_action, "contribution": doublecontribution}, {"campaignType": "Three or More Network Campaigns", "actions": moreactions, "contribution": morecontribution}];
                                                          pieChart3.update(chart3Data);
                                                    }

                                                    if (pieChart4 === undefined || pieChart4 === "undefined"){
                                                    var chart4Data = [{"campaignType": " ", "spend": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "spend": _spend, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns ", "spend": double_spend, "contribution": doublecontribution}, {"campaignType": " Three or More Network Campaigns",  "spend": morespend, "contribution": morecontribution}];
                                                            // Defining options for rendering pie chart 2.
                                                            var chart4Options = {
                                                            id: "4",
                                                                    container: {
                                                                    id: "#pieChart4all",
                                                                            width: widt,
                                                                            height: heig,
                                                                            title: "Spend",
                                                                            titlePos: 15
                                                                    },
                                                                    gloss: 'yes',
                                                                    margin: {
                                                                    top: 28,
                                                                    left: 0,
                                                                    right: 1,
                                                                    bottom: 28
                                                                    },
                                                                    bindings: {pie: "campaignType", value: "contribution", color: "campaignType"},
                                                                    radius: {inner: 0.8, outer: 1.0},
                                                                    tooltip: {
                                                                    container: "#pieChart4all", width: 120,
                                                                            bindings: [{label: "Campaign Type", bindWith: "campaignType"},
                                                                            {label: "Spend", bindWith: "spend"}]
                                                                    }
                                                            };
                                                            pieChart4 = cviz.widget.DoughnutChart.Runner(chart4Options).graph();
                                                            //Actual function call to render the Bar graph
                                                            pieChart4.render(chart4Data);
//                                                            var doughnutLength4 = $("#pieChart4all").find("svg").length;
//                                                            if (doughnutLength4 > 1) {
//                                                    $("#pieChart4all").find("svg").not('svg:first').remove()
//                                                    }
                                                             $("#pieChart4all").find("circle").css("fill"," #e1e1e1");;
                                                            $("#pieChart4all").find("circle").css("fill-opacity", "0.4");
                                                            $("#pieChart4all .arc path").eq(0).css("fill", "rgb(240,240,240)");
                                                            $("#pieChart4all .arc path").eq(0).css("stroke", "rgb(255,255,255)");
                                                            $("#pieChart4all .arc path").eq(3).css("fill", "rgb(128,203,196)");
                                                            $("#pieChart4all .arc path").eq(2).css("fill", "rgb(164,231,225)");
                                                            $("#pieChart4all .arc path").eq(1).css("fill", "rgb(200,247,243)");
                                                            $("#pieChart4all .arc text").hide();
                                                    }
                                                    else
                                                    {
                                                    var chart4Data = [{"campaignType": " ", "spend": " ", "contribution": 20}, {"campaignType": "Single Network Campaigns", "spend": _spend, "contribution": singlecontribution}, {"campaignType": "Dual Network Campaigns ", "spend": double_spend, "contribution": doublecontribution}, {"campaignType": " Three or More Network Campaigns",  "spend": morespend, "contribution": morecontribution}];
                                                           pieChart4.update(chart4Data);
                                                    }

                                                    }

                        

    }]);

