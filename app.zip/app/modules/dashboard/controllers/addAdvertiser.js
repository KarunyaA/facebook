dashboard.controller("addadvertiserController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', 'appSettings', '$timeout','apiService',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, appSettings, $timeout, apiService) {


     

        $scope.acc_name = {red: false};
        $scope.poc_name = {red: false};
        $scope.acc_url = {red: false};
        $scope.acc_poc = {red: false};
        $scope.acc_contact = {red: false};
        $scope.acc_email = {red: false};
        $scope.acc_add = {red: false};
        $scope.logo = {red: false};
        
        $scope.edit_view = false;
        $scope.success_message_popup=false;
        
        $scope.gotoaccountdashboard = function()
        {
            $state.go('app.accountdashboard');
        }
        
        
        //FETCH ACCOUNT NAME
        $scope.accontname_fetch = function () {
            //$state.go('app.addadvertiser');
            $rootScope.progressLoader = "block";
             $http({
                method: 'GET',
                url: appSettings.apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).success(function(response) {
                $rootScope.progressLoader = "none";
                $scope.accountName = response.accountFetchResponse.accountName;
                
            });
           
        };
        
        $scope.accontname_fetch();
        
        //ADD ADVERTISER SERVICE
         $scope.createAdvertiser =  function (_nObj, file) {
            var file = $scope.getCompanyLogo;
            var deferred = $q.defer();
            /**
             * Account Creation Rest API Header
             **/
            var configHeader = {
                headers: {
                    'Content-Type': 'application/json;',
                    'async': 'false;',
                    'dataType': 'jsonp;'
                }
            }
           
            var parameters = {
                 
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "accountId" : $window.localStorage.getItem("accountId"),
                
                "name": $scope.name,
                "emailId": $scope.email,
                "pocName": $scope.Pocname,
                "pocNumber": $scope.contact
              
            }; 
          
            $rootScope.progressLoader = "block";
            apiService.create("/user/createadvertiser", parameters, configHeader).then(function (response) {
                
                if (response.appStatus == 0) {
                    /**
                     * Upload Logo File Header
                     **/
                  
                    var fd = new FormData();
                    fd.append('file', file);
                    fd.append('role', 'Advertiser');
                    fd.append('id', response.advertiserId );
                    fd.append('userId', $window.localStorage.getItem("userId"));
                    fd.append('accessToken', $window.localStorage.getItem("accessToken"));
                      
                    
                    var uploadConfigHeader = {
                        transformRequest: angular.identity,
                        headers: {
                            'Content-Type': undefined
                        }
                    };
                    apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (uploadResponse) {
                        if (uploadResponse.appStatus == 0) {
                           
                            //deferred.resolve(uploadResponse);
                            var updateParam = {
                                "advertiserId": response.advertiserId,
                                "logoUrl": uploadResponse.successMessage
                            };
                            $scope.Logosuccess = uploadResponse.successMessage;
                            $scope.advertiserId = response.advertiserId;
                         
                            /**
                             * Update Advertiser Logo URL to System
                             **/
                       var parameters = {
                           
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken"),
                            
                            "advertiserId": $scope.advertiserId,
                            "pocName": $scope.Pocname,
                            "pocNumber": $scope.contact,
                            "description" : $scope.name,
                            "logoUrl": $scope.Logosuccess
                        };
                        
                        apiService.create("/user/updateadvertiser", parameters).then(function (updateResponse) {
                            if(updateResponse.appStatus==0)
                            {
                                $rootScope.progressLoader = "none";
                                 //SUCCESS POPUP
                                $scope.success_message_popup = true;
                                  var modalcreateadvertiser = $(".success-messagepopup");
                                  modalcreateadvertiser.show();
                                  

                                deferred.resolve(updateResponse);
                            }
                             
                        },
                                    function (updateResponse) {
                                        deferred.reject(updateResponse);
                                    });
                            return deferred.promise;
                        } 
                        
                        //UPLOAD IMAGE
                        else {
                            deferred.resolve(uploadResponse);
                        }
                    },
                            function (uploadResponse) {
                                deferred.reject(uploadResponse);
                               
                            });
                    return deferred.promise;
                }
                
                //CREATE ADVERTISER
                else {
                      $rootScope.progressLoader = "none";
					  
                              if(response.errorId == 4027)
                                {
                                    $scope.acc_poc.red = true;
                                    $scope.Adv_name_exist = true;
                                }
                                else if(response.errorId == 4029)
                                {
                                    $scope.acc_email.red = true;
                                    $scope.Email_exist = true;
                                }
                                else if(response.errorId == 4018){
                                    $scope.max_advertiser_reached = true;
									
									$scope.editAdsetErrorMsg = 'block';
									if (response.networkError != '' && response.networkError != undefined) {
										$scope.errorpopupHeading = response.networkError.error_user_title;
										$scope.errorMsg = response.networkError.error_user_msg;
									} else {
										$scope.errorpopupHeading = 'Error';
										$scope.errorMsg = response.errorMessage;
									}
									
                                }
                               
                                else
                                {
                                      $scope.error_message_popup = true;
                                      var modalcreateadvertiser = $(".success-messagepopup");
                                      modalcreateadvertiser.show();
                                     
                                }
                    deferred.resolve(response);
                }
                
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;
        };
        
        
        //IMAGE UPLOAD
         $scope.getuploadfilename = function (element) {
             
            $scope.$apply(function ($scope) {
                 $scope.size = element.files[0].size;
                 if($scope.size < 25000)
                 {
                    $scope.uploadedfilename = element.files[0];
                    $scope.logo = {red:false};
                    $scope.invalidImageSize = false;
                   
                }
                else
                {
                    $scope.logo = {red:true};
                    $scope.invalidImageSize = true;
                 
                }
              
            });
        };
              
        //CANCEL FUNCTION
        $scope.reset = function (getAdvertiserDetails) {
            $scope.name= null;
            $scope.companyPoc = null;     
            $scope.email = null;        
            $scope.contact = null;
            $scope.Pocname = null;
            $scope.tempfilename = null;
            $scope.uploadedfilename = null;
            
            $scope.acc_poc.red = false;
            $scope.acc_email.red = false;
            $scope.poc_name.red = false;
            $scope.acc_contact.red = false;
            $scope.logo.red = false;
            $scope.Adv_name_exist = false;
            $scope.Email_exist = false;
            $scope.accpocempty = false;
            $scope.pocnameempty = false;
            $scope.acccontactempty = false;
            $scope.accemailempty = false;
           
            $state.go('app.accountdashboard');
            
        }
        
        
        //SUCCESS OK POPUP
        $scope.success_close = function()
        {
            var modalcreateaudience = $(".success-messagepopup");
              modalcreateaudience.hide();
              $state.go('app.accountdashboard');
        }
        
        
        //ERROR VALIDATIONS
        $scope.acc_poc_empty_check = function (val)
        {

            $scope.accpocempty = false;
             $scope.Adv_name_exist = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_poc.red = true;
                $scope.accpocempty = true;
               
            }
            else
            {
                $scope.acc_poc.red = false;
                $scope.accpocempty = false;
            }
        }
        
        $scope.poc_name_empty_check = function (val)
        {

            $scope.pocnameempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.poc_name.red = true;
                $scope.pocnameempty = true;
            }
            else
            {
                $scope.poc_name.red = false;
                $scope.pocnameempty = false;
            }
        }
        $scope.acc_contact_empty_check = function (val)
        {

            $scope.acccontactempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_contact.red = true;
                $scope.acccontactempty = true;
            }
            else
            {
                $scope.acc_contact.red = false;
                $scope.acccontactempty = false;
            }
            
           
            if (!$scope.accemailempty && !$scope.acccontactempty && !$scope.accpocempty && !$scope.pocnameempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
            
        }
        $scope.acc_email_empty_check = function (val)
        {

            $scope.accemailempty = false;
             $scope.Email_exist = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_email.red = true;
                $scope.accemailempty = true;
            }
            else
            {
                $scope.acc_email.red = false;
                $scope.accemailempty = false;
            }
        }
        
       
        
        

    }]);

dashboard.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                var clean = val.replace(/[^0-9]+/g, '');
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });
            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});


dashboard.directive('validateEmail', function () {
    var EMAIL_REGEXP = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;

    return {
        require: 'ngModel',
        restrict: '',
        link: function (scope, elm, attrs, ctrl) {
            // only apply the validator if ngModel is present and Angular has added the email validator
            if (ctrl && ctrl.$validators.email) {

                // this will overwrite the default Angular email validator
                ctrl.$validators.email = function (modelValue) {
                    return ctrl.$isEmpty(modelValue) || EMAIL_REGEXP.test(modelValue);
                };
            }
        }
    };
})