dashboard.controller("campaigncreativeController", ['$rootScope', '$scope', '$http', '$q', '$state', '$location', 'dashboardService', 'apiService', 'Flash', '$window', 'appSettings', '$sce', '$timeout', 'globalData','$animate','$filter',
function ($rootScope, $scope, $http, $q, $state, $location, dashboardService, apiService, Flash, $window, appSettings, $sce, $timeout, globalData,$animate, $filter) {
	
	$scope.myInterval = 500;
        $scope.imgthumbnaildiv = false;
        $scope.vidthumbnaildiv = false;
	$scope.previewing = false;
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        var apiTPBase = appSettings.apiTPBase;
        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken"); 
        $scope.fourthActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.browseImgSuccessMsg = "none";
        $scope.browselibrary = "none";
        $scope.browselibraryvideos = "none";
        $scope.mainLoader = "none";
        $scope.errTextMsg = "none";
        $scope.errHeadlineTextMsg = "none";
        $scope.errLandingviewTextMsg = "none";
        $scope.uniqueArray = [];
		$scope.uniqueImageSelectionArray = [];
                $scope.campaignAudienceCampaignOfferArr = [];
        $scope.textBodyContent = "";
        $scope.campaignHeadline = "";
		$scope.cardHeadline = "";
		$scope.cardDescription = "";
		$scope.cardwebURL = "";
        $scope.campaignLandingView = "Timeline";
        $scope.hashVal = "";
        $scope.imagesSource = "";
        $scope.objectType = 'PHOTO';
        $scope.networkErrorPopup = "none";
	   $scope.slideShowCreate=true;
        $scope.advertCarousel = false;
        $scope.advertSingleImg = false;
        $scope.advertSingleVideo = false;
        $scope.advertSlideshow = false;
        $scope.step2_green=false;
        $scope.valAddWebsiteUrl = false;
        $scope.isHeadline = false;
        $scope.isCreateShowAdvOption = false;
        $scope.editAdsetErrorMsg = 'none';
        $scope.isCarousaltrafficText = false;
		$scope.campaignAudienceCampaignTargetLoader = true;
                $scope.campaignAudienceLandingViewLoader = false;
		/*Carousel advent*/	
		$scope.carouseladvent1 = true;
		$scope.showImgPrev = [];
		$scope.showVideoPrev = [];
		$scope.carouseladventEdit2 = false;
		$scope.carouseladventEdit3 = false;
		$scope.carouseladventEdit4 = false;
		$scope.carouseladventEdit5 = false;
		$scope.carouseladventEdit6 = false;
		$scope.carouseladventEdit7 = false;
		$scope.carouseladventEdit8 = false;
		$scope.carouseladventEdit9 = false;
				
		$scope.selectedImagegalleryArray = []; 
		$scope.selectedImagegalleryArrayVideo = []; 
		$scope.headlinecontents = [];
		 $scope.descriptioncontents = [];
		 $scope.weburlcontents = [];
		$scope.mediaImage = true;
        $scope.mediaVideo = true;
		$scope.carouseladvent = false;
		$scope.imageFormat = "imagemediaUpdate";
		$scope.imagePreviewSrc = "";
		$scope.imagePreviewVideoSrc = "";
		//$scope.showVideoPrev = false;
		//$scope.showImgPrev = false;
		//$scope.imageFormat1 = "videomediaUpdate";
		$scope.mediaarrow=true;
		$scope.previewing = false;
		$scope.counter = 1;
		$scope.isPixelTracking=false;
		$scope.isOfflineTracking=false;
        /*use Exist Post - start */
        $scope.existURLParam = false;
        $scope.exitShowAdvOption = true;
        $scope.exitHideAdvOption = false;
        $scope.selectedTarget = "";
        /*use Exist Post - end*/

        $scope.fbAccessToken = "";
        $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
        // $scope.marketingObjective = "LEAD_GENERATION";

        $scope.desktop = false;
        $scope.mobile = false;
        $scope.rightColumn = false;
        $scope.isLeadGen = false;
        
       // $scope.callToDirectionValue = 0;
        $scope.adminUserRole = false;
		$scope.accordianRole = false;
        $scope.webURL = "";
        $scope.adData = "";
        $scope.campaignEventLoader = false;
        $scope.uploadstep = '2';
        $scope.previewstep = '3';
        $scope.pageTabs = [];
        
        $scope.deleteImgThumbnail = function(){
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            $scope.imgthumbnaildiv = false;
           //$scope.deleteAdCreative();
        }
        
        $scope.deleteVidThumbnail = function(){
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            $scope.vidthumbnaildiv = false;
           //$scope.deleteAdCreative();
        }
        
        $scope.getPageTabs = function(pageId) {
            var accessToken = "";
            var name = "";
            for(i=0;i<$scope.connectFBVal.length;i++)
            {
                if(pageId == $scope.connectFBVal[i].id)
                {
//                    console.log("page matched");
//                    console.log($scope.connectFBVal[i].access_token);
                    accessToken = $scope.connectFBVal[i].access_token;
                    name = $scope.connectFBVal[i].name;
                }
            }
            if(accessToken != "")
            {
                $scope.pageTabs = [];
                $http({
                    method: 'GET',
                    url: apiTPBase + '/fetchpagetabs?pageAccessToken=' + accessToken + '&pageId=' + pageId + '&userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId'),
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response)
                {
                    if(response.data.appStatus == 0)
                    {
                        var obj = {
                            "name":"Timeline",
                            "urlPart":name.split(" ").join("-") + "-" + pageId + "/"
                        };
                        $scope.pageTabs.push(obj);
                        if($window.localStorage.getItem("campaignState") == "create") {
                            $scope.campaignLandingView = "Timeline";
                        }
                        angular.forEach(response.data.pageTabs,function(value,key)
                        {
                            angular.forEach(value,function(value2,key2)
                            {
                                var obj = {
                                    "name":value2.name,
                                    "urlPart":value2.link
                                }
                                $scope.pageTabs.push(obj);
                            });
                        });
                        $scope.campaignAudienceLandingViewLoader = false;
//                        console.log($scope.pageTabs);
                    }
                    else
                    {
                        $scope.campaignAudienceLandingViewLoader = false;
//                        console.log("fetch page tabs failed");
//                        console.log(response);
                    }
                });
            }
            else
            {
                $scope.campaignAudienceLandingViewLoader = false;
                $scope.pageTabs = [];
                var obj = {
                  "name":"Timeline",
                  "urlPart":name.split(" ").join("-") + "-" + pageId + "/"
                };
                $scope.pageTabs.push(obj);
//                console.log("Page accessToken not found");
            }
        };

        $scope.selectMessenger = function (radioDestination) {
            $scope.radioDestination = radioDestination;
            if (radioDestination == 'MESSENGER') {
                
                $scope.isDisplayLink = false;
                $scope.isWebURL = false;
            } else {
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbslideshow")
                {$scope.isWebURL = true;
                $scope.isDisplayLink = false;}
               else if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbcarosel"){
                   $scope.isDisplayLink = false;
               }
			   else if($scope.marketingObjective == "CONVERSIONS" && $scope.fbadvertFormat == "fbcarosel"){
                   $scope.isWebURL = false;
                $scope.isDisplayLink = false;
				$scope.isSeeMoreURL = true;
               }
            else{
                $scope.isWebURL = true;
                $scope.isDisplayLink = true;
            }
            }
            $window.localStorage.setItem("radioDestination", $scope.radioDestination);
        }
        $scope.getAdCreativeIdFromFaceBook = function () {
            var adId = $window.localStorage.getItem("adId");
            var queryStr = "https://graph.facebook.com/v2.8/" + adId + "?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&fields=creative";
            $http({
                method: 'GET',
                url: queryStr
            }).then(function (response) {
                if (response.data.creative.id) {// success
                    $window.localStorage.setItem("adCreativeId", response.data.creative.id)
                    $scope.getAdCreativeForEdit();
                }
            })
        }
        $scope.getAdCreativeForEdit = function () {
            var adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiTPBase + '/getadcreative?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.fbAdCreativeResponse.id) {
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
					//angular.element($('.accordianRole').prop('disabled', false));
					angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                                        $scope.step2_green=true;
                } else {
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
					//angular.element($('.accordianRole').prop('disabled', true));
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }
                if (response.data.appStatus == 0) {// success
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();
                    $scope.adCreativeDetails = response.data.fbAdCreativeResponse;
                    $scope.advertypeforEdit = response.data.fbAdCreativeResponse.object_type;
                    if ($scope.adCreativeDetails.url_tags) {
                        $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                    }
                    if($window.localStorage.getItem("marketingObjective") == 'PAGE_LIKES'){
                        $scope.campaignAudienceLandingViewLoader = true;
                        $scope.getPageTabs(response.data.fbAdCreativeResponse.object_id);
                    }
                    if(typeof(response.data.fbAdCreativeResponse.object_story_spec) != "undefined") {
                        if(typeof(response.data.fbAdCreativeResponse.object_story_spec.video_data) != "undefined"){
                            $scope.advertypeforEdit = 'VIDEO';
                        }
                    }
					$rootScope.progressLoader = "none";
					$scope.mainLoader = "none";
					//angular.element($('.cards-content .imgprv').css("visibility", "visible"));
                    //console.log($scope.adCreativeDetails.object_story_spec.link_data.child_attachments);
                                    if(typeof($scope.adCreativeDetails.object_story_spec) != "undefined") {
					if(typeof($scope.adCreativeDetails.object_story_spec.link_data) != "undefined"){
						if(typeof($scope.adCreativeDetails.object_story_spec.link_data.child_attachments) != "undefined"){
						$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","435px");
						$scope.fbadvertFormat = "fbcarosel";
                        $rootScope.progressLoader = "none";
						console.log('fbcarousel adven');
						$scope.carouseladvent = true;
						/*$scope.isHeadline = false;
						$scope.isDestination = false;
						$scope.isWebURL = false;						
						$scope.isSeeMoreURL = true;
						$scope.isAddWebsiteUrl = false;*/
						
						$scope.cardHeadline = [];
						$scope.cardwebURL = [];
						$scope.cardDescription = [];
						
						$scope.headlinecontents = [];
						$scope.weburlcontents = [];
						$scope.descriptioncontents = [];
						$scope.selectedImagegalleryArray = [];
						$scope.imagePreviewSrc = [];
						$scope.imagePreviewVideoSrc = [];
						$scope.child_attachments = $scope.adCreativeDetails.object_story_spec.link_data.child_attachments;
						$scope.child_attachmentslength = $scope.adCreativeDetails.object_story_spec.link_data.child_attachments.length;
						console.log($scope.child_attachmentslength);	

						if($scope.child_attachmentslength > 2){
							for(var i = 3;i <= $scope.child_attachmentslength; i++){
							var len = $scope.tabs.length + 1;
							console.log(len);
							var numLbl =  len;
							$scope.tabs.push({
							  title: numLbl     
							  
							});
									
							}
							
									if($scope.child_attachmentslength == 3){$scope.carouseladventEdit3 = true;}
									else if($scope.child_attachmentslength == 4){$scope.carouseladventEdit4 = true;}
									else if($scope.child_attachmentslength == 5){$scope.carouseladventEdit5 = true;}
									else if($scope.child_attachmentslength == 6){$scope.carouseladventEdit6 = true;}
									else if($scope.child_attachmentslength == 7){$scope.carouseladventEdit7 = true;}
									else if($scope.child_attachmentslength == 8){$scope.carouseladventEdit8 = true;}
									else if($scope.child_attachmentslength == 9){$scope.carouseladventEdit9 = true;}
									
							
							
						}
						else{
							$scope.carouseladventEdit2 = true;
						}
					
						for(var i = 0;i<$scope.child_attachmentslength; i++){
							if ($scope.child_attachments[i].name != undefined) {
							console.log($scope.child_attachments[i].link);
							$scope.cardHeadline[i] =  $scope.child_attachments[i].name;
							$scope.headlinecontents[i] = $scope.cardHeadline[i];
							$scope.cardwebURL[i] =  $scope.child_attachments[i].link;
							$scope.weburlcontents[i] = $scope.cardwebURL[i];
							$scope.cardDescription[i] =  $scope.child_attachments[i].description;
							$scope.descriptioncontents[i] = $scope.cardDescription[i];
							}
						}	
							
							for(var i = 0;i<$scope.child_attachmentslength; i++){
								(function(i)
								{
										if(typeof($scope.child_attachments[i].image_hash) != "undefined"){
											//$scope.mainLoader = "block";
											console.log(i);
											
																			
													/*	$scope.showImgPrev[i] = true;
														$scope.imagePreviewSrc[i] = $scope.adCreativeDetails.thumbnail_url;
														$scope.selectedImagegalleryArray[i] = $scope.imagePreviewSrc[i];
														console.log($scope.imagePreviewSrc[i]);  */
														
											   
										 
										 
										//Get add image service using Hash value
										
												var queryStr1 = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + $scope.child_attachments[i].image_hash;
												
												 $http({
													method: 'GET',
													url: apiTPBase + '/getadimages?' + queryStr1,
													headers: {
														'userId': $window.localStorage.getItem("userId"),
														'accessToken': $window.localStorage.getItem("accessToken")
													}
												}).then(function (response) {
													console.log(response);
													if (response.status == "200" && response.data.appStatus == '0') {
													console.log(i);
													
														$scope.mainLoader = "none";
														console.log('image hash servic success');
														//$scope.getimageURL = response.data.adImages[0].url;
														//console.log($scope.getimageURL);
														//console.log(response.data.adImages[0]);
														var JsonObj = response.data.adImages[0];
														 var array = [];
														for (var j in JsonObj) {
															if (JsonObj.hasOwnProperty(j)) {
																array[+j] = JsonObj[j];
																console.log(JsonObj[j].url);
																$scope.imagePreviewSrc[i] = JsonObj[j].url;
																console.log(i);														
																$scope.selectedImagegalleryArray[i] = $scope.imagePreviewSrc[i];
																console.log($scope.selectedImagegalleryArray[i]);
																$scope.uniqueImageSelectionArray[i] = JsonObj[j].hash;
																console.log($scope.uniqueImageSelectionArray);
																$scope.showImgPrev[i] = true;														
																//$scope.adCreativeDetails(array[+i]);
															}
														}
														
													}else{
                                                                                                            if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
                                                                                                                $window.localStorage.setItem("TokenExpired",true);
                                                                                                                $state.go('login');
                                                                                                            }else{
                                                                                                                $rootScope.progressLoader = "none";
                                                                                                                $scope.editAdsetErrorMsg = 'block';
                                                                                                                if(response.networkError!='' && response.networkError!=undefined){
                                                                                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                                                                    $scope.errorMsg = response.networkError.error_user_msg;

                                                                                                                    $scope.errorpopupHeading = 'Error';
                                                                                                                    $scope.errorMsg = response.networkError.message;
                                                                                                                }else{
                                                                                                                    $scope.errorpopupHeading = 'Error';
                                                                                                                    $scope.errorMsg = response.errorMessage;
                                                                                                                }
                                                                                                            }
                                                                                                        }
													});
													
										
												
											/*$scope.imagePreviewSrc[i] = $scope.adCreativeDetails.thumbnail_url;
											$scope.selectedImagegalleryArray[i] = $scope.imagePreviewSrc[i];
											console.log($scope.imagePreviewSrc[i]);
											$scope.showImgPrev[i] = true; */
											
										}
										else{
											console.log(i);
											console.log($scope.child_attachments[i].picture);
											console.log($('#imagePreviewVideo'+i).attr('id'));
											$scope.imagePreviewVideoSrc[i] = $scope.child_attachments[i].picture;
											$scope.selectedImagegalleryArray[i] = $scope.imagePreviewVideoSrc[i];
											//$scope.selectedImagegalleryArray[i] = $scope.child_attachments[i].video_id;
											console.log($scope.imagePreviewSrc[i]);
											$scope.showVideoPrev[i] = true;
											
										}
								})(i);
									
							}
							
						}
					}
                                    }
					else{
					
						if ($scope.advertypeforEdit == "VIDEO") {
							$scope.fbadvertFormat = "fbsinglevideo";
							$rootScope.progressLoader = "none";
						}
						else if ($scope.advertypeforEdit == "PHOTO" || $scope.advertypeforEdit == "PAGE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							 
						}
						else if ($scope.advertypeforEdit == "SHARE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							
						}
						else if($scope.advertypeforEdit == "SLIDESHOW") {
                        $scope.fbadvertFormat = "fbslideshow";
                        $rootScope.progressLoader = "none";
                        
						}
					}
                    if($scope.fbadvertFormat == "fbsingleimage"){                        
                        $scope.thumbnail = response.data.fbAdCreativeResponse.thumbnail_url;
						$scope.thumbnailVideo="images/campaign/single-video.png";
						$scope.thumbnailCarousel="images/campaign/carousel.svg";
						 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.imgthumbnaildiv = true;
                        
                    }else if($scope.fbadvertFormat == "fbsinglevideo"){
                        $scope.thumbnailVideo = response.data.fbAdCreativeResponse.thumbnail_url;
                        $scope.thumbnail="images/campaign/single-image.png";
						  $scope.thumbnailCarousel="images/campaign/carousel.svg";
						   $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.vidthumbnaildiv = true;
                    }
					else if($scope.fbadvertFormat == "fbslideshow"){
                         $scope.thumbnailVideo = "images/campaign/single-video.png";
                         $scope.thumbnail="images/campaign/single-image.png";
					     $scope.thumbnailSlideshow = response.data.fbAdCreativeResponse.thumbnail_url;
						 $scope.thumbnailCarousel="images/campaign/carousel.svg";
                      
                    }
					else if($scope.fbadvertFormat == "fbcarosel"){
						  $scope.thumbnailCarousel = response.data.fbAdCreativeResponse.thumbnail_url;
                          $scope.thumbnailVideo="images/campaign/single-video.png";
                          $scope.thumbnail="images/campaign/single-image.png";
						  $scope.thumbnailSlideshow = "images/campaign/slide-show.png";

                    }
					
                    if ($scope.marketingObjective == "LINK_CLICKS") {
					
					if($scope.advertypeforEdit == "VIDEO"){
					    $scope.textBodyContent = $scope.adCreativeDetails.body;
					   $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
					    $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title; 
                         $scope.newsfeedlinkdesc =  $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;                    
					       if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action != undefined){
								$scope.callToDirectionValue = $scope.adCreativeDetails.call_to_action_type;
							}
							if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.app_destination == "MESSENGER"){
							   $scope.radioDestination = "MESSENGER";
							}else{
							   $scope.radioDestination = "WEBSITEURL";
							    $scope.isWebURL = true;
                                                                $scope.isDisplayLink = true;
								$scope.campaignWebURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link; 
						 $scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption; 
							}
							
					}
				
                        else {
						
						if ($scope.adCreativeDetails.object_type == "SHARE" && $scope.carouseladvent == true) {
							
								if ($scope.adCreativeDetails.url_tags != '' && $scope.adCreativeDetails.url_tags != 'undefined' && $scope.adCreativeDetails.url_tags != null) {
								$scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
								}
								$scope.isSeeMoreURL = true;
								 $scope.textBodyContent = $scope.adCreativeDetails.body;
								$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								$scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
								$scope.callToDirectionValue = $scope.adCreativeDetails.call_to_action_type;
								$scope.isText = true;
								$scope.isWebURL = false;
								$scope.isHeadline = false;
								//$scope.isSeeMoreURL = true;
								$scope.iscardDescription = true;
								$scope.iscardwebURL = true;
								$scope.iscarddisplayLink = true;
								
								if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.app_destination != undefined){
							   $scope.radioDestination = "MESSENGER";
							   $scope.isSeeMoreURL = false;
							   $scope.ismessengertext = true;
							   $scope.messengertextBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.page_welcome_message;
							}else{
							   $scope.radioDestination = "WEBSITEURL";
							   $scope.isSeeMoreURL = true;
							   $scope.ismessengertext = false;
							   $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                
							}
								
								
								
								if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {                                
                                $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                               
								}
							
						}
						
						else{
                            if ($scope.adCreativeDetails.object_story_spec.link_data.link) {
								
								if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.app_destination == "MESSENGER"){
									  $scope.radioDestination = "MESSENGER";
								}
                                 else {
                                $scope.radioDestination = "WEBSITEURL";
                                $scope.isWebURL = true;
                                $scope.isDisplayLink = true;
                                $scope.campaignWebURL = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                $scope.displayLink = $scope.adCreativeDetails.object_story_spec.link_data.caption;
                              }
                            }
                          
					
                            if ($scope.adCreativeDetails.object_story_spec) {
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id; //$window.localStorage.getItem("selectedTarget");
                            if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action){
                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                            }

                                $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.link_data.name; //$window.localStorage.getItem("campaignHeadline");
                                $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent");

                            }


                        } 
					}						
                    } else if ($scope.marketingObjective == "BRAND_AWARENESS") {

					if($scope.adCreativeDetails.object_type == "SHARE" || $scope.adCreativeDetails.object_type == "PHOTO"){
					
							if($scope.carouseladvent == true){
							
								if ($scope.adCreativeDetails.url_tags != '' && $scope.adCreativeDetails.url_tags != 'undefined' && $scope.adCreativeDetails.url_tags != null) {
								$scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
								}
								$scope.isAddWebsiteUrl = false;
								$scope.isWebsiteurl = false;
								$scope.isDisplayLinkOptional = false;
								$scope.isHeadline1 = false;
								$scope.isHeadline = false;
								$scope.isDestination = false;
								$scope.isSeeMoreURL = true;
								$scope.isNewsFeedLinkDesc = false;
								$scope.isMoreDisplayURLOptional = true;
								$scope.isCallToActionOptional = true;
								$scope.iscardDescription = true;
								$scope.iscardwebURL = true;
								$scope.iscarddisplayLink = true;
								$scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
								$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								$scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
								if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action!= "undefined"){
								$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
								}

								if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {                                
                                $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                               
								}
							}
							
							else{
                                                                if ($scope.adCreativeDetails.object_type == "SHARE" || $scope.adCreativeDetails.object_type == "PHOTO") {

                                                                    if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("link_data"))
                                                                    {
                                                                        $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
                                                                        $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                                                        if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action)
                                                                        {
                                                                            $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                                                                        }
                                                                        else
                                                                        {
                                                                            $scope.callToDirectionValue = "NO_BUTTON";
                                                                        }
                                                                        $scope.valAddWebsiteUrl = true;
                                                                        $scope.checkAddWebsiteUrl();
                                                                        $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                                                        $scope.webURL = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                                                        if($scope.adCreativeDetails.object_story_spec.link_data.caption)
                                                                        {
                                                                            $scope.displayLink = $scope.adCreativeDetails.object_story_spec.link_data.caption;
                                                                        }
                                                                        else
                                                                        {
                                                                            $scope.displayLink = "";
                                                                        }
                                                                        $scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.link_data.name;
                                                                    }
                                                                    else if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("photo_data") || $scope.adCreativeDetails.object_story_spec.hasOwnProperty("video_data"))
                                                                    {
                                                                        $scope.textBodyContent = $scope.adCreativeDetails.body;
                                                                        $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                                                        $scope.valAddWebsiteUrl = false;
                                                                        $scope.newsfeedlinkdesc = "";
                                                                        $scope.displayLink = "";
                                                                        $scope.campaignHeadline = "";
                                                                        if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("photo_data"))
                                                                        {
                                                                            $scope.callToDirectionValue = "NO_BUTTON";
                                                                        }
                                                                        else if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("video_data"))
                                                                        {
                                                                            $scope.callToDirectionValue = "LEARN_MORE";
                                                                        }
                                                                        $scope.webURL = "";
                                                                        $scope.checkAddWebsiteUrl();
                                                                    }

                                                                    if($scope.adCreativeDetails.url_tags)
                                                                    {
                                                                        $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                                                                    }
                                                                    else
                                                                    {
                                                                        $scope.campaignURLParameter = "";
                                                                    }
                                                                }
						}
						
					}
                                        else if($scope.adCreativeDetails.object_type == "VIDEO")
                                        {
                                            $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.video_data.description;
                                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                            if($scope.adCreativeDetails.object_story_spec.video_data.hasOwnProperty("call_to_action"))
                                            {
                                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
                                                $scope.valAddWebsiteUrl = true;
                                                $scope.checkAddWebsiteUrl();
                                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;
                                                $scope.webURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link;
                                                if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title)
                                                {
                                                    $scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption;
                                                }
                                                else
                                                {
                                                    $scope.displayLink = "";
                                                }
                                                $scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title;
                                            }
                                            else
                                            {
                                                $scope.valAddWebsiteUrl = false;
                                                $scope.newsfeedlinkdesc = "";
                                                $scope.displayLink = "";
                                                $scope.campaignHeadline = "";
                                                $scope.callToDirectionValue = "LEARN_MORE";
                                                $scope.webURL = "";
                                                $scope.checkAddWebsiteUrl();
                                            }
                                            if($scope.adCreativeDetails.url_tags)
                                            {
                                                $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                                            }
                                            else
                                            {
                                                $scope.campaignURLParameter = "";
                                            }
                                        }
					
					
                    } else if ($scope.marketingObjective == "PAGE_LIKES") {
                        
						console.log($scope.adCreativeDetails);
                            $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                            $scope.selectedTarget = $scope.adCreativeDetails.object_id; //$window.localStorage.getItem("selectedTarget");
                            $scope.campaignHeadline = $scope.adCreativeDetails.title;
                            if($scope.adCreativeDetails.link_url != undefined)
                            {
                                var link_url_parts = $scope.adCreativeDetails.link_url.split('/');
//                            console.log(link_url_parts);
//                            console.log(link_url_parts[link_url_parts.length - 2]);
//                            console.log((link_url_parts[link_url_parts.length - 2]).indexOf($scope.selectedTarget));
                                if((link_url_parts[link_url_parts.length - 2]).indexOf($scope.selectedTarget) != -1) {
                                    $scope.campaignLandingView = "Timeline";
//                                console.log("edit mode landing view",$scope.campaignLandingView);
                                }
                                else {
                                    $scope.campaignLandingView = link_url_parts[link_url_parts.length - 2].charAt(0).toUpperCase() + link_url_parts[link_url_parts.length - 2].slice(1);
//                                    console.log("edit mode landing view",$scope.campaignLandingView);
                                }
                            }
                            else
                            {
                                $scope.campaignLandingView = "Timeline";
                            }
                       
                    } else if ($scope.marketingObjective == "EVENT_RESPONSES") {
                        //console.log($scope.adCreativeDetails);
                        if ($scope.adCreativeDetails.object_story_spec) {
                            $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id; //$window.localStorage.getItem("selectedTarget");
                        }
						 if($scope.adCreativeDetails.object_story_spec.link_data.event_id){			
	                                $scope.campaignEventLoader=false;			
	                                if($scope.adCreativeDetails.object_story_spec.link_data.event_id!='' && $scope.adCreativeDetails.object_story_spec.link_data.event_id!=undefined && $scope.adCreativeDetails.object_story_spec.link_data.event_id!=null){			
	                                    $scope.campaignAudienceCampaignTargetType = 'event';			
	                                    $window.localStorage.setItem("campaignAudienceTargetType","event");			
	                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.link_data.event_id;			
	                                    $window.localStorage.setItem("campaignAudienceTarget",$scope.campaignAudienceCampaignTarget);			
	                                }			
	                            }else if($scope.adCreativeDetails.object_story_spec.video_data.event_id){			
	                                $scope.campaignEventLoader=false;			
	                                if($scope.adCreativeDetails.object_story_spec.video_data.event_id!='' && $scope.adCreativeDetails.object_story_spec.video_data.event_id!=undefined && $scope.adCreativeDetails.object_story_spec.video_data.event_id!=null){			
	                                    $scope.campaignAudienceCampaignTargetType = 'event';			
	                                    $window.localStorage.setItem("campaignAudienceTargetType","event");			
	                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.video_data.event_id;			
	                                    $window.localStorage.setItem("campaignAudienceTarget",$scope.campaignAudienceCampaignTarget);			
	                                }			
	                            }
                    } else if ($scope.marketingObjective == "VIDEO_VIEWS") {

                       
					if($scope.adCreativeDetails.object_type == "SHARE"){
						if($scope.carouseladvent == true){
								$scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
								$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								$scope.isAddWebsiteUrl = false;
								$scope.isWebsiteurl = false;
								$scope.isDisplayLinkOptional = false;
								$scope.isHeadline1 = false;
								$scope.isHeadline = false;								
								$scope.isDestination = false;
								$scope.isSeeMoreURL = false;
								$scope.isNewsFeedLinkDesc = false;
								$scope.isMoreDisplayURLOptional = false;
								$scope.isCallToActionOptional = false;
								$scope.isDisplayLink = false;
								$scope.isCallToAction = false;
								$scope.isCreateShowandHideOptionWrap1 = false;
								
								$scope.mediaImage = false;
								$scope.mediaVideo = false;
								$scope.videoviewsmediaUpdate = true;
								$scope.mediaarrow = true;
								$scope.cardarrow = false;								
								$scope.imageFormat = "videoviewsmediaUpdate";  
								
							}
					}
					else{
		
                        $scope.textBodyContent = $scope.adCreativeDetails.body;
                        if ($scope.adCreativeDetails.object_story_spec.video_data.call_to_action) {                          
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;                     
						
				
							$scope.valAddWebsiteUrl = true;
							$scope.checkAddWebsiteUrl();
							$scope.isCallToAction = true;
							$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
							$scope.webURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link;//$window.localStorage.getItem("valAddWebsiteUrl");
							$scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;
							$scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption; //$window.localStorage.getItem("displayLink"); 
							$scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title;

                        } else {
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $scope.valAddWebsiteUrl = false;
                            $scope.checkAddWebsiteUrl();
                            $scope.isDisplayLink = false;
                            $scope.displayLink = '';
							$scope.isCallToAction = false;
                        }
                    } 
                    } else if ($scope.marketingObjective == "POST_ENGAGEMENT") {
                        if ($scope.adCreativeDetails.object_story_spec) {
                            $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                        }
                    }
					else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {
					if($scope.adCreativeDetails.object_type == "SHARE"){
                         if($scope.carouseladvent == true){
						 console.log('deep link check');
							if ($scope.adCreativeDetails.url_tags != '' && $scope.adCreativeDetails.url_tags != 'undefined' && $scope.adCreativeDetails.url_tags != null) {
								$scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
								}
							$scope.textBodyContent = $scope.adCreativeDetails.body;
							$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
							$scope.isHeadline1 = false;
							$scope.isHeadline = false;
							$scope.deepLink = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.link;
							$scope.isDestination = false;
							$scope.iscardDescription = true;
							$scope.iscardwebURL = true;
							$scope.iscarddisplayLink = true;
						}
						else{
                        if ($scope.adCreativeDetails.object_story_spec.link_data) {
                            $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							$scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.link_title;
							$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                        }
						else{
							if($scope.adCreativeDetails.object_story_spec.video_data)
							{
								$scope.textBodyContent = $scope.adCreativeDetails.body;
								$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								$scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title;
								$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
								
							}
						}
						}
					}
					else{
							$scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							$scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.link_title;
							$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
					}
                    }
                    else if ($scope.marketingObjective == "REACH") {
							//$scope.adCreativeDetails.object_type = "SLIDESHOW";

                        if ($scope.adCreativeDetails.object_type == "SHARE" || $scope.adCreativeDetails.object_type == "PHOTO") {
                            if($scope.carouseladvent == true){
                                if ($scope.adCreativeDetails.url_tags != '' && $scope.adCreativeDetails.url_tags != 'undefined' && $scope.adCreativeDetails.url_tags != null) {
                                    $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                                }
                                $scope.isHeadline = false;
                                $scope.isDestination = false;
                                $scope.isWebURL = false;	
                                $scope.isNewsFeedLinkDesc = false;
                                $scope.isWebsiteurl = false;
                                $scope.isCallToActionOptional = true;
                                $scope.isSeeMoreURL = true;
                                $scope.isAddWebsiteUrl = false;			
                                $scope.iscardDescription = true;
                                $scope.iscardwebURL = true;
                                $scope.iscarddisplayLink = true;								
                                $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								 $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action!= "undefined"){
                                    $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                                }

                                if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {                                
                                    $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                }
                            }
                            else{
                                if ($scope.adCreativeDetails.object_type == "SHARE" || $scope.adCreativeDetails.object_type == "PHOTO" ) {
                                    if($scope.carouseladvent == true){
                                        $scope.isHeadline = false;
                                        $scope.isDestination = false;
                                        $scope.isWebURL = false;	
                                        $scope.isNewsFeedLinkDesc = false;
                                        $scope.isWebsiteurl = false;
                                        $scope.isCallToActionOptional = true;
                                        $scope.isSeeMoreURL = true;
                                        $scope.isAddWebsiteUrl = false;								
                                        $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
                                        $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                        if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action!= "undefined"){
                                            $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                                        }
                                        if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {
                                            $scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                        }
                                    }
                                    else{
                                        if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("link_data"))
                                        {
                                            $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
                                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                            if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action)
                                            {
                                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                                            }
                                            else
                                            {
                                                $scope.callToDirectionValue = "";
                                            }
                                            $scope.valAddWebsiteUrl = true;
                                            $scope.checkAddWebsiteUrl();
                                            $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                            $scope.webURL = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                            if($scope.adCreativeDetails.object_story_spec.link_data.caption)
                                            {
                                                $scope.displayLink = $scope.adCreativeDetails.object_story_spec.link_data.caption;
                                            }
                                            else
                                            {
                                                $scope.displayLink = "";
                                            }
                                            $scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.link_data.name;
                                        }
                                        else if($scope.adCreativeDetails.object_story_spec.hasOwnProperty("photo_data"))
                                        {
                                            $scope.textBodyContent = $scope.adCreativeDetails.body;
                                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                            $scope.valAddWebsiteUrl = false;
                                            $scope.newsfeedlinkdesc = "";
                                            $scope.displayLink = "";
                                            $scope.campaignHeadline = "";
                                            $scope.callToDirectionValue = "";
                                            $scope.webURL = "";
                                            $scope.checkAddWebsiteUrl();
                                        }

                                        if($scope.adCreativeDetails.url_tags)
                                        {
                                            $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                                        }
                                        else
                                        {
                                            $scope.campaignURLParameter = "";
                                        }
                                    }
                                }
                            }
                        }else if ($scope.adCreativeDetails.object_type == "VIDEO"){
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.video_data.description;
                            if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action ==undefined){
                                $scope.valAddWebsiteUrl = false;
                                $scope.newsfeedlinkdesc = "";
                                $scope.displayLink = "";
                                $scope.campaignHeadline = "";
                                $scope.callToDirectionValue = "";
                                $scope.webURL = "";
                                $scope.checkAddWebsiteUrl();
                            }
                            else
                            {
                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
                                $scope.valAddWebsiteUrl = true;
                                $scope.checkAddWebsiteUrl();
                            }
                            if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action){
                                $scope.valAddWebsiteUrl = true;
                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;
                                $scope.webURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link;
                                $scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption;
                                $scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title;
                            }
                            if($scope.adCreativeDetails.url_tags)
                            {
                                $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                            }
                            else
                            {
                                $scope.campaignURLParameter = "";
                            }
                        }
					else if($scope.adCreativeDetails.object_type == "SLIDESHOW"){
						
						  $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
						  $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.video_data.description;						  
						 if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action){
							   $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
							   $scope.isAddWebsiteUrl = true;
							   $scope.valAddWebsiteUrl = true;
							   $scope.isCreateShowandHideOptionWrap1 = true;
							   $scope.checkAddWebsiteUrl();		
							   $scope.isDestination = false;
							   $scope.isHeadline = false;
							   $scope.rightColumn = false;
								if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value != "undefined"){
									$scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;
									$scope.webURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link;
									$scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption;
									$scope.campaignHeadline = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title;									
								}								   
						 }else{							 
						  $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
						  $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.video_data.description;		
						    $scope.valAddWebsiteUrl = false;
						    $scope.checkAddWebsiteUrl();	
					        $scope.isAddWebsiteUrl = false;
							$scope.rightColumn = false;
							$scope.isDestination = false;
							$scope.isHeadline = false;
						    $scope.isCreateShowandHideOptionWrap1 = true;
						 }						 
						 if($scope.adCreativeDetails.thumbnail_url){
							 
							 $scope.slideShowCreate = false;
							 $scope.slideShowSuccess = true;
							 $scope.slideShowPreview = $scope.adCreativeDetails.thumbnail_url;
						 }
					
					}
                    
                    }else if ($scope.marketingObjective == "LEAD_GENERATION") {

                        if($scope.advertypeforEdit == "VIDEO"){
                                            
                            $scope.textBodyContent = $scope.adCreativeDetails.body;                            
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title; 

                            if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action != "undefined"){
                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;                                    
                                if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value != "undefined"){
                                    $scope.selectLeadForm = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.lead_gen_form_id;
                                }                                    
                            }
                            $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;;
                            $scope.campaignWebURL = $scope.adCreativeDetails.object_story_spec.video_data.link;
                            $scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption;
							
							
						} 
			
						else if($scope.adCreativeDetails.object_type == "SHARE" && $scope.carouseladvent == true){
							$scope.textBodyContent = $scope.adCreativeDetails.body;                            
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action != "undefined"){
                                    $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;                                    
                                    if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value != "undefined"){
                                        $scope.selectLeadForm = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.lead_gen_form_id;
										console.log($scope.selectLeadForm);
										$window.localStorage.setItem("campaignAudienceTarget", $scope.selectedTarget);
                                    }                                    
                                }
								if ($scope.adCreativeDetails.url_tags) {
									$scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
								}
								
								$scope.isHeadline = false;
								$scope.isDestination = false;
								$scope.isWebURL = false;	
								$scope.isNewsFeedLinkDesc = false;
								$scope.isWebsiteurl = false;
								$scope.isCallToActionOptional = false;
								$scope.isSeeMoreURL = false;
								$scope.isDisplayLink = false;
								$scope.isAddWebsiteUrl = false;
								$scope.isCreateShowandHideOptionWrap1 = false;
								$scope.iscardDescription = false;
								$scope.iscardwebURL = false;
								$scope.iscarddisplayLink = false;
							
						}
			
						else {
                            
                            if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {
                                //$scope.radioDestination = "WEBSITEURL";
                                //$scope.isWebURL = true;
                                //$scope.isDisplayLink = true;
                                $scope.campaignWebURL = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                $scope.displayLink = $scope.adCreativeDetails.object_story_spec.link_data.caption;
                            }

                            if ($scope.adCreativeDetails.object_story_spec) {    
                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                                if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action != "undefined"){
                                    $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;                                    
                                    if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value != "undefined"){
                                        $scope.selectLeadForm = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.lead_gen_form_id;
                                    }                                    
                                }
                                $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.link_data.name; //$window.localStorage.getItem("campaignHeadline");
                                $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent");
                            }
                        }
                        $scope.getLeadGenForm();                        
                    }else if ($scope.marketingObjective == "OFFER_CLAIMS") {
                        //alert($scope.advertypeforEdit);
                        if($scope.advertypeforEdit == "VIDEO"){
                            $scope.textBodyContent = $scope.adCreativeDetails.body;
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            //alert($scope.selectedTarget);
							 $scope.rightColumn = false;
                        }
						
						else if($scope.adCreativeDetails.object_type == "SHARE" && $scope.carouseladvent == true){
							$scope.textBodyContent = $scope.adCreativeDetails.body;
							$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							$window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
							$scope.isAddWebsiteUrl = false;
								$scope.isText = true;
								$scope.isWebsiteurl = false;
								$scope.isDisplayLinkOptional = false;
								$scope.isHeadline1 = false;
								$scope.isHeadline = false;								
								$scope.isDestination = false;
								$scope.isSeeMoreURL = false;
								$scope.isNewsFeedLinkDesc = false;
								$scope.isMoreDisplayURLOptional = false;
								$scope.isCallToActionOptional = false;
								$scope.isDisplayLink = false;
								$scope.isCallToAction = false;
								$scope.isCreateShowandHideOptionWrap1 = false;
								
								$scope.mediaImage = false;
								$scope.mediaVideo = false;
								$scope.offersmediaUpdate = true;
								$scope.mediaarrow = true;
								$scope.cardarrow = false;								
								$scope.imageFormat = "offersmediaUpdate"; 
						}
						
						else{
                            $scope.textBodyContent = $scope.adCreativeDetails.body;
                            if ($scope.adCreativeDetails.object_story_spec) {
                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            }
                        }
                    }else if ($scope.marketingObjective == "CONVERSIONS") {
                        
                        if($scope.advertypeforEdit == "VIDEO"){
                                            
                            $scope.textBodyContent = $scope.adCreativeDetails.body;                            
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_title; 
                            $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.video_data.description;
                            
                            if($scope.adCreativeDetails.object_story_spec.video_data.call_to_action != undefined){
                                $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.type;
                            }
                            $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_description;
                            $scope.webURL = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link; 
                            $scope.displayLink = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.link_caption;
							
							
						} 
						
						else if($scope.adCreativeDetails.object_type == "SHARE" && $scope.carouseladvent == true){
							if ($scope.adCreativeDetails.url_tags != '' && $scope.adCreativeDetails.url_tags != 'undefined' && $scope.adCreativeDetails.url_tags != null) {
								$scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
								}
								$scope.isHeadline = false;
								$scope.isDestination = true;
								$scope.isurlandcanvas = true;
								$scope.isWebURL = false;	
								$scope.isNewsFeedLinkDesc = false;
								$scope.isWebsiteurl = false;
								$scope.isCallToActionOptional = true;
								$scope.isSeeMoreURL = true;
								$scope.isAddWebsiteUrl = false;			
								$scope.iscardDescription = true;
								$scope.iscardwebURL = true;
								$scope.iscarddisplayLink = true;								
								$scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
								$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
								$scope.seeMoreUrl = $scope.adCreativeDetails.object_story_spec.link_data.link;
								if(typeof($scope.adCreativeDetails.object_story_spec.link_data.call_to_action) !== "undefined"){
								$scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
								}
						}
						
						else {
                            
                            if ($scope.adCreativeDetails.object_story_spec.link_data.link != "" || $scope.adCreativeDetails.object_story_spec.link_data.link != "undefined") {                                
                                $scope.webURL = $scope.adCreativeDetails.object_story_spec.link_data.link;
                                $scope.displayLink = $scope.adCreativeDetails.object_story_spec.link_data.caption;
                            }

                            if ($scope.adCreativeDetails.object_story_spec) {
                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                                if($scope.adCreativeDetails.object_story_spec.link_data.call_to_action != "undefined"){
                                    $scope.callToDirectionValue = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.type;
                                }
                                $scope.campaignHeadline1 = $scope.adCreativeDetails.object_story_spec.link_data.name;
                                $scope.textBodyContent = $scope.adCreativeDetails.object_story_spec.link_data.message;
                            }
                        }
                    }
                    
                
                }else{
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }
        $scope.getAdForEdit = function () {
            var queryStr = "adsetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");

            $http({
                method: 'GET',
                url: apiTPBase + '/readaddata?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log(response.data.ads);
                if (response.data.appStatus == '0') {// success
                    angular.forEach(response.data.ads, function (value, key) {
                        var JsonObj = response.data.ads[key];
                        //console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                //$scope.adCreativeDetails(array[+i]);
                            }
                        }
                    });
                } else {// failed
                    console.log("failed for getadforedit service");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }
        
        $scope.getPageOffers = function(){
            //console.log($scope.connectFBVal);
            //console.log($scope.selectedTarget);
            var pageObj = $filter('filter')($scope.connectFBVal, function(d){return d.id == $scope.selectedTarget;})[0];
            $http({
                url : apiTPBase +'/getoffersinpage?'+'userNetworkMapId='+$window.localStorage.getItem('userNetworkMapId')+"&pageId="+$scope.selectedTarget+"&pageAccessToken="+pageObj.access_token,
                dataType : 'json',
                method : 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function(response){
                angular.forEach(response.offersInPage, function(value, key){
                    var JsonObj = response.offersInPage[key];            
                    var array = [];
                    for(var i in JsonObj) {
                        if(JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                            var OfferDetails = array[+i] = JsonObj[i];
                            var newOfferArr = {
                                "id" : OfferDetails.id,
                                "name" : OfferDetails.title,
                                "redemptionlink" : OfferDetails.redemption_link
                            }
                            $scope.campaignAudienceCampaignOfferArr.push(newOfferArr);
                        }
                    }
                });
                var OfferObj = $filter('filter')($scope.campaignAudienceCampaignOfferArr, function(d){return d.id==$scope.campaignAudienceCampaignOffer;})[0];
                $window.localStorage.setItem("OfferRedemptionLink",OfferObj.redemptionlink);
                $window.localStorage.setItem("OfferName",OfferObj.name);
            }).error(function(error){
                //alert(error);
            });
        }
        
        $scope.init = function () {
            
            if($window.localStorage.getItem("marketingObjective") == 'LEAD_GENERATION'){
                $scope.isLeadGen = true;
                $scope.callToDirectionValue = 'SIGN_UP';
                $scope.uploadstep = '3';
                $scope.previewstep = '4';
                if($window.localStorage.getItem("campaignState")=='create'){
                    $scope.getLeadGenForm();
                }
            }else if($window.localStorage.getItem("marketingObjective") == 'CANVAS_APP_INSTALLS'){
				$scope.radioDestination="APPSTORE";
				if($window.localStorage.getItem("campaignAudienceTargetType") == 'app'){
					
					$scope.appID = $window.localStorage.getItem("campaignAudienceTarget");
					$scope.deepLink = "https://apps.facebook.com/"+$scope.appID;
					console.log($scope.deepLink);
				}
			}            
            
            angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
            console.log(angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle"));
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
            $rootScope.freezeFlag = false;
            $rootScope.overLayAudience = false;

            //alert("1"+$scope.overLay);

            $rootScope.step = 4;
            if ($rootScope.campaignSteps[3] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }
            //$window.localStorage.setItem("campaignState", "edit");
           // angular.element('#step1').css('background-color', '#95D2B1');

            $scope.connectFBVal1 = $window.localStorage.getItem("pageCampaignTargetArr");
            $scope.connectFBVal = ""//JSON.parse($scope.connectFBVal1);
            $scope.campaignAudienceTargetType = $window.localStorage.getItem("campaignAudienceTargetType");
            //console.log($window.localStorage.getItem("campaignAudienceTarget"));
            $scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            
            if ($scope.selectedTarget == "undefined") {
                $scope.selectedTarget = "";
            }
            if ($scope.campaignPromateURL != "" && $scope.campaignPromateURL!="undefined" && $scope.campaignPromateURL!=null) {
                $scope.selectedTarget = "";
            }
            //alert($scope.selectedTarget);
//            if ($scope.callToDirectionValue == undefined) {
//                $scope.callToDirectionValue = "0";
//            }
            $scope.campaignPromateURL = $window.localStorage.getItem("hdcampaignAudienceCampaignTargetName");
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            $scope.previewSection();
            //$scope.adsetIdDetails = globalData.getLocal($window.localStorage.getItem("campaignId"));        		
            //$scope.useExistingPostLink = false;
            $scope.checkPreview();            
            $scope.getPromotablePage();
            if($window.localStorage.getItem("marketingObjective") == 'EVENT_RESPONSES'){
                $scope.getEventArr();
            }
            var campaignState = $window.localStorage.getItem("campaignState");
            $scope.campState = $window.localStorage.getItem("campaignState");
            //console.log(campaignState);
             if (campaignState == "create") {
              $scope.thumbnail="images/campaign/single-image.png";
              $scope.thumbnailVideo = "images/campaign/single-video.png";

			  $scope.thumbnailCarousel = "images/campaign/carousel.svg";

			 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";

             }
            if (campaignState == "edit") {
			$scope.carouseladvent1 = false;
                if ($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;					
                } else {
                    $scope.adminUserRole = false;					
                }
                //var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.textBodyContent = $window.localStorage.getItem("textBodyContent");

                //$scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
                $scope.newsfeedlinkdesc = $window.localStorage.getItem("newsfeedlinkdesc");
                $scope.displayLink = $window.localStorage.getItem("displayLink");
                $scope.campaignHeadline = $window.localStorage.getItem("campaignHeadline");
                $scope.campaignHeadline1 = $window.localStorage.getItem("campaignHeadline1");
                $scope.callToDirectionValue = $window.localStorage.getItem("callToDirectionValue");
                $scope.selectLeadForm = $window.localStorage.getItem("selectLeadForm");
                
                $scope.webURL = $window.localStorage.getItem("webURL");
                $scope.selectedTarget = $window.localStorage.getItem("selectedTarget");
                if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES")
                {
                    $scope.campaignAudienceLandingViewLoader = true;
                    $scope.getPageTabs($scope.selectedTarget);
                }
                $scope.valAddWebsiteUrl = $window.localStorage.getItem("valAddWebsiteUrl");
                //$scope.campaignHeadline = $window.localStorage.getItem("hdcampaignAudienceCampaignTargetName");
                $scope.getAdCreativeIdFromFaceBook();
                //$scope.getAdCreativeForEdit();
                //$scope.getAdForEdit();
            }
            
            // alert($scope.objectType);
			$scope.setLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.fsValue = angular.element(document.getElementById('step1')).offset().top;					
						$scope.ssValue = angular.element(document.getElementById('step2')).offset().top;		
						$scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                                                var offsetHeight3 = document.getElementById('step3container').offsetHeight;
                                                var fStep = $(".vr");						
                                                fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
                                                
					}
					}, 10);
			};
			$scope.setLine();
			$scope.setFixLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.exfsValue = angular.element(document.getElementById('existingStep1')).offset().top;					
						$scope.exssValue = angular.element(document.getElementById('existingStep2')).offset().top;											
						var exStep = $(".vline");						
						exStep.css('height', (($scope.exssValue - $scope.exfsValue)));						
					}
					}, 10);
			};
			
			$scope.imagePreviewSrc = [];
			$scope.imagePreviewVideoSrc = [];
			
		}
        
        $scope.getEventArr = function(){
            
            $scope.campaignEventLoader = true;
            //FOR EVENT
            $http({
                url : apiTPBase +'/getuserpromotedconnections?networkAdAccountId='+$scope.networkAdAccountId+'&userNetworkMapId='+$window.localStorage.getItem('userNetworkMapId'),
                dataType : 'json',
                method : 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function(response){
                if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
                    $window.localStorage.setItem("TokenExpired",true);
                    $state.go('login');
                };
                var promises = [];
                angular.forEach(response.events, function(value, key){
                    
                    //CHECK IF EVENT IS CORRECT OR NOT
                    $http({
                        url : 'https://graph.facebook.com/v2.8/'+value.id+'?access_token='+$rootScope.networkAccessToken+'&fields=is_page_owned',
                        dataType : 'json',
                        method : 'GET'
                    }).success(function(eventstatusresponse){
                        if(eventstatusresponse.is_page_owned){
                            var M_Obj = {id:eventstatusresponse.id, name:value.name};
                            promises.push(M_Obj);
                            $scope.eventCampaignTargetArr = promises;
                            $scope.campaignAudienceCampaignTargetArr = $scope.eventCampaignTargetArr;
                        }
                        $scope.campaignEventLoader = false;
                    }).catch(function(eventstatuserror){
                        console.log(eventstatuserror);
                    });

                });
                $scope.campaignAudienceCampaignTargetLoader = false;
                
            }).error(function(error){
                //alert(error);
            });
            
        }
        
        $scope.sendcampaignAudienceCampaignTarget = function(campaignAudienceCampaignTarget){
            $scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $rootScope.freezeFlag = true;
        }
        
        $scope.localAwareness = [
            {
                "id": "CALL_NOW",
                "name": "Call Now"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "GET DIRECTIONS"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }
        ]

        $scope.canvas_app_installs1 = [
            {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "USE_APP",
                "name": "Use App"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }
        ]
        $scope.canvas_app_installs = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "INSTALL_NOW",
                "name": "Install Now"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "LISTEN_NOW",
                "name": "Listen Now"
            }, {
                "id": "PLAY_GAME",
                "name": "Play Game"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            },{
                "id": "SIGN_UP",
                "name": "Sign Up"
            },{
                "id": "USE_APP",
                "name": "Use App"
            },{
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]
        $scope.reachPeople = [
			{
                "id": "LEARN_MORE",
                "name": "Learn More"
            },
            {
                "id": "CALL_NOW",
                "name": "Call Now"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "Get Directions"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }
        ]

        $scope.brandAwareness = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]
        
        $scope.leadgeneration = [
            {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "GET_QUOTE",
                "name": "Get Quote"
            },{
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            },{
                "id": "SUBSCRIBE",
                "name": "Subscribe"
            }

        ]


        $scope.videoBrandAwareness = [
            {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]

        $scope.video_views = [
            {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]

		$scope.pixelTrackingOptions = [
		{
			"id":"allpixel",
			"name":"Track all conversions from my Facebook pixel"			
		},
		{	
			"id":"nopixel",
			"name":"Do not track conversions"		
		}]
        
    $scope.getLeadGenForm = function(){
        //alert($window.localStorage.getItem('campaignAudienceTarget'));
        $http({
            url: apiTPBase + '/getleadgenforms?' + 'userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId')+'&pageId='+$window.localStorage.getItem('campaignAudienceTarget'),
            dataType: 'json',
            method: 'GET',
            headers: {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
        }).success(function (response) {
            $scope.connectLeadFormVal = [];
            angular.forEach(response.leadgenForms, function(value, key){
                var JsonObj = response.leadgenForms[key];            
                var array = [];          
                for(var i in JsonObj) {
                    if(JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                        var LeadFromDetails = array[+i] = JsonObj[i];                        
                        $scope.connectLeadFormVal.push(LeadFromDetails);
                    }
                }
            });
        }).error(function (error) {
            //alert(error);
            console.log(" failed $scope.getLeadGenForm")
        });

    }
        
        $scope.getPromotablePage = function () {
            $http({
                url: apiTPBase + '/fetchuserpromotablepages?' + 'userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId'),
                dataType: 'json',
                method: 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function (response) {
				$scope.campaignAudienceCampaignTargetLoader = false;
                //console.log(response);
                $scope.connectFBVal = response.fbUserPromotablePagesResponse;
                if($window.localStorage.getItem("marketingObjective") == 'OFFER_CLAIMS'){
                    $scope.getPageOffers();
                }
                if($window.localStorage.getItem("campaignState") == "create") {
                    if($window.localStorage.getItem("campaignAudienceTarget") != "undefined" && $window.localStorage.getItem("campaignAudienceTarget") != undefined && $window.localStorage.getItem("campaignAudienceTarget") != "") {
                        if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                            $scope.campaignAudienceLandingViewLoader = true;
                            $scope.getPageTabs($window.localStorage.getItem("campaignAudienceTarget"));
                        }
                    }
                }
            }).error(function (error) {
                //alert(error);
                console.log(" failed $scope.getPromotablePage")
            });
        }
        
        $scope.getExistingPost = function (pageId) {
            
            $scope.existingPostArr = [];
            $scope.selectedPostPage = '';
            var pageObj = $filter('filter')($scope.connectFBVal, function(d){return d.id == pageId;})[0];
            
            $scope.selectedPostPageLoader = true;
            $http({
                url: apiTPBase + '/getpagefeed?' + 'userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId')+"&pageId="+pageId+"&pageAccessToken="+pageObj.access_token,
                dataType: 'json',
                method: 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function (response) {
                //console.log(response);
                $scope.selectedPostPageLoader = false;
                angular.forEach(response.feedsInPage, function(val, key){
                    var JsonObj = response.feedsInPage[key];
                    angular.forEach(JsonObj, function(v, k){
                       angular.forEach(v.story_tags, function(vv, kk){
                           if(vv.id!=pageId && v.type=='page'){
                                var ExistingObj = 
                                {
                                    id:vv.id,
                                    name:vv.name,
                                    picture:v.picture,
                                    permalink_url:v.permalink_url,
                                    type:v.type
                                }
                               $scope.existingPostArr.push(ExistingObj);                               
                           }
                       }); 
                    });                    
                });
            }).error(function (error) {
                //alert(error);
                console.log(" failed $scope.getExistingPost")
            });
        }
        
        $scope.showExistingPost = function(){
            console.log($scope.existingPostArr);
            $scope.showExistingPopup = true;
            var selectExistingPopup = $(".selectExistingPopup");
            selectExistingPopup.show();                                
            angular.element($('body').css("overflow-y", "scroll"));
            var postObj = $filter('filter')($scope.existingPostArr, function(d){return d.id == $scope.selectedPostPage;})[0];
            $scope.postHeading = postObj.name;
            $scope.postImage = postObj.picture;
            $scope.permalinkUrl = postObj.permalink_url;
            
        }
        
        $scope.addExistingPost = function(){
            
            $scope.objectType = "SHARE";
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": $scope.networkAdAccountId,
                "objectType": $scope.objectType,
                "body": "test body",
                "name": "test name",
                "objectStoryId": $scope.selectedTarget+"_"+$scope.selectedPostPage
            };
            if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null){
                var urlparams = {
                    "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
            console.log(parameters);
            $http({
                method: 'POST',
                url: apiTPBase + '/createadcreative',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {
                
                if (response.data.appStatus == 0) {
                    $rootScope.progressLoader = "block";
                    $scope.adCreativeId = response.data.adCreativeId;

                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.hideExistingPost();
                    $scope.createAd();
                    $scope.desktopCreativePreview_1();
                    $scope.mobileCreativePreview_1();
                    $scope.rightColumnCreativePreview_1();

                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                }
                else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                    $scope.showMediaErrorPopup(response);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }
                
            });
            
        }
        
        $scope.hideExistingPost= function(){
            $scope.showExistingPopup = false;
            angular.element($('body').css("overflow-y", "scroll"));
        }
                
        $scope.checkPreview = function () {
            
            var preview = $window.localStorage.getItem("campaignAudiencePlacementsValues");
            preview = "mobilenewsfeed,desktoprightcolumn,desktopnewsfeed";
            var arr = preview.split(',');
            angular.forEach(arr, function (value, key) {
                //console.log(arr[key])
                if (arr[key] == 'mobilenewsfeed') {
                    $scope.mobile = true;
                }
                if (arr[key] == 'desktoprightcolumn') {
                    $scope.rightColumn = true;
                }
                if (arr[key] == 'desktopnewsfeed') {
                    $scope.desktop = true;
                }
                if (arr[key] == 'instagram') {
                    $scope.instagramfeed = true;
                }
            });
        

            //mobilenewsfeed,desktoprightcolumn,desktopnewsfeed
        }
       
     
        $scope.fetChPreview = function () {
            var queryStr = ""//$scope.fbAccessToken+"&ad_format=\'DESKTOP_FEED_STANDARD\'&creative={\"object_story_id":"585993311604680_1843108879300915"}"
            $http({
                method: 'GET',
                url: "https://graph.facebook.com/v2.8/act_" + $scope.networkAdAccountId + "/generatepreviews?access_token=" + queryStr,
            }).then(function (response) {
                //console.log(response);
            });
        }
        
        
        $scope.selectAdvertFormat = function (mode) {
            
            
             
            
            if (mode == 'insert') {
                $rootScope.freezeFlag = true;
				angular.element($('.btnCampaignCreative').prop('disabled', true));
				//angular.element($('.accordianRole').prop('disabled', true));
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            } else {				
                $rootScope.freezeFlag = false;
            }

            $window.localStorage.setItem("fbadvertFormat", $scope.fbadvertFormat);
			//$scope.fbadvertFormat = "fbcarosel";
			$scope.isCreateShowandHideOptionWrap1 = false;
			$scope.isPixelTracking =false;
			$scope.isOfflineTracking =false;
			$scope.isDeepLink=false;
            switch ($scope.fbadvertFormat) {
                case "fbsingleimage": // Single image
                    
                    $scope.isCreateShowandHideOptionWrap = true;
                    $scope.isNewsFeedLinkDesc = true;
                    //$scope.isHeadline = true;

                    if ($scope.marketingObjective == "POST_ENGAGEMENT") { //Boost your post
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isLandingview = false;
                        $scope.useExistingPostLink = true;
                        $scope.isDisplayLink = false;
                    }
                    else if ($scope.marketingObjective == "PAGE_LIKES") { //Promote your page
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isHeadlineAdvancedOption = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption = false;
                        $scope.isLandingview = false;
                        $scope.useExistingPostLink = false;

                    }
                    else if ($scope.marketingObjective == "REACH") { //Reach People near your business
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.radioDestination = false;
                        $scope.islocalAwarness = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isSeeMoreURL = false;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isLearnMoreUrl = false;
                        $scope.isUrlParam = false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption = false;
                        $scope.useExistingPostLink = false;
                        $scope.isAddWebsiteUrl = true;
                        $scope.callToDirection = $scope.reachPeople;
                        $scope.isMoreDisplayURLOptional = false;
						$scope.isCreateShowandHideOptionWrap1=true;
                    }
                    else if ($scope.marketingObjective == "BRAND_AWARENESS") { //Increase Brand Awareness
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.callToDirectionValue = "NO_BUTTON";
                        $scope.isCreateHideAdvOption=false;
                        $scope.isUrlParam = false;
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isMoreDisplayURLOptional = false;
                        $scope.isInstagram = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isAddWebsiteUrl = true;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCallToAction1 = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.brandAwareness;
                        $scope.isCreateShowandHideOptionWrap1=true;
                    }
                    else if ($scope.marketingObjective == "LINK_CLICKS") { //Send people to your website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isCallToAction1 = true;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.brandAwareness;
                        $scope.isCallToActionOptional = true;
                        $scope.callToDirectionValue = "LEARN_MORE";
                         $scope.isCarousaltrafficText = false;
                         $scope.isDisplayLink = false;
                         $scope.isCreateHideAdvOption=false;
                         if($scope.radioDestination == null){
                         $scope.radioDestination = 'WEBSITEURL';}
                         if($scope.radioDestination == 'WEBSITEURL')
                         {$scope.isWebURL = true;}
                         $scope.isAdvancedNewsFeedLinkDesc = false;
                         $scope.isUrlParamoptional = false;
                         $scope.isAdvancedDisplayLink = false;
                         
                         
                         
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {  //Get installs of your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = false;
                        $scope.isinstalls = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isDisplayLinkOptional = false;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirection = $scope.canvas_app_installs;
                        $scope.isDeepLink = true;
                        $scope.isCallToActionOptional = true;
                        $scope.callToDirectionValue = "PLAY_GAME";
                        //$scope.ispageasactor = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.radioDestination = 'APPSTORE';
                        
                        }
                    else if ($scope.marketingObjective == "EVENT_RESPONSES") { //Raise attendance at your events
                        $scope.advertPreviewHeading = "Page and Event";
                        $scope.isEvent = true;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirection = $scope.brandAwareness;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isUrlParam = false;
                    }
                    else if ($scope.marketingObjective == "VIDEO_VIEWS") {  //Get videos views
                        $scope.advertPreviewHeading = "";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = true;
                        $scope.isCreateHideAdvOption=false;
                    }
                    else if ($scope.marketingObjective == "LEAD_GENERATION") { //Collect leads for your business
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = true;
                        $scope.isNewsFeedLinkDesc = true;
                        $scope.isDisplayLink = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isUrlParam = false;
                        $scope.isCreateHideAdvOption = false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirection = $scope.leadgeneration;
                    }
                    else if ($scope.marketingObjective == "CONVERSIONS") { //Increase conversions on website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isWebsiteurl = true;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCallToAction1 = true;                        
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.brandAwareness;
                        $scope.isCallToActionOptional = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_ENGAGEMENT") { // //Increase engagements on your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToAction1 = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isDesOptional = false;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = false;

                    }
                    break;
                case "fbsinglevideo": // Single Video
                    $scope.isCreateShowandHideOptionWrap = false;
                    $scope.isNewsFeedLinkDesc = false;
                    //$scope.isHeadline = true;
                    //$scope.isDestination = false;
                    if ($scope.marketingObjective == "POST_ENGAGEMENT") { //Boost your post
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = true;
                        $scope.isDisplayLink = false;
                    }
                    else if ($scope.marketingObjective == "PAGE_LIKES") { //Promote your page
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isCreateShowandHideOptionWrap1 = false;
                        $scope.isCreateShowAdvOption = false;
                        $scope.isCreateHideAdvOption = false;
                        $scope.isLandingview = false;
                        $scope.isHeadlineAdvancedOption = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.marketingObjective == "REACH") { //Reach People near your business
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToActionOptional = false;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isMoreDisplayURLOptional = false;
                        $scope.isLearnMoreUrl = true;
                        $scope.isAddWebsiteUrl = true;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isUrlParam = false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption = false;
                        $scope.useExistingPostLink = false;
                        $scope.isWebURL = false;
                        $scope.isLearnMoreUrl= false;
                        $scope.isCreateShowandHideOptionWrap1=true;
						$scope.isDisplayLinkOptional = false;
                    }
                    else if ($scope.marketingObjective == "BRAND_AWARENESS") { //Increase Brand Awareness
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.callToDirectionValue = "LEARN_MORE";
                        $scope.isEvent = false;
                        $scope.isUrlParam = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isMoreDisplayURLOptional = false;
                        $scope.isHeadline = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isAddWebsiteUrl = true;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.videoBrandAwareness;
                        $scope.isCreateShowandHideOptionWrap1=true;
                    }
                    else if ($scope.marketingObjective == "LINK_CLICKS") { //Send people to your website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.isSeeMoreURL = false;
                        $scope.callToDirectionValue = "LEARN_MORE";
                        $scope.callToDirection = $scope.videoBrandAwareness;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                         $scope.isCarousaltrafficText = false;
                         $scope.isCreateHideAdvOption=false;
                         $scope.isCreateHideAdvOption=false;
                         if($scope.radioDestination == null){
                         $scope.radioDestination = 'WEBSITEURL';} 
                         if($scope.radioDestination == 'WEBSITEURL')
                         {$scope.isWebURL = true;}
                         $scope.isAdvancedNewsFeedLinkDesc = false;
                         $scope.isUrlParamoptional = false;
                         $scope.isAdvancedDisplayLink = false;
                            
                        
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {  //Get installs of your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = false;
                        $scope.isinstalls = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToActionOptional = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirection = $scope.canvas_app_installs;
                        $scope.isDeepLink = true;
                        $scope.callToDirectionValue = "PLAY_GAME";
                        //$scope.ispageasactor = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.radioDestination = 'APPSTORE';
                        if($scope.selectedTarget == "undefined")
                        {$scope.selectedTarget = "";}
                        
                    }
                    else if ($scope.marketingObjective == "EVENT_RESPONSES") { //Raise attendance at your events
                        $scope.advertPreviewHeading = "Page and Event";
                        $scope.isEvent = true;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isUrlParam = false;
                    }
                    else if ($scope.marketingObjective == "VIDEO_VIEWS") {  //Get videos views
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isAddWebsiteUrl = true;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.video_views;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isUrlParam = false;
                    }
                    else if ($scope.marketingObjective == "LEAD_GENERATION") { //Collect leads for your business
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = true;
                        $scope.isDisplayLink = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isUrlParam = false;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.marketingObjective == "CONVERSIONS") { //Increase conversions on website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                        $scope.callToDirection = $scope.videoBrandAwareness;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_ENGAGEMENT") { // //Increase engagements on your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isDesOptional = false;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						 $scope.rightColumn = false;
                    }
                    break;
                case "fbslideshow":  // Slide show
                    $scope.isCreateShowandHideOptionWrap = false;
                    $scope.isNewsFeedLinkDesc = false;
                    //$scope.isHeadline = true;
                    //$scope.isDestination = false;
                    if ($scope.marketingObjective == "POST_ENGAGEMENT") { //Boost your post
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = true;
                    }
                    else if ($scope.marketingObjective == "PAGE_LIKES") { //Promote your page
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadlineAdvancedOption = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						 $scope.isCreateShowandHideOptionWrap1 = false;
						 $scope.isLandingview=false;
						 $scope.isCreateShowAdvOption = false;
						 $scope.isCreateHideAdvOption=false;
						 						
                    }
                    else if ($scope.marketingObjective == "REACH") { //Reach People near your business
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isMoreDisplayURLOptional = false;
                        $scope.isCallToActionOptional = false;
			            $scope.isCallToAction1 =false;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isLearnMoreUrl= false;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isUrlParam = false;
                        $scope.useExistingPostLink = false;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isAddWebsiteUrl=true;
                        $scope.isWebURL=false;
                        $scope.isSeeMoreURL =false;						
                        $scope.rightColumn = false;

                    }
                    else if ($scope.marketingObjective == "BRAND_AWARENESS") { //Increase Brand Awareness
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.callToDirectionValue = "LEARN_MORE";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isUrlParam = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isMoreDisplayURLOptional = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
					    $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
						 $scope.isCreateHideAdvOption=false;
                        $scope.useExistingPostLink = true;
                    }
                    else if ($scope.marketingObjective == "LINK_CLICKS") { //Send people to your website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;                      
						 $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = false;
                        $scope.isSeeMoreURL = false;
                        $scope.isDisplayLink = false;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.callToDirectionValue = "LEARN_MORE";
                        $scope.isCreateShowandHideOptionWrap = true;
                        if($scope.radioDestination == null){
                         $scope.radioDestination = 'WEBSITEURL';
                         }
                         if($scope.radioDestination == 'WEBSITEURL')
                         {$scope.isWebURL = true;}
                         
					   $scope.isCreateShowandHideOptionWrap1 = true;
					   $scope.isCreateHideAdvOption=false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = true;
                         $scope.isCarousaltrafficText = false;
                         $scope.isAdvancedNewsFeedLinkDesc = false;
                         $scope.isUrlParamoptional = false;
                         $scope.isAdvancedDisplayLink = false;
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {  //Get installs of your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = false;
                        $scope.isinstalls = true;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirectionValue = "PLAY_GAME";
                        //$scope.ispageasactor = true;
                        $scope.radioDestination = 'APPSTORE';
						$scope.isPixelTracking =false;
						$scope.isOfflineTracking =false;
						$scope.isDisplayLink = false;
						$scope.isDeepLink=true;
                                                $scope.isCreateHideAdvOption=false;
                    }
                    else if ($scope.marketingObjective == "EVENT_RESPONSES") { //Raise attendance at your events
                        $scope.advertPreviewHeading = "Page and Event";
                        $scope.isEvent = true;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isUrlParam = false;
                        
                    }
                    else if ($scope.marketingObjective == "VIDEO_VIEWS") {  //Get videos views
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;                     
                        $scope.useExistingPostLink = true;
                        $scope.isUrlParam = false;
						 $scope.isCreateShowandHideOptionWrap1 = true;
						 $scope.isLandingview=false;
						 $scope.isCreateShowAdvOption = true;
						 $scope.isCreateHideAdvOption=false;
                                                 $scope.isAddWebsiteUrl = true;
                    }
                    else if ($scope.marketingObjective == "LEAD_GENERATION") { //Collect leads for your business
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = true;
                        $scope.isCreateShowandHideOptionWrap = true;                  
                        $scope.useExistingPostLink = false;
                        $scope.isUrlParam = false;
					    $scope.isCreateShowandHideOptionWrap1 = true;
						 $scope.isLandingview=false;
						 $scope.isCreateShowAdvOption = true;
						 $scope.isCreateHideAdvOption=false;
                    }
                    else if ($scope.marketingObjective == "CONVERSIONS") { //Increase conversions on website
                        $scope.advertPreviewHeading = "Page and  Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;                     
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;                        
                        $scope.useExistingPostLink = true;
						$scope.isCreateShowandHideOptionWrap1 = true;
						$scope.isLandingview=false;
					    $scope.isCreateShowAdvOption = true;
					    $scope.isCreateHideAdvOption=false;
						$scope.isCallToActionOptional = false;
						$scope.isCallToAction = true;
						$scope.isWebsiteurl=true;
						$scope.isHeadline = true;
						$scope.isText =true;
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_ENGAGEMENT") { // //Increase engagements on your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isCreateShowandHideOptionWrap = true;
                        $scope.isDesOptional = false;
                        $scope.useExistingPostLink = false;
						 $scope.isCreateShowandHideOptionWrap1 = true;
						  $scope.isCreateShowAdvOption = true;
						  $scope.isCreateHideAdvOption=false;
                    }
                    else if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						 $scope.rightColumn = false;
                    }
                    break;
                case "fbcarosel": //Carosel				
                    $scope.isNewsFeedLinkDesc = true;
                    $scope.isEvent = false;
				  $scope.isCreateHideAdvOption = false;
				  $scope.isUrlParam=false;

                    if ($scope.marketingObjective == "POST_ENGAGEMENT") { //Boost your post
                        $scope.advertPreviewHeading = "Page & Carousel";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = true;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
						
                    }
                    else if ($scope.marketingObjective == "PAGE_LIKES") { //Promote your page
                        $scope.advertPreviewHeading = "";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "REACH") { //Reach People near your business
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.radioDestination = false;
                        $scope.radioDestination = false;
                        $scope.islocalAwarness = false;
                        $scope.isAddWebsiteUrl = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
						$scope.isSeeMoreURL = true;
						$scope.isMoreDisplayURLOptional = true;
						$scope.isCallToActionOptional = true;	
						$scope.isCallToAction = false;
                                                $scope.isWebsiteurl = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isLearnMoreUrl = false;
						$scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.useExistingPostLink = false;						
						$scope.isUrlParam = false;						
                        $scope.callToDirection = $scope.reachPeople;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						//$scope.rightColumn = false;
						$scope.isWebURL=false;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "BRAND_AWARENESS") { //Increase Brand Awareness
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isUrlParam = false;
                        $scope.isAddWebsiteUrl=false;
                        $scope.isSeeMoreURL = true;
                        $scope.isMoreDisplayURLOptional = true;
                        $scope.isDisplayLink = false;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isWebsiteurl = false;
                        $scope.isHeadline1 = false;
                        $scope.isDisplayLinkOptional = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = true;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "LINK_CLICKS") { //Send people to your website
                        $scope.advertPreviewHeading = "Page and Links";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = true;
                        $scope.islocalAwarness = true;
                        $scope.isHeadline = false;
                        $scope.isText = false;
                        $scope.isCarousaltrafficText = true;
                        $scope.isCallToActionOptional = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.callToDirectionValue = "LEARN_MORE";
                        $scope.useExistingPostLink = true;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isDisplayLink = false;
                        $scope.isDisplayLinkOptional = false;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateHideAdvOption = false;
                        $scope.isAdvancedDisplayLink = false;
                        $scope.isAdvancedNewsFeedLinkDesc = false;
                        $scope.isUrlParamoptional = false;
                        if($scope.radioDestination == null){
                         $scope.radioDestination = 'WEBSITEURL';}
                        if($scope.radioDestination == 'WEBSITEURL'){
                            $scope.isSeeMoreURL = true;
                            $scope.isCallToActionOptional = true;
                            $scope.isWebURL = false;
                            
                        }
                        if($scope.radioDestination == 'MESSENGER'){
                            $scope.isAdvancedDisplayLink = false;
                          }
                        
                        
                        
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {  //Get installs of your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.islocalAwarness = true;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
                        $scope.callToDirectionValue = "PLAY_GAME";
                        //$scope.ispageasactor = true;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isDeepLink = true;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
						
                    }
                    else if ($scope.marketingObjective == "EVENT_RESPONSES") { //Raise attendance at your events
                        $scope.advertPreviewHeading = "";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
                                                $scope.isCreateHideAdvOption = false;
												$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "VIDEO_VIEWS") {  //Get videos views
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = true;

                        $scope.mediaImage = false;
                        $scope.mediaVideo = false;
                        $scope.videoviewsmediaUpdate = true;
                        $scope.mediaarrow = true;
                        $scope.cardarrow = false;
                        $scope.isWebsiteurl = false;
                        $scope.isDisplayLink = false;
                        $scope.isHeadline1 = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isAddWebsiteUrl = false;
                        $scope.imageFormat = "videoviewsmediaUpdate";  

                    }
                    else if ($scope.marketingObjective == "LEAD_GENERATION") { //Collect leads for your business
                        $scope.advertPreviewHeading = "Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCreateShowAdvOption = false;
                        $scope.isDisplayLink = false;
                        $scope.useExistingPostLink = false;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.isCreateShowandHideOptionWrap1 = false;
						$scope.isLandingview=false;
						$scope.isCreateShowAdvOption = false;
						$scope.isCreateHideAdvOption=false;
                    }
                    else if ($scope.marketingObjective == "CONVERSIONS") { //Increase conversions on website
                        $scope.advertPreviewHeading = "Page and Text";
						 $scope.isDestination = true;
						$scope.isDisplayLink = false;
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
						$scope.isText = true;
						$scope.islocalAwarness = false;
                        $scope.isInstagram = false;
						$scope.isWebURL = false;
						$scope.isurlandcanvas = true;
                        $scope.isUrlParam = false;
                        $scope.isAddWebsiteUrl=false;
                        $scope.isSeeMoreURL = true;
                        $scope.isMoreDisplayURLOptional = false;
                        //$scope.isDisplayLink = false;
                        $scope.isCreateShowandHideOptionWrap1 = true;
                        $scope.isCreateShowAdvOption = true;
                        $scope.isCreateHideAdvOption=false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isWebsiteurl = false;
                        $scope.isHeadline1 = false;
                        $scope.isDisplayLinkOptional = false;
                        $scope.isHeadline = false;
                        
                        $scope.isCallToAction = false;
                        $scope.isCallToActionOptional = true;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = true;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;	
						
                    }
                    else if ($scope.marketingObjective == "CANVAS_APP_ENGAGEMENT") { // //Increase engagements on your app
                        $scope.advertPreviewHeading = "Page and Text";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = true;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = true;
                        $scope.isText = true;
                        $scope.isCallToAction = true;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isDesOptional = true;
                        $scope.useExistingPostLink = false;
						$scope.mediaImage = true;
						$scope.mediaVideo = true;
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
                    }
                    else if ($scope.marketingObjective == "OFFER_CLAIMS") { ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = false;												
						$scope.iscardDescription = true;
						$scope.iscardwebURL = true;
						$scope.iscarddisplayLink = true;
						
						$scope.mediaImage = false;
                        $scope.mediaVideo = false;
                        $scope.offersmediaUpdate = true;
                        $scope.mediaarrow = true;
                        $scope.cardarrow = false;
                        $scope.isWebsiteurl = false;
                        $scope.isDisplayLink = false;
                        $scope.isHeadline1 = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isAddWebsiteUrl = false;
                        $scope.imageFormat = "offersmediaUpdate";
                    }
                    break;
            }

        }
        $scope.createShowAdvancedOption = function () {
            $scope.isCreateHideAdvOption = true;
            $scope.isCreateShowAdvOption = false;
             $scope.isOfflineTracking = false;
			$scope.isPixelTracking = false;
            switch ($scope.marketingObjective) {
				
                case "PAGE_LIKES":
                    $scope.isHeadline1 = false;
                    $scope.isHeadlineAdvancedOption = true;
                    $scope.isLandingview = true;
                    $scope.useExistingPostLink = false;
					if($scope.fbadvertFormat == "fbslideshow") {
                        $scope.isUrlParam = false;
                        $scope.useExistingPostLink = false;
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isLandingview =false;
						$scope.isHeadline=false;
                    }
                    break;
                case "REACH":
                    if ($scope.fbadvertFormat == "fbsingleimage") {
                        $scope.isUrlParam = true;
                        $scope.isNewsFeedLinkDesc = true;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.fbadvertFormat == "fbsinglevideo") {
                        $scope.isUrlParam = true;
                        $scope.useExistingPostLink = false;
                    }
                    else if ($scope.fbadvertFormat == "fbslideshow") {
                        $scope.isUrlParam = true;
                        $scope.useExistingPostLink = false;
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isWebURL=false;
						$scope.isSeeMoreURL =false;
						
                    }
                    else if ($scope.fbadvertFormat == "fbcarosel") {
                        $scope.isUrlParam = true;                        
						$scope.isPixelTracking = false;
                    }
                    break;
                case "BRAND_AWARENESS":
                    $scope.isUrlParam = true;
                    $scope.useExistingPostLink = true;
			      if($scope.fbadvertFormat == "fbslideshow") {                    
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isLandingview =false;						
                    }
                    break;
                case "LINK_CLICKS":
                    $scope.isAdvancedNewsFeedLinkDesc = true;
                    $scope.isUrlParam = true;
                    $scope.isDisplayLink = true;
                    $scope.useExistingPostLink = true;
                    
               
                    if($scope.fbadvertFormat == "fbcarosel")
                    {   $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedNewsFeedLinkDesc = false;
                         $scope.isDisplayLink = false;
                         if($scope.radioDestination == 'WEBSITEURL')
                         $scope.isAdvancedDisplayLink = true;
                         
                         
                    }
                    else $scope.isAdvancedDisplayLink = false;
                    if($scope.fbadvertFormat == "fbsingleimage" && $scope.radioDestination == 'WEBSITEURL'){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedDisplayLink = true;
                    }
                    if($scope.fbadvertFormat == "fbsingleimage" && $scope.radioDestination == 'MESSENGER'){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedDisplayLink = false;
                        
                    }
                    if($scope.fbadvertFormat == "fbsinglevideo" && $scope.radioDestination == 'WEBSITEURL'){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedDisplayLink = true;
                    }
                    if($scope.fbadvertFormat == "fbsinglevideo" && $scope.radioDestination == 'MESSENGER'){
                        
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedDisplayLink = false;
                        
                    }
                    if($scope.fbadvertFormat == "fbslideshow" && $scope.radioDestination == 'WEBSITEURL'){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isAdvancedDisplayLink = true;
                        $scope.isCallToAction = true;
                        $scope.isCallToActionOptional = false;
                        $scope.isDisplayLink = false;
                    }
                    if($scope.fbadvertFormat == "fbslideshow" && $scope.radioDestination == 'MESSENGER'){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = true;
                        $scope.isCallToAction = true;
                        $scope.isCallToActionOptional = false;
                        $scope.isAdvancedDisplayLink = false;
                        $scope.isDisplayLink = false;
                        
                    }
                    
                    if($scope.fbadvertFormat == "fbsinglevideo")
                    {   
                        $scope.isDisplayLink = true;
                    }
                    
                    if ($scope.radioDestination != '' && $scope.radioDestination != undefined) {
                        $scope.selectMessenger($scope.radioDestination);
                    }
					
                    break;
                case "EVENT_RESPONSES":
                    $scope.isUrlParam = true;
                    $scope.useExistingPostLink = false;
                    break;
                case "LEAD_GENERATION":
                    if($scope.fbadvertFormat == "fbcarosel"){
                        $scope.isUrlParam = false;
                    }else{
                        $scope.isUrlParam = true;
                    }
                    $scope.useExistingPostLink = false;
					if($scope.fbadvertFormat == "fbslideshow") {
						//$scope.isOfflineTracking = true;
						//$scope.isPixelTracking = true;
                    }
                    break;
                case "CONVERSIONS":
                    $scope.isNewsFeedLinkDesc = true
                    $scope.isUrlParam = true;
                    //$scope.isDisplayLink = true;
                    $scope.useExistingPostLink = true;
					if($scope.fbadvertFormat == "fbslideshow") {
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;	
						$scope.isHeadline=true;
                    }
					if($scope.fbadvertFormat == "fbcarosel") {							
						$scope.isDisplayLink = false;
					    $scope.isNewsFeedLinkDesc = false;
						$scope.isAdvancedDisplayLink = true;
						
                    }
                    break;
                case "CANVAS_APP_ENGAGEMENT":
                    $scope.isUrlParam = true;
                    $scope.isDisplayLink = false;
                    $scope.useExistingPostLink = false;
					if($scope.fbadvertFormat == "fbslideshow") {                      
						//$scope.isOfflineTracking = true;
						//$scope.isPixelTracking = true;
						$scope.isDeepLink =true;
						$scope.isHeadline=true;
                    }
                    break;
                case "VIDEO_VIEWS":
                    $scope.isUrlParam = true;
                    $scope.useExistingPostLink = true;
					if($scope.fbadvertFormat == "fbslideshow") {
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;						
                    }
                    break;
            }



        }
        $scope.createHideAdvancedOption = function () {
            $scope.isCreateHideAdvOption = false;
            $scope.isCreateShowAdvOption = true;

            switch ($scope.marketingObjective) {
                case "PAGE_LIKES":
                    $scope.isHeadline1 = false;
                    $scope.isLandingview = false;
                    $scope.isHeadlineAdvancedOption = false;
					$scope.isOfflineTracking = false;
				    $scope.isPixelTracking = false;
                    break;
                case "REACH":
                    $scope.isUrlParam = false;
                    $scope.isNewsFeedLinkDesc = false;
					$scope.isOfflineTracking = false;
				    $scope.isPixelTracking = false;
					$scope.isWebURL=false;

//				    $scope.isSeeMoreURL =true;
				  if ($scope.fbadvertFormat == "fbslideshow") {
                        $scope.isUrlParam = false;
                        $scope.useExistingPostLink = false;
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isWebURL=false;
						$scope.isSeeMoreURL =false;
						
                    }
					
                    break;
                case "BRAND_AWARENESS":
                    $scope.isUrlParam = false;
					$scope.isOfflineTracking = false;
				    $scope.isPixelTracking = false;
                    break;
                case "LINK_CLICKS":
                    $scope.isAdvancedNewsFeedLinkDesc = false;
                    $scope.isUrlParam = false;
                    $scope.isDisplayLink = false;
                    if ($scope.radioDestination != '' && $scope.radioDestination != undefined) {
                        $scope.selectMessenger($scope.radioDestination);
                    }
                    if($scope.fbadvertFormat == "fbcarosel"){
                        $scope.isUrlParam = false;
                        $scope.isUrlParamoptional = false;
                        $scope.isDisplayLink = false;
                        $scope.isAdvancedDisplayLink = false;
                        
                    }
                    if($scope.fbadvertFormat == "fbsingleimage" ){
                        $scope.isAdvancedDisplayLink = false;
                        $scope.isUrlParamoptional = false;
                    }
                    if($scope.fbadvertFormat == "fbsinglevideo" ){
                        $scope.isAdvancedDisplayLink = false;
                        $scope.isUrlParamoptional = false;
                    }
                    if($scope.fbadvertFormat == "fbslideshow" ){
                        $scope.isAdvancedDisplayLink = false;
                        $scope.isUrlParamoptional = false;
                    }
                    if($scope.fbadvertFormat == "fbsinglevideo"){
                        $scope.isDisplayLink = false;
                        
                    }
					if($scope.fbadvertFormat == "fbslideshow") {
						$scope.isUrlParam = false;
						$scope.useExistingPostLink = false;
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isLandingview =false;
						$scope.isDisplayLink = false;						
                    }
					
                    break;
                case "EVENT_RESPONSES":
                    $scope.isUrlParam = false;
                    break;
                case "LEAD_GENERATION":
                    $scope.isUrlParam = false;
					if($scope.fbadvertFormat == "fbslideshow") {                      
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
                    }
                    break;
                case "CONVERSIONS":
                    $scope.isNewsFeedLinkDesc = false
                    $scope.isUrlParam = false;
                    $scope.isDisplayLink = false;
					  
                    $scope.useExistingPostLink = false;
					if($scope.fbadvertFormat == "fbslideshow") {							
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;							
						$scope.isHeadline=false;
                    }
					if($scope.fbadvertFormat == "fbcarosel") {							
						
						$scope.isAdvancedDisplayLink = false;
						
                    }
                                       
                    break;
                case "CANVAS_APP_ENGAGEMENT":
                    $scope.isUrlParam = false;
                    $scope.isDisplayLink = false;
					if($scope.fbadvertFormat == "fbslideshow") {                      
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;
						$scope.isDeepLink =false;
						$scope.isHeadline=false;
                    }
                    break;
                case "VIDEO_VIEWS":
                    $scope.isUrlParam = false;
					if($scope.fbadvertFormat == "fbslideshow") {
						$scope.isOfflineTracking = false;
						$scope.isPixelTracking = false;						
                    }
                    break;
            }


        }
        $scope.exitPostShowAdvanceOption = function () {
            $scope.existURLParam = true;
            $scope.exitShowAdvOption = false;
            $scope.exitHideAdvOption = true;
        }
        $scope.exitPostHideAdvanceOption = function () {
            $scope.existURLParam = false;
            $scope.exitShowAdvOption = true;
            $scope.exitHideAdvOption = false;
        }
        $scope.checkAddWebsiteUrl = function () {
            $window.localStorage.setItem("valAddWebsiteUrl", $scope.valAddWebsiteUrl);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/

			
            if ($scope.valAddWebsiteUrl) {
                switch ($scope.marketingObjective) {
                    case "BRAND_AWARENESS": //Increase Brand Awareness
                        if($scope.fbadvertFormat != "fbcarosel")
                        {
                            $scope.isWebsiteurl = true;
                            $scope.isDisplayLinkOptional = true;
                            $scope.isHeadline1 = true;
                            $scope.isNewsFeedLinkDesc = true;
                            $scope.isCallToActionOptional = true;
                        }
                        break;
                    case "VIDEO_VIEWS":
                        $scope.isWebsiteurl = true;
                        $scope.isDisplayLink = true;
                        $scope.isHeadline1 = true;
                        $scope.isNewsFeedLinkDesc = true;
                        $scope.isCallToAction1 = true;
                        $scope.isCallToAction=false;

                        if($scope.fbadvertFormat == "fbcarosel"){
                        $scope.isWebsiteurl = false;
                        $scope.isDisplayLink = false;
                        $scope.isHeadline1 = false;
                        $scope.isNewsFeedLinkDesc = false;
                    }
                        
                        
                        if($scope.fbadvertFormat == "fbsinglevideo" || $scope.fbadvertFormat == "fbslideshow"){
                            $scope.isCallToAction = true;
                        }
                        break;
                    case "REACH":
                        if($scope.fbadvertFormat != "fbcarosel")
                        {
                            if($scope.fbadvertFormat == "fbsinglevideo" || $scope.fbadvertFormat == "fbslideshow")
                            {
                                $scope.isDisplayLinkOptional = false;
                                $scope.isDisplayLink = true;
                                $scope.isCallToAction = true;
                                $scope.isCallToActionOptional = false;
                            }
                            else if($scope.fbadvertFormat == "fbsingleimage")
                            {
                                $scope.isDisplayLink = false;
                                $scope.isDisplayLinkOptional = true;
                                $scope.isCallToAction = false;
                                $scope.isCallToActionOptional = true;
                            }
                            $scope.isWebsiteurl = true;
                            $scope.isHeadline1 = true;
                            $scope.isNewsFeedLinkDesc = true;
                            $scope.isCallToAction1 = false;
                            $scope.isHeadline = false;
                            $scope.isDestination = false;
                            $scope.isWebURL = false;
                        }
                        else
                        {
                            $scope.isHeadline1 = false;
                            $scope.isDisplayLink = false;
                            $scope.isDisplayLinkOptional = false;
                        }
                        break;
                }

            }
            else {
                switch ($scope.marketingObjective) {
                    case "BRAND_AWARENESS": //Increase Brand Awareness
                        if($scope.fbadvertFormat != "fbcarosel")
                        {
                            $scope.isCallToActionOptional = false;
                            $scope.isWebsiteurl = false;
                            $scope.isCallToAction = false;
                            $scope.isDisplayLinkOptional = false;
                            $scope.isHeadline1 = false;
                            $scope.isNewsFeedLinkDesc = false;
                        }
                        break;
                    case "VIDEO_VIEWS":
                        $scope.isWebsiteurl = false;
                        $scope.isDisplayLink = false;
                        $scope.isHeadline1 = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isCallToAction1 = false;
                        if($scope.fbadvertFormat == "fbsinglevideo" || $scope.fbadvertFormat == "fbslideshow"){
                            $scope.isCallToAction = false;
                        }
                        break;
                    case "REACH":
                        if($scope.fbadvertFormat != "fbcarosel")
                        {
                            if($scope.fbadvertFormat == "fbsinglevideo" || $scope.fbadvertFormat == "fbslideshow")
                            {
                                $scope.isDisplayLink = false;
                                $scope.isDisplayLinkOptional = false;
                            }
                            else if($scope.fbadvertFormat == "fbsingleimage")
                            {
                                $scope.isDisplayLinkOptional = false;
                            }
                            $scope.isWebsiteurl = false;
                            $scope.isHeadline1 = false;
                            $scope.isCallToActionOptional = false;
                            $scope.isNewsFeedLinkDesc = false;
                            $scope.isCallToAction1 = false;
                            $scope.isCallToAction = false;
                        }
                        break;
                }
            }

        }
        $scope.previewSection = function () {
            switch ($scope.marketingObjective) {
                case "POST_ENGAGEMENT": //Boost your post
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = false;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "PAGE_LIKES": //Promote your page
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = false;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "REACH": //Reach People near your business
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "BRAND_AWARENESS": //Increase Brand Awareness
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "LINK_CLICKS": //Send people to your website
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "CANVAS_APP_INSTALLS": //Get installs of your app
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "EVENT_RESPONSES": //Raise attendance at your events
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = false;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "VIDEO_VIEWS": //Get videos views
                    $scope.fbadvertFormat = "fbsinglevideo";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = false;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "LEAD_GENERATION": //Collect leads for your business
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "CONVERSIONS": //Increase conversions on website
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "CANVAS_APP_ENGAGEMENT": //Increase engagements on your app
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;
                case "OFFER_CLAIMS": //Get people to claim your offer
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;

            }
        }



        $scope.changeAdvertFormat = function () {
            // alert($scope.fbadvertFormat);
            //console.log($scope.fbadvertFormat);
        }
        $scope.init();		
        $scope.getBrowseLibraryImagekey = function (data) {
            $scope.imagesSource = data.imageSources;
            console.log($scope.imagesSource);
            if ($scope.imagesSource === undefined) {
                console.log('Choose one from library');
                return true;
            }
            /*var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
             if (isCreativeAdCreativeId) {
             $scope.deleteAdCreative();
             }else{*/
            $scope.creativeAdCreative($scope.imagesSource);
            //}

            angular.element($('body').css("overflow-y", "scroll"));
            $scope.browselibrary = "none";
        }


		
	$scope.$watchCollection(function () {
        if ($scope.frmCreateNewAdvert)
            return $scope.frmCreateNewAdvert;
    }, function () {
       if ($scope.frmCreateNewAdvert)
       if (($scope.frmCreateNewAdvert.$invalid == true))
             $scope.inputTypeFile = false;	
        else
             $scope.inputTypeFile = true;	
    }, true);

	
	    $scope.inputTypeFile = false;
		/*$scope.getInputType = function (){
	
		if (!$scope.frmCreateNewAdvert.$valid) { 
                  $scope.inputTypeFile = false;		
                  return;
            }
			    $scope.inputTypeFile = true;
			
    
			
        
        } */
		
        $scope.getCampaignfiles = function (element) {
		
		  
            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
                window.scrollTo(0, document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));
				//angular.element($('.accordianRole').prop('disabled', true));
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            }
            else {
			      $rootScope.progressLoader = 'block';
                document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
                $scope.errTextMsg = "none";
                angular.element($('.btnCampaignCreative').prop('disabled', false));
				//angular.element($('.accordianRole').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                                $scope.step2_green=true;
                $scope.$apply(function ($scope) {
                    $scope.uploadedfilename = element.files[0];
                });
                //console.log(element.files[0]);
                var reader = new FileReader();
                reader.onload = function () {
                    $scope.dataURL = reader.result;
                };
                $timeout(function () {
                    //console.log($scope.dataURL);				
				
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
			parameters.append('type','IMAGE');
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('imageFile',element.files[0]);

			if (typeof (element.files[0]) == "object") {
                            $http({													
                                method: 'POST',
                                url: apiTPBase + '/createadimage',
                                data: parameters,
                                                    transformRequest: angular.identity,
                                headers: {
                                                        'Content-Type': undefined,
                                                        'dataType': 'jsonp',
                                                        'async': 'false'
                                                        }

                            }).then(function (response) {
                                console.log(response);
                                                        $rootScope.progressLoader = 'none';
                                if (response.status == "200" && response.data.appStatus == 0) {
                                    $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                                    $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
                                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
                                    //if (isCreativeAdCreativeId) {
                                      //  $scope.deleteAdCreative($scope.hashVal);

                                   // }
                                    $scope.creativeAdCreative($scope.hashVal);
                                }
                                else {
                                    console.log('failed $scope.getCampaignfiles');
                                                                $scope.showErrorPopup(response.data);
                                    // Flash.create('danger', response.errorMessage, 'large-text');
                                }															
                            });
					
			}
																			
                }, 1000);
                
                
                reader.readAsDataURL(element.files[0]);
            }//else
				
        };
		
        $scope.browseExistingVideos = function (element) {

            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
            
            $http({
                method: 'GET',               
                url: apiTPBase + '/getadvideos?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                console.log(response);
                
                
                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    $scope.mainLoader = "none";	
                    $scope.existVideosList = response.data.data;
				
                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
                    $scope.existVideosList = arrAdAccountCreativeallDataVideo;
					
		}       
                        
                $rootScope.progressLoader = "none";
                $scope.browselibraryvideos = "block";
                //$scope.existVideosList = response.data.adVideos;
            });
        };
        $scope.getBrowseLibraryVideoID = function (data) {
            $scope.videoID = data.videoSources;
            $scope.hashVal = data.videoSources;
            if ($scope.videoID === undefined) {
                console.log('Choose one from library');
                return true;
            }
            
            $scope.creativeAdCreative($scope.videoID);
            $scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
        }
        $scope.getCampaignVideoFiles = function (element) {
            $rootScope.progressLoader = 'block';
            
            /*$scope.$apply(function ($scope) {
                $scope.uploadedfilename = element.files[0];
            });*/
            var parameters = new FormData();
            parameters.append('userId',$window.localStorage.getItem("userId"));
            parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
            parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
            parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
            parameters.append('source',element.files[0]);

            if (typeof (element.files[0]) == "object") {                

                $http({
                    method: 'POST',
                    url: apiTPBase + '/createadvideo',
                    data: parameters,
                    transformRequest: angular.identity,
                    headers: {
                            'Content-Type': undefined,
                            'dataType': 'jsonp',
                            'async': 'false'
                    }
                }).then(function (response) {
                    //console.log(response);					
                    if (response.data.appStatus == '0') {
                        $scope.newvideoID = response.data.adVideoId;
                        $scope.callGetadvideos($scope.newvideoID);
                    } else {
                        console.log("failed $scope.getCampaignVideoFiles");
			$scope.showErrorPopup(response.data);
                    }
                });



            }
        };
        
        $scope.callGetadvideos = function(newvideoID){
            
            var modalErr = $(".video_error_popup");
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID ;
                $scope.mainLoader = "block";
                $http({
                    method: 'GET',
                    url: apiTPBase + '/getadvideos?' + queryStr,
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
                                    $scope.pictureFormat = adVideoID.format;
                                    $scope.videoStatus = adVideoID.status;
                                    angular.forEach( $scope.pictureFormat,function(ulrVal){
                                        if(ulrVal.filter == "native"){
                                            $scope.imageURLValue = ulrVal.picture;
                                            //$scope.videoSource = adVideoID.source;
                                        }
                                    });
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';
                        $scope.checkCreatedVideoStatus(newvideoID);
                    } 
                });
            
            },0);

        }
        
        $scope.checkCreatedVideoStatus = function(newvideoID){
            $scope.newvideoID = newvideoID;
            if($scope.videoStatus){
                if($scope.videoStatus.video_status == "ready"){
                    console.log($scope.newvideoID+"|"+$scope.imageURLValue);
                    $scope.creativeAdCreative($scope.newvideoID+"|"+$scope.imageURLValue);
                }else if($scope.videoStatus.video_status == "error"){
                    $scope.popupTitle = 'Error';
                    $scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup");
                    modalErr.show();
                }else{
                    $scope.popupTitle = 'Video Status Error';
                    $scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup");
                    modalErr.show();
                    //$scope.callGetadvideos(newvideoID);
                }			
            }			
        }

        $scope.selectPromotable = function (pageId, _name) {
            $scope.campaignAudienceCampaignTargetLoader = false;
            $scope.selectedTarget = pageId;
            $scope.selectedTargetName = _name;
            if($scope.selectedTarget!=null && $scope.selectedTarget!="" && $scope.selectedTarget!=undefined)
            {
                angular.element('#selectTargetObjective').removeClass("mandatory");
            }else
            {
                angular.element('#selectTargetObjective').addClass("mandatory");
            }
            $window.localStorage.setItem("selectedTarget", $scope.selectedTarget);

            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please re-select image/video");
            if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES")
            {
                $scope.campaignAudienceLandingViewLoader = true;
//                console.log($scope.selectedTarget);
//                console.log($scope.connectFBVal);
                $scope.getPageTabs(pageId);
            }
            $scope.getExistingPost(pageId);
        }
        $scope.getDisplayLink = function (displayLink) {
            $scope.displayLink = displayLink;
            if($scope.displayLink!=null && $scope.displayLink!="" && $scope.displayLink!=undefined)
            {
                angular.element('#errdisplayLink').removeClass("mandatory");
            }else
            {
                angular.element('#errdisplayLink').addClass("mandatory");
            }
            $window.localStorage.setItem("displayLink", $scope.displayLink);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
		$scope.getDisplayURLoptional = function (displayURLoptional) {
            $scope.displayURLoptional = displayURLoptional;
            $window.localStorage.setItem("displayURLoptional", $scope.displayURLoptional);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
		$scope.getMoreURL = function (seeMoreUrl) {
            $scope.seeMoreUrl = seeMoreUrl;
            if($scope.seeMoreUrl!=null && $scope.seeMoreUrl!="" && $scope.seeMoreUrl!=undefined)
            {
                angular.element('#seeMoreUrl').removeClass("required");
            }else
            {
                angular.element('#seeMoreUrl').addClass("required");
            }
            $window.localStorage.setItem("seeMoreUrl", $scope.seeMoreUrl);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
        $scope.getwebURL = function (webURL) {
            $scope.webURL = webURL;
            if($scope.webURL!=null && $scope.webURL!="" && $scope.webURL!=undefined)
            {
                angular.element('#websiteURL').removeClass("mandatory");
            }else
            {
                angular.element('#websiteURL').addClass("mandatory");
            }
            $window.localStorage.setItem("webURL", $scope.webURL);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        }
		
		$scope.getWebURLVal = function(){
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
                        if($window.localStorage.getItem("campaignState") != "edit")
                        {
                            $scope.newsfeedlinkdesc = "";
                            $scope.webURL = "";
                            $scope.displayLink = "";
                            $scope.campaignHeadline = "";
                        }
			//$scope.callToDirectionValue = 0;
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
		}
                $scope.sendcampaignURLParameter = function(campaignURLParameter){
                    $scope.campaignURLParameter = campaignURLParameter;
                }
        $scope.creativeAdCreative = function (imageHashVal) {
            $rootScope.progressLoader = "block";
            //console.log(imageHashVal);
            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
            if (isCreativeAdCreativeId) {
                $scope.deleteAdCreative();
                $window.localStorage.removeItem("adCreativeId");
                if ($window.localStorage.removeItem("deleteAdCreativeStatus")) { //alert("dfdsf")
                    $scope.networkErrorPopup = 'block';
                    return;
                }
            }
            
                        
            $scope.objid = imageHashVal.split('|')[0];
            $scope.objurl = imageHashVal.split('|')[1];
            //console.log($scope.objurl);
            $window.localStorage.setItem("campaignMediaURL", $scope.objurl);

			
            //$scope.campaignHeadline1 = "";
            $window.localStorage.setItem("newsfeedlinkdesc", $scope.newsfeedlinkdesc);
            $window.localStorage.setItem("valAddWebsiteUrl", $scope.valAddWebsiteUrl);
            $window.localStorage.setItem("displayLink", $scope.displayLink);
            $window.localStorage.setItem("selectLeadForm", $scope.selectLeadForm);
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            //$window.localStorage.setItem("campaignHeadline", $scope.campaignHeadline);
            

            $scope.pageIdVal = $scope.selectedTarget;
            //console.log($scope.marketingObjective);
            console.log($scope.fbadvertFormat);
            if ($scope.fbadvertFormat == 'fbcarosel') {
                $scope.objectType = 'PHOTO';
                $window.localStorage.setItem("campaignMediaFormat", "Carosel");
				
						$scope.objectType = "SHARE";
                   
				
            } else if ($scope.fbadvertFormat == 'fbsingleimage') {

                if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {
                    $scope.audiTarget = $window.localStorage.getItem("campaignAudienceTarget");
                    $scope.objectType = "SHARE";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "link": "https://apps.facebook.com/" + $scope.audiTarget,
                            "message": $scope.textBodyContent,
                            "image_hash": $scope.objid,
                            "call_to_action": {
                                "type": $scope.callToDirectionValue, //"USE_APP",
                                "value": {
                                    "application": $scope.audiTarget,
                                    "link": "https://apps.facebook.com/" + $scope.audiTarget,
                                    "link_title": $scope.campaignHeadline1
                                }
                            }
                        }
                    }
                } else if ($scope.marketingObjective == "EVENT_RESPONSES") {
                    $scope.objectType = "SHARE";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "link": "https://www.facebook.com/events/" + $window.localStorage.getItem("campaignAudienceTarget"),
                            "message": $scope.textBodyContent,
                            "image_hash": $scope.objid,
                            "call_to_action": {
                                "type": "EVENT_RSVP" //$scope.callToDirectionValue
                            },
                            "event_id": $window.localStorage.getItem("campaignAudienceTarget")
                        }
                    }

                } else if ($scope.marketingObjective == "LINK_CLICKS") {
                    $scope.objectType = "SHARE";
                    //MESSENGER
                    if ($scope.callToDirectionValue == null || $scope.callToDirectionValue == undefined || $scope.callToDirectionValue == '0' || $scope.callToDirectionValue == ""){    
                    if ($scope.radioDestination == 'MESSENGER') {
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "link_data": {
                                "link": "https://fb.com/messenger_doc/",
                                "message": $scope.textBodyContent,
                                "name": $scope.campaignHeadline1, //"ADVIMEDIA SARL",
                                "description": $scope.newsfeedlinkdesc,
                                "image_hash": $scope.objid,
                                "call_to_action": {
                                    
                                    "value": {
                                        "app_destination": $scope.radioDestination
                                    }
                                },
                                "page_welcome_message": $scope.messengertextBodyContent
                            }
                        }
                    } else {
                        //WEBSITE LINK
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "link_data": {
                                "link": $scope.campaignWebURL, //"http://www.advimedia.com/",
                                "message": $scope.textBodyContent,
                                "name": $scope.campaignHeadline1, //"ADVIMEDIA SARL",
                                "caption": $scope.displayLink,
                                "description": $scope.newsfeedlinkdesc,
                                "image_hash": $scope.objid,
                                
                            }
                        }
                    }
                }
                else{
                    if ($scope.radioDestination == 'MESSENGER') {
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "link_data": {
                                "link": "https://fb.com/messenger_doc/",
                                "message": $scope.textBodyContent,
                                "name": $scope.campaignHeadline1, //"ADVIMEDIA SARL",
                                "description": $scope.newsfeedlinkdesc,
                                "image_hash": $scope.objid,
                                "call_to_action": {
                                    "type": $scope.callToDirectionValue,
                                    "value": {
                                        "app_destination": $scope.radioDestination
                                    }
                                },
                                "page_welcome_message": $scope.messengertextBodyContent
                            }
                        }
                    } else {
                        //WEBSITE LINK
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "link_data": {
                                "link": $scope.campaignWebURL, //"http://www.advimedia.com/",
                                "message": $scope.textBodyContent,
                                "name": $scope.campaignHeadline1, //"ADVIMEDIA SARL",
                                "caption": $scope.displayLink,
                                "description": $scope.newsfeedlinkdesc,
                                "image_hash": $scope.objid,
                                "call_to_action": {
                                    "type": $scope.callToDirectionValue //"LEARN_MORE"
                                }
                            }
                        }
                    }
                }


                } else if ($scope.marketingObjective == "BRAND_AWARENESS") {

                    if ($scope.valAddWebsiteUrl == true) {
                        //WEBSITE LINK
                        if ($scope.callToDirectionValue == null || $scope.callToDirectionValue == undefined || $scope.callToDirectionValue == '0' || $scope.callToDirectionValue == "") {
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "link_data": {
                                    "link": $scope.webURL, //"http://www.advimedia.com/",
                                    "message": $scope.textBodyContent,
                                    "name": $scope.campaignHeadline, //"ADVIMEDIA SARL",
                                    "caption": $scope.displayLink,
                                    "description": $scope.newsfeedlinkdesc,
                                    "image_hash": $scope.objid
                                }
                            }
                        }
                        else {
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "link_data": {
                                    "link": $scope.webURL, //"http://www.advimedia.com/",
                                    "message": $scope.textBodyContent,
                                    "name": $scope.campaignHeadline, //"ADVIMEDIA SARL",
                                    "caption": $scope.displayLink,
                                    "description": $scope.newsfeedlinkdesc,
                                    "image_hash": $scope.objid,
                                    "call_to_action": {
                                        "type": $scope.callToDirectionValue //"LEARN_MORE"
                                    }
                                }
                            }
                        }

                        $scope.objectType = "SHARE";

                    } else {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "photo_data": {
                                "caption": $scope.textBodyContent,
                                "image_hash": $scope.objid,
                            }
                        }
                        $scope.objectType = "PHOTO";
                    }


                } else if ($scope.marketingObjective == "REACH") {
                    $scope.objectType = "SHARE";
                    if ($scope.valAddWebsiteUrl) {
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "link_data": {
                                "link": $scope.webURL,
                                "message": $scope.textBodyContent,
                                "description":$scope.newsfeedlinkdesc,
                                "name": $scope.campaignHeadline,//"ADVIMEDIA SARL",
                                "image_hash": $scope.objid,
                            }
                        }
                        if($scope.callToDirectionValue != "" && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != null)
                        {
                            var calltoaction = {
                                "call_to_action": {
                                    "type":$scope.callToDirectionValue
                                }
                            };
                            $scope.objectStorySpec.link_data = angular.extend({},$scope.objectStorySpec.link_data,calltoaction);
                        }
//                        console.log(JSON.stringify($scope.objectStorySpec,null,2));
                        if($scope.displayLink != "" && $scope.displayLink != undefined && $scope.displayLink != null)
                        {
//                            angular.extend({},parameters,urlparams);
                            var displink = {
                                "caption": $scope.displayLink
                            };
                            $scope.objectStorySpec.link_data = angular.extend({},$scope.objectStorySpec.link_data,displink);
                        }
//                        console.log(JSON.stringify($scope.objectStorySpec,null,2));
//                        console.log($scope.objectStorySpec);
                    } else {
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,                          
                            "photo_data": {
                                "caption": $scope.textBodyContent,
                                "image_hash": $scope.objid,
                            }
                        };
                    }
                }else if ($scope.marketingObjective == "LEAD_GENERATION") {
                    $scope.objectType = 'SHARE';
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "name": $scope.campaignHeadline1,
                            "message": $scope.textBodyContent,
                            "description": $scope.newsfeedlinkdesc,
                            "caption": $scope.displayLink,                            
                            "link": "http://fb.me/",
                            "image_hash": $scope.objid,
                            "call_to_action": {
                                "type": $scope.callToDirectionValue,
                                "value": {
                                    "lead_gen_form_id": $scope.selectLeadForm
                                }
                            }
                        }
                    }
                }else if ($scope.marketingObjective == "OFFER_CLAIMS") {
                    $scope.objectType = 'SHARE';
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "link" : $window.localStorage.getItem("OfferRedemptionLink"),
                            "message": $scope.textBodyContent,
                            "image_hash": $scope.objid,
                            "offer_id": $scope.campaignAudienceCampaignOffer,
                            "call_to_action":
                            {
                                "type": "GET_OFFER_VIEW"
                            }
                        }
                    }
                }else if ($scope.marketingObjective == "CONVERSIONS") {
                    $scope.objectType = 'SHARE';
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "link": $scope.webURL,
                            "message": $scope.textBodyContent,
                            "name": $scope.campaignHeadline1,
                            "caption": $scope.displayLink,
                            "attachment_style": "link",
                            "description": $scope.newsfeedlinkdesc,
                            "image_hash": $scope.objid,
                            "call_to_action": {
                                "type": $scope.callToDirectionValue
                            }
                        }
                    }
                }else if ($scope.marketingObjective == "PAGE_LIKES") {
                    $scope.objectType = 'PAGE';
                    
                } else {
                    $scope.objectType = 'PHOTO';
                    $scope.objectStorySpec = {
                        "page_id": $scope.selectedTarget,
                        "photo_data": {
                            "caption": $scope.textBodyContent,
                            "image_hash": $scope.objid
                        }
                    }

                }

                $window.localStorage.setItem("campaignMediaFormat", "Single Image");
            } 
            else if ($scope.fbadvertFormat == 'fbsinglevideo') {

                if ($scope.marketingObjective == "EVENT_RESPONSES") {
                    //console.log('event here');
                    $scope.objectType = "VIDEO";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "description": $scope.textBodyContent,
                            "call_to_action": {
                                "type": "EVENT_RSVP",
                                "value": {
                                    "link": "https://www.facebook.com/events/" + $window.localStorage.getItem("campaignAudienceTarget"),
                                    "event_id": $window.localStorage.getItem("campaignAudienceTarget")
                                }
                            },
                            "image_url": $scope.objurl
                        }
                    }


                }
                else if ($scope.marketingObjective == "BRAND_AWARENESS") {

                    if ($scope.valAddWebsiteUrl == true) {
                        //WEBSITE LINK
                        if ($scope.callToDirectionValue == null || $scope.callToDirectionValue == undefined || $scope.callToDirectionValue == '0' || $scope.callToDirectionValue == "") {
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "video_data": {
                                    "video_id": $scope.objid,
                                    "description": $scope.textBodyContent,
                                    "call_to_action":
                                            {
                                                "value":
                                                        {
                                                            "link_caption": $scope.displayLink,
                                                            "link": $scope.webURL,
                                                            "link_description": $scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
                                                            "link_title": $scope.campaignHeadline
                                                        }


                                            },
                                    "image_url": $scope.objurl
                                }
                            }
                        }
                        else {
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "video_data": {
                                    "video_id": $scope.objid,
                                    "description": $scope.textBodyContent,
                                    "call_to_action":
                                            {
                                                "type": $scope.callToDirectionValue,
                                                "value":
                                                        {
                                                            "link_caption": $scope.displayLink,
                                                            "link": $scope.webURL,
                                                            "link_description": $scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
                                                            "link_title": $scope.campaignHeadline
                                                        }


                                            },
                                    "image_url": $scope.objurl
                                }
                            }
                        }

                        $scope.objectType = "VIDEO";

                    } else {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "image_url": $scope.objurl

                            }
                        }
                        $scope.objectType = "VIDEO";
                    }


                }
                else if ($scope.marketingObjective == "VIDEO_VIEWS") {

                    if ($scope.valAddWebsiteUrl == true) {
                        //WEBSITE LINK
                     /*   if ($scope.callToDirectionValue == null || $scope.callToDirectionValue == undefined || $scope.callToDirectionValue == '0') {
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "video_data": {
                                    "video_id": $scope.objid,
                                    "description": $scope.textBodyContent,
                                    "call_to_action":
                                            {
                                                "value":
                                                        {
                                                            "link_caption": $scope.displayLink,
                                                            "link": $scope.webURL,
                                                            "link_description": $scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
                                                            "link_title": $scope.campaignHeadline
                                                        }


                                            },
                                    "image_url": $scope.objurl
                                }
                            }
                        }
                        else { */
                           
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "video_data": {
                                    "video_id": $scope.objid,
                                    "description": $scope.textBodyContent,
                                    "call_to_action":
                                            {
                                                "type": $scope.callToDirectionValue,
                                                "value":
                                                        {
                                                            "link_caption": $scope.displayLink,
                                                            "link": $scope.webURL,
                                                            "link_description": $scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
                                                            "link_title": $scope.campaignHeadline
                                                        }


                                            },
                                    "image_url": $scope.objurl
                                }
                            }
                        

                        $scope.objectType = "VIDEO";

                    } else {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "image_url": $scope.objurl

                            }
                        }
                        $scope.objectType = "VIDEO";
                    }


                }
                else if ($scope.marketingObjective == "LINK_CLICKS") {

                    $scope.objectType = "VIDEO";
                    //MESSENGER
                    if ($scope.callToDirectionValue == null || $scope.callToDirectionValue == undefined || $scope.callToDirectionValue == '0' || $scope.callToDirectionValue == ""){    
                    
                    if ($scope.radioDestination == 'MESSENGER') {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "call_to_action": {
                                    
                                    "value": {
                                        "app_destination": $scope.radioDestination,      
                                         "link": "https://fb.com/messenger_doc/",
                                         "link_description": $scope.newsfeedlinkdesc,
                                        "link_format": "VIDEO_LPP",
                                        "link_title": $scope.campaignHeadline1

                                    }
                                },
                                "image_url": $scope.objurl,
                                "page_welcome_message": $scope.messengertextBodyContent
                            }
                        }

                    } else {
                        //WEBSITE LINK
					
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "call_to_action": {
                                    
                                    "value": {
                                        "link_caption": $scope.displayLink,
                                        "link": $scope.campaignWebURL,
                                        "link_description": $scope.newsfeedlinkdesc,
                                        "link_format": "VIDEO_LPP",
                                        "link_title": $scope.campaignHeadline1

                                    }
                                },
                                "image_url": $scope.objurl
                            }
                        }
                    }
                }
                else{
                    if ($scope.radioDestination == 'MESSENGER') {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "call_to_action": {
                                    "type": $scope.callToDirectionValue,
                                    "value": {
                                        "app_destination": $scope.radioDestination,      
                                         "link": "https://fb.com/messenger_doc/",
                                         "link_description": $scope.newsfeedlinkdesc,
                                        "link_format": "VIDEO_LPP",
                                        "link_title": $scope.campaignHeadline1

                                    }
                                },
                                "image_url": $scope.objurl,
                                "page_welcome_message": $scope.messengertextBodyContent
                            }
                        }

                    } else {
                        //WEBSITE LINK
					
                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "call_to_action": {
                                    "type": $scope.callToDirectionValue,
                                    "value": {
                                        "link_caption": $scope.displayLink,
                                        "link": $scope.campaignWebURL,
                                        "link_description": $scope.newsfeedlinkdesc,
                                        "link_format": "VIDEO_LPP",
                                        "link_title": $scope.campaignHeadline1

                                    }
                                },
                                "image_url": $scope.objurl
                            }
                        }
                    }
                }


                } else if ($scope.marketingObjective == "REACH") {
                    //console.log('i am here for');
                    $scope.object_type = "VIDEO";				
					   if ($scope.valAddWebsiteUrl == true) {                 
                     
                            $scope.objectStorySpec = {
                                "page_id": $scope.pageIdVal,
                                "video_data": {
                                    "video_id": $scope.objid,
                                    "description": $scope.textBodyContent,
                                    "call_to_action":
                                            {
                                                "type": $scope.callToDirectionValue,
                                                "value":
                                                        {
                                                            "link_caption": $scope.displayLink,
                                                            "link": $scope.webURL,
                                                            "link_description": $scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
                                                            "link_title": $scope.campaignHeadline
                                                        }
                                            },
                                    "image_url": $scope.objurl
                                }
                            }
                    
                        $scope.objectType = "VIDEO";

                    } else {

                        $scope.objectStorySpec = {
                            "page_id": $scope.pageIdVal,
                            "video_data": {
                                "video_id": $scope.objid,
                                "description": $scope.textBodyContent,
                                "image_url": $scope.objurl

                            }
                        }
                        $scope.objectType = "VIDEO";
                    }
					
					
                } else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {
                    $scope.audiTarget = $window.localStorage.getItem("campaignAudienceTarget");
                    $scope.objectType = 'VIDEO';

                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
							"description": $scope.textBodyContent,
                            "call_to_action": {
                                "type": $scope.callToDirectionValue, //"USE_APP",
                                "value": {
                                    "application": $scope.audiTarget,
                                    "link": "https://apps.facebook.com/" + $scope.audiTarget,
                                    "link_title": $scope.campaignHeadline1
                                }
                            },
                            "image_url": "https://scontent.xx.fbcdn.net/v/t15.0-10/16231971_169094980245578_511468396647284736_n.jpg?oh=5094448888b98cc199970cf328b2c5fa&oe=593D70A2",
                        }
                    }
                }else if ($scope.marketingObjective == "LEAD_GENERATION") {
                    $scope.objectType = "VIDEO";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "description": $scope.textBodyContent,
                            "call_to_action":
                                {
                                    "type": $scope.callToDirectionValue,
                                    "value":
                                        {
                                            "lead_gen_form_id": $scope.selectLeadForm,
                                            "link_caption": $scope.displayLink,
                                            "link": "http://fb.me/",
                                            "link_description": $scope.newsfeedlinkdesc,
                                            "link_title": $scope.campaignHeadline1
                                        }


                                },
                            "image_url": $scope.objurl
                        }
                    }
                }else if ($scope.marketingObjective == "OFFER_CLAIMS") {
                    $scope.objectType = "VIDEO";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "description": $scope.textBodyContent,
                            "call_to_action":
                            {
                                "type": "GET_OFFER_VIEW",
                                "value" : {
                                    "link" : $window.localStorage.getItem("OfferRedemptionLink"),
                                    "link_title": $window.localStorage.getItem("OfferName")
                                }
                            },
                            "image_url": $scope.objurl,
                            "offer_id": $scope.campaignAudienceCampaignOffer 
                        }
                    }   
                }else if ($scope.marketingObjective == "CONVERSIONS") {
                    console.log('VVVVVVVVVVVVVVV');
                    console.log($scope.objurl);
                    $scope.objectType = "VIDEO";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "description": $scope.textBodyContent,
                            "call_to_action":
                            {
                                "type": $scope.callToDirectionValue,
                                "value" : {
                                    "link_caption": $scope.displayLink,
                                    "link": $scope.webURL,
                                    "link_description": $scope.newsfeedlinkdesc,
                                    "link_format": "VIDEO_LPP",
                                    "link_title": $scope.campaignHeadline1
                                }
                            },
                            "image_url": $scope.objurl
                        }
                    }
                } else {
                    $scope.objectType = 'VIDEO';
                    $scope.objectStorySpec = {
                        "page_id": $scope.selectedTarget,
                        "video_data": {
                            "description": $scope.textBodyContent,
                            "video_id": $scope.objid,
                            "image_url": $scope.objurl
                        }
                    }

                }

                $window.localStorage.setItem("campaignMediaFormat", "Single Video");
            } 
            else if ($scope.fbadvertFormat == 'fbslideshow') {
                  $scope.objectType = "VIDEO";
				  if($scope.objurl){
					  $scope.imageURLValue = $scope.objurl;
				  }
                 $window.localStorage.setItem("campaignMediaFormat", "Slideshow");	
					$scope.object_type = "VIDEO";
					if($scope.marketingObjective == "POST_ENGAGEMENT") {
							$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"description": $scope.textBodyContent,
										"video_id": $scope.objid ,
										"image_url":$scope.imageURLValue 
														
											}
								}
					}
					else if($scope.marketingObjective == "PAGE_LIKES"){						
							$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid ,
										"description": $scope.textBodyContent,										
										"call_to_action": {
										 "type": "LIKE_PAGE",
										 "value": {
										  "page": $scope.pageIdVal
										 }
														
										},
											"image_url":$scope.imageURLValue 
									}
					        }
					}
					else if($scope.marketingObjective == "REACH"){						
						if($scope.valAddWebsiteUrl){												
								$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {											
												"link_caption":$scope.displayLink,
												"link":$scope.webURL,
												"link_description":$scope.newsfeedlinkdesc,
												"link_title": $scope.campaignHeadline
											
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
							}
							else {
									$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"description": $scope.textBodyContent,
										"video_id": $scope.objid ,
										"image_url":$scope.imageURLValue 
														
											}
									}
							}
					}
					else if($scope.marketingObjective == "BRAND_AWARENESS") {	
							if($scope.valAddWebsiteUrl){												
								$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {											
												"link_caption":$scope.displayLink,
												"link":$scope.webURL,
												"link_description":$scope.newsfeedlinkdesc,
												"link_title": $scope.campaignHeadline,
											    "link_format": "VIDEO_LPP"
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
							}
							else {
									$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"description": $scope.textBodyContent,
										"video_id": $scope.objid ,
										"image_url":$scope.imageURLValue 
														
											}
									}
							}
					
					
				}
	           else if($scope.marketingObjective == "LINK_CLICKS") {
													
							if($scope.radioDestination == 'WEBSITEURL'){
												
								$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {											
												"link_caption":$scope.displayLink,
												"link":$scope.campaignWebURL,
												 "link_format": "VIDEO_LPP",
												"link_description":$scope.newsfeedlinkdesc,
												"link_title": $scope.campaignHeadline1 
											
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
							}
							else {
								$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,			                                                                       
									"video_data": {			                                                                    
										"video_id": $scope.objid,			                                                                              
										"description": $scope.textBodyContent,			                                                                              
										"call_to_action": {			                                                                               
											"type": $scope.callToDirectionValue,			                                                                                        
										"value": {                			                                                                                                    
											"app_destination": "MESSENGER",			                                                                      
											"link_caption": $scope.displayLink,			                                                                      
											"link": "https://fb.com/messenger_doc/",			                                                                  
											"link_description":$scope.newsfeedlinkdesc,			                                                              
											"link_format": "VIDEO_LPP",			                                                                          
											"link_title":  $scope.campaignHeadline1                                                                                											                                                                             
												}			                                                                                        
										},			                                                                                
									"image_url": $scope.imageURLValue,			                                                
									"page_welcome_message": $scope.messengertextBodyContent			                                
									}			                                                                        
								}
							}
						}
				else if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {
					
					$scope.audiTarget = $window.localStorage.getItem("campaignAudienceTarget");
						$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {											
												"application": $scope.audiTarget,
												"link":"https://apps.facebook.com/"+$scope.audiTarget,												
												"link_title": $scope.campaignHeadline1
											
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
				}
				  else if($scope.marketingObjective == "VIDEO_VIEWS") {
													
							if($scope.valAddWebsiteUrl){
												
								$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {											
												"link_caption":$scope.displayLink,
												"link":$scope.webURL,
												"link_description":$scope.newsfeedlinkdesc,
											    "link_format": "VIDEO_LPP",
												"link_title": $scope.campaignHeadline
											
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
							}
							else {
									$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"description": $scope.textBodyContent,
										"video_id": $scope.objid ,
										"image_url":$scope.imageURLValue 
														
											}
									}
							}
					
					
				} 
					else if ($scope.marketingObjective == "LEAD_GENERATION") {
					
					
						$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {
											"type": $scope.callToDirectionValue,
											"value": {		
												"lead_gen_form_id": $scope.selectLeadForm,
												"link_caption": $scope.displayLink,
												"link": "http://fb.me/",
												"link_description":$scope.newsfeedlinkdesc,
												"link_title":  $scope.campaignHeadline1										
											}
										},
										"image_url": $scope.imageURLValue
									}
								}
				}
				else if ($scope.marketingObjective == "CONVERSIONS") {
					 $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "description": $scope.textBodyContent,
                            "call_to_action":
                            {
                                "type": $scope.callToDirectionValue,
                                "value" : {
                                    "link_caption": $scope.displayLink,
                                    "link": $scope.webURL,
                                    "link_description": $scope.newsfeedlinkdesc,
                                    "link_format": "VIDEO_LPP",
                                    "link_title": $scope.campaignHeadline1
                                }
                            },
                            "image_url": $scope.imageURLValue
                        }
                    }
				}
				else if ($scope.marketingObjective == "EVENT_RESPONSES") {
				
						$scope.objectStorySpec = {
									"page_id": $scope.pageIdVal,
									"video_data": {
										"video_id": $scope.objid,
										"description": $scope.textBodyContent,
										"call_to_action": {											
											 "type": "EVENT_RSVP",
											 "value": {		
												  "link": "https://www.facebook.com/events/" + $window.localStorage.getItem("campaignAudienceTarget"),
		                                          "event_id": $window.localStorage.getItem("campaignAudienceTarget")													  
											  }
										},
										"image_url": $scope.imageURLValue
									}
								}
					
				}
	
            }
            //console.log("objectStorySpec : "+JSON.stringify($scope.objectStorySpec));
            if ($scope.campaignHeadline != '' && $scope.campaignHeadline != undefined && $scope.campaignHeadline != 'null') {
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,
                    //"objectId" : $scope.selectedTarget,//Note : remove this for video
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields",
                    //"imageHash" : imageHashVal, // Note : its for image 
                    //"videoId" : imageHashVal, // Note : its for video
                    "title": $scope.campaignHeadline
                };
            } else {
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,
                    //"objectId" : $scope.selectedTarget,//Note : remove this for video
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields"
                            //"imageHash" : imageHashVal, // Note : its for image 
                            //"videoId" : imageHashVal, // Note : its for video
                };
            }
            if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
            if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                if($scope.isCreateHideAdvOption) {
                    var url = "";
                    for(var i=0;i<$scope.pageTabs.length;i++) {
                        if($scope.pageTabs[i].name == $scope.campaignLandingView) {
                            url = "https://www.facebook.com/" + $scope.pageTabs[i].urlPart;
                        }
                    }
                    var link_url = {
                        "linkUrl":url
                    };
                    parameters = angular.extend({},parameters,link_url);
                }
                var image_hash = {
                    "imageHash":$scope.objid
                };
                parameters = angular.extend({},parameters,image_hash);
                var object_id = {
                    "objectId":$scope.pageIdVal
                };
                parameters = angular.extend({},parameters,object_id);
                
            }
            console.log(parameters);
            $rootScope.progressLoader = 'block';
            $http({
                method: 'POST',
                url: apiTPBase + '/createadcreative',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {

                if (response.data.appStatus == 0) {
                    //console.log(response.data.adCreativeId);
                    $scope.adCreativeId = response.data.adCreativeId;
                      $scope.showSlideShowBrowser=false;
                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.browselibraryPopupHeading = "Browse Library";
                    $scope.browselibrarySuccessMsg = "successfully uploaded";
                    $scope.createAd();
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();
                    // $scope.browseImgSuccessMsg = "block";
                    $scope.browselibrary = "none";
					$scope.objurl = "";
                    angular.element('#step2').css('background-color', '#95D2B1');

                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    //angular.element($('.accordianRole').prop('disabled', false));
                    //globalData.setLocal("adCreativeId", $scope.adCreativeId, response.data);
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                }
                else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                    $scope.slideShowSuccess=false;
                    $scope.slideShowCreate=true;
                    $scope.showMediaErrorPopup(response);
                    $scope.showSlideShowBrowser=false;
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    //angular.element($('.accordianRole').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                    //  Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
            
            
            
        }
        //=-------------------------------------------------------------------------------------------------
        
        $scope.desktopCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "DESKTOP_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + $scope.adCreativeId+ "&adFormat=" + $scope.previewCategory;
                $http({
                     method: 'GET',
					url: apiTPBase + '/getfbpreview?' + $scope.facebookGraphCall,
					headers: {
						'userId': $window.localStorage.getItem("userId"),
						'accessToken': $window.localStorage.getItem("accessToken")
					}
                }).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.progressLoaderPreveiw = "none";
                        $scope.RetryDesktopPreview = "none";
                        $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.desktopPreview1 = {src: $scope.embedSrcDesktop, title: "Desktop Preview"};
                    }
                    else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }

        $scope.mobileCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "MOBILE_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
                $http({
                    method: 'GET',
                    url: $scope.facebookGraphCall,
                }).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                        $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.mobilePreview1 = {src: $scope.embedSrcDesktop, title: "Mobile Preview"};
                    }
                    else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }
        
        $scope.rightColumnCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "RIGHT_COLUMN_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
                $http({
                    method: 'GET',
                    url: $scope.facebookGraphCall,
                }).then(function (response) {
                    $scope.progressLoaderPreveiw = "none"
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                         $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.rightColumnPreview1 = {src: $scope.embedSrcDesktop, title: "Right Column Preview"};
                    } else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }
        //----------------------------------------------------------------------------------------------------
        $scope.desktopCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "DESKTOP_FEED_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");

            var queryStr = "networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
            $http({
                method: 'GET',
                url: apiTPBase + '/getfbpreview?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }

            }).then(function (response) {
                console.log(response);
                $scope.progressLoaderPreveiw = "none";

                if (response.data.previewFb[0].preview) {
                    $scope.progressLoaderPreveiw = "none";
                    $scope.RetryDesktopPreview = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.desktopPreview = {src: $scope.embedSrcDesktop, title: "Desktop Preview"};
                }
                else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }

        $scope.mobileCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "MOBILE_FEED_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
            $http({
                method: 'GET',
                url: apiTPBase + '/getfbpreview?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                $scope.progressLoaderPreveiw = "none";
                if (response.data.previewFb[0].preview) {
                    $scope.RetryDesktopPreview = "none";
                    $scope.progressLoaderPreveiw = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.mobilePreview = {src: $scope.embedSrcDesktop, title: "Mobile Preview"};
                }
                else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }
        
        $scope.rightColumnCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "RIGHT_COLUMN_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
            $http({
                method: 'GET',
                url: apiTPBase + '/getfbpreview?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                $scope.progressLoaderPreveiw = "none"
                if (response.data.previewFb[0].preview) {
                    $scope.RetryDesktopPreview = "none";
                     $scope.progressLoaderPreveiw = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.rightColumnPreview = {src: $scope.embedSrcDesktop, title: "Right Column Preview"};
                } else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }
        
        $scope.createAd = function () {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": $scope.networkAdAccountId,
                "adsetId": $window.localStorage.getItem("adsetId"),
                "creativeId": $window.localStorage.getItem("adCreativeId"),
                "name": "Demo Ad",
                "status": "PAUSED"
            };
            $http({
                method: 'POST',
                url: apiTPBase + '/createad',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {
                $scope.mainLoader = "none";
                if (response.data.appStatus == 0) {
                    $scope.adId = response.data.adId;
                    $window.localStorage.setItem("adId", $scope.adId);
                    //$scope.desktopCreativePreview();
                    //$scope.mobileCreativePreview();
                    //$scope.rightColumnCreativePreview();
                    $scope.getAd();
					angular.element($('.btnCampaignCreative').prop('disabled', false));
					//angular.element($('.accordianRole').prop('disabled', false));
					angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                                        $scope.step2_green=true;
                }
                else {
                    $rootScope.progressLoader = "none"
                    $scope.showErrorPopup(response.data);
					angular.element($('.btnCampaignCreative').prop('disabled', true));
					//angular.element($('.accordianRole').prop('disabled', true));
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }
            });
        }

        $scope.showErrorPopup = function (response) {
            if(response.networkError!='' && response.networkError!=undefined){
                $scope.popupTitle = response.networkError.error_user_title;
                $scope.popupMessage = response.networkError.error_user_msg;
            }else{
                $scope.popupTitle = 'Error';
                $scope.popupMessage = response.errorMessage;
            }
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }
        $scope.showSuccessPopup = function () {
            //console.log('success popup here123');
            $scope.popupTitle = "Assigning creative";
            $scope.popupMessage = "Ad created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show();

        }
        $scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            $scope.networkErrorPopup = 'none';
            successReq.hide();


        }
        $scope.showMediaErrorPopup = function (response) {
            
            if(response.data.networkError!='' && response.data.networkError!=undefined){
				if(response.data.networkError.error_user_title){
					$scope.popupTitle = response.data.networkError.error_user_title;
					$scope.popupMessage = response.data.networkError.error_user_msg;
				}
				else{
					$scope.popupTitle = 'Invalid Parameter';
					$scope.popupMessage = response.data.errorMessage;
				}
                
            }else{
                $scope.popupTitle = 'Invalid Parameter';
                $scope.popupMessage = response.data.errorMessage;
            }
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }

        $scope.hidePopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".success_popup");
            modalApproveReq.hide();
        }

        $scope.getAd = function () {
            var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
            $http({
                method: 'GET',
                url: apiTPBase + '/getad?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify($scope.adData));
                    $scope.saveAd($scope.adData);
                    console.log("success $scope.getAd");
                } else {// failed
                    console.log("failed $scope.getAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
        }

        $scope.saveAdforDelete = function () {

            //console.log($scope.adData)
            $scope.adDataFromLocal = JSON.parse($window.localStorage.getItem("adData"));

            $scope.adDataTemp = {
                "status": "DELETED"
            };

            var camR = {};
            for (var key in $scope.adDataFromLocal) {
                camR[key] = $scope.adDataFromLocal[key];
            }
            for (var key in $scope.adDataTemp) {
                camR[key] = $scope.adDataTemp[key];
            }
            $scope.adDataFromLocal = camR;
            console.log($scope.adData);

            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": $scope.adDataFromLocal
            };
            $http({
                method: 'POST',
                url: apiTPBase + '/saveaddata',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {
                if (response.data.appStatus == 0) {
                    $rootScope.progressLoader = "none";
                    //$scope.showSuccessPopup(response.data.successMessage);
                }
                else {
                    console.log('failed $scope.saveAdforDelete')
                    $scope.showErrorPopup(response.data);
                    $scope.networkErrorPopup = "block";
                    $scope.popupTitleError = "Error";
                    $scope.popupTitleError = response.data.errorMessage;
                    return false;

                }
            });
        }


        $scope.saveAd = function (adData) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": adData
            };
            $http({
                method: 'POST',
                url: apiTPBase + '/saveaddata',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    $rootScope.progressLoader = "none";
                    $scope.showSuccessPopup(response.data.successMessage);
                    // $scope.getAdCreative();
                    $scope.getAdSetAdCreative();
                    $scope.networkErrorPopup = "none";
                    $scope.popupTitleError = "";
                    $scope.popupTitleError = "";
                }
                else {
                    console.log('failed $scope.saveAd');
                    $scope.showErrorPopup(response.data);
                    $scope.networkErrorPopup = "block";
                    $scope.popupTitleError = "Error";
                    $scope.popupTitleError = response.data.errorMessage;
                    return false;
                }
            });
        }
        $scope.getAdSetAdCreative = function () {

            var queryStr = "adSetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");

            $http({
                method: 'GET',
                //url: apiTPBase + '/getadaccountsadcreative?'+queryStr,
                url: apiTPBase + '/getadsetadcreative?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $scope.adCreativeDatailsResponse = response.data.fbAdSetCreativeResponse.data[0];
                    console.log('test');
                    $scope.saveAdAccountAdCreative($scope.adCreativeDatailsResponse)
					//$scope.fbadvertFormat = "fbslideshow";
                    if($scope.fbadvertFormat == "fbsingleimage"){
                        $scope.thumbnail = $scope.adCreativeDatailsResponse.thumbnail_url;
                         $scope.thumbnailVideo = "images/campaign/single-video.png";
				 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
						 $scope.thumbnailCarousel = "images/campaign/carousel.svg";
                    }else if($scope.fbadvertFormat == "fbsinglevideo"){
                        $scope.thumbnail="images/campaign/single-image.png";
                         $scope.thumbnailVideo = $scope.adCreativeDatailsResponse.thumbnail_url;
						 $scope.thumbnailCarousel = "images/campaign/carousel.svg";
						  $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                    }
					else if($scope.fbadvertFormat == "fbcarosel"){
						  $scope.thumbnailCarousel = $scope.adCreativeDatailsResponse.thumbnail_url;
                          $scope.thumbnailVideo="images/campaign/single-video.png";
                          $scope.thumbnail="images/campaign/single-image.png";

						 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                    }else if($scope.fbadvertFormat == "fbslideshow"){
                        $scope.thumbnail="images/campaign/single-image.png";
                         $scope.thumbnailVideo =  "images/campaign/single-video.png";
						  $scope.thumbnailSlideshow = $scope.adCreativeDatailsResponse.thumbnail_url;
						  $scope.thumbnailCarousel = "images/campaign/carousel.svg";
						$scope.slideShowCreate = false;			
	                     $scope.slideShowSuccess = true;			
	                    $scope.slideShowPreview = $scope.adCreativeDatailsResponse.thumbnail_url;
                    }
					
					
                    //$scope.saveAdAccountAdCreative($scope.adCreativeDetails);
                    //console.log(response.data.successMessage);
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });

        }
        $scope.getAdCreative = function () { /// service missing saveAdCreative
            //   var queryStr = "adAccountId="+$scope.networkAdAccountId+"&networkMapId="+$window.localStorage.getItem("userNetworkMapId")+"&limit=10";
            var queryStr = "adsetid=" + $window.localStorage.getItem("adsetId") + "&networkmapid=" + $window.localStorage.getItem("userNetworkMapId");
            $http({
                method: 'GET',
                url: apiTPBase + '/getadcreative?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {// success
                    $scope.fbAdCreativeResp = response.data.fbAdCreativeResponse;
                    console.log($scope.fbAdCreativeResp);
                    for (var i = 0; i < response.data.fbAdCreativeResponse.data.length; i++) {
                        if ($window.localStorage.getItem("adCreativeId") == response.data.fbAdCreativeResponse.data[i].id) {
                            $scope.respAdCreativeObj = response.data.fbAdCreativeResponse.data[i];
                        }
                    }
                    console.log($scope.respAdCreativeObj);

                    $scope.saveAdAccountAdCreative($scope.respAdCreativeObj);
                    console.log(response.data.successMessage);
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
        }

        $scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }


        $scope.sendBodyContent = function (val) {
            $scope.textBodyContent = val;
            if($scope.textBodyContent!=null && $scope.textBodyContent!="" && $scope.textBodyContent!=undefined)
            {
                angular.element('#textBodyContent').removeClass("mandatory");
            }else
            {
                angular.element('#textBodyContent').addClass("mandatory");
            }
            $window.localStorage.setItem("textBodyContent", $scope.textBodyContent);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; }*/
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             
        };

        $scope.sendHeadline = function (val) {
		
            $scope.campaignHeadline = val;
            if($scope.campaignHeadline!=null && $scope.campaignHeadline!="" && $scope.campaignHeadline!=undefined)
            {
                angular.element('#campaignHeadline1').removeClass("required");
            }else
            {
                angular.element('#campaignHeadline1').addClass("required");
            }
            $window.localStorage.setItem("campaignHeadline", $scope.campaignHeadline)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; } */
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             
        };
		
	$scope.sendLeadForm = function (val) {
            $scope.selectLeadForm = val;
            $window.localStorage.setItem("selectLeadForm", $scope.selectLeadForm)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
        };
		
		$scope.sendmessengertext = function (val) {
            $scope.messengertextBodyContent = val;
            $window.localStorage.setItem("sendmessengertext", $scope.messengertextBodyContent)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
        };
		
        
            $scope.sendHeadline1 = function (val) {
            $scope.campaignHeadline1 = val;
            if($scope.campaignHeadline1!=null && $scope.campaignHeadline1!="" && $scope.campaignHeadline1!=undefined)
            {
                angular.element('#idcampaignHeadline').removeClass("required");
            }else
            {
                angular.element('#idcampaignHeadline').addClass("required");
            }
            $window.localStorage.setItem("campaignHeadline1", $scope.campaignHeadline1)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; } */
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
             
             
        };
        $scope.sendnewsfeedlinkdesc = function (val) {
            $scope.newsfeedlinkdesc = val;
            if($scope.newsfeedlinkdesc!=null && $scope.newsfeedlinkdesc!="" && $scope.newsfeedlinkdesc!=undefined)
            {
                angular.element('#txtnewsfeedlinkdesc').removeClass("mandatory");
            }else
            {
                angular.element('#txtnewsfeedlinkdesc').addClass("mandatory");
            }
            $window.localStorage.setItem("newsfeedlinkdesc", $scope.newsfeedlinkdesc)
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; }*/
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
             
             

        };
		
		//Carousel card textbox model
		 
		$scope.sendCardHeadline = function (val,index) {
		console.log(index);
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardHeadline = val;			
			// $scope.headlinecontents = [];
			 $scope.headlinecontents[index] = $scope.cardHeadline[index];
                         if($scope.cardHeadline[index]!=null && $scope.cardHeadline[index]!="" && $scope.cardHeadline[index]!=undefined)
                        {
                            angular.element("#cardHeadline"+index).removeClass("required");
                        }else
                        {
                            angular.element("#cardHeadline"+index).addClass("required");
                        } 
			 console.log($scope.headlinecontents);					
			$window.localStorage.setItem("cardHeadline", JSON.stringify($scope.headlinecontents));
		}
		     
        };
		
		$scope.sendCardDescription = function (val,index) {
		
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardDescription = val;			
			// $scope.descriptioncontents = [];
			 $scope.descriptioncontents[index] = $scope.cardDescription[index];	
			console.log($scope.descriptioncontents);			 
			$window.localStorage.setItem("cardDescription", JSON.stringify($scope.descriptioncontents));
		}
		 
             
        };
		
		$scope.sendcardwebURL = function (val,index) {			
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardwebURL = val;			
			// $scope.weburlcontents = [];
			$scope.weburlcontents[index] = $scope.cardwebURL[index];
                        if($scope.cardwebURL[index]!=null && $scope.cardwebURL[index]!="" && $scope.cardwebURL[index]!=undefined)
                        {
                            angular.element("#cardwebURL"+index).removeClass("mandatory");
                        }else
                        {
                            angular.element("#cardwebURL"+index).addClass("mandatory");
                        } 
			$window.localStorage.setItem("cardwebURL", JSON.stringify($scope.weburlcontents));
			console.log($scope.weburlcontents);	
		}
		 
             
        };

        $scope.sendLandingView = function (val) {
            $scope.campaignLandingView = val;
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        };

        $scope.getAdAccountAdCreative = function () {
		

            $scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));

            //angular.element($('.btnCampaignCreative').prop('disabled', false));
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
			//angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
           // angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
			//angular.element($('.accordianRole').prop('disabled', false));
            var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
            $http({
                method: 'GET',
                url: apiTPBase + '/getadimages?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    $scope.mainLoader = "none";
                    $scope.browselibrary = "block";
                    var arrAdAccountCreativeallData = [];
                    
                    angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
                    $scope.uniqueArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
//                    for (var i = 0; i < response.data.adAccountAdCreative.length; i++) {
//                        if (response.data.adAccountAdCreative[i].image_hash != undefined) {
//                            arrAdAccountCreativeallData.push(response.data.adAccountAdCreative[i]);
//                        }
//                    }
//                    $scope.uniqueArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "image_hash");
//                    for (var i = 0; i < response.data.adAccountAdCreative.length; i++) {
//                        if ($window.localStorage.getItem("adCreativeId") == response.data.adAccountAdCreative[i].id) {
//                            $scope.respGetAdCreativeObj = response.data.adAccountAdCreative[i];
//                        }
//                    }
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;

                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
            // }
        }


        $scope.saveAdAccountAdCreative = function (respGetAdCreativeObj) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetID": $window.localStorage.getItem("adsetId"),
                "adCreativeID": $window.localStorage.getItem("adCreativeId"),
                "adCreativeDetails": respGetAdCreativeObj,
            };
            $http({
                method: 'POST',
                url: apiTPBase + '/saveadsetadcreative',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {
                if (response.data.appStatus == 0) {
                    $rootScope.campaignSteps[3] = true;
                    //$rootScope.step = 4;
                }
                else {
                    console.log('failed');
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }
        $scope.deleteAdCreative = function () {
		  $rootScope.progressLoader = 'block';
            var isCreateAd = $window.localStorage.getItem("adId");
            var isAdDetails = $window.localStorage.getItem("adData");
            if (isCreateAd) {
                $scope.deleteAd();
                $scope.saveAdforDelete();
            }
            var queryStr = "adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            $http({
                method: 'DELETE',
                url: apiTPBase + '/deleteadcreative?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //alert(response.data.appStatus)
                if (response.data.appStatus == '0') {// success
                    //$scope.creativeAdCreative(hashVal);
                    $scope.networkErrorPopup = 'none';
                    $scope.popupTitleError = '';
                    $scope.popupMessageError = '';
                    $window.localStorage.setItem("deleteAdCreativeStatus", "true");
                } else {// failed
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }                       

                    }
                    $window.localStorage.setItem("deleteAdCreativeStatus", "false");

                }
            });
        }

        $scope.deleteAd = function () {
            var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adId=" + $window.localStorage.getItem("adId");
            $http({
                method: 'DELETE',
                url: apiTPBase + '/deletead?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    // 'networkAccessToken' : $window.localStorage.getItem("networkAccessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log("success delete ad");
                    $scope.networkErrorPopup = 'none';
                    $scope.popupTitleError = "";
                    $scope.popupMessageError = '';
                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
                    if (isCreativeAdCreativeId) {
                        $scope.deleteAdCreative();
                    }
                } else {// failed
                    console.log("failed $scope.deleteAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    return false;
                }
            });
        }
        $scope.saveAndProceedNextStep = function () {
            console.log("textBodyContent : " + $scope.textBodyContent);
            console.log("imagesSource : " + $scope.imagesSource);
            console.log("hashVal : " + $scope.hashVal);
            //  if(($scope.textBodyContent != "") && ($scope.imagesSource != "" || $scope.hashVal != "")){
            //angular.element($('.btnCampaignCreative').prop('disabled', false));
            $rootScope.freezeFlag = false;
            $rootScope.campaignSteps[3] = true;
			 $rootScope.campaignSteps[4] = true;
            $state.go('app.campaignsummary');
            /* }
             else{
             angular.element($('.btnCampaignCreative').prop('disabled', true));
             console.log("Please upload/browse image");
             }*/

        }
        $scope.closePopup = function () {
			$scope.editAdsetErrorMsg = "none";
            $scope.mainLoader = "none";
            $scope.browseImgSuccessMsg = "none";
            $scope.browselibrary = "none";
            $scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
			
        }


        $scope.changeSelection = function (image_hash) {
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.getExistingVideosID = function (videoID) {
            if (angular.element($("#" + videoID).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + videoID).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.sendcampaignWebURL = function (campaignWebURL) {
            console.log(campaignWebURL);
            $scope.campaignWebURL = campaignWebURL;
            if($scope.campaignWebURL!=null && $scope.campaignWebURL!="" && $scope.campaignWebURL!=undefined)
            {
                angular.element('#campaignWebURL').removeClass("mandatory");
            }else
            {
                angular.element('#campaignWebURL').addClass("mandatory");
            }
            $window.localStorage.setItem("campaignWebURL", $scope.campaignWebURL);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }

        $scope.selectCallToAction = function (_callToDirectionValue) {
            $scope.callToDirectionValue = _callToDirectionValue;


            //alert(_callToDirectionValue); 
//            if($scope.callToDirectionValue == "NO_BUTTON" && $scope.fbadvertFormat == "fbcarosel" && $scope.marketingObjective == "LINK_CLICKS")
//            {  $scope.isCreateShowandHideOptionWrap1 = true;
//                
//            }
//            else{  $scope.isCreateShowandHideOptionWrap1 = false;
//                
//            }

            if($scope.fbadvertFormat == "fbcarosel" && $scope.marketingObjective == "LINK_CLICKS" )
            {  
                $scope.isDisplayLink = false;
                $scope.isCreateShowandHideOptionWrap1 = true;
                
            }
            if($scope.callToDirectionValue!=null && $scope.callToDirectionValue!="" && $scope.callToDirectionValue!=undefined)
            {
                angular.element('#callToAction').removeClass("mandatory");
            }else
            {
                angular.element('#callToAction').addClass("mandatory");
            }
            $window.localStorage.setItem("callToDirectionValue", $scope.callToDirectionValue);
			$rootScope.freezeFlag = true;
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
                        
        
        }
        
        $scope.selectlearnMoreUrl = function(_learnMoreUrl)
        {
           $scope.learnMoreUrl = _learnMoreUrl;
            if($scope.learnMoreUrl!=null && $scope.learnMoreUrl!="" && $scope.learnMoreUrl!=undefined)
            {
                angular.element('#learnMoreUrl').removeClass("required");
            }else
            {
                angular.element('#learnMoreUrl').addClass("required");
            } 
        };
         $scope.selectcampaignURLParameter = function(_campaignURLParameter)
        {
            $scope.campaignURLParameter = _campaignURLParameter;
            if($scope.campaignURLParameter!=null && $scope.campaignURLParameter!="" && $scope.campaignURLParameter!=undefined)
            {
                angular.element('#campaignURLParameter').removeClass("required");
            }else
            {
                angular.element('#campaignURLParameter').addClass("required");
            }
        };
        $scope.selectPixelTracking = function(pixelTracking)
        {
            if(pixelTracking!=null && pixelTracking!="" && pixelTracking!=undefined)
            {
                angular.element('#pixelTracking').removeClass("mandatory");
            }else
            {
                angular.element('#pixelTracking').addClass("mandatory");
            }
        };
        $scope.selectMessenger = function (radioDestination) {
            //if($scope.isCreateHideAdvOption){
            $scope.radioDestination = radioDestination;
            if (radioDestination == 'MESSENGER') {
                $scope.isDisplayLink = false;
                $scope.isAdvancedDisplayLink = false;
              
                if($scope.marketingObjective == "LINK_CLICKS" )
                {
                    $scope.isSeeMoreURL = false;
                    $scope.ismessengertext = true;
                }
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbslideshow")
                {$scope.isCallToAction = true;$scope.isCallToActionOptional = false;}
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbsinglevideo")
                {$scope.isDisplayLink = false;}
                $scope.isWebURL = false;
                var campaignStateForEdit = $window.localStorage.getItem("campaignState");
                if (campaignStateForEdit == 'edit') {
                    /*$rootScope.freezeFlag  = true;
                     angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                     angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                     */
                }
                
            }

			else if (radioDestination == 'URLCANVAS'){
				$scope.isSeeMoreURL = true;
				$scope.isWebURL = false;
			}

			else if(radioDestination == 'WEBSITEURL'){
                 $scope.ismessengertext = false;
                 $scope.isWebURL = true;
                 
                 
                 if ($scope.marketingObjective == "REACH") {
                    $scope.isDisplayLink = false;
                } else {
                    //$scope.isDisplayLink = true;
                }
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbsinglevideo")
                {$scope.isDisplayLink = false;
                 if($scope.isCreateHideAdvOption == true) {$scope.isAdvancedDisplayLink = true;}
                }
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbsingleimage")
                {$scope.isDisplayLink = false;
                    if($scope.isCreateHideAdvOption == true) {$scope.isAdvancedDisplayLink = true;} 
                }
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbslideshow")
                {if($scope.isCreateHideAdvOption == true) {$scope.isAdvancedDisplayLink = true;}
                 $scope.isCallToAction = true;
                 $scope.isCallToActionOptional = false;
                 $scope.isDisplayLink = false;
                }
                
                
                
                if($scope.marketingObjective == "LINK_CLICKS" && $scope.fbadvertFormat == "fbcarosel")
                {   $scope.isDisplayLink = false;
                    $scope.isAdvancedDisplayLink = false;
                    $scope.isCallToAction = false;
                    $scope.isNewsFeedLinkDesc = false;
                    $scope.isDestination = true;
                    $scope.isSeeMoreURL = true;
                    $scope.ismessengertext = false;
                    $scope.isWebURL = false;
                }
                var campaignStateForEdit = $window.localStorage.getItem("campaignState");
                if (campaignStateForEdit == 'edit') {
                    /*$rootScope.freezeFlag  = true;
                     angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                     angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                     */
                }
            }
            //}
            $window.localStorage.setItem("radioDestination", $scope.radioDestination);
        }

        // Use Exist Post Services integration
        //$scope.fetchuserpromotablepages();
        $scope.promotableposts = function () {
            $http({
                method: 'GET',
                url: 'https://graph.facebook.com/585993311604680/promotable_posts?access_token=EAAJ4OaibPkYBAJVkRNZCKm1ZCuJZATHOaXJNz2TEvZAboSqlBjnsLdv0tZCTKON5ZBXe56y4hIDyOIxi8ulk4kIW5PypmTS1h06Imp3vj1gG3EPBu5LwAgzRGuJZBn87wS4Wf6ZCGIl2F8ZCbzxRlvDGOZAYJhYOUb32mJFUFFZC5mqSKQIJdcWZCnQe&limit=100&fields=name,description,link',
                /*headers: {
                 "userId": $window.localStorage.getItem("userId"),
                 "accessToken": $window.localStorage.getItem("accessToken")
                 }*/
            }).success(function (response) {
                console.log(response);

            }).error(function (error) {
                //alert(error);
            });
        }
		
		
		
		//Carousel advent code start
		
		$scope.selectMedia = function (val,index) {
            $scope.imageFormat = "imagemediaUpdate";            
            $scope.media=true;
			$scope.mediaarrow=true;
			$scope.cardarrow=false;
			
			if($scope.campaignState == 'create'){
					$scope.showVideoPrev[index] = false;
					console.log(index);
				}
			
			
        }

        $scope.selectMedia1 = function (val,index) {
            $scope.imageFormat = "videomediaUpdate";            
            $scope.media=true;
            //$scope.createCards();  
			$scope.mediaarrow=false;
			$scope.cardarrow=true;	
				if($scope.campaignState == 'create'){
					$scope.showImgPrev[index] = false;
					console.log(index);
				} 
			
        }
		
		 $scope.selectMedia2 = function (val) {
            $scope.imageFormat = "videoviewsmediaUpdate";            
            $scope.media=false;
            //$scope.createCards();  
			$scope.mediaarrow=false;
			$scope.cardarrow=false;		
			
        }
		
		 $scope.selectImagePopup = function (index) {
		 
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
				else{
					
				//$rootScope.progressLoader = 'block';
                document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
				 //	document.getElementById("seeMoreUrl").style.borderColor = "#A9A9A9";
                $scope.errTextMsg = "none";
				angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
               /* angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); */
                $scope.step2_green=true;
			$scope.uploadimgcount = index;
			angular.element($('body').css("overflow", "hidden"));
            var createPopup = $(".selectImagePopup");// Get the modal Reject req
            createPopup.show();
			$scope.mainLoader = "block";
			
			
			var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId");     //$scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray1 = "";
            $http({
                method: 'GET',
				url: apiTPBase + '/getadimages?' + queryStr,
				headers: {
					'userId': $window.localStorage.getItem("userId"),
					'accessToken': $window.localStorage.getItem("accessToken")
					
				}
            }).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    $scope.mainLoader = "none";					
                    //$scope.browselibrary = "block";
                    var arrAdAccountCreativeallData = [];
					console.log(response.data.adImages.length);
                    angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    }); 
					$scope.uniqueArray1 = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
					//console.log(uniqueArray1);
					console.log(arrAdAccountCreativeallData);
                    console.log($scope.respGetAdCreativeObj);
					
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                       // $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
			
			}
			
		 }
		 
		 
		  $scope.selectVideoPopup = function (index) {
		  
		  
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
			else {	
			
			 document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";				
             $scope.errTextMsg = "none";
             angular.element($('.btnCampaignCreative').prop('disabled', false));
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			 angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
			$scope.uploadimgcount = index;
			angular.element($('body').css("overflow", "hidden"));
            var createPopup = $(".selectVideoPopup");// Get the modal Reject req
            createPopup.show();
			$scope.mainLoader = "block";
			
			 var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
			 angular.element($('body').css("overflow-y", "hidden"));
			 $scope.uniqueArrayVideo = "";
            $http({
                method: 'GET',               
                url: apiTPBase + '/getadvideos?' + queryStr,
				headers: {
					'userId': $window.localStorage.getItem("userId"),
					'accessToken': $window.localStorage.getItem("accessToken")
				}
            }).then(function (response) {
			
			 if (response.data.appStatus == '0') {// success
				console.log(response.data);
                 $scope.mainLoader = "none";		
               // $scope.browselibraryvideos = "block";
                //console.log(response.data.data);
                $scope.existVideosList = response.data.data;
				
				var arrAdAccountCreativeallDataVideo = [];
                     angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
					// $scope.uniqueArrayVideo = $scope.removeDuplicates(arrAdAccountCreativeallDataVideo, "id");                  
					$scope.uniqueArrayVideo = arrAdAccountCreativeallDataVideo;                  
                    console.log($scope.uniqueArrayVideo);
					
			}
		 else {
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                } 
			
            });
			
			} 
			
		 }
		 
		 
		 
		 
		 $scope.selectImage = function(){
			$scope.imagePreviewSrc[$scope.uploadimgcount] = $scope.selectedImagegallery;	
			$('#imagePreview'+$scope.uploadimgcount).attr('src', $scope.selectedImagegallery);	
			$('#imagePreview'+$scope.uploadimgcount).attr('class', $scope.selectedImagegalleryHash);	
			$scope.showImgPrev[$scope.uploadimgcount] = true;
			//$scope.closePopup();
			angular.element($('body').css("overflow-y", "scroll"));
			
			angular.element($('#fbImagepopup').css("display","none"));			
			console.log($('#imagePreview'+$scope.uploadimgcount).attr('src'));
		//	$scope.selectedImagegalleryArray.push($('#imagePreview'+$scope.uploadimgcount).attr('src'));
			$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('src'));
			console.log($scope.selectedImagegalleryArray);
			
			$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('class'));
			console.log($scope.uniqueImageSelectionArray);
			
		 } 
		 
		 
		  $scope.selectVideo = function(){
			$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.selectedImagegallery;	
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.selectedImagegallery);
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.selectedImagegalleryVideo);
				//angular.element($('.cards-content .imgprv #imagePreviewVideo'+$scope.uploadimgcount).css("visibility", "visible"));
				//angular.element($('.cards-content .imgprv #imagePreviewVideo'+$scope.uploadimgcount+ '+span').css("visibility", "visible"));
			$scope.showVideoPrev[$scope.uploadimgcount] = true;
			//$scope.closePopup();
			angular.element($('body').css("overflow-y", "scroll"));
			angular.element($('#fbVideopopup').css("display","none"));
			//$scope.previewing = true;
			//angular.element($('.cards-content .imgprv').css("visibility", "visible"));
			console.log($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
		//	$scope.selectedImagegalleryArray.push($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
			$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
			$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
			console.log($scope.selectedImagegalleryArray);
			console.log($scope.selectedImagegalleryArrayVideo);
			
			$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
			console.log($scope.uniqueImageSelectionArray);
			
			
		 }
		 
		
			$scope.selectedImagePush = [];
		$scope.changeSelectionImage = function (image_hash) {
			
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
				
				
				// console.log($('.galleryImages label img').attr('src'));
				console.log($('.sel_bk_color label img').attr('src'));
				$scope.selectedImagegallery = $('.sel_bk_color label img').attr('src');
				$scope.selectedImagegalleryHash = image_hash;
				console.log($scope.selectedImagegalleryHash);
				$scope.selectedImagePush.push(image_hash);
				
				//Code to remove duplicate hash value from array
				/* $scope.uniqueImageSelectionArray = $scope.selectedImagePush.filter(function( item, index, inputArray)
					{
						return inputArray.indexOf(item) == index;
					});
			
			console.log($scope.uniqueImageSelectionArray); */
				
            }
			// $scope.selectedImagePush.push(image_hash);
			

        }
		 
		
		 $scope.changeSelectionVideo = function (videoID1) {
			console.log(videoID1);
           
				 if (angular.element($(".galleryVideos #" + videoID1).is(':checked'))) {				 
					angular.element($('.galleryVideos').removeClass('sel_bk_color1'));
                angular.element($(".galleryVideos #" + videoID1).parent(".galleryVideos").addClass('sel_bk_color1'));	

						console.log($('.sel_bk_color1 label img').attr('src'));
				$scope.selectedImagegallery = $('.sel_bk_color1 label img').attr('src');
				$scope.selectedImagegalleryVideo = $('.sel_bk_color1 label img').attr('class');
				$scope.selectedImagegalleryHash = videoID1;
				console.log($scope.selectedImagegalleryHash);
				$scope.selectedImagePush.push(videoID1);
				
				//Code to remove duplicate hash value from array
				/* $scope.uniqueImageSelectionArray = $scope.selectedImagePush.filter(function( item, index, inputArray)
					{
						return inputArray.indexOf(item) == index;
					});
			
			console.log($scope.uniqueImageSelectionArray); */
				
            }

        }
		 
		  $scope.deleteImg = function (index) {
			//console.log(index);
            $scope.uploading = true;
            $scope.previewing = false;
			console.log($('#imagePreview'+index).attr('src'));
			$('#imagePreview'+index).attr('src', '#');
			//angular.element($('.cards-content .imgprv #imagePreview'+index).css("visibility", "hidden"));
			//angular.element($('.cards-content .imgprv #imagePreview'+index+ '+span').css("visibility", "hidden"));
			$scope.showImgPrev[index] = false;
        }
		
		 $scope.deleteImgVideo = function (index) {
			//console.log(index);
            $scope.uploading = true;
            $scope.previewing = false;
			console.log($('#imagePreviewVideo'+index).attr('src'));
			$('#imagePreviewVideo'+index).attr('src', '#');			
			$scope.showVideoPrev[index] = false;
        }
		 
		 //Image Upload section carousel
		 
		   $scope.uploadFile = function (files) {
		   
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {			
                $('#imagePreview'+$scope.uploadimgcount).attr('src', e.target.result);				
				$scope.showImgPrev[$scope.uploadimgcount] = true;
                $scope.dataURL = reader.result;                
                $scope.splittedData = $scope.dataURL.split(',')[1]; 
				$scope.mainLoader = "block";
            };
            
			 $timeout(function () {                    				
			$scope.mainLoader = "block";
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
			parameters.append('type','IMAGE');
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('imageFile',files[0]);

					 if (typeof (files[0]) == "object") {
                    $http({													
                        method: 'POST',
                        url: apiTPBase + '/createadimage',
                        data: parameters,
					    transformRequest: angular.identity,
                        headers: {
						'Content-Type': undefined,
						'dataType': 'jsonp',
						'async': 'false'
						}
																	
                    }).then(function (response) {
                        console.log(response);
						$rootScope.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
							$scope.mainLoader = "none";
							angular.element($('body').css("overflow-y", "scroll"));
							angular.element($('#fbImagepopup').css("display","none"));	
                            $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
							console.log($scope.hashVal);
                            $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
							console.log($scope.hashUrl);
                            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
							
                          $scope.imagePreviewSrc[$scope.uploadimgcount] = $scope.hashUrl;	
						  $('#imagePreview'+$scope.uploadimgcount).attr('src', $scope.hashUrl);
						  $('#imagePreview'+$scope.uploadimgcount).attr('class', $scope.hashVal);						
							$scope.showImgPrev[$scope.uploadimgcount] = true;
							$scope.selectedImagePush.push($scope.hashVal);
							$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('class'));
							console.log($scope.uniqueImageSelectionArray);
							$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('src'));
							console.log($scope.selectedImagegalleryArray);
                        }
                        else {
                            console.log('failed $scope.getCampaignfiles');
							$scope.showErrorPopup(response.data);
							$scope.mainLoader = "none";
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }															
                    });
					
					}
																			
                }, 1000);
			
			
			
            reader.readAsDataURL(files[0]);
          
        };
		
		
	   $scope.closeImagePopup = function () {
            $scope.mainLoader = "none";            
            angular.element($('body').css("overflow-y", "scroll"));			
			angular.element($('#fbImagepopup').css("display","none"));
			
			console.log($('#imagePreview'+$scope.uploadimgcount).attr('src'));
			if($('#imagePreview'+$scope.uploadimgcount).attr('src') == "#"){
			$('#imagePreview'+$scope.uploadimgcount).attr('src', ' ');
			$('#imagePreview'+$scope.uploadimgcount).attr('class', ' ');				
				$scope.showImgPrev[$scope.uploadimgcount] = false;
				}
        }	
		

		 $scope.closeVideoPopup = function () {
            $scope.mainLoader = "none";            
            angular.element($('body').css("overflow-y", "scroll"));						
			angular.element($('#fbVideopopup').css("display","none"));
			
			console.log($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
			if($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src') == "#"){
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', ' ');
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', ' ');				
				$scope.showVideoPrev[$scope.uploadimgcount] = false;
				}
        }

		$scope.validateCarousel = function()
                {
                    console.log("validated");
                    console.log($scope.selectedImagegalleryArray);
                    $scope.index = [];
					
				if($scope.marketingObjective == "VIDEO_VIEWS" || $scope.marketingObjective == "OFFER_CLAIMS"){
					
                    for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }                       
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
				}
				
				else if($scope.marketingObjective == "LEAD_GENERATION"){
					
                    for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }                       
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
						
						  if($scope.selectLeadForm=="" || $scope.selectLeadForm==undefined || $scope.selectLeadForm==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
				}
				
				
				else{
					 for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                        if($scope.weburlcontents[i]=="" || $scope.weburlcontents[i]==undefined || $scope.weburlcontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
					
				
				}
                    if($scope.index.length==0)
                    {
                        for(i=0;i<$scope.tabs.length;i++)
                        {
                            console.log($scope.tabs[i].title-1);
                            angular.element('#mainCntr #'+($scope.tabs[i].title-1)).removeClass("mandatory_red");
                        }
                        angular.element('#step2').css('background-color', '#95D2B1');
                        console.log("if")
                        $scope.createCarousel();
                    }
                    else
                    {
                        for(i=0;i<$scope.tabs.length;i++)
                        {
                            for(j=0;j<$scope.index.length;j++)
                            {
                                angular.element('#mainCntr #'+$scope.index[j]).addClass("mandatory_red");
                                if($scope.index[j]!= ($scope.tabs[i].title - 1))
                                {
                                    angular.element('#mainCntr #'+($scope.tabs[i].title-1)).removeClass("mandatory_red");
                                }
                            }
                            
                        }
                        angular.element('#step2').css('background-color', '#c2c2c2');
                    }
                };

	
		$scope.createCarousel = function(){
			
			angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); 			
			if($scope.selectedImagegalleryArray.length >= 2){
			$scope.mainLoader = "block";
					 var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
						if (isCreativeAdCreativeId) {
							$scope.deleteAdCreative();
							$window.localStorage.removeItem("adCreativeId");
							if ($window.localStorage.removeItem("deleteAdCreativeStatus")) { //alert("dfdsf")
								$scope.networkErrorPopup = 'block';
								return;
							}
						}
					console.log($scope.selectedImagegalleryArray);
					 $scope.pageIdVal = $scope.selectedTarget;
					 $scope.objectType = "SHARE";
					 
			if($scope.marketingObjective != "VIDEO_VIEWS" && $scope.marketingObjective != "CANVAS_APP_INSTALLS" && $scope.marketingObjective != "LINK_CLICKS" && $scope.marketingObjective != "LEAD_GENERATION" && $scope.marketingObjective != "OFFER_CLAIMS" && $scope.marketingObjective != "CONVERSIONS"){	
				console.log('other obj exclusing video and app installs');
				if ($scope.callToDirectionValue != '' && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"link_title": $scope.cardHeadline[i]}} }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"link_title": $scope.cardHeadline[i]}} }
					
					);
					}					
					}					
					var link_data1 = {
								"link":  $scope.seeMoreUrl,
                                "message": $scope.textBodyContent,  
								"caption": $scope.displayURLoptional,
                                "call_to_action": {
                                        "type": $scope.callToDirectionValue //"LEARN_MORE"
                                    },
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);  
				}
					
				else{
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i] }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i] }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  $scope.seeMoreUrl,
                                "message": $scope.textBodyContent,  
								"caption": $scope.displayURLoptional,                                
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
				}
			}
			
			else if($scope.marketingObjective == "CANVAS_APP_INSTALLS"){
				$scope.audiTarget = $window.localStorage.getItem("campaignAudienceTarget");
				console.log('canvas app obj spec');
				if ($scope.callToDirectionValue != '' && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: "https://apps.facebook.com/" + $scope.audiTarget, image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"application": $scope.audiTarget, "link": "https://apps.facebook.com/" + $scope.audiTarget, "link_title": $scope.cardHeadline[i]}} }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: "https://apps.facebook.com/" + $scope.audiTarget, picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"application": $scope.audiTarget, "link": "https://apps.facebook.com/" + $scope.audiTarget, "link_title": $scope.cardHeadline[i]}} }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  "https://apps.facebook.com/" + $scope.audiTarget,
                                "message": $scope.textBodyContent,  								
                                "call_to_action": {
                                        "type": $scope.callToDirectionValue,
										"value": {
												  "application": $scope.audiTarget,
												  "link": "https://apps.facebook.com/" + $scope.audiTarget
												  
												 }
                                    },
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);  
				}
					
				else{
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i] }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i] }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  "https://apps.facebook.com/" + $scope.audiTarget,
                                "message": $scope.textBodyContent,                                  
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
				}
			}
			
			else if($scope.marketingObjective == "VIDEO_VIEWS"){
				console.log('video views object story specs');
				var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					console.log('video selected');
					child_attachments.push(
					{picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], video_id: $scope.selectedImagegalleryArrayVideo[i] });
					}
					
					var link_data1 = {								
                                "message": $scope.textBodyContent, 
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
			}
					

			else if($scope.marketingObjective == "LINK_CLICKS"){
					
				console.log('traffic objective spec');
				if ($scope.callToDirectionValue != '' && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					if($scope.radioDestination == "WEBSITEURL"){
					console.log('website url selected');
								for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
								
								if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
									{
									console.log('image selected');
								child_attachments.push(
								
								{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], call_to_action: {type: $scope.callToDirectionValue} }
								
								);
								}
								else{
									console.log('video selected');
									child_attachments.push(
								
								{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue} }
								
								);
								}					
								}
								
								var link_data1 = {
											"link":  $scope.seeMoreUrl,
											"message": $scope.textBodyContent,  
											"caption": $scope.displayURLoptional,
											"attachment_style": "link",
											"call_to_action": {
													"type": $scope.callToDirectionValue //"LEARN_MORE"
												},
											"multi_share_end_card": false,
											"multi_share_optimized": false
												
								}
					}
					else{
					
						console.log('messenger selected');
						for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
								
							if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
									{
									console.log('image selected');
								child_attachments.push(
								
								{link: "https://fb.com/messenger_doc/", image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], call_to_action: {type: $scope.callToDirectionValue, "value":{					"app_destination": "MESSENGER"}} }								
								);
								}
								else{
									console.log('video selected');
								child_attachments.push(								
								{link: "https://fb.com/messenger_doc/", picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue, "value":{"app_destination": "MESSENGER"}} }
								);
								}					
								}
								
								var link_data1 = {
											"link":  "https://fb.com/messenger_doc/",
											"message": $scope.textBodyContent,  
											"caption": $scope.displayURLoptional,
											"attachment_style": "link",
											"call_to_action": {
													"type": $scope.callToDirectionValue, //"LEARN_MORE"
													"value":{
														"app_destination": "MESSENGER"
													}
												},
											"page_welcome_message": $scope.messengertextBodyContent
												
								}
						
					
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);  
				}
					
				else{
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i] }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i] }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  $scope.seeMoreUrl,
                                "message": $scope.textBodyContent,  
								"caption": $scope.displayURLoptional,
								"attachment_style": "link",                                
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
				}
			
			}

				
			else if($scope.marketingObjective == "LEAD_GENERATION"){
				console.log('lead generation obj spec');
				if ($scope.callToDirectionValue != '' && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: "http://fb.me/", image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"lead_gen_form_id": $scope.selectLeadForm}} }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: "http://fb.me/", picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue, "value": {"lead_gen_form_id": $scope.selectLeadForm}} }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  "http://fb.me/",
                                "message": $scope.textBodyContent,  								
                                "call_to_action": {
                                        "type": $scope.callToDirectionValue, //"LEARN_MORE"
										"value": {
												  "lead_gen_form_id": $scope.selectLeadForm
												 }
                                    }									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);  
				}
			}
			
				
			else if($scope.marketingObjective == "OFFER_CLAIMS"){
				console.log('offer claims obj');
				var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					console.log('Image selected');
					child_attachments.push(
					{link: $window.localStorage.getItem("OfferRedemptionLink"), image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], call_to_action: {type: "GET_OFFER_VIEW"} });
					
					}
					
					var link_data1 = {	
								"link" : $window.localStorage.getItem("OfferRedemptionLink"),
                                "message": $scope.textBodyContent, 
								"call_to_action": {
								   "type": "GET_OFFER_VIEW"
								},
								"offer_id": $scope.campaignAudienceCampaignOffer
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
			}
				
				
			
			else if($scope.marketingObjective == "CONVERSIONS"){	
				console.log('conversions obj spec');
				if ($scope.callToDirectionValue != '' && $scope.callToDirectionValue != undefined && $scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], call_to_action: {type: $scope.callToDirectionValue} }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: $scope.callToDirectionValue} });
					}					
					}
					
					var link_data1 = {
								"link":  $scope.seeMoreUrl,
                                "message": $scope.textBodyContent,  
								"caption": $scope.displayLink,
								"attachment_style": "link",
                                "call_to_action": {
                                        "type": $scope.callToDirectionValue //"LEARN_MORE"
                                    }
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);  
				}
					
				else{
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					
					if($scope.selectedImagegalleryArray[i].indexOf('png') != -1 || $scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: $scope.cardwebURL[i], image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i] }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: $scope.cardwebURL[i], picture: $scope.selectedImagegalleryArray[i], name: $scope.cardHeadline[i], description: $scope.cardDescription[i], video_id: $scope.selectedImagegalleryArrayVideo[i] }
					
					);
					}					
					}

					var link_data1 = {
								"link":  $scope.seeMoreUrl,
                                "message": $scope.textBodyContent,  
								"caption": $scope.displayLink,
								"attachment_style": "link"
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
				}
			}
				
				var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,                    
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields"
                            
                };
				
				 if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
					
					
					 $http({
                method: 'POST',
                url: apiTPBase + '/createadcreative',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {

                if (response.data.appStatus == 0) {
					$scope.mainLoader = "none";                   
                    $scope.adCreativeId = response.data.adCreativeId;                  
                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.browselibraryPopupHeading = "Browse Library";
                    $scope.browselibrarySuccessMsg = "successfully uploaded";
                    $scope.createAd();
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();                    
                    $scope.browselibrary = "none";
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
					angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                }
                else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                    $scope.showMediaErrorPopup(response);
					angular.element($('.btnCampaignCreative').prop('disabled', true));					
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");                    
                }
            });  
					
			}
			
		}
		
	
//Carousel video file upload

$scope.getCampaignVideoFilesCarousel = function (element) {
			$rootScope.progressLoader = 'block';            
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = element.files[0];
            });
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('source',element.files[0]);
			
			
            if (typeof (element.files[0]) == "object") {
               
                $http({
                    method: 'POST',
                    url: apiTPBase + '/createadvideo',
					data: parameters,
					transformRequest: angular.identity,
					headers: {
						'Content-Type': undefined,
						'dataType': 'jsonp',
						'async': 'false'
					}
                    
                }).then(function (response) {
                    //console.log(response);
					$scope.mainLoader = "none";
                    if (response.data.appStatus == '0') {
                        $scope.newvideoID = response.data.adVideoId;
                        console.log($scope.newvideoID);
						$scope.callGetadvideosCarousel($scope.newvideoID);
						angular.element($('body').css("overflow-y", "scroll"));
						angular.element($('#fbVideopopup').css("display","none"));
                       
                    } else {
                        console.log("failed $scope.getCampaignVideoFiles");
						$scope.showErrorPopup(response.data);
						$scope.mainLoader = "none";
                    }
                });



            }
        };	
		
		
		$scope.callGetadvideosCarousel = function(newvideoID){
            console.log('getvideocarousel');
            var modalErr = $(".video_error_popup_carousel");
			angular.element($('body').css("overflow-y", "scroll"));
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID ;
                $scope.mainLoader = "block";
                $http({
                    method: 'GET',
                    url: apiTPBase + '/getadvideos?' + queryStr,
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
                                    $scope.pictureFormat = adVideoID.format;
                                    $scope.videoStatus = adVideoID.status;
                                    angular.forEach( $scope.pictureFormat,function(ulrVal){
                                        if(ulrVal.filter == "native"){
                                            $scope.imageURLValue = ulrVal.picture;
                                            $scope.slideShowSource = adVideoID.source;
											
											$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.imageURLValue;	
											$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.imageURLValue);
											$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.slideShowSource);
											$scope.showVideoPrev[$scope.uploadimgcount] = true;
											$scope.selectedImagePush.push($scope.hashVal);
											$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
											console.log($scope.uniqueImageSelectionArray);
											
											$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
											$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
											console.log($scope.selectedImagegalleryArray);	
                                        }
                                    });
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';
                        $scope.checkCreatedVideoStatusCarousel(newvideoID);
                    } 
                });
            
            },0);

        }
		
		
		$scope.checkCreatedVideoStatusCarousel = function(newvideoID){
            $scope.newvideoID = newvideoID;
            if($scope.videoStatus){
                if($scope.videoStatus.video_status == "ready"){
					console.log('video upload success');
                    console.log($scope.newvideoID+"|"+$scope.imageURLValue);
					$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.imageURLValue;	
					$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.imageURLValue);
					$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.newvideoID);
					$scope.showVideoPrev[$scope.uploadimgcount] = true;
					$scope.selectedImagePush.push($scope.hashVal);
					$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
					console.log($scope.uniqueImageSelectionArray);
					
					$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
					$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
					console.log($scope.selectedImagegalleryArray);	
                    //$scope.creativeAdCreative($scope.newvideoID+"|"+$scope.slideShowSource);
                }else if($scope.videoStatus.video_status == "error"){
                    $scope.popupTitle = 'Error';
                    $scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                }else{
                    $scope.popupTitle = 'Video Status Error';
                    $scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                    //$scope.callGetadvideos(newvideoID);
                }			
            }			
        }
		 
$scope.tabs = [{
    title: '1'
},
{
title: '2'
}];


 $timeout(function () {		
		if($scope.tabs.length == 2){
		console.log($scope.tabs.length);
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
		}
	},1000);
		


$scope.removeTab = function($index) {

	if($scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
	}
	else{

    console.log("Removing tab: " + $index);
	$scope.cardHeadline[$index] = "";
	$scope.cardDescription[$index] = "";
	$scope.cardwebURL[$index] = "";	
	$scope.selectedImagegalleryArray.splice($index, 1); 
   $scope.tabs.splice($index, 1);	
	$scope.leftStyle1 = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) - 42;
	console.log($scope.leftStyle1);
	$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",$scope.leftStyle1);	
	for(i=0;i<$scope.tabs.length;i++){
			$scope.tabs[i].title = (i+1);
	}
	if($scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock2 .removeCard').css("display", "none"));
	}
	}
     
  };

  $scope.addTab = function($index) {
    var len = $scope.tabs.length + 1;
    var numLbl =  len;

    if(numLbl <=10){
	$scope.cardHeadline[numLbl-1] = "";
	$scope.cardDescription[numLbl-1] = "";
	$scope.cardwebURL[numLbl-1] = "";
	$scope.showImgPrev[numLbl-1] = false;
	$scope.showVideoPrev[numLbl-1] = false;
	
	$scope.leftStyle = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) + 42;
	//console.log($scope.leftStyle);
	$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",$scope.leftStyle);
	
	 $scope.tabs.push({
      title: numLbl     
	  
    });
       
	for(i=0;i<$scope.tabs.length;i++){
			$scope.tabs[i].title = (i+1);		
			angular.element($('.cards-content '+'#contentBlock'+i+' .removeCard').css("display", "block"));
				
	}
    
    }
  };
  
  
  $scope.cardSelection = function(index){	
  
	var len = $scope.tabs.length + 1;
	var len1 = $scope.tabs.length - 1;
    var numLbl =  len;
	
	if(index == numLbl - 2 && index !=2){	
		
		//$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","420px");
		if(index == 3){
			$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","185px");
		}
		else if(index == 4){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","230px");}
		else if(index == 5){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","265px");}
		else if(index == 6){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","312px");}
		else if(index == 7){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","355px");}
		else if(index == 8){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","392px");}
		else if(index == 9){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","436px");}
		
	}
  
		 $timeout(function () {
		//console.log($('#contentBlock'+index+' .cardContainer .mediaBlock').height());
		var imgSelector = $('#contentBlock'+index+' .cardContainer .mediaBlock').height();
		if(imgSelector > 500){
			$scope.mediaarrow = false;
			$scope.cardarrow = true;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		else{
			$scope.mediaarrow = true;
			$scope.cardarrow = false;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		},300);
		
  	}

	//Carousel advent code end
		//ENABLE SLIDESHOW POPUP
	    $scope.onSlideshowSuccess = false;
		$scope.onCreateSlideShow=false;
		$scope.addSlideshow=true;
		$scope.previewSlideShowImage = false;
		$scope.previewSlideShowVideo = false;
		$scope.displaySelectedImages=false;
		$scope.displaySelectedVideos=false;
		$scope.displaySelectedImagesBtn = true;
		$scope.displaySelectedVideosBtn=false;
		$scope.aspectRatioOptions = [
		
			{	
				"id":"Original",
				"name":"Original "	
			},
			{	
				"id":"Square",
				"name":"Square (1:1)"	
			},
			{	
				"id":"Rectangle",
				"name":"Rectangle (16:9)"	
			},
			{	
				"id":"Vertical",
				"name":"Vertical (2:3)"	
			}
		]
		
		$scope.imageDurationOptions = [
		
			{	
				"id":"0.5 seconds",
				"value":"500",
                "key":"0.5"				
			},
			{	
				"id":"1 seconds",
				"value":"1000",
                "key":"01"				
			},
			{	
				"id":"2 seconds",
				"value":"2000"	,
				"key":"02"				
			},
			{	
				"id":"3 seconds",
				"value":"3000",
				"key":"03"								
			},
			{	
				"id":"4 seconds",
				"value":"4000",
				"key":"04"				
			},
			{	
				"id":"5 seconds",
				"value":"5000",
                "key":"05"				
			}
		]
		
	
	$scope.musicOptions = [
		
			{	
				"id":"None",
				"name":"None"	
			},
			{	
				"id":"Chillwave",
				"name":"Chillwave"	
			},
			{	
				"id":"Dreamy",
				"name":"Dreamy"	
			},
			{	
				"id":"Timelapse",
				"name":"Timelapse"	
			},
			{	
				"id":"Space Trip",
				"name":"Space Trip"	
			},
			{	
				"id":"Dance",
				"name":"Dance"	
			},
			{	
				"id":"Workday",
				"name":"Workday"	
			},
			{	
				"id":"Longboard",
				"name":"Longboard"	
			},
			{	
				"id":"Jazzy Samba",
				"name":"Jazzy Samba"	
			},
			{	
				"id":"Electric Coconut",
				"name":"Electric Coconut"	
			},
			{	
				"id":"Action",
				"name":"Action"	
			},
			{	
				"id":"Happy Zone",
				"name":"Happy Zone"	
			},
			{	
				"id":"Garage Groove",
				"name":"Garage Groove"	
			},
			{	
				"id":"Blues Country",
				"name":"Blues Country"	
			},
			{	
				"id":"Wonder",
				"name":"Wonder"	
			},
			{	
				"id":"Wonder",
				"name":"Wonder"	
			},
			{	
				"id":"Homecoming",
				"name":"Homecoming"	
			},
			{	
				"id":"Good Memories",
				"name":"Good Memories"	
			},
			{	
				"id":"Swamp",
				"name":"Swamp"	
			}
			
		]
		$scope.enableSlideShow = function(){
			  if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
			$scope.showSlideShowBrowser =true;
			$scope.aspectRatio = "Original";
			$scope.imageDuration = "1000";
			$scope.slideShowTransition="none";
			$scope.musicValue = "None";
			$scope.onCreateSlideShow=true;
            $scope.createSlideShowBrowser = true;
			var slideshowpopup = $(".creativeSlideShow");
		    slideshowpopup.show();
			angular.element($('body').css("overflow-y", "hidden"));
			
		}
		
		$scope.selectAspectRatio = function(selectedRatio){
			
				console.log(selectedRatio);
				
		}
		$scope.durationToBeDisplayed = [];
		$scope.selectImageDuration = function(selectedDuration){
			
			angular.forEach($scope.imageDurationOptions,function(getID){
				if(selectedDuration == getID.value){		
					$scope.displayTime = getID.key;
				}				
			})

			console.log($scope.displayTime );			
            var display = 0;
	if($scope.displaySelectedImages){
			
			if($scope.selectedSlideShowImages.length != 0){
			$scope.durationToBeDisplayed = [];
			
			for(i=0;i<$scope.selectedSlideShowImages.length;i++){
			
				display = parseFloat(display) + parseFloat($scope.displayTime);
				var sampleVal = parseFloat(display.toFixed(2));
				console.log(sampleVal);
				if(sampleVal <= 9) {
				 sampleVal = "0:0"+sampleVal;	
				}else{
					sampleVal = "0:"+sampleVal;	
				}
				console.log(sampleVal);
				$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
				 console.log($scope.durationToBeDisplayed);
			  } 			
			}else{
				$scope.durationToBeDisplayed = [];
                 $scope.displayTime = 1;				
				for(i=0;i<$scope.selectedSlideShowImages.length;i++){
				
					display = parseFloat(display) + parseFloat($scope.displayTime);
					var sampleVal = parseFloat(display.toFixed(2));
					console.log(sampleVal);
					if(sampleVal <= 9) {
					 sampleVal = "0:0"+sampleVal;	
					}else{
						sampleVal = "0:"+sampleVal;	
					}
					console.log(sampleVal);
					$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
					 console.log($scope.durationToBeDisplayed);
				  }				
			}
	}
	else if($scope.displaySelectedVideos){
			
			if($scope.selectedSlideShowVideos.length != 0){
			$scope.durationToBeDisplayed = [];
			
			for(i=0;i<$scope.selectedSlideShowVideos.length;i++){
			
				display = parseFloat(display) + parseFloat($scope.displayTime);
				var sampleVal = parseFloat(display.toFixed(2));
				console.log(sampleVal);
				if(sampleVal <= 9) {
				 sampleVal = "0:0"+sampleVal;	
				}else{
					sampleVal = "0:"+sampleVal;	
				}
				console.log(sampleVal);
				$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
				 console.log($scope.durationToBeDisplayed);
			  } 			
			}else{
				$scope.durationToBeDisplayed = [];
                 $scope.displayTime = 1;				
				for(i=0;i<$scope.selectedSlideShowVideos.length;i++){
				
					display = parseFloat(display) + parseFloat($scope.displayTime);
					var sampleVal = parseFloat(display.toFixed(2));
					console.log(sampleVal);
					if(sampleVal <= 9) {
					 sampleVal = "0:0"+sampleVal;	
					}else{
						sampleVal = "0:"+sampleVal;	
					}
					console.log(sampleVal);
					$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
					 console.log($scope.durationToBeDisplayed);
				  }				
			}
 }
		//	$scope.createSlideshow(); 
			
				
		}
		
		$scope.selectMusic=function(selectedMusic){
			
			console.log(selectedMusic);
		}
	
	
		$scope.cancelSlideShow = function(){
			 $scope.showSlideShowBrowser =false;
			 $scope.addSlideshow=true;
			 $scope.createSlideShowBrowser = false;
			 $scope.showSelectImages = false;
			 $scope.showSelectVideos = false;
			 $scope.selectedSlideShowImages=[];
			 $scope.durationToBeDisplayed=[];
			 $scope.selectedImages=[];
			 $scope.selectedVideos=[];
			 $scope.selectedSlideShowVideos=[];
			 $scope.onCreateSlideShow=false;
			 $scope.previewSlideShowVideo=false;
			 $scope.previewSlideShowImage=false;
			 $scope.displaySelectedImagesBtn = true;
		      $scope.displaySelectedVideosBtn=false;
			 angular.element($('body').css("overflow-y", "scroll"));
		}
		$scope.slideShowBrowserImage=[];
		$scope.getSlideShowImageBrowser = function(){

		console.log($scope.slideShowBrowser);
		$scope.displaySelectedImages=true;
		$scope.displaySelectedVideos=false;
		$scope.displaySelectedImagesBtn = true;
		$scope.displaySelectedVideosBtn=false;
		$scope.selectedSlideShowVideos=[];
		$scope.selectedVideos=[];
		$scope.durationToBeDisplayed =[];
		 $rootScope.progressLoader = "block";              
			
            $scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));    
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
			
			
			var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
            $http({
                method: 'GET',
                url: apiTPBase + '/getadimages?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
						$scope.showSelectImages = true;
						$scope.showSelectVideos = false;
						var addImagesPopup = $(".selectImagesSlideshow");
						addImagesPopup.show();
						angular.element($('body').css("overflow-y", "scroll"));
						$rootScope.progressLoader = "none"; 
					
						$scope.mainLoader = "none";
						var arrAdAccountCreativeallData = [];
						
					 angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.slideShowBrowserImage = s_images;
                                    }

                                }

                            }
                        }
                    });
                    $scope.slideShowImageArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");


                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;

                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
		     
		}
		
		$scope.cancelAddImages = function(){
			
			$scope.showSelectImages = false;
			$scope.selectImageDuration($scope.imageDuration);
			angular.element($('body').css("overflow-y", "scroll"));
			
		}
		$scope.selectedImages = [];
		$scope.selectedSlideShowImages =[];
		
		$scope.getSelectedImages=function(image){
			console.log(image);
			if(image.Selected){
				if($scope.selectedImages.indexOf(image) == -1){
				      $scope.selectedImages.push(image);						
				}
				
			}else{				
				$scope.selectedImages.splice($scope.selectedImages.indexOf(image),1);
			}
			
		}
			
		$scope.addSlideShowImages = function(){
			
			console.log("Add Images");
			console.log($scope.selectedSlideShowImages);
			$scope.selectedSlideShowImages=angular.extend($scope.selectedSlideShowImages,$scope.selectedImages);
			//$scope.selectedSlideShowImages= $scope.selectedImages;
			$scope.showSelectImages = false;
			$scope.selectImageDuration($scope.imageDuration);
	
			
			angular.element($('body').css("overflow-y", "scroll"));
		}
		
		
		$scope.addMoreSlideShowImages=function(){
			if($scope.selectedSlideShowImages.length > 0){
				$scope.showSelectImages = true;	
				$scope.showSelectVideos =false;
			}else if($scope.selectedSlideShowVideos.length > 0){
				$scope.showSelectVideos =true;
				$scope.showSelectImages = false;	
			}
			
			$timeout(function() {			
				return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
			});
			
		}
		
		$scope.deleteSelectedImg = function(image){
			if($scope.selectedSlideShowImages){
					$scope.selectedSlideShowImages.splice($scope.selectedSlideShowImages.indexOf(image),1);
					$timeout(function() {			
						return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
					});			
					$scope.selectImageDuration($scope.imageDuration);		
			}
			if($scope.selectedSlideShowVideos){
					$scope.selectedSlideShowVideos.splice($scope.selectedSlideShowVideos.indexOf(image),1);
					$timeout(function() {			
						return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
					});			
					$scope.selectImageDuration($scope.imageDuration);		
				
			}
		
		}
		
		 $scope.uploadSlideShowImage = function (uploadedFiles) {
             console.log(uploadedFiles);
		
		      $rootScope.progressLoader = 'block';
               
                angular.element($('.btnCampaignCreative').prop('disabled', false));			
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                $scope.$apply(function ($scope) {
                    $scope.uploadedfilename = uploadedFiles.files[0];
                });             
                var reader = new FileReader();
                reader.onload = function () {
                    $scope.dataURL = reader.result;
                };
                $timeout(function () {
             
						var parameters = new FormData();
						parameters.append('userId',$window.localStorage.getItem("userId"));
						parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
						parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
						parameters.append('type','IMAGE');
						parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
						parameters.append('imageFile',uploadedFiles.files[0]);

					 if (typeof (uploadedFiles.files[0]) == "object") {
                    $http({													
                        method: 'POST',
                        url: apiTPBase + '/createadimage',
                        data: parameters,
					    transformRequest: angular.identity,
                        headers: {
						'Content-Type': undefined,
						'dataType': 'jsonp',
						'async': 'false'
						}
																	
                    }).then(function (response) {
                        console.log(response);
						$rootScope.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
                            $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                            $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
                            
                                 $scope.getUploadedImage(response.data.adImageDetails.images.bytes.hash, $scope.uploadedfilename);
							  /* var imageObj=
								 {
										"thumbnail_url": $scope.hashVal,
										"url":$scope.hashUrl,
										"id":$scope.uploadedfilename.name,
										Selected:false
								 }
								$scope.slideShowImageArray.push(imageObj);*/
                             
                        }
                        else {
                            console.log('failed $scope.getCampaignfiles');
							$scope.showErrorPopup(response.data);
                           
                        }															
                    });
					
					}
																			
                }, 1000);
                reader.readAsDataURL(uploadedFiles.files[0]);			
              
		 }
		 $scope.getUploadedImage = function(hashVal,uploadedfilename){
			 console.log(hashVal);
			var queryStr1 = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + hashVal;
		
		 $http({
			method: 'GET',
			url: apiTPBase + '/getadimages?' + queryStr1,
			headers: {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			}
		}).then(function (response) {
			console.log(response);
			if (response.status == "200" && response.data.appStatus == '0') {
	
				$scope.mainLoader = "none";
				console.log('image hash servic success');
				
				var JsonObj = response.data.adImages[0];
				 var array = [];
				for (var j in JsonObj) {
					if (JsonObj.hasOwnProperty(j)) {
						array[+j] = JsonObj[j];
						console.log(JsonObj[j].url);
						$scope.imagePreviewSrc[i] = JsonObj[j].url;
						console.log(i);	
	                var imageObj=
					 {
							"thumbnail_url": $scope.imagePreviewSrc[i],
							"url":$scope.imagePreviewSrc[i],
							"id":uploadedfilename.name,
							Selected:false
					 }
					$scope.slideShowImageArray.push(imageObj);

					}
				}
				
			}else{
						if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
							$window.localStorage.setItem("TokenExpired",true);
							$state.go('login');
						}else{
							$rootScope.progressLoader = "none";
							$scope.editAdsetErrorMsg = 'block';
							if(response.networkError!='' && response.networkError!=undefined){
								$scope.errorpopupHeading = response.networkError.error_user_title;
								$scope.errorMsg = response.networkError.error_user_msg;

								$scope.errorpopupHeading = 'Error';
								$scope.errorMsg = response.networkError.message;
							}else{
								$scope.errorpopupHeading = 'Error';
								$scope.errorMsg = response.errorMessage;
							}
						}
					}
			});
													
			 
		 }
		  $scope.pictureFormat = [];
		  $scope.getSlideshowVideos = function(){
			  
	   	 // var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") +"&adVideoId="+$scope.slideshowID;
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
		    $rootScope.progressLoader = 'block';
		$timeout(function(){

		var promises = [];		  
        var queryStr = '/getadvideos?userNetworkMapId=' +  $window.localStorage.getItem("userNetworkMapId")  + "&adAccountId="+ $scope.networkAdAccountId +"&videoId="+$scope.slideshowID ;
		var headerVal = {
			headers: {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			}
		};
		promises.push(apiService.getTp(queryStr,headerVal).then(function(resp){  		
			 if (resp.appStatus == 0) {
					   $scope.mainLoader = "none";
                      console.log(resp);		                				  
					 angular.forEach(resp.adVideos,function(key,value){
					  	angular.forEach(key,function(adVideoID){
							if($scope.slideshowID == adVideoID.id){	
							     $scope.pictureFormat = adVideoID.format;	
								 $scope.videoStatus = adVideoID.status;
                                 angular.forEach( $scope.pictureFormat,function(ulrVal){
                                 	if(ulrVal.filter == "native"){
                                 		$scope.imageURLValue = ulrVal.picture;
								        $scope.slideShowSource = adVideoID.source;
                                 	}
                                 })
							}
					  	})
					})
					$scope.slideShowSuccess=true;
					$scope.slideShowCreate=false;
				    $scope.generateSlideshowPreview(resp);								
                }
                else {
                    console.log('failed');
                    if(resp.appStatus > 0 && (resp.errorMessage=='Access token is invalid or expired' || resp.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(resp.networkError!='' && resp.networkError!=undefined){
                            $scope.errorpopupHeading = resp.networkError.error_user_title;
                            $scope.errorMsg = resp.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = resp.errorMessage;
                        }
                    }
                } 
		}));		 
		  	  $q.all(promises).finally(function(){   
				  console.log("PROMISE");
				  console.log(promises);
			      $rootScope.progressLoader = 'none';	
				 $scope.checkCreatedSlideStatus();
             });
	  },0);

		  }
		   $scope.checkCreatedSlideStatus = function(){			
	                			
					 if($scope.videoStatus){			
									if($scope.videoStatus.video_status == "ready"){			
											$scope.creativeAdCreative($scope.slideshowID);                			
								}else if($scope.videoStatus.video_status == "error"){
											angular.element($('body').css("overflow-y", "scroll"));	
                                            $scope.popupTitle = 'Error';
											$scope.popupMessage = "Video Status Error";
											angular.element($('body').css("overflow-y", "hidden"))
											var modalErr = $(".error_popup");
											modalErr.show();											
											return ;			
									}else{			
											  $scope.getSlideshowVideos();                                                			
									}			
					}			
	        }
		  $scope.generateSlideshowPreview = function(response){
				 angular.forEach(response.adVideos,function(key,value){
					  	angular.forEach(key,function(adVideoID){			
							if($scope.slideshowID == adVideoID.id){	
							     $scope.iFrameValue = adVideoID.format;								   
                                 angular.forEach( $scope.iFrameValue ,function(ulrVal){
                                 	if(ulrVal.filter == "native"){                                 		
											$scope.video_Source = ulrVal.picture;

                                 	}
                                 })					
							}						  		
					  	})									
					})			
				
				 $scope.slideShowPreview =  $scope.video_Source; 
				 $scope.slideshowGIF =  $scope.video_GIF;
                  //  $scope.slideShowPreview = {src: $scope.video_Source, title: "Desktop Preview"};
					$scope.slideShowCreate = false ;
					$scope.slideShowSuccess = true;
		  }
		  $scope.imageURL = [];
		 $scope.createImageSlideShow = function(){
			 
			 console.log($scope.selectedSlideShowImages);
			 console.log($scope.imageDuration);
			 console.log($scope.slideShowTransition);
			  $scope.imageURL =[];
			 if($scope.selectedSlideShowImages.length > 0){
				 	angular.forEach($scope.selectedSlideShowImages,function(images){
						if(images.url.includes("?")){							
						   	$scope.splicedVal = images.url.slice(0,images.url.indexOf("?"));
							if($scope.imageURL.indexOf($scope.splicedVal) == -1){							
							       $scope.imageURL.push($scope.splicedVal);
						   }
						}else{						
						   if($scope.imageURL.indexOf(images.url) == -1){							
							       $scope.imageURL.push(images.url);
						   }					   
						}							  
			     }) 
			 }
			 if($scope.selectedSlideShowVideos.length > 0){
				 $scope.imageURL =[];
				 	angular.forEach($scope.selectedSlideShowVideos,function(images){
						$scope.videoURL = images.picture.slice(0,images.picture.indexOf("?"));
						if($scope.imageURL.indexOf($scope.videoURL) == -1){
							$scope.imageURL.push($scope.videoURL);
						}						
			     })					 
			 }
		   
			     var parameters = {
					"userId": $window.localStorage.getItem("userId"),
					"accessToken": $window.localStorage.getItem("accessToken"),
					"userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
					"adAccountId":$window.localStorage.getItem("networkAdAccountId"),
					"slideShowSpec":{
							"images_urls":$scope.imageURL,
							"duration_ms": $scope.imageDuration,
							"transition_ms": 200
						
					    }
                };
			  
		
		  var promises = [];
		  promises.push($http({
              method: 'POST',
                url: apiTPBase + '/createadslideshow',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function(response){            
					 if (response.data.appStatus == 0) {
					console.log(response);
					$scope.slideshowID = response.data.adVideoId;
					//$scope.creativeAdCreative(response.data.adVideoId); 
					$scope.showSlideshowSuccessPopup();					
                }
                else {
                    console.log('failed');
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                } 
          }));
		  $q.all(promises).finally(function(){   
				  console.log("PROMISE");
				  console.log(promises);
				
			     // $scope.getSlideshowVideos();
             });

		 }
	  $scope.showSlideshowSuccessPopup = function () {
            //console.log('success popup here123');
			$scope.onSlideshowSuccess = true;
			$scope.showSlideShowBrowser=false;
            $scope.popupTitle = "Slideshow Creation";
            $scope.popupMessage = "Slideshow created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup1");
            successReq.show();

        }
        $scope.closeSlideshowSuccessPopup = function () {
			$scope.onSlideshowSuccess = false;
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup1");
            $scope.networkErrorPopup = 'none';
            successReq.hide();
			$scope.getSlideshowVideos();
			
		    
			$scope.showSlideShowBrowser=false;
		
        }

		
		$scope.createSlideshow = function(){

			$scope.myInterval = parseInt($scope.imageDuration);
		    $scope.activeSlide=0;
			$timeout(function() {
			
				return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
			});
				$scope.addSlideshow=false;
			if($scope.selectedSlideShowImages.length != 0){
				
			$scope.previewSlideShowImage = true;	
			$scope.previewSlideShowVideo = false;
			$scope.createImageSlideShow();
			}
			if($scope.selectedSlideShowVideos.length != 0){
				$scope.previewSlideShowImage = false;	
				$scope.previewSlideShowVideo = true;
				$scope.createImageSlideShow();
			}
			
		   
			console.log($scope.selectedSlideShowImages);
			angular.element($('body').css("overflow-y", "scroll"));
		};
		
	 $scope.deleteSelectedSlide = function(){		 
			$scope.slideShowSuccess = false;
			$scope.slideShowCreate = true;	
	}
                $scope.onDropComplete = function (index, obj, evt) {
                  
					if($scope.selectedSlideShowImages.length > 0){
						var otherObj = $scope.selectedSlideShowImages[index];
						var otherIndex = $scope.selectedSlideShowImages.indexOf(obj);
						$scope.selectedSlideShowImages[index] = obj;
						$scope.selectedSlideShowImages[otherIndex] = otherObj;
						console.log($scope.selectedSlideShowImages);
					}
					if($scope.selectedSlideShowVideos.length > 0){
						   var otherObj = $scope.selectedSlideShowVideos[index];
							var otherIndex = $scope.selectedSlideShowVideos.indexOf(obj);
							$scope.selectedSlideShowVideos[index] = obj;
							$scope.selectedSlideShowVideos[otherIndex] = otherObj;
							console.log($scope.selectedSlideShowVideos);	
					}
                }   
				
				
		$scope.slideShowVideoArray=[]
		$scope.getSlideShowVideoBrowser = function(){

		$scope.displaySelectedImages=false;
		$scope.displaySelectedVideos=true;
		$scope.displaySelectedImagesBtn = false;
		$scope.displaySelectedVideosBtn=true;
        $scope.selectedSlideShowImages=[];
		$scope.selectedImages=[];	
		$scope.durationToBeDisplayed =[];		
		   if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
			$rootScope.progressLoader = "block";
	       
		   var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
            
            $http({
                method: 'GET',               
                url: apiTPBase + '/getadvideos?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                console.log(response);
                
                 $scope.browseVideoArray = [];
                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    $scope.mainLoader = "none";	
                    $scope.browseVideoArray = response.data.data;
				
                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
                 $scope.slideShowVideoArray = arrAdAccountCreativeallDataVideo;
				$scope.showSelectImages = false;
				$scope.showSelectVideos = true;
				var addVideosPopup = $(".selectVideosSlideshow");
				addVideosPopup.show();
				angular.element($('body').css("overflow-y", "hidden"));
				
					
		}  
		else {
							console.log('failed');
							if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
								$window.localStorage.setItem("TokenExpired",true);
								$state.go('login');
							}else{
								$rootScope.progressLoader = "none";
								$scope.editAdsetErrorMsg = 'block';
								if(response.data.networkError!='' && response.data.networkError!=undefined){
									$scope.errorpopupHeading = response.data.networkError.error_user_title;
									$scope.errorMsg = response.data.networkError.error_user_msg;
								}else{
									$scope.errorpopupHeading = 'Error';
									$scope.errorMsg = response.data.errorMessage;
								}
							}
						}		
                        
                $rootScope.progressLoader = "none";
               
                //$scope.existVideosList = response.data.adVideos;
            });
		}
		
		
			$scope.selectedSlideShowVideos= [];
			$scope.selectedVideos = [];
			
			
			$scope.getSelectedVideos=function(video){
				console.log(video);
				if(video.Selected){
					$scope.selectedVideos.push(video);					
				}else{				
					$scope.selectedVideos.splice($scope.selectedVideos.indexOf(video),1);
				}
		
		 }
			$scope.addSlideShowVideos = function(){
			
				console.log("Add Videos");
				console.log($scope.selectedSlideShowVideos);
			//	$scope.selectedSlideShowVideos= $scope.selectedVideos;		
				$scope.selectedSlideShowVideos= angular.extend($scope.selectedSlideShowVideos,$scope.selectedVideos);				
				$scope.showSelectVideos = false;
				$scope.selectImageDuration($scope.imageDuration);
				angular.element($('body').css("overflow-y", "scroll"));
		  }
	
		$scope.cancelAddVideos= function(){
			
			$scope.showSelectVideos = false;
			$scope.selectImageDuration($scope.imageDuration);
			angular.element($('body').css("overflow-y", "scroll"));
			
		}
		
		
			
		 $scope.uploadSlideShowVideo = function (element) {
		   $rootScope.progressLoader = 'block';
            var parameters = new FormData();
            parameters.append('userId',$window.localStorage.getItem("userId"));
            parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
            parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
            parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
            parameters.append('source',element.files[0]);

            if (typeof (element.files[0]) == "object") {                

                $http({
                    method: 'POST',
                    url: apiTPBase + '/createadvideo',
                    data: parameters,
                    transformRequest: angular.identity,
                    headers: {
                            'Content-Type': undefined,
                            'dataType': 'jsonp',
                            'async': 'false'
                    }
                }).then(function (response) {

                    if (response.status == "200") {
                        $scope.newvideoID = response.data.id;
                        $scope.getUploadedvideos(response.data.id);                      
                    } else {
                        console.log("failed $scope.getCampaignVideoFiles");
						$scope.showErrorPopup(response.data);
                    }

                });
				
            }
		
		 }
		 $scope.getUploadedvideos = function(newvideoID){
			 console.log(newvideoID);
			 var modalErr = $(".video_error_popup");
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID ;
                $scope.mainLoader = "block";
                $http({
                    method: 'GET',
                    url: apiTPBase + '/getadvideos?' + queryStr,
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
								    $scope.pictureFormat = adVideoID.format;										
                                    $scope.videoStatus = adVideoID.status;									
								     if($scope.videoStatus){
										if($scope.videoStatus.video_status == "ready"){
											
												angular.forEach($scope.pictureFormat,function(ulrVal){
												if(ulrVal.filter == "native"){
													var videoObj=
																 {
																		"picture":ulrVal.picture,
																		"id":adVideoID.id,
																		Selected:false
																 }
																 $scope.slideShowVideoArray.push(videoObj);
																 console.log($scope.slideShowVideoArray);
											
												}
											});
										}else if($scope.videoStatus.video_status == "error"){
											$scope.popupTitle = 'Error';
											$scope.popupMessage = "Video Status Error";
											angular.element($('body').css("overflow-y", "hidden"))
											var modalErr = $(".error_popup");
											modalErr.show();
										}else{
											$scope.popupTitle = 'Video Status Error';
											$scope.popupMessage = "processing error, would you like to continue...";
											angular.element($('body').css("overflow-y", "hidden"))
											var modalErr = $(".video_error_popup");
											modalErr.show();
											
										}			
									}
                                
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';                     
                    } 
					
                });
            
            },0);
		 }
		
		 
		 
	
    }]); 
	

	//Directive code


 dashboard.directive('compileHtml',
  function() {
    return {
      restrict: 'A',
      templateUrl: '../CNAP_UI_Repo/app/modules/dashboard/views/fbcreativecarousel-directive.html'
    };
  }
);  

