dashboard.controller("campaigncontroller", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$window', 'appSettings', '$sce', '$timeout',
function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $window, appSettings, $sce, $timeout) {


 $scope.secondActiveDiv = 'yes';
 
 $scope.firstActiveDivImg = true;
    $scope.secondActiveDivImg = false;
    $scope.thirdActiveDivImg = false;
    $scope.fourthActiveDivImg = false;
    $scope.fifthActiveDivImg = false;
    $scope.select_market = false;
    $scope.cancelbutton = true;
    
   
      
    
            //-------------------------------------
$scope.import_keywords=function()
{
    var modaledit_currency = $(".campaign__keyword");// Get the modal Reject req
            modaledit_currency.show();
            $scope.Edit_currency_rate=true;
            
};

$scope.close=function()
{
    var modaledit_currency = $(".twittercampaignaudience-popup");// Get the modal Reject req
            modaledit_currency.hide();
            //$scope.Edit_currency_rate=true;
            
};

$scope.import_keywords = function()
{
    $scope.usernames = false;
    $scope.keywords = true;
    $scope.show = false;
    
    
    $scope.campaignaudience_cancelbtn = true;
    $scope.campaignaudience_submitbtn = true;
    $scope.campaignaudience_saveandexitbtn = false;
    $scope.campaignaudience_verifyusernamebtn = false;
     $scope.campaignaudience_verifyshowbtn = false;
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup");
    modalcampaignaudience.show();
    
};

$scope.import_username = function()
{
    $scope.usernames = true;
    $scope.keywords = false;
    $scope.show = false;
   
    $scope.campaignaudience_verifyusernamebtn = true;
     $scope.campaignaudience_cancelbtn = true;
    $scope.campaignaudience_saveandexitbtn = false;
    $scope.campaignaudience_submitbtn = false;
     $scope.campaignaudience_verifyshowbtn = false;
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup");
    modalcampaignaudience.show();
};

$scope.import_shows = function()
{
    $scope.usernames = false;
    $scope.keywords = false;
    $scope.show = true;
     $scope.saveandexit = false;
   
    $scope.campaignaudience_verifyusernamebtn = false;
     $scope.campaignaudience_cancelbtn = true;
    $scope.campaignaudience_saveandexitbtn = false;
    $scope.campaignaudience_submitbtn = false;
    $scope.campaignaudience_verifyshowbtn = true;
    
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup");
    modalcampaignaudience.show();
};


$scope.exit_campaign = function()
{
    $scope.usernames = false;
    $scope.keywords = false;
    $scope.show = false;
    $scope.saveandexit = true;
   
    $scope.campaignaudience_verifyusernamebtn = false;
     $scope.campaignaudience_cancelbtn = true;
    $scope.campaignaudience_saveandexitbtn = true;
    $scope.campaignaudience_submitbtn = false;
    $scope.campaignaudience_verifyshowbtn = false;
    
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup");
    modalcampaignaudience.show();
};
$scope.browse_interests = function()
{
    $scope.usernames = false;
    $scope.keywords = false;
    $scope.show = false;
    $scope.saveandexit = false;
    $scope.browseinterests = true;
     $scope.browseandselectevent = false;
    
    
    $scope.campaignaudience_verifyusernamebtn = false;
     $scope.campaignaudience_cancelbtn = false;
    $scope.campaignaudience_saveandexitbtn = false;
    $scope.campaignaudience_submitbtn = false;
    $scope.campaignaudience_verifyshowbtn = false;
    $scope.campaignaudience_donebtn = true;
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
    modalcampaignaudience.show();
    
};

$scope.browse_andselectevent= function()
{
  
     $scope.browseandselectevent = true;
    
    
  
    $scope.campaignaudience_donebtn = true;
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
    modalcampaignaudience.show();
    
};

$scope.browse_categories= function()
{
  
     $scope.browsecategories = true;
    
    
  
    $scope.campaignaudience_donebtn = true;
    
    var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
    modalcampaignaudience.show();
    
};




 
$scope.limit_targeting=function()
{
    $scope.select_market = $scope.select_market ? false: true;
    
};
 

if($window.localStorage.getItem("marketingObjective")=='POST_ENGAGEMENT'){
        $scope.PlacementsArr = {
            "data" : 
            [
                {
                    "name" : "User's Timeline",
                    "id" : "mobilenewsfeed",
                    "pic" : "fa fa-clock-o"
                },
                {
                    "name" : "Search Results",
                    "id" : "instagram",
                    "pic" : "fa fa-clock-o"
                },
                {
                    "name" : "Profile Pages",
                    "id" : "desktopnewsfeed",
                    "pic" : "fa fa-file-image-o"
                }
               
            ]
        };
   }
  
  
  
//pop up
//
                //BROWSE INTERESTS
        $scope.setInit = function(){
            angular.forEach($scope.parentCompaign, function(value, key){
                    angular.element('#tab'+(key+1)).css('outline', 'none')
            });
            
	};
        
        $scope.toggleTab = function(_obj, _this) {
          
               $scope.rightHtmlData =  $scope.rightContent[_obj];
               angular.forEach($scope.rightContent, function(value, key){
                       
                       console.log('#tab',key+1)
			angular.element('#tab'+(key+1)).css('background','#f3f3f3');
			angular.element('#tab'+(key+1)).css('border-left-color','#e4e4e4');
			angular.element('#tab'+(key+1)).css('outline', 'none')
		}  );
			
		angular.element('#tab'+(_obj+1)).css('background','#ffffff');
		angular.element('#tab'+(_obj+1)).css('border-left-color','#ffb75c');
	   
        }
        
        
        $scope.list = [  
      {  
        "list1":"Automotive"
      },
      {  
        "list1":"Beauty"
      },
      {  
         "list1":"Books and Literature"
         
      },
      {  
         "list1":"Business"
       
      },
      {  
         "list1":"Careers"
       
      },
       {  
         "list1":"Education"
       
      },
      {  
         "list1":"Events"
       
      },
      {  
         "list1":"Family and Parenting"
       
      },
      {  
         "list1":"Food and drink"
       
      }
    ];
    
       
        $scope.rightContent = [
        [  
          {  
              "list2":"1"},
          {"list2":"All of automotive"},
            {"list2":"Automotive news and general info"}, 
           { "list2":"Car Culture"},
            {"list2":"Convertibles"},
            {"list2":"Hybrid and electric vehicles"}
          
          
        ],
     
        [
             {"list2":"2"},
            {"list2":"CGP Brands auto2"},
             { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

        ], 
  
         [  
             {"list2":"3"},
            { "list2":"Auto3"},
              { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

         ],
         [
               {"list2":"4"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"5"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
         
         [
               {"list2":"6"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"7"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"8"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"9"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ]
    ];
       // END OF BROWSE INTERESTS
   
   //       BROWSE SELECT EVENTS
   
   
    $scope.setInit = function(){
            angular.forEach($scope.parentCompaign, function(value, key){
                    angular.element('#tab'+(key+1)).css('outline', 'none')
            });
            
	};
        
        $scope.toggleTab = function(_obj, _this) {
          
               $scope.rightHtmlData =  $scope.rightContent_events[_obj];
               angular.forEach($scope.rightContent_events, function(value, key){
                       
                       console.log('#tab',key+1)
			angular.element('#tab'+(key+1)).css('background','#f3f3f3');
			angular.element('#tab'+(key+1)).css('border-left-color','#e4e4e4');
			angular.element('#tab'+(key+1)).css('outline', 'none')
		}  );
			
		angular.element('#tab'+(_obj+1)).css('background','#ffffff');
		angular.element('#tab'+(_obj+1)).css('border-left-color','#ffb75c');
	   
        }
        
        
        $scope.list_event = [  
      {  
        "list1":"Sports"
      },
      {  
        "list1":"Entertainment"
      },
      {  
         "list1":"Holidays"
         
      },
      {  
         "list1":"Conferences"
       
      },
      {  
         "list1":"Other"
       
      },
       {  
         "list1":"Politics"
       
      },
      {  
         "list1":"Events"
       
      },
      {  
         "list1":"Movie Releases"
       
      },
      {  
         "list1":"Recurring Trends"
       
      }
    ];
    
       
        $scope.rightContent_events = [
        [  
          {  
              "list2":"1"},
          {"list2":"1000 Millas Patagonia"},
            {"list2":"104th Grey Cup"}, 
           { "list2":"Lorem Ipsum"},
            {"list2":"Lorem Ipsum"},
            {"list2":"Lorem Ipsum"}
          
          
        ],
     
        [
             {"list2":"2"},
            {"list2":"CGP Brands auto2"},
             { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

        ], 
  
         [  
             {"list2":"3"},
            { "list2":"Auto3"},
              { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

         ],
         [
               {"list2":"4"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"5"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
         
         [
               {"list2":"6"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"7"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"8"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"9"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ]
    ];
   
   //BROWSE CATEGORIES
    $scope.setInit = function(){
            angular.forEach($scope.parentCompaign, function(value, key){
                    angular.element('#tab'+(key+1)).css('outline', 'none')
            });
            
	};
        
        $scope.toggleTab = function(_obj, _this) {
          
               $scope.rightHtmlData =  $scope.rightContent_categories[_obj];
               angular.forEach($scope.rightContent_categories, function(value, key){
                       
                       console.log('#tab',key+1)
			angular.element('#tab'+(key+1)).css('background','#f3f3f3');
			angular.element('#tab'+(key+1)).css('border-left-color','#e4e4e4');
			angular.element('#tab'+(key+1)).css('outline', 'none')
		}  );
			
		angular.element('#tab'+(_obj+1)).css('background','#ffffff');
		angular.element('#tab'+(_obj+1)).css('border-left-color','#ffb75c');
	   
        }
        
        
        $scope.list_categories= [  
      {  
        "list1":"Auto"
      },
      {  
        "list1":"Auto (DLX Auto powered by polk)"
      },
      {  
         "list1":"Business"
         
      },
      {  
         "list1":"CGP Brands"
       
      },
      {  
         "list1":"CGP BusStyles"
       
      },
       {  
         "list1":"CGP categories"
       
      },
      {  
         "list1":"Demographics"
       
      },
      {  
         "list1":"Dining"
       
      },
      {  
         "list1":"Finance"
       
      }
    ];
    
       
        $scope.rightContent_categories = [
        [  
          {  
              "list2":"1"},
          {"list2":"All of Auto"},
            {"list2":"104th Grey Cup"}, 
           { "list2":"Lorem Ipsum"},
            {"list2":"Lorem Ipsum"},
            {"list2":"Lorem Ipsum"}
          
          
        ],
     
        [
             {"list2":"2"},
            {"list2":"CGP Brands auto2"},
             { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

        ], 
  
         [  
             {"list2":"3"},
            { "list2":"Auto3"},
              { "list2":"Luxury"},
            {"list2":"Minivans"},
            { "list2":"Motorcycles"},
             {"list2":"Off road vehicles"},
             {"list2":"performance vehicles"}

         ],
         [
               {"list2":"4"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"5"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
         
         [
               {"list2":"6"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"7"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"8"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ],
        [
               {"list2":"9"},
            {  "list2":"Business"},
            {  "list2":"CGP Brands"}
      
        ]
    ];
 

}]);