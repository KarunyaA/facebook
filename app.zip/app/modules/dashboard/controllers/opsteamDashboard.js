dashboard.controller("OpsteamDashboardController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', 'appSettings','$timeout','apiService',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, appSettings, $timeout, apiService) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;
        var apiTwitterBase = appSettings.apiTwitterBase;
        $scope.bool = [];
        $scope.wholeParentArray = [];
        $scope.wholeArray = [];
        $scope.fbwholechildArray = [];
        $scope.twwholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.currencyList ={};
        $scope.totalTWCampaigns = 0;
        $scope.totalFBCampaigns = 0;
        
        //$scope.editAdsetErrorMsg = 'none';
        //$rootScope.progressLoader = "block";
        
        
        
        $scope.searchAdvertiserDetails = function () {
            $rootScope.progressLoader = "block";
            
            $http({
                method: 'GET',
                url: apiBase + '/user/searchuser?searchedUserId=' + $scope.searchAdvertiser,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.userType = response.data.searchedUser.userRole;
                    if ($scope.userType == "Advertiser") {
                        $scope.advertiserId = response.data.advertiserId;
                        //$scope.responseData = response;
                        //$scope.editablePanel = "advertiser";
                        $window.localStorage.setItem("advertiserId",$scope.advertiserId);
                        $scope.fetchAdvertiserDetails($scope.advertiserId);
                    }
                } else {// failed
                        $rootScope.progressLoader = "none";
                }
            });

        }
        $scope.loadCurrencyCode = function(){
            $http.get("localData/currencyData.json").success(function (data){
                $scope.currencyList = data.currencyList;
                //console.log($scope.currencyList);
            });
        }

        $timeout(function () {
            $scope.init();
        }, 1500);

        $scope.downloadAccountLogo = function (accountLogoUrl) {
            $rootScope.progressLoader = "block";
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths": [accountLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer + '/downloadimages',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (response) {                
                if (response.data.appStatus == '0' && advertiserLogoUrl != undefined) {
                    $rootScope.progressLoader = "none";
                    //console.log(resp.data.imageContent[advertiserLogoUrl]);
                    $scope.accountLogo = response.data.imageContent[$scope.accountLogoUrl];
                }else{
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
                
            });
        }

        $scope.getAdvertiserDetails = function () {
            $rootScope.progressLoader = "block";
            //$scope.accountId = "100003"  // need to change from service integration
            $http({
                method: 'GET',
                url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.advertiserDetails = response.data.advDataFetchResponse;
                    angular.forEach($scope.advertiserDetails, function (val, key){
                if($scope.advertiserDetails[key].advertiserId == $window.localStorage.getItem("advertiserId")){
                    $scope.advertiserLogoUrl = $scope.advertiserDetails[key].logoUrl;
                    $scope.downloadAdvertiserLogo($scope.advertiserLogoUrl)
                }
            });
                    $scope.getAdvertiserIdfromopsteam();

                } else {// failed
                    $rootScope.progressLoader = "none";
                    //console.log("failed");
                    //console.log(response);
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
            }
            });
        }
        //$scope.getAdvertiserDetails();
        
        
        //get advertiser id from ops team data fetch
        $scope.getAdvertiserIdfromopsteam = function () {
            $rootScope.progressLoader = "block";
            //$scope.accountId = "100003"  // need to change from service integration
            $http({
                method: 'GET',
                url: apiBase + '/user/opsteamdatafetch?opsteamId=' + $window.localStorage.getItem("OpsTeamId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.opsteamdetails = response.data.fetchOpsteamResponse;
                    $scope.advertiserId=$scope.opsteamdetails.advertiserId;
                    //console.log($scope.advertiserId);
                    $window.localStorage.setItem("advertiserId",$scope.advertiserId);
                    $scope.allnetworks();//getting all networks

                } else {// failed
                    $rootScope.progressLoader = "none";
                    //console.log("failed");
                    //console.log(response);
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
            }
            });
        }
        
        
        $scope.downloadAdvertiserLogo = function(advertiserLogoUrl, loopKey){
            //alert(advertiserLogoUrl);
            $rootScope.progressLoader = "block";
            $scope.advertiserLogo = [];
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths" : [advertiserLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer+'/downloadimages',
                data : parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function(response) {
                //console.log(response);
                if (response.data.appStatus == '0' && advertiserLogoUrl != undefined) {
                    $rootScope.progressLoader = "none";
                    //console.log(resp.data.imageContent[advertiserLogoUrl]);
                    $scope.advertiserLogo[loopKey] = response.data.imageContent[advertiserLogoUrl];
                }else{
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
                
            });
        }

        $scope.allnetworks = function () {
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + "/user/fetchallnetwork",
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    //console.log('in all networks')
                    $scope.allnetworksarray = response.data.networkList;
                    $scope.networksforacc();//getting networks for all account
                } else {
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }

        //FETCHADVERTISERNETWORK
        $scope.networksforacc = function () {
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    //console.log('in fetchadvnetwoks')
                    $scope.networksarrayforacc = response.data.advertiserNetworkList;
                    //console.log($scope.networksarrayforacc)
                    for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                        angular.forEach($scope.allnetworksarray, function (val, key) {
                            if ($scope.networksarrayforacc[i].networkId == val.networkId) {
                                $scope.networksarrayforadvertiser.push(val);
                            }
                        });
                        //console.log($scope.networksarrayforadvertiser)
                        //console.log('going to my function')
                        $scope.checkNetworkforadvertiser();
                    }
                    $scope.selectadvertiser();
                } else {
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }


        $scope.checkNetworkforadvertiser = function () {
            //console.log('fetchadvertisra')
            $scope.networkforadv = true;
            $scope.networksarrayforadvertiser = [];

            for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                //console.log('inside for loop')
                angular.forEach($scope.advertiserDetails, function (val, key) {
                    //console.log('inside angular for each')
                    if ($window.localStorage.getItem("advertiserId") == val.advertiserId) {
                        //console.log('frst check')
                        if (val.advertiserEmail == $scope.networksarrayforacc[i].userId) {
                            //console.log('second check')
                            $scope.networkid = $scope.networksarrayforacc[i].networkId;
                            angular.forEach($scope.allnetworksarray, function (val, key) {
                                if ($scope.networkid == val.networkId) {                                    
                                    $scope.networksarrayforadvertiser.push(val);
                                    $scope.userNetworkMapId = $scope.networksarrayforacc[i].userNetworkMapId;
                                    $scope.readadAccountId($scope.userNetworkMapId);
                                }
                            });


                        }
                    }
                });
            }

        }


        $scope.readadAccountId = function (networkMapID) {
            //alert('ji');
            $rootScope.progressLoader = "block";
            var promises = [];

            //FOR FB
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccounts?networkMapId=' + $window.localStorage.getItem("userNetworkMapId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {
                        $scope.fbadaccountid = response.data.fbReadAdAccountResponse[key].fbAdAccountId;
                        //alert($scope.fbadaccountid);
                        $scope.fbcurrency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                        $scope.readFBaccoutnInsights();
                    });
                    angular.forEach($scope.currencyList, function(value, key) {
                        if($scope.currencyList[key].currency == $scope.fbcurrency){
                            $scope.fbcurrencyCode = $scope.currencyList[key].currencyCode;
                        }
                    });
                    
                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });

            //FOR TW
            $http({
                method: 'GET',
                url: appSettings.apiTwitterBase + '/readadaccounts?userNetworkMapId=' + $window.localStorage.getItem("twUserNetworkMapId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adAccounts, function (value, key){
                        var JsonObj1 = response.data.adAccounts[key];
                        var array = [];          
                        for(var kk in JsonObj1) {
                            $scope.twadaccountid = JsonObj1[kk].twAdAccountId;
                            $scope.readTWaccoutnInsights();
                            var module1 = '/readadfundinginstruments?userNetworkMapId=' + $window.localStorage.getItem("twUserNetworkMapId");
                            var header1 = {
                                headers: {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                }
                            };
                            promises.push(apiService.getTwr(module1,header1).then(function(res){
                                angular.forEach(res.fundingInstruments, function(v, k){
                                    var JsonObj = res.fundingInstruments[key];
                                    var array = [];          
                                    for(var twi in JsonObj) {
                                        $scope.twcurrency = JsonObj[twi].twFundingInstrumentDetails.currency;
                                        angular.forEach($scope.currencyList, function(value, key) {
                                            if($scope.currencyList[key].currency == $scope.twcurrency){
                                                $scope.twcurrencyCode = $scope.currencyList[key].currencyCode;
                                            }
                                        });
                                    }
                                });


                            }));
                        }

                    });     

                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });
            

        };
        
        $scope.selectadvertiser = function () {
            $rootScope.progressLoader = "block";
            $scope.wholeParentArray = [];
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchparentcampaignsbyadvertiser?advertiserId=' + $window.localStorage.getItem("advertiserId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.campaigndetails = response.data.parentCampaigns;
                    for (var i = 0; i < $scope.campaigndetails.length; i++) {
                        var _obj = {
                            "id": $scope.campaigndetails[i].parentCampaignId,
                            "name": $scope.campaigndetails[i].parentCampaignName,
                            "type": "parent"
                        }
                        $scope.wholeParentArray.push(_obj);
                    }
                    //getting child campaigns
                    angular.forEach($scope.wholeParentArray, function (val, key) {
                        $scope.fetchFBChildAndPush(val.id);
                        $scope.fetchTWChildAndPush(val.id);
                    });
                    //$scope.readadAccountId();

                }
                else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }
            });
        }
        
        $scope.readTWaccoutnInsights = function(){
            //alert('hii123');
		var promises= [];		
		var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&adAccountId=' + $window.localStorage.getItem("twNetworkAdAccountId");
             var module = apiTwitterBase+"/readadaccountsinsights" + "?" + queryStr
             var header = {
                 headers: {
                     'userId': $window.localStorage.getItem("userId"),
                     'accessToken': $window.localStorage.getItem("accessToken")
                 }
             };
             promises.push(apiService.getTwitterPoint(module, header).then(function(response) {
                //console.log(response);
                if (response.appStatus == 0) {                 
                    angular.forEach(response.adAccountInsights, function (value, key) {
                        //alert($scope.twadaccountid);
                        if(response.adAccountInsights[key][$scope.twadaccountid].spend!==0){
                            $scope.twAccountspend = response.adAccountInsights[key][$scope.twadaccountid].spend;
                        }else{
                            $scope.twAccountspend=0;
                        }
                        var lastSyncDate = response.adAccountInsights[key][$scope.twadaccountid].modifiedOn;
                        $scope.lastSyncDate = lastSyncDate; 


                    });

                } else {
                     //failed 
                     if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                         $window.localStorage.setItem("TokenExpired", true);
                         $state.go('login');
                     } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                     }

                     $rootScope.progressLoader = "none";
                }

             }));
			 $q.all(promises).finally(
			 function() {
			  
			 }); 
	}

        $scope.fetchFBChildAndPush = function (_id) {
            $rootScope.progressLoader = "block";
            $scope.fbwholechildArray = [];
            queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "parentCampaignId=" + _id;
            $http({
                method: 'GET',
                url: apiTPBase + "/readadcampaign" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log(response);
                var index = 0;
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    $scope.childCampaigns = response.data.adcampaigns;
                    var count = 0;
                    angular.forEach($scope.childCampaigns, function (value, key) {
                        var JsonObj = $scope.childCampaigns[key]
                        var array = [];
                        for (var j in JsonObj) {
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                array[+j] = JsonObj[j];
                                var _obj = {
                                    "id": array[+j].campaignId,
                                    "name": array[+j].campaignDetails.name,
                                    "type": "child",
                                    "parentid": _id
                                }
                                count++;
                                $scope.fbwholechildArray.push(_obj);

                            }
                        }
                    });
                    if($scope.fbwholechildArray.length!=0)
                    {
                        $scope.totalFBCampaigns = $scope.fbwholechildArray.length;
                    }
                    //console.log($scope.totalFBCampaigns);

                } else {
                    $rootScope.progressLoader = "none";
                    //console.log('readadcampaign failed');
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }
        
        $scope.fetchTWChildAndPush = function (_id) {
            $rootScope.progressLoader = "block";
            $scope.twwholechildArray = [];
            queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "parentCampaignId=" + _id;
            $http({
                method: 'GET',
                url: apiTwitterBase + "/readcampaign" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                var index = 0;
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    $scope.childCampaigns = response.data.campaign;
                    var count = 0;
                    angular.forEach($scope.childCampaigns, function (value, key) {
                        var JsonObj = $scope.childCampaigns[key]
                        var array = [];
                        for (var j in JsonObj) {
                            var _obj = {
                                "id": JsonObj[j].twCampaignId,
                                "name": JsonObj[j].twCampaignDetails.name,
                                "type": "child",
                                "parentid": _id
                            }
                            count++;
                            $scope.twwholechildArray.push(_obj);
                        }
                    });
                    if($scope.twwholechildArray.length!=0)
                    {
                        $scope.totalTWCampaigns = $scope.twwholechildArray.length;
                    }
//                    console.log($scope.totalTWCampaigns);

                } else {
                    $rootScope.progressLoader = "none";
                    //console.log('readadcampaign failed');
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }
        

	$scope.init = function () {
		
            $rootScope.progressLoader = "block";
            //$scope.advertiserDetails = {};
            //$scope.adverDetails =[];
            $http({
                method: 'GET',
                url: apiBase + '/user/getaccountdetails?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
				
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.accountName = response.data.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                    $scope.downloadAccountLogo($scope.accountLogoUrl);
                    $scope.getAdvertiserDetails();
                    $scope.loadCurrencyCode();
                } else {// failed
                    $rootScope.progressLoader = "none";
                    //console.log("failed");
                }
            });
            
            //$scope.loadCurrencyCode();
        }

        $scope.readFBaccoutnInsights = function () {
            $scope.accountsadvoverall = true;
            var overall = "overall";
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' + $window.localStorage.getItem("userNetworkMapId") + '&adAccountId=' + $window.localStorage.getItem("networkAdAccountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adadvimpressions = response.data.adAccountInsights[key][$scope.fbadaccountid].impressions;
                        $scope.adadvclicks = response.data.adAccountInsights[key][$scope.fbadaccountid].clicks;
                        if(response.data.adAccountInsights[key][$scope.fbadaccountid].spend!==0){
                            $scope.fbAccountspend = response.data.adAccountInsights[key][$scope.fbadaccountid].spend;
                        }else{
                            $scope.fbAccountspend=0;
                        }
                        $scope.advcallToAction = response.data.adAccountInsights[key][$scope.fbadaccountid].callToAction;
                        var lastSyncDate = response.data.adAccountInsights[key][$scope.fbadaccountid].modifiedOn;                        
                        $scope.lastSyncDate = lastSyncDate.split(" "); 

                    });
                    
                    
                } else {
                    
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });
            
        };


        $scope.closePrevPlanDetails = function(){
            $scope.editAdsetErrorMsg = "none";
        }

    }]);

