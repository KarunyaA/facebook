dashboard.controller("metriccomparisonController", ['$rootScope', '$scope', '$http', '$state', '$filter', '$location', 'dashboardService', 'Flash', '$q', '$window', '$sce', 'appSettings', '$timeout','apiService','performanceServices',
    function ($rootScope, $scope, $http, $state, $filter, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout,apiService,performanceServices) {
        var vm = this;
        
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;
        var fbNetwork = appSettings.fbNetwork;
        $scope.bool = [];
        $scope.networksarrayforacc = [];
        $scope.wholeParentArray = [];
        $scope.wholeParentarraydisp = [];
        $scope.wholeParentarraydisponload = [];
        $scope.wholechildarraydisponload = [];
        $scope.wholeParentArrayOnLoad = [];
        $scope.selectedgrapharray = [];
        $scope.wholeArray = [];
        $scope.wholechildArray = [];
        $scope.wholechildarraydisp = [];
        $scope.wholeChildArrayOnLoad = [];
        $scope.wholemetricArray = [];
        $scope.grapharray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforaccount = [];
        $scope.campaigninsights = [];
        $scope.accinsights = [];
        $scope.networkforadv = false;
        $scope.insightsarr = [];
        $scope.arrayofobj = [];
        $scope.arr1 = [];
        $scope.arr2 = [];
        $scope.networkmaparray = [];
        $scope.plotarray = [];
        $scope.adaccountid =[];
        $scope.advertiserdetails = {};
        $scope.newgraph = 'false';
        $scope.breakpoints = [];
        $scope.defaultmetricArray = [];
        $scope.duplicateplot = [];
        $scope.displaydate=[];
        $scope.allmetrics = [];
        $scope.onloadaccinsights=[];
        $scope.allMetricNamesWithOutDuplicate = [];
       $scope.wholemetricArray1= [];
       $scope.whatToCall = [];
       $scope.selectedcampbool  = false;
       var errorcount=true;
       var errorCompletionStatus=false;
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();   
        });
        
        $scope.setUserIdAndAccessToken = function() {
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.getaccountdetails();
        };
                
        $scope.loadCurrencyCode = function(){
                performanceServices.loadcurrencydata().then(function(response) {
                $scope.currencyList = response.currencyList;
                $scope.setUserIdAndAccessToken();
            });
        };
     /////////////////////////////////////////////////////////////////////  
     
     
        $scope.accountRole = true;
        $scope.networksforaccount = [];
        $scope.structarray = [];
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.networkDropDownOnLoad = [];
        $scope.campaignDropDown = [];
        $scope.error=[];
        var errorHeader = [];
        $scope.errorpopup2Heading="We're sorry something went wrong!";
        var errorString = [];
        var errornetwork =[];
        $scope.toDate = localDateTimetoUTCDateTime(new Date());
        $scope.fromDate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
        var today = new Date();
        $scope.CurDate = today.toISOString().slice(0,10);
        
        
        
   
        
        
        //getting account details on load
        $scope.getaccountdetails = function (){
            
            //checking the user role
            $scope.userRole = $window.localStorage.getItem("role");
            if($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
            {
                $scope.accountRole = false;
            }
            $rootScope.progressLoader = "block";
            var promises = [];
            var getAccountDetailsSuccess = false;
            $scope.accountId = $window.localStorage.getItem("accountId");
            $scope.advertiserDetails = {};
            $scope.adverDetails = [];
            promises.push(performanceServices.getaccountdetails($scope.accountId).then(function (response) {
                if (response.appStatus == '0') {// success
                   // $rootScope.progressLoader = "none";
                    $scope.accountName = response.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.accountFetchResponse.logoUrl;
                    getAccountDetailsSuccess = true;
                } else {
                 //   $rootScope.progressLoader = "none";
                    // failed
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                   //     $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(getAccountDetailsSuccess)
                        {
                            $scope.downloadAccountLogo($scope.accountLogoUrl);
                        }
                        
                    });
        };
        //download accountlogo on load
        $scope.downloadAccountLogo = function (accountLogoUrl){
            var promises = [];
            promises.push(performanceServices.downloadimages(accountLogoUrl).then(function(response){
                if (response.appStatus == '0'){
                //    $rootScope.progressLoader = "none";
                    $scope.accountLogo = response.imageContent[$scope.accountLogoUrl];
                }
                else{
               //     $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                  //      $rootScope.progressLoader = "none";
                      $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.imageContent[$scope.accountLogoUrl].errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
          //              if(downloadImageSuccess)
                        {
                            $scope.getAdvertiserDetails();
                        } 
                        
                    });
        };
        
        
        $scope.loadCurrencyCode();
        
        
        
        
        //getting advertiser details on load
        $scope.getAdvertiserDetails = function (){
           // $rootScope.progressLoader = "block";
            var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {
                  //  $rootScope.progressLoader = "none";
                    // success
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                } 
                else{
                //    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                   //     $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    
                    function(){
                        if(getAdvertiserDetails)
                        {
                            $scope.allnetworks();
//                            $scope.networksforacc();
                        }
                    });
        };
        
        
        
        $scope.allnetworks = function (){
          //  $rootScope.progressLoader = "block";
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response){
                if (response.appStatus == '0') {
                 //   $rootScope.progressLoader = "none";
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                }
                else{
                //    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                  //      $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(allnetworks)
                        {
//                            $scope.allnetworks();
                            $scope.networksforacc();
                        }
                    });
        };
        
        
        
        $scope.networksforacc = function (){
           // $rootScope.progressLoader = "block";
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {
                    // success
                  //  $rootScope.progressLoader = "none";
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                    for (i = 0; i < $scope.networksarrayforacc.length; i++){
                        angular.forEach($scope.allnetworksarray, function (val, key){
                            if ($scope.networksarrayforacc[i].networkId == val.networkId){
                                if(!$scope.networksforaccount.includes(val.networkName)){
                                    var obj = {
                                        "networkName":val.networkName,
                                        "networkId":val.networkId
                                    };
                                    $scope.networksforaccount.push(obj);
                                }
                            }
                        });
                    }
                   
                }
                else{
               //     $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                 //       $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(networksforaccount)
                        {
//                            $scope.allnetworks();
                             $scope.getusernetworkmapids();
                        } 
                    });
        };
        
        
        $scope.getusernetworkmapids = function (){
            var promises = [];
//            console.log($scope.allnetworksarray);
            angular.forEach($scope.advertiserdetails, function (val, key){
                var networkdetailobj=[];
                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){   
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){   
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl
                                };
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.structarray.push(obj);
            });
            
            $scope.error = angular.copy($scope.structarray);
            for (i = 0; i < $scope.structarray.length; i++)
            {
                if ($scope.structarray[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                      //  $rootScope.progressLoader = "block";
                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            promises.push(performanceServices.readadaccounts($scope.structarray[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function(response)
                            {    
                                if(response.appStatus == 0)
                                {
                                 //   $rootScope.progressLoader = "none";
                                    angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
                                    {
                                        var parent = [];
                                        $scope.structarray[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                        $scope.structarray[i].networkDetails[j]["currency"] = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                        $scope.structarray[i].networkDetails[j]["parent"] = parent;
                                        $scope.currency = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                    });
                                    $scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                                }
                                else{
                                   
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                        } else {
                                                  
                                               
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                             errorString.push( response.networkError.message);
                                                    } else {
                                                            errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                        errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage); 
                                                        
                                                }
                                            }
                                }
                            }));
                        }
                        else
                        {
                            promises.push(performanceServices.readadaccounts($scope.structarray[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function(response)
                            {    
                                if(response.appStatus == 0)
                                {
                                 //   $rootScope.progressLoader = "none";
                                    angular.forEach(response.adAccounts, function (value, key) 
                                    {
                                         angular.forEach(value, function (val, key1)
                                         {
                                            var parent = [];
                                            $scope.structarray[i].networkDetails[j]["twAdAccountId"]=val.twAdAccountId;
                                            $scope.structarray[i].networkDetails[j]["parent"] = parent;
                                         });
                                      
                                    });
                                }
                                else{
                                   
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                             } else {
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                              errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                              errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                         errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                        errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage);
                                                        
                                                }                            
                        }
                                }
                            }));
                        }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
//                        console.log("first");
                        //$scope.readaccountinsights();
                        
                            $scope.fillDropDowns();
                        
                     
                    });
        };
        
        
      
        $scope.fillDropDowns = function()
        {
            var promises = [];
            var parentSuccess=false;
//            console.log(JSON.stringify($scope.networkmaparray, null, 2));
            for(i=0;i<$scope.structarray.length;i++)
            {
                var obj = {
                    "advertiserName":$scope.structarray[i].advertiserName,
                    "advertiserId":$scope.structarray[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
            }
    //===========================================================Network Drop Down==================================================================
            var allnetworkswithduplicate = [];
            var allnetworkswithoutduplicate = [];
            var allnetworkswithduplicateobjects = [];
            for(i=0;i<$scope.structarray.length;i++)
            {
                if($scope.structarray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                    {
                        
                            var obj = {
                                "networkId":$scope.structarray[i].networkDetails[j].networkId,
                                "networkName":$scope.structarray[i].networkDetails[j].networkName,
                                "networkURL":$scope.structarray[i].networkDetails[j].networkURL
                            };
                            allnetworkswithduplicate.push($scope.structarray[i].networkDetails[j].networkName);
                            allnetworkswithduplicateobjects.push(obj);
                        
                    }
                }
            }
            allnetworkswithoutduplicate = allnetworkswithduplicate.filter(function(elem, index, self) {
                return index == self.indexOf(elem);
            });
//            console.log(allnetworkswithduplicate);
//            console.log(allnetworkswithoutduplicate);
//            console.log(allnetworkswithduplicateobjects);
            for(i=0;i<allnetworkswithoutduplicate.length;i++)
            {
                var obj = {
                    "networkId":"",
                    "networkName":allnetworkswithoutduplicate[i],
                    "networkURL":""
                };
                $scope.networkDropDown.push(obj);
            }
            $scope.networkDropDownOnLoad = angular.copy($scope.networkDropDown);
            for(i=0;i<$scope.networkDropDown.length;i++)
            {
                for(j=0;j<allnetworkswithduplicateobjects.length;j++)
                {
                    if($scope.networkDropDown[i].networkName == allnetworkswithduplicateobjects[j].networkName)
                    {
                        $scope.networkDropDown[i].networkId = allnetworkswithduplicateobjects[j].networkId;
                        $scope.networkDropDown[i].networkURL = allnetworkswithduplicateobjects[j].networkURL;
                    }
                }
            }
//==============================================================================================================================================           
                for(i=0;i<$scope.structarray.length;i++)
                {
        //                console.log("1");
                    if($scope.structarray[i].hasOwnProperty("networkDetails"))
                    {
        //                    console.log("2");
                        
        //                        console.log("3");
                            (function(i)
                            {
                                        promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.structarray[i].advertiserId).then(function(response)
                                        {
                                            if (response.appStatus == '0') {// success
                                                parentSuccess=true;
                                                $scope.campaigndetails = response.parentCampaigns;
                                                for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                                {
                                                    for (var k = 0; k < $scope.campaigndetails.length; k++){
                                                        var _obj = {
                                                            "id": $scope.campaigndetails[k].parentCampaignId,
                                                            "name": $scope.campaigndetails[k].parentCampaignName,
                                                            "type": "Parent",
                                                            "userNetworkMapId": $scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                            "networkUrl":$scope.structarray[i].networkDetails[j].networkURL
                                                        };
                                                        $scope.wholeParentArray.push(_obj);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                    $window.localStorage.setItem("TokenExpired", true);
                                                    $state.go('login');
                                                } else {
                                       //                 $rootScope.progressLoader = "none";
                                           //     $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                              errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                             errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        //$scope.errorpopupHeading = 'Error';
                                                        errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                        errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage);
                                                }
                                                    }
                                            }
                                        }));
                                    
                                
                            })(i);
                        
                    }
                }
            
            $q.all(promises).finally(
                    function(){
                         
//                        console.log("before fetch child and push");
                         for(a=0;a<$scope.wholeParentArray.length;a++)
                        {
                            for(i=0;i<$scope.structarray.length;i++)
                            {
 //                               console.log("3");
                                if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                {
//                                    console.log("4");
                                    for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                    {
//                                        console.log("5");
                                        (function(i,j,a)
                                        {
//                                            console.log("6");
                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == $scope.wholeParentArray[a].userNetworkMapId)
                                            {
                                                
//                                                    console.log("7");
                                                        if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                                        {
                                                            var child = [];
                                                            var obj = {
                                                                "id":$scope.wholeParentArray[a].id,
                                                                "name":$scope.wholeParentArray[a].name,
                                                                "type":"Parent",
                                                                "child":child
                                                            };
//                                                            console.log($scope.networkmaparray[i].networkDetails[j]);
//                                                            console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                                                            $scope.structarray[i].networkDetails[j].parent.push(obj);
                                                        }
                                               
                                            }
                                        })(i,j,a);
                                    }
                                }
                            }
                        }
                    
                        $scope.fetchallchildandpush();
                  
                    });
        };
        $scope.advertisername= [];
        $scope.fetchallchildandpush = function()
        {
//            console.log("fetch all child and push");
            var promises = [];
            var campaign= false;
            for(i=0;i<$scope.wholeParentArray.length;i++)
            {
                
                (function(i)
                {
                    
                    
                    
               var k=0;
                   for(k;k<$scope.structarray.length;k++)
                        {
                              
                              if($scope.structarray[k].hasOwnProperty("networkDetails"))
                                
                                    {
                                          
                                        for(j=0;j<$scope.structarray[k].networkDetails.length;j++)
                                    {
                                         
                                   for(l=0;l<$scope.structarray[k].networkDetails[j].parent.length;l++)
                                    {
                                        
                                    
                                    if($scope.structarray[k].networkDetails[j].parent[l].id==$scope.wholeParentArray[i].id)
                                        {
                                            
                                           $scope.advertisername[i]= $scope.structarray[k].advertiserName;
                                            
                                        }
                                    
                                    }}
                            }
                        }
                           
                    
                    
                    //checking whether the parent network is Fb or twitter
                    if($scope.wholeParentArray[i].networkUrl == appSettings.fbNetwork)
                    {    
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) {
                            if (response.appStatus == '0') {
                                campaign=true;
                             //   $rootScope.progressLoader = "none";
                                $scope.childCampaigns = response.adcampaigns;
                                var count = 0;
                                angular.forEach($scope.childCampaigns, function (value, key) {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) {
                                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].campaignId,
                                                "name": array[+j].campaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                        }
                                    }
                                });
                            } else {
                               // $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {       //           $rootScope.progressLoader = "none";
                                           //     $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                             errornetwork.push("Facebook");
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.wholeParentArray[i].name );
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                              errornetwork.push("Facebook");
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        errornetwork.push("Facebook");
                                                         errorHeader.push(" Advertiser:<b>"+ $scope.advertisername[i]+ "</b><br> Parent Campaign: <b>"+$scope.wholeParentArray[i].name+"</b>" );
                                                        errorString.push(response.errorMessage);
                                                }
                                    }
                            }
                        }));
                        
                    }    
                    else
                    {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork,undefined).then(function (response) {
                            if (response.appStatus == '0') {
                              //  $rootScope.progressLoader = "none";
                                $scope.childCampaigns = response.campaign;
                                var count = 0;
                                 campaign=true;
                                angular.forEach($scope.childCampaigns, function (value, key) {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].twCampaignId,
                                                "name": array[+j].twCampaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                    }
                                });
                            } else {
                           //     $rootScope.progressLoader = "none";
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                        
                                             //           $rootScope.progressLoader = "none";
                                           //     $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                             errornetwork.push("Twitter");
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.wholeParentArray[i].name );
                                                             errorString.push(response.networkError.message);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                              errornetwork.push("Twitter");
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        errornetwork.push("Twitter");
                                                       errorHeader.push(" Advertiser:<b>"+ $scope.advertisername[i]+ "</b><br> Parent Campaign: <b>"+$scope.wholeParentArray[i].name+"</b>" );
                                                        errorString.push(response.errorMessage);
                                                }
                                    }
                            }
                        }));
                        
                    }
                        
                })(i);
            }
            $q.all(promises).finally(
                    function(){
                       
                        for(a=0;a<$scope.wholechildArray.length;a++)
                        {
                            for(i=0;i<$scope.structarray.length;i++)
                            {
                                
                                if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                {
                                    
                                    for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                    {
                                        
                                        (function(i,j,a)
                                        {
                                          
                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == $scope.wholechildArray[a].userNetworkMapId)
                                            {
                                                if($scope.structarray[i].networkDetails[j].networkURL == $scope.wholeParentArray[i].networkUrl)
                                                {
                                                    //pushing FB campaigns into struct array
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                                        {
                                                            
                                                            for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                            {
                                                                if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid)
                                                                {
                                                                    var obj = {
                                                                            "id":$scope.wholechildArray[a].id,
                                                                            "name":$scope.wholechildArray[a].name,
                                                                            "parentId":$scope.wholechildArray[a].parentid,
                                                                            "type":"Child"
                                                                            };
                                                                        $scope.structarray[i].networkDetails[j].parent[k].child.push(obj);
                                                               }
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    //pushing Twitter campaigns into struct array
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                                        {
                                                            
                                                            for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                            {
                                                                if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid)
                                                                {
                                                                    var obj = {
                                                                            "id":$scope.wholechildArray[a].id,
                                                                            "name":$scope.wholechildArray[a].name,
                                                                            "parentId":$scope.wholechildArray[a].parentid,
                                                                            "type":"Child"
                                                                            };
            //                                                            console.log($scope.networkmaparray[i].networkDetails[j]);
            //                                                            console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                                                                        $scope.structarray[i].networkDetails[j].parent[k].child.push(obj);
                                                               }
                                                            }
                                                        }
                                                 
                                                } 
                                            }
                                        })(i,j,a);
                                    }
                                }
                            }
                        }
                        
                        console.log($scope.structarray);
                       //updatin the campaign dropdown on load
                       for(i=0;i<$scope.structarray.length;i++)
                            {
                                if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                    {
                                        //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                        {
                                            if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                            {
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.structarray[i].networkDetails[j].parent[k].id,
                                                            "name":$scope.structarray[i].networkDetails[j].parent[k].name,
                                                            "type":"Parent"
                                                            };
                                                        $scope.wholeParentArrayOnLoad.push(obj);
                                                    }
                                            }
                                        }    
                                    }
                                }
                            }
                       
                       for(i=0;i<$scope.structarray.length;i++)
                            {
                                if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                    {
                                            if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                            {
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        if($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty("child"))
                                                        {
                                                            for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                {
                                                                    var obj = {
                                                                        "id":$scope.structarray[i].networkDetails[j].parent[k].child[l].id,
                                                                        "name":$scope.structarray[i].networkDetails[j].parent[k].child[l].name,
                                                                        "type":"child",
                                                                        "parentid":$scope.structarray[i].networkDetails[j].parent[k].id
                                                                        };
                                                                    $scope.wholeChildArrayOnLoad.push(obj);
                                                                }
                                                        }
                                                        
                                                    }
                                            }
                                    }
                                }
                            }
                      $scope.wholeParentArray = [];
                      $scope.wholechildArray = [];
                      $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
                      $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
                      
                      //getting allaccount insights on load
                      $scope.allaccountinsightsonload();
                      
                      //getting allcampaign insights on load
                      $scope.allcampaigninsightsonload();
                
                    });
        };
        //////////////////////////////////////////////////////////////////
        
        $scope.allaccountinsightsonload = function()
        {
            $scope.progressLoader="block";
            var promises = [];
               //getting account insights on load
                        for (i = 0; i < $scope.structarray.length; i++){
                                if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                            
                                            (function(i,j)
                                            {
                                            if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                {
                                                    //getting fb ad account insights on load
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                                    {
                                                         $scope.breakdown = "DAILY";
                                                         console.log("getting fb account insights");
                                                            $scope.breakpoints = [];
                                                            $scope.wholemetricArray = [];
                                                            $scope.grapharray=[];
                                                            
                                                            if($scope.breakdown == "DAILY")
                                                            {
                                                                
                                                                $scope.displaydate=[];
                                                                //getting dates between corresponding selected start and end values
                                                                 date1 = new Date($scope.fromDate);
                                                                 date2 = new Date($scope.toDate);
                                                                 var day = 1000 * 60 * 60 * 24;
                                                                 var diff = (date2.getTime() - date1.getTime()) / day;
                                                                 for (var i1 = 0; i1 <= diff; i1++)
                                                                 {
                                                                     var xx = date1.getTime() + day * i1;
                                                                     var yy = new Date(xx);

                                                                     var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                     var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                     $scope.breakpoints.push(d2);
                                                                 }
                                                                 for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                {
                                                                     $scope.displaydate.push(new Date($scope.breakpoints[i2]).getDate() + "-" + new Date($scope.breakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                }
                                                                
                                                            }
                                                            promises.push(performanceServices.readadaccountsinsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].adAccountId,$scope.fromDate,$scope.toDate,$scope.breakdown,appSettings.fbNetwork,true).then(function(response)
                                                            {
                                                                 if (response.appStatus == '0') {
                                                                        
                                                                   //  $rootScope.progressLoader = "none";
                                                                     $scope.nograph=false;
                                                                     $scope.innerarray = [];
                                                                     $scope.weekvalue = [];
                                                                     $scope.weeknum=[];
                                                                     $scope.monthnum=[];
                                                                     $scope.quaternum=[];
                                                                     $scope.halfnum=[];
                                                                     $scope.yearnum=[];
                                                                     $scope.date = [];
                                                                     $scope.wholemetricArray1=[];
                                                                     var iden =0;

                                                                     $scope.accountinsights = response.adAccountInsights;
                                                                     angular.forEach($scope.accountinsights, function (value, key) {
                                                                         var JsonObj = $scope.accountinsights[key]
                                                                         var array = [];

                                                                         for (var j1 in JsonObj) {
                                                                             if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                 $scope.innerarray = JsonObj[j1];

                                                                                // console.log($scope.innerarray)
                                                                                 //console.log(totalimpressions)

                                                                                 //converting timestamp to dates
                                                                                 if($scope.breakdown == "DAILY")
                                                                                 {    
                                                                                      for (var timestamp in $scope.innerarray)
                                                                                     {
                                                                                         var timestmp=timestamp.toString();
                                                                                        if(timestmp.length==10)
                                                                                        {
                                                                                            //timestamp is in seconds
                                                                                            //converting to milliseconds
                                                                                            var timest=timestmp.concat("000");
                                                                                           // console.log(timest);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                             timest=timestmp;
                                                                                        }
                                                                                         var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                          //$scope.date.push(date);
                                                                                           $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                                                                     }
                                                                                     //console.log($scope.date);
                                                                                 }
                                                                                 //calculating week number from response
                                                                                 else if($scope.breakdown == "WEEKLY")
                                                                                 {
                                                                                     for (var weeknum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=weeknum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.weeknum.push(parts);
                                                                                                $scope.getdatesfromweeknum(weekno,year);
                                                                                         }
                                                                                       //   console.log($scope.weeknum);
                                                                                 }
                                                                                 //calculating month number from response
                                                                                 else if($scope.breakdown == "MONTHLY")
                                                                                 {
                                                                                     for (var monthnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=monthnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.monthnum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating quarter number from response
                                                                                 else if($scope.breakdown == "QUARTERLY")
                                                                                 {
                                                                                     for (var quaternum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=quaternum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.quaternum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating half-yearly number from response
                                                                                 else if($scope.breakdown == "HALFYEARLY")
                                                                                 {
                                                                                     for (var halfnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=halfnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.halfnum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating yearly number from response
                                                                                 else if($scope.breakdown == "YEARLY")
                                                                                 {
                                                                                     for (var yearnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=yearnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                $scope.yearnum.push(parts);
                                                                                         }
                                                                                 }

                                                                                 // traversing into the object to get insights
                                                                                 angular.forEach($scope.innerarray, function (value, key) {
                                                                                      var id1 = 1;

                                                                                     $scope.hasinsightdetails=false;
                                                                                     $scope.wholemetricArray1=[];
                                                                                     $scope.wholemetricname=[];
                                                                                     $scope.arrayofobj = [];
                                                                                     $scope.parentmetricarray = [];
                                                                                     $scope.insightsarr = [];
                                                                                     $scope.arr1 = [];
                                                                                     $scope.arr2 = [];
                                                                                     var totalclicks = 0;
                                                                                     var totalimpressions = 0;
                                                                                     var totalspend = 0;
                                                                                     var totalactions = 0;
                                                                                     var t = $scope.innerarray[key];

                                                                                     for (var k1 in t)
                                                                                     {
                                                                                         if (k1 == "clicks")
                                                                                         {
                                                                                             totalclicks+=t.clicks;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalclicks,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);

                                                                                         }
                                                                                         if (k1 == "impressions")
                                                                                         {
                                                                                             totalimpressions+=t.impressions;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalimpressions,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);
                                                                                         }

                                                                                         if (k1 == "spend")
                                                                                         {
                                                                                              totalspend+=t.spend;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalspend,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);
                                                                                         }
                                                                                         if (k1 == "callToAction")
                                                                                         {

                                                                                              totalactions+=t.callToAction;
                                                                                             var obj = {
                                                                                                 "name": "actions",
                                                                                                 "value": totalactions,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push("actions");
                                                                                         }

                                                                                         if (k1 == "insightsDetails")
                                                                                         {
                                                                                             $scope.hasinsightdetails=true;
                                                                                             $scope.insightsarr = t.insightsDetails;

                                                                                         }
                                                                                     }
                                                                             //        
                                                       //                      if( breakdown == "DAILY")
                                                       //                      {       
                                                                                 for (k in $scope.insightsarr)
                                                                                     {
                                                                                         //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                                                                         var obj;
                                                                                         function traverse(jsonObj, category) {
                                                                                             if (typeof jsonObj == "object") {
                                                                                                 $.each(jsonObj, function (k, v) {
                                                                                                     if (k == category) {
                                                                                                         if (typeof v == "object")
                                                                                                         {
                                                                                                             angular.forEach(v, function (key1, value1) {
                                                                                                                 $scope.arrayofobj.push(key1);
                                                                                                                 $scope.parentmetricarray.push(k);
                                                                                                             });
                                                                                                         }
                                                                                                         else
                                                                                                         {
                                                                                                             if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                                                                             {

                                                                                                             }
                                                                                                             else
                                                                                                             {
                                                                                                                 var t = 0;
                                                                                                                 var newchar = ' '
                                                                                                                 k = k.split('_').join(newchar);
                                                                                                                 var obj = {
                                                                                                                     "name": k,
                                                                                                                     "value": v,
                                                                                                                     "id": id1++,
                                                                                                                     "disabled": "false"
                                                                                                                 }
                                                                                                                 $scope.wholemetricArray1.push(obj);
                                                                                                                 $scope.wholemetricname.push(k);
                                                                                                             }
                                                                                                         }

                                                                                                     } else {
                                                                                                         traverse(v, category);
                                                                                                     }

                                                                                                 });
                                                                                             }
                                                                                             else {
                                                                                                 // jsonOb is a number or string
                                                                                             }
                                                                                         }
                                                                                         traverse($scope.insightsarr, k)
                                                                                        // console.log(obj)
                                                                                         $scope.keyvalue = obj;
                                                                                     }
                                                                                   //  console.log($scope.arrayofobj);
                                                                                     angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                                                                         var parentmetric=$scope.parentmetricarray[value1];
                                                                                                         var childmetric=key1.action_type;
                                                                                                         var newchar = ' '
                                                                                                         parentmetric = parentmetric.split('_').join(newchar);
                                                                                                         childmetric = childmetric.split('_').join(newchar);
                                                                                                         childmetric = childmetric.split('.').join(newchar);
                                                                                                 var obj = {
                                                                                                          "name": parentmetric +" - "+ childmetric,
                                                                                                          "value":key1.value,
                                                                                                          "id": id1++,
                                                                                                          "disabled": "false"
                                                                                                         }

                                                                                             $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                                                                        //     console.log(obj);
                                                                                           $scope.arr2.push(obj);

                                                                                     });
                                                                                     for (var i1 = 0; i1 < $scope.arr2.length; i1++) {
                                                                                       // console.log($scope.arr2[i]);
                                                                                         $scope.wholemetricArray1.push($scope.arr2[i1]);
                                                                                     }
                                                                                        if($scope.breakdown == "DAILY")
                                                                                        {
                                                                                         var obj1 = {
                                                                                             "date": $scope.date[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }  
                                                                                          $scope.grapharray.push(obj1);
                                                                                         }
                                                                                         else if($scope.breakdown == "WEEKLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.weeknum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);

                                                                                         } 
                                                                                         else if($scope.breakdown == "MONTHLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.monthnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                         else if($scope.breakdown == "QUARTERLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.quaternum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         }  
                                                                                         else if($scope.breakdown == "HALFYEARLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.halfnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                         else if($scope.breakdown == "YEARLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.yearnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                 });
                                                                             }
                                                                         }
                                                                        //  console.log($scope.wholemetricArray);
                                                                     });
                                                                    $scope.onloadaccinsights=  $scope.grapharray;
                                                                    $scope.plotarray = [];
                                                                    $scope.arr1=[];
                                                 //                   console.log($scope.wholemetricArray1);
                                                                 }
                                                                 else {//failed
                                                            //         $rootScope.progressLoader = "none";
                                                                     if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                                                                         $window.localStorage.setItem("TokenExpired",true);
                                                                         $state.go('login');
                                                                     }
                                                                     else{
                                                               //          $rootScope.progressLoader = "none";
                                                                      //       $scope.editAdsetErrorMsg = 'block';
                                                                            if (response.networkError != '' && response.networkError != undefined) {
                                                                              if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                                 $scope.errorpopupHeading = 'Error';
                                                                                   errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                                                // $scope.errorMsg = response.networkError.message;
                                                                                  errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                                               errorString.push(response.networkError.message);
                                                                             } else {
                                                                                 $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                                   // $scope.errorMsg = response.networkError.error_user_msg;
                                                                                     errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                                                    errorHeader.push(response.networkError.error_user_title);
                                                                                      errorString.push(response.networkError.error_user_msg);
                                                            
                                                                                 }
                                                                                } else {
                                                                                     $scope.errorpopupHeading = 'Error';
                                                                                    // $scope.errorMsg = response.errorMessage;
                                                                                      errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                                                     errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                                                     errorString.push(response.errorMessage);
                                                                     }
                                                                     }

                                                                         $scope.nograph=true;
                                                                        // $scope.metricselect = [];
                                                                     //}
                                                                 }
                                                           }));

                                                    }
                                                }
                                                else
                                                {
                                                    console.log("getting twitter account insights");
                                                     //getting twitter ad account insights on load
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty('twAdAccountId'))
                                                    {
                                                         $scope.breakdown = "DAILY";
//                                                         $scope.readtwitteradaccountInsightsforlastweek($scope.fromDate, $scope.toDate, $scope.breakdown, $scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                    
                                                            $scope.twbreakpoints = [];
                                                            $scope.twwholemetricArray = [];
                                                            $scope.twgrapharray=[];
                                                            $scope.twwholemetricname = [];       
                                                            if($scope.breakdown == "DAILY")
                                                            {
                                                                $scope.twdisplaydate=[];
                                                                //getting dates between corresponding selected start and end values
                                                                 date1 = new Date($scope.fromDate);
                                                                 date2 = new Date($scope.toDate);
                                                                 var day = 1000 * 60 * 60 * 24;
                                                                 var diff = (date2.getTime() - date1.getTime()) / day;
                                                                 for (var i1 = 0; i1 <= diff; i1++)
                                                                 {
                                                                     var xx = date1.getTime() + day * i1;
                                                                     var yy = new Date(xx);

                                                                     var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                     var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                     $scope.twbreakpoints.push(d2);
                                                                 }
                                                              //  console.log($scope.breakpoints);
                                                                 for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                {
                                                                     $scope.twdisplaydate.push(new Date($scope.twbreakpoints[i2]).getDate() + "-" + new Date($scope.twbreakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                }
                                                               // console.log($scope.displaydate);
                                                            }
                                                            promises.push(performanceServices.readadaccountsinsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].twAdAccountId,$scope.fromDate,$scope.toDate,$scope.breakdown,appSettings.twNetwork,true).then(function(response)
                                                            {    
                                                                if(response.appStatus == 0)
                                                                {
                                                                     //   $rootScope.progressLoader = "none";
                                                                        $scope.nograph=false;
                                                                        $scope.innerarray = [];
                                                                        $scope.weekvalue = [];
                                                                        $scope.weeknum=[];
                                                                        $scope.monthnum=[];
                                                                        $scope.quaternum=[];
                                                                        $scope.halfnum=[];
                                                                        $scope.yearnum=[];
                                                                        $scope.date = [];
                                                                        var iden =0;

                                                                        $scope.accountinsights = response.adAccountInsights;
                                                                        angular.forEach($scope.accountinsights, function (value, key) {
                                                                                var JsonObj = $scope.accountinsights[key]
                                                                                var array = [];
                                                                                
                                                                                for (var j1 in JsonObj) {
                                                                                        if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                                $scope.innerarray = JsonObj[j1];
                                                                                                //converting timestamp to dates
                                                                                                if($scope.breakdown == "DAILY")
                                                                                                {    
                                                                                                         for (var timestamp in $scope.innerarray)
                                                                                                        {
                                                                                                                   var timestmp=timestamp.toString();
                                                                                                                    if(timestmp.length==10)
                                                                                                                    {
                                                                                                                        //timestamp is in seconds
                                                                                                                        //converting to milliseconds
                                                                                                                        var timest=timestmp.concat("000");
                                                                                                                       // console.log(timest);
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                         timest=timestmp;
                                                                                                                    }
                                                                                                                     var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                                                      //$scope.date.push(date);
                                                                                                                       $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));

                                                                                                        }
                                                                                           }
                                                                                                //calculating week number from response
                                                                                                else if($scope.breakdown == "WEEKLY")
                                                                                                {
                                                                                                        for (var weeknum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=weeknum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.weeknum.push(parts);
                                                                                                                           $scope.getdatesfromweeknum(weekno,year);
                                                                                                                }
                                                                                                          //   console.log($scope.weeknum);
                                                                                                }
                                                                                                //calculating month number from response
                                                                                                else if($scope.breakdown == "MONTHLY")
                                                                                                {
                                                                                                        for (var monthnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=monthnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.monthnum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating quarter number from response
                                                                                                else if($scope.breakdown == "QUARTERLY")
                                                                                                {
                                                                                                        for (var quaternum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=quaternum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.quaternum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating half-yearly number from response
                                                                                                else if($scope.breakdown == "HALFYEARLY")
                                                                                                {
                                                                                                        for (var halfnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=halfnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.halfnum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating yearly number from response
                                                                                                else if($scope.breakdown == "YEARLY")
                                                                                                {
                                                                                                        for (var yearnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=yearnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           $scope.yearnum.push(parts);
                                                                                                                }
                                                                                                }

                                                                                                // traversing into the object to get insights
                                                                                                angular.forEach($scope.innerarray, function (value, key) {
                                                                                                         var id1 = 1;
                                                                                                        $scope.twwholemetricname = [];
                                                                                                        $scope.hasinsightdetails=false;
                                                                                                        $scope.arrayofobj = [];
                                                                                                        $scope.parentmetricarray = [];
                                                                                                        $scope.insightsarr = [];
                                                                                                        $scope.arr1 = [];
                                                                                                        $scope.arr2 = [];
                                                                                                        var totalclicks = 0;
                                                                                                        var totalimpressions = 0;
                                                                                                        var totalspend = 0;
                                                                                                        var totalactions = 0;
                                                                                                        var t = $scope.innerarray[key];

                                                                                                        for (var k1 in t)
                                                                                                        {
                                                                                                                if (k1 == "clicks")
                                                                                                                {
                                                                                                                        totalclicks+=t.clicks;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalclicks,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);

                                                                                                                }
                                                                                                                if (k1 == "impressions")
                                                                                                                {
                                                                                                                        totalimpressions+=t.impressions;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalimpressions,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);
                                                                                                                }

                                                                                                                if (k1 == "spend")
                                                                                                                {
                                                                                                                         totalspend+=t.spend;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalspend,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);
                                                                                                                }
                                                                                                                if (k1 == "callToAction")
                                                                                                                {

                                                                                                                         totalactions+=t.callToAction;
                                                                                                                        var obj = {
                                                                                                                                "name": "actions",
                                                                                                                                "value": totalactions,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push("actions");
                                                                                                                }

                                                                                                                if (k1 == "insightsDetails")
                                                                                                                {
                                                                                                                        $scope.hasinsightdetails=true;
                                                                                                                        $scope.insightsarr = t.insightsDetails;

                                                                                                                }
                                                                                                        }
                                                                                                        //traversing into the inner array
                                                                                                         angular.forEach($scope.insightsarr, function (value, key) {
                                                                                                                 angular.forEach(value, function (val, key1) {
                                                                                                                         var jsonObj = val.metrics;
                                                                                                                         var arr =[];
                                                                                                                          for(var z in jsonObj)
                                                                                                                                {
                                                                                                                                        if (jsonObj.hasOwnProperty(z)) {
                                                                                                                                                if (z != "clicks" && z != "impressions" && z != "spend" && z != "callToAction")
                                                                                                                                                {    
                                                                                                                                                        arr[+z] = jsonObj[z];
                                                                                                                                                                var obj = {
                                                                                                                                                                        "name": z,
                                                                                                                                                                        "value": arr[+z][0],
                                                                                                                                                                        "id": id1++,
                                                                                                                                                                        "disabled": "false"
                                                                                                                                                                }
                                                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                                                        $scope.twwholemetricname.push(z);

                                                                                                                                                }
                                                                                                                                        }
                                                                                                                                }
                                                                                                                 });
                                                                                                         });
                                                                                                    });
                                                                                                    }
                                                                                }

                                                                                                           if($scope.breakdown == "DAILY")
                                                                                                           {
                                                                                                                var obj1 = {
                                                                                                                        "date": $scope.date[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                }
                                                                                                                else if($scope.breakdown == "WEEKLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.weeknum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);

                                                                                                                } 
                                                                                                                else if($scope.breakdown == "MONTHLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.monthnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                                                else if($scope.breakdown == "QUARTERLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.quaternum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                }  
                                                                                                                else if($scope.breakdown == "HALFYEARLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.halfnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                                                else if($scope.breakdown == "YEARLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.yearnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                        

                                                                        });
                                                                }
                                                                else{
                                                                    $scope.nograph=true;
                                                                //    $rootScope.progressLoader = "none";
                                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                                $window.localStorage.setItem("TokenExpired", true);
                                                                                $state.go('login');
                                                                        } else {
                                                                       //     $rootScope.progressLoader = "none";
                               //                 $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                           // $scope.errorMsg = response.networkError.message;
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                             errorString.push(response.networkError.message);  errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                             errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                   //     $scope.errorMsg = response.errorMessage;  errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                        errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage);
                                                }
                                                                                                        }
                                                                }
                                                            }));
                                                    }
                                             }
                                         })(i,j);
                                        }
                                    }
                                }
                                $q.all(promises).finally(
                                function(){
                                    
                           //       $scope.progressLoader="none";
                                    $scope.allmetricswithoutduplicates = [];
                                    $scope.allmetricswithduplicates = [];
                                    $scope.metricdropdown = [];
                                    
                                    
                                    $scope.grapharray1 = [];
                                    $scope.twgrapharray1 = [];
                                   // console.log($scope.grapharray);
                                   // console.log($scope.twgrapharray);
                                    $scope.grapharray1 = angular.copy($scope.grapharray);
                                    $scope.twgrapharray1 = angular.copy($scope.twgrapharray);
                                    //getting all metrics without duplicates
                                     angular.forEach($scope.wholemetricname, function (value, key) {
                                           $scope.allmetricswithduplicates.push(value);                                           
                                       });
                                     angular.forEach($scope.twwholemetricname, function (val, k) {
                                           $scope.allmetricswithduplicates.push(val);                                           
                                       }); 
                                       
                                    $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                            return index == self.indexOf(elem);
                                    }); 
                                    
                                    //updating the metric drop down 
                                    var iden = 1;
                                        angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                              var obj = {
                                                    "name": val,
                                                    "id": iden++,
                                                    "disabled": "false"
                                                }
                                                $scope.metricdropdown.push(obj);
                                        });
                                                                                  
                                     //setting default metrics 
                                if($scope.isgraph==false)
                                {
                                    //plot the default graph
                                    $scope.metricselect.push("impressions");
                                }
                                else
                                {
                                    $scope.metricselect = [];
                                }   
                                    
                                    if($scope.userRole == "Advertiser" || $scope.userRole == "Ops Team")
                                        {
                                            console.log("Advertiser / Ops Team role");
                                            $scope.advertiserId = $window.localStorage.getItem("advertiserId");
                                            $scope.selectadvertiser();
                                        }
                                        else
                                        {
                                            $scope.newgraph = "true";
                                              //call for sample graph data creation 
                                             $scope.sampledatacreation();     
                                        }
                                    
                                });
         
        };
       
       $scope.allaccountinsights = function(sdate,edate,breakdown)
        {
            $scope.newgraph="false";
            var promises = [];
               //getting account insights 
                for (i = 0; i < $scope.structarray.length; i++){
                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                            (function(i,j)
                            {
                                if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {
                                                    //getting fb ad account insights on load
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty('adAccountId'))
                                                    {
                                                         console.log("getting fb account insights");
                                                            $scope.breakpoints = [];
                                                            $scope.wholemetricArray = [];
                                                            $scope.grapharray=[];
                                                            
                                                            if(breakdown== "DAILY")
                                                            {
                                                                
                                                                $scope.displaydate=[];
                                                                //getting dates between corresponding selected start and end values
                                                                 date1 = new Date(sdate);
                                                                 date2 = new Date(edate);
                                                                 var day = 1000 * 60 * 60 * 24;
                                                                 var diff = (date2.getTime() - date1.getTime()) / day;
                                                                 for (var i1 = 0; i1 <= diff; i1++)
                                                                 {
                                                                     var xx = date1.getTime() + day * i1;
                                                                     var yy = new Date(xx);

                                                                     var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                     var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                     $scope.breakpoints.push(d2);
                                                                 }
                                                                 for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                {
                                                                     $scope.displaydate.push(new Date($scope.breakpoints[i2]).getDate() + "-" + new Date($scope.breakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                }
                                                                
                                                            }
                                                            promises.push(performanceServices.readadaccountsinsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].adAccountId,sdate,edate,breakdown,appSettings.fbNetwork,false).then(function(response)
                                                            {
                                                                 if (response.appStatus == '0') {
                                                                        
                                                                    // $rootScope.progressLoader = "none";
                                                                     $scope.nograph=false;
                                                                     $scope.innerarray = [];
                                                                     $scope.weekvalue = [];
                                                                     $scope.weeknum=[];
                                                                     $scope.monthnum=[];
                                                                     $scope.quaternum=[];
                                                                     $scope.halfnum=[];
                                                                     $scope.yearnum=[];
                                                                     $scope.date = [];
                                                                     $scope.wholemetricArray1=[];
                                                                     var iden =0;

                                                                     $scope.accountinsights = response.adAccountInsights;
                                                                     angular.forEach($scope.accountinsights, function (value, key) {
                                                                         var JsonObj = $scope.accountinsights[key]
                                                                         var array = [];

                                                                         for (var j1 in JsonObj) {
                                                                             if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                 $scope.innerarray = JsonObj[j1];

                                                                                // console.log($scope.innerarray)
                                                                                 //console.log(totalimpressions)

                                                                                 //converting timestamp to dates
                                                                                 if(breakdown == "DAILY")
                                                                                 {    
                                                                                      for (var timestamp in $scope.innerarray)
                                                                                     {
                                                                                            var timestmp=timestamp.toString();
                                                                                            if(timestmp.length==10)
                                                                                            {
                                                                                                //timestamp is in seconds
                                                                                                //converting to milliseconds
                                                                                                var timest=timestmp.concat("000");
                                                                                               // console.log(timest);
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                 timest=timestmp;
                                                                                            }
                                                                                             var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                              //$scope.date.push(date);
                                                                                               $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                                                                     }
                                                                                     //console.log($scope.date);
                                                                                 }
                                                                                 //calculating week number from response
                                                                                 else if(breakdown == "WEEKLY")
                                                                                 {
                                                                                     for (var weeknum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=weeknum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.weeknum.push(parts);
                                                                                                $scope.getdatesfromweeknum(weekno,year);
                                                                                         }
                                                                                       //   console.log($scope.weeknum);
                                                                                 }
                                                                                 //calculating month number from response
                                                                                 else if(breakdown == "MONTHLY")
                                                                                 {
                                                                                     for (var monthnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=monthnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.monthnum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating quarter number from response
                                                                                 else if(breakdown == "QUARTERLY")
                                                                                 {
                                                                                     for (var quaternum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=quaternum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.quaternum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating half-yearly number from response
                                                                                 else if(breakdown == "HALFYEARLY")
                                                                                 {
                                                                                     for (var halfnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=halfnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                var weekno=parts[2];
                                                                                                $scope.halfnum.push(parts);
                                                                                         }
                                                                                 }
                                                                                 //calculating yearly number from response
                                                                                 else if(breakdown == "YEARLY")
                                                                                 {
                                                                                     for (var yearnum in $scope.innerarray)
                                                                                         {
                                                                                                var parts=yearnum.split('_').join(' ');
                                                                                                var year=parts[0];
                                                                                                $scope.yearnum.push(parts);
                                                                                         }
                                                                                 }

                                                                                 // traversing into the object to get insights
                                                                                 angular.forEach($scope.innerarray, function (value, key) {
                                                                                      var id1 = 1;

                                                                                     $scope.hasinsightdetails=false;
                                                                                     $scope.wholemetricArray1=[];
                                                                                     $scope.wholemetricname=[];
                                                                                     $scope.arrayofobj = [];
                                                                                     $scope.parentmetricarray = [];
                                                                                     $scope.insightsarr = [];
                                                                                     $scope.arr1 = [];
                                                                                     $scope.arr2 = [];
                                                                                     var totalclicks = 0;
                                                                                     var totalimpressions = 0;
                                                                                     var totalspend = 0;
                                                                                     var totalactions = 0;
                                                                                     var t = $scope.innerarray[key];

                                                                                     for (var k1 in t)
                                                                                     {
                                                                                         if (k1 == "clicks")
                                                                                         {
                                                                                             totalclicks+=t.clicks;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalclicks,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);

                                                                                         }
                                                                                         if (k1 == "impressions")
                                                                                         {
                                                                                             totalimpressions+=t.impressions;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalimpressions,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);
                                                                                         }

                                                                                         if (k1 == "spend")
                                                                                         {
                                                                                              totalspend+=t.spend;
                                                                                             var obj = {
                                                                                                 "name": k1,
                                                                                                 "value": totalspend,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push(k1);
                                                                                         }
                                                                                         if (k1 == "callToAction")
                                                                                         {

                                                                                              totalactions+=t.callToAction;
                                                                                             var obj = {
                                                                                                 "name": "actions",
                                                                                                 "value": totalactions,
                                                                                                 "id": id1++,
                                                                                                 "disabled": "false"
                                                                                             }
                                                                                             $scope.wholemetricArray1.push(obj);
                                                                                             $scope.wholemetricname.push("actions");
                                                                                         }

                                                                                         if (k1 == "insightsDetails")
                                                                                         {
                                                                                             $scope.hasinsightdetails=true;
                                                                                             $scope.insightsarr = t.insightsDetails;

                                                                                         }
                                                                                     }
                                                                             //        
                                                       //                      if( breakdown == "DAILY")
                                                       //                      {       
                                                                                 for (k in $scope.insightsarr)
                                                                                     {
                                                                                         //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                                                                         var obj;
                                                                                         function traverse(jsonObj, category) {
                                                                                             if (typeof jsonObj == "object") {
                                                                                                 $.each(jsonObj, function (k, v) {
                                                                                                     if (k == category) {
                                                                                                         if (typeof v == "object")
                                                                                                         {
                                                                                                             angular.forEach(v, function (key1, value1) {
                                                                                                                 $scope.arrayofobj.push(key1);
                                                                                                                 $scope.parentmetricarray.push(k);
                                                                                                             });
                                                                                                         }
                                                                                                         else
                                                                                                         {
                                                                                                             if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                                                                             {

                                                                                                             }
                                                                                                             else
                                                                                                             {
                                                                                                                 var t = 0;
                                                                                                                 var newchar = ' '
                                                                                                                 k = k.split('_').join(newchar);
                                                                                                                 var obj = {
                                                                                                                     "name": k,
                                                                                                                     "value": v,
                                                                                                                     "id": id1++,
                                                                                                                     "disabled": "false"
                                                                                                                 }
                                                                                                                 $scope.wholemetricArray1.push(obj);
                                                                                                                 $scope.wholemetricname.push(k);
                                                                                                             }
                                                                                                         }

                                                                                                     } else {
                                                                                                         traverse(v, category);
                                                                                                     }

                                                                                                 });
                                                                                             }
                                                                                             else {
                                                                                                 // jsonOb is a number or string
                                                                                             }
                                                                                         }
                                                                                         traverse($scope.insightsarr, k)
                                                                                        // console.log(obj)
                                                                                         $scope.keyvalue = obj;
                                                                                     }
                                                                                   //  console.log($scope.arrayofobj);
                                                                                     angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                                                                         var parentmetric=$scope.parentmetricarray[value1];
                                                                                                         var childmetric=key1.action_type;
                                                                                                         var newchar = ' '
                                                                                                         parentmetric = parentmetric.split('_').join(newchar);
                                                                                                         childmetric = childmetric.split('_').join(newchar);
                                                                                                         childmetric = childmetric.split('.').join(newchar);
                                                                                                 var obj = {
                                                                                                          "name": parentmetric +" - "+ childmetric,
                                                                                                          "value":key1.value,
                                                                                                          "id": id1++,
                                                                                                          "disabled": "false"
                                                                                                         }

                                                                                             $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                                                                        //     console.log(obj);
                                                                                           $scope.arr2.push(obj);

                                                                                     });
                                                                                     for (var i1 = 0; i1 < $scope.arr2.length; i1++) {
                                                                                       // console.log($scope.arr2[i]);
                                                                                         $scope.wholemetricArray1.push($scope.arr2[i1]);
                                                                                     }
                                                                                        if(breakdown == "DAILY")
                                                                                        {
                                                                                         var obj1 = {
                                                                                             "date": $scope.date[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }  
                                                                                          $scope.grapharray.push(obj1);
                                                                                         }
                                                                                         else if(breakdown == "WEEKLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.weeknum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);

                                                                                         } 
                                                                                         else if(breakdown == "MONTHLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.monthnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                         else if(breakdown == "QUARTERLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.quaternum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         }  
                                                                                         else if(breakdown == "HALFYEARLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.halfnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                         else if(breakdown == "YEARLY")
                                                                                         {
                                                                                             var obj1 = {
                                                                                             "date": $scope.yearnum[iden++],
                                                                                             "metricobj": $scope.wholemetricArray1,
                                                                                             "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                       }           
                                                                                          $scope.grapharray.push(obj1);
                                                                                         } 
                                                                                 });
                                                                             }
                                                                         }
                                                                        //  console.log($scope.wholemetricArray);
                                                                     });
                                                                    $scope.onloadaccinsights=  $scope.grapharray;
                                                                    $scope.plotarray = [];
                                                                    $scope.arr1=[];
                                                 //                   console.log($scope.wholemetricArray1);
                                                                 } else {//failed
                                                                  //   $rootScope.progressLoader = "none";
                                                                     if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                                                                         $window.localStorage.setItem("TokenExpired",true);
                                                                         $state.go('login');
                                                                     }
                                                                     else{
                                                                    //     $rootScope.progressLoader = "none";
                             //                   $scope.editAdsetErrorMsg = 'block';
                                                           if (response.networkError != '' && response.networkError != undefined) {
                                                          if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                            $scope.errorMsg = response.networkError.message;
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                              errorString.push(response.networkError.message);  errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                             } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                           // $scope.errorMsg = response.networkError.error_user_msg;
                                                            errorHeader.push(response.networkError.error_user_title);
                                                            errorString.push(response.networkError.error_user_msg);
                                                              errornetwork.push($scope.structarray[i].networkDetails[j].networkName)
                                                            }
                                                              } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.errorMessage;
                                                          errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                        errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                        errorString.push(response.errorMessage);
                                                              }
                                                                     }

                                                                         $scope.nograph=true;
                                                                        // $scope.metricselect = [];
                                                                     //}
                                                                 }
                                                           }));

                                                    }
                                                }
                                                else
                                                {
                                                    console.log("getting twitter account insights");
                                                     //getting twitter ad account insights on load
                                                    if($scope.structarray[i].networkDetails[j].hasOwnProperty('twAdAccountId'))
                                                    {
//                                                         $scope.readtwitteradaccountInsightsforlastweek($scope.fromDate, $scope.toDate, $scope.breakdown, $scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                            $scope.twbreakpoints = [];
                                                            $scope.twwholemetricArray = [];
                                                            $scope.twgrapharray=[];
                                                            $scope.twwholemetricname = [];       
                                                            if(breakdown == "DAILY")
                                                            {
                                                                $scope.twdisplaydate=[];
                                                                //getting dates between corresponding selected start and end values
                                                                 date1 = new Date(sdate);
                                                                 date2 = new Date(edate);
                                                                 var day = 1000 * 60 * 60 * 24;
                                                                 var diff = (date2.getTime() - date1.getTime()) / day;
                                                                 for (var i1 = 0; i1 <= diff; i1++)
                                                                 {
                                                                     var xx = date1.getTime() + day * i1;
                                                                     var yy = new Date(xx);

                                                                     var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                     var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                     $scope.twbreakpoints.push(d2);
                                                                 }
                                                              //  console.log($scope.breakpoints);
                                                                 for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                {
                                                                     $scope.twdisplaydate.push(new Date($scope.twbreakpoints[i2]).getDate() + "-" + new Date($scope.twbreakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                }
                                                               // console.log($scope.displaydate);
                                                            }
                                                            promises.push(performanceServices.readadaccountsinsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].twAdAccountId,sdate,edate,breakdown,appSettings.twNetwork,false).then(function(response)
                                                            {    
                                                                if(response.appStatus == 0)
                                                                {       $scope.twwholemetricArray = [];
                                                                  //      $rootScope.progressLoader = "none";
                                                                        $scope.nograph=false;
                                                                        $scope.innerarray = [];
                                                                        $scope.weekvalue = [];
                                                                        $scope.weeknum=[];
                                                                        $scope.monthnum=[];
                                                                        $scope.quaternum=[];
                                                                        $scope.halfnum=[];
                                                                        $scope.yearnum=[];
                                                                        $scope.date = [];
                                                                        var iden =0;

                                                                        $scope.accountinsights = response.adAccountInsights;
                                                                        angular.forEach($scope.accountinsights, function (value, key) {
                                                                                var JsonObj = $scope.accountinsights[key]
                                                                                var array = [];

                                                                                for (var j1 in JsonObj) {
                                                                                        if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                                $scope.innerarray = JsonObj[j1];
                                                                                                //converting timestamp to dates
                                                                                                if(breakdown == "DAILY")
                                                                                                {    
                                                                                                         for (var timestamp in $scope.innerarray)
                                                                                                        {
                                                                                                             var timestmp=timestamp.toString();
                                                                                                            if(timestmp.length==10)
                                                                                                            {
                                                                                                                //timestamp is in seconds
                                                                                                                //converting to milliseconds
                                                                                                                var timest=timestmp.concat("000");
                                                                                                               // console.log(timest);
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                                 timest=timestmp;
                                                                                                            }
                                                                                                             var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                                              //$scope.date.push(date);
                                                                                                               $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));     

                                                                                                        }
                                                                                           }
                                                                                                //calculating week number from response
                                                                                                else if(breakdown == "WEEKLY")
                                                                                                {
                                                                                                        for (var weeknum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=weeknum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.weeknum.push(parts);
                                                                                                                           $scope.getdatesfromweeknum(weekno,year);
                                                                                                                }
                                                                                                          //   console.log($scope.weeknum);
                                                                                                }
                                                                                                //calculating month number from response
                                                                                                else if(breakdown == "MONTHLY")
                                                                                                {
                                                                                                        for (var monthnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=monthnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.monthnum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating quarter number from response
                                                                                                else if(breakdown == "QUARTERLY")
                                                                                                {
                                                                                                        for (var quaternum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=quaternum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.quaternum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating half-yearly number from response
                                                                                                else if(breakdown == "HALFYEARLY")
                                                                                                {
                                                                                                        for (var halfnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=halfnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           var weekno=parts[2];
                                                                                                                           $scope.halfnum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                //calculating yearly number from response
                                                                                                else if(breakdown == "YEARLY")
                                                                                                {
                                                                                                        for (var yearnum in $scope.innerarray)
                                                                                                                {
                                                                                                                           var parts=yearnum.split('_').join(' ');
                                                                                                                           var year=parts[0];
                                                                                                                           $scope.yearnum.push(parts);
                                                                                                                }
                                                                                                }
                                                                                                // traversing into the object to get insights
                                                                                                angular.forEach($scope.innerarray, function (value, key) {
                                                                                                         var id1 = 1;
                                                                                                        $scope.twwholemetricname = [];
                                                                                                        $scope.twwholemetricArray = [];
                                                                                                        $scope.hasinsightdetails=false;
                                                                                                        $scope.arrayofobj = [];
                                                                                                        $scope.parentmetricarray = [];
                                                                                                        $scope.insightsarr = [];
                                                                                                        $scope.arr1 = [];
                                                                                                        $scope.arr2 = [];
                                                                                                        var totalclicks = 0;
                                                                                                        var totalimpressions = 0;
                                                                                                        var totalspend = 0;
                                                                                                        var totalactions = 0;
                                                                                                        var t = $scope.innerarray[key];

                                                                                                        for (var k1 in t)
                                                                                                        {
                                                                                                                if (k1 == "clicks")
                                                                                                                {
                                                                                                                        totalclicks+=t.clicks;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalclicks,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);

                                                                                                                }
                                                                                                                if (k1 == "impressions")
                                                                                                                {
                                                                                                                        totalimpressions+=t.impressions;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalimpressions,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);
                                                                                                                }

                                                                                                                if (k1 == "spend")
                                                                                                                {
                                                                                                                         totalspend+=t.spend;
                                                                                                                        var obj = {
                                                                                                                                "name": k1,
                                                                                                                                "value": totalspend,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push(k1);
                                                                                                                }
                                                                                                                if (k1 == "callToAction")
                                                                                                                {

                                                                                                                         totalactions+=t.callToAction;
                                                                                                                        var obj = {
                                                                                                                                "name": "actions",
                                                                                                                                "value": totalactions,
                                                                                                                                "id": id1++,
                                                                                                                                "disabled": "false"
                                                                                                                        }
                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                        $scope.twwholemetricname.push("actions");
                                                                                                                }

                                                                                                                if (k1 == "insightsDetails")
                                                                                                                {
                                                                                                                        $scope.hasinsightdetails=true;
                                                                                                                        $scope.insightsarr = t.insightsDetails;

                                                                                                                }
                                                                                                        }
                                                                                                        //traversing into the inner array
                                                                                                         angular.forEach($scope.insightsarr, function (value, key) {
                                                                                                                 angular.forEach(value, function (val, key1) {
                                                                                                                         var jsonObj = val.metrics;
                                                                                                                         var arr =[];
                                                                                                                          for(var z in jsonObj)
                                                                                                                                {
                                                                                                                                        if (jsonObj.hasOwnProperty(z)) {
                                                                                                                                                if (z != "clicks" && z != "impressions" && z != "spend" && z != "callToAction")
                                                                                                                                                {    
                                                                                                                                                        arr[+z] = jsonObj[z];
                                                                                                                                                                var obj = {
                                                                                                                                                                        "name": z,
                                                                                                                                                                        "value": arr[+z][0],
                                                                                                                                                                        "id": id1++,
                                                                                                                                                                        "disabled": "false"
                                                                                                                                                                }
                                                                                                                                                        $scope.twwholemetricArray.push(obj);
                                                                                                                                                        $scope.twwholemetricname.push(z);

                                                                                                                                                }
                                                                                                                                        }
                                                                                                                                }
                                                                                                                 });
                                                                                                         });
                                                                                                                if(breakdown == "DAILY")
                                                                                                                {
                                                                                                                var obj1 = {
                                                                                                                        "date": $scope.date[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                }
                                                                                                                else if(breakdown == "WEEKLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.weeknum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);

                                                                                                                } 
                                                                                                                else if(breakdown == "MONTHLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.monthnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                                                else if(breakdown == "QUARTERLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.quaternum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                }  
                                                                                                                else if(breakdown == "HALFYEARLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.halfnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                                                else if(breakdown == "YEARLY")
                                                                                                                {
                                                                                                                        var obj1 = {
                                                                                                                        "date": $scope.yearnum[iden++],
                                                                                                                        "metricobj": $scope.twwholemetricArray,
                                                                                                                        "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId
                                                                                                                                          }           
                                                                                                                 $scope.twgrapharray.push(obj1);
                                                                                                                } 
                                                                                                });
                                                                                        }
                                                                                }

                                                                        });
                                                                }
                                                                else{
                                                                    $scope.nograph=true;
                                                                 //   $rootScope.progressLoader = "none";
                                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                                                                $window.localStorage.setItem("TokenExpired", true);
                                                                                                                $state.go('login');
                                                                                                        } else {//$rootScope.progressLoader = "none";
                               //                                         $scope.editAdsetErrorMsg = 'block';
                                                                                if (response.networkError != '' && response.networkError != undefined) {
                                                                                   if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                                    $scope.errorpopupHeading = 'Error';
                                                                                    // $scope.errorMsg = response.networkError.message;
                                                                                   errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                                                  errorString.push(response.networkError.message);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                     } else {
                                                                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                                   // $scope.errorMsg = response.networkError.error_user_msg;
                                                                                    errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                                                   errorString.push(response.networkError.error_user_msg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            
                                                                     }
                                                                   } else {
                                                                   $scope.errorpopupHeading = 'Error';
                                                                 //  $scope.errorMsg = response.errorMessage;
                                                                   errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                   errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                                   errorString.push(response.errorMessage);
                                                                      }
                                                                                                        }
                                                                }
                                                            }));
                                                    }
                                             }
                                         })(i,j);
                                        }
                                    }
                                }
                                $q.all(promises).finally(
                                function(){
                                   
                                  // console.log($scope.selectedcampaign);
                                    if($scope.selectedcampaign=="" || $scope.selectedcampaign == undefined  || $scope.selectedcampaign=="Select Campaign")
                                    {
                                        console.log("plotting graph for account insights");
                                    $scope.allmetricswithoutduplicates = [];
                                    $scope.allmetricswithduplicates = [];
                                    $scope.metricdropdown = [];
                                    
                                    $scope.grapharray1 = [];
                                    $scope.twgrapharray1 = [];
                                    
                                    $scope.grapharray1 = angular.copy($scope.grapharray);
                                    $scope.twgrapharray1 = angular.copy($scope.twgrapharray);
                                    
                                    //getting all metrics without duplicates
                                     angular.forEach($scope.wholemetricname, function (value, key) {
                                           $scope.allmetricswithduplicates.push(value);                                           
                                       });
                                     angular.forEach($scope.twwholemetricname, function (val, k) {
                                           $scope.allmetricswithduplicates.push(val);                                           
                                       }); 
                                       
                                    $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                            return index == self.indexOf(elem);
                                    }); 
                                    $scope.metricdropdown = [];
                                    //updating the metric drop down 
                                    var iden = 1;
                                        angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                              var obj = {
                                                    "name": val,
                                                    "id": iden++,
                                                    "disabled": "false"
                                                }
                                                $scope.metricdropdown.push(obj);
                                        });
                                        //checking whether the metrics selction is more than 4 and if so disabling the other metrics
                                       $timeout(function(){
                                            if ($scope.metricselect.length == 4)
                                            {
                                                $scope.map ={};
                                                for (var i = 0; i < $scope.metricselect.length; i++) {
                                                    $scope.map[$scope.metricselect[i]] = i;
                                                }

                                                $scope.disableid = [];
                                                //disabling the remaining metrics
                                                for (i = 0; i < $scope.metricdropdown.length; i++) {
                                                    if (!($scope.metricdropdown[i].name in $scope.map)) {

                                                        $scope.metricdropdown[i].disabled = "true";
                                                        $scope.disableid.push($scope.metricdropdown[i].id);
                                                    }
                                                }
                                                for (i = 0; i < $scope.metricdropdown.length; i++) {
                                                    var _in = $scope.metricdropdown[i].id;
                                                    angular.element('#list' + _in).removeClass('disableElement');
                                                }
                                                for (i = 0; i < $scope.disableid.length; i++)
                                                {
                                                    var _in = $scope.disableid[i];
                                                        angular.element('#list' + _in).addClass('disableElement');
                                                }
                                            }
                                        },200);
                                        
                                        
                                        
                                        
                                        
                                        
                                        $scope.sampledatacreation();
                                    }
                                    
                               
                                });
         
        };


        $scope.allcampaigninsightsonload = function()
        { 
            console.log("this is the correct fundction")
            $scope.progressLoader="block";
           var promises = [];
           $scope.campgrapharray = [];
           $scope.twcampgrapharray = [];
           var breakdown = "DAILY";
            //getting campaign insights 
                for (i = 0; i < $scope.structarray.length; i++){
                    
                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                    if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                        for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
//                                           if($scope.structarray[i].networkDetails[j].parent[k].id == parentid)
//                                           {
                                               //getting the child ids of selected parent
                                               if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                {
                                                   for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                   {
                                                       (function(i,j,k,l){
                                                           console.log($scope.structarray[i].networkDetails[j].networkURL);
                                                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                            { 
                                                                // $scope.getinsights(sdate, edate,breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                //getting fb ad campaign insights 
                                                                
                                    console.log("getting facebook campaign insights");
                                    $scope.breakpoints = [];
                                    $scope.campgrapharray=[];

                                              //  $rootScope.progressLoader = "block";
                                                  if(breakdown == "DAILY")
                                                {
                                                    $scope.displaydate = [];
                                                    //getting dates between corresponding selected start and end values
                                                     date1 = new Date($scope.fromDate);
                                                     date2 = new Date($scope.toDate);
                                                     var day = 1000 * 60 * 60 * 24;
                                                     var diff = (date2.getTime() - date1.getTime()) / day;
                                                     for (var i1 = 0; i1 <= diff; i1++)
                                                     {
                                                         var xx = date1.getTime() + day * i1;
                                                         var yy = new Date(xx);

                                                         var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                         var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                         $scope.breakpoints.push(d2);
                                                     }
                                                    //  console.log($scope.breakpoints);
                                                     for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                     {
                                                         $scope.displaydate.push(new Date($scope.breakpoints[i2]).getDate() + "-" + new Date($scope.breakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                     }
                                                   //  console.log($scope.displaydate);
                                                }
                                                promises.push(performanceServices.readadcampaigninsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.fromDate,$scope.toDate,undefined,breakdown,appSettings.fbNetwork,true).then(function(response)
                                                {
                                        var index = 0;
                                        if (response.appStatus == '0') {
                                       //     $rootScope.progressLoader = "none";
                                                $scope.campwholemetricArray = [];
                                                $scope.innerarray = [];
                                                $scope.weekvalue = [];
                                                $scope.weeknum = [];
                                                $scope.monthnum = [];
                                                $scope.quaternum = [];
                                                $scope.halfnum = [];
                                                $scope.yearnum = [];
                                                $scope.date = [];
                                                 var iden1 = 0;
                                                 //$scope.nograph=false;

                                            $scope.campaigninsights = response.adCampaignInsights;
                                          //  console.log($scope.campaigninsights);


                                            angular.forEach($scope.campaigninsights, function (value, key) {
                                                var JsonObj = $scope.campaigninsights[key]
                                                var array = [];
                                             //   console.log(JsonObj);
                                                for (var j4 in JsonObj) {
                                                //    console.log(j4);
                                                    if (JsonObj.hasOwnProperty(j4) && !isNaN(+j4)) {
                                                        $scope.innerarray = JsonObj[j4];

                                                   //     console.log($scope.innerarray);
                                                        //converting timestamp to dates
                                                        if(breakdown == "DAILY")
                                                        {    
                                                             for (var timestamp in $scope.innerarray)
                                                            {
                                                                var timestmp=timestamp.toString();
                                                                 if(timestmp.length==10)
                                                                 {
                                                                     //timestamp is in seconds
                                                                     //converting to milliseconds
                                                                     var timest=timestmp.concat("000");
                                                                    // console.log(timest);
                                                                 }
                                                                 else
                                                                {
                                                                     timest=timestmp;
                                                                }
                                                                  var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                   //$scope.date.push(date);
                                                                    $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                                            }
                                                            //  console.log($scope.date);
                                                        }
                                                        //calculating week number from response
                                                        else if(breakdown == "WEEKLY")
                                                        {
                                                            for (var weeknum in $scope.innerarray)
                                                                {
                                                                       var parts=weeknum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.weeknum.push(parts);
                                                                       $scope.getdatesfromweeknum(weekno,year);
                                                                }
                                                              //   console.log($scope.weeknum);
                                                        }
                                                        //calculating month number from response
                                                        else if(breakdown == "MONTHLY")
                                                        {
                                                            for (var monthnum in $scope.innerarray)
                                                                {
                                                                       var parts=monthnum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.monthnum.push(parts);
                                                                }
                                                        }
                                                        //calculating quarter number from response
                                                        else if(breakdown == "QUARTERLY")
                                                        {
                                                            for (var quaternum in $scope.innerarray)
                                                                {
                                                                       var parts=quaternum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.quaternum.push(parts);
                                                                }
                                                        }
                                                        //calculating half-yearly number from response
                                                        else if(breakdown == "HALFYEARLY")
                                                        {
                                                            for (var halfnum in $scope.innerarray)
                                                                {
                                                                       var parts=halfnum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.halfnum.push(parts);
                                                                }
                                                        }
                                                        //calculating yearly number from response
                                                        else if(breakdown == "YEARLY")
                                                        {
                                                            for (var yearnum in $scope.innerarray)
                                                                {
                                                                       var parts=yearnum.split('_').join(' ');
                                                                       var year=parts[1];
                                                                       $scope.yearnum.push(parts);
                                                                }
                                                        }

                                                        // traversing into the object to get insights
                                                        angular.forEach($scope.innerarray, function (value, key) {
                                                             var id1 = 1;

                                                            $scope.hasinsightdetails=false;
                                                            $scope.wholemetricArray=[];
                                                            $scope.wholemetricname=[];
                                                            $scope.arrayofobj = [];
                                                            $scope.parentmetricarray = [];
                                                            $scope.insightsarr = [];
                                                            $scope.arr1 = [];
                                                            $scope.arr2 = [];
                                                            var totalclicks = 0;
                                                            var totalimpressions = 0;
                                                            var totalspend = 0;
                                                            var totalactions = 0;
                                                            var t = $scope.innerarray[key];
                                                         //   console.log(t)
                                                            for (var k1 in t)
                                                            {
                                                                if (k1 == "clicks")
                                                                {
                                                                    totalclicks+=t.clicks;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalclicks,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);

                                                                }
                                                                if (k1 == "impressions")
                                                                {
                                                                    totalimpressions+=t.impressions;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalimpressions,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);
                                                                }

                                                                if (k1 == "spend")
                                                                {
                                                                     totalspend+=t.spend;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalspend,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);
                                                                }
                                                                 if (k1 == "callToAction")
                                                                {

                                                                     totalactions+=t.callToAction;
                                                                    var obj = {
                                                                        "name": "actions",
                                                                        "value": totalactions,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push("actions");
                                                                }

                                                                if (k1 == "insightsDetails")
                                                                {
                                                                    $scope.hasinsightdetails=true;
                                                                    $scope.insightsarr = t.insightsDetails;

                                                                }
                                                            }
                                                            //console.log($scope.hasinsightdetails);
                                                    //        
                              //                      if( breakdown == "DAILY")
                              //                      {       
                                                        for (k2 in $scope.insightsarr)
                                                            {
                                                                //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k2)
                                                                var obj;
                                                                function traverse(jsonObj, category) {
                                                                    if (typeof jsonObj == "object") {
                                                                        $.each(jsonObj, function (k2, v) {
                                                                            if (k2 == category) {
                                                                                if (typeof v == "object")
                                                                                {
                                                                                    angular.forEach(v, function (key1, value1) {
                                                                                        $scope.arrayofobj.push(key1);
                                                                                        $scope.parentmetricarray.push(k2);
                                                                                    });
                                                                                }
                                                                                else
                                                                                {
                                                                                    if (k2 == "clicks" || k2 == "impressions" || k2 == "spend" || k2 =="date_start" || k2 == "date_stop" || k2 == "objective" || k2== "account_name" || k2=="account_id")
                                                                                    {

                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        var t = 0;
                                                                                        var newchar = ' '
                                                                                        k2 = k2.split('_').join(newchar);
                                                                                        var obj = {
                                                                                            "name": k2,
                                                                                            "value": v,
                                                                                            "id": id1++,
                                                                                            "disabled": "false"
                                                                                        }
                                                                                        $scope.wholemetricArray.push(obj);
                                                                                        $scope.wholemetricname.push(k2);
                                                                                    }
                                                                                }

                                                                            } else {
                                                                                traverse(v, category);
                                                                            }

                                                                        });
                                                                    }
                                                                    else {
                                                                        // jsonOb is a number or string
                                                                    }
                                                                }
                                                                traverse($scope.insightsarr, k2)
                                                               // console.log(obj)
                                                                $scope.keyvalue = obj;
                                                            }
                                                          //  console.log($scope.arrayofobj);
                                                           // console.log($scope.parentmetricarray);
                                                            angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                                                var parentmetric=$scope.parentmetricarray[value1];
                                                                                var childmetric=key1.action_type;
                                                                                var newchar = ' '
                                                                                parentmetric = parentmetric.split('_').join(newchar);
                                                                                childmetric = childmetric.split('_').join(newchar);

                                                                        var obj = {
                                                                                 "name": parentmetric +" - "+ childmetric,
                                                                                 "value":key1.value,
                                                                                 "id": id1++,
                                                                                 "disabled": "false"
                                                                                }

                                                                    $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                                               //     console.log(obj);
                                                                  $scope.arr2.push(obj);

                                                            });
                                                            for (var i4 = 0; i4 < $scope.arr2.length; i4++) {
                                                              // console.log($scope.arr2[i4]);
                                                                $scope.wholemetricArray.push($scope.arr2[i4]);
                                                            }

                                                               if(breakdown == "DAILY")
                                                               {
                                                                //   console.log(iden1);
                                                                var obj1 = {
                                                                    "date": $scope.date[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              } 
                                                                    $scope.campgrapharray.push(obj1);

                                                                }
                                                                else if(breakdown == "WEEKLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.weeknum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              } 
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "MONTHLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.monthnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "QUARTERLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.quaternum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                }  
                                                                else if(breakdown == "HALFYEARLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.halfnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "YEARLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.yearnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 

                                                        });
                                                    }
                                                }
                                               //  console.log($scope.wholemetricArray);
                                            });
                                        }
                                        else
                                        {
                                          //  $rootScope.progressLoader = "none";
                                            if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
                                                $window.localStorage.setItem("TokenExpired",true);
                                                $state.go('login');
                                            }
                                            else{
                                           //     $rootScope.progressLoader = "none";
                                                $scope.editAdsetErrorMsg = 'none';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = "WE're sry something went wrong!";
                                                            $scope.errorMsg = response.networkError.message;
                                                             errorHeader.push($scope.errorpopupHeading);
                                                             errorString.push($scope.errorMsg);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                            $scope.errorMsg = response.networkError.error_user_msg;
                                                            errorHeader.push($scope.errorpopupHeading);
                                                            errorString.push($scope.errorMsg);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = "WE're sry something went wrong!";
                                                        $scope.errorMsg = response.errorMessage;
                                                      errorHeader.push(" Advertiser:<b>"+$scope.structarray[i].advertiserName + "</b><br> parentcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[j].name+"</b><br> childcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[k].child[l].name+"</b>");
                                                        errorString.push($scope.errorMsg);
                                                       errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                     //  $scope.errorhandeler();
                                                        
                                                }
                                            }

                                            //    $scope.nograph=true;
                                            $scope.campaignwithnoinsights++;
                                        //    console.log($scope.campaignwithnoinsights);

                                       // console.log($scope.selectedcampaignsinsightscount);
//                                        if($scope.campaignwithnoinsights == $scope.selectedcampaignsinsightscount)
//                                        {
//                                            $scope.nograph = true;
//                                        }

                                        }    
                                   }));

                                                                
                                                   
                                                            }
                                                            else
                                                            {
                                                                console.log("getting twitter campaign insights");
                                                                //getting twitter ad account insights on load
//                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == "7vu7q")
//                                                            {
                                                                if($scope.structarray[i].networkDetails[j].hasOwnProperty('twAdAccountId'))
                                                                {
                        //                                                         $scope.readtwitteradaccountInsightsforlastweek($scope.fromDate, $scope.toDate, $scope.breakdown, $scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                    $scope.twbreakpoints = [];
                                                                                    $scope.twwholemetricArray = [];
                                                                                    $scope.twcampgrapharray=[];
                                                                                    $scope.twwholemetricname = [];       
                                                                                    if(breakdown == "DAILY")
                                                                                    {
                                                                                        $scope.twdisplaydate=[];
                                                                                        //getting dates between corresponding selected start and end values
                                                                                         date1 = new Date($scope.fromDate);
                                                                                         date2 = new Date($scope.toDate);
                                                                                         var day = 1000 * 60 * 60 * 24;
                                                                                         var diff = (date2.getTime() - date1.getTime()) / day;
                                                                                         for (var i1 = 0; i1 <= diff; i1++)
                                                                                         {
                                                                                             var xx = date1.getTime() + day * i1;
                                                                                             var yy = new Date(xx);

                                                                                             var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                                             var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                                             $scope.twbreakpoints.push(d2);
                                                                                         }
                                                                                      //  console.log($scope.breakpoints);
                                                                                         for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                                        {
                                                                                             $scope.twdisplaydate.push(new Date($scope.twbreakpoints[i2]).getDate() + "-" + new Date($scope.twbreakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                                        }
                                                                                       // console.log($scope.displaydate);
                                                                                    }
                                                                                    promises.push(performanceServices.readadcampaigninsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.fromDate,$scope.toDate,undefined,breakdown,appSettings.twNetwork,true).then(function(response)
                                                                                    {     
                                                                                        if(response.appStatus == 0)
                                                                                        {       $scope.twwholemetricArray = [];
                                                                                         //       $rootScope.progressLoader = "none";
                                                                                                //$scope.nograph=false;
                                                                                                $scope.innerarray = [];
                                                                                                $scope.weekvalue = [];
                                                                                                $scope.weeknum=[];
                                                                                                $scope.monthnum=[];
                                                                                                $scope.quaternum=[];
                                                                                                $scope.halfnum=[];
                                                                                                $scope.yearnum=[];
                                                                                                $scope.date = [];
                                                                                                var iden =0;

                                                                                                $scope.campaigninsights = response.adCampaignInsights;
                                                                                                angular.forEach($scope.campaigninsights, function (value, key) {
                                                                                                        var JsonObj = $scope.campaigninsights[key]
                                                                                                        var array = [];

                                                                                                        for (var j1 in JsonObj) {
                                                                                                                if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                                                        $scope.innerarray = JsonObj[j1];
                                                                                                                        //converting timestamp to dates
                                                                                                                        if(breakdown == "DAILY")
                                                                                                                        {    
                                                                                                                                 for (var timestamp in $scope.innerarray)
                                                                                                                                {
                                                                                                                                           var timestmp=timestamp.toString();
                                                                                                                                            if(timestmp.length==10)
                                                                                                                                            {
                                                                                                                                                //timestamp is in seconds
                                                                                                                                                //converting to milliseconds
                                                                                                                                                var timest=timestmp.concat("000");
                                                                                                                                               // console.log(timest);
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                                timest=timestmp;
                                                                                                                                            }
                                                                                                                                             var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                                                                              //$scope.date.push(date);
                                                                                                                                               $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                                                                                                                             //  console.log($scope.date);
                                                                                                                                }
                                                                                                                   }
                                                                                                                        //calculating week number from response
                                                                                                                        else if(breakdown == "WEEKLY")
                                                                                                                        {
                                                                                                                                for (var weeknum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=weeknum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.weeknum.push(parts);
                                                                                                                                                   $scope.getdatesfromweeknum(weekno,year);
                                                                                                                                        }
                                                                                                                                  //   console.log($scope.weeknum);
                                                                                                                        }
                                                                                                                        //calculating month number from response
                                                                                                                        else if(breakdown == "MONTHLY")
                                                                                                                        {
                                                                                                                                for (var monthnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=monthnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.monthnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating quarter number from response
                                                                                                                        else if(breakdown == "QUARTERLY")
                                                                                                                        {
                                                                                                                                for (var quaternum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=quaternum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.quaternum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating half-yearly number from response
                                                                                                                        else if(breakdown == "HALFYEARLY")
                                                                                                                        {
                                                                                                                                for (var halfnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=halfnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.halfnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating yearly number from response
                                                                                                                        else if(breakdown == "YEARLY")
                                                                                                                        {
                                                                                                                                for (var yearnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=yearnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   $scope.yearnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        // traversing into the object to get insights
                                                                                                                        angular.forEach($scope.innerarray, function (value, key) {
                                                                                                                                 var id1 = 1;
                                                                                                                                $scope.twwholemetricname = [];
                                                                                                                                $scope.twwholemetricArray = [];
                                                                                                                                $scope.hasinsightdetails=false;
                                                                                                                                $scope.arrayofobj = [];
                                                                                                                                $scope.parentmetricarray = [];
                                                                                                                                $scope.insightsarr = [];
                                                                                                                                $scope.arr1 = [];
                                                                                                                                $scope.arr2 = [];
                                                                                                                                var totalclicks = 0;
                                                                                                                                var totalimpressions = 0;
                                                                                                                                var totalspend = 0;
                                                                                                                                var totalactions = 0;
                                                                                                                                var t = $scope.innerarray[key];

                                                                                                                                for (var k1 in t)
                                                                                                                                {
                                                                                                                                        if (k1 == "clicks")
                                                                                                                                        {
                                                                                                                                                totalclicks+=t.clicks;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalclicks,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);

                                                                                                                                        }
                                                                                                                                        if (k1 == "impressions")
                                                                                                                                        {
                                                                                                                                                totalimpressions+=t.impressions;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalimpressions,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);
                                                                                                                                        }

                                                                                                                                        if (k1 == "spend")
                                                                                                                                        {
                                                                                                                                                 totalspend+=t.spend;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalspend,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);
                                                                                                                                        }
                                                                                                                                        if (k1 == "callToAction")
                                                                                                                                        {

                                                                                                                                                 totalactions+=t.callToAction;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": "actions",
                                                                                                                                                        "value": totalactions,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push("actions");
                                                                                                                                        }

                                                                                                                                        if (k1 == "insightsDetails")
                                                                                                                                        {
                                                                                                                                                $scope.hasinsightdetails=true;
                                                                                                                                                $scope.insightsarr = t.insightsDetails;

                                                                                                                                        }
                                                                                                                                }
                                                                                                                                //traversing into the inner array
                                                                                                                                
                                                                                                                                var res = $scope.insightsarr.id_data;
                                                                                                                                angular.forEach(res[0].metrics,function(value,key)
                                                                                                                                {
                                                                                                                                     if (key == "clicks" || key == "impressions" || key == "spend" || key == "callToAction")
                                                                                                                                     {
                                                                                                                                         
                                                                                                                                     }
                                                                                                                                     else
                                                                                                                                     {
                                                                                                                                                angular.forEach(value, function(value2,key2)
                                                                                                                                           {
                                                                                                                                               if(typeof(value2) == "object")
                                                                                                                                               {
                                                                                                                                                   angular.forEach(value2, function(value3,key3)
                                                                                                                                                   {
       //                                                                                                                                                console.log(typeof(value3));
                                                                                                                                                      // console.log(value3,key2,key);
                                                                                                                                                       var obj = {
                                                                                                                                                                   "name": key.split('_').join(' ') + " - " + key2.split('_').join(' '),
                                                                                                                                                                   "value": value3,
                                                                                                                                                                   "id": id1++,
                                                                                                                                                                   "disabled": "false"
                                                                                                                                                           }
                                                                                                                                                           $scope.twwholemetricArray.push(obj);
                                                                                                                                                           $scope.twwholemetricname.push(key.split('_').join(' ') + " - " + key2.split('_').join(' '));

                                                                                                                                                   });
                                                                                                                                               }
                                                                                                                                               else
                                                                                                                                               {
                                                                                                                                                   if(typeof(key2) == "string")
                                                                                                                                                   {
                                                                                                                                                       //console.log(value2,key2,key);
                                                                                                                                                      var obj = {
                                                                                                                                                                   "name": key.split('_').join(' ') + " - " + key2.split('_').join(' '),
                                                                                                                                                                   "value": value2,
                                                                                                                                                                   "id": id1++,
                                                                                                                                                                   "disabled": "false"
                                                                                                                                                           }
                                                                                                                                                           $scope.twwholemetricArray.push(obj);
                                                                                                                                                           $scope.twwholemetricname.push(key.split('_').join(' ') + " - " + key2.split('_').join(' '));
                                                                                                                                                   }
                                                                                                                                                   else
                                                                                                                                                   {
                                                                                                                                                      // console.log(value2,key);
                                                                                                                                                      var obj = {
                                                                                                                                                                   "name": key.split('_').join(' '),
                                                                                                                                                                   "value": value2,
                                                                                                                                                                   "id": id1++,
                                                                                                                                                                   "disabled": "false"
                                                                                                                                                           }
                                                                                                                                                           $scope.twwholemetricArray.push(obj);
                                                                                                                                                           $scope.twwholemetricname.push(key.split('_').join(' '));
                                                                                                                                                   }
                                                                                                                                               }
                                                                                                                                           });
                                                                                                                                     }
                                                                                                                                    
                                                                                                                                });
//                                                                                                                         
                                                                                                                                 
                                                                                                                                        if(breakdown == "DAILY")
                                                                                                                                        {
                                                                                                                                        var obj1 = {
                                                                                                                                                "date": $scope.date[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        }
                                                                                                                                        else if(breakdown == "WEEKLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.weeknum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);

                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "MONTHLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.monthnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "QUARTERLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.quaternum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        }  
                                                                                                                                        else if(breakdown == "HALFYEARLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.halfnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "YEARLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.yearnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        }
                                                                                                                                       }); 
                                                                                                                }
                                                                                                        }

                                                                                                });
                                                                                        }
                                                                                        else{
                                                                                            $scope.editAdsetErrorMsg = 'none';
                                                                             //               $rootScope.progressLoader = "none";
                                                                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                                                    $window.localStorage.setItem("TokenExpired", true);
                                                                                                    $state.go('login');
                                                                                            } else {
                                                                              //                      $rootScope.progressLoader = "none";
                                                                            //                       $scope.editAdsetErrorMsg = 'block';
                                                                                                     if (response.networkError != '' && response.networkError != undefined) {
                                                                                                     if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                                                     $scope.errorpopupHeading = "WE're sry something went wrong!";
                                                                                                     $scope.errorMsg = response.networkError.message;
                                                                                                     errorHeader.push($scope.errorpopupHeading);
                                                                                                     errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                                                   errorString.push($scope.errorMsg);
                                                                                                    } else {
                                                                                                     $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                                                                  $scope.errorMsg = response.networkError.error_user_msg;
                                                                                                          errorHeader.push($scope.errorpopupHeading);
                                                                                                          errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                                                             }
                                                                                                      } else {
                                                                                                          $scope.errorpopupHeading = "WE're sry something went wrong!";
                                                                                                          $scope.errorMsg = response.errorMessage;
                                                                                                          errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                                                          errorHeader.push("Advertiser:<b>"+$scope.structarray[i].advertiserName + "</b><br> parentcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[j].name+"</b><br> childcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[k].child[l].name+"</b>");
                                                                                                          errorString.push($scope.errorMsg);
                                                                                                       //   $scope.errorhandeler();
                                                                                                        
                                                                                                      }}
                                                                                        }
                                                                                    }));
                                                                            }
                                                                        }
//                                                            }                                                                                      
                                                    })(i,j,k,l)
                                                                        
                                                }
                                            }
//                                        }
                                    }  
                                   
                                }       
                                else
                                {
                                     //selected parent has no child
                                    $scope.nograph=true;
                                }
                        }
                    }
                }

                $q.all(promises).finally(
                         
                function(){
                  $scope.progressLoader="none";
                   errorCompletionStatus=true;
                   $scope.errorhandeler();
//                    $scope.allmetricswithoutduplicates = [];
//                    $scope.allmetricswithduplicates = [];
//                    $scope.metricdropdown = [];
                    $scope.campgrapharray1 = [];
                    $scope.camptwgrapharray1 = [];
                  //  console.log( $scope.campgrapharray);
                    //console.log( $scope.twcampgrapharray);
                    $scope.campgrapharray1 = angular.copy($scope.campgrapharray);
                    $scope.twcampgrapharray1 = angular.copy($scope.twcampgrapharray);

//                    //getting all metrics without duplicates
//                     angular.forEach($scope.wholemetricname, function (value, key) {
//                           $scope.allmetricswithduplicates.push(value);                                           
//                       });
//                     angular.forEach($scope.twwholemetricname, function (val, k) {
//                           $scope.allmetricswithduplicates.push(val);                                           
//                       }); 
//
//                    $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
//                            return index == self.indexOf(elem);
//                    }); 
//                    $scope.metricdropdown = [];
//                    //updating the metric drop down 
//                    var iden = 1;
//                        angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
//                              var obj = {
//                                    "name": val,
//                                    "id": iden++,
//                                    "disabled": "false"
//                                }
//                                $scope.metricdropdown.push(obj);
//                        });
//                    console.log( $scope.metricdropdown);
//                    
//                    
//                    //checking whether the metrics selction is more than 4 and if so disabling the other metrics
//                    $timeout(function(){
//                         if ($scope.metricselect.length == 4)
//                         {
//                             $scope.map ={};
//                             for (var i = 0; i < $scope.metricselect.length; i++) {
//                                 $scope.map[$scope.metricselect[i]] = i;
//                             }
//
//                             $scope.disableid = [];
//                             //disabling the remaining metrics
//                             for (i = 0; i < $scope.metricdropdown.length; i++) {
//                                 if (!($scope.metricdropdown[i].name in $scope.map)) {
//
//                                     $scope.metricdropdown[i].disabled = "true";
//                                     $scope.disableid.push($scope.metricdropdown[i].id);
//                                 }
//                             }
//                             for (i = 0; i < $scope.metricdropdown.length; i++) {
//                                 var _in = $scope.metricdropdown[i].id;
//                                 angular.element('#list' + _in).removeClass('disableElement');
//                             }
//                             for (i = 0; i < $scope.disableid.length; i++)
//                             {
//                                 var _in = $scope.disableid[i];
//                                     angular.element('#list' + _in).addClass('disableElement');
//                             }
//                         }
//                     },200);
                    //call for sample graph data creation 
//                   $scope.sampledatacreation();
            
                });
        
        
        };

         $scope.allcampaigninsights= function(sdate,edate,breakdown)
        {
            $scope.progressLoader="block";
           var promises = [];
           $scope.campgrapharray = [];
           $scope.twcampgrapharray = [];
           $scope.newgraph="false";
            //getting campaign insights 
                for (i = 0; i < $scope.structarray.length; i++){
                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                    if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                        for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
//                                           if($scope.structarray[i].networkDetails[j].parent[k].id == parentid)
//                                           {
                                               //getting the child ids of selected parent
                                               if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                {
                                                   for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                   {
                                                       (function(i,j,k,l){
                                                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                            { 
                                                                // $scope.getinsights(sdate, edate,breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                //getting fb ad campaign insights 
                                                                
                                    console.log("getting facebook campaign insights");
                                    $scope.breakpoints = [];
                                    $scope.campgrapharray=[];

                                                $rootScope.progressLoader = "block";
                                                  if(breakdown == "DAILY")
                                                {
                                                    $scope.displaydate = [];
                                                    //getting dates between corresponding selected start and end values
                                                     date1 = new Date(sdate);
                                                     date2 = new Date(edate);
                                                     var day = 1000 * 60 * 60 * 24;
                                                     var diff = (date2.getTime() - date1.getTime()) / day;
                                                     for (var i1 = 0; i1 <= diff; i1++)
                                                     {
                                                         var xx = date1.getTime() + day * i1;
                                                         var yy = new Date(xx);

                                                         var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                         var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                         $scope.breakpoints.push(d2);
                                                     }
                                                    //  console.log($scope.breakpoints);
                                                     for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                     {
                                                         $scope.displaydate.push(new Date($scope.breakpoints[i2]).getDate() + "-" + new Date($scope.breakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                     }
                                                   //  console.log($scope.displaydate);
                                                }
                                                promises.push(performanceServices.readadcampaigninsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,sdate,edate,undefined,breakdown,appSettings.fbNetwork,false).then(function(response)
                                                {
                                        var index = 0;
                                        if (response.appStatus == '0') {
                                         //   $rootScope.progressLoader = "none";
                                            //$scope.nograph = false;
                                                $scope.wholemetricArray = [];
                                                $scope.innerarray = [];
                                                $scope.weekvalue = [];
                                                $scope.weeknum = [];
                                                $scope.monthnum = [];
                                                $scope.quaternum = [];
                                                $scope.halfnum = [];
                                                $scope.yearnum = [];
                                                $scope.date = [];
                                                 var iden1 = 0;
                                                 //$scope.nograph=false;

                                            $scope.campaigninsights = response.adCampaignInsights;
                                          //  console.log($scope.campaigninsights);


                                            angular.forEach($scope.campaigninsights, function (value, key) {
                                                var JsonObj = $scope.campaigninsights[key]
                                                var array = [];
                                             //   console.log(JsonObj);
                                                for (var j4 in JsonObj) {
                                                //    console.log(j4);
                                                    if (JsonObj.hasOwnProperty(j4) && !isNaN(+j4)) {
                                                        $scope.innerarray = JsonObj[j4];

                                                   //     console.log($scope.innerarray);
                                                        //converting timestamp to dates
                                                        if(breakdown == "DAILY")
                                                        {    
                                                             for (var timestamp in $scope.innerarray)
                                                            {
                                                                var timestmp=timestamp.toString();
                                                                 if(timestmp.length==10)
                                                                 {
                                                                     //timestamp is in seconds
                                                                     //converting to milliseconds
                                                                     var timest=timestmp.concat("000");
                                                                    // console.log(timest);
                                                                 }
                                                                 else
                                                                 {
                                                                     timest=timestmp;
                                                                 }
                                                                  var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                   //$scope.date.push(date);
                                                                    $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                                            }
                                                            //  console.log($scope.date);
                                                        }
                                                        //calculating week number from response
                                                        else if(breakdown == "WEEKLY")
                                                        {
                                                            for (var weeknum in $scope.innerarray)
                                                                {
                                                                       var parts=weeknum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.weeknum.push(parts);
                                                                       $scope.getdatesfromweeknum(weekno,year);
                                                                }
                                                              //   console.log($scope.weeknum);
                                                        }
                                                        //calculating month number from response
                                                        else if(breakdown == "MONTHLY")
                                                        {
                                                            for (var monthnum in $scope.innerarray)
                                                                {
                                                                       var parts=monthnum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.monthnum.push(parts);
                                                                }
                                                        }
                                                        //calculating quarter number from response
                                                        else if(breakdown == "QUARTERLY")
                                                        {
                                                            for (var quaternum in $scope.innerarray)
                                                                {
                                                                       var parts=quaternum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.quaternum.push(parts);
                                                                }
                                                        }
                                                        //calculating half-yearly number from response
                                                        else if(breakdown == "HALFYEARLY")
                                                        {
                                                            for (var halfnum in $scope.innerarray)
                                                                {
                                                                       var parts=halfnum.split('_').join(' ');
                                                                       var year=parts[0];
                                                                       var weekno=parts[2];
                                                                       $scope.halfnum.push(parts);
                                                                }
                                                        }
                                                        //calculating yearly number from response
                                                        else if(breakdown == "YEARLY")
                                                        {
                                                            for (var yearnum in $scope.innerarray)
                                                                {
                                                                       var parts=yearnum.split('_').join(' ');
                                                                       var year=parts[1];
                                                                       $scope.yearnum.push(parts);
                                                                }
                                                        }

                                                        // traversing into the object to get insights
                                                        angular.forEach($scope.innerarray, function (value, key) {
                                                             var id1 = 1;

                                                            $scope.hasinsightdetails=false;
                                                            $scope.wholemetricArray=[];
                                                            $scope.wholemetricname=[];
                                                            $scope.arrayofobj = [];
                                                            $scope.parentmetricarray = [];
                                                            $scope.insightsarr = [];
                                                            $scope.arr1 = [];
                                                            $scope.arr2 = [];
                                                            var totalclicks = 0;
                                                            var totalimpressions = 0;
                                                            var totalspend = 0;
                                                            var totalactions = 0;
                                                            var t = $scope.innerarray[key];
                                                         //   console.log(t)
                                                            for (var k1 in t)
                                                            {
                                                                if (k1 == "clicks")
                                                                {
                                                                    totalclicks+=t.clicks;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalclicks,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);

                                                                }
                                                                if (k1 == "impressions")
                                                                {
                                                                    totalimpressions+=t.impressions;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalimpressions,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);
                                                                }

                                                                if (k1 == "spend")
                                                                {
                                                                     totalspend+=t.spend;
                                                                    var obj = {
                                                                        "name": k1,
                                                                        "value": totalspend,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push(k1);
                                                                }
                                                                 if (k1 == "callToAction")
                                                                {

                                                                     totalactions+=t.callToAction;
                                                                    var obj = {
                                                                        "name": "actions",
                                                                        "value": totalactions,
                                                                        "id": id1++,
                                                                        "disabled": "false"
                                                                    }
                                                                    $scope.wholemetricArray.push(obj);
                                                                    $scope.wholemetricname.push("actions");
                                                                }

                                                                if (k1 == "insightsDetails")
                                                                {
                                                                    $scope.hasinsightdetails=true;
                                                                    $scope.insightsarr = t.insightsDetails;

                                                                }
                                                            }
                                                            //console.log($scope.hasinsightdetails);
                                                    //        
                              //                      if( breakdown == "DAILY")
                              //                      {       
                                                        for (k2 in $scope.insightsarr)
                                                            {
                                                                //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k2)
                                                                var obj;
                                                                function traverse(jsonObj, category) {
                                                                    if (typeof jsonObj == "object") {
                                                                        $.each(jsonObj, function (k2, v) {
                                                                            if (k2 == category) {
                                                                                if (typeof v == "object")
                                                                                {
                                                                                    angular.forEach(v, function (key1, value1) {
                                                                                        $scope.arrayofobj.push(key1);
                                                                                        $scope.parentmetricarray.push(k2);
                                                                                    });
                                                                                }
                                                                                else
                                                                                {
                                                                                    if (k2 == "clicks" || k2 == "impressions" || k2 == "spend" || k2 =="date_start" || k2 == "date_stop" || k2 == "objective" || k2== "account_name" || k2=="account_id")
                                                                                    {

                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        var t = 0;
                                                                                        var newchar = ' '
                                                                                        k2 = k2.split('_').join(newchar);
                                                                                        var obj = {
                                                                                            "name": k2,
                                                                                            "value": v,
                                                                                            "id": id1++,
                                                                                            "disabled": "false"
                                                                                        }
                                                                                        $scope.wholemetricArray.push(obj);
                                                                                        $scope.wholemetricname.push(k2);
                                                                                    }
                                                                                }

                                                                            } else {
                                                                                traverse(v, category);
                                                                            }

                                                                        });
                                                                    }
                                                                    else {
                                                                        // jsonOb is a number or string
                                                                    }
                                                                }
                                                                traverse($scope.insightsarr, k2)
                                                               // console.log(obj)
                                                                $scope.keyvalue = obj;
                                                            }
                                                          //  console.log($scope.arrayofobj);
                                                           // console.log($scope.parentmetricarray);
                                                            angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                                                var parentmetric=$scope.parentmetricarray[value1];
                                                                                var childmetric=key1.action_type;
                                                                                var newchar = ' '
                                                                                parentmetric = parentmetric.split('_').join(newchar);
                                                                                childmetric = childmetric.split('_').join(newchar);

                                                                        var obj = {
                                                                                 "name": parentmetric +" - "+ childmetric,
                                                                                 "value":key1.value,
                                                                                 "id": id1++,
                                                                                 "disabled": "false"
                                                                                }

                                                                    $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                                               //     console.log(obj);
                                                                  $scope.arr2.push(obj);

                                                            });
                                                            for (var i4 = 0; i4 < $scope.arr2.length; i4++) {
                                                              // console.log($scope.arr2[i4]);
                                                                $scope.wholemetricArray.push($scope.arr2[i4]);
                                                            }

                                                               if(breakdown == "DAILY")
                                                               {
                                                                //   console.log(iden1);
                                                                var obj1 = {
                                                                    "date": $scope.date[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              } 
                                                                    $scope.campgrapharray.push(obj1);

                                                                }
                                                                else if(breakdown == "WEEKLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.weeknum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              } 
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "MONTHLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.monthnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "QUARTERLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.quaternum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                }  
                                                                else if(breakdown == "HALFYEARLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.halfnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 
                                                                else if(breakdown == "YEARLY")
                                                                {
                                                                    var obj1 = {
                                                                    "date": $scope.yearnum[iden1++],
                                                                    "metricobj": $scope.wholemetricArray,
                                                                    "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                    "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                              }           
                                                                 $scope.campgrapharray.push(obj1);
                                                                } 

                                                        });
                                                    }
                                                }
                                               //  console.log($scope.wholemetricArray);
                                            });
                                        }
                                        else
                                        {
                                         //   $rootScope.progressLoader = "none";
                                            if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
                                                $window.localStorage.setItem("TokenExpired",true);
                                                $state.go('login');
                                            }
                                            else{
                                           //    $rootScope.progressLoader = "none";
                                       //         $scope.editAdsetErrorMsg = 'block';
                                                if (response.networkError != '' && response.networkError != undefined) {
                                                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                            $scope.errorpopupHeading = 'Error';
                                                            $scope.errorMsg = response.networkError.message;
                                                             errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                             errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                    } else {
                                                            $scope.errorpopupHeading = response.networkError.error_user_title;
                                                            $scope.errorMsg = response.networkError.error_user_msg;
                                                            errorHeader.push($scope.structarray[i].advertiserName + " : " + $scope.structarray[i].networkDetails[j].networkName);
                                                            errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            
                                                    }
                                                } else {
                                                        $scope.errorpopupHeading = 'Error';
                                                        $scope.errorMsg = response.errorMessage;
                                                    errorHeader.push(" Advertiser:<b>"+$scope.structarray[i].advertiserName + "</b><br> parentcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[j].name+"</b><br> childcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[k].child[l].name+"</b>");
                                                        errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                     //   $scope.errorhandeler();
                                                }
                                            }

                                            //    $scope.nograph=true;
                                            $scope.campaignwithnoinsights++;
                                        //    console.log($scope.campaignwithnoinsights);

                                       // console.log($scope.selectedcampaignsinsightscount);
//                                        if($scope.campaignwithnoinsights == $scope.selectedcampaignsinsightscount)
//                                        {
//                                            $scope.nograph = true;
//                                        }

                                        }    
                                   }));

                                                                
                                                   
                                                            }
                                                            else
                                                            {
                                                                console.log("getting twitter campaign insights");
                                                                //getting twitter ad account insights on load
                                                                if($scope.structarray[i].networkDetails[j].hasOwnProperty('twAdAccountId'))
                                                                {
                        //                                                         $scope.readtwitteradaccountInsightsforlastweek($scope.fromDate, $scope.toDate, $scope.breakdown, $scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                    $scope.twbreakpoints = [];
                                                                                    $scope.twwholemetricArray = [];
                                                                                    $scope.twcampgrapharray=[];
                                                                                    $scope.twwholemetricname = [];       
                                                                                    if(breakdown == "DAILY")
                                                                                    {
                                                                                        $scope.twdisplaydate=[];
                                                                                        //getting dates between corresponding selected start and end values
                                                                                         date1 = new Date(sdate);
                                                                                         date2 = new Date(edate);
                                                                                         var day = 1000 * 60 * 60 * 24;
                                                                                         var diff = (date2.getTime() - date1.getTime()) / day;
                                                                                         for (var i1 = 0; i1 <= diff; i1++)
                                                                                         {
                                                                                             var xx = date1.getTime() + day * i1;
                                                                                             var yy = new Date(xx);

                                                                                             var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                                                                                             var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                                                                                             $scope.twbreakpoints.push(d2);
                                                                                         }
                                                                                      //  console.log($scope.breakpoints);
                                                                                         for(var i2 = 0; i2 <$scope.breakpoints.length; i2++)
                                                                                        {
                                                                                             $scope.twdisplaydate.push(new Date($scope.twbreakpoints[i2]).getDate() + "-" + new Date($scope.twbreakpoints[i2]).toLocaleString('en-us', { month: "short" }));
                                                                                        }
                                                                                       // console.log($scope.displaydate);
                                                                                    }
                                                                                    promises.push(performanceServices.readadcampaigninsights($scope.structarray[i].networkDetails[j].userNetworkMapId,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,sdate,edate,undefined,breakdown,appSettings.twNetwork,false).then(function(response)
                                                                                    {     
                                                                                        if(response.appStatus == 0)
                                                                                        {       $scope.twwholemetricArray = [];
                                                                                             //   $rootScope.progressLoader = "none";
                                                                                                //$scope.nograph=false;
                                                                                                $scope.innerarray = [];
                                                                                                $scope.weekvalue = [];
                                                                                                $scope.weeknum=[];
                                                                                                $scope.monthnum=[];
                                                                                                $scope.quaternum=[];
                                                                                                $scope.halfnum=[];
                                                                                                $scope.yearnum=[];
                                                                                                $scope.date = [];
                                                                                                var iden =0;

                                                                                                $scope.campaigninsights = response.adCampaignInsights;
                                                                                                angular.forEach($scope.campaigninsights, function (value, key) {
                                                                                                        var JsonObj = $scope.campaigninsights[key]
                                                                                                        var array = [];

                                                                                                        for (var j1 in JsonObj) {
                                                                                                                if (JsonObj.hasOwnProperty(j1) && !isNaN(+j1)) {
                                                                                                                        $scope.innerarray = JsonObj[j1];
                                                                                                                        //converting timestamp to dates
                                                                                                                        if(breakdown == "DAILY")
                                                                                                                        {    
                                                                                                                                 for (var timestamp in $scope.innerarray)
                                                                                                                                {
                                                                                                                                            var timestmp=timestamp.toString();
                                                                                                                                            if(timestmp.length==10)
                                                                                                                                            {
                                                                                                                                                //timestamp is in seconds
                                                                                                                                                //converting to milliseconds
                                                                                                                                                var timest=timestmp.concat("000");
                                                                                                                                               // console.log(timest);
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                                timest=timestmp;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                             var date = $filter('date')(timest, 'yyyy-MM-dd');
                                                                                                                                              //$scope.date.push(date);
                                                                                                                                               $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));

                                                                                                                                }
                                                                                                                   }
                                                                                                                        //calculating week number from response
                                                                                                                        else if(breakdown == "WEEKLY")
                                                                                                                        {
                                                                                                                                for (var weeknum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=weeknum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.weeknum.push(parts);
                                                                                                                                                   $scope.getdatesfromweeknum(weekno,year);
                                                                                                                                        }
                                                                                                                                  //   console.log($scope.weeknum);
                                                                                                                        }
                                                                                                                        //calculating month number from response
                                                                                                                        else if(breakdown == "MONTHLY")
                                                                                                                        {
                                                                                                                                for (var monthnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=monthnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.monthnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating quarter number from response
                                                                                                                        else if(breakdown == "QUARTERLY")
                                                                                                                        {
                                                                                                                                for (var quaternum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=quaternum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.quaternum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating half-yearly number from response
                                                                                                                        else if(breakdown == "HALFYEARLY")
                                                                                                                        {
                                                                                                                                for (var halfnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=halfnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   var weekno=parts[2];
                                                                                                                                                   $scope.halfnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        //calculating yearly number from response
                                                                                                                        else if(breakdown == "YEARLY")
                                                                                                                        {
                                                                                                                                for (var yearnum in $scope.innerarray)
                                                                                                                                        {
                                                                                                                                                   var parts=yearnum.split('_').join(' ');
                                                                                                                                                   var year=parts[0];
                                                                                                                                                   $scope.yearnum.push(parts);
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        // traversing into the object to get insights
                                                                                                                        angular.forEach($scope.innerarray, function (value, key) {
                                                                                                                                 var id1 = 1;
                                                                                                                                $scope.twwholemetricname = [];
                                                                                                                                $scope.twwholemetricArray = [];
                                                                                                                                $scope.hasinsightdetails=false;
                                                                                                                                $scope.arrayofobj = [];
                                                                                                                                $scope.parentmetricarray = [];
                                                                                                                                $scope.insightsarr = [];
                                                                                                                                $scope.arr1 = [];
                                                                                                                                $scope.arr2 = [];
                                                                                                                                var totalclicks = 0;
                                                                                                                                var totalimpressions = 0;
                                                                                                                                var totalspend = 0;
                                                                                                                                var totalactions = 0;
                                                                                                                                var t = $scope.innerarray[key];

                                                                                                                                for (var k1 in t)
                                                                                                                                {
                                                                                                                                        if (k1 == "clicks")
                                                                                                                                        {
                                                                                                                                                totalclicks+=t.clicks;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalclicks,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);

                                                                                                                                        }
                                                                                                                                        if (k1 == "impressions")
                                                                                                                                        {
                                                                                                                                                totalimpressions+=t.impressions;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalimpressions,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);
                                                                                                                                        }

                                                                                                                                        if (k1 == "spend")
                                                                                                                                        {
                                                                                                                                                 totalspend+=t.spend;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": k1,
                                                                                                                                                        "value": totalspend,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push(k1);
                                                                                                                                        }
                                                                                                                                        if (k1 == "callToAction")
                                                                                                                                        {

                                                                                                                                                 totalactions+=t.callToAction;
                                                                                                                                                var obj = {
                                                                                                                                                        "name": "actions",
                                                                                                                                                        "value": totalactions,
                                                                                                                                                        "id": id1++,
                                                                                                                                                        "disabled": "false"
                                                                                                                                                }
                                                                                                                                                $scope.twwholemetricArray.push(obj);
                                                                                                                                                $scope.twwholemetricname.push("actions");
                                                                                                                                        }

                                                                                                                                        if (k1 == "insightsDetails")
                                                                                                                                        {
                                                                                                                                                $scope.hasinsightdetails=true;
                                                                                                                                                $scope.insightsarr = t.insightsDetails;

                                                                                                                                        }
                                                                                                                                }
                                                                                                                                //traversing into the inner array
                                                                                                                                var res = $scope.insightsarr.id_data;
                                                                                                                                angular.forEach(res[0].metrics,function(value,key)
                                                                                                                                {
//                                                                                                                                    console.log(value,key);
                                                                                                                                    angular.forEach(value, function(value2,key2)
                                                                                                                                    {
                                                                                                                                        if (key == "clicks" || key == "impressions" || key == "spend" || key == "callToAction")
                                                                                                                                     {
                                                                                                                                         
                                                                                                                                     }
                                                                                                                                     else
                                                                                                                                     {
                                                                                                                                        if(typeof(value2) == "object")
                                                                                                                                        {
                                                                                                                                            angular.forEach(value2, function(value3,key3)
                                                                                                                                            {
//                                                                                                                                                console.log(typeof(value3));
                                                                                                                                               // console.log(value3,key2,key);
                                                                                                                                                var obj = {
                                                                                                                                                            "name": key.split('_').join(' ') + " - " + key2.split('_').join(' '),
                                                                                                                                                            "value": value3,
                                                                                                                                                            "id": id1++,
                                                                                                                                                            "disabled": "false"
                                                                                                                                                    }
                                                                                                                                                    $scope.twwholemetricArray.push(obj);
                                                                                                                                                    $scope.twwholemetricname.push(key.split('_').join(' ') + " - " + key2.split('_').join(' '));
                                                                                                                                                
                                                                                                                                            });
                                                                                                                                        }
                                                                                                                                        else
                                                                                                                                        {
                                                                                                                                            if(typeof(key2) == "string")
                                                                                                                                            {
                                                                                                                                               // console.log(value2,key2,key);
                                                                                                                                               var obj = {
                                                                                                                                                            "name": key.split('_').join(' ') + " - " + key2.split('_').join(' '),
                                                                                                                                                            "value": value2,
                                                                                                                                                            "id": id1++,
                                                                                                                                                            "disabled": "false"
                                                                                                                                                    }
                                                                                                                                                    $scope.twwholemetricArray.push(obj);
                                                                                                                                                    $scope.twwholemetricname.push(key.split('_').join(' ') + " - " + key2.split('_').join(' '));
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                               // console.log(value2,key);
                                                                                                                                               var obj = {
                                                                                                                                                            "name": key.split('_').join(' '),
                                                                                                                                                            "value": value2,
                                                                                                                                                            "id": id1++,
                                                                                                                                                            "disabled": "false"
                                                                                                                                                    }
                                                                                                                                                    $scope.twwholemetricArray.push(obj);
                                                                                                                                                    $scope.twwholemetricname.push(key.split('_').join(' '));
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    });
                                                                                                                                });
                                                                                                                                
                                                                                                                                
                                                                                                                                if(breakdown == "DAILY")
                                                                                                                                        {
                                                                                                                                        var obj1 = {
                                                                                                                                                "date": $scope.date[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        }
                                                                                                                                        else if(breakdown == "WEEKLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.weeknum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);

                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "MONTHLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.monthnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "QUARTERLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.quaternum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        }  
                                                                                                                                        else if(breakdown == "HALFYEARLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.halfnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        } 
                                                                                                                                        else if(breakdown == "YEARLY")
                                                                                                                                        {
                                                                                                                                                var obj1 = {
                                                                                                                                                "date": $scope.yearnum[iden++],
                                                                                                                                                "metricobj": $scope.twwholemetricArray,
                                                                                                                                                "usernetwork":$scope.structarray[i].networkDetails[j].userNetworkMapId,
                                                                                                                                                "childid":$scope.structarray[i].networkDetails[j].parent[k].child[l].id
                                                                                                                                                                  }           
                                                                                                                                         $scope.twcampgrapharray.push(obj1);
                                                                                                                                        } 
                                                                                                                                
                                                                                                                        });
                                                                                                                }
                                                                                                        }

                                                                                                });
                                                                                                                                 
                                                                                                                                 
                                                                                                                                 
                                                                                                                                        
                                                                                                                     
                                                                                        }
                                                                                        else{
                                                                                           
                                                                                    //     $rootScope.progressLoader = "none";
                                                                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                                                                    $window.localStorage.setItem("TokenExpired", true);
                                                                                                    $state.go('login');
                                                                                       } else {
                                                                                    //     $rootScope.progressLoader = "none";
                                                                                       $scope.editAdsetErrorMsg = 'none';
                                                                                       if (response.networkError != '' && response.networkError != undefined) {
                                                                                       if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                                       $scope.errorpopupHeading = 'Error';
                                                                                       $scope.errorMsg = response.networkError.message;
                                                                                       errorHeader.push($scope.errorpopupHeading);
                                                                                       errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                                       } else {
                                                                                       $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                                       $scope.errorMsg = response.networkError.error_user_msg;
                                                                                       errorHeader.push($scope.errorpopupHeading);
                                                                                       errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                            
                                                                                       }
                                                                                       } else {
                                                                                          $scope.errorpopupHeading = "Error";
                                                                                          $scope.errorMsg = response.errorMessage;
                                                                                           errorHeader.push(" Advertiser:<b>"+$scope.structarray[i].advertiserName + "</b><br> parentcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[j].name+"</b><br> childcampaign:<b>" + $scope.structarray[i].networkDetails[j].parent[k].child[l].name+"</b>");
                                                                                          errorString.push($scope.errorMsg);errornetwork.push($scope.structarray[i].networkDetails[j].networkName);
                                                                                   //       $scope.errorhandeler();
                                                       
                                                                                                                                              }}
                                                                                        }
                                                                                    }));
                                                                            }
                                                                        }
                                                                                                                                                 
                                                    })(i,j,k,l)
                                                                        
                                                }
                                            }
//                                        }
                                    }    
                                }       
                                else
                                {
                                     //selected parent has no child
                                    $scope.nograph=true;
                                }
                        }
                    }
                }
                  
                $q.all(promises).finally(
                function(){
                    $scope.progressLoader="none";
                   errorCompletionStatus="true"
                   $scope.errorhandeler();
                   
                     if($scope.selectedcampaign!="" && $scope.selectedcampaign != undefined  && $scope.selectedcampaign!="Select Campaign")
                    {
                        console.log("plotting graph for campaign insights");
                        $scope.allmetricswithoutduplicates = [];
                    $scope.allmetricswithduplicates = [];
                    $scope.metricdropdown = [];
                    $scope.campgrapharray1 = [];
                    $scope.camptwgrapharray1 = [];
                  //  console.log( $scope.campgrapharray);
                  //  console.log( $scope.twcampgrapharray);
                    $scope.campgrapharray1 = angular.copy($scope.campgrapharray);
                    $scope.twcampgrapharray1 = angular.copy($scope.twcampgrapharray);

                    //getting all metrics without duplicates
                     angular.forEach($scope.wholemetricname, function (value, key) {
                           $scope.allmetricswithduplicates.push(value);                                           
                       });
                     angular.forEach($scope.twwholemetricname, function (val, k) {
                           $scope.allmetricswithduplicates.push(val);                                           
                       }); 

                    $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                            return index == self.indexOf(elem);
                    }); 
                    $scope.metricdropdown = [];
                    //updating the metric drop down 
                    var iden = 1;
                        angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                              var obj = {
                                    "name": val,
                                    "id": iden++,
                                    "disabled": "false"
                                }
                                $scope.metricdropdown.push(obj);
                        });
                  //  console.log( $scope.metricdropdown);
                    
                    
                    //checking whether the metrics selction is more than 4 and if so disabling the other metrics
                    $timeout(function(){
                         if ($scope.metricselect.length == 4)
                         {
                             $scope.map ={};
                             for (var i = 0; i < $scope.metricselect.length; i++) {
                                 $scope.map[$scope.metricselect[i]] = i;
                             }

                             $scope.disableid = [];
                             //disabling the remaining metrics
                             for (i = 0; i < $scope.metricdropdown.length; i++) {
                                 if (!($scope.metricdropdown[i].name in $scope.map)) {

                                     $scope.metricdropdown[i].disabled = "true";
                                     $scope.disableid.push($scope.metricdropdown[i].id);
                                 }
                             }
                             for (i = 0; i < $scope.metricdropdown.length; i++) {
                                 var _in = $scope.metricdropdown[i].id;
                                 angular.element('#list' + _in).removeClass('disableElement');
                             }
                             for (i = 0; i < $scope.disableid.length; i++)
                             {
                                 var _in = $scope.disableid[i];
                                     angular.element('#list' + _in).addClass('disableElement');
                             }
                         }
                     },200);
                        $rootScope.progressLoader = "none";
                        $scope.sampledatacreation(); 
                    }
               
             
                     
             
                }
                      
                     );
         
        };

                
        //if no campaign is selected
        $scope.nocampaignselection = function()
        {   
            $scope.selectedcampaign="Select Campaign";
            $scope.selectedcampbool = false;
            $scope.selectedcampobj = {};
            //no parent/child campaign is selected
            if($scope.networkname == "" || $scope.networkname == undefined || $scope.networkname == null)
            {
                
                //checking whether advertiser dropdown is selected or  not
                if($scope.advertiserId!= "" && $scope.advertiserId!= null && $scope.advertiserId!= undefined )
                {
                    //no network selected
                    //advertiser is selected
                              
                                $scope.tmp = [];
                                $scope.tmp1=[];
                                $scope.allmetricswithoutduplicates = [];
                                $scope.allmetricswithduplicates = [];
                                $scope.metricdropdown = [];
                                $scope.wholemetricname = [];
                                $scope.twwholemetricname = [];
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                //getting usernetworkmap id of selected advertiser
                                                if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                   if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                                   {
                                                                       //filtering the graph array for only fb's user network map id
                                                                        angular.forEach($scope.grapharray, function (val, key) {
                                                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                {
                                                                                     $scope.tmp.push(val);
                                                                                     angular.forEach(val.metricobj, function (val1, key) {
                                                                                            $scope.wholemetricname.push(val1.name);
                                                                                        });
                                                                                }
                                                                        });
                                                                   }
                                                                   else
                                                                   {
                                                                       //filtering the graph array for only fb's user network map id
                                                                       angular.forEach($scope.twgrapharray, function (val, key) {
                                                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                {
                                                                                     $scope.tmp1.push(val);
                                                                                     angular.forEach(val.metricobj, function (val1, key) {
                                                                                            $scope.twwholemetricname.push(val1.name);
                                                                                        });
                                                                                }
                                                                        });
                                                                   }
                                                            }
                                                    }
                                                }
                                            }
                                    //getting all metrics without duplicates
                                        angular.forEach($scope.wholemetricname, function (value, key) {
                                              $scope.allmetricswithduplicates.push(value);                                           
                                          });
                                        angular.forEach($scope.twwholemetricname, function (val, k) {
                                              $scope.allmetricswithduplicates.push(val);                                           
                                          }); 

                                       $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                               return index == self.indexOf(elem);
                                       }); 

                                       //displaying default metric value   
                                         $scope.metricselect = [];
                                         $scope.metricselect.push("impressions");

                                       //updating the metric drop down 
                                       var iden = 1;
                                           angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                                 var obj = {
                                                       "name": val,
                                                       "id": iden++,
                                                       "disabled": "false"
                                                   }
                                                   $scope.metricdropdown.push(obj);
                                           });  

                                        for (i = 0; i < $scope.disableid.length; i++)
                                        {
                                            var _in = $scope.disableid[i];
                                            angular.element('#list' + _in).removeClass('disableElement');
                                        }
                                        $scope.map = {};
                                        $scope.disableid = [];
                                            
                                            
                                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                        {
                                            $scope.grapharray1 = angular.copy($scope.tmp);
                                            $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                            $scope.nograph = false;
                                            $scope.newgraph = "true";
                                            $scope.sampledatacreation();
                                        }
                                        else
                                        {
                                            $scope.nograph = true;
                                        }
                   
                }
                else
                {
                    //no advertiser no network 
                    //should draw graph for both fb and twitter 
                    $scope.newgraph='false';
                    //displaying default metric value   
                    $scope.metricselect = [];
                    $scope.metricselect.push("impressions");
                    for (i = 0; i < $scope.disableid.length; i++)
                    {
                        var _in = $scope.disableid[i];
                        angular.element('#list' + _in).removeClass('disableElement');
                    }
                    $scope.map = {};
                    $scope.disableid = [];
                    
                    //checking whether from and to dates are selected or not 
                    if($scope.enteredfromDate == undefined || $scope.enteredtoDate == undefined || $scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
                    {
                        $scope.formattedtodate = localDateTimetoUTCDateTime(new Date());
                        $scope.formattedfromdate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
                        $scope.breakdown = "DAILY";
                        //getting account insights for lastweek dates
                        $scope.allaccountinsights($scope.formattedfromdate , $scope.formattedtodate , $scope.breakdown);
                    }
                    else
                    {    //getting account insights for selected date range
                        $scope.allaccountinsights($scope.startdat , $scope.enddat , $scope.breakdown);
                    }
                    
                }
                
            }
            else
            {    
                //network is selected
                 //checking whether advertiser dropdown is selected or  not
                if($scope.advertiserId!= "" && $scope.advertiserId!= null && $scope.advertiserId!= undefined )
                {
                    //network is selected
                    //advertiser is selected
                     
                        $scope.tmp = [];
                        $scope.tmp1=[];
                        $scope.allmetricswithoutduplicates = [];
                        $scope.allmetricswithduplicates = [];
                        $scope.metricdropdown = [];
                        $scope.wholemetricname = [];
                        $scope.twwholemetricname = [];
                        for (i = 0; i < $scope.structarray.length; i++){
                            //getting usernetworkmap id of selected advertiser
                            if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                            //getting usernetworkmap id of selected network
                                            if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                {   
                                                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                        {
                                                            //filtering the graph array for only selected advertiser's user network map id
                                                            angular.forEach($scope.grapharray, function (val, key) {
                                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                            {
                                                                 $scope.tmp.push(val);
                                                                 angular.forEach(val.metricobj, function (val1, key) {
                                                                        $scope.wholemetricname.push(val1.name);
                                                                        });
                                                            }
                                                            });
                                                           
                                                        }
                                                        else
                                                        {
                                                            angular.forEach($scope.twgrapharray, function (val, key) {
                                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                            {
                                                                 $scope.tmp1.push(val);
                                                                 angular.forEach(val.metricobj, function (val1, key) {
                                                                        $scope.twwholemetricname.push(val1.name);
                                                                        });
                                                            }
                                                            });
                                                            
                                                        }
                                                }
                                            }
                                        }
                                }
                            }
                            //getting all metrics without duplicates
                            angular.forEach($scope.wholemetricname, function (value, key) {
                                  $scope.allmetricswithduplicates.push(value);                                           
                              });
                            angular.forEach($scope.twwholemetricname, function (val, k) {
                                  $scope.allmetricswithduplicates.push(val);                                           
                              }); 

                           $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                   return index == self.indexOf(elem);
                           }); 
                           
                           //displaying default metric value   
                             $scope.metricselect = [];
                             $scope.metricselect.push("impressions");
                             
                           //updating the metric drop down 
                           var iden = 1;
                               angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                     var obj = {
                                           "name": val,
                                           "id": iden++,
                                           "disabled": "false"
                                       }
                                       $scope.metricdropdown.push(obj);
                               });  
                            
                            for (i = 0; i < $scope.disableid.length; i++)
                            {
                                var _in = $scope.disableid[i];
                                angular.element('#list' + _in).removeClass('disableElement');
                            }
                            $scope.map = {};
                            $scope.disableid = [];
                          //  console.log($scope.map);
                          //  console.log($scope.disableid);
                            
                            if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                            {
                                $scope.grapharray1 = angular.copy($scope.tmp);
                                $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                $scope.nograph = false;
                                $scope.newgraph = "true";
                                $scope.sampledatacreation();
                            }
                            else
                            {
                                $scope.nograph = true;
                            }
                }
                else
                {
                    //network is selected
                    //no advertiser is selected
                    $scope.tmp = [];
                    $scope.tmp1=[];
                    $scope.allmetricswithoutduplicates = [];
                    $scope.allmetricswithduplicates = [];
                    $scope.metricdropdown = [];
                    $scope.wholemetricname = [];
                    $scope.twwholemetricname = [];
                    for (i = 0; i < $scope.structarray.length; i++){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                        //getting usernetworkmap id of selected network
                                        if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                        {
                                            if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                            {
                                                //filtering the graph array for only selected advertiser's user network map id
                                                angular.forEach($scope.grapharray, function (val, key) {
                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                {
                                                     $scope.tmp.push(val);
                                                      angular.forEach(val.metricobj, function (val1, key) {
                                                            $scope.wholemetricname.push(val1.name);
                                                            });
                                                }
                                                });
                                               
                                            }
                                            else
                                            {
                                                angular.forEach($scope.twgrapharray, function (val, key) {
                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                {
                                                     $scope.tmp1.push(val);
                                                      angular.forEach(val.metricobj, function (val1, key) {
                                                            $scope.twwholemetricname.push(val1.name);
                                                            });
                                                }
                                                });
                                               
                                            }
                                          //  console.log($scope.tmp);
                                          //  console.log($scope.tmp1);
                                        }
                                    }
                                }     
                        }
                        
                        //getting all metrics without duplicates
                            angular.forEach($scope.wholemetricname, function (value, key) {
                                  $scope.allmetricswithduplicates.push(value);                                           
                              });
                            angular.forEach($scope.twwholemetricname, function (val, k) {
                                  $scope.allmetricswithduplicates.push(val);                                           
                              }); 

                           $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                   return index == self.indexOf(elem);
                           }); 
                           
                           //displaying default metric value   
                             $scope.metricselect = [];
                             $scope.metricselect.push("impressions");
                             
                           //updating the metric drop down 
                            var iden = 1;
                            angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                 var obj = {
                                       "name": val,
                                       "id": iden++,
                                       "disabled": "false"
                                   }
                                   $scope.metricdropdown.push(obj);
                           }); 

                            for (i = 0; i < $scope.disableid.length; i++)
                            {
                                var _in = $scope.disableid[i];
                                angular.element('#list' + _in).removeClass('disableElement');
                            }
                               
                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                        {
                            $scope.grapharray1 = angular.copy($scope.tmp);
                            $scope.twgrapharray1 = angular.copy($scope.tmp1);
                            $scope.nograph = false;
                            $scope.newgraph = "true";
                            $scope.sampledatacreation();
                        }
                        else
                        {
                            $scope.nograph = true;
                        }
                
                }
           
            }

        }
        $scope.resetdate = function(date)
        {
                $scope.from="";
                $scope.to="";
                $scope.fromDate1="";
                $scope.toDate1="";
                $scope.startdat = "";
                $scope.enddat = "";
                $scope.newgraph = 'false';
                //getting last week dates
                var today = new Date();
                $scope.formattedtodate = localDateTimetoUTCDateTime(new Date());
                $scope.formattedfromdate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
                $scope.breakdown = "DAILY";
                $scope.allaccountinsights($scope.formattedfromdate , $scope.formattedtodate , $scope.breakdown);
                $scope.allcampaigninsights($scope.formattedfromdate , $scope.formattedtodate , $scope.breakdown);
                
                
                //updating the metric dropdown
                
                   

        }
  
       //getting parent and child campaign details for the selected advertiser
        $scope.selectadvertiser = function(advertiserId)
        {
//            console.log($scope.advertiserId);
            $scope.selectedcampbool = false;
            if(advertiserId!="")
            {    
                    var advwithparent =0;
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    //updating campaign dropdown
                    $scope.selectedcampaign = '';
                    var advwithparent =0;
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    
                
                    //updatin the campaign dropdown on load
                       for(i=0;i<$scope.structarray.length;i++)
                            {
                                if ($scope.structarray[i].advertiserId == $scope.advertiserId)
                                {    if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                        {
                                            //as FB and twitter has same parent campaigns, pushing only parent campaigns under fb 
                                            if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                            {
                                                if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                                {
                                                    advwithparent++;
                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            var obj = {
                                                                "id":$scope.structarray[i].networkDetails[j].parent[k].id,
                                                                "name":$scope.structarray[i].networkDetails[j].parent[k].name,
                                                                "type":"Parent"
                                                                };
                                                            $scope.wholeParentArray.push(obj);
                                                        }
                                                }
                                                else
                                                {
                                                     if(advwithparent ==0)
                                                    {   
                                                        //the selected advertsier has no parent/child campaigns 
                                                        $scope.wholechildArray = [];
                                                        $scope.wholeParentArray = [];
                                                    }
                                                }
                                            }    
                                        }
                                    }
                                }
                            }
                       
                       for(i=0;i<$scope.structarray.length;i++)
                            {
                                if ($scope.structarray[i].advertiserId == $scope.advertiserId)
                                {
                                    if($scope.structarray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.structarray[i].networkDetails.length;j++)
                                        {
                                                if($scope.structarray[i].networkDetails[j].hasOwnProperty("parent"))
                                                {
                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            if($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty("child"))
                                                            {
                                                                for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                    {
                                                                        var obj = {
                                                                            "id":$scope.structarray[i].networkDetails[j].parent[k].child[l].id,
                                                                            "name":$scope.structarray[i].networkDetails[j].parent[k].child[l].name,
                                                                            "type":"child",
                                                                            "parentid":$scope.structarray[i].networkDetails[j].parent[k].id
                                                                            };
                                                                        $scope.wholechildArray.push(obj);
                                                                    }
                                                            }

                                                        }
                                                }
                                        }
                                    }
                                }
                            }
                    
                   
                    
                    
                    //updating network dropdown
                     $scope.networkname='';
                     for (i = 0; i < $scope.structarray.length; i++){
                        if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                $scope.networkDropDown = [];
                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                        var obj = {
                                            "networkId":$scope.structarray[i].networkDetails[j].networkId,
                                            "networkName":$scope.structarray[i].networkDetails[j].networkName,
                                            "networkURL":$scope.structarray[i].networkDetails[j].networkUrl
                                            };
                                        $scope.networkDropDown.push(obj);  
                                        }
                            }
                            else
                            {
                                //the selected advertsier has no networks 
                                $scope.networkDropDown = [];
                            }
                        }
                    }
                    
                    
                $scope.nograph=false;   
                $scope.selectedgrapharray = [];
                //advertiser selected 
                        $scope.tmp = [];
                        $scope.tmp1 = [];
                        $scope.allmetricswithoutduplicates = [];
                        $scope.allmetricswithduplicates = [];
                        $scope.metricdropdown = [];
                        $scope.wholemetricname = [];
                        $scope.twwholemetricname = [];
                                for (i = 0; i < $scope.structarray.length; i++){
                                        if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                       //filtering the graph array for only selected advertiser's user network map id
                                                        angular.forEach($scope.grapharray, function (val, key) {
                                                                    if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                    {
                                                                         $scope.tmp.push(val);
                                                                         angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.wholemetricname.push(val1.name);
                                                                            });
                                                                    }
                                                            });
                                                        angular.forEach($scope.twgrapharray, function (val, key) {
                                                                    if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                    {
                                                                         $scope.tmp1.push(val);
                                                                         angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.twwholemetricname.push(val1.name);
                                                                            });
                                                                    }
                                                            });
                                                    }
                                                }
                                            }
                                        }
                                    //getting all metrics without duplicates
                                     angular.forEach($scope.wholemetricname, function (value, key) {
                                           $scope.allmetricswithduplicates.push(value);                                           
                                       });
                                     angular.forEach($scope.twwholemetricname, function (val, k) {
                                           $scope.allmetricswithduplicates.push(val);                                           
                                       }); 
                                       
                                    $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                            return index == self.indexOf(elem);
                                    }); 
                                    
                                    $scope.metricdropdown = [];
                                    //updating the metric drop down 
                                    var iden = 1;
                                        angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                              var obj = {
                                                    "name": val,
                                                    "id": iden++,
                                                    "disabled": "false"
                                                }
                                                $scope.metricdropdown.push(obj);
                                        });
                                        //checking whether the metrics selction is more than 4 and if so disabling the other metrics
                                       $timeout(function(){
                                            if ($scope.metricselect.length == 4)
                                            {
                                                $scope.map={};
                                                for (var i = 0; i < $scope.metricselect.length; i++) {
                                                   $scope.map[$scope.metricselect[i]] = i;
                                                }

                                                $scope.disableid = [];
                                                //disabling the remaining metrics
                                                for (i = 0; i < $scope.metricdropdown.length; i++) {
                                                    if (!($scope.metricdropdown[i].name in $scope.map)) {

                                                        $scope.metricdropdown[i].disabled = "true";
                                                        $scope.disableid.push($scope.metricdropdown[i].id);
                                                    }
                                                }
                                                for (i = 0; i < $scope.metricdropdown.length; i++) {
                                                    var _in = $scope.metricdropdown[i].id;
                                                    angular.element('#list' + _in).removeClass('disableElement');
                                                }
                                                for (i = 0; i < $scope.disableid.length; i++)
                                                {
                                                    var _in = $scope.disableid[i];
                              
                                                        angular.element('#list' + _in).addClass('disableElement');
                                                }
                                            }
                                        },200);
                                     
                                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                        {
                                            $scope.grapharray1 = angular.copy($scope.tmp);
                                            $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                            $scope.nograph = false;
                                            $scope.newgraph = "true";
                                            $scope.sampledatacreation();
                                        }
                                        else
                                        {
                                            $scope.nograph = true;
                                        }
                                         
                 
           }
           else
           {
                //no advertiser is selected
                //updating campaign dropdown
                $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
                $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
                $scope.selectedcampaign="Select Campaign";   
               
               
                //updating network dropdown
                $scope.networkname='';
              //  console.log($scope.networkDropDownOnLoad);
                $scope.networkDropDown =  angular.copy($scope.networkDropDownOnLoad);
                
            $scope.newgraph='false';
           //checking whether from and to dates are selected or not 
            if($scope.enteredfromDate == undefined || $scope.enteredtoDate == undefined || $scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
            {
            $scope.formattedtodate = localDateTimetoUTCDateTime(new Date());
            $scope.formattedfromdate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
            $scope.breakdown = "DAILY";
                    //getting account insights for lastweek dates
                    $scope.allaccountinsights($scope.formattedfromdate , $scope.formattedtodate , $scope.breakdown);
            }
            else
            {    //getting account insights for selected date range
                 $scope.allaccountinsights($scope.startdat , $scope.enddat , $scope.breakdown);
            } 
           // $scope.wholeParentarraydisponload=$scope.wholeParentarraydisp;
                
           }    
           
        }
        
        
         //changing the metric dropdown based on selected advertiser
        $scope.selectnetwork = function(networkId)
        {
            $scope.selectedcampbool = false;
            if($scope.networkname == "" || $scope.networkname == undefined || $scope.networkname == null)
            {
                
                //checking whether advertiser dropdown is selected or  not
                if($scope.advertiserId!= "" && $scope.advertiserId!= null && $scope.advertiserId!= undefined )
                {
                    //no network selected
                    //advertiser is selected
                              
                                $scope.tmp = [];
                                $scope.tmp1=[];
                                $scope.allmetricswithoutduplicates = [];
                                $scope.allmetricswithduplicates = [];
                                $scope.metricdropdown = [];
                                $scope.wholemetricname = [];
                                $scope.twwholemetricname = [];
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                //getting usernetworkmap id of selected advertiser
                                                if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                   if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                                   {
                                                                       //filtering the graph array for only fb's user network map id
                                                                        angular.forEach($scope.grapharray, function (val, key) {
                                                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                {
                                                                                     $scope.tmp.push(val);
                                                                                     angular.forEach(val.metricobj, function (val1, key) {
                                                                                            $scope.wholemetricname.push(val1.name);
                                                                                        });
                                                                                }
                                                                        });
                                                                   }
                                                                   else
                                                                   {
                                                                       //filtering the graph array for only fb's user network map id
                                                                       angular.forEach($scope.twgrapharray, function (val, key) {
                                                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                {
                                                                                     $scope.tmp1.push(val);
                                                                                     angular.forEach(val.metricobj, function (val1, key) {
                                                                                            $scope.twwholemetricname.push(val1.name);
                                                                                        });
                                                                                }
                                                                        });
                                                                   }
                                                            }
                                                    }
                                                }
                                            }
                                    //getting all metrics without duplicates
                                        angular.forEach($scope.wholemetricname, function (value, key) {
                                              $scope.allmetricswithduplicates.push(value);                                           
                                          });
                                        angular.forEach($scope.twwholemetricname, function (val, k) {
                                              $scope.allmetricswithduplicates.push(val);                                           
                                          }); 

                                       $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                               return index == self.indexOf(elem);
                                       }); 

                                       //displaying default metric value   
                                         $scope.metricselect = [];
                                         $scope.metricselect.push("impressions");

                                       //updating the metric drop down 
                                       var iden = 1;
                                           angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                                 var obj = {
                                                       "name": val,
                                                       "id": iden++,
                                                       "disabled": "false"
                                                   }
                                                   $scope.metricdropdown.push(obj);
                                           });  

                                        for (i = 0; i < $scope.disableid.length; i++)
                                        {
                                            var _in = $scope.disableid[i];
                                            angular.element('#list' + _in).removeClass('disableElement');
                                        }
                                        $scope.map = {};
                                        $scope.disableid = [];
                                            
                                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                        {
                                            $scope.grapharray1 = angular.copy($scope.tmp);
                                            $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                            $scope.nograph = false;
                                            $scope.newgraph = "true";
                                            $scope.sampledatacreation();
                                        }
                                        else
                                        {
                                            $scope.nograph = true;
                                        }
                   
                    
                    
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    //updating campaign dropdown
                    $scope.selectedcampaign = '';
                    for (i = 0; i < $scope.structarray.length; i++){
                        if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                    (function(i,j)
                                        {  
                                            if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                    var obj = {
                                                        "id":$scope.structarray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.structarray[i].networkDetails[j].parent[k].name,
                                                        "type":"Parent",
                                                        "userNetworkMapId": $scope.structarray[i].networkDetails[j].userNetworkMapId
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                    if($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                    {
                                                        for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++){
                                                            var obj = {
                                                                "id":$scope.structarray[i].networkDetails[j].parent[k].child[l].id,
                                                                "name":$scope.structarray[i].networkDetails[j].parent[k].child[l].name,
                                                                "type":"child",
                                                                "parentid":$scope.structarray[i].networkDetails[j].parent[k].child[l].parentId
                                                            };
                                                            $scope.wholechildArray.push(obj);
                                                        }
                                                    }
                                                                        
                                                }
                                            }
                                            else
                                            {
                                                //the selected advertsier has no parent/child campaigns 
                                                 $scope.wholechildArray = [];
                                                 $scope.wholeParentArray = [];
                                            }
                                    })(i,j);    
                                }
                            }
                        }
                    }
                    
                
                }
                else
                {
                    //no advertiser no network 
                    //updating campaign dropdown
                    $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
                    $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
                    $scope.selectedcampaign="Select Campaign";
                    
                    
                    //should draw graph for both fb and twitter 
                           $scope.newgraph='false';
                    //checking whether from and to dates are selected or not 
                    if($scope.enteredfromDate == undefined || $scope.enteredtoDate == undefined || $scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
                    {
                        $scope.formattedtodate = localDateTimetoUTCDateTime(new Date());
                        $scope.formattedfromdate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
                        $scope.breakdown = "DAILY";
                        //getting account insights for lastweek dates
                        $scope.allaccountinsights($scope.formattedfromdate , $scope.formattedtodate , $scope.breakdown);
                    }
                    else
                    {    //getting account insights for selected date range
                        $scope.allaccountinsights($scope.startdat , $scope.enddat , $scope.breakdown);
                    }
                    
                }
                
            }
            else
            {    
                //network is selected
                 //checking whether advertiser dropdown is selected or  not
                if($scope.advertiserId!= "" && $scope.advertiserId!= null && $scope.advertiserId!= undefined )
                {
                    //network is selected
                    //advertiser is selected
                     
                        $scope.tmp = [];
                        $scope.tmp1=[];
                        $scope.allmetricswithoutduplicates = [];
                        $scope.allmetricswithduplicates = [];
                        $scope.metricdropdown = [];
                        $scope.wholemetricname = [];
                        $scope.twwholemetricname = [];
                        for (i = 0; i < $scope.structarray.length; i++){
                            //getting usernetworkmap id of selected advertiser
                            if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                        for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                            //getting usernetworkmap id of selected network
                                            if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                {   
                                                        if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                                        {
                                                            //filtering the graph array for only selected advertiser's user network map id
                                                            angular.forEach($scope.grapharray, function (val, key) {
                                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                            {
                                                                 $scope.tmp.push(val);
                                                                 angular.forEach(val.metricobj, function (val1, key) {
                                                                        $scope.wholemetricname.push(val1.name);
                                                                        });
                                                            }
                                                            });
                                                           
                                                        }
                                                        else
                                                        {
                                                            angular.forEach($scope.twgrapharray, function (val, key) {
                                                            if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                            {
                                                                 $scope.tmp1.push(val);
                                                                 angular.forEach(val.metricobj, function (val1, key) {
                                                                        $scope.twwholemetricname.push(val1.name);
                                                                        });
                                                            }
                                                            });
                                                            
                                                        }
                                                }
                                            }
                                        }
                                }
                            }
                            //getting all metrics without duplicates
                            angular.forEach($scope.wholemetricname, function (value, key) {
                                  $scope.allmetricswithduplicates.push(value);                                           
                              });
                            angular.forEach($scope.twwholemetricname, function (val, k) {
                                  $scope.allmetricswithduplicates.push(val);                                           
                              }); 

                           $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                   return index == self.indexOf(elem);
                           }); 
                           
                           //displaying default metric value   
                             $scope.metricselect = [];
                             $scope.metricselect.push("impressions");
                             
                           //updating the metric drop down 
                           var iden = 1;
                               angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                     var obj = {
                                           "name": val,
                                           "id": iden++,
                                           "disabled": "false"
                                       }
                                       $scope.metricdropdown.push(obj);
                               });  
                            
                            for (i = 0; i < $scope.disableid.length; i++)
                            {
                                var _in = $scope.disableid[i];
                                angular.element('#list' + _in).removeClass('disableElement');
                            }
                            $scope.map = {};
                            $scope.disableid = [];
                           // console.log($scope.map);
                           // console.log($scope.disableid);
                            
                            if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                            {
                                $scope.grapharray1 = angular.copy($scope.tmp);
                                $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                $scope.nograph = false;
                                $scope.newgraph = "true";
                                $scope.sampledatacreation();
                            }
                            else
                            {
                                $scope.nograph = true;
                            }
                                                
                           
                    //network is selected
                    //advertiser is selected
                    //updating campaign dropdown 
                    
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    //updating campaign dropdown
                    $scope.selectedcampaign = '';
                    for (i = 0; i < $scope.structarray.length; i++){
                        if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                    
                                    if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                    {    
                                    (function(i,j)
                                        {  
                                            if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                    var obj = {
                                                        "id":$scope.structarray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.structarray[i].networkDetails[j].parent[k].name,
                                                        "type":"Parent",
                                                        "userNetworkMapId": $scope.structarray[i].networkDetails[j].userNetworkMapId
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                    if($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                    {
                                                        for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++){
                                                            var obj = {
                                                                "id":$scope.structarray[i].networkDetails[j].parent[k].child[l].id,
                                                                "name":$scope.structarray[i].networkDetails[j].parent[k].child[l].name,
                                                                "type":"child",
                                                                "parentid":$scope.structarray[i].networkDetails[j].parent[k].child[l].parentId
                                                            };
                                                            $scope.wholechildArray.push(obj);
                                                        }
                                                    }
                                                                        
                                                }
                                            }
                                            else
                                            {
                                                //the selected advertsier and network has no parent/child campaigns 
                                                 $scope.wholechildArray = [];
                                                 $scope.wholeParentArray = [];
                                            }
                                    })(i,j);
                                    }
                                }
                            }
                        }
                    }
                    
                }
                else
                {
                    //network is selected
                    //no advertiser is selected
                    $scope.tmp = [];
                    $scope.tmp1=[];
                    $scope.allmetricswithoutduplicates = [];
                    $scope.allmetricswithduplicates = [];
                    $scope.metricdropdown = [];
                    $scope.wholemetricname = [];
                    $scope.twwholemetricname = [];
                    for (i = 0; i < $scope.structarray.length; i++){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                        //getting usernetworkmap id of selected network
                                        if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                        {
                                            if($scope.structarray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                            {
                                                //filtering the graph array for only selected advertiser's user network map id
                                                angular.forEach($scope.grapharray, function (val, key) {
                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                {
                                                     $scope.tmp.push(val);
                                                      angular.forEach(val.metricobj, function (val1, key) {
                                                            $scope.wholemetricname.push(val1.name);
                                                            });
                                                }
                                                });
                                               
                                            }
                                            else
                                            {
                                                angular.forEach($scope.twgrapharray, function (val, key) {
                                                if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                {
                                                     $scope.tmp1.push(val);
                                                      angular.forEach(val.metricobj, function (val1, key) {
                                                            $scope.twwholemetricname.push(val1.name);
                                                            });
                                                }
                                                });
                                               
                                            }
                                          //  console.log($scope.tmp);
                                          //  console.log($scope.tmp1);
                                        }
                                    }
                                }     
                        }
                        
                        //getting all metrics without duplicates
                            angular.forEach($scope.wholemetricname, function (value, key) {
                                  $scope.allmetricswithduplicates.push(value);                                           
                              });
                            angular.forEach($scope.twwholemetricname, function (val, k) {
                                  $scope.allmetricswithduplicates.push(val);                                           
                              }); 

                           $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                   return index == self.indexOf(elem);
                           }); 
                           
                           //displaying default metric value   
                             $scope.metricselect = [];
                             $scope.metricselect.push("impressions");
                             
                           //updating the metric drop down 
                            var iden = 1;
                            angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                 var obj = {
                                       "name": val,
                                       "id": iden++,
                                       "disabled": "false"
                                   }
                                   $scope.metricdropdown.push(obj);
                           }); 

                            for (i = 0; i < $scope.disableid.length; i++)
                            {
                                var _in = $scope.disableid[i];
                                angular.element('#list' + _in).removeClass('disableElement');
                            }
                               
                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                        {
                            $scope.grapharray1 = angular.copy($scope.tmp);
                            $scope.twgrapharray1 = angular.copy($scope.tmp1);
                            $scope.nograph = false;
                            $scope.newgraph = "true";
                            $scope.sampledatacreation();
                        }
                        else
                        {
                            $scope.nograph = true;
                        }
                                                
                          
                    $scope.wholeParentArray = [];
                    $scope.wholechildArray = [];
                    //updating campaign dropdown
                    $scope.selectedcampaign = '';
                    for (i = 0; i < $scope.structarray.length; i++){
                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                    if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                    { 
                                    (function(i,j)
                                        {  
                                            if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                    var obj = {
                                                        "id":$scope.structarray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.structarray[i].networkDetails[j].parent[k].name,
                                                        "type":"Parent",
                                                        "userNetworkMapId": $scope.structarray[i].networkDetails[j].userNetworkMapId
                                                        };
                                                    $scope.wholeParentArray.push(obj);
                                                    if($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                    {
                                                        for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++){
                                                            var obj = {
                                                                "id":$scope.structarray[i].networkDetails[j].parent[k].child[l].id,
                                                                "name":$scope.structarray[i].networkDetails[j].parent[k].child[l].name,
                                                                "type":"child",
                                                                "parentid":$scope.structarray[i].networkDetails[j].parent[k].child[l].parentId
                                                            };
                                                            $scope.wholechildArray.push(obj);
                                                        }
                                                    }
                                                                        
                                                }
                                            }
                                            else
                                            {
                                                //the selected advertsier and network has no parent/child campaigns 
                                                 $scope.wholechildArray = [];
                                                 $scope.wholeParentArray = [];
                                            }
                                    })(i,j);
                                    }
                                }
                            }
                        
                    }
                
                }
           
            }
        
        }
        $scope.parentselection = function (parentobj)
        {
          //  var iden1=0;
            //console.log(parentobj);
            $scope.selectedcampobj= parentobj;
            $scope.selectedcampbool = true;
            $scope.selectedcampaign = '';
            $scope.selectedcampaign = parentobj.name;
            
            $scope.tmp = [];
            $scope.tmp1=[];
            $scope.allmetricswithoutduplicates = [];
            $scope.allmetricswithduplicates = [];
            $scope.metricdropdown = [];
            $scope.wholemetricname = [];
            $scope.twwholemetricname = [];
            $scope.campgrapharray1 = [];
            $scope.twcampgrapharray1 = [];
          //  console.log($scope.campgrapharray);
          //  console.log($scope.twcampgrapharray);
          //  console.log($scope.structarray);
            
            if($scope.networkname == "" || $scope.networkname == undefined || $scope.networkname == null)
            {
                //no network selected
				//campaign is selected
            for (i = 0; i < $scope.structarray.length; i++){
                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                (function(i,j)
                                    {  
                                        if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                            for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                    {
                                                        //getting the child ids of selected parent
                                                        if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                        {
                                                            for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                            {
                                                                 //filter the graph array for only selected campaign's usernetworkmap id
                                                                angular.forEach($scope.campgrapharray, function (val, key) {
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                        {
                                                                             $scope.tmp.push(val);
                                                                             angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.wholemetricname.push(val1.name);
                                                                            });
                                                                        }
                                                                });
                                                                angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                        {
                                                                             $scope.tmp1.push(val);
                                                                             angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.twwholemetricname.push(val1.name);
                                                                            });
                                                                        }
                                                                });

                                                            }

                                                        }
                                                        else
                                                        {
                                                            //selected parent has no child
                                                            $scope.nograph=true;
                                                        }
                                                    }

                                            }
                                        }

                                    })(i,j);
                        }
                    }
            }
            }
			else
			{
				//network selected
				//campaign is selected
                              //  console.log("network");
                              //  console.log($scope.campgrapharray);
            for (i = 0; i < $scope.structarray.length; i++){
                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                (function(i,j)
                                    {
                                        if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                        { 									
                                        if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                            for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                    {
                                                        //getting the child ids of selected parent
                                                        if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                        {
                                                            for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                            {
                                                                 //filter the graph array for only selected campaign's usernetworkmap id
                                                                angular.forEach($scope.campgrapharray, function (val, key) {
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                        {
                                                                             $scope.tmp.push(val);
                                                                             
                                                                             angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.wholemetricname.push(val1.name);
                                                                            });
                                                                        }
                                                                });
                                                                angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                        {
                                                                             $scope.tmp1.push(val);
                                                                             angular.forEach(val.metricobj, function (val1, key) {
                                                                                $scope.twwholemetricname.push(val1.name);
                                                                            });
                                                                        }
                                                                });

                                                            }

                                                        }
                                                        else
                                                        {
                                                            //selected parent has no child
                                                            $scope.nograph=true;
                                                        }
                                                    }

                                            }
                                        }
									}

                                    })(i,j);
                        }
                    }
            }
				
			}
            
            
            
        //    console.log($scope.wholemetricname);
        //   console.log($scope.twwholemetricname);
            
            
                //getting all metrics without duplicates
                            angular.forEach($scope.wholemetricname, function (value, key) {
                                  $scope.allmetricswithduplicates.push(value);                                           
                              });
                            angular.forEach($scope.twwholemetricname, function (val, k) {
                                  $scope.allmetricswithduplicates.push(val);                                           
                              }); 

                           $scope.allmetricswithoutduplicates = $scope.allmetricswithduplicates.filter(function(elem, index, self) {
                                   return index == self.indexOf(elem);
                           }); 
                           
                           //displaying default metric value   
                             $scope.metricselect = [];
                             $scope.metricselect.push("impressions");
                             
                           //updating the metric drop down 
                           var iden = 1;
                               angular.forEach($scope.allmetricswithoutduplicates, function (val, key1) {
                                     var obj = {
                                           "name": val,
                                           "id": iden++,
                                           "disabled": "false"
                                       }
                                       $scope.metricdropdown.push(obj);
                               });  
                        //    console.log($scope.metricdropdown);
                            for (i = 0; i < $scope.disableid.length; i++)
                            {
                                var _in = $scope.disableid[i];
                                angular.element('#list' + _in).removeClass('disableElement');
                            }
                            $scope.map = {};
                            $scope.disableid = [];
                        //    console.log($scope.map);
                        //    console.log($scope.disableid);
//                 console.log($scope.twcampgrapharray);
//                  angular.forEach($scope.twcampgrapharray, function (val, key) {
//                      if(val.childid == "7vu7q" && val.date == "6-Apr")
//                      {
//                          console.log(val.metricobj);
//                      }
//                  });
               // console.log($scope.tmp);
                console.log($scope.tmp1)
                if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                {
                    $scope.campgrapharray1 = angular.copy($scope.tmp);
                    $scope.twcampgrapharray1 = angular.copy($scope.tmp1);
                    $scope.nograph = false;
                    $scope.newgraph = "true";
                    $scope.sampledatacreation();
                }
                else
                {
                    $scope.nograph = true;
                }
        }

        $scope.test = function (parentobj, _index) {
           
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                {
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        }

        $scope.childselection = function (_index, childobj)
        {
            $scope.bool[childobj.parentid] = true;
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != childobj.parentid)
                {
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
           
            $scope.selectedcampaign = '';
            $scope.selectedcampaign = childobj.name;
            $scope.selectedcampobj =childobj;
            $scope.selectedcampbool = true;
            $scope.show = true;
            
            $scope.tmp = [];
            $scope.tmp1 = [];
            $scope.campgrapharray1 = [];
            $scope.twcampgrapharray1 = [];
        //    console.log($scope.campgrapharray);
        //    console.log($scope.twcampgrapharray);
            //getting insights of the selected child
                   for (i = 0; i < $scope.structarray.length; i++){
                        if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                (function(i,j)
                                    {  
                                            if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){                                           
                                                            if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                            {
                                                                for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                {
                                                                    if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == $scope.selectedcampobj.id)
                                                                    {
                                                                         //filter the graph array for only selected campaign's usernetworkmap id
                                                                            angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                    if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                    {
                                                                                         $scope.tmp.push(val);
                                                                                    }
                                                                            });
                                                                            angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                    if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                    {
                                                                                         $scope.tmp1.push(val);
                                                                                    }
                                                                            });
                                                                    }
                                                                }

                                                            }
                                                            else
                                                            {
                                                                //selected parent has no child
                                                                $scope.nograph=true;
                                                            }
                                                }
                                            }
                                    })(i,j);
                            }
                        }
                }
                if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                {
                    $scope.campgrapharray1 = angular.copy($scope.tmp);
                    $scope.twcampgrapharray1 = angular.copy($scope.tmp1);
                    $scope.nograph = false;
                    $scope.newgraph = "true";
                    $scope.sampledatacreation();
                }
                else
                {
                    $scope.nograph = true;
                }
           
           
           
        }
        
       
        $scope.metric_count = 0;
        $scope.show = false;
        $scope.isgraph = false;
        var result = [];
        $scope.disableid = [];
        var pos = 0;
        $scope.map = {};
        $scope.metricselect = [];
         
        $scope.showmetrics = function ()
        {
           
            $scope.show = false;
        };
        $scope.metricselection = function (val)
        {   
            $scope.isgraph = true;
            $scope.metric_count++;
           
            //console.log(lastweekdates);
            $scope.show = false;
            var index = $scope.metricselect.indexOf(val.name);
            if (index > -1)
            {
                $scope.metricselect.splice(index, 1);
                delete $scope.map[val.name];
                for (i = 0; i < $scope.disableid.length; i++)
                {
                    var _in = $scope.disableid[i];
                    angular.element('#list' + _in).removeClass('disableElement');
                }
            }
            else
            {
                //checking whether metric count exceeded 4 
                if ($scope.metricselect.length == 3)
                {
                    $scope.map ={};
                    $scope.metricselect.push(val.name);
                    for (var i = 0; i < $scope.metricselect.length; i++) {
                        $scope.map[$scope.metricselect[i]] = i;
                    }

                    $scope.disableid = [];
                    //disabling the remaining metrics
                    for (i = 0; i < $scope.metricdropdown.length; i++) {
                        if (!($scope.metricdropdown[i].name in $scope.map)) {

                            $scope.metricdropdown[i].disabled = "true";
                            $scope.disableid.push($scope.metricdropdown[i].id);
                        }
                    }
                    for (i = 0; i < $scope.disableid.length; i++)
                    {
                        var _in = $scope.disableid[i];
                        angular.element('#list' + _in).addClass('disableElement');
                    }
                }
                else
                {
                    $scope.metricselect.push(val.name);
                }
            }

            //creating an array for sample data
            $scope.plotarray=[];
            
            
            if($scope.metricselect.length==0)
            {
                //if no metrics are selected
                $scope.nograph=true;
               // $("#sampleChart").empty();
              //  $("#sampleChart svg.line-chart").eq(2).find("g").find("line").attr("opacity","0");     
            
            }
            else
            {
//                if($scope.metricselect.length==1) {
//                     $("#sampleChart svg.line-chart").attr("width", "1114");
//                     console.log('length is zero')
//                }
                $scope.nograph=false;
                $scope.sampledatacreation();
                
               // console.log($scope.nograph);
            }
            
        }

        //sample data creation with metric values
        $scope.metricdatacreation = function(array)
        {
                console.log($scope.newgraph);
                    if($scope.newgraph=="false")
                    {    
                       $scope.filteringdata(); 
                    }
                    else
                    {
                        $scope.plotgraph();
                        
                    }   
        }
        
        
        $scope.filteringdata = function()
        {
            if($scope.advertiserId == undefined || $scope.advertiserId=="" || $scope.advertiserId==null)
                            {
                                //no advertiser is selected
                                //getting account insights for selected date range
                                if($scope.selectedcampaign=="" || $scope.selectedcampaign == undefined  || $scope.selectedcampaign=="Select Campaign")
                                {
                                        //no camapigns too selected
                                        //
                                        if($scope.networkname=="" ||  $scope.networkname=="Select Networks" || $scope.networkname==undefined )
                                        {
                                            $scope.nograph = false;
                                            $scope.plotgraph();
                                        }
                                        else
                                        {
                                            //no camapigns selected
                                            //network is selected
                                            $scope.tmp =[];
                                            $scope.tmp1 =[];
                                            $scope.grapharray1 =[];
                                            $scope.twgrapharray1 =[];
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                //getting usernetworkmap id of selected network
                                                                if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                                {   
                                                                              //  console.log($scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                              //  console.log($scope.networkname);
                                                                                //filter the graph array for only selected network's usernetworkmap id
                                                                                angular.forEach($scope.grapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp.push(val);
                                                                                        }
                                                                                });
                                                                                angular.forEach($scope.twgrapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp1.push(val);
                                                                                        }
                                                                                });
                                                                    }
                                                                }    
                                                            }
                                                }
                                                
                                            if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                            {
                                                $scope.grapharray1 = angular.copy($scope.tmp);
                                                $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                                $scope.nograph = false;
                                                $scope.plotgraph();
                                            }
                                            else
                                            {
                                                $scope.nograph = true;
                                            }
                                            
                                        }
                                }
                                else
                                {
                                    //no advertiser selected
                                    //campaign is selected
                                    $scope.campgrapharray1=[];
                                    $scope.twcampgrapharray1=[];
                                    $scope.tmp =[];
                                    $scope.tmp1 =[];
                                    $scope.selectedcampbool = true;
                                 //   console.log($scope.selectedcampobj.type);
                                 //   console.log($scope.networkname);
                                    if($scope.selectedcampobj.type == "Parent")
                                    {
                                        //no network selected
                                        if($scope.networkname=="" ||  $scope.networkname=="Select Networks" || $scope.networkname==undefined )
                                        {
                                          //  console.log("no network selected");
                                            //getting insights of the selected parent
                                            for (i = 0; i < $scope.structarray.length; i++){
                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                                            {
                                                                                //getting the child ids of selected parent
                                                                                if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                {
                                                                                    for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                    {
                                                                                        (function(i,j,k,l)
                                                                                        {  
                                                                                                //   $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                                //filter the graph array for only selected campaign's usernetworkmap id
                                                                                               angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                          //  console.log(val);
                                                                                                            $scope.tmp.push(val);
                                                                                                       }
                                                                                               });
                                                                                               angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                         //  console.log(val);
                                                                                                            $scope.tmp1.push(val);
                                                                                                       }
                                                                                               });
                                                                                       
                                                                
                                                                                        })(i,j,k,l);
                                                                                    }

                                                                                }
                                                                                else
                                                                                {
                                                                                    //selected parent has no child
                                                                                    $scope.nograph=true;
                                                                                }
                                                                            }

                                                             }
                                                            }
                                                }
                                            }
                                    }
                                        }
                                        else
                                        {
                                          //  console.log("network selected");
                                          //network selected  
                                          //getting insights of the selected parent
                                            for (i = 0; i < $scope.structarray.length; i++){
                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                        if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                                { 
                                                                if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                                            {
                                                                                //getting the child ids of selected parent
                                                                                if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                {
                                                                                    for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                    {
                                                                                        (function(i,j,k,l)
                                                                                        {  
                                                                                                //   $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                                //filter the graph array for only selected campaign's usernetworkmap id
                                                                                               angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                           // console.log(val);
                                                                                                            $scope.tmp.push(val);
                                                                                                       }
                                                                                               });
                                                                                               angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                          // console.log(val);
                                                                                                            $scope.tmp1.push(val);
                                                                                                       }
                                                                                               });
                                                                                       
                                                                
                                                                                        })(i,j,k,l);
                                                                                    }

                                                                                }
                                                                                else
                                                                                {
                                                                                    //selected parent has no child
                                                                                    $scope.nograph=true;
                                                                                }
                                                                            }

                                                             }
                                                            }
                                                                }
                                                }
                                            }
                                    }
                                          
                                          
                                        }
                                            
                                    }
                                    else if ($scope.selectedcampobj.type == "child")
                                    {   
                                            //getting insights of the selected child
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                        (function(i,j)
                                                            {  
                                                                    if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                        for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){                                           
                                                                                    if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                    {
                                                                                        for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                        {
                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == $scope.selectedcampobj.id)
                                                                                            {
                                                                                                 //filter the graph array for only selected campaign's usernetworkmap id
                                                                                                    angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                            {
                                                                                                                 $scope.tmp.push(val);
                                                                                                            }
                                                                                                    });
                                                                                                    angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                            {
                                                                                                                 $scope.tmp1.push(val);
                                                                                                            }
                                                                                                    });
                                                                                            }
                                                                                        }
                                                   
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        //selected parent has no child
                                                                                        $scope.nograph=true;
                                                                                    }
                                                                        }
                                                                    }
                                                            })(i,j);
                                                    }
                                                }
                                        }
                                     
                                    }
                                  //  console.log($scope.tmp);
                                  //  console.log($scope.tmp1);
                                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                        {
                                            $scope.campgrapharray1 = angular.copy($scope.tmp);
                                            $scope.twcampgrapharray1 = angular.copy($scope.tmp1);
                                            $scope.nograph = false;
                                            $scope.plotgraph();
                                        }
                                        else
                                        {
                                            $scope.nograph = true;
                                        }
                                } 
                            }
                            else
                            {
                                //advertiser is selected
                                if($scope.selectedcampaign=="" || $scope.selectedcampaign == undefined  || $scope.selectedcampaign=="Select Campaign")
                                {
                                    //no parent/child campaign is selected
                                    //getting the user network map id of the selected advertiser
                                    $scope.newgraph ='false';
                                    
                                     if($scope.networkname=="" ||  $scope.networkname=="Select Networks" || $scope.networkname==undefined )
                                        {
                                                //no network is selected
                                                //getting account insights on load
                                                $scope.tmp =[];
                                                $scope.tmp1 =[];
                                               for (i = 0; i < $scope.structarray.length; i++){
                                                   //getting usernetworkmap id of selected advertiser
                                                    if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                        //filter the graph array for only selected network's usernetworkmap id
                                                                                angular.forEach($scope.grapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp.push(val);
                                                                                        }
                                                                                });
                                                                                angular.forEach($scope.twgrapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp1.push(val);
                                                                                        }
                                                                                });
                                                                    }
                                                            }
                                                    }
                                                }
                                                if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                                {
                                                    $scope.grapharray1 = angular.copy($scope.tmp);
                                                    $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                                    $scope.nograph = false;
                                                    $scope.plotgraph();
                                                }
                                                else
                                                {
                                                    $scope.nograph = true;
                                                }
                                        }
                                        else
                                        {
                                            $scope.tmp =[];
                                            $scope.tmp1 =[];
                                            //network is selected
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                //getting usernetworkmap id of selected advertiser
                                                if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                                    if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                            for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                //getting usernetworkmap id of selected network
                                                                if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                                { 
                                                                   
                                                                        //filter the graph array for only selected network's usernetworkmap id
                                                                                angular.forEach($scope.grapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp.push(val);
                                                                                        }
                                                                                });
                                                                                angular.forEach($scope.twgrapharray, function (val, key) {
                                                                                        if($scope.structarray[i].networkDetails[j].userNetworkMapId == val.usernetwork)
                                                                                        {
                                                                                             $scope.tmp1.push(val);
                                                                                        }
                                                                                });
                                                                }
                                                            }    
                                                        }
                                                    }
                                                }
                                                if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                                {
                                                    $scope.grapharray1 = angular.copy($scope.tmp);
                                                    $scope.twgrapharray1 = angular.copy($scope.tmp1);
                                                    $scope.nograph = false;
                                                    $scope.plotgraph();
                                                }
                                                else
                                                {
                                                    $scope.nograph = true;
                                                }
                                        }   
                                        
                                        
                                }
                                else
                                {    
                                   // advertiser selected 
                                   //camapign too selected
                                 
                                    $scope.campgrapharray1=[];
                                    $scope.twcampgrapharray1=[];
                                    $scope.tmp =[];
                                    $scope.tmp1 =[];
                                    $scope.selectedcampbool = true;
                                 //   console.log($scope.selectedcampobj.type);
                                 //   console.log($scope.networkname);
                                    if($scope.selectedcampobj.type == "Parent")
                                    {
                                        //no network selected
                                        if($scope.networkname=="" ||  $scope.networkname=="Select Networks" || $scope.networkname==undefined )
                                        {
                                        //    console.log("no network selected");
                                            //getting insights of the selected parent
                                            for (i = 0; i < $scope.structarray.length; i++){
                                            if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                                if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                                            {
                                                                                //getting the child ids of selected parent
                                                                                if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                {
                                                                                    for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                    {
                                                                                        (function(i,j,k,l)
                                                                                        {  
                                                                                                //   $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                                //filter the graph array for only selected campaign's usernetworkmap id
                                                                                               angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                        //    console.log(val);
                                                                                                            $scope.tmp.push(val);
                                                                                                       }
                                                                                               });
                                                                                               angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                        //   console.log(val);
                                                                                                            $scope.tmp1.push(val);
                                                                                                       }
                                                                                               });
                                                                                       
                                                                
                                                                                        })(i,j,k,l);
                                                                                    }

                                                                                }
                                                                                else
                                                                                {
                                                                                    //selected parent has no child
                                                                                    $scope.nograph=true;
                                                                                }
                                                                            }

                                                             }
                                                            }
                                                }
                                            }
                                            }
                                    }
                                        }
                                        else
                                        {
                                        //    console.log("network selected");
                                          //network selected  
                                          //getting insights of the selected parent
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                if ($scope.structarray[i].advertiserId == $scope.advertiserId){
                                            if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                        if($scope.structarray[i].networkDetails[j].networkName == $scope.networkname)
                                                                { 
                                                                if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                    for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){
                                                                        if($scope.structarray[i].networkDetails[j].parent[k].id == $scope.selectedcampobj.id)
                                                                            {
                                                                                //getting the child ids of selected parent
                                                                                if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                {
                                                                                    for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                    {
                                                                                        (function(i,j,k,l)
                                                                                        {  
                                                                                                //   $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,$scope.structarray[i].networkDetails[j].parent[k].child[l].id,$scope.structarray[i].networkDetails[j].userNetworkMapId);
                                                                                                //filter the graph array for only selected campaign's usernetworkmap id
                                                                                               angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                        //    console.log(val);
                                                                                                            $scope.tmp.push(val);
                                                                                                       }
                                                                                               });
                                                                                               angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                       if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                       {
                                                                                                        //   console.log(val);
                                                                                                            $scope.tmp1.push(val);
                                                                                                       }
                                                                                               });
                                                                                       
                                                                
                                                                                        })(i,j,k,l);
                                                                                    }

                                                                                }
                                                                                else
                                                                                {
                                                                                    //selected parent has no child
                                                                                    $scope.nograph=true;
                                                                                }
                                                                            }

                                                             }
                                                            }
                                                                }
                                                }
                                            }
                                        }
                                    }
                                          
                                          
                                        }
                                            
                                    }
                                    else if ($scope.selectedcampobj.type == "child")
                                    {   
                                            //getting insights of the selected child
                                            for (i = 0; i < $scope.structarray.length; i++){
                                                if ($scope.structarray[i].hasOwnProperty('networkDetails')){
                                                    for(j=0; j< $scope.structarray[i].networkDetails.length; j++){
                                                        (function(i,j)
                                                            {  
                                                                    if ($scope.structarray[i].networkDetails[j].hasOwnProperty('parent')){
                                                                        for(k=0;k<$scope.structarray[i].networkDetails[j].parent.length;k++){                                           
                                                                                    if ($scope.structarray[i].networkDetails[j].parent[k].hasOwnProperty('child'))
                                                                                    {
                                                                                        for(l=0;l<$scope.structarray[i].networkDetails[j].parent[k].child.length;l++)
                                                                                        {
                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == $scope.selectedcampobj.id)
                                                                                            {
                                                                                                 //filter the graph array for only selected campaign's usernetworkmap id
                                                                                                    angular.forEach($scope.campgrapharray, function (val, key) {
                                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                            {
                                                                                                                 $scope.tmp.push(val);
                                                                                                            }
                                                                                                    });
                                                                                                    angular.forEach($scope.twcampgrapharray, function (val, key) {
                                                                                                            if($scope.structarray[i].networkDetails[j].parent[k].child[l].id == val.childid)
                                                                                                            {
                                                                                                                 $scope.tmp1.push(val);
                                                                                                            }
                                                                                                    });
                                                                                            }
                                                                                        }
                                                   
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        //selected parent has no child
                                                                                        $scope.nograph=true;
                                                                                    }
                                                                        }
                                                                    }
                                                            })(i,j);
                                                    }
                                                }
                                        }
                                     
                                    }
                                //    console.log($scope.tmp);
                                //    console.log($scope.tmp1);
                                        if($scope.tmp.length > 0 || $scope.tmp1.length> 0)
                                        {
                                            $scope.campgrapharray1 = angular.copy($scope.tmp);
                                            $scope.twcampgrapharray1 = angular.copy($scope.tmp1);
                                            $scope.nograph = false;
                                            $scope.plotgraph();
                                        }
                                        else
                                        {
                                            $scope.nograph = true;
                                        }
                                   
                                }
                            }
            
             
            
        };
        
        //sample data creation with zero values
        $scope.sampledatacreation = function()
        {
            $scope.plotarray = [];
            //initialing zero to selected daily-wise metric value
                    if ($scope.breakdown == "DAILY")
                    {
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                            for (var k = 0; k < $scope.displaydate.length; k++)
                            {
//                                for (var j = 0; j < $scope.date.length; j++)
//                                {
////                                console.log($scope.date[j]);
//                                    if ($scope.breakpoints[k] == $scope.date[j])
//                                    {
                                        var obj =
                                                {
                                                    "date": $scope.displaydate[k],
                                                    "metric": $scope.metricselect[i],
                                                    "value": 0
                                                }
                                        $scope.plotarray.push(obj);
//                                        break;
//                                    }
//                                    else
////                                    {
//                                        var obj =
//                                                {
//                                                    "date": $scope.breakpoints[k],
//                                                    "metric": $scope.metricselect[i],
//                                                    "value": 0
//                                                }
//                                        $scope.plotarray.push(obj);
//                                        break;
//                                    }
                                }
                            }
//                        }
                      //  console.log($scope.date);
                        $scope.metricdatacreation($scope.date);

                    }
                     //initialing zero to selected week-wise metric value
                    else if ($scope.breakdown == "WEEKLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.weeknum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for weekly
                         $scope.metricdatacreation($scope.weeknum);
                    }
                    
                    //initialing zero to selected month-wise metric value
                     else if ($scope.breakdown == "MONTHLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.monthnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for monthly
                       $scope.metricdatacreation($scope.monthnum);
                       
                    }
                    
                    //initialing zero to selected quarterly-wise metric value
                     else if ($scope.breakdown == "QUARTERLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.quaternum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for quarterly
                        $scope.metricdatacreation($scope.quaternum);
                        
                    }
                    //initialing zero to selected halfyearly-wise metric value
                     else if ($scope.breakdown == "HALFYEARLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.halfnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for halfyearly
                        $scope.metricdatacreation($scope.halfnum);
                        
                    }
                    //initialing zero to selected yearly-wise metric value
                     else if ($scope.breakdown == "YEARLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.yearnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for yearly
                        $scope.metricdatacreation($scope.yearnum);
                    }
            
        }


        //get from date , to date
        $scope.selectstartdate = function (val)
        {
            //var iden1=0;
           //  console.log($scope.fromDate);
            $scope.enteredfromDate = val;
            //var _utc = new Date(val.getUTCFullYear(), val.getUTCMonth(), val.getUTCDate(), val.getUTCHours(), val.getUTCMinutes(), val.getUTCSeconds());
            $scope.startdat = $filter('date')(val, 'yyyy-MM-dd');
            if($scope.enteredtoDate!=null && $scope.enteredfromDate!=null && $scope.from != "" && $scope.to!="")
            {    
                if(new Date($scope.from) <= new Date($scope.to))
                {
                    datedifference = 0;
                    $scope.breakdown = "";
                    var date = new Date();
                    var hour = date.getHours(); var hour1 = hour > 10 ? '0'+hour : hour;
                    var min = date.getMinutes(); var min1 = min > 10 ? '0'+min : min;
                    var sec = date.getSeconds();  var sec1 = sec > 10 ? '0'+sec : sec;
                    var fromDateTime = $scope.startdat +" "+hour1 +":"+min1+":"+sec1;
                    var toDateTime = $scope.enddat +" "+hour1 +":"+min1+":"+sec1; 
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.currentDate = new Date($scope.UTCFromDate);
                    $scope.toDateNumber = new Date($scope.UTCToDate).getDate();
                    $scope.toMonth = new Date($scope.UTCToDate).getMonth() + 1;
                    $scope.toYear = new Date().getFullYear();
                    $scope.fromDateNumber = new Date($scope.UTCFromDate).getDate();
                    $scope.fromMonth = new Date($scope.UTCFromDate).getMonth() + 1;
                    $scope.fromYear = new Date($scope.UTCFromDate).getFullYear();
                    $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
                    if($scope.monthDiff < 0)
                    {
                        $scope.monthDiff = $scope.monthDiff + 12;
                    }
                    $scope.yearDiff = $scope.toYear - $scope.fromYear;
                    while ($scope.currentDate <= new Date($scope.enddat)){
                        $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                        datedifference = datedifference+1;
                    }
                  //  console.log(datedifference);
                  //  console.log($scope.monthDiff);
                    if(datedifference >=1 && datedifference <=7)
                    {
                        $scope.breakdown = "DAILY";
                    }
                    else if($scope.yearDiff>=1){
                        $scope.breakdown = "YEARLY";
                    }
                    else if(datedifference>=8 && datedifference<=31 && $scope.monthDiff <= 1){
                        $scope.breakdown = "WEEKLY";
                    }
                    else if(datedifference>=8 && datedifference<=31 && $scope.monthDiff > 1){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if($scope.monthDiff >= 1 && $scope.monthDiff <=3){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if ($scope.monthDiff>3 && $scope.monthDiff <= 6){
                        $scope.breakdown = "QUARTERLY";
                    }
                    else if ($scope.monthDiff > 6  && $scope.monthDiff <=12){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff <2){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff>=2){
                        $scope.breakdown = "YEARLY";
                    }
                    $scope.startdat=$scope.UTCFromDate;
                    $scope.enddat=$scope.UTCToDate;
                    $scope.diffDays=datedifference;
                    
                    
                    
               
                        $scope.allaccountinsights($scope.startdat , $scope.enddat , $scope.breakdown);
                    
                 
                        $scope.allcampaigninsights($scope.startdat , $scope.enddat , $scope.breakdown);
                   
//                   
                } else
                {
                    //invalid date range 
                    $scope.nograph= true;
                    $scope.from="";
                    $scope.to="";
                }  
    }
            
   }

        $scope.selectenddate = function (val)
        {
         //   var iden1=0;
            $scope.enteredtoDate = val;
            $scope.enddat = $filter('date')(val, 'yyyy-MM-dd');
            if($scope.enteredtoDate!=null && $scope.enteredfromDate!=null && $scope.from != "" && $scope.to!="")
            {    
                if(new Date($scope.from) <= new Date($scope.to))
                {
                    datedifference = 0;
                    $scope.breakdown = "";
                    var date = new Date();
                    var hour = date.getHours(); var hour1 = hour > 10 ? '0'+hour : hour;
                    var min = date.getMinutes(); var min1 = min > 10 ? '0'+min : min;
                    var sec = date.getSeconds();  var sec1 = sec > 10 ? '0'+sec : sec;
                    var fromDateTime = $scope.startdat +" "+hour1 +":"+min1+":"+sec1;
                    var toDateTime = $scope.enddat +" "+hour1 +":"+min1+":"+sec1; 
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.currentDate = new Date($scope.UTCFromDate);
                    $scope.toDateNumber = new Date($scope.UTCToDate).getDate();
                    $scope.toMonth = new Date($scope.UTCToDate).getMonth() + 1;
                    $scope.toYear = new Date().getFullYear();
                    $scope.fromDateNumber = new Date($scope.UTCFromDate).getDate();
                    $scope.fromMonth = new Date($scope.UTCFromDate).getMonth() + 1;
                    $scope.fromYear = new Date($scope.UTCFromDate).getFullYear();
                    $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
                    if($scope.monthDiff < 0)
                    {
                        $scope.monthDiff = $scope.monthDiff + 12;
                    }
                    $scope.yearDiff = $scope.toYear - $scope.fromYear;
                    while ($scope.currentDate <= new Date($scope.enddat)){
                        $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                        datedifference = datedifference+1;
                    }
                  //  console.log(datedifference);
                  //  console.log($scope.monthDiff);
                    if(datedifference >=1 && datedifference <=7)
                    {
                        $scope.breakdown = "DAILY";
                    }
                    else if($scope.yearDiff>=1){
                        $scope.breakdown = "YEARLY";
                    }
                    else if(datedifference>=8 && datedifference<=31 && $scope.monthDiff <= 1){
                        $scope.breakdown = "WEEKLY";
                    }
                    else if(datedifference>=8 && datedifference<=31 && $scope.monthDiff > 1){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if($scope.monthDiff >= 1 && $scope.monthDiff <=3){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if ($scope.monthDiff>3 && $scope.monthDiff <= 6){
                        $scope.breakdown = "QUARTERLY";
                    }
                    else if ($scope.monthDiff > 6  && $scope.monthDiff <=12){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff <2){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff>=2){
                        $scope.breakdown = "YEARLY";
                    }
                    $scope.startdat=$scope.UTCFromDate;
                    $scope.enddat=$scope.UTCToDate;
                    $scope.diffDays=datedifference;
                    
                    
                    
               
                        $scope.allaccountinsights($scope.startdat , $scope.enddat , $scope.breakdown);
                    
                 
                        $scope.allcampaigninsights($scope.startdat , $scope.enddat , $scope.breakdown);
                   
//                   
                } else
                {
                    //invalid date range 
                    $scope.nograph= true;
                    $scope.from="";
                    $scope.to="";
                }  
    } 
 }     

        $scope.getdatesfromweeknum = function(week,yr)
        {
            var tm = 1000 * 60 * 60 * 24;
            var d = 0;
            do {
                var start = new Date(yr, 0, 1 + d);
                d++
            } while (start.getDay() != 1)

            var sta_dt = new Date(start.getTime() + tm * (week - 1) * 7);
            var end_dt = new Date(sta_dt.getTime() + tm * 6);
            var  sta= $filter('date')(sta_dt, 'yyyy-MM-dd');
            var  end = $filter('date')(end_dt, 'yyyy-MM-dd');
            
            var obj = {
                "weeknum":week,
                 "startdate":sta,
                 "enddate":end
            };
            
            $scope.weekvalue.push(obj);
        }
        
        function localDateTimetoUTCDateTime(date){
            var d = new Date(date);
            var utcDate = d.toUTCString();
            return new Date(utcDate).toISOString().slice(0,10);
        }

        $scope.checkCurrencyCode = function(_code) {
			angular.forEach($scope.currencyList, function(value, key) {				
				if($scope.currencyList[key].currency == _code){
					$scope.currencyValue = $scope.currencyList[key].currencyCode;					
					return $scope.currencyList[key].currencyCode;
				}
			});
			$scope.currencyCode = $scope.currencyValue;			
                        $scope.tempCurrencyCode =$scope.currencyValue;
                        //console.log($scope.currencyCode);
         }
   
        $scope.plotgraph = function ()
        {
            if(!$scope.selectedcampbool)
            {   
                        angular.forEach($scope.plotarray, function (v, k1)
                        {
                            angular.forEach($scope.grapharray1, function (value, key) {
                                    if (value.date == v.date)
                                    {    // account insights dates that have metric object    
                                            angular.forEach(value.metricobj, function (val, k) {
                                            if (val.name == v.metric )
                                            {
                                                //checking whether it is in string or not
                                                if(typeof(val.value)=='string')
                                                {
                                                    var tmp=parseFloat(val.value);
                                                     v.value += Math.round(tmp);
                                                }
                                                else
                                                {    
                                                    v.value += Math.round(val.value);
                                                }
                                            }
                                        });
                                    }
                            });
                        });
                        angular.forEach($scope.plotarray, function (v1, k1)
                        {
                            angular.forEach($scope.twgrapharray1, function (value1, key) {
                                    if (value1.date == v1.date)
                                    {    // account insights dates that have metric object    
                                            angular.forEach(value1.metricobj, function (val1, k) {
                                            if (val1.name == v1.metric )
                                            {
                                                
                                                //checking whether it is in string or not
                                                if(typeof(val1.value)=='string')
                                                {
                                                    var tmp=parseFloat(val1.value);
                                                     v1.value += Math.round(tmp);
                                                }
                                                else
                                                {    
                                                    v1.value += Math.round(val1.value);
                                                }
                                                console.log(v1.value);
                                            }
                                        });
                                    }
                            });
                        });
            }
            else 
            {
               // console.log($scope.campgrapharray1);
                console.log($scope.twcampgrapharray1);
                angular.forEach($scope.plotarray, function (v, k1)
                        {
                            angular.forEach($scope.campgrapharray1, function (value, key) {
                                    if (value.date == v.date)
                                    {    // account insights dates that have metric object    
                                            angular.forEach(value.metricobj, function (val, k) {
                                            if (val.name == v.metric )
                                            {
                                                //checking whether it is in string or not
                                                if(typeof(val.value)=='string')
                                                {
                                                    var tmp=parseFloat(val.value);
                                                     v.value += Math.round(tmp);
                                                }
                                                else
                                                {    
                                                    v.value += Math.round(val.value);
                                                }
                                                
                                            }
                                        });
                                    }
                            });
                        });
                        console.log($scope.twcampgrapharray1);
                        console.log($scope.plotarray);
//                        angular.forEach($scope.plotarray, function (v1, k1)
//                        {
//                            angular.forEach($scope.twcampgrapharray1, function (value1, key) {
//                                    if (value1.date == v1.date)
//                                    {    // account insights dates that have metric object    
//                                            angular.forEach(value1.metricobj, function (val1, k) {
//                                            if (val1.name == v1.metric )
//                                            {
//                                                if(val1.value > 0)
//                                                {
//                                                     console.log(value1);
//                                                }
//                                               
//                                                //checking whether it is in string or not
//                                                if(typeof(val1.value)=='string')
//                                                {
//                                                    var tmp=parseFloat(val1.value);
//                                                     v1.value += Math.round(tmp);
//                                                }
//                                                else
//                                                {    
//                                                    v1.value += Math.round(val1.value);
//                                                }
//                                                
//                                            }
//                                        });
//                                    }
//                            });
//                        });
                        
                        for(var i=0;i<$scope.plotarray.length;i++)
                        {
                             for(var j=0;j<$scope.twcampgrapharray1.length;j++)
                             {
                                 if($scope.plotarray[i].date == $scope.twcampgrapharray1[j].date)
                                     {    // account insights dates that have metric object    
//                                            angular.forEach(value1.metricobj, function (val1, k) {
                                        for(k=0;k<$scope.twcampgrapharray1[j].metricobj.length;k++)
                                        {
                                            if ($scope.twcampgrapharray1[j].metricobj[k].name == $scope.plotarray[i].metric )
                                            {
                                                if($scope.twcampgrapharray1[j].metricobj[k].value > 0)
                                                {
                                                    console.log(i,j,k);
                                                    console.log($scope.twcampgrapharray1[j]);
                                                }
                                               
                                                //checking whether it is in string or not
                                                if(typeof($scope.twcampgrapharray1[j].metricobj[k].value)=='string')
                                                {
                                                    var tmp=parseFloat($scope.twcampgrapharray1[j].metricobj[k].value);
                                                     $scope.plotarray[i].value += Math.round(tmp);
                                                }
                                                else
                                                {    
                                                    $scope.plotarray[i].value += Math.round($scope.twcampgrapharray1[j].metricobj[k].value);
                                                }
                                                
                                            }
                                        }
                                    }
                             }
                        }
            }
            
            
            // console.log(JSON.stringify($scope.plotarray, null, 2));
            // console.log($scope.diffDays);
             $scope.samedate=false;
             //if both dates are same , then duplicates the same date object
             if($scope.diffDays==1)
             {
                    $scope.samedate=true;
                    var plotarray2 = [];
                    plotarray2 = $scope.plotarray;
                    angular.forEach(plotarray2, function (v, k1)
                    {
                        $scope.plotarray.push(v);
                    });
                //    console.log(plotarray2);
             }
             $scope.zerocount = 0
             for(var i=0;i<$scope.plotarray.length;i++)
             {
                 if($scope.plotarray[i].value==0)
                 {
                     $scope.zerocount++;
                 }
//                 console.log($scope.zerocount);
//                 console.log($scope.plotarray.length);
                if($scope.plotarray.length == $scope.zerocount)
                {
                    $scope.nograph=true;
//                    console.log($scope.nograph);
                }
             }
             
             $scope.graphinit();
        }

        $scope.graphinit = function ()
        {
//          console.log($scope.nograph);
            $scope.values = [];
            angular.forEach($scope.plotarray, function (v, k1)
            {
                $scope.rr ={"month": v.date, "metric": v.metric, "amount": v.value};
                $scope.values.push($scope.rr);

            });
            $scope.colorvalues = [];
            var color = ["#03A9F4", "#FFC107", "#b388ff", "#80cbc4"];
           // console.log($scope.metricselect);

            var tmp = $scope.metricselect[0];
            var tmp1 = $scope.metricselect[1];
            var tmp2 = $scope.metricselect[2];
            var tmp3 = $scope.metricselect[3];

            var color1 = color[0];
            var color2 = color[1];
            var color3 = color[2];
            var color4 = color[3];
            $scope.color = {};
            $scope.color[tmp] = color1;
            $scope.color[tmp1] = color2;
            $scope.color[tmp2] = color3;
            $scope.color[tmp3] = color4;
//            [tmp]: color1,
//                    [tmp1]: color2,
//                    [tmp2]: color3,
//                    [tmp3]: color4,
//        };
       // console.log($scope.color);
//            angular.forEach($scope.color, function (v, k1)
//            {
//                console.log(v.metric);
//            });
        //console.log($scope.color);
       // console.log($scope.values);
       
        plotValues($scope.values, $scope.color);
       
        };
        
        
        
        function plotValues(val, colourobj) {
            // Sample Data for this line chart demo.
            $("#sampleChart").empty();
           
            var sampleData = val;
            // Defining options for rendering line chart.
            var options = {
                id: "1",
                container: {id: "#sampleChart", title: " ", showDataLabels: 'no', titlePos: 24, contextBrush: "no", width:1110, height:270},
                markerRadius: 3,
                bindings: {x: "month", y: "amount", category: "metric", marker: ''},
                labels: {x: " ", y: " "},
                margin: {top: 30, right: 50, bottom: 30, left: 80},
                scaling: {x: 4, y: 1},
                //scaleFormat: {x: "%a - %e", y: " "},
                ticks: {
                    x: 7,
                    y: 7
                },
                axisRange:
                    {
                  y:
                  {
                      min: 0
                  }
                },
                tickerAngle: {x: 0},
                colors: colourobj,
                
                tooltip: {
                    width: 250,
                    bindings: [{label: $scope.currencyCode, bindWith: "amount"}]
                }
            };

            var bar_graph = cviz.widget.LineChart.Runner(options).graph();


             $rootScope.progressLoader = "none";
            bar_graph.render(sampleData);
            
            for (var i = 0; ; i++)
                {
                   var a = document.getElementById("sampleChart").children[0];
                    
                       // if($(a).hasClass("tool-tip"))
                      //  {   
//                            if (document.getElementById("sampleChart").children[1].children[0].children[3].children[i].hasChildNodes())
//                            document.getElementById("sampleChart").children[1].children[0].children[3].children[i].innerHTML = "<line x1='-200' y1='0' x2='350%' y2='0'></line>";
//                            else
//                            {
//                                 break;
//                            }
//                            document.getElementById("sampleChart").children[1].children[0].children[2].setAttribute("transform","translate(0,220)");
                       // }
                      //  else
                     //   {
                            if (document.getElementById("sampleChart").children[0].children[0].children[4].children[i].hasChildNodes())
                            {    
                                document.getElementById("sampleChart").children[0].children[0].children[4].children[i].innerHTML = "<line x1='-200' y1='0' x2='350%' y2='0'></line>";
                            }else
                            {
                                 break;
                            }
                            
                             document.getElementById("sampleChart").children[0].children[0].children[3].setAttribute("transform","translate(0,225)");
                       // }
                    
//                    document.getElementById("sampleChart").children[1].children[1].children[1]
//                    document.getElementById("sampleChart").children[1].children[1].childNodes[1].style.opacity
                }
               
               //document.getElementById("sampleChart").children[1].children[0].children[2].setAttribute("transform","translate(0,220)");
               
//               for (var i = 0; ; i++)
//                {
//                    if (document.getElementById("sampleChart").children[0].children[0].children[4].children[i].hasChildNodes())
//                        document.getElementById("sampleChart").children[0].children[0].children[4].children[1].innerHTML = "<line x1='-200' y1='0' x2='350%' y2='0'></line>";
//                    else
//                    {
//                    break;
//                    }
////                    document.getElementById("sampleChart").children[1].children[1].children[1]
////                    document.getElementById("sampleChart").children[1].children[1].childNodes[1].style.opacity
//                }
//               
//               document.getElementById("sampleChart").children[0].children[0].children[3].setAttribute("transform","translate(0,220)");
        };
      
       
                //resetting the pop up
          $scope.resetPopup = function() {
                       $scope.campSumErrors = "none";
                       $scope.editAdsetErrorMsg="none";
                        angular.element("#errorScroll").scrollTop(0);
                      
        };
     
    
    
           $scope.resetPopup1 = function() {
                       $scope.campSumErrors = "none";$scope.editAdsetErrorMsg="none";
                        angular.element("#errorScroll").scrollTop(0);
                        errorcount=false;
                        errorCompletionStatus=false;
                        angular.element($('body').css("overflow-y", "scroll"));
                         var errorHeader = [];    
                        var errorString = [];
                        var errornetwork =[];
        };
         
        $scope.errorhandeler =function()
        {
            var p=0;
            $rootScope.progressLoader = "none";
          //  if(errorcount)
            {
                
                if(errorCompletionStatus && (errorHeader.length)>0)
                {
                    
                   
                $scope.campSumErrors = 'block';
              angular.element($('body').css("overflow-y", "hidden"));
              angular.element("#campSumErrors").empty();	
               angular.element("#errorScroll").css("height","100px");
               angular.element("#errorScroll").css("overflow-y","none");
              angular.element("#lessErrors").css("display","none");	
	      angular.element("#moreErrors").css("display","flex");
            for(p;p<errorHeader.length;p++)
                {
                    var image;
                 
                   
                 if(errornetwork[p]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                            
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
                     
                    );
       
                    }else
                    if(errornetwork[p]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                               "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
        
                    );
                }
                }
               
                }
            }
          
           
              
            };
       //"<img style='width: 30%;height: 30%;src='images/accountDashboard/facebook.svg'>"+
       //  $scope.campSumErrors='block';
                $scope.viewMoreErrors = function()
        {  var pp=0;
            angular.element("#campSumErrors").empty();	
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
             for(pp;pp<errorHeader.length;pp++)
                {
                    var image;
                    var a=70,b=20;
                  //  console.log(errorHeader[pp].indexOf('<br>'));
                  //  console.log(errorHeader[pp]);
                    if( errorHeader[pp].indexOf("childcampaign") > -1)
                        a=90;b=30
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: "+a+"px; border-right: 1px solid #c5c5c5;float: left;padding-top: "+b+"px;'>"+								
                                                                
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp]
                                 +"</div>" +"</div>"+ "</div>" 

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: "+a+"px; border-right: 1px solid #c5c5c5;float: left;padding-top: "+b+"px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp] +
                               								
                                "</div>" +    "</div>" + "</div>" 
        
                    );
                }
                }  
    
        };
    
        $scope.viewLessErrors = function()
        {
            var pp;
         angular.element("#campSumErrors").empty();			
          angular.element("#errorScroll").css("height","100px");
          angular.element("#errorScroll").css("overflow-y","hidden");
          angular.element("#lessErrors").css("display","none");	
	  angular.element("#moreErrors").css("display","flex");
          angular.element($('body').css("overflow-y", "none"));
          angular.element("#errorScroll").scrollTop(0);
            
          
           
            
            
            for(pp=0;pp<errorHeader.length;pp++)
                {
                    var image;
                 console.log(errornetwork[pp]);
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                             
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[pp] +                               						
                                "</div>" +                              
                                "</div>"

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;padding-top: 8px;'>" +
                                errorString[pp] +                               						
                                "</div>" +                              
                                "</div>"
        
                    );
                }
                } 
        };


    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    
    $scope.resetPopup1 = function() {
                       $scope.campSumErrors = "none";$scope.editAdsetErrorMsg="none";
                    angular.element("#errorScroll").scrollTop(0);
                       errorcount=false;
                        angular.element($('body').css("overflow-y", "scroll"));
                        
        var errorHeader = [];
     //   $scope.errorpopup2Heading="We're sorry something went wrong!";
        var errorString = [];
        var errornetwork =[];
        };
         var p=0;
        $scope.errorhandeler =function()
        {
            $rootScope.progressLoader = "none";
            if(errorcount)
            {
                
                if(errorCompletionStatus)
                {
                    angular.element($('body').css("overflow-y", "hidden"));
                $scope.campSumErrors = 'block';
            
             angular.element("#errorScroll").css("height","100px");
                angular.element("#errorScroll").css("overflow-y","hidden");
                angular.element("#moreErrors").css("display","flex");
            } for(p;p<errorHeader.length;p++)
                {
                    var image;
                 
                   
                 if(errornetwork[p]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left; padding-left: 10px;'>" +
                                errorString[p] +
                                "</div></div>" +"<div class='firsthalferror' ><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "

                    );
       
                    }else
                    if(errornetwork[p]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[p] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/twitter.png' ></img></div>"+
                            "</div></div><br> <br>"
        
                    );
                }else
                    if(errornetwork[p]==="parentcampaign")
                { angular.element("#campSumErrors").append(
                             "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror' >"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[p] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "
        
                    );
                }
                }
               
        
            }
          
           
              
            };
    //"<img style='width: 30%;height: 30%;src='images/accountDashboard/facebook.svg'>"+
     //  $scope.campSumErrors='block';
           $scope.viewMoreErrors = function()
        {  var pp=0;
            angular.element("#campSumErrors").empty();	
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
             for(pp;pp<p;pp++)
                {
                    var image;
                 
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +"<div style='width:100%; font-weight:bold; color:#484848;font-size:13px;text-align:left; padding-left: 10px;'>" + 
                                errorHeader[pp] +     "</div>" +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left; padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror' ><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +"<div style='width:100%; font-weight:bold; color:#484848;font-size:13px;text-align:left; padding-left: 10px;'>" + 
                                errorHeader[pp] +     "</div>" +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/twitter.png' ></img></div>"+
                            "</div></div><br> <br>"
        
                    );
                }else
                    if(errornetwork[pp]==="parentcampaign")
                { angular.element("#campSumErrors").append(
                             "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror' >"
                                +"<div style='width:100%; font-weight:bold;color:#484848;font-size:13px; text-align:left; padding-left: 10px;'>" + 
                                errorHeader[pp] +     "</div>" +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "
        
                    );
                }
                }  
    
        };
    
               $scope.viewLessErrors = function()
        {
            var pp;
           angular.element("#campSumErrors").empty();			
            angular.element("#errorScroll").css("height","100px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#lessErrors").css("display","none");	
			angular.element("#moreErrors").css("display","flex");
             for(pp=0;pp<p;pp++)
                {
                    var image;
                 
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left; padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror' ><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "

                    );
       
                    }else
                    if(errornetwork[pp]==="Twitter")
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/twitter.png' ></img></div>"+
                            "</div></div><br> <br>"
        
                    );
                }else
                    if(errornetwork[pp]==="parentcampaign")
                { angular.element("#campSumErrors").append(
                             "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror' >"
                               +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/facebook.png' ></img></div>"+
                            "</div></div><br> "
        
                    );
                }
                } 
        };
    */      
 }]);