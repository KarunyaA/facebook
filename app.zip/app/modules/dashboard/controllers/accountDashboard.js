dashboard.controller("AccountDashboardController", ['$rootScope', '$scope','$http', '$state', '$location', 'dashboardService', 'Flash', '$q' ,'$window', '$sce', 'appSettings','$timeout', 'apiService','$filter',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout,apiService,$filter) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;
        $scope.fbNetwork = appSettings.fbNetwork;
        $scope.twNetwork = appSettings.twNetwork;
        $rootScope.progressLoader = "block";
        $scope.rightNavCtrlbtn = 0;
        $scope.ctrlLimt = 0;
        $scope.totalAdvertiser = 0;
        $scope.isLeftBtnEnable = false;
        $scope.isrightBtnEnable = true;
        $scope.isEditPlanDetails = false;
        $scope.paypalBtn = false;
        $scope.isClosePlanDetails = false;
        $scope.isPlanExpNotification = false;
        $scope.prevPlanDetails = "none";
        $scope.networkmaparray = [];
        $scope.bool = [];
        $scope.wholeParentArray = [];
        $scope.wholeArray = [];
        $scope.wholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkforadv = false;
        //$scope.adCampaignsLength = [];
		$scope.isEditPlanDatelabel = true;
        $scope.currencyList ={};
        $scope.iseditMode = [];
		$scope.advertiserData = [];
		$scope.planDetails={};
		$scope.paypalLabel="Renew & Pay";
		var details={};
		$scope.sDate = "";
		$scope.eDate = "";
		$scope.standardPlan = "";
		$scope.planChange = false;
        $timeout(function () {
            $scope.init();
        }, 1500);
		$scope.addadvertiserfunc = function(){
			$state.go('app.addadvertiser');
		}   

         $scope.loadCurrencyCode = function(){
			$http.get("localData/currencyData.json").success(function (data){
				$scope.currencyList = data.currencyList;
				//console.log($scope.currencyList);
			});
		}  
        $scope.searchAdv = function(item){
            if ($scope.searchAdvertiser == undefined) {
                $scope.counted = 0;
                return true;
            }else{
                if (item.advertiserName.toLowerCase()
                        .indexOf($scope.searchAdvertiser.toLowerCase()) != -1) {
                    $scope.networkmaparray = $scope.counted;
                    return true;
                }
            }
            return false;
        }
        
        $scope.closePopup = function(){
           $scope.editAdsetErrorMsg = 'none';
        }
        
        $scope.searchByAdvertiser = function(){
            $scope.ctrlLimt = 0;
            $scope.counted = $filter("filter")($scope.tempnetworkmapArr, $scope.searchAdvertiser);
            if ($scope.searchAdvertiser === undefined || $scope.searchAdvertiser == '' || $scope.searchAdvertiser == null) {
                $scope.networkmaparray = $scope.tempnetworkmapArr;
            } else {
                $scope.networkmaparray = $scope.counted;
            }
        }
        
        $scope.init = function(){
            $rootScope.progressLoader = "block";
			 angular.element($('body').css("overflow-y", "scroll"))
			$scope.popupTitle = "Your Payment was successful!";
			$scope.popupMessage = "Transaction ID for this Payment is "+$scope.paymentID+"."+"Confirmation email sent to your registered email id";;
            $scope.advertiserDetails = {};
            $scope.adverDetails =[];
			$scope.planDetails.currentPlan = "SMB";
			$scope.planDesc = "5";
			$scope.planId = "110001";
			$scope.totalAmount = '0.01';
			$scope.currencyCode="USD";
			details = {
				
			}
			$scope.editPlanDetails();
			
            $http({
                method: 'GET',
                url: apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                if (response.data.appStatus == '0'){// success
                    //$rootScope.progressLoader = "none";
                    $scope.accountName = response.data.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                    $scope.downloadAccountLogo($scope.accountLogoUrl); 
                    $scope.getAdvertiserDetails();
                    $scope.fetchCurentPlanDetails();
                } else {// failed
                    console.log("failed");
                }
            });
            $scope.loadCurrencyCode();
			
			//---------------------------------------------------------------------------------------------
			// Render the PayPal button
			paypal.Button.render({
				// Set your environment
				env: 'production', // sandbox | production
				// PayPal Client IDs - replace with your own
				// Create a PayPal app: https://developer.paypal.com/developer/applications/create
				 style: {
					label: 'checkout', // checkout || credit
					size:  'small',    // tiny | small | medium
					shape: 'rect',     // pill | rect
					color: 'silver'      // gold | blue | silver
					
				},
				client: {
					sandbox:    'AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PiV8e1GWU6liB2CUXlkA59kJXE7M6R',
					production: 'Aco85QiB9jk8Q3GdsidqKVCXuPAAVbnqm0agscHCL2-K2Lu2L6MxDU2AwTZa-ALMn_N0z-s2MXKJBxqJ'
				},
				// Wait for the PayPal button to be clicked
				payment: function() {
					// Make a client-side call to the REST api to create the payment
					return paypal.rest.payment.create(this.props.env, this.props.client, {
						transactions: [
							{
								"amount": { 
									"total": $scope.totalAmount, 
									"currency": $scope.currencyCode,
									"details": {
										"subtotal": $scope.totalAmount
										
									}
								},
								"item_list": {
									"items": [
									  {
									  "name": $scope.planDetails.currentPlan,
									  "description": "Brown color hat",
									  "quantity": "1",
									  "price": $scope.totalAmount,
									  "sku": $scope.planId,
									  "currency": $scope.currencyCode
								}]}
      
							}
						]
					});
				},
				// Wait for the payment to be authorized by the customer
				onAuthorize: function(data, actions) {
					// Execute the payment
					$scope.hidePayPalPopup();
					//console.log(data);
					//console.log(actions);
					return actions.payment.execute().then(function(resp) {
						//console.log(resp);
						$scope.paymentID = data.paymentID;
						$scope.showPopup(data, actions);					
						//$scope.paypalSuccessPopup = "block";

					   // document.querySelector('#paypal-button-container').innerText = 'Payment Complete!';
					});
				}

			}, '#paypal-button-container');
		
			
			//---------------------------------------------------------------------------------------------
			
			
		/*$scope.load = function () {
        alert("load event detected!");
    }*/
	

			
			
			
					
            
        }        

		$scope.gotoPayPal = function(){
			console.log($scope.planChange+" >>$scope.planChange$scope.planChange$scope.planChange");
			if($scope.planChange != true) {
					$scope.popupTitle = "Confirm Plan Details";

				$timeout(function () {
				$scope.popupMessage = "You are about to upgrade your plan from SMB to Enterprise. To confirm, please click on PayPal button and proceed with the payment.";
					var modalApproveReq = $(".paypal_modalApprove");// Get the modal Approve req
					modalApproveReq.show();
				}, 0);
			} else {
				$scope.downGradePlan();
			}
			
		}
		$scope.downGradePlan = function(){
			
			$scope.popupTitle = "Confirm Plan Details";

				$timeout(function () {
				$scope.popupMessage = "You are trying to downgrade the plan from Enterprise to SMB."
				$scope.popupMessage1 = "Please note that you have exceed the maximum number of Advertisers that is allowed in SMB plan."
				$scope.popupMessage2 = "Please note: In order to continue to downgrade you have to delete some advertisers."
					var modalApproveReq = $(".paypalDowngrade_modalApprove");// Get the modal Approve req
					modalApproveReq.show();
				}, 0);
		}
                $scope.showPopup = function(_data, actions){
				
				$scope.popupTitle = "Your Payment was successful!";

				$timeout(function () {
				$scope.popupMessage = "Transaction ID for this Payment is "+$scope.paymentID+"."+" Confirmation email sent to your registered email id";
					var modalApproveReq = $(".paypal_success");// Get the modal Approve req
					modalApproveReq.show();
				}, 1500);
		
				
			}
			$scope.hidePayPalPopup = function(){
				var modalApproveReq = $(".paypal_modalApprove");// Get the modal Approve req
				modalApproveReq.hide();
			}
			$scope.hidePayPalPopup1 = function(){
				$scope.planChange = false;
				var modalApproveReq = $(".paypalDowngrade_modalApprove");// Get the modal Approve req
				modalApproveReq.hide();
			}
			$scope.resetSelection = function(){
				console.log($scope.planId);
				  var parameters = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken"),
                    "planId":$scope.planId,
					"planName":$scope.planDetails.currentPlan,
					"transactionId":$scope.paymentID,
					"amount":$scope.totalAmount,
					"currencyCode":$scope.currencyCode,
					"paymentStatus":"Completed"
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/paypalintegration',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(resp) {
                    //console.log(resp);
					if(resp.data.appStatus =='0'){
						$scope.createPlanMapping(resp.data.paymentId);
						/* $scope.popupTitle = "Your Payment saved successful!";

						$timeout(function () {
							$scope.popupMessage = "Payment ID for this Payment is "+resp.data.paymentId;
							var modalApproveReq = $(".save_modalApprove");// Get the modal Approve req
							modalApproveReq.show();
						}, 1500); */
					}
                }); 
				var modalApproveReq = $(".paypal_success");// Get the modal Approve req
				modalApproveReq.hide();
			}
			$scope.createPlanMapping = function(paymentId){
				console.log($scope.sDate+" :: "+$scope.eDate);
				$scope.planStartDateval = $scope.sDate;
				$scope.planEndDateval = $scope.eDate;
				  var parameters = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken"),
                    "planId":$scope.planId,
					"paymentId":paymentId,
					"currentPlanFlag":"1",
					"planStartDate":$scope.sDate,
					"planEndDate": $scope.eDate
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/createaccountplanmapping',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(resp) {
                    console.log(resp);
					if(resp.data.appStatus =='0'){
						$scope.popupTitle = "Success!";
						$scope.popupMessage = resp.data.successMessage

					} else {
						$scope.popupTitle = "Failed!";
						$scope.popupMessage = resp.data.errorMessage
					}
				
					$timeout(function () {						
						var modalApproveReq = $(".save_modalApprove");// Get the modal Approve req
						modalApproveReq.show();
					}, 1500);
                }); 
			}
			$scope.hidePopup = function(){
				var modalApproveReq = $(".save_modalApprove");// Get the modal Approve req
				modalApproveReq.hide();
			}
            $scope.downloadAccountLogo = function(accountLogoUrl){
                var apiImageServer = appSettings.apiImageServer;
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "filePaths" : [accountLogoUrl]
                };
                $http({
                    method: 'POST',
                    url: apiImageServer+'/downloadimages',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(resp) {
                     $scope.accountLogo = resp.data.imageContent[$scope.accountLogoUrl];
                });
            }
            $scope.downloadAdvertiserLogo = function(advertiserLogoUrl, loopKey){
                $scope.advertiserLogo = [];
                var apiImageServer = appSettings.apiImageServer;
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "filePaths" : [advertiserLogoUrl]
                };
                $http({
                    method: 'POST',
                    url: apiImageServer+'/downloadimages',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(resp) {
					//console.log(resp);
                    $scope.advertiserLogo[loopKey] = resp.data.imageContent[advertiserLogoUrl];
                });
            }
            
            
            $scope.getAdvertiserDetails = function(){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/advertiserdatafetch?accountId='+$window.localStorage.getItem("accountId"),
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
                    if (response.data.appStatus == '0'){// success
                        $scope.advertiserDetails = response.data.advDataFetchResponse;
						$scope.advertiserData  = response.data.advDataFetchResponse;

                        $scope.allnetworks($scope.advertiserDetails);
                    } else {// failed
                        console.log("failed")
                    }
                });
            }
            
            
            $scope.allnetworks = function (advertiserDetails){
                $http({
                    method: 'GET',
                    url: apiBase + "/user/fetchallnetwork",
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.allnetworksarray = response.data.networkList;
                        $scope.networksforacc(advertiserDetails);
                    } else {
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            //$rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                });
            }

            //FETCHADVERTISERNETWORK
            $scope.networksforacc = function (advertiserDetails){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function (response) {
                    if (response.data.appStatus == '0') {// success
                            $scope.networksarrayforacc = response.data.advertiserNetworkList;
                            $scope.getUserNetworkMapId();
                        
                    } else {
                        $rootScope.progressLoader = "none";
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            //$rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                });
            }
            
            
            
            $scope.checkCurrencyCode = function(_code) {
			//console.log($scope.currencyList);
			angular.forEach($scope.currencyList, function(value, key) {				
				if($scope.currencyList[key].currency == _code){
					//console.log($scope.currencyList[key].currencyCode+" --- "+_code);
					$scope.currencyValue = $scope.currencyList[key].currencyCode;					
					//console.log($scope.currencyValue);
					return $scope.currencyList[key].currencyCode;
					
				}
			});
			
			$scope.currencyCode = $scope.currencyValue;			
		}
 
            
            $scope.getUserNetworkMapId = function (){
            var promises = [];
            angular.forEach($scope.advertiserDetails, function (val, key){
                var networkdetailobj=[];
                var i = 0;
                var obj={
                            "advertiserName":val.advertiserName,
                            "advertiseremail":val.advertiserEmail,
                            "advertiserLogoUrl":val.logoUrl,
                            "advertiserDesc":val.description,
                            "advertiserID":val.advertiserId
                        };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId
                                };
                                if($scope.allnetworksarray[j].networkUrl == appSettings.fbNetwork)
                                {
                                    obj2["Id"] = 0;
                                }
                                else if($scope.allnetworksarray[j].networkUrl == appSettings.twNetwork)
                                {
                                    obj2["Id"] = 1;
                                }
                                else if($scope.allnetworksarray[j].networkUrl == appSettings.adsenseNetwork)
                                {
                                    obj2["Id"] = 2;
                                }
                                else if($scope.allnetworksarray[j].networkUrl == appSettings.cogadNetwork)
                                {
                                    obj2["Id"] = 3;
                                }
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.networkmaparray.push(obj);
            });
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        $scope.countNetMapId = $scope.countNetMapId + 1;
                    }
                }
            }
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            //console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                            //console.log('$$$');
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork){
                                //console.log($scope.networkmaparray[i].networkDetails[j].networkURL);
                                var module = '/readadaccounts?networkMapId=' + $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                                var header = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTp(module,header).then(function(response){    
                                    if(response.appStatus == 0){
                                        angular.forEach(response.fbReadAdAccountResponse, function (value, key){
                                            $scope.networkmaparray[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.fbcurrency = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                            angular.forEach($scope.currencyList, function(value, key) {
                                                if($scope.currencyList[key].currency == $scope.fbcurrency){
                                                    $scope.fbcurrencyCode = $scope.currencyList[key].currencyCode;
                                                }
                                            });
                                        });

                                        //$scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                                    }
                                }));
                            }                            
                            if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork){
                                
                                var module = '/readadaccounts?userNetworkMapId=' + $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                                var header = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTwr(module,header).then(function(response){
                                    if(response.appStatus == 0){
                                        angular.forEach(response.adAccounts, function (value, key){
                                            var JsonObj1 = response.adAccounts[key];
                                            var array = [];          
                                            for(var kk in JsonObj1) {
                                                $scope.networkmaparray[i].networkDetails[j]["adAccountId"]=JsonObj1[kk].twAdAccountId;

                                                var module1 = '/readadfundinginstruments?userNetworkMapId=' + $scope.networkmaparray[i].networkDetails[j].userNetworkMapId;
                                                var header1 = {
                                                    headers: {
                                                        'userId': $window.localStorage.getItem("userId"),
                                                        'accessToken': $window.localStorage.getItem("accessToken")
                                                    }
                                                };
                                                promises.push(apiService.getTwr(module1,header1).then(function(res){
                                                    angular.forEach(res.fundingInstruments, function(v, k){
                                                        var JsonObj = res.fundingInstruments[key];
                                                        var array = [];          
                                                        for(var twi in JsonObj) {
                                                            $scope.twcurrency = JsonObj[twi].twFundingInstrumentDetails.currency;
                                                            //$scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                                                            angular.forEach($scope.currencyList, function(value, key) {
                                                                if($scope.currencyList[key].currency == $scope.twcurrency){
                                                                    $scope.twcurrencyCode = $scope.currencyList[key].currencyCode;
                                                                }
                                                            });

                                                        }
                                                    });


                                                }));
                                            }
                                            
                                        });

            
                                    }
                                }));
                            }

                                    
                        //$scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                        })(i,j);
                        
                    }
                }
            }
            $q.all(promises).finally(
                function(){
                    $scope.readaccountinsights();
                });
            };
        $scope.readaccountinsights = function(){
            var promises = [];
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId') && $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork){   
                                var TotalSpend = 0;
                                var lastSync = "";
                                var module2 = '/readadaccountsinsights?userNetworkMapId=' +  $scope.networkmaparray[i].networkDetails[j].userNetworkMapId + "&adAccountId="+$scope.networkmaparray[i].networkDetails[j].adAccountId;
                                var header2 = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTp(module2,header2).then(function(resp){
                                    if(resp.appStatus == 0){
                                        resp = resp.adAccountInsights;
                                        var array = [];
                                        angular.forEach(resp, function(value, key){
                                            var JSONobject = resp[key];
                                            angular.forEach(JSONobject, function(value, key){
                                                TotalSpend = TotalSpend + JSONobject[key].spend;
                                                lastSync = JSONobject[key].modifiedOn;
                                            });
                                        });
                                        $scope.networkmaparray[i].networkDetails[j]['TotalSpend']=TotalSpend;
                                        $scope.networkmaparray[i].networkDetails[j]['lastSync']=lastSync;
                                    }
                                }));
                            }                            
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId') && $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork){   
                                var TotalSpend = 0;
                                var lastSync = "";
                                var module2 = '/readadaccountsinsights?userNetworkMapId=' +  $scope.networkmaparray[i].networkDetails[j].userNetworkMapId + "&adAccountId="+$scope.networkmaparray[i].networkDetails[j].adAccountId;
                                var header2 = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTwr(module2,header2).then(function(resp){
                                    if(resp.appStatus == 0){
                                        resp = resp.adAccountInsights;
                                        var array = [];
                                        angular.forEach(resp, function(value, key){
                                            var JSONobject = resp[key];
                                            angular.forEach(JSONobject, function(value, key){
                                                TotalSpend = TotalSpend + JSONobject[key].spend;
                                                lastSync = JSONobject[key].modifiedOn;
                                            });
                                        });
                                        $scope.networkmaparray[i].networkDetails[j]['TotalSpend']=TotalSpend;
                                        $scope.networkmaparray[i].networkDetails[j]['lastSync']=lastSync;
                                    }
                                }));
                            }
                        })(i,j);
                    }
                }
                
            }
            $q.all(promises).finally(
                    function(){                            
                            $scope.tempnetworkmapArr = $scope.networkmaparray;
                            //console.log(JSON.stringify($scope.tempnetworkmapArr, null, 2));   
                            $scope.fetchChildAndPush();
                            $rootScope.progressLoader = 'none';
                    });
        };
            

            $scope.fetchChildAndPush = function (){
                var promises = [];
            for (i = 0; i < $scope.networkmaparray.length; i++){
                if ($scope.networkmaparray[i].hasOwnProperty('networkDetails')){
                    for(j=0; j< $scope.networkmaparray[i].networkDetails.length; j++){
                        (function(i,j){
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId') && $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork){   
                                var TotalCampaigns = 0;
                                var module2 = '/readadcampaign?userNetworkMapId=' +  $scope.networkmaparray[i].networkDetails[j].userNetworkMapId + "&networkAdAccountId="+$scope.networkmaparray[i].networkDetails[j].adAccountId;
                                var header2 = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTp(module2,header2).then(function(resp){  
                                    if(resp.appStatus == 0){
                                        TotalCampaigns = resp.adcampaigns.length;
                                        $scope.networkmaparray[i].networkDetails[j]['TotalCampaigns']=TotalCampaigns;
                                    }
                                }));
                            }
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty('adAccountId') && $scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork){   
                                var TotalCampaigns = 0;
                                var module2 = '/readcampaign?userNetworkMapId=' +  $scope.networkmaparray[i].networkDetails[j].userNetworkMapId + "&adAccountId="+$scope.networkmaparray[i].networkDetails[j].adAccountId;
                                var header2 = {
                                    headers: {
                                        'userId': $window.localStorage.getItem("userId"),
                                        'accessToken': $window.localStorage.getItem("accessToken")
                                    }
                                };
                                promises.push(apiService.getTwr(module2,header2).then(function(resp){
                                    if(resp.appStatus == 0){
                                        TotalCampaigns = resp.campaign.length;
                                        $scope.networkmaparray[i].networkDetails[j]['TotalCampaigns']=TotalCampaigns;
                                    }
                                }));
                            }
                        })(i,j);
                    }
                }
            }
            
            $q.all(promises).finally(function(){
                //console.log(JSON.stringify($scope.networkmaparray, null, 2));
            });
                
                
            }

           
            
            /*$scope.fetchPlanDetails = function(planId){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchplandetails',
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
                    if (response.data.appStatus == '0') {// success
                        console.log("success fetch plan details");
                       // $scope.planDetailsResponse = response.data.planDetailsResponse;
                        for(var i=0;i<response.data.planDetailsResponse.length;i++){
                            if(response.data.planDetailsResponse[i].planId == planId){
                                $scope.planDetails = response.data.planDetailsResponse[i].planName;
                            }
                        }
  
                        
                    } else {// failed
                        console.log("failure fetch plan details");
                    }
                });
            }*/
            
            /*$scope.fetchadvertisernetwork = function(){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchadvertisernetwork?accountId='+$window.localStorage.getItem("accountId"),
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
                        if (response.data.appStatus == '0') {// success
                            console.log("success fetchadvnetwork");
                            console.log(response.data.advertiserNetworkList.length)
                        }
                        else{
                            console.log("failed fetchadvnetwork");
                        }
                 });
            }*/
        
        
        
            /*$scope.paypalIntegration = function(){
                var parameters = {
                    "userId" : $window.localStorage.getItem("userId"),
                    "accessToken" : $window.localStorage.getItem("accessToken"),
                    "planId" : "110002",  
                    "planName" : "SMB",
                    "transactionId" : "8RK00710S81841254",
                    "amount" : "200",
                    "currencyCode" : "USD",
                    "paymentStatus" : "Completed"
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/paypalIntegration',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(response) {
                     $scope.accountLogo = response.data;
                });
            }*/
        
        
        
           /* $scope.createAccountPlanMapping = function(planId,paymentId,planStartDateval,planEndDateval){
                var parameters = {
                    "userId" : $window.localStorage.getItem("userId"),
                    "accessToken" : $window.localStorage.getItem("accessToken"),
                    "planId" : "110002",  
                    "paymentId" : "120005",
                    "currentPlanFlag" : "1",
                    "planStartDate" : "2017-01-20",
                    "planEndDate" : "2017-02-19"
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/createaccountplanmapping',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(response) {
                     $scope.accountLogo = response.data.imageContent[$scope.accountLogoUrl];
                });
            }*/
            
            
            function minTwoDigits(n) {
                return (n < 10 ? '0' : '') + n;
            }
            $scope.fetchPlanDetails = function(noOfAdvertisers,planId){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchplandetails',
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
                    if (response.data.appStatus == '0') {
                        $scope.planDetailsResponse = response.data.planDetailsResponse; 
                        angular.forEach($scope.planDetailsResponse, function(value, key) { 
                            if(planId == value.planId){
                                $scope.totalAdvertiser = minTwoDigits(value.maxNoAccounts); 
                                $scope.currentPlanOption = value.planName;
								$scope.planDetails.currentPlan = value.planName;
								$scope.standardPlan = value.planName
                            }
                        });
                        angular.element($("#accountDashboardHeader .btnAddNewOpsTeam").prop("disabled",false));
                        console.log(noOfAdvertisers+"===="+$scope.totalAdvertiser);
                        if(noOfAdvertisers >= $scope.totalAdvertiser){
                            angular.element($("#accountDashboardHeader .btnAddNewOpsTeam").prop("disabled",true));
                        }
                        if(noOfAdvertisers == $scope.totalAdvertiser){
                            $scope.progressBarValue = "100";
                            angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                        }
                        else if(noOfAdvertisers == ($scope.totalAdvertiser/2)){
                            $scope.progressBarValue = "50";
                            angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                        }
                        else if(noOfAdvertisers < ($scope.totalAdvertiser/2)){
                            $scope.progressBarValue = "30";
                            angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                        }
                        else if(noOfAdvertisers > ($scope.totalAdvertiser/2)){
                            $scope.progressBarValue = "70";
                            angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                        }
                    }
                });
            }
            
            function changeDateFormat(input) {
                var datePart = input.match(/\d+/g),day = datePart[0], month = datePart[1], year = datePart[2];
                return year+'-'+month+'-'+day;
            }
            function add_months(dt, n){
                return new Date(dt.setMonth(dt.getMonth() + n));      
            }
            
            $scope.daysBetween = function( date1, date2 ) {
                //Get 1 day in milliseconds
                var one_day=1000*60*60*24;

                // Convert both dates to milliseconds
                var date1_ms = date1.getTime();
                var date2_ms = date2.getTime();

                // Calculate the difference in milliseconds
                var difference_ms = date2_ms - date1_ms;

                // Convert back to days and return
                return Math.round(difference_ms/one_day); 
              }
            $scope.changePlanDetails = function(plan){
				$scope.planDetails.currentPlan = plan	

				if($scope.standardPlan != $scope.planDetails.currentPlan){
					$scope.planChange = true;
				}
				if($scope.planDetails.currentPlan == "SMB"){
					$scope.totalAmount = "0.01";
					$scope.planDesc = "5";
				} else {
					$scope.totalAmount = "0.02";
					$scope.planDesc = "10";
				}
					
			}
			$scope.onStartDateChange = function(selectedStartDate){
				$scope.selectedStartDate = selectedStartDate;

				//console.log($scope.selectedStartDate);
			}
			$scope.onEndDateChange = function(selectedEndDate){
				$scope.selectedEndDate = selectedEndDate;
				$scope.eDate = $filter('date')($scope.selectedEndDate,'yyyy-MM-dd');			

			}
			$scope.resetEdit = function(){
				$scope.isEditPlanDetails = true;
                                $scope.paypalBtn = false;
                                $scope.isClosePlanDetails = false;
				$scope.isEditPlanDate = false;
				$scope.isEditPlanDatelabel = true;
				$scope.planStartDateval =$scope.planStartDateval_dup;
				$scope.planEndDateval = $scope.planEndDateval_dup;
				$scope.paypalLabel="Renew & Pay"
			}
            $scope.editPlanDetails = function(){
				$scope.paypalLabel = "Renew & Pay";
				$scope.isEditPlanDetails = false;
                                $scope.paypalBtn = true;
                                $scope.isClosePlanDetails = true;
				//$scope.isEditPlanDate = true;
				//$scope.isEditPlanDatelabel = false;
				//$scope.planStartDateval = {};
				//$scope.planEndDateval = {};
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0! 
				var yyyy = today.getFullYear();
				if(dd<10){dd='0'+dd} 
				if(mm<10){mm='0'+mm} 
				today = yyyy+'-'+mm+'-'+dd;
				
				
				var futureOneMonth = new Date();
				var dd1 = futureOneMonth.getDate()+1;
				var mm1 = futureOneMonth.getMonth()+2; //January is 0! 
				var yyyy1 = futureOneMonth.getFullYear();
				if(dd1<10){dd1='0'+dd1} 
				if(mm1<10){mm1='0'+mm1} 
				$scope.planStartDateval1 = {
					value: new Date(today)
				};
				$scope.selectedStartDate = $scope.planStartDateval1.value;
				$scope.planEndDateval1 = {
					value:new Date(futureOneMonth)
				};
				$scope.selectedEndDate = addMonthsUTC($scope.selectedStartDate, 1);
				//$scope.selectedEndDate = $scope.planEndDateval1.value;
				console.log($scope.selectedStartDate+" :: "+$scope.selectedEndDate);
				$scope.sDate = $filter('date')($scope.selectedStartDate,'yyyy-MM-dd');
				$scope.eDate = $filter('date')($scope.selectedEndDate,'yyyy-MM-dd');
				console.log($scope.sDate);
				console.log($scope.eDate);
				$window.localStorage.setItem("planEndDate", $scope.eDate);
			}

              function addMonthsUTC (date, count) {
				  if (date && count) {
					var m, d = (date = new Date(+date)).getUTCDate()

					date.setUTCMonth(date.getUTCMonth() + count, 1)
					m = date.getUTCMonth()
					date.setUTCDate(d-1)
					if (date.getUTCMonth() !== m) date.setUTCDate(0)
				  }
				  return (date-1);
				}
							
            $scope.fetchCurentPlanDetails = function(){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchcurrentplan',
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
					//console.log(response);
                    if (response.data.appStatus == '0') {// success
                        //console.log("success fetch plan");
                        $scope.noofAdvertiser = minTwoDigits(response.data.noOfAdvertisers);
                        $scope.planId = response.data.currentPlanResponse[0].planId;
                        $scope.paymentId = response.data.currentPlanResponse[0].paymentId; 
                        $scope.planStartDateTime = response.data.currentPlanResponse[0].subscriptionStartDate;
                        $scope.planEndDateTime = response.data.currentPlanResponse[0].subscriptionEndDate;
                        var planStartDate = $scope.planStartDateTime.split(" ");
                        var planEndDate = $scope.planEndDateTime.split(" "); 
                        

                        var today1 = new Date();
                        var dd = today1.getDate();
                        var mm = today1.getMonth()+1; //January is 0! 
                        var yyyy = today1.getFullYear();
                        if(dd<10){dd='0'+dd} 
                        if(mm<10){mm='0'+mm} 
                        today1 = yyyy+'-'+mm+'-'+dd;    
						
						var arr = planEndDate[0].split('-');
						var endDate = arr[2]+'-'+arr[1]+'-'+arr[0]
						//console.log(today1);
						//console.log(endDate);



                        var currentDate = new Date(today1);
						var planEndDateval = new Date(endDate);
                        var diffDays = $scope.daysBetween(currentDate, planEndDateval);

                        console.log(diffDays);



                        $scope.isEditPlanDate = false;
                        $scope.isEditPlanDatelabel = true;
						$scope.planStartDateval = planStartDate[0];
                        $scope.planEndDateval = planEndDate[0];
						
						$scope.planStartDateval_dup = planStartDate[0];
                        $scope.planEndDateval_dup = planEndDate[0];

                       if(diffDays <= 5){
                            $scope.isEditPlanDetails = true;
                            $scope.paypalBtn = false;
                            $scope.isClosePlanDetails = false;
                            $scope.isEditPlanDate = false;
                            $scope.isEditPlanDatelabel = true;
                            //console.log($scope.isEditPlanDatelabel);
                       }
                       else{
                           $scope.isEditPlanDate = false;
                           $scope.isEditPlanDetails = false;
                           $scope.paypalBtn = true;
                           $scope.isClosePlanDetails = true;
                           $scope.isEditPlanDatelabel = true;
                           $scope.planStartDateval = planStartDate[0];
                           $scope.planEndDateval = planEndDate[0];
                       }
                       if(diffDays <= 5){
                           $scope.isPlanExpNotification = true;
                       }
                       else{
                           $scope.isPlanExpNotification = false;
                       }
                       $scope.fetchPlanDetails(response.data.noOfAdvertisers,$scope.planId);
                       
                    } else {// failed
                        console.log("failure fetch plan");
                    }
                });
                
            } 
            $scope.paypalLoginPopup = "none";
            $scope.integrationWithPayPal = function(){
                $scope.paypalLoginPopup = "block";
                $scope.paypalURL = 'https://www.sandbox.paypal.com/signin?country.x=US&locale.x=en_US'; //Test PayPal API URL
                var url = $scope.paypalURL + "";

                $scope.paypalID = 'Insert_PayPal_Email'; //Business Email
                $scope.trustSrc = function(src) {
                    return $sce.trustAsResourceUrl(src);
                 }
                 $scope.paypalLoginUrlLink = {src:url};
				 $scope.trustedHtml = $sce.trustAsHtml($scope.paypalURL); 
            }
             
            $scope.rightNavCtrl = function(obj){                
                //alert("$scope.advertiserDetails.length  : "+$scope.advertiserDetails.length);
                 //alert("$scope.rightNavCtrlbtn  : "+$scope.rightNavCtrlbtn);
                
                
                 if($scope.advertiserDetails.length  > ( $scope.rightNavCtrlbtn + 3)){
                    $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn + 3);
                   // console.log("1 : " +$scope.ctrlLimt);
                    $scope.rightNavCtrlbtn =  $scope.ctrlLimt;
                        $scope.isLeftBtnEnable = true;
                        $scope.isrightBtnEnable = false;
                        
                }
                
            }
            $scope.leftNavCtrl = function(ctrlLimt){
                
               // alert(" left $scope.advertiserDetails.length : "+$scope.advertiserDetails.length);
                // alert(" left $scope.rightNavCtrlbtn : "+$scope.rightNavCtrlbtn);
                
                 if($scope.rightNavCtrlbtn  != 0){
                   //  alert("ok");
                    $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn - 3);
                   // console.log("2 :  "+$scope.ctrlLimt);
                    $scope.rightNavCtrlbtn =  $scope.ctrlLimt;

                      $scope.isLeftBtnEnable = false;
                      $scope.isrightBtnEnable = true;
              }
             
            }
            $scope.updateAdvertiserDescrip = function(){// block bcoz of service changes
              //  alert("test");
                var parameters = {
                    "userId" : $window.localStorage.getItem("userId"),
                    "accessToken" : $window.localStorage.getItem("accessToken"),
                    "advertiserId" : "600002",  
                    "pocName" : "Marketing Manager",
                    "pocNumber" : "9620303610",
                    "description" : "Disney Parks and Resorts",
                    "logoUrl" : "account/100001/400001/400001.png"
                    
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/updateadvertiser',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(response) {
                    if (response.data.appStatus == '0' && advertiserLogoUrl != undefined) {
                        $rootScope.progressLoader = "none";
                        //console.log(resp.data.imageContent[advertiserLogoUrl]);
                        $scope.accountLogo = response.data.imageContent[$scope.accountLogoUrl];
                    }else{
                        $rootScope.progressLoader = "none";
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }

                });
            }
            
            $scope.fetchhistoryplandetails = function(){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchhistoricplandetails ',
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
					//console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.prevPlanDetails = "block";
                        $scope.prevPlanDetailsErrormsg = "none";
                        $scope.previousPlanDetails = response.data.fetchHistoricPlanDetailsResponse;
                        $scope.startDateTime = response.data.fetchHistoricPlanDetailsResponse.subscriptionStartDate;
                      //$scope.startDate = $scope.startDateTime[0];
                        //console.log($scope.startDate);
                    }
                    else if(response.data.errorId == '3058')
                    {
                        $rootScope.progressLoader = "none";
                        $scope.prevPlanDetails = "block";
                        $scope.prevPlanDetailsErrormsg = "none";
                        $scope.previousPlanDetails = [];
                    }
                    else{
                        $scope.prevPlanDetailsErrormsg = "block";
                        $scope.prevPlanDetails = "none";
                        $scope.prevPlanErrorHeading = "Error Message";
                        $scope.prevPlanErrorMsg = response.data.errorMessage;
                    }
                });
            }
            $scope.closePrevPlanDetails = function(){
                $scope.prevPlanDetails = "none";
                $scope.prevPlanDetailsErrormsg = "none";
            }

            $scope.enableEditDescription = function (desc,advertiserId){
	
				 $scope.iseditMode[advertiserId] = true;				
	             $scope.advDescription = desc;
			}
			
		$scope.updateDescription = function (description,advertiserId){

		$scope.advertiserId = advertiserId;
		 $scope.advertiserDesc = description;
		
		angular.forEach($scope.advertiserData,function(returnVal,key){
		if(returnVal.advertiserId == $scope.advertiserId ){
		    $scope.advertiserLogoUrl = returnVal.logoUrl;                                
                $scope.pocName =returnVal.pocName;
				$scope.pocNumber = returnVal.pocPhone;		
		  var parameters = {
                    "userId" : $window.localStorage.getItem("userId"),
                    "accessToken" : $window.localStorage.getItem("accessToken"),
                    "advertiserId" : $scope.advertiserId,
                    "pocName" :  $scope.pocName,
                    "pocNumber" : $scope.pocNumber ,
                    "description" : $scope.advertiserDesc,
                    "logoUrl" :  $scope.advertiserLogoUrl                     
                };
				$http({
                    method: 'POST',
                    url: apiBase+'/user/updateadvertiser',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(response) {     
			    	 $scope.iseditMode[$scope.advertiserId] = false;								   				
					  angular.forEach($scope.networkmaparray,function(val,key){
		                if(val.advertiserID == $scope.advertiserId ){
		                   val.description = $scope.advertiserDesc;
		                  }						  
				       })
					 
					 
                });
		}
	
		})

		}
	
		$scope.cancelEditMode = function (advertiserId,desc){
			   	$scope.iseditMode[advertiserId] = false;	
	          	$scope.advertiserId = advertiserId;
                 angular.forEach($scope.networkmaparray,function(val,key){
		                if(val.advertiserID == $scope.advertiserId ){
		                   val.advertiserDesc =   $scope.advDescription;
		                  }						  
				       })				
		}
		
		/*$scope.openjQueryPopup = function(){
			var w = window.open("", "popupWindow", "width=600, height=400, scrollbars=yes");
               $timeout(function () {
					console.log('closed');
					w.close();
				}, 5000);
		}*/
		
		/*$timeout(function () {
				console.log(angular.element('#paypal-button-container iframe body .paypal-button-content'));
				angular.element('#paypal-button-container').addClass('paypal-button-container-custom');
				angular.element('#paypal-button-container iframe body .paypal-button-content').empty();
				}, 10000);*/

		}]);




dashboard.filter('split', function() {
        return function(input, splitChar, splitIndex) {
            // do some bounds checking here to ensure it has that index
            return input.split(splitChar)[splitIndex];
        }
    });