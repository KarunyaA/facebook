dashboard.controller("metriccomparisonopsController", ['$rootScope', '$scope', '$http', '$state', '$filter', '$location', 'dashboardService', 'Flash', '$q', '$window', '$sce', 'appSettings', '$timeout',
    function ($rootScope, $scope, $http, $state, $filter, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;
         var fbNetwork = appSettings.fbNetwork;
        $scope.bool = [];
        $scope.networksarrayforacc = [];
        $scope.wholeParentArray = [];
        $scope.selectedgrapharray = [];
        $scope.wholeArray = [];
        $scope.wholechildArray = [];
        $scope.wholemetricArray = [];
        $scope.grapharray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforaccount = [];
        $scope.campaigninsights = [];
        $scope.accinsights = [];
        $scope.networkforadv = false;
        $scope.insightsarr = [];
        $scope.arrayofobj = [];
        $scope.arr1 = [];
        $scope.arr2 = [];
        $scope.networkmaparray = [];
        $scope.plotarray = [];
        $scope.adaccountid =[];
        $scope.advertiserdetails = {};
        $scope.newgraph = 'false';
       // $scope.nograph=false;
        $scope.breakpoints = [];
        $scope.defaultmetricArray = [];
        $scope.allmetrics = [];
        
        $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();   
        });
        
        $scope.loadCurrencyCode = function(){
			$http.get("localData/currencyData.json").success(function (data){
				$scope.currencyList = data.currencyList;
				//console.log($scope.currencyList);
			});
		}
                
                
        //getting the account name and id
        $scope.getaccountdetails = function () {
            $rootScope.progressLoader = "block";
            $scope.accountId = $window.localStorage.getItem("accountId");
          //  console.log($scope.accountId);
            $scope.advertiserDetails = {};
            $scope.adverDetails = [];
            $http({
                method: 'GET',
                url: apiBase + '/user/getaccountdetails?accountId=' + $scope.accountId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                };
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.accountName = response.data.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                    $scope.downloadAccountLogo($scope.accountLogoUrl);

                } else {// failed
                    $rootScope.progressLoader = "none";
                }
            });
            
            
             $scope.loadCurrencyCode();
        }
        $scope.getaccountdetails();

        $scope.downloadAccountLogo = function (accountLogoUrl) {
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths": [accountLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer + '/downloadimages',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (resp) {
                $scope.accountLogo = resp.data.imageContent[$scope.accountLogoUrl];
            });
        }

        
//         $(".date-input").datepicker({
//            });
//     
        //getting parent and child campaign details 
        $scope.fetchparent = function () {
            $rootScope.progressLoader = "block";
//            $window.localStorage.setItem("advertiserId", advertiserId);
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchparentcampaignsbyadvertiser?advertiserId=' + $window.localStorage.getItem("advertiserId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {
                     $rootScope.progressLoader = "none";
                    // success
                    $scope.campaigndetails = response.data.parentCampaigns;
                    //adding parent details to whole parent array
                    for (var i = 0; i < $scope.campaigndetails.length; i++) {
                        var _obj = {
                            "id": $scope.campaigndetails[i].parentCampaignId,
                            "name": $scope.campaigndetails[i].parentCampaignName,
                            "type": "parent"
                        }
                        $scope.wholeParentArray.push(_obj);
                    }
                //   console.log($scope.wholeParentArray);

                    //getting networks for selected advertiser
                    $scope.checkNetworkforadvertiser($window.localStorage.getItem("advertiserId"));

                   // console.log("hiee")
                    
                    
           //          getting child campaigns for selected advertiser
                    angular.forEach($scope.wholeParentArray, function (val, key) {
                       
                            $scope.fetchChildAndPush(val.id);
                    });
                
                }
                else {// failed
                    
                     if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    };
                     $rootScope.progressLoader = "none";
                }
            });
            
            
            
            //changing the metric dropdown based on selected advertiser
              //   $scope.metricchangebasedonadvertiser(advertiserId);
        }
        
       //if no campaign is selected
        $scope.nocampaignselection = function()
        {
            $scope.selectedcampaign="Select Campaign";
         
                $scope.selectedusernetmap = $window.localStorage.getItem("userNetworkMapId");
                if($scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
                {
                     $scope.readadaccountInsights($scope.formattedfromdate, $scope.formattedtodate, $scope.breakdown,$scope.selectedusernetmap);
                }   
                else
                {
                    $scope.readadaccountInsights($scope.startdat, $scope.enddat, $scope.breakdown,$scope.selectedusernetmap);
                }    
        }
        
        
        $scope.resetdate1 = function(date)
        {
                $scope.fromDate="";
                $scope.toDate="";
                $scope.startdat = "";
                $scope.enddat = "";
                $scope.newgraph = 'false';
                //getting last week dates
                var today = new Date();
                var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
                var lastWeekMonth = lastWeek.getMonth() + 1;
                var lastWeekDay = lastWeek.getDate();
                var lastWeekYear = lastWeek.getFullYear();
                var lastWeekDisplay = lastWeekMonth + "/" + lastWeekDay + "/" + lastWeekYear;
                var lastWeekDisplayPadded = (("0000" + lastWeekYear.toString()).slice( - 4) + "-" + ("00" + lastWeekMonth.toString()).slice( - 2) + "-" + ("00" + lastWeekDay.toString()).slice( - 2));
                $scope.formattedfromdate = $filter('date')(lastWeekDisplayPadded, 'yyyy-MM-dd');
                $scope.formattedtodate = $filter('date')(today, 'yyyy-MM-dd');
                $scope.breakdown = "DAILY";
      //  console.log($scope.selectedcampaign);
        //resetting from and to date to empty and displaying last week metrics
        if($scope.selectedcampaign=="" || $scope.selectedcampaign=="Select Campaign" || $scope.selectedcampaign==undefined)
            {
                //no parent/child campaign is selected
                //getting the user network map id of the selected advertiser
                $scope.newgraph ='false';
                $scope.selectedusernetmap =  $window.localStorage.getItem("userNetworkMapId");
                //for (i = 0; i < $scope.networkmaparray.length; i++)
                   //     {
                                $scope.readadaccountInsights($scope.formattedfromdate, $scope.formattedtodate, $scope.breakdown, $scope.selectedusernetmap);
                    //    }
            }
            else
            {                   
                //getting campaign insights for selected date range    
               //checking whether the selected parent has child or not
               
               angular.forEach($scope.wholeParentArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                            angular.forEach($scope.wholechildArray, function (v, key) {
                              if(val.id==v.parentid)
                                  {
                                      //getting insights bypassing child id and usernetwork map id of selected parent
                                        $scope.getinsights($scope.formattedfromdate, $scope.formattedtodate,$scope.breakdown,v.id,v.usernetworkmapid);
                                  }
                                  else
                                  {
                                      //selected parent does not have child
                                  }    
                     
                                });     
                    }
                });
                
              //    console.log($scope.selectedcampaign);
                //getting insights of the selected child
                 angular.forEach($scope.wholechildArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                        $scope.getinsights($scope.formattedfromdate, $scope.formattedtodate,$scope.breakdown,val.id,val.usernetworkmapid);
                    }
                 
                 });
            }
        }
  
       
       
//                //changing the metric dropdown based on selected network
//        $scope.metricchangebasedonnetwork = function(networkId)
//        {
//           // console.log(networkId);
//           // console.log($scope.advertiserId);
//            if(networkId!="" || $scope.advertiserId!="")
//            {    
////                             angular.forEach($scope.networksarrayforacc, function (val, key) {
////                               if (networkId == val.networkId)
////                               {
////                                    $scope.selectedusernetmap=val.userNetworkMapId;
////                                }
////                                });
//                  console.log($scope.selectedusernetmap);
//                  
//                    //getting metric object of obtained user network map id
//                      angular.forEach($scope.grapharray, function (val, key) {
//                           if(val.usernetwork==$scope.selectedusernetmap)
//                           {
//                               $scope.selectedgrapharray.push(val);
//                           }
//                      });
//                    $scope.wholemetricArray = [];
//                    $scope.arr1=[];
//                    
//                    //updating the metric drop down
//                    angular.forEach($scope.selectedgrapharray, function (val, key) {
//                         angular.forEach(val.metricobj, function (val1, key1)
//                         {
//                                    var obj=val.metricobj[key1];
//                                    
//                                    //removing duplicates 
//                                    if ($scope.arr1.indexOf(obj.name) == - 1) {
//                                       $scope.arr1.push(obj.name);
//                                       $scope.wholemetricArray.push(obj);
//                                 }
//                         });
//                  
//                     });
//                    // console.log($scope.metricselect);
//                     console.log($scope.wholemetricArray);
//                   //  console.log($scope.selectedgrapharray);
//                     
//                        
////                      creating an array for selected advertiser
//                         $scope.newgraph='true';
//                         $scope.sampledatacreation();
//              
//                
//  
//           }
//           else
//           {
//               //$scope.wholemetricArray = [];
//               //default graph and metric array 
//               //console.log($scope.defaultmetricArray);
//               //setting array for on-load metrics
//              // angular.forEach($scope.defaultmetricArray, function (key1, value1) {
//                         
//               //       $scope.wholemetricArray.push($scope.defaultmetricArray[value1]);
//              // });
//                console.log($scope.wholemetricArray);
//               // creating an array for selected advertiser
//                         $scope.newgraph='false';
//                         $scope.sampledatacreation();
//                
//               
//           }    
//           
//        }
//        
        //select network for advertiser
        $scope.selectnetworkforadv = function(networkid)
        {
             //changing the metric dropdown based on selected network
             $scope.metricchangebasedonnetwork(networkid);
             
        }
        
        //select network from on-load 
        $scope.selectnetwork = function(networkname)
        {
            if(networkname!="")
            {
            //getting network id from selected network name
            angular.forEach($scope.allnetworksarray, function (val, key)
                        {
                            if (networkname == val.networkName)
                            {
                               $scope.selectednetworkid=val.networkId;
                            }
                        });
            
                        //changing the metric dropdown based on selected network
                         $scope.metricchangebasedonnetwork($scope.selectednetworkid);
            }
            else
            {    
            //changing the metric dropdown based on selected network
             $scope.metricchangebasedonnetwork(networkname);
            }
        }

        //getting networks for selected advertiser
        $scope.checkNetworkforadvertiser = function (advertiserId)
        {
            $scope.networkforadv = true;
            $scope.networksarrayforadvertiser = [];
            //traversing the account networks for advertiser email 
            for (i = 0; i < $scope.networksarrayforacc.length; i++)
            {
                        if ($window.localStorage.getItem("userNetworkMapId") == $scope.networksarrayforacc[i].userNetworkMapId)
                        {
                            $scope.networkid = $scope.networksarrayforacc[i].networkId;
                            angular.forEach($scope.allnetworksarray, function (val, key)
                            {
                                if ($scope.networkid == val.networkId)
                                {
                                    $scope.networksarrayforadvertiser.push(val);
                                }
                            });
                        }
            }
         //   console.log($scope.networksarrayforadvertiser);
        }
        $scope.parentselection = function (parentobj)
        {
          //  var iden1=0;
            $scope.selectedcampaign = '';
            $scope.selectedcampaign = parentobj.name;
            $scope.selectedcampaignsinsightscount = 0;
            $scope.campaignwithnoinsights = 0;
            
            //checking whether from and to dates are selected or not 
            if($scope.enteredfromDate == undefined || $scope.enteredtoDate == undefined || $scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
            {
            //getting last week dates
            var today = new Date();
            var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
            var lastWeekMonth = lastWeek.getMonth() + 1;
            var lastWeekDay = lastWeek.getDate();
            var lastWeekYear = lastWeek.getFullYear();
            var lastWeekDisplay = lastWeekMonth + "/" + lastWeekDay + "/" + lastWeekYear;
            var lastWeekDisplayPadded = (("0000" + lastWeekYear.toString()).slice(-4) + "-" + ("00" + lastWeekMonth.toString()).slice(-2) + "-" + ("00" + lastWeekDay.toString()).slice(-2));

            $scope.formattedfromdate = $filter('date')(lastWeekDisplayPadded, 'yyyy-MM-dd');
            $scope.formattedtodate = $filter('date')(today, 'yyyy-MM-dd');
            $scope.breakdown = "DAILY";
            }
            else
            {    
                 $scope.formattedfromdate=$scope.startdat;
                 $scope.formattedtodate=$scope.enddat;
            }  
           

           //   console.log(parentobj.id);
             //checking whether the selected parent has child or not
             angular.forEach($scope.wholechildArray, function (val, key) {
                    if(parentobj.id==val.parentid)
                     {
                        //getting insights bypassing child id and usernetwork map id of selected parent
                        $scope.getinsights($scope.formattedfromdate, $scope.formattedtodate,$scope.breakdown,val.id,val.usernetworkmapid);
                        $scope.selectedcampaignsinsightscount++;
                     }
                     else
                     {
                         //selected parent does not have child
                          $scope.nograph=true;
                     }    
                     
             });
            
      
        }

        $scope.test = function (parentobj, _index) {

            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                {
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        }

        
        $scope.childselection = function (_index, childobj)
        {
           // var iden1=0;
            $scope.bool[childobj.parentid] = true;
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != childobj.parentid)
                {
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }

            // angular.element('#child' + _index).addClass('selectchild');
            $scope.selectedcampaign = '';
            $scope.selectedcampaign = childobj.name;
            $scope.show = true;

          
          
            //checking whether from and to dates are selected or not 
            if($scope.enteredfromDate == undefined || $scope.enteredtoDate == undefined || $scope.startdat == undefined || $scope.enddat == undefined || $scope.startdat == "" || $scope.enddat == "")
            {
                //getting last week dates
                var today = new Date();
                var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
                var lastWeekMonth = lastWeek.getMonth() + 1;
                var lastWeekDay = lastWeek.getDate();
                var lastWeekYear = lastWeek.getFullYear();
                var lastWeekDisplay = lastWeekMonth + "/" + lastWeekDay + "/" + lastWeekYear;
                var lastWeekDisplayPadded = (("0000" + lastWeekYear.toString()).slice(-4) + "-" + ("00" + lastWeekMonth.toString()).slice(-2) + "-" + ("00" + lastWeekDay.toString()).slice(-2));
                
                $scope.formattedfromdate = $filter('date')(lastWeekDisplayPadded, 'yyyy-MM-dd');
                $scope.formattedtodate = $filter('date')(today, 'yyyy-MM-dd');
                $scope.breakdown = "DAILY";
            }
            else
            {    
                 $scope.formattedfromdate=$scope.startdat;
                 $scope.formattedtodate=$scope.enddat;
            }  
            
            
                //getting insights bypassing child id and usernetwork map id of selected child
                $scope.getinsightsforchild($scope.formattedfromdate, $scope.formattedtodate,$scope.breakdown,childobj.id,childobj.usernetworkmapid);
          
        }


       var id = 1;
        $scope.getinsights = function (startdate,enddate,breakdown,childid,usernetworkmapid)
        {
          //  console.log("getting campaign insights");
            $scope.breakpoints = [];
            $scope.grapharray=[];
            
           $rootScope.progressLoader = "block";
             $scope.newgraph='false';
             
             if(breakdown == "DAILY")
           {
               $scope.displaydate=[];
               //getting dates between corresponding selected start and end values
                date1 = new Date(startdate);
                date2 = new Date(enddate);
                var day = 1000 * 60 * 60 * 24;
                var diff = (date2.getTime() - date1.getTime()) / day;
                for (var i = 0; i <= diff; i++)
                {
                    var xx = date1.getTime() + day * i;
                    var yy = new Date(xx);
                            
                    var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                    var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                    $scope.breakpoints.push(d2);
                }
                
             //   console.log($scope.breakpoints);
                for(var i = 0; i <$scope.breakpoints.length; i++)
               {
                    $scope.displaydate.push(new Date($scope.breakpoints[i]).getDate() + "-" + new Date($scope.breakpoints[i]).toLocaleString('en-us', { month: "short" }));
               }
             //  console.log($scope.displaydate);
           }
            
            queryStr = "userNetworkMapId=" +  $window.localStorage.getItem("userNetworkMapId")+ "&" + "adCampaignId=" + childid +'&fromDate=' + startdate + '&toDate=' + enddate + '&breakDown=' + breakdown;
          
            $http({
                method: 'GET',
                url: apiTPBase + "/readadcampaigninsights" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                var index = 0;
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                        $scope.nograph=false;
                        $scope.wholemetricArray = [];
                        $scope.innerarray = [];
                        $scope.weekvalue = [];
                        $scope.weeknum = [];
                        $scope.monthnum = [];
                        $scope.quaternum = [];
                        $scope.halfnum = [];
                        $scope.yearnum = [];
                        $scope.date = [];
                         var iden1 = 0;
                         //$scope.nograph=false;
                    $scope.campaigninsights = response.data.adCampaignInsights;
                 //   console.log($scope.campaigninsights);
                    
                    
                    angular.forEach($scope.campaigninsights, function (value, key) {
                        var JsonObj = $scope.campaigninsights[key]
                        var array = [];
                     //   console.log(JsonObj);
                        for (var j in JsonObj) {
                           // console.log(j);
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                $scope.innerarray = JsonObj[j];
                                
                              //  console.log($scope.innerarray);
                                //converting timestamp to dates
                                if(breakdown == "DAILY")
                                {    
                                     for (var timestamp in $scope.innerarray)
                                    {
                                        var timestmp=timestamp.toString();
                                         if(timestmp.length==10)
                                         {
                                             //timestamp is in seconds
                                             //converting to milliseconds
                                             var timest=timestmp.concat("000");
                                           //  console.log(timest);
                                         }   
                                          var date = $filter('date')(timest, 'yyyy-MM-dd');
                                          $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                    }
                                   //   console.log($scope.date);
                                }
                                //calculating week number from response
                                else if(breakdown == "WEEKLY")
                                {
                                    for (var weeknum in $scope.innerarray)
                                        {
                                               var parts=weeknum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.weeknum.push(parts);
                                               $scope.getdatesfromweeknum(weekno,year);
                                        }
                                      //   console.log($scope.weeknum);
                                }
                                //calculating month number from response
                                else if(breakdown == "MONTHLY")
                                {
                                    for (var monthnum in $scope.innerarray)
                                        {
                                               var parts=monthnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.monthnum.push(parts);
                                        }
                                }
                                //calculating quarter number from response
                                else if(breakdown == "QUARTERLY")
                                {
                                    for (var quaternum in $scope.innerarray)
                                        {
                                               var parts=quaternum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.quaternum.push(parts);
                                        }
                                }
                                //calculating half-yearly number from response
                                else if(breakdown == "HALFYEARLY")
                                {
                                    for (var halfnum in $scope.innerarray)
                                        {
                                               var parts=halfnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.halfnum.push(parts);
                                        }
                                }
                                //calculating yearly number from response
                                else if(breakdown == "YEARLY")
                                {
                                    for (var yearnum in $scope.innerarray)
                                        {
                                               var parts=yearnum.split('_').join(' ');
                                               var year=parts[1];
                                               $scope.yearnum.push(parts);
                                        }
                                }
                                
                                // traversing into the object to get insights
                                angular.forEach($scope.innerarray, function (value, key) {
                                     var id1 = 1;
                                    
                                    $scope.hasinsightdetails=false;
                                    $scope.wholemetricArray=[];
                                    $scope.wholemetricname=[];
                                    $scope.arrayofobj = [];
                                    $scope.parentmetricarray = [];
                                    $scope.insightsarr = [];
                                    $scope.arr1 = [];
                                    $scope.arr2 = [];
                                    var totalclicks = 0;
                                    var totalimpressions = 0;
                                    var totalspend = 0;
                                    var totalactions = 0;
                                    var t = $scope.innerarray[key];
                                 //   console.log(t)
                                    for (var k1 in t)
                                    {
                                        if (k1 == "clicks")
                                        {
                                            totalclicks+=t.clicks;
                                            var obj = {
                                                "name": k1,
                                                "value": totalclicks,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);

                                        }
                                        if (k1 == "impressions")
                                        {
                                            totalimpressions+=t.impressions;
                                            var obj = {
                                                "name": k1,
                                                "value": totalimpressions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }

                                        if (k1 == "spend")
                                        {
                                             totalspend+=t.spend;
                                            var obj = {
                                                "name": k1,
                                                "value": totalspend,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }
                                        if (k1 == "callToAction")
                                        {
                                            
                                             totalactions+=t.callToAction;
                                            var obj = {
                                                "name": "actions",
                                                "value": totalactions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push("actions");
                                        }
                                        if (k1 == "insightsDetails")
                                        {
                                            $scope.hasinsightdetails=true;
                                            $scope.insightsarr = t.insightsDetails;
                                            
                                        }
                                    }
                                    //console.log($scope.hasinsightdetails);
                            //        
      //                      if( breakdown == "DAILY")
      //                      {       
                                for (k in $scope.insightsarr)
                                    {
                                        //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                        var obj;
                                        function traverse(jsonObj, category) {
                                            if (typeof jsonObj == "object") {
                                                $.each(jsonObj, function (k, v) {
                                                    if (k == category) {
                                                        if (typeof v == "object")
                                                        {
                                                            angular.forEach(v, function (key1, value1) {
                                                                $scope.arrayofobj.push(key1);
                                                                $scope.parentmetricarray.push(k);
                                                            });
                                                        }
                                                        else
                                                        {
                                                            if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                            {

                                                            }
                                                            else
                                                            {
                                                                var t = 0;
                                                                var newchar = ' '
                                                                k = k.split('_').join(newchar);
                                                                var obj = {
                                                                    "name": k,
                                                                    "value": v,
                                                                    "id": id1++,
                                                                    "disabled": "false"
                                                                }
                                                                $scope.wholemetricArray.push(obj);
                                                                $scope.wholemetricname.push(k);
                                                            }
                                                        }

                                                    } else {
                                                        traverse(v, category);
                                                    }

                                                });
                                            }
                                            else {
                                                // jsonOb is a number or string
                                            }
                                        }
                                        traverse($scope.insightsarr, k)
                                       // console.log(obj)
                                        $scope.keyvalue = obj;
                                    }
                                  //  console.log($scope.arrayofobj);
                                   // console.log($scope.parentmetricarray);
                                    angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                        var parentmetric=$scope.parentmetricarray[value1];
                                                        var childmetric=key1.action_type;
                                                        var newchar = ' '
                                                        parentmetric = parentmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('_').join(newchar);
                                                   
                                                var obj = {
                                                         "name": parentmetric +" - "+ childmetric,
                                                         "value":key1.value,
                                                         "id": id1++,
                                                         "disabled": "false"
                                                        }
                                            
                                            $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                       //     console.log(obj);
                                          $scope.arr2.push(obj);

                                    });
                                    for (var i = 0; i < $scope.arr2.length; i++) {
                                      // console.log($scope.arr2[i]);
                                        $scope.wholemetricArray.push($scope.arr2[i]);
                                    }
                                   
                                       if(breakdown == "DAILY")
                                       {
                                        //   console.log(iden1);
                                        var obj1 = {
                                            "date": $scope.date[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      } 
                                            $scope.grapharray.push(obj1);
                                             
                                        }
                                        else if(breakdown == "WEEKLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.weeknum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      } 
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "MONTHLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.monthnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "QUARTERLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.quaternum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }  
                                        else if(breakdown == "HALFYEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.halfnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "YEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.yearnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetworkmapid,
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        
                                });
                            }
                        }
                       //  console.log($scope.wholemetricArray);
                    });
                  //   console.log($scope.wholemetricArray);
                  //   console.log($scope.grapharray);
                   //  console.log($scope.metricselect);
                   
                   
                $scope.allmetrics.push($scope.wholemetricname);
                //console.log($scope.allmetrics);
                $scope.wholemetricArray1=[];
                //getting only the intersecting metrics 
                $scope.commmonmetrics= $scope.allmetrics.shift().reduce(function(res, v) {
                                    if (res.indexOf(v) === -1 && $scope.allmetrics.every(function(a) {
                                    return a.indexOf(v) !== -1;
                                    })) res.push(v);
                                    return res;
                                    }, []);
                //console.log($scope.commmonmetrics);
            
                angular.forEach($scope.wholemetricArray, function (value, key) {
                    
                    for(i=0;i<$scope.commmonmetrics.length;i++)
                    {
                        if($scope.commmonmetrics[i]==value.name)
                        {
                            $scope.wholemetricArray1.push(value);
                        }
                    }
                });
                   
                   
                   
                   //call for sample graph data creation 
                   $scope.sampledatacreation();
                    
                }
                else
                {
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                    else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            if(response.data.networkError.message!='' && response.data.networkError.message!=undefined){
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            }else{
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                     //$scope.nograph = true;
                    
                    $scope.campaignwithnoinsights++;
               //     console.log($scope.campaignwithnoinsights);
                 
              //  console.log($scope.selectedcampaignsinsightscount);
                if($scope.campaignwithnoinsights == $scope.selectedcampaignsinsightscount)
                {
                    $scope.nograph = true;
                }
                }    
            });
        }
        
        
         $scope.getinsightsforchild = function (startdate,enddate,breakdown,childid,usernetworkmapid)
        {
            console.log("getting campaign insights");
            $scope.breakpoints = [];
            $scope.grapharray=[];
            
           $rootScope.progressLoader = "block";
             $scope.newgraph='false';
             
             if(breakdown == "DAILY")
           {
                $scope.displaydate=[];
               //getting dates between corresponding selected start and end values
                date1 = new Date(startdate);
                date2 = new Date(enddate);
                var day = 1000 * 60 * 60 * 24;
                var diff = (date2.getTime() - date1.getTime()) / day;
                for (var i = 0; i <= diff; i++)
                {
                    var xx = date1.getTime() + day * i;
                    var yy = new Date(xx);
                            
                    var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                    var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                    $scope.breakpoints.push(d2);
                }
            //    console.log($scope.breakpoints);
                for(var i = 0; i <$scope.breakpoints.length; i++)
               {
                    $scope.displaydate.push(new Date($scope.breakpoints[i]).getDate() + "-" + new Date($scope.breakpoints[i]).toLocaleString('en-us', { month: "short" }));
               }
            //   console.log($scope.displaydate);
           }
            
            queryStr = "userNetworkMapId=" +$window.localStorage.getItem("userNetworkMapId")+ "&" + "adCampaignId=" + childid +'&fromDate=' + startdate + '&toDate=' + enddate + '&breakDown=' + breakdown;
          
            $http({
                method: 'GET',
                url: apiTPBase + "/readadcampaigninsights" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                var index = 0;
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                        $scope.nograph=false;
                        $scope.wholemetricArray = [];
                        $scope.innerarray = [];
                        $scope.weekvalue = [];
                        $scope.weeknum = [];
                        $scope.monthnum = [];
                        $scope.quaternum = [];
                        $scope.halfnum = [];
                        $scope.yearnum = [];
                        $scope.date = [];
                         var iden1 = 0;
                         //$scope.nograph=false;

                    $scope.campaigninsights = response.data.adCampaignInsights;
               //     console.log($scope.campaigninsights);
                    
                    
                    angular.forEach($scope.campaigninsights, function (value, key) {
                        var JsonObj = $scope.campaigninsights[key]
                        var array = [];
                   //     console.log(JsonObj);
                        for (var j in JsonObj) {
                        //    console.log(j);
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                $scope.innerarray = JsonObj[j];
                                
                            //    console.log($scope.innerarray);
                                //converting timestamp to dates
                                if(breakdown == "DAILY")
                                {    
                                     for (var timestamp in $scope.innerarray)
                                    {
                                        var timestmp=timestamp.toString();
                                         if(timestmp.length==10)
                                         {
                                             //timestamp is in seconds
                                             //converting to milliseconds
                                             var timest=timestmp.concat("000");
                                       //      console.log(timest);
                                         }   
                                          var date = $filter('date')(timest, 'yyyy-MM-dd');
                                         $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                    }
                                 //     console.log($scope.date);
                                }
                                //calculating week number from response
                                else if(breakdown == "WEEKLY")
                                {
                                    for (var weeknum in $scope.innerarray)
                                        {
                                               var parts=weeknum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.weeknum.push(parts);
                                               $scope.getdatesfromweeknum(weekno,year);
                                        }
                                      //   console.log($scope.weeknum);
                                }
                                //calculating month number from response
                                else if(breakdown == "MONTHLY")
                                {
                                    for (var monthnum in $scope.innerarray)
                                        {
                                               var parts=monthnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.monthnum.push(parts);
                                        }
                                }
                                //calculating quarter number from response
                                else if(breakdown == "QUARTERLY")
                                {
                                    for (var quaternum in $scope.innerarray)
                                        {
                                               var parts=quaternum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.quaternum.push(parts);
                                        }
                                }
                                //calculating half-yearly number from response
                                else if(breakdown == "HALFYEARLY")
                                {
                                    for (var halfnum in $scope.innerarray)
                                        {
                                               var parts=halfnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.halfnum.push(parts);
                                        }
                                }
                                //calculating yearly number from response
                                else if(breakdown == "YEARLY")
                                {
                                    for (var yearnum in $scope.innerarray)
                                        {
                                               var parts=yearnum.split('_').join(' ');
                                               var year=parts[1];
                                               $scope.yearnum.push(parts);
                                        }
                                }
                                
                                // traversing into the object to get insights
                                angular.forEach($scope.innerarray, function (value, key) {
                                     var id1 = 1;
                                    
                                    $scope.hasinsightdetails=false;
                                    $scope.wholemetricArray=[];
                                    $scope.wholemetricname=[];
                                    $scope.arrayofobj = [];
                                    $scope.parentmetricarray = [];
                                    $scope.insightsarr = [];
                                    $scope.arr1 = [];
                                    $scope.arr2 = [];
                                    var totalclicks = 0;
                                    var totalimpressions = 0;
                                    var totalspend = 0;
                                    var totalactions = 0;
                                    var t = $scope.innerarray[key];
                                 //   console.log(t)
                                    for (var k1 in t)
                                    {
                                        if (k1 == "clicks")
                                        {
                                            totalclicks+=t.clicks;
                                            var obj = {
                                                "name": k1,
                                                "value": totalclicks,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);

                                        }
                                        if (k1 == "impressions")
                                        {
                                            totalimpressions+=t.impressions;
                                            var obj = {
                                                "name": k1,
                                                "value": totalimpressions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }

                                        if (k1 == "spend")
                                        {
                                             totalspend+=t.spend;
                                            var obj = {
                                                "name": k1,
                                                "value": totalspend,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }
                                        if (k1 == "callToAction")
                                        {
                                            
                                             totalactions+=t.callToAction;
                                            var obj = {
                                                "name": "actions",
                                                "value": totalactions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push("actions");
                                        }
                                        if (k1 == "insightsDetails")
                                        {
                                            $scope.hasinsightdetails=true;
                                            $scope.insightsarr = t.insightsDetails;
                                            
                                        }
                                    }
                                    //console.log($scope.hasinsightdetails);
                            //        
      //                      if( breakdown == "DAILY")
      //                      {       
                                for (k in $scope.insightsarr)
                                    {
                                        //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                        var obj;
                                        function traverse(jsonObj, category) {
                                            if (typeof jsonObj == "object") {
                                                $.each(jsonObj, function (k, v) {
                                                    if (k == category) {
                                                        if (typeof v == "object")
                                                        {
                                                            angular.forEach(v, function (key1, value1) {
                                                                $scope.arrayofobj.push(key1);
                                                                $scope.parentmetricarray.push(k);
                                                            });
                                                        }
                                                        else
                                                        {
                                                            if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                            {

                                                            }
                                                            else
                                                            {
                                                                var t = 0;
                                                                var newchar = ' '
                                                                k = k.split('_').join(newchar);
                                                                var obj = {
                                                                    "name": k,
                                                                    "value": v,
                                                                    "id": id1++,
                                                                    "disabled": "false"
                                                                }
                                                                $scope.wholemetricArray.push(obj);
                                                                $scope.wholemetricname.push(k);
                                                            }
                                                        }

                                                    } else {
                                                        traverse(v, category);
                                                    }

                                                });
                                            }
                                            else {
                                                // jsonOb is a number or string
                                            }
                                        }
                                        traverse($scope.insightsarr, k)
                                       // console.log(obj)
                                        $scope.keyvalue = obj;
                                    }
                                  //  console.log($scope.arrayofobj);
                                   // console.log($scope.parentmetricarray);
                                    angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                        var parentmetric=$scope.parentmetricarray[value1];
                                                        var childmetric=key1.action_type;
                                                        var newchar = ' '
                                                        parentmetric = parentmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('_').join(newchar);
                                                   
                                                var obj = {
                                                         "name": parentmetric +" - "+ childmetric,
                                                         "value":key1.value,
                                                         "id": id1++,
                                                         "disabled": "false"
                                                        }
                                            
                                            $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                       //     console.log(obj);
                                          $scope.arr2.push(obj);

                                    });
                                    for (var i = 0; i < $scope.arr2.length; i++) {
                                      // console.log($scope.arr2[i]);
                                        $scope.wholemetricArray.push($scope.arr2[i]);
                                    }
                                   
                                       if(breakdown == "DAILY")
                                       {
                                        //   console.log(iden1);
                                        var obj1 = {
                                            "date": $scope.date[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      } 
                                            $scope.grapharray.push(obj1);
                                             
                                        }
                                        else if(breakdown == "WEEKLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.weeknum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      } 
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "MONTHLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.monthnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "QUARTERLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.quaternum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }  
                                        else if(breakdown == "HALFYEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.halfnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "YEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.yearnum[iden1++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork": $window.localStorage.getItem("userNetworkMapId"),
                                            "childid":childid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        
                                });
                            }
                        }
                       //  console.log($scope.wholemetricArray);
                    });
//                     console.log($scope.wholemetricArray);
//                     console.log($scope.grapharray);
//                     console.log($scope.metricselect);
                    
                $scope.allmetrics.push($scope.wholemetricname);
                //console.log($scope.allmetrics);
                $scope.wholemetricArray1=[];
                //getting only the intersecting metrics 
                $scope.commmonmetrics= $scope.allmetrics.shift().reduce(function(res, v) {
                                    if (res.indexOf(v) === -1 && $scope.allmetrics.every(function(a) {
                                    return a.indexOf(v) !== -1;
                                    })) res.push(v);
                                    return res;
                                    }, []);
                //console.log($scope.commmonmetrics);
            
                angular.forEach($scope.wholemetricArray, function (value, key) {
                    
                    for(i=0;i<$scope.commmonmetrics.length;i++)
                    {
                        if($scope.commmonmetrics[i]==value.name)
                        {
                            $scope.wholemetricArray1.push(value);
                        }
                    }
                });
                   //call for sample graph data creation 
                   $scope.sampledatacreation();
                    
                }
                else
                {
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                    else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            if(response.data.networkError.message!='' && response.data.networkError.message!=undefined){
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            }else{
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                     $scope.nograph = true;
                }    
            });
        }

        $scope.parenttoggle = false;
        $scope.fetchChildAndPush = function (_id) {
            $rootScope.progressLoader = "block";
            $scope.wholechildArray = [];
         //   console.log($window.localStorage.getItem("userNetworkMapId"));
            queryStr = "userNetworkMapId=" +$window.localStorage.getItem("userNetworkMapId")+ "&" + "parentCampaignId=" + _id;
            $http({
                method: 'GET',
                url: apiTPBase + "/readadcampaign" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log("trying to get child")
                var index = 0;
                if (response.data.appStatus == '0') {
                     $rootScope.progressLoader = "none";

                    $scope.childCampaigns = response.data.adcampaigns;
                    //console.log($scope.childCampaigns)
                    var count = 0;
                    angular.forEach($scope.childCampaigns, function (value, key) {
                        var JsonObj = $scope.childCampaigns[key]
                        var array = [];
                        for (var j in JsonObj) {
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                array[+j] = JsonObj[j];
                                var _obj = {
                                    "id": array[+j].campaignId,
                                    "name": array[+j].campaignDetails.name,
                                    "type": "child",
                                    "parentid": _id,
                                    "usernetworkmapid": $window.localStorage.getItem("userNetworkMapId")
                                }
                                count++;
                                $scope.wholechildArray.push(_obj);
                                //console.log($scope.wholechildArray)

                            }
                        }
                    })

                } else {
                    console.log('readadcampaign failed');
                     $rootScope.progressLoader = "none";
                     if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    };

                }
            });

        }


        $scope.allnetworksforadv = function ()
        {
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + "/user/fetchallnetwork",
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                }
                ;
                if (response.data.appStatus == '0') {
                     $rootScope.progressLoader = "none";
                    $scope.allnetworksarray = response.data.networkList;
                    //getting networks for all account
                        $scope.networksforacc();
                }
                else
                {
                    //failed
                     $rootScope.progressLoader = "none";
                }
            });
        }

        $scope.networksforacc = function ()
        {
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    // success
                    $scope.arr1=[];
                    $scope.networksarrayforacc = response.data.advertiserNetworkList;
      //              console.log($scope.networksarrayforacc);
//                   for (i = 0; i < $scope.networksarrayforacc.length; i++)
//                        {
//                              angular.forEach($scope.advertiserdetails, function (val, key) {
//                              if (val.advertiserEmail == $scope.networksarrayforacc[i].userId)
//                                {
//                                    angular.forEach($scope.allnetworksarray, function (val, key)
//                                    {
//                                        console.log(val.networkUrl);
//                                        if ($scope.networksarrayforacc[i].networkId == val.networkId)
//                                        {
//                                            var obj={
//                                                    "networkname":val.networkName,
//                                                    "networkid":val.networkId,
//                                                    "usernetworkmapid":$scope.networksarrayforacc[i].userNetworkMapId,
//                                                    };
//                                             //removing duplicates    
//                                             if ($scope.arr1.indexOf(obj.networkname) == - 1) {
//                                                        $scope.arr1.push(obj.networkname);
//                                                        $scope.networksarrayforaccount.push(obj);
//                                                     }       
//                                                    
//                                            console.log(obj);
//                                            
//                                    //  $scope.userNetworkMapId = $scope.networksarrayforacc[i].userNetworkMapId;
//                                        }
//                                    });
//                                }
//                            });
//                         }
                   
                   
                   
                   
                    for(i=0;i<$scope.allnetworksarray.length;i++)
                        {
                            var obj = {
                                "networkId":$scope.allnetworksarray[i].networkId,
                                "networkName":$scope.allnetworksarray[i].networkName,
                                "networkURL":$scope.allnetworksarray[i].networkUrl
                                    };
                              //      console.log(obj.networkURL);
                              //      console.log(appSettings.fbNetwork);
                                if(obj.networkURL == appSettings.fbNetwork)
                                {
                                    $scope.networksarrayforaccount.push(obj);
                                }
                        } 
                    $scope.nograph = false;
                 //   console.log($scope.networksarrayforaccount);
                    //getting all user network map ids 
                    $scope.getusernetworkmapids();
                }
                else
                {
                    //failed
                     $scope.nograph = true;
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    };

                }
            });

        }
         $scope.metric_count = 0;
        $scope.show = false;
        $scope.isgraph = false;
        var result = [];
        $scope.disableid = [];
        var pos = 0;
        var map = {};
        $scope.metricselect = [];
        
        $scope.showcampaigns = function ()
        {
        //    console.log($scope.wholeParentArray.length);
            if($scope.wholeParentArray.length!=0)
            {
            $scope.showcamp= false;
            }
            else
            {
              $scope.showcamp= true;
            }
        };
        
        $scope.showmetrics = function ()
        {
            $scope.show = false;
        };
        
        
        $scope.metricselection = function (val)
        {
            $scope.isgraph = true;
            $scope.metric_count++;

           // $scope.plotarray = [];
            //console.log(lastweekdates);
            $scope.show = false;
            var index = $scope.metricselect.indexOf(val.name);
            if (index > -1)
            {
                $scope.metricselect.splice(index, 1);
                delete map[val.name];
                for (i = 0; i < $scope.disableid.length; i++)
                {
                    var _in = $scope.disableid[i];
                    angular.element('#list' + _in).removeClass('disableElement');
                }
            }
            else
            {
                //checking whether metric count exceeded 4 
                if ($scope.metricselect.length == 3)
                {
                    $scope.metricselect.push(val.name);
                    for (var i = 0; i < $scope.metricselect.length; i++) {
                        map[$scope.metricselect[i]] = i;
                    }

                    $scope.disableid = [];
                    //disabling the remaining metrics
                    for (i = 0; i < $scope.wholemetricArray1.length; i++) {
                        if (!($scope.wholemetricArray1[i].name in map)) {

                            $scope.wholemetricArray1[i].disabled = "true";
                            $scope.disableid.push($scope.wholemetricArray1[i].id);
                          //  console.log($scope.wholemetricArray[i])
                        }
                    }
                   // console.log($scope.disableid)
                    for (i = 0; i < $scope.disableid.length; i++)
                    {
                        var _in = $scope.disableid[i];
                        angular.element('#list' + _in).addClass('disableElement');
                    }
                }
                else
                {
                    $scope.metricselect.push(val.name);
                }
            }

            //creating an array for sample data
            $scope.plotarray=[];
            $scope.sampledatacreation();
            
            if($scope.metricselect.length==0)
            {
                //if no metrics are selected
                $scope.nograph=true;
            }
            else
            {
                $scope.nograph=false;
            }
            
        }

        $scope.remove = function (val)
        {
            var index = $scope.metricselect.indexOf(val)
            if (index > -1)
            {
                $scope.metricselect.splice(index, 1);
                for (i = 0; i < $scope.disableid.length; i++)
                {
                    var _in = $scope.disableid[i];
                    angular.element('#list' + _in).removeClass('disableElement');
                }
                delete map[val];

            }
        }
         //sample data creation with metric values
        $scope.metricdatacreation = function(array)
        {
        //    console.log($scope.newgraph);
            //plotting graphs for daily
            
                    if($scope.newgraph=="false")
                    {    
//                        for (var i = 0; i < array.length; i++)
//                        {
                            $scope.plotgraph(array[i])
//                        }
                    }
                    else
                    {
                        for (var i = 0; i < array.length; i++)
                        {
                            $scope.plotnewgraph(array[i])
                        }
                    }   
                    
            $scope.graphinit();
        }
        
        
        
        //sample data creation with zero values
        $scope.sampledatacreation = function()
        {
            $scope.plotarray = [];
            //initialing zero to selected daily-wise metric value
                    if ($scope.breakdown == "DAILY")
                    {
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                            for (var k = 0; k < $scope.displaydate.length; k++)
                            {
//                                for (var j = 0; j < $scope.date.length; j++)
//                                {
////                                console.log($scope.date[j]);
//                                    if ($scope.breakpoints[k] == $scope.date[j])
//                                    {
                                        var obj =
                                                {
                                                    "date": $scope.displaydate[k],
                                                    "metric": $scope.metricselect[i],
                                                    "value": 0
                                                }
                                        $scope.plotarray.push(obj);
//                                        break;
//                                    }
//                                    else
////                                    {
//                                        var obj =
//                                                {
//                                                    "date": $scope.breakpoints[k],
//                                                    "metric": $scope.metricselect[i],
//                                                    "value": 0
//                                                }
//                                        $scope.plotarray.push(obj);
//                                        break;
//                                    }
                                }
                            }
//                        }
                      //  console.log($scope.date);
                        $scope.metricdatacreation($scope.date);

                    }
                     //initialing zero to selected week-wise metric value
                    else if ($scope.breakdown == "WEEKLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.weeknum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for weekly
                         $scope.metricdatacreation($scope.weeknum);
                    }
                    
                    //initialing zero to selected month-wise metric value
                     else if ($scope.breakdown == "MONTHLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.monthnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for monthly
                       $scope.metricdatacreation($scope.monthnum);
                       
                    }
                    
                    //initialing zero to selected quarterly-wise metric value
                     else if ($scope.breakdown == "QUARTERLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.quaternum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for quarterly
                        $scope.metricdatacreation($scope.quaternum);
                        
                    }
                    //initialing zero to selected halfyearly-wise metric value
                     else if ($scope.breakdown == "HALFYEARLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.halfnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for halfyearly
                        $scope.metricdatacreation($scope.halfnum);
                        
                    }
                    //initialing zero to selected yearly-wise metric value
                     else if ($scope.breakdown == "YEARLY")
                    {
                        
                        for (var i = 0; i < $scope.metricselect.length; i++)
                        {
                               angular.forEach($scope.yearnum, function (val, k) {
                                    var obj =
                                            {
                                                "date": val,
                                                "metric": $scope.metricselect[i],
                                                "value": 0
                                            }
                                    $scope.plotarray.push(obj);
                                });
                                
                        }
                        //plotting graphs for yearly
                        $scope.metricdatacreation($scope.yearnum);
                    }
            
         //    console.log($scope.plotarray);
        }

         //get from date , to date
        $scope.selectstartdate = function (val)
        {
            //var iden1=0;
            $scope.enteredfromDate = val;
           //  var _utc = new Date(val.getUTCFullYear(), val.getUTCMonth(), val.getUTCDate(), val.getUTCHours(), val.getUTCMinutes(), val.getUTCSeconds());
            $scope.startdat = $filter('date')(val, 'yyyy-MM-dd');
        //    console.log($scope.startdat);
             if($scope.enteredtoDate!=null && $scope.enteredfromDate!=null && $scope.fromDate != "" && $scope.toDate !="" )
            {
            
                if(new Date($scope.fromDate) <= new Date($scope.toDate))
                {
                    //calculating the date difference
                   datedifference = 0;
                    $scope.breakdown = "";
                    var date = new Date();
                    var hour = date.getHours(); var hour1 = hour > 10 ? '0'+hour : hour;
                    var min = date.getMinutes(); var min1 = min > 10 ? '0'+min : min;
                    var sec = date.getSeconds();  var sec1 = sec > 10 ? '0'+sec : sec;
                    var fromDateTime = $scope.startdat +" "+hour1 +":"+min1+":"+sec1;
                    var toDateTime = $scope.enddat +" "+hour1 +":"+min1+":"+sec1; 
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.currentDate = new Date($scope.UTCFromDate);
                    $scope.toDateNumber = new Date($scope.UTCToDate).getDate();
                    $scope.toMonth = new Date($scope.UTCToDate).getMonth() + 1;
                    $scope.toYear = new Date().getFullYear();
                    $scope.fromDateNumber = new Date($scope.UTCFromDate).getDate();
                    $scope.fromMonth = new Date($scope.UTCFromDate).getMonth() + 1;
                    $scope.fromYear = new Date($scope.UTCFromDate).getFullYear();
                    $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
                    if($scope.monthDiff < 0)
                    {
                        $scope.monthDiff = $scope.monthDiff + 12;
                    }
                    $scope.yearDiff = $scope.toYear - $scope.fromYear;
                    while ($scope.currentDate <= new Date($scope.enddat)){
                        $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                        datedifference = datedifference+1;
                    }
                    if(datedifference >=1 && datedifference <=7)
                    {
                        $scope.breakdown = "DAILY";
                    }
                    else if($scope.yearDiff>=1){
                        $scope.breakdown = "YEARLY";
                    }
                    else if(datedifference>=8 && datedifference<=30 && $scope.monthDiff <= 1){
                        $scope.breakdown = "WEEKLY";
                    }
                    else if(datedifference>=8 && datedifference<=30 && $scope.monthDiff > 1){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if($scope.monthDiff >= 1 && $scope.monthDiff <=3){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if ($scope.monthDiff>3 && $scope.monthDiff <= 6){
                        $scope.breakdown = "QUARTERLY";
                    }
                    else if ($scope.monthDiff > 6  && $scope.monthDiff <=12){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff <2){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff>=2){
                        $scope.breakdown = "YEARLY";
                    }
//                    console.log(datedifference);
//                    console.log($scope.monthDiff);
//                    console.log($scope.enddat);
                    $scope.startdat=$scope.UTCFromDate;
                    $scope.enddat=$scope.UTCToDate;
                
  
              if($scope.selectedcampaign=="" || $scope.selectedcampaign=="Select Campaign" || $scope.selectedcampaign==undefined)
            {
                //no parent/child campaign is selected
                //getting the user network map id of the selected advertiser
                $scope.newgraph ='false';
             //   console.log($scope.newgraph);
                                    
                $scope.selectedusernetmap=  $window.localStorage.getItem("userNetworkMapId");
                                $scope.readadaccountInsights($scope.startdat, $scope.enddat, $scope.breakdown, $scope.selectedusernetmap);
            }
            else
            {                   
                //getting campaign insights for selected date range    
               //checking whether the selected parent has child or not
               
               angular.forEach($scope.wholeParentArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                            angular.forEach($scope.wholechildArray, function (v, key) {
                              if(val.id==v.parentid)
                                  {
                                      //getting insights bypassing child id and usernetwork map id of selected parent
                                        $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,v.id,v.usernetworkmapid);
                                  }
                                  else
                                  {
                                      //selected parent does not have child
                                  }    
                     
                                });     
                    }
                });
                
              //    console.log($scope.selectedcampaign);
                //getting insights of the selected child
                 angular.forEach($scope.wholechildArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                        $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,val.id,val.usernetworkmapid);
                    }
                 
                 });
            }
        } 
         else
        {
                 //invalid date range 
                 $scope.nograph= true;
                 $scope.fromDate="";
                 $scope.toDate="";
         }    
            
            } 
        }

        function localDateTimetoUTCDateTime(date){
            var d = new Date(date);
            var utcDate = d.toUTCString();
            return new Date(utcDate).toISOString().slice(0,10);
        }

        
        $scope.selectenddate = function (val)
        {
         //   var iden1=0;
            $scope.enteredtoDate = val;
         //   var _utc = new Date(val.getUTCFullYear(), val.getUTCMonth(), val.getUTCDate(), val.getUTCHours(), val.getUTCMinutes(), val.getUTCSeconds());
            $scope.enddat = $filter('date')(val, 'yyyy-MM-dd');
             if($scope.enteredtoDate!=null && $scope.enteredfromDate!=null && $scope.fromDate != "" && $scope.toDate !="" )
            {    
                if(new Date($scope.fromDate) <= new Date($scope.toDate))
                {
                 
                    datedifference = 0;
                    $scope.breakdown = "";
                    var date = new Date();
                    var hour = date.getHours(); var hour1 = hour > 10 ? '0'+hour : hour;
                    var min = date.getMinutes(); var min1 = min > 10 ? '0'+min : min;
                    var sec = date.getSeconds();  var sec1 = sec > 10 ? '0'+sec : sec;
                    var fromDateTime = $scope.startdat +" "+hour1 +":"+min1+":"+sec1;
                    var toDateTime = $scope.enddat +" "+hour1 +":"+min1+":"+sec1; 
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.currentDate = new Date($scope.UTCFromDate);
                    $scope.toDateNumber = new Date($scope.UTCToDate).getDate();
                    $scope.toMonth = new Date($scope.UTCToDate).getMonth() + 1;
                    $scope.toYear = new Date().getFullYear();
                    $scope.fromDateNumber = new Date($scope.UTCFromDate).getDate();
                    $scope.fromMonth = new Date($scope.UTCFromDate).getMonth() + 1;
                    $scope.fromYear = new Date($scope.UTCFromDate).getFullYear();
                    $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
                    if($scope.monthDiff < 0)
                    {
                        $scope.monthDiff = $scope.monthDiff + 12;
                    }
                    $scope.yearDiff = $scope.toYear - $scope.fromYear;
                    while ($scope.currentDate <= new Date($scope.enddat)){
                        $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                        datedifference = datedifference+1;
                    }
                    if(datedifference >=1 && datedifference <=7)
                    {
                        $scope.breakdown = "DAILY";
                    }
                    else if($scope.yearDiff>=1){
                        $scope.breakdown = "YEARLY";
                    }
                    else if(datedifference>=8 && datedifference<=30 && $scope.monthDiff <= 1){
                        $scope.breakdown = "WEEKLY";
                    }
                    else if(datedifference>=8 && datedifference<=30 && $scope.monthDiff > 1){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if($scope.monthDiff >= 1 && $scope.monthDiff <=3){
                        $scope.breakdown = "MONTHLY";
                    }
                    else if ($scope.monthDiff>3 && $scope.monthDiff <= 6){
                        $scope.breakdown = "QUARTERLY";
                    }
                    else if ($scope.monthDiff > 6  && $scope.monthDiff <=12){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff <2){
                        $scope.breakdown = "HALFYEARLY";
                    }
                    else if ($scope.monthDiff > 12 && $scope.yearDiff>=2){
                        $scope.breakdown = "YEARLY";
                    }
//                    console.log(datedifference);
//                    console.log($scope.monthDiff);
//                    console.log($scope.enddat);
                    $scope.startdat=$scope.UTCFromDate;
                    $scope.enddat=$scope.UTCToDate;
                
         //   console.log($scope.selectedcampaign);
            if($scope.selectedcampaign=="" || $scope.selectedcampaign=="Select Campaign" || $scope.selectedcampaign==undefined)
            {
                //no parent/child campaign is selected
                //getting the user network map id of the selected advertiser
                $scope.newgraph ='false';
                $scope.selectedusernetmap =  $window.localStorage.getItem("userNetworkMapId");
                //for (i = 0; i < $scope.networkmaparray.length; i++)
                   //     {
                                $scope.readadaccountInsights($scope.startdat, $scope.enddat, $scope.breakdown, $scope.selectedusernetmap);
                    //    }
            }
            else
            {                   
                //getting campaign insights for selected date range    
               //checking whether the selected parent has child or not
               
               angular.forEach($scope.wholeParentArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                            angular.forEach($scope.wholechildArray, function (v, key) {
                              if(val.id==v.parentid)
                                  {
                                      //getting insights bypassing child id and usernetwork map id of selected parent
                                        $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,v.id,v.usernetworkmapid);
                                  }
                                  else
                                  {
                                      //selected parent does not have child
                                  }    
                     
                                });     
                    }
                });
                
              //    console.log($scope.selectedcampaign);
                //getting insights of the selected child
                 angular.forEach($scope.wholechildArray, function (val, key) {
                    if($scope.selectedcampaign==val.name)
                    {
                        $scope.getinsights($scope.startdat, $scope.enddat,$scope.breakdown,val.id,val.usernetworkmapid);
                    }
                 
                 });
            }
            }else
        {
                 //invalid date range 
                 $scope.nograph= true;
                 $scope.fromDate="";
                 $scope.toDate="";
         } 
    } 
 }     
      //readadaccoutnInsights
        $scope.readadaccountInsights = function (fromdate, todate, breakdown, usernetmapid) {
           console.log("getting account insights");
           $scope.breakpoints = [];
           $scope.wholemetricArray = [];
           $scope.grapharray=[];
                     
           if(breakdown == "DAILY")
           {
               $scope.displaydate=[];
               //getting dates between corresponding selected start and end values
                date1 = new Date(fromdate);
                date2 = new Date(todate);
                var day = 1000 * 60 * 60 * 24;
                var diff = (date2.getTime() - date1.getTime()) / day;
                for (var i = 0; i <= diff; i++)
                {
                    var xx = date1.getTime() + day * i;
                    var yy = new Date(xx);
                            
                    var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                    var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                    $scope.breakpoints.push(d2);
                }
              //  console.log($scope.breakpoints);
                for(var i = 0; i <$scope.breakpoints.length; i++)
               {
                    $scope.displaydate.push(new Date($scope.breakpoints[i]).getDate() + "-" + new Date($scope.breakpoints[i]).toLocaleString('en-us', { month: "short" }));
               }
              // console.log($scope.displaydate);
           }
            $rootScope.progressLoader = "block";

            //getting insights for all user network map ids 
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' +  $window.localStorage.getItem("userNetworkMapId")+'&fromDate=' + fromdate + '&toDate=' + todate + '&breakDown=' + breakdown,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //       console.log(response);
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    $scope.nograph=false;
                    $scope.innerarray = [];
                    $scope.weekvalue = [];
                    $scope.weeknum=[];
                    $scope.monthnum=[];
                    $scope.quaternum=[];
                    $scope.halfnum=[];
                    $scope.yearnum=[];
                    $scope.date = [];
                    $scope.wholemetricArray=[];
                    var iden =0;
                    
                    $scope.accountinsights = response.data.adAccountInsights;
                //    console.log($scope.accountinsights);
                    angular.forEach($scope.accountinsights, function (value, key) {
                        var JsonObj = $scope.accountinsights[key]
                        var array = [];
                        
                        for (var j in JsonObj) {
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                $scope.innerarray = JsonObj[j];
                                
                               // console.log($scope.innerarray)
                                //console.log(totalimpressions)
                                
                                //converting timestamp to dates
                                if(breakdown == "DAILY")
                                {    
                                     for (var timestamp in $scope.innerarray)
                                    {
                                        //    console.log(timestamp);
                                           var date = $filter('date')(timestamp, 'yyyy-MM-dd');
                                            $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                    
                                    }
                                 //   console.log($scope.date);
                                }
                                //calculating week number from response
                                else if(breakdown == "WEEKLY")
                                {
                                    for (var weeknum in $scope.innerarray)
                                        {
                                               var parts=weeknum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.weeknum.push(parts);
                                               $scope.getdatesfromweeknum(weekno,year);
                                        }
                                      //   console.log($scope.weeknum);
                                }
                                //calculating month number from response
                                else if(breakdown == "MONTHLY")
                                {
                                    for (var monthnum in $scope.innerarray)
                                        {
                                               var parts=monthnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.monthnum.push(parts);
                                        }
                                }
                                //calculating quarter number from response
                                else if(breakdown == "QUARTERLY")
                                {
                                    for (var quaternum in $scope.innerarray)
                                        {
                                               var parts=quaternum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.quaternum.push(parts);
                                        }
                                }
                                //calculating half-yearly number from response
                                else if(breakdown == "HALFYEARLY")
                                {
                                    for (var halfnum in $scope.innerarray)
                                        {
                                               var parts=halfnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.halfnum.push(parts);
                                        }
                                }
                                //calculating yearly number from response
                                else if(breakdown == "YEARLY")
                                {
                                    for (var yearnum in $scope.innerarray)
                                        {
                                               var parts=yearnum.split('_').join(' ');
                                               var year=parts[1];
                                               $scope.yearnum.push(parts);
                                        }
                                }
                                
                                // traversing into the object to get insights
                                angular.forEach($scope.innerarray, function (value, key) {
                                     var id1 = 1;
                                    
                                    $scope.hasinsightdetails=false;
                                    $scope.wholemetricArray=[];
                                    $scope.wholemetricname=[];
                                    $scope.arrayofobj = [];
                                    $scope.parentmetricarray = [];
                                    $scope.insightsarr = [];
                                    $scope.arr1 = [];
                                    $scope.arr2 = [];
                                    var totalclicks = 0;
                                    var totalimpressions = 0;
                                    var totalspend = 0;
                                    var totalactions = 0;
                                    var t = $scope.innerarray[key];
                                 //   console.log(t)
                                    for (var k1 in t)
                                    {
                                        if (k1 == "clicks")
                                        {
                                            totalclicks+=t.clicks;
                                            var obj = {
                                                "name": k1,
                                                "value": totalclicks,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);

                                        }
                                        if (k1 == "impressions")
                                        {
                                            totalimpressions+=t.impressions;
                                            var obj = {
                                                "name": k1,
                                                "value": totalimpressions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }

                                        if (k1 == "spend")
                                        {
                                             totalspend+=t.spend;
                                            var obj = {
                                                "name": k1,
                                                "value": totalspend,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }
                                        if (k1 == "callToAction")
                                        {
                                            
                                             totalactions+=t.callToAction;
                                            var obj = {
                                                "name": "actions",
                                                "value": totalactions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray.push(obj);
                                            $scope.wholemetricname.push("actions");
                                        }
                                        if (k1 == "insightsDetails")
                                        {
                                            $scope.hasinsightdetails=true;
                                            $scope.insightsarr = t.insightsDetails;
                                            
                                        }
                                    }
                                    //console.log($scope.hasinsightdetails);
                            //        
      //                      if( breakdown == "DAILY")
      //                      {       
                                for (k in $scope.insightsarr)
                                    {
                                        //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                        var obj;
                                        function traverse(jsonObj, category) {
                                            if (typeof jsonObj == "object") {
                                                $.each(jsonObj, function (k, v) {
                                                    if (k == category) {
                                                        if (typeof v == "object")
                                                        {
                                                            angular.forEach(v, function (key1, value1) {
                                                                $scope.arrayofobj.push(key1);
                                                                $scope.parentmetricarray.push(k);
                                                            });
                                                        }
                                                        else
                                                        {
                                                            if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                            {

                                                            }
                                                            else
                                                            {
                                                                var t = 0;
                                                                var newchar = ' '
                                                                k = k.split('_').join(newchar);
                                                                var obj = {
                                                                    "name": k,
                                                                    "value": v,
                                                                    "id": id1++,
                                                                    "disabled": "false"
                                                                }
                                                                $scope.wholemetricArray.push(obj);
                                                                $scope.wholemetricname.push(k);
                                                            }
                                                        }

                                                    } else {
                                                        traverse(v, category);
                                                    }

                                                });
                                            }
                                            else {
                                                // jsonOb is a number or string
                                            }
                                        }
                                        traverse($scope.insightsarr, k)
                                       // console.log(obj)
                                        $scope.keyvalue = obj;
                                    }
                                  //  console.log($scope.arrayofobj);
                                   // console.log($scope.parentmetricarray);
                                    angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                        var parentmetric=$scope.parentmetricarray[value1];
                                                        var childmetric=key1.action_type;
                                                        var newchar = ' '
                                                        parentmetric = parentmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('.').join(newchar);
                                                var obj = {
                                                         "name": parentmetric +" - "+ childmetric,
                                                         "value":key1.value,
                                                         "id": id1++,
                                                         "disabled": "false"
                                                        }
                                            
                                            $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                       //     console.log(obj);
                                          $scope.arr2.push(obj);

                                    });
                                    for (var i = 0; i < $scope.arr2.length; i++) {
                                      // console.log($scope.arr2[i]);
                                        $scope.wholemetricArray.push($scope.arr2[i]);
                                    }
                                       if(breakdown == "DAILY")
                                       {
                                        var obj1 = {
                                            "date": $scope.date[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }
                                        else if(breakdown == "WEEKLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.weeknum[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        
                                        } 
                                        else if(breakdown == "MONTHLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.monthnum[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "QUARTERLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.quaternum[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }  
                                        else if(breakdown == "HALFYEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.halfnum[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "YEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.yearnum[iden++],
                                            "metricobj": $scope.wholemetricArray,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                });
                            }
                        }
                       //  console.log($scope.wholemetricArray);
                    });
                   // console.log($scope.wholemetricArray);
                    //console.log($scope.wholemetricname);
                  //  console.log($scope.grapharray);
                   $scope.plotarray = [];
                   $scope.arr1=[];
                 
                 
                $scope.allmetrics.push($scope.wholemetricname);
                //console.log($scope.allmetrics);
                $scope.wholemetricArray1=[];
                //getting only the intersecting metrics 
                $scope.commmonmetrics= $scope.allmetrics.shift().reduce(function(res, v) {
                                    if (res.indexOf(v) === -1 && $scope.allmetrics.every(function(a) {
                                    return a.indexOf(v) !== -1;
                                    })) res.push(v);
                                    return res;
                                    }, []);
                //console.log($scope.commmonmetrics);
            
                angular.forEach($scope.wholemetricArray, function (value, key) {
                    
                    for(i=0;i<$scope.commmonmetrics.length;i++)
                    {
                        if($scope.commmonmetrics[i]==value.name)
                        {
                            $scope.wholemetricArray1.push(value);
                        }
                    }
                });
                  
                   
                   //call for sample graph data creation 
                   $scope.sampledatacreation();

                } else {//failed
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    };
                        $scope.nograph=true;
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            if(response.data.networkError.message!='' && response.data.networkError.message!=undefined){
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            }else{
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    
                }
            });


        };
        $scope.clear = function()
        {
             $("#sampleChart").empty();
            
        }
        
        $scope.getdatesfromweeknum = function(week,yr)
        {
            var tm = 1000 * 60 * 60 * 24;
            var d = 0;
            do {
                var start = new Date(yr, 0, 1 + d);
                d++
            } while (start.getDay() != 1)

            var sta_dt = new Date(start.getTime() + tm * (week - 1) * 7);
            var end_dt = new Date(sta_dt.getTime() + tm * 6);
            var  sta= $filter('date')(sta_dt, 'yyyy-MM-dd');
            var  end = $filter('date')(end_dt, 'yyyy-MM-dd');
            
            var obj = {
                "weeknum":week,
                 "startdate":sta,
                 "enddate":end
            };
            
            $scope.weekvalue.push(obj);
        }
        
        
        $scope.getlastweekdates = function ()
        {
            //getting last week dates
//            var today = new Date();
//            var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
//            var lastWeekMonth = lastWeek.getMonth() + 1;
//            var lastWeekDay = lastWeek.getDate();
//            var lastWeekYear = lastWeek.getFullYear();
//            var lastWeekDisplay = lastWeekMonth + "/" + lastWeekDay + "/" + lastWeekYear;
//            var lastWeekDisplayPadded = (("0000" + lastWeekYear.toString()).slice(-4) + "-" + ("00" + lastWeekMonth.toString()).slice(-2) + "-" + ("00" + lastWeekDay.toString()).slice(-2));
//
//            $scope.formattedfromdate = $filter('date')(lastWeekDisplayPadded, 'yyyy-MM-dd');
//            $scope.formattedtodate = $filter('date')(today, 'yyyy-MM-dd');

            //console.log($scope.formattedfromdate);
            //console.log($scope.formattedtodate);
            
            var today = new Date();
            $scope.CurDate = today.toISOString().slice(0,10); 
            $scope.formattedtodate = localDateTimetoUTCDateTime(new Date());
            $scope.formattedfromdate = localDateTimetoUTCDateTime(new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000)));
//            console.log($scope.formattedfromdate);
//            console.log($scope.formattedtodate);
            
            $scope.breakdown = "DAILY";
               $scope.selectedusernetmap =  $window.localStorage.getItem("userNetworkMapId");
               $scope.readadaccountInsightsforlastweek($scope.formattedfromdate, $scope.formattedtodate, $scope.breakdown,$scope.selectedusernetmap);
 
            
        };
        
        $scope.checkCurrencyCode = function(_code) {
			//console.log($scope.currencyList);
			angular.forEach($scope.currencyList, function(value, key) {				
				if($scope.currencyList[key].currency == _code){
					//console.log($scope.currencyList[key].currencyCode+" --- "+_code);
					$scope.currencyValue = $scope.currencyList[key].currencyCode;					
					//console.log($scope.currencyValue);
					return $scope.currencyList[key].currencyCode;
					
				}
			});
			
			$scope.currencyCode = $scope.currencyValue;			
		}
        
        
        
        //GETADACCOUNTID

        $scope.readadAccountId = function (usernetmapid) {

            //alert($scope.userNetworkMapId);
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccounts?networkMapId=' +  $window.localStorage.getItem("userNetworkMapId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {
                    // success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {

                        $scope.adaccountid.push(response.data.fbReadAdAccountResponse[key].fbAdAccountId);
                         $scope.currency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                    });
                    
                     $scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                 //   console.log("currency = "+$scope.currency);
                //    console.log("currency = "+$scope.currencyCode);
                    
             
                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    ;
                }
               
               

            });



        };
        //getting all usernetworkmap ids on load
        $scope.getusernetworkmapids = function ()
        {
                $scope.usernetworkmapid=$window.localStorage.getItem("userNetworkMapId");
                $scope.readadAccountId($scope.usernetworkmapid);
            
                    //setting default metrics 
                   if($scope.isgraph==false)
                   {
                       //plot the default graph
                       $scope.metricselect.push("impressions");
                   }
                   else
                   {
                       $scope.metricselect = [];
                   }   
                   
                   //getting insights for last week
                    $scope.getlastweekdates(); 
                    
                   
                    //fetchig parent campaigns
                    $scope.fetchparent();
                    
                    
        }

         $scope.plotgraph = function (date)
        {
            angular.forEach($scope.plotarray, function (v, k1)
            {
                angular.forEach($scope.grapharray, function (value, key) {
                        
                        if (value.date == v.date)
                        {    // account insights dates that have metric object    
                              //  console.log(v.date)
                             //   console.log(value.date)
                                angular.forEach(value.metricobj, function (val, k) {
                                //console.log(val);

                                if (val.name == v.metric )
                                {
                                    //checking whether it is in string or not
                                    if(typeof(val.value)=='string')
                                    {
                                        var tmp=parseFloat(val.value);
                                        v.value += Math.round(tmp);
                                    }
                                    else
                                    {    
                                //         console.log(v.value)
                                       v.value += Math.round(val.value);
                                    }
                               //      console.log(v.value)
                                }
                            });
                        }

                });
            });
           //  console.log($scope.plotarray);
             $scope.samedate=false;
             //if both dates are same , then duplicates the same date object
             if($scope.diffDays==1)
             {
                    $scope.samedate=true;
                    var plotarray2 = [];
                    plotarray2 = $scope.plotarray;
                 //   console.log(plotarray2.length);

                    angular.forEach(plotarray2, function (v, k1)
                    {
                        $scope.plotarray.push(v);
                    });
                //    console.log($scope.plotarray);

             }
             
             $scope.zerocount = 0
             for(var i=0;i<$scope.plotarray.length;i++)
             {
                 if($scope.plotarray[i].value==0)
                 {
                     $scope.zerocount++;
                 }
                if($scope.plotarray.length == $scope.zerocount)
                {
                    $scope.nograph=true;
                }
             }
             
        }
        
            //getting all networks
                $scope.allnetworksforadv();   
            
             
                
              
        
        $scope.plotnewgraph = function (date)
        {
           // console.log($scope.selectedgrapharray);
            angular.forEach($scope.plotarray, function (v, k1)
            {
                angular.forEach($scope.selectedgrapharray, function (value, key) {
                    
                        if (value.date == date)
                        {    // insights dates that have metric object    
                            angular.forEach(value.metricobj, function (val, k) {
                                //console.log(val);

                                if (val.name == v.metric && v.date == date)
                                {
                                     v.value = Math.round (val.value);
                          //          console.log(v.value)
                                }
                            });
                        }
                
                });
            });
           //  console.log($scope.plotarray);
           
           //if both dates are same , then duplicates the same date object
             if($scope.diffDays==1)
             {
                    $scope.samedate=true;
                    var plotarray2 = [];
                    plotarray2 = $scope.plotarray;
                //    console.log(plotarray2.length);

                    angular.forEach(plotarray2, function (v, k1)
                    {
                        $scope.plotarray.push(v);
                    });
                //    console.log($scope.plotarray);

             }
             
             $scope.zerocount = 0
             for(var i=0;i<$scope.plotarray.length;i++)
             {
                 if($scope.plotarray[i].value==0)
                 {
                     $scope.zerocount++;
                 }
                if($scope.plotarray.length == $scope.zerocount)
                {
                    $scope.nograph=true;
                }
             }
        }
        
        $scope.hover = function(el)
        {
      //      console.log(el);
        }

        $scope.graphinit = function ()
        {
          //  console.log($scope.plotarray);
            $scope.values = [];
            angular.forEach($scope.plotarray, function (v, k1)
            {
                $scope.rr =
                        {"month": v.date, "metric": v.metric, "amount": v.value};

                $scope.values.push($scope.rr);

            });
        
         //   console.log($scope.values);
            $scope.colorvalues = [];
            var color = ["#03A9F4", "#FFC107", "#b388ff", "#80cbc4"];
            //console.log($scope.metricselect);

            var tmp = $scope.metricselect[0];
            var tmp1 = $scope.metricselect[1];
            var tmp2 = $scope.metricselect[2];
            var tmp3 = $scope.metricselect[3];

            var color1 = color[0];
            var color2 = color[1];
            var color3 = color[2];
            var color4 = color[3];
            $scope.color = {
            [tmp]: color1,
                    [tmp1]: color2,
                    [tmp2]: color3,
                    [tmp3]: color4,
        }
        //console.log($scope.color);
//            angular.forEach($scope.color, function (v, k1)
//            {
//                console.log(v.metric);
//            });
        //console.log($scope.color);
        //console.log($scope.values);
        plotValues($scope.values, $scope.color);
        };
        
        
        
        function plotValues(val, colourobj) {
            // Sample Data for this Bar chart demo.
            $("#sampleChart").empty();
            var sampleData = val;
            // Defining options for rendering Bar chart.
            var options = {
                id: "1",
                container: {id: "#sampleChart", title: " ", showDataLabels: 'no', titlePos: 24, contextBrush: "no" , width:1110, height:270},
                markerRadius: 3,
                bindings: {x: "month", y: "amount", category: "metric", marker: ''},
                labels: {x: " ", y: " "},
                margin: {top: 30, right: 50, bottom: 30, left: 80},
                scaling: {x: 4, y: 1},
                scaleFormat: {x: "%a - %e", y: " "},
                ticks: {
                    x: 7,
                    y: 7
                },
                axisRange:
                    {
                  y:
                  {
                      min: 0
                  }
                    
                },
                tickerAngle: {x: 0},
                colors: colourobj,
                tooltip: {
                    width: 250,
                    bindings: [{label: $scope.currencyCode, bindWith: "amount"}]
                }
            };

            var bar_graph = cviz.widget.LineChart.Runner(options).graph();

            //Actual function call to render the Bar graph
//            if(val.length==7)
//            {
//               
//                alert("render");
            bar_graph.render(sampleData);
            
           for (var i = 0; ; i++)
                {
                   var a = document.getElementById("sampleChart").children[0];

                            if (document.getElementById("sampleChart").children[0].children[0].children[4].children[i].hasChildNodes())
                            {    
                                document.getElementById("sampleChart").children[0].children[0].children[4].children[i].innerHTML = "<line x1='-200' y1='0' x2='350%' y2='0'></line>";
                            }else
                            {
                                 break;
                            }
                             document.getElementById("sampleChart").children[0].children[0].children[3].setAttribute("transform","translate(0,225)");

                }

        };




//readadaccoutnInsights
        $scope.readadaccountInsightsforlastweek = function (fromdate, todate, breakdown, usernetmapid) {
           console.log("getting account insights");
           $scope.breakpoints = [];
           $scope.wholemetricArray = [];
           $scope.grapharray=[];
                     
           if(breakdown == "DAILY")
           {
               $scope.displaydate=[];
               //getting dates between corresponding selected start and end values
                date1 = new Date(fromdate);
                date2 = new Date(todate);
                var day = 1000 * 60 * 60 * 24;
                var diff = (date2.getTime() - date1.getTime()) / day;
                for (var i = 0; i <= diff; i++)
                {
                    var xx = date1.getTime() + day * i;
                    var yy = new Date(xx);
                            
                    var tmp=yy.getFullYear() + '-' + ('0' + (yy.getMonth() +1)).slice(-2) + '-' + ('0' + yy.getDate()).slice(-2);
                    var d2 = $filter('date')(tmp, 'yyyy-MM-dd');
                    $scope.breakpoints.push(d2);
                }
                
            //    console.log($scope.breakpoints);
                for(var i = 0; i <$scope.breakpoints.length; i++)
               {
                    $scope.displaydate.push(new Date($scope.breakpoints[i]).getDate() + "-" + new Date($scope.breakpoints[i]).toLocaleString('en-us', { month: "short" }));
               }
            //   console.log($scope.displaydate);
           }
            $rootScope.progressLoader = "block";

            //getting insights for all user network map ids 
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' +  $window.localStorage.getItem("userNetworkMapId") +'&fromDate=' + fromdate + '&toDate=' + todate + '&breakDown=' + breakdown,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                   //    console.log(response);
                if (response.data.appStatus == '0') {

                    $scope.nograph=false;
                    $scope.innerarray = [];
                    $scope.weekvalue = [];
                    $scope.weeknum=[];
                    $scope.monthnum=[];
                    $scope.quaternum=[];
                    $scope.halfnum=[];
                    $scope.yearnum=[];
                    $scope.date = [];
                    $scope.wholemetricArray1=[];
                    var iden =0;
                    
                    $scope.accountinsights = response.data.adAccountInsights;
                //    console.log($scope.accountinsights);
                    angular.forEach($scope.accountinsights, function (value, key) {
                        var JsonObj = $scope.accountinsights[key]
                        var array = [];
                        
                        for (var j in JsonObj) {
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                $scope.innerarray = JsonObj[j];
                                
                               // console.log($scope.innerarray)
                                //console.log(totalimpressions)
                                
                                //converting timestamp to dates
                                if(breakdown == "DAILY")
                                {    
                                     for (var timestamp in $scope.innerarray)
                                    {
                                            //console.log(timestamp);
                                           var date = $filter('date')(timestamp, 'yyyy-MM-dd');
                                            $scope.date.push(new Date(date).getDate() + "-" + new Date(date).toLocaleString('en-us', { month: "short" }));
                                    
                                    }
                                   // console.log($scope.date);
                                }
                                //calculating week number from response
                                else if(breakdown == "WEEKLY")
                                {
                                    for (var weeknum in $scope.innerarray)
                                        {
                                               var parts=weeknum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.weeknum.push(parts);
                                               $scope.getdatesfromweeknum(weekno,year);
                                        }
                                      //   console.log($scope.weeknum);
                                }
                                //calculating month number from response
                                else if(breakdown == "MONTHLY")
                                {
                                    for (var monthnum in $scope.innerarray)
                                        {
                                               var parts=monthnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.monthnum.push(parts);
                                        }
                                }
                                //calculating quarter number from response
                                else if(breakdown == "QUARTERLY")
                                {
                                    for (var quaternum in $scope.innerarray)
                                        {
                                               var parts=quaternum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.quaternum.push(parts);
                                        }
                                }
                                //calculating half-yearly number from response
                                else if(breakdown == "HALFYEARLY")
                                {
                                    for (var halfnum in $scope.innerarray)
                                        {
                                               var parts=halfnum.split('_').join(' ');
                                               var year=parts[0];
                                               var weekno=parts[2];
                                               $scope.halfnum.push(parts);
                                        }
                                }
                                //calculating yearly number from response
                                else if(breakdown == "YEARLY")
                                {
                                    for (var yearnum in $scope.innerarray)
                                        {
                                               var parts=yearnum.split('_').join(' ');
                                               var year=parts[0];
                                               $scope.yearnum.push(parts);
                                        }
                                }
                                
                                // traversing into the object to get insights
                                angular.forEach($scope.innerarray, function (value, key) {
                                     var id1 = 1;
                                    
                                    $scope.hasinsightdetails=false;
                                    $scope.wholemetricArray1=[];
                                    $scope.wholemetricname=[];
                                    $scope.arrayofobj = [];
                                    $scope.parentmetricarray = [];
                                    $scope.insightsarr = [];
                                    $scope.arr1 = [];
                                    $scope.arr2 = [];
                                    var totalclicks = 0;
                                    var totalimpressions = 0;
                                    var totalspend = 0;
                                    var totalactions = 0;
                                    var t = $scope.innerarray[key];
                                 //   console.log(t)
                                    for (var k1 in t)
                                    {
                                        if (k1 == "clicks")
                                        {
                                            totalclicks+=t.clicks;
                                            var obj = {
                                                "name": k1,
                                                "value": totalclicks,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray1.push(obj);
                                            $scope.wholemetricname.push(k1);

                                        }
                                        if (k1 == "impressions")
                                        {
                                            totalimpressions+=t.impressions;
                                            var obj = {
                                                "name": k1,
                                                "value": totalimpressions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray1.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }

                                        if (k1 == "spend")
                                        {
                                             totalspend+=t.spend;
                                            var obj = {
                                                "name": k1,
                                                "value": totalspend,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray1.push(obj);
                                            $scope.wholemetricname.push(k1);
                                        }
                                        if (k1 == "callToAction")
                                        {
                                            
                                             totalactions+=t.callToAction;
                                            var obj = {
                                                "name": "actions",
                                                "value": totalactions,
                                                "id": id1++,
                                                "disabled": "false"
                                            }
                                            $scope.wholemetricArray1.push(obj);
                                            $scope.wholemetricname.push("actions");
                                        }
                                        if (k1 == "insightsDetails")
                                        {
                                            $scope.hasinsightdetails=true;
                                            $scope.insightsarr = t.insightsDetails;
                                            
                                        }
                                    }
                                    //console.log($scope.hasinsightdetails);
                            //        
      //                      if( breakdown == "DAILY")
      //                      {       
                                for (k in $scope.insightsarr)
                                    {
                                        //$scope.keyvalue = $scope.getKeyValues($scope.insightsarr, k)
                                        var obj;
                                        function traverse(jsonObj, category) {
                                            if (typeof jsonObj == "object") {
                                                $.each(jsonObj, function (k, v) {
                                                    if (k == category) {
                                                        if (typeof v == "object")
                                                        {
                                                            angular.forEach(v, function (key1, value1) {
                                                                $scope.arrayofobj.push(key1);
                                                                $scope.parentmetricarray.push(k);
                                                            });
                                                        }
                                                        else
                                                        {
                                                            if (k == "clicks" || k == "impressions" || k == "spend" || k =="date_start" || k == "date_stop" || k == "objective" || k== "account_name" || k=="account_id")
                                                            {

                                                            }
                                                            else
                                                            {
                                                                var t = 0;
                                                                var newchar = ' '
                                                                k = k.split('_').join(newchar);
                                                                var obj = {
                                                                    "name": k,
                                                                    "value": v,
                                                                    "id": id1++,
                                                                    "disabled": "false"
                                                                }
                                                                $scope.wholemetricArray1.push(obj);
                                                                $scope.wholemetricname.push(k);
                                                            }
                                                        }

                                                    } else {
                                                        traverse(v, category);
                                                    }

                                                });
                                            }
                                            else {
                                                // jsonOb is a number or string
                                            }
                                        }
                                        traverse($scope.insightsarr, k)
                                       // console.log(obj)
                                        $scope.keyvalue = obj;
                                    }
                                  //  console.log($scope.arrayofobj);
                                   // console.log($scope.parentmetricarray);
                                    angular.forEach($scope.arrayofobj, function (key1, value1) {
                                                        var parentmetric=$scope.parentmetricarray[value1];
                                                        var childmetric=key1.action_type;
                                                        var newchar = ' '
                                                        parentmetric = parentmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('_').join(newchar);
                                                        childmetric = childmetric.split('.').join(newchar);
                                                var obj = {
                                                         "name": parentmetric +" - "+ childmetric,
                                                         "value":key1.value,
                                                         "id": id1++,
                                                         "disabled": "false"
                                                        }
                                            
                                            $scope.wholemetricname.push(parentmetric +" - "+ childmetric);
                                       //     console.log(obj);
                                          $scope.arr2.push(obj);

                                    });
                                    for (var i = 0; i < $scope.arr2.length; i++) {
                                      // console.log($scope.arr2[i]);
                                        $scope.wholemetricArray1.push($scope.arr2[i]);
                                    }
                                       if(breakdown == "DAILY")
                                       {
                                        var obj1 = {
                                            "date": $scope.date[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }
                                        else if(breakdown == "WEEKLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.weeknum[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        
                                        } 
                                        else if(breakdown == "MONTHLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.monthnum[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "QUARTERLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.quaternum[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        }  
                                        else if(breakdown == "HALFYEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.halfnum[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                        else if(breakdown == "YEARLY")
                                        {
                                            var obj1 = {
                                            "date": $scope.yearnum[iden++],
                                            "metricobj": $scope.wholemetricArray1,
                                            "usernetwork":usernetmapid
                                                      }           
                                         $scope.grapharray.push(obj1);
                                        } 
                                });
                            }
                        }
                       //  console.log($scope.wholemetricArray);
                    });
                   // console.log($scope.wholemetricArray);
                    //console.log($scope.wholemetricname);
                  //  console.log($scope.grapharray);
                   $scope.plotarray = [];
                   $scope.arr1=[];
                   //call for sample graph data creation 
                   $scope.sampledatacreation();

                } else {
                    
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && response.errorMessage == 'Access token is invalid or expired') {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    };
                        $scope.nograph=true;
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            if(response.data.networkError.message!='' && response.data.networkError.message!=undefined){
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            }else{
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                }
            });
        };
        
        $scope.resetPopup = function() {
            $scope.editAdsetErrorMsg = 'none';
        }

        
    }]);


//dashboard.directive('tooltip', function(){
//    return {
//        restrict: 'A',
//        link: function(scope, element, attrs){
//            $(element).hover(function(){
//                console.log("on hover");
//                $(element).tooltip('show');
//            }, function(){
//                // on mouseleave
//                $(element).tooltip('hide');
//            });
//        }
//    };
//});



