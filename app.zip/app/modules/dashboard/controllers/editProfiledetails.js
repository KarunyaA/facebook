
dashboard.controller("profiledetailsController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {
        var apiBase = appSettings.apiBase;
        $scope.editprofileform = {}
        $scope.acc_name = {red: false};
        $scope.acc_url = {red: false};
        $scope.acc_poc = {red: false};
        $scope.acc_contact = {red: false};
        $scope.acc_email = {red: false};
        $scope.acc_add = {red: false};
        $scope.acc_logo = {red: false};
        $scope.edit_view = false;
        $scope.edit_profiledetails = function () {
            $scope.edit_view = true;
            angular.element('.is-div-disabled').css('opacity', 1);
            angular.element('.is-div-disabled').css('pointer-events', 'auto');
            angular.element('.is-btn-disabled').css('opacity', 0.9);
            angular.element('.is-btn-disabled').css('pointer-events', 'none');
        }
        $scope.cancelfunc = function()
        {
            angular.element('.is-div-disabled').css('opacity', 0.9);
            angular.element('.is-div-disabled').css('pointer-events', 'none');
            $scope.edit_view = false; 
        }

        $scope.acc_name_empty_check = function (val)
        {
            $scope.accnameempty = false;
            if (val == "" || val == undefined || val == null)
            {
                $scope.acc_name.red = true;
                $scope.accnameempty = true;
            }
            else
            {
                $scope.acc_name.red = false;
                $scope.accnameempty = false;
            }
        }
        $scope.acc_url_empty_check = function (val1)
        {
            $scope.accurlempty = false;
            if (val1 == "" || val1 == undefined || val1 == null)
            {
                $scope.acc_url.red = true;
                $scope.accurlempty = true;
            }
            else
            {
                $scope.acc_url.red = false;
                $scope.accurlempty = false;
            }
            if (!$scope.acccontactempty && !$scope.accpocempty && !$scope.accurlempty &&  !$scope.accaddempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
        }
        $scope.acc_poc_empty_check = function (val)
        {
            $scope.accpocempty = false;
            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_poc.red = true;
                $scope.accpocempty = true;
            }
            else
            {
                $scope.acc_poc.red = false;
                $scope.accpocempty = false;
            }
            if (!$scope.acccontactempty && !$scope.accpocempty && !$scope.accurlempty &&  !$scope.accaddempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
        }
        $scope.acc_contact_empty_check = function (val)
        {
            $scope.acccontactempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_contact.red = true;
                $scope.acccontactempty = true;
            }
            else
            {
                $scope.acc_contact.red = false;
                $scope.acccontactempty = false;
            }
            if (!$scope.acccontactempty && !$scope.accpocempty && !$scope.accurlempty &&  !$scope.accaddempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
        }
        $scope.acc_email_empty_check = function (val)
        {
            $scope.accemailempty = false;
            if (val === "" || val == undefined || val == null)
            {
                $scope.acc_email.red = true;
                $scope.accemailempty = true;
            }
            else
            {
                $scope.acc_email.red = false;
                $scope.accemailempty = false;
            }
            
        }
        $scope.acc_add_empty_check = function (val)
        {

            $scope.accaddempty=false;
           
            if( val==="" || val==undefined || val==null)
            {
               $scope.acc_add.red=true;
               $scope.accaddempty=true;
            }
            else
            {
                $scope.acc_add.red=false;
                $scope.accaddempty=false;
            }  
           
            if (!$scope.acccontactempty && !$scope.accpocempty && !$scope.accurlempty &&  !$scope.accaddempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
        }
        
        $scope.editProfileDetails = function(){
               
            $http({
                method: 'GET',
                url: apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                
                if (response.data.appStatus == '0') {// success
                     console.log(response.data.appStatus);
                    $scope.editprofileform.accountName = response.data.accountFetchResponse.accountName;
                    $scope.editprofileform.accountUrl = response.data.accountFetchResponse.companyUrl;
                    $scope.editprofileform.companyPoc = response.data.accountFetchResponse.companyPoc;
                    $scope.editprofileform.contact = response.data.accountFetchResponse.contact;
                    $scope.editprofileform.email = response.data.accountFetchResponse.email;
                    $scope.editprofileform.address = response.data.accountFetchResponse.address;
                    $scope.tmp_logo=response.data.accountFetchResponse.logoUrl
                } 
            });
        };
        
      
         $scope.getuseruploadfilename = function(element) {
                $scope.$apply(function($scope) {
                if(element.files[0].size<25000)
                {
                    $scope.uploadedfilename = element.files[0];
                    $scope.maxSizeError = false;
                    $scope.acc_logo.red=false;
                }else
                {
                    $scope.maxSizeError = true;
                    $scope.acc_logo.red=true;
                } 
                if (!$scope.acccontactempty && !$scope.accpocempty && !$scope.accurlempty &&  !$scope.accaddempty)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            }
                });
        }; 

        
        
        $scope.editProfileDetails();
        
        $scope.updateprofiledetails = function () {
            var file = $scope.getCompanyLogo;
            var deferred = $q.defer();
            //Upload Logo File Header
            var fd = new FormData();
            fd.append('file', file);
            fd.append('role', 'Account');
            fd.append('id', $window.localStorage.getItem("accountId"));
            fd.append('userId', $window.localStorage.getItem("userId"));
            fd.append('accessToken', $window.localStorage.getItem("accessToken"));

            var uploadConfigHeader = {
                transformRequest: angular.identity,
                headers: {
                    'Content-Type': undefined
                }
            };
            if (typeof (file) == "object") {
                //alert('file');
                 $rootScope.progressLoader = "block";
                apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (logupload) {
                    if (logupload.appStatus == 0) {
                        $scope.uploadSuccessURL = logupload.successMessage;
                        var parameters = {
                            "userId": $window.localStorage.getItem('userId'),
                            "accessToken": $window.localStorage.getItem('accessToken'),
                            "accountId": $window.localStorage.getItem("accountId"),
                            "accountUrl": $scope.editprofileform.accountUrl,
                            "companyPoc": $scope.editprofileform.companyPoc,
                            "contact": $scope.editprofileform.contact,
                            "address": $scope.editprofileform.address,
                            "logoUrl": $scope.uploadSuccessURL
                        }
                        //alert($scope.uploadSuccessURL)
                        apiService.create("/user/updateaccount", parameters).then(function (updateResponse) {
                            if (updateResponse.appStatus == 0)
                            {
                                deferred.resolve(updateResponse);
                                 $rootScope.progressLoader = "none";
                                $scope.message_span = updateResponse.successMessage;
                                $scope.openSuccessPopup();
                                
                            }else
                            {
                                $rootScope.progressLoader = "none";
                                if(updateResponse.errorId==8003)
                                {
                                    var modalApproveReq = $(".account_modalApprove");
                                    $scope.popupMessage="Update failed.Please enter new data for updating";
                                    $scope.alreadyexisterror=true;
                                    $scope.error=false;
                                    $scope.success=false;
                                    modalApproveReq.show();
                                    
                                }else
                                {
                                    $scope.alreadyexisterror=false;
                                    $scope.openErrorPopup();
                                }
                            }
                            $scope.editProfileDetails();
                        },
                                function (updateResponse) {
                                    deferred.reject(updateResponse);
                                });
                        return deferred.promise;
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.openErrorPopup();
                        deferred.resolve(logupload);
                    }
                },
                        function (logupload) {
                            deferred.reject(logupload);
                        });
                return deferred.promise;
            }
            else {
                 $rootScope.progressLoader = "block";
                //alert('test');
                var parameters = {
                    "userId": $window.localStorage.getItem('userId'),
                    "accessToken": $window.localStorage.getItem('accessToken'),
                    "accountId": $window.localStorage.getItem("accountId"),
                    "accountUrl": $scope.editprofileform.accountUrl,
                    "companyPoc": $scope.editprofileform.companyPoc,
                    "contact": $scope.editprofileform.contact,
                    "address": $scope.editprofileform.address,
                    "logoUrl": $scope.tmp_logo
                }
                apiService.create("/user/updateaccount", parameters).then(function (updateResponse) {
                    if (updateResponse.appStatus == 0)
                    {
                        deferred.resolve(updateResponse);
                         $rootScope.progressLoader = "none";
                        $scope.message_span = updateResponse.successMessage;
                        $scope.openSuccessPopup();
                    }else
                            {
                                $rootScope.progressLoader = "none";
                                if(updateResponse.errorId==8003)
                                {
                                    console.log("error");
                                    var modalApproveReq = $(".account_modalApprove");
                                    $scope.popupTitle="Update Profile Details";
                                    $scope.popupMessage="No values have been changed";
                                    $scope.alreadyexisterror=true;
                                    $scope.error=false;
                                    $scope.success=false;
                                    modalApproveReq.show();
                                    
                                }else
                                {   
                                $scope.alreadyexisterror=false;
                                $scope.openErrorPopup();
                                }
                            }
                    deferred.resolve(updateResponse);
                },
                        function (updateResponse) {
                            deferred.reject(updateResponse);
                        });
                return deferred.promise;

            }

        };

        $scope.openSuccessPopup = function()
        {
                        //angular.element($('body').css("overflow-y","hidden"))
			var modalApproveReq = $(".account_modalApprove");// Get the modal Approve req
			$scope.popupTitle="Update Profile Details"
                        $scope.popupMessage="The Profile details is updated successfully!"
                        $scope.success=true;
                        $scope.error=false;
                        modalApproveReq.show();
        }
        
        $scope.openErrorPopup = function()
        {
                        //angular.element($('body').css("overflow-y","hidden"))
			var modalApproveReq = $(".account_modalApprove");// Get the modal Approve req
			$scope.popupTitle="Update Profile Details"
                        $scope.popupMessage=""
                        $scope.error=true;
                        $scope.success=false;
                        modalApproveReq.show();
        }
        
        $scope.successpopup_close = function()
        {
            var modalApproveReq = $(".account_modalApprove");
            modalApproveReq.hide();
            $scope.edit_view = false;
            angular.element('.is-div-disabled').css('opacity', 0.9);
            angular.element('.is-div-disabled').css('pointer-events', 'none');
        }
        

    }]);

dashboard.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                var clean = val.replace(/[^0-9]+/g, '');
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });
            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});
