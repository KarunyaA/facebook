﻿

dashboard.controller("EducationController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
    var vm = this;
    vm.meMarks = false;
    vm.mscMarks = false;
    vm.hscMarks = false;
    vm.sslcMarks = false;
    vm.education = [
        {
            course: "M.E",
            year:"2013 - 2015",
            title: "Computer Science & Engineering",
            institution: "PPG Institute of Technology, Coimbatore",
            board:"Anna University, Chennai",
            theme: "info",
            icon: "graduation‐cap ",
            mark: 8.2,
            max: 10
        },
        {
            course: "M.Sc",
            year: "2008 - 2013",
            title: "Software Systems",
            institution: "Kovai Kalaimagal College of Arts & Science, Coimbatore",
            board: "Bharathiar University, Coimbatore",
            theme: "warning",
            icon: "graduation‐cap ",
            mark: 8.3,
            max: 10
        }
    ];



}]);

