dashboard.controller("AdvertiserDashboardController", ['$rootScope', '$scope','$http', '$state', '$location', 'dashboardService', 'Flash', '$q' ,'$window', 'appSettings', '$timeout','apiService',
function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, appSettings, $timeout, apiService) {  
    
    var vm = this;
    var apiBase = appSettings.apiBase;
    var apiTPBase = appSettings.apiTPBase;
	var apiTwitterBase= appSettings.apiTwitterBase;
    $scope.editAdsetErrorMsg = 'none';
    $rootScope.progressLoader = "block";
    $scope.existingDesc = "" ;
    var FbUrl = appSettings.fbNetwork;
    var FbRedirectUrl = appSettings.FbsyncRedirectUri;
    $scope.bool = [];
    $scope.wholeParentArray = [];
    $scope.wholeArray = [];
    $scope.wholechildArray = [];
    $scope.allnetworksarray = [];
    $scope.networksarrayforadvertiser = [];
    $scope.networkforadv = false;
    $scope.enableText = true;
    $scope.editMode = false;
	$scope.editModeAdv=true;
	$scope.totalCampaigns = 0;
	$scope.facebookCampaigns =0;
	$scope.twitterCampaigns = 0;
	$scope.allCampaigns = [];
    $scope.twAccountspend=0;
    $scope.advadspend = 0;
	$scope.fbAccountspend=0;
    $scope.totalAdvertiser = 0;
	$scope.lastSyncDate = "";
	$scope.lastSyncDateTW ="";
    $scope.currencyList ={};
	
		$scope.loadCurrencyCode = function(){
			$http.get("localData/currencyData.json").success(function (data){
				$scope.currencyList = data.currencyList;
			});
		}

        
$scope.getExpiryTimeandCheck = function(userNetworkMapId){
    console.log('get network AccessToken')
    $http({
        method: 'GET',
        url: apiBase + '/user/readnetworktoken?userNetworkMapId=' + userNetworkMapId,
        headers: {
            'userId': $window.localStorage.getItem("userId"),
            'accessToken': $window.localStorage.getItem("accessToken")
        }
        }).then(function(response) {
            console.log(response);
            var jsonObj = response.data.networkTokenDetails;
            angular.forEach(jsonObj, function(value, key) {
            var JsonObj = jsonObj[key];
            var array = [];
            for (var i in JsonObj) {
                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                    array[+i] = JsonObj[i];
                    var networkDetails = array[+i];
                    console.log(networkDetails.expiryTime);
                    $scope.networkAccessTokenExpiryTime = networkDetails.expiryTime;
                    var expDate = new Date($scope.networkAccessTokenExpiryTime * 1000);
                    console.log('expiredtime :' + expDate);
                    var todayDate = new Date();
                    console.log('Today Date : ' + todayDate);
                    if(todayDate > expDate){
                        console.log("token expired");
                        $scope.networkAccessTokenExpired = true;
                        $scope.synchsuccess = false;  
                    }else{
                        console.log('token not expired');
                        $scope.networkAccessTokenExpired = false;
                        $scope.synchsuccess = true;
                    }
                    $window.localStorage.setItem('networkAccessTokenExpired' , $scope.networkAccessTokenExpired);
                }
            }
        });				
    })
};

$scope.checksync = function (){
    console.log("check if advertiser is synced with fb")
    $scope.userNetworkMapId = $window.localStorage.getItem("userNetworkMapId");
    if($scope.userNetworkMapId == undefined){
        $scope.synchsuccess = false;
    }else{
        $scope.getExpiryTimeandCheck($scope.userNetworkMapId);
    }
};   
   

$scope.getaccountdetails = function(){
     $rootScope.progressLoader = "block";
    $scope.advertiserDetails = {};
        $scope.adverDetails =[];
        $http({
            method: 'GET',
            url: apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
             $rootScope.progressLoader = "none";
            if (response.data.appStatus == '0') {// success

                $scope.accountName = response.data.accountFetchResponse.accountName;
                $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                $scope.downloadAccountLogo($scope.accountLogoUrl); 
                //$scope.getAdvertiserDetails();
                //$scope.fetchCurentPlanDetails();
            } else {// failed

                 if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

            }
        });
}

    $scope.downloadAccountLogo = function(accountLogoUrl){
        var apiImageServer = appSettings.apiImageServer;
        var parameters = {
            'userId': $window.localStorage.getItem("userId"),
            'accessToken': $window.localStorage.getItem("accessToken"),
            "filePaths" : [accountLogoUrl]
        };
        $http({
            method: 'POST',
            url: apiImageServer+'/downloadimages',
            data : parameters,
            headers: {
                'Content-Type': "application/json"
            }
        }).then(function(response) {
            if (response.data.appStatus == '0' && advertiserLogoUrl != undefined) {
                $rootScope.progressLoader = "none";
                //console.log(resp.data.imageContent[advertiserLogoUrl]);
                $scope.accountLogo = response.data.imageContent[$scope.accountLogoUrl];
            }else{
                $rootScope.progressLoader = "none";
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }
        });
    }
    
    $scope.advertiserdatafetch = function(){
        $http({
            method: 'GET',
            url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
            $rootScope.progressLoader = "none";
            if (response.data.appStatus == '0') {// success
                $scope.advertiserdetails = response.data.advDataFetchResponse;
                angular.forEach($scope.advertiserdetails, function (val, key){
                if($scope.advertiserdetails[key].advertiserId == $window.localStorage.getItem("advertiserId")){
                    $scope.advertiserLogoUrl = $scope.advertiserdetails[key].logoUrl;
                    $scope.advertiserDescription = $scope.advertiserdetails[key].description;
					$scope.advertiserDesc =  $scope.advertiserDescription;
					$scope.existingDesc = $scope.advertiserdetails[key].description;
                    $scope.downloadAdvertiserLogo($scope.advertiserLogoUrl)
                }
            });
            $scope.allnetworks();//getting all networks
            $scope.networksforacc();//getting networks for all account
                

            } else {// failed
                    //console.log("failed");
                    //console.log(response);
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
            }
        });
    }

		//--2------------------------------------------------------------------------------------------------------------
		 $scope.allnetworks = function (){
        $http({
            method: 'GET',
            url: apiBase + "/user/fetchallnetwork",
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
            if (response.data.appStatus == '0') {
                //console.log('in all networks')
                $scope.allnetworksarray = response.data.networkList;
				 $scope.networksforacc();//getting networks for all account
            } else {
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }
        });
    }
		
		
		//--2------------------------------------------------------------------------------------------------------------
		
		//--4-----------------------------------------------------------------------------------------------------------
		$scope.checkNetworkforadvertiser = function (){
		
        $scope.networkforadv = true;
        $scope.networksarrayforadvertiser = [];
		console.log($scope.networksarrayforacc);
		console.log($scope.advertiserdetails);
		console.log($scope.allnetworksarray);
		
        for (i = 0; i < $scope.networksarrayforacc.length; i++){
            angular.forEach($scope.advertiserdetails, function (val, key) {
                if ($window.localStorage.getItem("advertiserId") == val.advertiserId){
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        $scope.networkid = $scope.networksarrayforacc[i].networkId;
                        angular.forEach($scope.allnetworksarray, function (val, key){
                            if ($scope.networkid == val.networkId){
                                $scope.networksarrayforadvertiser.push(val);
                                $scope.userNetworkMapId = $scope.networksarrayforacc[i].userNetworkMapId;
								//console.log('checkNetworkforadvertiser 2' )
								if(val.networkUrl == appSettings.fbNetwork) {
									$scope.readFBadAccounts($scope.userNetworkMapId);
								}
								if(val.networkUrl == appSettings.twNetwork) {
									$scope.readTWadAccounts($scope.userNetworkMapId);
								}
                                
                            }
                        });
                        
                        
                    }
                }
            });
        }
        
        
    }
	 //--4-----------------------------------------------------------------------------------------------------------
	 
	 //--15---------------------------
	 $scope.getAllFBCampaigns = function(wholeParentArray) {
     var promises = [];
     var parentCampaign = [];
     angular.forEach(wholeParentArray, function(val, key) {
        parentCampaign.push(val.id)
     });
     if($window.localStorage.getItem("userNetworkMapId") != "" && $window.localStorage.getItem("userNetworkMapId") != undefined)
     {
     for (var j = 0; j < parentCampaign.length; j++) {
         (function(j) {            
             $rootScope.progressLoader = "block";
			var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "parentCampaignId=" + parentCampaign[j];
             var module = "/readadcampaign" + "?" + queryStr
             var header = {
                 headers: {
                     'userId': $window.localStorage.getItem("userId"),
                     'accessToken': $window.localStorage.getItem("accessToken")
                 }
             };
             promises.push(apiService.getTp(module, header).then(function(response) {
				 
                 if (response.appStatus == 0) {
                     $rootScope.progressLoader = "none";
                     // success
                     $scope.fbCampaigndetails = response.adcampaigns;
					 $scope.facebookCampaigns += $scope.fbCampaigndetails.length;
//                                         console.log(parentCampaign[j],$scope.fbCampaigndetails.length);
//                                         console.log($scope.facebookCampaigns);
					 //console.log($scope.facebookCampaigns);
                   //  $scope.facebookCampaigns.push($scope.fbCampaigndetails.length);

                 } else {
                     //failed 
                     if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                         $window.localStorage.setItem("TokenExpired", true);
                         $state.go('login');
                     } else {
                         $rootScope.progressLoader = "none";
                         $scope.editAdsetErrorMsg = 'block';
                     }

                     $rootScope.progressLoader = "none";
                 }

             }));

         })(j);


     }
     }
     $q.all(promises).finally(
         function() {
          if(promises.length == parentCampaign.length){
				$scope.getAllCampaigns()
			}

         }); 
 }
	 
	 
	 //--15---------------------------
		//--14---------------------------
			  $scope.getAllTWCampaigns = function(wholeParentArray) {
     var promises = [];
     var parentCampaign = [];
     angular.forEach(wholeParentArray, function(val, key) {
        parentCampaign.push(val.id)
     });
     if($window.localStorage.getItem("twUserNetworkMapId") != "" && $window.localStorage.getItem("twUserNetworkMapId") != undefined)
     {
     for (var j = 0; j < parentCampaign.length; j++) {
         (function(j) {            
             $rootScope.progressLoader = "block";
			var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "parentCampaignId=" + parentCampaign[j];
             var module = apiTwitterBase+"/readcampaign" + "?" + queryStr
             var header = {
                 headers: {
                     'userId': $window.localStorage.getItem("userId"),
                     'accessToken': $window.localStorage.getItem("accessToken")
                 }
             };
             promises.push(apiService.getTwitterPoint(module, header).then(function(response) {
				 
                 if (response.appStatus == 0) {
                     $rootScope.progressLoader = "none";
                     // success
                     $scope.campaigndetails = response.campaign;   
					 $scope.twitterCampaigns += $scope.campaigndetails.length;					 
					// $scope.twitterCampaigns.push($scope.campaigndetails.length);

                 } else {
                     //failed 
                     if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                         $window.localStorage.setItem("TokenExpired", true);
                         $state.go('login');
                     } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                     }

                     $rootScope.progressLoader = "none";
                 }

             }));

         })(j);


     }
     }
     $q.all(promises).finally(
         function() {
            if(promises.length == parentCampaign.length){
				$scope.getAllCampaigns()
			}

         }); 
 }
		
		//--14---------------------------
		//--13---------------------------
		
			$scope.selectadvertiser = function (){
        $scope.wholeParentArray = [];
        $http({
            method: 'GET',
            url: apiBase + '/user/fetchparentcampaignsbyadvertiser?advertiserId=' + $window.localStorage.getItem("advertiserId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
            if (response.data.appStatus == '0') {// success
                $scope.campaigndetails = response.data.parentCampaigns;
                for (var i = 0; i < $scope.campaigndetails.length; i++) {
                    var _obj = {
                        "id": $scope.campaigndetails[i].parentCampaignId,
                        "name": $scope.campaigndetails[i].parentCampaignName,
                        "type": "parent"
                    }
                    $scope.wholeParentArray.push(_obj);
					$window.localStorage.setItem("parentID", $scope.campaigndetails[$scope.campaigndetails.length-1].parentCampaignId);
					if(i == ($scope.campaigndetails.length-1)){
						//console.log(i +" :*********************************: "+$scope.campaigndetails.length);
					}
					
                }
				
				$scope.getAllTWCampaigns($scope.wholeParentArray);
				$scope.getAllFBCampaigns($scope.wholeParentArray);
                
            }
            else {// failed
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

            }
        });
    }
		
	 
		//--13----------------------------
		//--12--------------------------
		
		$scope.fetchPlanDetails = function(noOfAdvertisers,planId){
        $http({
            method: 'GET',
            url: apiBase + '/user/fetchplandetails',
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
            
            if (response.data.appStatus == '0') {
                $rootScope.progressLoader = "none";
                $scope.planDetailsResponse = response.data.planDetailsResponse;
                angular.forEach($scope.planDetailsResponse, function(value, key) {
                    if(planId == value.planId){
                        $scope.totalAdvertiser = minTwoDigits(value.maxNoAccounts);
                        $scope.currentPlan = planId;
                    }
                });
                angular.element($("#accountDashboardHeader .btnAddNewOpsTeam").prop("disabled",false));
                if(noOfAdvertisers >= $scope.totalAdvertiser){
                    angular.element($("#accountDashboardHeader .btnAddNewOpsTeam").prop("disabled",true));
                }
                if(noOfAdvertisers == $scope.totalAdvertiser){
                    $scope.progressBarValue = "100";
                    angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                }
                else if(noOfAdvertisers == ($scope.totalAdvertiser/2)){
                    $scope.progressBarValue = "50";
                    angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                }
                else if(noOfAdvertisers < ($scope.totalAdvertiser/2)){
                    $scope.progressBarValue = "30";
                    angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                }
                else if(noOfAdvertisers > ($scope.totalAdvertiser/2)){
                    $scope.progressBarValue = "70";
                    angular.element($(".progress-bar").css("width",$scope.progressBarValue+"%"));
                }
            }
        });
    }
		
		//--12--------------------------
		
		
		//--11--------------------------
		$scope.fetchCurentPlanDetails = function(){
			//alert('fetchCurentPlanDetails')
        $http({
            method: 'GET',
            url: apiBase + '/user/fetchcurrentplan',
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
			//console.log(response);
            if (response.data.appStatus == '0') {// success
                //console.log("success fetch plan");
                $rootScope.progressLoader = "none";
                $scope.noofAdvertiser = minTwoDigits(response.data.noOfAdvertisers);
                $scope.planId = response.data.currentPlanResponse[0].planId;
                $scope.paymentId = response.data.currentPlanResponse[0].paymentId; 
                $scope.planStartDateTime = response.data.currentPlanResponse[0].subscriptionStartDate;
                $scope.planEndDateTime = response.data.currentPlanResponse[0].subscriptionEndDate;
                var planStartDate = $scope.planStartDateTime.split(" ");
                var planEndDate = $scope.planEndDateTime.split(" "); 


                var today1 = new Date();
                var dd = today1.getDate();
                var mm = today1.getMonth()+1; //January is 0! 
                var yyyy = today1.getFullYear();
                if(dd<10){dd='0'+dd} 
                if(mm<10){mm='0'+mm} 
                today1 = yyyy+'-'+mm+'-'+dd;    



                var currentDate = new Date(today1);  //alert(planStartDate[0]);
                var planEndDateval = new Date(planStartDate[0]); //alert(planEndDateval); alert(currentDate);
                var diffDays = parseInt((planEndDateval - today1) / (1000 * 60 * 60 * 24)); 

                //var diffDays = $scope.daysBetween(planEndDate[0], today1);

               // alert(diffDays)
                $scope.isEditPlanDate = false;
                $scope.isEditPlanDatelabel = true;
                var diffDays = 10;
               if(diffDays <= 3){
                    $scope.isEditPlanDetails = true;
                    $scope.isEditPlanDate = true;
                    $scope.isEditPlanDatelabel = false;
                    $scope.planStartDateval = {};
                    $scope.planEndDateval = {};
                    var today = new Date();
                    var dd = today.getDate();
                    var mm = today.getMonth()+1; //January is 0! 
                    var yyyy = today.getFullYear();
                    if(dd<10){dd='0'+dd} 
                    if(mm<10){mm='0'+mm} 
                    today = yyyy+'-'+mm+'-'+dd;


                    var futureOneMonth = new Date();
                    var dd1 = futureOneMonth.getDate()+1;
                    var mm1 = futureOneMonth.getMonth()+2; //January is 0! 
                    var yyyy1 = futureOneMonth.getFullYear();
                    if(dd1<10){dd1='0'+dd1} 
                    if(mm1<10){mm1='0'+mm1} 
                    futureOneMonth = yyyy1+'-'+mm1+'-'+dd1;
                    document.getElementById("planStartDate").setAttribute("max", today);
                    document.getElementById("planStartDate").setAttribute("min", today);
                    $scope.planStartDateval = {
                        //value: new Date(changeDateFormat(planStartDate[0]))
                        value: new Date(today)
                    };
                    //var dt = new Date();
                    //console.log(add_months(dt, 1).toString());
                    $scope.planEndDateval = {
                        value:new Date(futureOneMonth)
                    };
                    document.getElementById("planEndDate").setAttribute("max", futureOneMonth);
                    document.getElementById("planEndDate").setAttribute("min", futureOneMonth);
               }
               else{
                   $scope.isEditPlanDate = false;
                   $scope.isEditPlanDetails = false;
                   $scope.isEditPlanDatelabel = true;
                   $scope.planStartDateval = planStartDate[0];
                   $scope.planEndDateval = planEndDate[0];
               }
               if(diffDays <= 5){
                   $scope.isPlanExpNotification = true;
               }
               else{
                   $scope.isPlanExpNotification = false;
               }
               $scope.fetchPlanDetails(response.data.noOfAdvertisers,$scope.planId);

            } else {// failed
                //console.log("failure fetch plan");
            }
			$window.localStorage.setItem("planEndDate", planEndDate[0]);
        });
    }
	 
		//--11--------------------------
		
		//--10--------------------------
		
		  $scope.downloadAccountLogo = function(accountLogoUrl){
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths" : [accountLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer+'/downloadimages',
                data : parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function(resp) {
                 $scope.accountLogo = resp.data.imageContent[$scope.accountLogoUrl];
            });
        }
		
		//--10--------------------------
	 
	 
		//--9---------------------
		 $scope.getaccountdetails = function(){
			$rootScope.progressLoader = "block";
			$scope.advertiserDetails = {};
            $scope.adverDetails =[];
            $http({
                method: 'GET',
                url: apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                 $rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') {// success
                    
                    $scope.accountName = response.data.accountFetchResponse.accountName;
                    $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                    $scope.downloadAccountLogo($scope.accountLogoUrl); 
                    //$scope.getAdvertiserDetails();
                    //$scope.fetchCurentPlanDetails();
                } else {// failed
                    
                     if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    
                }
            });
    }
		//--9---------------------
		//--8---------------------
		$scope.readTWaccoutnInsights = function(){
      
		var promises= [];		
		var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&adAccountId=' + $window.localStorage.getItem("twNetworkAdAccountId");
             var module = apiTwitterBase+"/readadaccountsinsights" + "?" + queryStr
             var header = {
                 headers: {
                     'userId': $window.localStorage.getItem("userId"),
                     'accessToken': $window.localStorage.getItem("accessToken")
                 }
             };
             promises.push(apiService.getTwitterPoint(module, header).then(function(response) {
                
                if (response.appStatus == 0) {                 
                    angular.forEach(response.adAccountInsights, function (value, key) {                        
                        if(response.adAccountInsights[key][$scope.twadaccountid].spend!==0){
                            $scope.twAccountspend = response.adAccountInsights[key][$scope.twadaccountid].spend;
                            //$scope.getAllCampaignSpend();
                        }else{
                            $scope.twAccountspend=0;
                        }
                    });

                } else {
                     //failed 
                     if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                         $window.localStorage.setItem("TokenExpired", true);
                         $state.go('login');
                     } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                     }

                     $rootScope.progressLoader = "none";
                }

             }));
			 $q.all(promises).finally(
			 function() {
			  
			 }); 
	}
		
		//--8---------------------
	 
		//--7---------------------
		 $scope.readFBaccoutnInsights = function () {
            $scope.accountsadvoverall = true;
            var overall = "overall";
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' + $window.localStorage.getItem("userNetworkMapId") + '&adAccountId=' + $window.localStorage.getItem("networkAdAccountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    angular.forEach(response.data.adAccountInsights, function (value, key) {
						 
                        $scope.adadvimpressions = response.data.adAccountInsights[key][$scope.fbadaccountid].impressions;
                        $scope.adadvclicks = response.data.adAccountInsights[key][$scope.fbadaccountid].clicks;
                        if(response.data.adAccountInsights[key][$scope.fbadaccountid].spend!==0){
                            $scope.fbAccountspend = response.data.adAccountInsights[key][$scope.fbadaccountid].spend;
                            //$scope.getAllCampaignSpend();
                        }else{
                            $scope.fbAccountspend=0;
                        }
                        $scope.advcallToAction = response.data.adAccountInsights[key][$scope.fbadaccountid].callToAction;
                    });
                    
                    
                } else {
                    
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });
            
        };
    
		
		//--7---------------------
		
		
		//--5---------------------
		
		$scope.readFBadAccounts = function(networkMapID) {
		$rootScope.progressLoader = "block";
        var promises = [];
        
        //FOR FB
        $http({
            method: 'GET',
            url: appSettings.apiTPBase + '/readadaccounts?networkMapId=' + networkMapID,
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
			console.log(response);
            if (response.data.appStatus == '0') {// success
                $rootScope.progressLoader = "none";
				var array = [];
				var JsonObj = response.data.fbReadAdAccountResponse;
				for (var i in JsonObj) {
					if (JsonObj.hasOwnProperty(i)) {
						array[+i] = JsonObj[i];
						console.log(array[+i]);
					}
				}
                angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {
                    var lastSyncDate = response.data.fbReadAdAccountResponse[key].modifiedOn;                        
                    $scope.lastSyncDate = lastSyncDate; 
                    console.log($scope.lastSyncDate);
                    $scope.fbadaccountid = response.data.fbReadAdAccountResponse[key].fbAdAccountId;
                    //alert($scope.fbadaccountid);
                    $scope.fbcurrency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                    angular.forEach($scope.currencyList, function(value, key) {
                        if($scope.currencyList[key].currency == $scope.fbcurrency){
                            $scope.fbcurrencyCode = $scope.currencyList[key].currencyCode;
                        }
                    });
                    $scope.readFBaccoutnInsights();
                });
                 //$scope.currencyCode1 = $scope.checkCurrencyCode($scope.fbcurrency);
                 
            } else {// failed
                $rootScope.progressLoader = "none";
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

            }
            
        });
	}
	//--5---------------------	
	
	//--6---------------------	
		$scope.readTWadAccounts = function (networkMapID) {        
        $rootScope.progressLoader = "block";
        var promises = [];
        //FOR TW
        $http({
            method: 'GET',
            url: appSettings.apiTwitterBase + '/readadaccounts?userNetworkMapId=' + $window.localStorage.getItem("twUserNetworkMapId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
            if (response.data.appStatus == '0') {// success
                $rootScope.progressLoader = "none";
                
                angular.forEach(response.data.adAccounts, function (value, key){
                    var JsonObj1 = response.data.adAccounts[key];
                    var array = [];          
                    for(var kk in JsonObj1) {
                        var lastSyncDate =JsonObj1[kk].modifiedOn;
                        $scope.lastSyncDateTW = lastSyncDate;
                        $scope.twadaccountid = JsonObj1[kk].twAdAccountId;
                        $scope.readTWaccoutnInsights();
                        var module1 = '/readadfundinginstruments?userNetworkMapId=' + $window.localStorage.getItem("twUserNetworkMapId");
                        var header1 = {
                            headers: {
                                'userId': $window.localStorage.getItem("userId"),
                                'accessToken': $window.localStorage.getItem("accessToken")
                            }
                        };
                        promises.push(apiService.getTwr(module1,header1).then(function(res){
                            angular.forEach(res.fundingInstruments, function(v, k){
                                var JsonObj = res.fundingInstruments[key];
                                var array = [];          
                                for(var twi in JsonObj) {
                                    $scope.twcurrency = JsonObj[twi].twFundingInstrumentDetails.currency;
                                    //$scope.currencyCode1 = $scope.checkCurrencyCode($scope.twcurrency);
                                    angular.forEach($scope.currencyList, function(value, key) {
                                        if($scope.currencyList[key].currency == $scope.twcurrency){
                                            $scope.twcurrencyCode = $scope.currencyList[key].currencyCode;
                                        }
                                    });
                                }
                            });


                        }));
                    }

                });     
                 
            } else {// failed
                $rootScope.progressLoader = "none";
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

            }
            
        });
        
        
    };
	//--6---------------------
		
	//--3-----------------------------------------------------------------------------------------------------------
    //FETCHADVERTISERNETWORK
    $scope.networksforacc = function (){
        $http({
            method: 'GET',
            url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
			console.log(response);
            if (response.data.appStatus == '0') {// success
				
                $scope.networksarrayforacc = response.data.advertiserNetworkList;
              
                for (i = 0; i < $scope.networksarrayforacc.length; i++){
                    angular.forEach($scope.allnetworksarray, function (val, key){
                        if ($scope.networksarrayforacc[i].networkId == val.networkId){
                            $scope.networksarrayforadvertiser.push(val);
                        }
                    });
					if(i==1) {
						 $scope.checkNetworkforadvertiser();
					}
                }
				
            } else {
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }
        });
    }
		//--3-----------------------------------------------------------------------------------------------------------
		
		
		//--1-----------------------------------------------------------------------------------------------------------
		$scope.advertiserdatafetch = function(){
			
        $http({
            method: 'GET',
            url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
            $rootScope.progressLoader = "none";
            if (response.data.appStatus == '0') {// success
                $scope.advertiserdetails = response.data.advDataFetchResponse;
                angular.forEach($scope.advertiserdetails, function (val, key){
                if($scope.advertiserdetails[key].advertiserId == $window.localStorage.getItem("advertiserId")){
                    $scope.advertiserLogoUrl = $scope.advertiserdetails[key].logoUrl;
                    $scope.advertiserDescription = $scope.advertiserdetails[key].description;
					$scope.advertiserDesc =  $scope.advertiserDescription;
					$scope.existingDesc = $scope.advertiserdetails[key].description;
                    $scope.downloadAdvertiserLogo($scope.advertiserLogoUrl)
                }
            });
            $scope.allnetworks();//getting all networks
           
                

            } else {
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
            }
        });
    }
		//--1-----------------------------------------------------------------------------------------------------------
		
		
		
		
		
		

        
$scope.getExpiryTimeandCheck = function(userNetworkMapId){
    //console.log('get network AccessToken')
    $http({
        method: 'GET',
        url: apiBase + '/user/readnetworktoken?userNetworkMapId=' + userNetworkMapId,
        headers: {
            'userId': $window.localStorage.getItem("userId"),
            'accessToken': $window.localStorage.getItem("accessToken")
        }
        }).then(function(response) {
            //console.log(response);
            var jsonObj = response.data.networkTokenDetails;
            angular.forEach(jsonObj, function(value, key) {
            var JsonObj = jsonObj[key];
            var array = [];
            for (var i in JsonObj) {
                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                    array[+i] = JsonObj[i];
                    var networkDetails = array[+i];
                    //console.log(networkDetails.expiryTime);
                    $scope.networkAccessTokenExpiryTime = networkDetails.expiryTime;
                    var expDate = new Date($scope.networkAccessTokenExpiryTime * 1000);
                    //console.log('expiredtime :' + expDate);
                    var todayDate = new Date();
                    //console.log('Today Date : ' + todayDate);
                    if(todayDate > expDate){
                        //console.log("token expired");
                        $scope.networkAccessTokenExpired = true;
                        $scope.synchsuccess = false;  
                    }else{
                        //console.log('token not expired');
                        $scope.networkAccessTokenExpired = false;
                        $scope.synchsuccess = true;
                    }
                    $window.localStorage.setItem('networkAccessTokenExpired' , $scope.networkAccessTokenExpired);
                }
            }
        });				
    })
};

$scope.checksync = function (){
    //console.log("check if advertiser is synced with fb")
    $scope.userNetworkMapId = $window.localStorage.getItem("userNetworkMapId");
    if($scope.userNetworkMapId == undefined){
        $scope.synchsuccess = false;
    }else{
        $scope.getExpiryTimeandCheck($scope.userNetworkMapId);
    }
};   
    
   
    $scope.downloadAccountLogo = function(accountLogoUrl){
        var apiImageServer = appSettings.apiImageServer;
        var parameters = {
            'userId': $window.localStorage.getItem("userId"),
            'accessToken': $window.localStorage.getItem("accessToken"),
            "filePaths" : [accountLogoUrl]
        };
        $http({
            method: 'POST',
            url: apiImageServer+'/downloadimages',
            data : parameters,
            headers: {
                'Content-Type': "application/json"
            }
        }).then(function(response) {
            if (response.data.appStatus == '0' && $scope.advertiserLogoUrl != undefined) {
                $rootScope.progressLoader = "none";
                //console.log(resp.data.imageContent[advertiserLogoUrl]);
                $scope.accountLogo = response.data.imageContent[$scope.accountLogoUrl];
            }else{
                $rootScope.progressLoader = "none";
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }
        });
    }
    
   
    
   
   
    
    
    
    $scope.checkCurrencyCode = function(_code) {
        //console.log(_code);
        angular.forEach($scope.currencyList, function(value, key) {				
            if($scope.currencyList[key].currency == _code){
                //console.log($scope.currencyList[key].currencyCode+" --- "+_code);
                $scope.currencyValue = $scope.currencyList[key].currencyCode;					
                //console.log($scope.currencyValue);
                return $scope.currencyList[key].currencyCode;
            }
        });			
        $scope.currencyCode = $scope.currencyValue;
        //console.log($scope.currencyCode);
    }
	
	
    
    
    
    

    $scope.getAllCampaigns= function(){
        $scope.totalCampaigns = $scope.twitterCampaigns+$scope.facebookCampaigns;
    }
  
 
	
	 $scope.fetchTWChildAndPush = function (_id){
        $scope.twChildCampaignArray = [];
         queryStr = "userNetworkMapId=" + $window.localStorage.getItem('twUserNetworkMapId') + "&" + "parentCampaignId=" + _id
			
        $http({
            method: 'GET',
            url: apiTwitterBase + "/readcampaign" + "?" + queryStr,
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function (response) {
			//console.log(response.data.campaign);
            var index = 0;
            if (response.data.appStatus == '0'){
                $scope.twChildCampaigns = response.data.campaign;
				var obj = {
					"id":_id,
					"total":$scope.twChildCampaigns.length
				}
				$scope.allCampaigns.push(obj);
                var count = 0;
                angular.forEach($scope.twChildCampaigns, function (value, key) {
                    var JsonObj = $scope.twChildCampaigns[key]
                    var array = [];
					//console.log(JsonObj);
                    for (var j in JsonObj) {
                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                            array[+j] = JsonObj[j];
                            var _obj = {
                                "id": array[+j].twCampaignId,
                                "name": array[+j].twCampaignDetails.name,
                                "type": "child",
                                "parentid": _id
                            }
							
							//$scope.twitterCampaigns++;
                            count++;
                           $scope.twChildCampaignArray.push(_obj);
                            
                        }
                    }
					if(($scope.twChildCampaigns.length-1) == key){
						//console.log("Twitter "+$scope.twChildCampaignArray.length);
						$scope.getCampaignTotal();
					} 
					
                });
               
            } else {
                //console.log('readadcampaign failed');
                if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editAdsetErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                        $scope.errorMsg = response.data.networkError.error_user_msg;
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }
        });
    }

    $scope.getCampaignTotal = function(){
		 $scope.totalCampaigns = $scope.wholechildArray.length+$scope.twChildCampaignArray.length;
		
	}

	$scope.getAllCampaignSpend = function(){
		 $scope.advadspend = $scope.twAccountspend+$scope.fbAccountspend;
	}
  
	
   
    
    
      function minTwoDigits(n) {
                return (n < 10 ? '0' : '') + n;
            }
    
    
    
    
    
    
    
    
        $scope.fetchhistoryplandetails = function(){
                $http({
                    method: 'GET',
                    url: apiBase + '/user/fetchhistoricplandetails ',
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                }).then(function(response) {
                    if (response.data.appStatus == '0') {
                        $rootScope.progressLoader = "none";
                        $scope.prevPlanDetails = "block";
                        $scope.prevPlanDetailsErrormsg = "none";
                        $scope.previousPlanDetails = response.data.fetchHistoricPlanDetailsResponse;
                        $scope.startDateTime = response.data.fetchHistoricPlanDetailsResponse.subscriptionStartDate;
                      //$scope.startDate = $scope.startDateTime[0];
                        //console.log($scope.startDate);
                    }
                    else{
                        $scope.prevPlanDetailsErrormsg = "block";
                        $scope.prevPlanDetails = "none";
                        $scope.prevPlanErrorHeading = "Error Message";
                        $scope.prevPlanErrorMsg = response.data.errorMessage;
                    }
                });
            }
            $scope.closePrevPlanDetails = function(){
                $scope.prevPlanDetails = "none";
                $scope.prevPlanDetailsErrormsg = "none";
                $scope.editAdsetErrorMsg = "none";
            }
      
        $scope.downloadAdvertiserLogo = function(advertiserLogoUrl){
            $scope.advertiserLogo = [];
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths" : [advertiserLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer+'/downloadimages',
                data : parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function(response) {
                if (response.data.appStatus == '0' && advertiserLogoUrl != undefined) {
                    $rootScope.progressLoader = "none";
                    //console.log(resp.data.imageContent[advertiserLogoUrl]);
                    $scope.advertiserLogo = response.data.imageContent[advertiserLogoUrl];
                }else{
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
                
            });
        }

        $scope.getAdvertiserDetails = function(){
            //$rootScope.progressLoader = "block";
            $scope.accountId = $window.localStorage.getItem("accountId");
            $http({
                method: 'GET',
                url: apiBase + '/user/advertiserdatafetch?accountId='+$scope.accountId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                //alert(response.data.advDataFetchResponse);
                $rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') {// success
                    $scope.advertiserDetails = response.data.advDataFetchResponse;
                    //$scope.advertiserDesc = response.data.advDataFetchResponse[0].description;
                    //$scope.advertiserLogoUrl = response.data.advDataFetchResponse[0].logoUrl;
                    //$scope.downloadAdvertiserLogo($scope.advertiserLogoUrl);


                } else {// failed
                        //console.log("failed");
                        if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                            $window.localStorage.setItem("TokenExpired",true);
                            $state.go('login');
                        }else{
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if(response.data.networkError!='' && response.data.networkError!=undefined){
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }else{
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                }
            });
        }

         $scope.gotoCreateOpsTeam = function() {
			$state.go('app.addopsteam');
		}
        
        $scope.updateAdvertiserDescrip = function (desc){
		      $scope.editModeAdv=false;
		      $scope.enableText = false;
			  $scope.editMode = true;
			  $scope.advDescriptionVal = desc;
		}
		$scope.updateDescription = function (description){
		
		 angular.forEach($scope.advertiserdetails, function (val, key){
			   
        if($scope.advertiserdetails[key].advertiserId == $window.localStorage.getItem("advertiserId"))
				{                   
				$scope.advertiserLogoUrl = $scope.advertiserdetails[key].logoUrl;                                
                $scope.pocName = $scope.advertiserdetails[key].pocName;
				$scope.pocNumber = $scope.advertiserdetails[key].pocPhone;		
		  var parameters = {
                    "userId" : $window.localStorage.getItem("userId"),
                    "accessToken" : $window.localStorage.getItem("accessToken"),
                    "advertiserId" : $window.localStorage.getItem("advertiserId"),
                    "pocName" :  $scope.pocName,
                    "pocNumber" : $scope.pocNumber ,
                    "description" : $scope.advertiserDesc,
                    "logoUrl" :  $scope.advertiserLogoUrl                     
                };
                $http({
                    method: 'POST',
                    url: apiBase+'/user/updateadvertiser',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(response) {                  
					 $scope.advertiserDescription = $scope.advertiserDesc ;
				     $scope.editModeAdv=true;
				     $scope.editMode =false;
					 $scope.enableText = true;
					 
					    
                });
		    }		
		})
		}
//		$scope.init = function(){
//       
//        $scope.advertiserdatafetch();
//        $scope.getaccountdetails();
//        $scope.fetchCurentPlanDetails();
//        $scope.loadCurrencyCode();
//        $scope.selectadvertiser();
//        $scope.checksync();
//               
//                
//    }
//	 $timeout(function () {
//          $rootScope.progressLoader = "none";
//            $scope.init();
//    }, 1500);

		$scope.cancelEditMode = function (){
		       $scope.editModeAdv=true;
			   $scope.editMode =false;
			   $scope.enableText = true;
			  
			   $scope.advertiserDescription= $scope.advDescriptionVal;
			   $scope.advertiserDesc =  $scope.advertiserDescription;
			   //$scope.advertiserDescription = $scope.advertiserDesc ;
			 				 
		}
                
	//==================== LAST SYNCH SERVICE INTEGRATION FOR FACEBOOK ==============//

$scope.permitAccess = function(){
    var showPermission = $(".lastSynch");
    showPermission.show();
    $scope.lastSynchLoginShow =  true;
    $scope.lastSynchRedirectSuccess = false;
    $scope.lastSynchRedirectError = false;
    
};

$scope.openLastSynchPopUp = function(){
  
    $rootScope.progressLoader = 'block';
    var showPermission = $(".lastSynch");
    showPermission.hide();
    $scope.fetchAllNetworkforAppId();
};


//calling fetch all network for client id 
$scope.fetchAllNetworkforAppId = function(){
    //console.log("trying to fetch app id");
    $http({
       method : 'GET',
       url : apiBase + '/user/fetchallnetwork',
       headers:{
           'userId' : $window.localStorage.getItem('userId'),
           'accessToken' : $window.localStorage.getItem('accessToken')
       }
    }).then(function(response){
        $scope.fetchNetworkAppId = response.data.networkList;
        if(response.data.appStatus == '0'){
            angular.forEach($scope.fetchNetworkAppId, function(value,key){
            if(value.networkUrl === FbUrl){
                $scope.networkId = value.networkId;
                $scope.clientId = value.appId;
                //console.log($scope.clientId);
            }
           });
           $scope.openWindowforAccessToken($scope.clientId);
        }else{
            $scope.errorPopUp(response.data.errorMessage);
        }
        
    });
};


$scope.openWindowforAccessToken = function(clientId){
    $rootScope.progressLoader = 'none';
    //console.log('new window');
    
    $rootScope.popupWindow = window.open("https://www.facebook.com/dialog/oauth?client_id="+ clientId +
                                    "&response_type=token&scope=email,user_events,pages_messaging&\n\
                                        redirect_uri=" + FbRedirectUrl,
                                        '', 'scrollbars=1,height=600,width=800,left=500,top=100'); 
    
    window.OnChildWindowLoaded = function (href) {
        //console.log('Opened ' + href + ' successfully');
        
        if(href == undefined){
            $rootScope.progressLoader = 'none';
            var showPermission = $(".lastSynch");
            showPermission.show();
            $scope.synchsuccess = false;
            $scope.lastSynchRedirectError = true;
            $scope.lastSynchLoginShow =  false;
            $scope.lastSynchRedirectSuccess = false;
            $scope.errorMessageLastsynch = "Login Sync failed";
        
        }else if(href.toString().indexOf("access_token") > 0){
            var accessToken = href.toString();
            //console.log("yes");
            accessToken = accessToken.split("#")["1"];
            accessToken = accessToken.split("&")["0"];
            accessToken = accessToken.split("=")["1"];
            //console.log("temp" + accessToken);
            $scope.getPermanentAccessToken(accessToken);
           
        }else if(href.toString().indexOf("error") > 0){
            //console.log("login failed");
            $rootScope.popupWindow.close();
            $rootScope.progressLoader = 'none';
            var showPermission = $(".lastSynchFb");
            showPermission.show();
        }
    };
};



$scope.getPermanentAccessToken = function(urlAccessToken){
    //console.log("obtaining permanent access token");
    //service call to obtain long lived token
    $http({
       method : 'GET',
       url : apiTPBase + '/getlonglivedtoken?shortLivedToken=' +urlAccessToken,
       headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
    }).then(function(response){
        //console.log(response);
        if(response.data.appStatus== '0'){
            $scope.permanentAccessToken = response.data.longLivedToken;
            $scope.getConfirmation();
        }else{
            $rootScope.popupWindow.close();
            $scope.errorPopUp(response.data.errorMessage);
        }
    });
};

$scope.getConfirmation =function(){
  //get confirmation
window.getValue = function(val){
    //console.log('user persmission ' + val)
    if(val == 'true'){
        $rootScope.progressLoader = 'block';
        //console.log("access granted");
        $scope.createUserNetworkMapId();
        $rootScope.popupWindow.close();
        
    }else if(val == 'false'){
        //console.log('access denied');
        $rootScope.popupWindow.close();
        $rootScope.progressLoader = 'none';
        var showPermission = $(".lastSynchFb");
        showPermission.show();
        
    }else{
        //console.log('error');
        $rootScope.popupWindow.close();
        $rootScope.progressLoader = 'none';
        var showPermission = $(".lastSynchFbLoginError");
        showPermission.show();
    }
};
};

$scope.createUserNetworkMapId = function(){
  //console.log("create user newtork map id");
  var parameters = {
      'userId' : $window.localStorage.getItem('userId'),
      'accessToken' : $window.localStorage.getItem('accessToken'),
      'networkId' : $scope.networkId
  };
  $http({
     method : 'POST',
     url : apiBase+'/user/createusernetworkmaping',
     data : parameters
  }).then(function(response){
      //console.log(response);
       if(response.data.appStatus == '0'){
            $scope.saveFBAccessToken($scope.permanentAccessToken);
       }else{
            $scope.errorPopUp(response.data.errorMessage);
       }
  });
};


$scope.saveFBAccessToken = function(permanentAccessToken){
    //console.log('trying to save fb access token in token out');
    //console.log(permanentAccessToken);
    var parameters = {
      'userId' : $window.localStorage.getItem('userId'),
      'accessToken' : $window.localStorage.getItem('accessToken'),
      'networkId' : $scope.networkId,
      'fbAccessToken' : permanentAccessToken,
      'tokenMethod' : "OAuth 2.0"
    };
   $http({
        method : 'POST',
        url: apiBase+'/user/savefbtoken',
        data : parameters,
        headers: {
            'Content-Type': "application/json"
        }
   }).then(function(response){
       //console.log(response);
       if(response.data.appStatus == '0'){
            $scope.getUserDetails(permanentAccessToken);
       }else{
            $scope.errorPopUp(response.data.errorMessage);
       }
      
   });
};

 
$scope.getUserDetails = function(permanentAccessToken){
  //console.log("obtaining user details");
  $http({
       method : 'GET',
       url : 'https://graph.facebook.com/me?\n\
                fields=email,name,gender,first_name,last_name,age_range&\n\
                access_token='+ permanentAccessToken
    }).then(function(response){
        //console.log(response);
        if(response.status == '200'){//using status since get req no appStatus
            $scope.advertiserNewtorkFetch();    
        }else{
            $scope.errorPopUp(response.data.errorMessage);
        }
       
    });
};

$scope.advertiserNewtorkFetch = function(){
   //console.log("trying to fetch advertiser network map id");
   $http({
      method : 'GET',
      url : apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem('accountId'),
      headers:{
           'userId' : $window.localStorage.getItem('userId'),
           'accessToken' : $window.localStorage.getItem('accessToken')
       }
   }).then(function(response){
       //console.log(response);
       if(response.data.appStatus = '0'){
           $scope.adevrtiserNetworkList = response.data.advertiserNetworkList;
           angular.forEach($scope.adevrtiserNetworkList, function(value,key){
            if(value.networkId == $scope.networkId){
                $window.localStorage.setItem("userNetworkMapId" , $scope.userNetworkMapId);
                $scope.userNetworkMapId = value.userNetworkMapId;

                //console.log($scope.userNetworkMapId);
                 $scope.getFbAdAccount($scope.userNetworkMapId);
                }
           });
       }else{
           $scope.errorPopUp(response.data.errorMessage);
       }
   });
};

$scope.getFbAdAccount = function(userNetworkMapId){
    //console.log('get FB Ad Account Details');
    $http({
       method : 'GET',
       url : apiTPBase + '/getadaccounts?userNetworkMapId=' + userNetworkMapId,
       
       headers:{
           'userId' : $window.localStorage.getItem('userId'),
           'accessToken' : $window.localStorage.getItem('accessToken')
       }
    }).then(function(response){
        //console.log(response);
        if(response.data.appStatus == '0'){
            $scope.FbAdAccountDetails = response.data.fbAdAccounts;
            console.log($scope.FbAdAccountDetails);
            angular.forEach($scope.FbAdAccountDetails, function(value,key){
               $scope.FbAdAccountDetails = value;
               $scope.networkAdAccountId = value.account_id;
               $scope.accountStatus = value.account_status;
                if($scope.accountStatus == '1'){
                    console.log($scope.networkAdAccountId);
                    $scope.saveFbAdAccountDetails($scope.FbAdAccountDetails, userNetworkMapId, $scope.networkAdAccountId);
                }else{
                    console.log($scope.networkAdAccountId);
                    console.log('cannot save this ad account');
                }
           });
        }
    });
};

$scope.saveFbAdAccountDetails = function(FbAdAccountDetails, userNetworkMapId, networkAdAccountId){
    //console.log('saving fb ad account details in db');
    var parameters = {
        'userId' : $window.localStorage.getItem('userId'),
        'accessToken' : $window.localStorage.getItem('accessToken'),
        'userNetworkMapId' : userNetworkMapId,
        'adAccountId' : networkAdAccountId,
        'adAccountDetails' : FbAdAccountDetails
         };
    $http({
       method: 'POST',
       url: apiTPBase+'/saveadaccount',
       data : parameters,
       headers: {
           'Content-Type': "application/json"
       }
     }).then(function(response){
        //console.log(response);
        $window.localStorage.setItem('networkAdAccountId', networkAdAccountId);
        $rootScope.progressLoader = 'none';
        var showPermission = $(".lastSynch");
        showPermission.show();
        $scope.lastSynchLoginShow =  false;
        $scope.lastSynchRedirectSuccess = true;
        $scope.lastSynchRedirectError = false;
        $scope.lastSynchLoginShow =  false;
        $scope.synchsuccess = true;

     });
    
};

$scope.closePopupLastSync = function(){
    var showPermission = $(".lastSynch");
    showPermission.hide();
};

$scope.closePopupLastSyncFb = function(){
    var showPermission = $(".lastSynchFb");
    showPermission.hide();
};

$scope.errorPopUp = function(erroMessage){
        //console.log(erroMessage);
        $rootScope.progressLoader = 'none';
        var showPermission = $(".lastSynch");
        showPermission.show();
        $scope.synchsuccess = false;
        $scope.lastSynchRedirectError = true;
        $scope.lastSynchLoginShow =  false;
        $scope.lastSynchRedirectSuccess = false;
        $scope.errorMessageLastsynch =erroMessage;
            
};

//aysnc fb js sdk 
function statusChangeCallback(response) {
    
    if (response.status === 'connected') {
      //console.log("user already logged in, obtaining temp access Token");
      //console.log("TAT response");
      //console.log(response);
    
      $window.localStorage.setItem('tempAccessToken' , response.authResponse.accessToken);
      $scope.getPermanentAccessToken();
    
    } else {
      //console.log("please log in");
      $scope.loginFb();
    }
};

$scope.loginFb = function(){
    FB.login(function(response){
        //console.log(response);
        statusChangeCallback(response);
      });
};

$scope.openLastSynchPopUpfbsdk = function(){
    $rootScope.progressLoader = 'block';
    var showPermission = $(".lastSynch");
    showPermission.hide();
    $scope.fetchAllNetworkforAppId();
  
    //async sdk integration fb
    window.fbAsyncInit = function() {
      FB.init({
        appId      : '1048637028523108',
        xfbml      : true,
        version    : 'v2.9'
      });
        FB.getLoginStatus(function (response) {
            //check whether user is logged in
            statusChangeCallback(response);
        });
    };

    (function(d, s, id){
       var js, fjs = d.getElementsByTagName(s)[0];
       if (d.getElementById(id)) {return;}
       js = d.createElement(s); js.id = id;
       js.src = "//connect.facebook.net/en_US/sdk.js";
       fjs.parentNode.insertBefore(js, fjs);
     }(document, 'script', 'facebook-jssdk'));
};


	$scope.init = function(){       
		$scope.advertiserdatafetch();
		$scope.getaccountdetails();
		$scope.fetchCurentPlanDetails();
		$scope.loadCurrencyCode();
		$scope.selectadvertiser();
		$scope.checksync();
    }
	$timeout(function () {
          $rootScope.progressLoader = "none";
            $scope.init();
    }, 2500);





 }]);

