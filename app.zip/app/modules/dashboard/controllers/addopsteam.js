
    dashboard.controller("optsteamcreatecontroller", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {
        
        $scope.acc_name = {red: false};
        $scope.adv_name = {red: false};
        $scope.name = {red: false};
        $scope.adv_contact = {red: false};
        $scope.ops_email = {red: false};
        $scope.var_opsemail_class= {red:false};
        $scope.var_message_span_ospemail = false;
        $scope.gotoadvDashboard =function (){
           $state.go('app.advertiserdashboard');
        }
        
        $scope.edit_profiledetails = function () {
            $scope.edit_view = true;
            angular.element('.is-div-disabled').css('opacity', 1);
            angular.element('.is-div-disabled').css('pointer-events', 'auto');
            angular.element('.is-btn-disabled').css('opacity', 0.9);
            angular.element('.is-btn-disabled').css('pointer-events', 'none');
        }
        
        
        $scope.isDiabled = true;

        $scope.acc_name_empty_check = function (val)
        {

            $scope.accnameempty = false;

            if (val == "" || val == undefined || val == null)
            {
                $scope.acc_name.red = true;
                $scope.accnameempty = true;
            }
            else
            {
                $scope.acc_name.red = false;
                $scope.accnameempty = false;
            }
        }
        $scope.adv_name_empty_check = function (val1)
        {
            $scope.advnameempty = false;
            if (val1 == "" || val1 == undefined || val1 == null)
            {
                $scope.adv_name.red = true;
                $scope.advnameempty = true;
            }
            else
            {
                $scope.adv_name.red = false;
                $scope.advnameempty = false;
            }
        }
        $scope.name_empty_check = function (val)
        {

            $scope.nameempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.name.red = true;
                $scope.nameempty = true;
            }
            else
            {
                $scope.name.red = false;
                $scope.nameempty = false;
            }
        }
        $scope.adv_contact_empty_check = function (val)
        {

            $scope.advactempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.adv_contact.red = true;
                $scope.advcontactempty = true;
            }
            else
            {
                $scope.adv_contact.red = false;
                $scope.advcontactempty = false;
            }
        }
        $scope.ops_email_empty_check = function (val)
        {

            $scope.opsemailempty = false;

            if (val === "" || val == undefined || val == null)
            {
                $scope.ops_email.red = true;
                $scope.opsemailempty = true;
            }
            else
            {
                $scope.ops_email.red = false;
                $scope.opsemailempty = false;
            }
        }
               
        $scope.getaccountDetails_fetch = function () {
            //alert($window.localStorage.getItem("userId"));
            
            $rootScope.progressLoader = "block";
             $http({
                method: 'GET',
                url: appSettings.apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    //$scope.Records = response.data.networkList;
                 $scope.accountName=  response.data.accountFetchResponse.accountName;
                 
               
                } else {// failed
                    $rootScope.progressLoader = "none";
                }
            });
        };
        $scope.getaccountDetails_fetch();
        
        $scope.advertiserdatafetch = function () {
                       
            $rootScope.progressLoader = "block";
             $http({
                method: 'GET',
                url: appSettings.apiBase + '/user/advertiserdatafetch?accountId='+$window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    //$scope.Records = response.data.networkList;
                 $scope.advertiserName=  response.data.advDataFetchResponse[0].advertiserName;
                 //$scope.advertiserid=response.data.advDataFetchResponse[0].advertiserId;
                 
               
                } else {// failed
                    $rootScope.progressLoader = "none";
                }
            });
        };
        $scope.advertiserdatafetch();
                        
        $scope.create_opsteam = function (_nObj) {
           
            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),                          
                "accountId":$window.localStorage.getItem("accountId"),
                "advertiserId":$window.localStorage.getItem("advertiserId"),
                "opsMemberName":$scope.Name,
                "opsPhone":$scope.contact,
                "opsEmail":$scope.email
                //"status":"active"
            };
            
            
            $rootScope.progressLoader = "block";
            //console.log(parameters);
            $http({
                url: appSettings.apiBase + "/user/opsteammemberlogincreation",
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                //alert(response.errorMessage)
                if (response.errorId > 0) {
                    $rootScope.progressLoader = "none";
                    if(response.errorId == 2013)
                    {
                        $scope.var_opsemail_class= {red:true};
                        $scope.var_message_span_ospemail = true;
                        $scope.create_ops_Error = false;
                    }
                    else{
                    //alert(response.errorMessage);
                    var modalcreate_opsteam = $(".create_opsteam");// Get the modal Reject req
                    modalcreate_opsteam.show();
                    $scope.opsteam_create_Success=false;
                    $scope.create_ops_Error=true;
                }
                } else {
                    $rootScope.progressLoader = "none";
                    var modalcreate_opsteam = $(".create_opsteam");// Get the modal Reject req
                    modalcreate_opsteam.show();
                     $scope.var_opsemail_class= {red:false};
                    $scope.var_message_span_ospemail = false;
                    $scope.opsteam_create_Success=true;
                    $scope.message_span = "Ad Ops user account is created successfully";                             
                                
                }
                              
            }).error(function (error) {
                console.log('error')
                //alert(error);
            });
        };
        
       
        
        $scope.create_opsteam_close=function(){
           var modalcreate_opsteam = $(".create_opsteam");// Get the modal Reject req
            modalcreate_opsteam.hide();
            $state.go('app.advertiserdashboard');
        }

    }]);

dashboard.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                var clean = val.replace(/[^0-9]+/g, '');
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });
            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});

app.directive('validateEmail', function () {
    var EMAIL_REGEXP = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;

    return {
        require: 'ngModel',
        restrict: '',
        link: function (scope, elm, attrs, ctrl) {
            // only apply the validator if ngModel is present and Angular has added the email validator
            if (ctrl && ctrl.$validators.email) {

                // this will overwrite the default Angular email validator
                ctrl.$validators.email = function (modelValue) {
                    return ctrl.$isEmpty(modelValue) || EMAIL_REGEXP.test(modelValue);
                };
            }
        }
    };
})



        
        
    
