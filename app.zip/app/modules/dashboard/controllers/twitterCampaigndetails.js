dashboard.controller("twittercampaigndetailsController", ['$rootScope', '$scope', '$state', 'catalyst','$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http','$filter','$compile','appSettings',
function ($rootScope, $scope, $state, catalyst, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile,appSettings) 
{
    var vm = this;
        vm.getData = {};
        vm.setSet = {};
		
		  $scope.firstActiveDiv = 'yes';
    
		$scope.firstActiveDivImg = false;
		$scope.secondActiveDivImg = false;
		$scope.thirdActiveDivImg = false;
		$scope.fourthActiveDivImg = false;
		$scope.fifthActiveDivImg = false;
		
        var apiTPBase = appSettings.apiTPBase;
        vm.showDetails = true;
        $scope.campaignplan = [];
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.objective = ''; //Test variable, Not needed remove this decularation
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};
        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        $scope.init = function () {
            $scope.todayDate = new Date();
            $scope.minDate = new Date();
            $scope.campaignplan.accountCountryName = "India"
            $scope.campaignplan.currency = "Indian Rupee"
            $scope.campaignplan.description = "Asia/Kolkata"
            $scope.campaignplan.adAccName = "Digi Live"
            $scope.campaignplan.advertSetName = "createAdsetTest1"
        }
		
		$scope.$watch('vm.getData.objective', function(newVal, oldVal){	
                  
			if(newVal){
                              console.log(newVal)
				 $window.localStorage.setItem("marketingObjective", newVal);
                                 angular.element('#step1').css('background-color', '#95D2B1');
				
                                angular.element('.is-div-disabled').css('opacity', 1);
                                angular.element('.is-div-disabled').css('pointer-events', 'auto');  
			}
		 }, true)
                 
                 $scope.$watch('vm.getData.campaignName', function(newVal, oldVal){	
                    console.log(newVal)
			if(newVal){
                            $window.localStorage.setItem("tempCampaignName", newVal);
                            angular.element('.is-btn-disabled').css('opacity', 1);
                            angular.element('.is-btn-disabled').css('pointer-events', 'auto'); 
                            angular.element('#step2').css('background-color', '#95D2B1');
			} else {
                            angular.element('.is-btn-disabled').css('opacity', 0.9);
                            angular.element('.is-btn-disabled').css('pointer-events', 'none'); 
                            angular.element('#step2').css('background-color', '#C2C2C2');
                        }
		 }, true)
                 
                 
        /*Added for Summary page show Need to be removed*/
        /*$window.localStorage.setItem("campaignAudienceTargetType", $scope.campaignAudienceTargetType);
        $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceTarget);
        
        $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);
        $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
        $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
        $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
        $window.localStorage.setItem("campaignAudienceLanguage", $scope.campaignAudienceLanguage);
        $window.localStorage.setItem("campaignaudienceDetailedTargeting", $scope.campaignaudienceDetailedTargeting);
        $window.localStorage.setItem("campaignAudienceConnection", $scope.campaignAudienceConnection);
        $window.localStorage.setItem("campaignAudiencePlacements", $scope.campaignAudiencePlacements);
        $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);*/
        
        
        
        $scope.objectiveValue = $window.localStorage.getItem("objective");
        $scope.campaignNamevalue = $window.localStorage.getItem("tempCampaignName");
        $scope.LocationValue = $window.localStorage.getItem("campaignAudienceLocations");
        $scope.agefromValue = $window.localStorage.getItem("campaignAudienceAgeFrom");
        $scope.agetoValue = $window.localStorage.getItem("campaignAudienceAgeTo");
        $scope.genderValue = $window.localStorage.getItem("campaignAudienceGender");
        $scope.languagesValue = $window.localStorage.getItem("campaignAudienceLanguage");
        //$scope.detailTargetingValue = $window.localStorage.getItem("campaignaudienceDetailedTargeting");
        $scope.mobileDeviceValue = $window.localStorage.getItem("campaignAudienceMobileDevice");
		
		$scope.mobileDeviceValue_1 = $window.localStorage.getItem("MFeedcampaignAudiencePlacements");
		$scope.mobileDeviceValue_2 = $window.localStorage.getItem("DFeedcampaignAudiencePlacements");
		$scope.mobileDeviceValue_3 = $window.localStorage.getItem("DRColumncampaignAudiencePlacements");
        
		$scope.mobilenewfeed = $scope.mobileDeviceValue_1+" "+$scope.mobileDeviceValue_2+" "+$scope.mobileDeviceValue_3;
	
		
        /*End of summary Page Temp Variables*/
        $scope.selectBudget = function (_obj) {

            if (_obj.name == "Daily Budget") {
                $scope.campaignplan.budgetValue = "20"
            } else {
                $scope.campaignplan.budgetValue = "50"
            }
        }
        $scope.selectAdvertDelivery = function (_obj) {
            $scope.campaignplan.advertDelivery = _obj.name

        }
        $scope.selectSchedule = function (value) {
            if (value == 1) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
            }
        }
        $scope.onDateChange1 = function (selectedDate) {
            $scope.startDate = selectedDate

            var _date = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');

            if ($scope.startDate > $scope.todayDate) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');
            } else {
                console.log('less than')
            }
        }
        $scope.onDateChange2 = function (selectedDate) {
            $scope.endDate = selectedDate
            console.log($scope.endDate)
            if ($scope.endDate > $scope.startDate) {
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.endDate), 'yyyy-mm-dd HH:mm:ss');
                console.log($scope.campaignplan.scheduleEndDate)
            } else {
                console.log('less than')
            }
        }
        $scope.selectBidAmount = function (value) {
            if (value == 1) {
                $scope.showText = false;
                $scope.campaignplan.bidAmount = "1000"
            } else {
                $scope.showText = true;
            }
        }
        $scope.saveBidAmount = function (value) {
            $scope.campaignplan.bidAmount = value;

        }
        $scope.gotoParentCampaign = function(){
            $state.go('app.parentcampaign');
        }
        $scope.gototwitterCampaignaudience = function(){
            $state.go('app.twitterCampaignAudience');
        }
        $scope.init();
            
      /*  $scope.postCampaignPlan = function (data) {
            console.log($scope.campaignplan)

            var headers = {
                "Content-Type": "application/json"
            }

            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "networkAdAccountId": "114680145658525",
                "dailyBudget": $scope.campaignplan.budgetValue,
                "isAutobid": "true",
                "adlabels": [
                    {"name": "adLabelN1"}
                ],
                "name": $scope.campaignplan.advertSetName,
                "billingEvent": "IMPRESSIONS",
                "campaignId": "23842529546860715",
                "targeting": {
                    "geo_locations": {
                        "countries": ["US"]}
                },
                "status": "PAUSED",
                //"networkAccessToken": "EAAFMB7HwTnoBAE5hdTzFbPQgcKsGOaOX9RUWpZAshWv7dMxqTHx7TbofgdUpWClS5qlz0IhskZCWK7Rkd1Voo8YgcgIlvsGsH5ijA4FX7AqiFgQuIzOdYFgKr1bfAmEOGEKuGbq9afcssTBDj3u52YVOOKuTMwIXPcXVO8uQZDZD",
                "networkAccessToken" : $window.localStorage.getItem("networkAccessToken"),
                "userNetworkMapId": "300013"
            }
        }*/
        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */
        $scope.result = 'pass';
		function getCampaignDetailsFromFB(campaignId){
			var headers = {			
				"Content-Type": "application/json",
				"userId":$scope.userId,
				"accessToken":$scope.accessToken
			}
			console.log(campaignId)
			var queryStr = "campaignId="+campaignId+"&"+"userNetworkMapId="+$window.localStorage.getItem("userNetworkMapId");
			$http({
                method: 'GET',
				url: apiTPBase+"/getcampaignbycampaignid"+"?"+queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
				
                if (response.data.appStatus == '0') {// success
                 console.log(response.data.campaign);
				 getNetWorkMapId(response.data.campaign, campaignId)
				// saveCampaignDataToLocalDB(response.data.campaign, campaignId);
				 
                } else {// failed
					
				
                }
            });
		}
		//
		function getNetWorkMapId(response, campaignId){
			/*$http({
                method: 'GET',
				url: apiTPBase+"/getfbuserid?networkMapId=300002",
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
				
                if (response.data.appStatus == '0') {// success
					console.log(response.data.fbUserId);
					saveCampaignDataToLocalDB(response, campaignId,response.data.fbUserId);
                } else {// failed
					
				
                }
            });*/
			saveCampaignDataToLocalDB(response, campaignId);
		}
		
		function saveCampaignDataToLocalDB(response, campaignId){
			var networkMapId=$window.localStorage.getItem("userNetworkMapId");
			var parameters = {
				"userId":$window.localStorage.getItem("userId"),
				"accessToken":$window.localStorage.getItem("accessToken"),
				"userNetworkMapId":networkMapId,
				"parentCampaignId":$window.localStorage.getItem("parentCampaignId"),
				"adAccountId":response.account_id,
				"campaignId":campaignId,
				"campaignDetails":{ 
					"id": campaignId, 
					"account_id": response.account_id, 
					"buying_type": "AUCTION", 
					"can_use_spend_cap": true, 
					"configured_status": "PAUSED", 
					"created_time": response.created_time, 
					"effective_status": "PAUSED", 
					"name": response.name, 
					"objective": response.objective, 
					"spend_cap": "5000000", 
					"start_time": response.start_time, 
					"status": "PAUSED", 
					"updated_time": response.updated_time
				 }
			}
			$http({
                method: 'POST',
				url: apiTPBase+"/savecampaigndata",
				data : parameters,
				headers: {
					'Content-Type': "application/json"
				}
            }).then(function(response) {
				console.log(response);
                if (response.data.appStatus == '0') {// success
					console.log('campaign details saved successfully')
					$state.go('app.campaignaudience');
				 
                } else {// failed
					
				
                }
            });
			
		}
		//
        vm.createCampaignObjective = function (data) {
			
            if (data.objective == undefined) {
                alert('Please Select Marketing Objective');
                return true;
            }
            loginService.campService(data).then(function (response) {
				console.log(response);
                if (response.appStatus == 0) {
					console.log(response.campaignId);
                    $window.localStorage.setItem("campaignId", response.campaignId);
                    $window.localStorage.setItem("objective", data.objective);
					getCampaignDetailsFromFB(response.campaignId);
                    
                } else {
                    Flash.create('danger', response.errorMessage, 'large-text');
                }

            });
        };
        vm.campSummaryAction = function (data) {
            loginService.campSummaryService(data).then(function (response) {
				//alert(":: "+response.success);
                if (response.success==true) {
                    $scope.successPopup();
                } else {
					$scope.successPopup();
                    //Flash.create('danger', "Connection Issue with Facebook", 'large-text');
                }
            });
        };

        //-------------------------------
        /*$scope.campaignplan =[
         {
         "accountCountryName": "India",
         "currency": "Indian Rupee",
         "description": "Asia/Kolkata",
         "adAccName": "Digi Live",
         "advertSetName":"createAdsetTest1"
         }
         ];*/
        /*	$scope.campaignplan =[
         {
         "accountCountryName": "India",
         "currency": "Indian Rupee",
         "description": "Asia/Kolkata",
         "adAccName": "Digi Live",
         "budgetValue":"",
         "scheduleStartDate":"",
         "scheduleEndDate":"",
         "advertSetName":"createAdsetTest1",
         "advertDelivery":"",
         "bidAmount":""
         }
         ];
         */

        //----------------------------

        $scope.accountItems = [
            {
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }
        ]
        $scope.currencyItems = [
            {
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }
        ]
        $scope.timeZoneItems = [
            {
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }
        ]
        $scope.budgetItems = [
            {
                "id": 1,
                "name": "Daily Budget",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Lifetime Budget",
                "description": null,
                "code": null
            }
        ]
        $scope.advertItems = [
            {
                "id": 1,
                "name": "NONE",
                "description": null,
                "code": null
            },
            {
                "id": 2,
                "name": "APP_INSTALLS",
                "description": null,
                "code": null
            },
            {
                "id": 3,
                "name": "BRAND_AWARENESS",
                "description": null,
                "code": null
            },
            {
                "id": 4,
                "name": "CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 5,
                "name": "ENGAGED_USERS",
                "description": null,
                "code": null
            },
            {
                "id": 6,
                "name": "EXTERNAL",
                "description": null,
                "code": null
            },
            {
                "id": 7,
                "name": "EVENT_RESPONSES",
                "description": null,
                "code": null
            },
            {
                "id": 8,
                "name": "IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 9,
                "name": "LEAD_GENERATION",
                "description": null,
                "code": null
            },
            {
                "id": 10,
                "name": "LINK_CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 11,
                "name": "OFFER_CLAIMS",
                "description": null,
                "code": null
            },
            {
                "id": 12,
                "name": "OFFSITE_CONVERSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 13,
                "name": "PAGE_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 14,
                "name": "PAGE_LIKES",
                "description": null,
                "code": null
            },
            {
                "id": 15,
                "name": "POST_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 16,
                "name": "REACH",
                "description": null,
                "code": null
            },
            {
                "id": 17,
                "name": "SOCIAL_IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 18,
                "name": "VIDEO_VIEWS",
                "description": null,
                "code": null
            },
            {
                "id": 19,
                "name": "APP_DOWNLOADS",
                "description": null,
                "code": null
            }
        ];
        var modalSuccessPop = $(".success-popup");// Get the modal Success req
        $scope.successPopup = function () {
            modalSuccessPop.show();
        }
        $scope.closeSuccessPopup = function () {
            modalSuccessPop.hide();
        }
        
    
    
}]);