dashboard.controller("createCampaignPlanController", ['$rootScope', '$scope', '$state', '$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http','$filter','$compile',
function ($rootScope, $scope, $state, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile) {
    var vm = this;
    vm.showDetails = true;
	$scope.campaignPlanCurrency ={};
	$scope.campaignPlanBudget ={};
	$scope.campaignPlanSchedule ={};
    vm.home = {}; 
    $scope.init = function(){
		$scope.opened1 = false;
		$scope.open1 = function(){
			$scope.opened1 = true;
		}
		$scope.todayDate = new Date();
		$scope.minDate   = new Date();
		$scope.onDateChange = function(_obj) {
			console.log(_obj.minDate)
			console.log(_obj.date)
			console.log(_obj.todayDate)			
		}
			
	}
	$scope.init();
	
	$scope.postCampaignPlan = function(data){
		console.log(data)
	}
	
	//----------------------------
	
	$scope.accountItems = [
		{
        "id": 1,
        "name": "Linux",
        "description": null,
        "code": null
		}, {
			"id": 2,
			"name": "Windows",
			"description": null,
			"code": null
		}
	]
	$scope.currencyItems = [
		{
        "id": 1,
        "name": "Linux",
        "description": null,
        "code": null
		}, {
			"id": 2,
			"name": "Windows",
			"description": null,
			"code": null
		}
	]
	$scope.timeZoneItems = [
		{
        "id": 1,
        "name": "Linux",
        "description": null,
        "code": null
		}, {
			"id": 2,
			"name": "Windows",
			"description": null,
			"code": null
		}
	]
	$scope.budgetItems = [
		{
        "id": 1,
        "name": "Linux",
        "description": null,
        "code": null
		}, {
			"id": 2,
			"name": "Windows",
			"description": null,
			"code": null
		}
	]
	$scope.advertItems = [
		{
        "id": 1,
        "name": "Linux",
        "description": null,
        "code": null
		}, {
			"id": 2,
			"name": "Windows",
			"description": null,
			"code": null
		}
	]
	
	
	
	
	//----------------------------

    
}]);

