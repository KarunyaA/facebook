dashboard.controller("dashboardadvController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', '$timeout',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, $timeout) {
        var apiBase = appSettings.apiBase;
        var apiTPBase = appSettings.apiTPBase;

        $scope.editAdsetErrorMsg = 'none';

        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");

        $scope.insights = 'today';

        $scope.closePopupDetails = function () {
            $scope.editAdsetErrorMsg = "none";
        }

        $scope.chartfacebookGraph = function ()
        {
            $scope.graphfacebook = true;
            $scope.graphtwitter = false;
            $scope.graphinstagram = false;
            $scope.graphgoogle = false;
            $scope.graphbing = false;
            //$scope.graphtwitter=true;

        }
        
        $scope.init = function(){
        //$rootScope.progressLoader = "block";
        $http({
            method: 'GET',
            url: apiBase + '/user/getaccountdetails?accountId='+$window.localStorage.getItem("accountId"),
            headers: {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            }
        }).then(function(response) {
            $rootScope.progressLoader = "none";
            if (response.data.appStatus == '0') {// success
                $scope.accountName = response.data.accountFetchResponse.accountName;
                $scope.accountLogoUrl = response.data.accountFetchResponse.logoUrl;
                $scope.downloadAccountLogo($scope.accountLogoUrl); 
                $scope.getAdvertiserDetails();

            } else {// failed
                    console.log("failed");
                    console.log(response);
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
            }
        });
    }
    $scope.init();
    $scope.downloadAccountLogo = function(accountLogoUrl){
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths" : [accountLogoUrl]
            };
            $http({
                method: 'POST',
                url: apiImageServer+'/downloadimages',
                data : parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function(resp) {
                 $scope.accountLogo = resp.data.imageContent[$scope.accountLogoUrl];
            });
        }
        $scope.getAdvertiserDetails = function () {
            //$scope.accountId = "100003"  // need to change from service integration
            $http({
                method: 'GET',
                url: apiBase + '/user/advertiserdatafetch?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $scope.advertiserdetails = response.data.advDataFetchResponse;

                    //getting all networks
                    $scope.allnetworks();
                    console.log('fetchallnetwoks');

                    //getting networks for all account
                    $scope.networksforacc();
                    console.log('fetchadvnetwork');

                } else {// failed

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }

        $scope.getAdvertiserDetails();
        $scope.bool = [];
        $scope.wholeParentArray = [];
        $scope.wholeArray = [];
        $scope.wholechildArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkforadv = false;

        $scope.allnetworks = function ()
        {
            //
            //  console.log("hiee")
            $http({
                method: 'GET',
                url: apiBase + "/user/fetchallnetwork",
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {
                    console.log('in all networks')
                    $scope.allnetworksarray = response.data.networkList;
                    //console.log($scope.allnetworksarray)
                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }

        //FETCHADVERTISERNETWORK
        $scope.networksforacc = function ()
        {
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchadvertisernetwork?accountId=' + $window.localStorage.getItem("accountId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log('in fetchadvnetwoks')
                    $scope.networksarrayforacc = response.data.advertiserNetworkList;
                    //console.log($scope.networksarrayforacc)
                    for (i = 0; i < $scope.networksarrayforacc.length; i++)
                    {

                        angular.forEach($scope.allnetworksarray, function (val, key)
                        {
                            if ($scope.networksarrayforacc[i].networkId == val.networkId)
                            {
                                $scope.networksarrayforadvertiser.push(val);
                            }
                        });
                        //console.log($scope.networksarrayforadvertiser)
                        console.log('going to my function')
                        $scope.checkNetworkforadvertiser();

                    }
                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });


        }


        $scope.checkNetworkforadvertiser = function ()
        {
            //console.log(advertiserId)
            $scope.networkforadv = true;
            $scope.networksarrayforadvertiser = [];
            //traversing the account networks for advertiser email 

            for (i = 0; i < $scope.networksarrayforacc.length; i++)
            {

                angular.forEach($scope.advertiserdetails, function (val, key) {
                    if ($window.localStorage.getItem("advertiserId") == val.advertiserId)
                    {

                        if (val.advertiserEmail == $scope.networksarrayforacc[i].userId)
                        {
                            $scope.networkid = $scope.networksarrayforacc[i].networkId;

                            angular.forEach($scope.allnetworksarray, function (val, key)
                            {
                                if ($scope.networkid == val.networkId && val.networkUrl==appSettings.fbNetwork)
                                {
                                    $scope.networksarrayforadvertiser.push(val);

                                    $scope.userNetworkMapId = $scope.networksarrayforacc[i].userNetworkMapId;

                                }
                            });
                        }
                    }
                });

            }
            console.log('read ad accoutnt')
            $scope.readadAccountId();




        }
        //ADACCOUNTID & CURRENCY
        $scope.readadAccountId = function () {
            //alert($scope.userNetworkMapId);
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccounts?networkMapId=' + $scope.userNetworkMapId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    console.log('in readadaccount')

                    angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {

                        $scope.adaccountid = response.data.fbReadAdAccountResponse[key].fbAdAccountId;
                        //$window.localStorage.setItem("adaccountId", $scope.adaccountid);
                        $scope.currency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;


                    });
                    //console.log($scope.currency)
                    if ($scope.currency == "INR") {
                        $scope.inr = true;
                        $scope.usd = false;
                        $scope.eur = false;
                        $scope.gpb = false;
                    } else if($scope.currency == "USD") {
                        $scope.inr = false;
                        $scope.usd = true;
                        $scope.eur = false;
                        $scope.gpb = false;
                    } else if ($scope.currency == "EUR") {
                        $scope.inr = false;
                        $scope.usd = false;
                        $scope.eur = true;
                        $scope.gpb = false;
                    } else if ($scope.currency == "GPB") {
                        $scope.inr = false;
                        $scope.usd = false;
                        $scope.eur = false;
                        $scope.gpb = true;
                    }
                    console.log('read today')
                    $scope.readadaccoutnInsightsadvToday();
                    //$scope.readadaccoutnInsightsYesterday();
                    console.log('read overAll')
                    $scope.readadaccoutnInsights();
                    $scope.selectadvertiser();
                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });
            

        };


        $scope.selectadvertiser = function () {
            //console.log('test');
            $scope.wholeParentArray = [];
            //$window.localStorage.setItem("advertiserId", advertiserId);
            $http({
                method: 'GET',
                url: apiBase + '/user/fetchparentcampaignsbyadvertiser?advertiserId=' + $window.localStorage.getItem("advertiserId"),
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    $scope.campaigndetails = response.data.parentCampaigns;
                    //adding parent details to whole array
                    for (var i = 0; i < $scope.campaigndetails.length; i++) {
                        var _obj = {
                            "id": $scope.campaigndetails[i].parentCampaignId,
                            "name": $scope.campaigndetails[i].parentCampaignName,
                            "type": "parent",
                            "status": $scope.campaigndetails[i].parentCampaignStatus
                        }
                        if(_obj.status!=="DELETED"){
                        $scope.wholeParentArray.push(_obj);
                    }
                    }
                    //getting child campaigns
                    angular.forEach($scope.wholeParentArray, function (val, key) {
                        $scope.fetchChildAndPush(val.id,val.name);
                    });
                    //$scope.checkNetworkforadvertiser(advertiserId);
                }
                else {// failed

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }
            });
        }
//        $scope.selectadvertiser();



        $scope.parentselection = function (_obj)
        {
            //console.log(_obj.id)
            //$scope.parentoverall=true;
            $scope.selectedvalue = '';
            $scope.selectedvalue = _obj.name;
            $scope.parent_id = _obj.id;
            $scope.show=true;
            //console.log($scope.parent_id);
            //console.log($scope.wholechildArray)
            for (var i = 0; i < $scope.wholechildArray.length; i++) {

                if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                    $scope.childID = $scope.wholechildArray[i].id;
                    //console.log($scope.childID);
                    $scope.totalallparentimpressions = 0;
                    $scope.totalallparentclicks = 0;
                    $scope.totalallparentspend = 0;
                    $scope.totalallparentaction = 0;

                    $scope.totalallparentimpressions = 0;
                    $scope.totalallparentclicks = 0;
                    $scope.totalallparentspend = 0;
                    $scope.totalallparentaction = 0;

                    $scope.totalallYesterdayparentimpressions = 0;
                    $scope.totalallYesterdayparentclicks = 0;
                    $scope.totalallYesterdayparentspend = 0;
                    $scope.totalallYesterdayparentaction = 0;

                    //if($scope.insights=='overall'){
                    //console.log('overall' +$scope.insights);
                    $scope.parentchildcampaignOverall($scope.wholechildArray[i].id);
                    //}
                    // else if($scope.insights=='today'){
                    console.log('today' + $scope.insights);
                    $scope.parentchildcampaignYesterday($scope.wholechildArray[i].id);
                    $scope.parentchildcampaignToday($scope.wholechildArray[i].id);
                    //}

                }

            }
            $scope.show=false;
        };

        $scope.totalallparentimpressions = 0;
        $scope.totalallparentclicks = 0;
        $scope.totalallparentspend = 0;
        $scope.totalallparentaction = 0;

        $scope.parentchildcampaignOverall = function (childID)
        {
            $rootScope.progressLoader = "block";
            $scope.parentoverall = true;
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + childID,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //alert('Overall success')
                //console.log('response');
                if (response.data.appStatus == '0') {// success
                    // alert('overll parent response')
                    $rootScope.progressLoader = "none";


                    angular.forEach(response.data.adCampaignInsights, function (value, key) {

                        $scope.adimpressionsallparent = response.data.adCampaignInsights[key][childID].impressions;
                        $scope.adclicksallparent = response.data.adCampaignInsights[key][childID].clicks;
                        $scope.adspendallparent = response.data.adCampaignInsights[key][childID].spend;
                        $scope.adcallToActionallparent = response.data.adCampaignInsights[key][childID].callToAction;


                    });


                    $scope.totalallparentimpressions += $scope.adimpressionsallparent;
                    $scope.totalallparentclicks += $scope.adclicksallparent;
                    $scope.totalallparentspend += $scope.adspendallparent;
                    $scope.totalallparentaction += $scope.adcallToActionallparent;


                    console.log($scope.totalallparentimpressions + '---' + $scope.totalallparentclicks + '---' + $scope.totalallparentspend + '---' + $scope.totalallparentaction)
                    plotValuesparentoverall($scope.totalallparentimpressions, $scope.totalallparentclicks, $scope.totalallparentaction, $scope.totalallparentspend);
                    $scope.facebookparentoverall($scope.totalallparentimpressions, $scope.totalallparentclicks, $scope.totalallparentaction, $scope.totalallparentspend, overall);
                    $scope.network = true;
                    //PIECHART
                    $scope.overall = false;
                    $scope.network = true;
                    $scope.today = false;

                    $scope.advtoday = false;
                    $scope.advoverall = false;
                    $scope.parentcampaignoverall = true;
                    $scope.parentcampaignToday = false;
                    //PIECHART
                    $scope.woserivce = false;
                    $scope.parentcampaign = true;
                    $scope.wcampaignserivcetoday = false;

                    $scope.nettabselection = true;
                    $scope.advertisergraph = false;
                    $scope.childgraph = false;
                    $scope.message = false;
                    $scope.alladvgraph = false;
                    $scope.parentgraph = true;

                    //$scope.noingightsparenttoday=false;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;


                    $scope.img = false;
                    $scope.overallData = true;
                    $scope.currentData = false;
                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');
                }

                else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.network = false;
                    $scope.noingightsoveralltoday = true;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    //$scope.noingightsoveralltoday=false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;
                    $scope.overall = false;
                    $scope.network = false;
                    $scope.today = false;
                    $scope.overallchildcampaign = false;
                    $scope.todaychildcampaign = false;
                    $scope.advoverall = false;
                    $scope.advtoday = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;
                    $scope.nettabselection = false;
                    $scope.advertisergraph = false;
                    $scope.childgraph = false;
                    $scope.message = true;
                    $scope.alladvgraph = false;
                    $scope.parentgraph = true;
                    $scope.network = false;
                    $scope.img = false;
                    $scope.overallData = false;
                    $scope.currentData = false;
                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            for(var i=0;i<$scope.wholechildArray.length;i++)
                            {
                                if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                                $scope.errorMsg = "Insight Details are not available for "+$scope.wholechildArray[i].parentName;
                                }
                            }
                            }
                    }

                }
//                   
            })

            $scope.readCorrespondingInsightsOverall = function ()
            {
                //$scope.insights='overall';
                if ($scope.parentoverall == true)
                {
                    $scope.totalallparentimpressions = 0;
                    $scope.totalallparentclicks = 0;
                    $scope.totalallparentspend = 0;
                    $scope.totalallparentaction = 0;
                    for (var i = 0; i < $scope.wholechildArray.length; i++) {

                        if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                            $scope.childID = $scope.wholechildArray[i].id;
                            console.log($scope.childID);
                            $scope.totalallparentimpressions = 0;
                            $scope.totalallparentclicks = 0;
                            $scope.totalallparentspend = 0;
                            $scope.totalallparentaction = 0;
                            $scope.parentchildcampaignOverall($scope.wholechildArray[i].id);
                            //$scope.parentchildcampaignYesterday($scope.wholechildArray[i].id);
                            //$scope.parentchildcampaignToday($scope.wholechildArray[i].id);

                        }

                    }
                    // $scope.parentchildcampaignOverall($scope.childID);
                    console.log("parent overall");
                }
            };
            $scope.readCorrespondingInsightsToday = function ()
            {
                //$scope.insights='today';
                if ($scope.parentToday == true)
                {
                    $scope.totalallTodayparentimpressions = 0;
                    $scope.totalallTodayparentclicks = 0;
                    $scope.totalallTodayparentspend = 0;
                    $scope.totalallTodayparentaction = 0;
                    $scope.totalallYesterdayparentimpressions = 0;
                    $scope.totalallYesterdayparentclicks = 0;
                    $scope.totalallYesterdayparentspend = 0;
                    $scope.totalallYesterdayparentaction = 0;
                    for (var i = 0; i < $scope.wholechildArray.length; i++) {

                        if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                            $scope.childID = $scope.wholechildArray[i].id;
                            console.log($scope.childID);
                            $scope.totalallTodayparentimpressions = 0;
                            $scope.totalallTodayparentclicks = 0;
                            $scope.totalallTodayparentspend = 0;
                            $scope.totalallTodayparentaction = 0;

                            $scope.totalallYesterdayparentimpressions = 0;
                            $scope.totalallYesterdayparentclicks = 0;
                            $scope.totalallYesterdayparentspend = 0;
                            $scope.totalallYesterdayparentaction = 0;
                            // $scope.parentchildcampaignOverall($scope.wholechildArray[i].id);
                            $scope.parentchildcampaignYesterday($scope.wholechildArray[i].id);
                            $scope.parentchildcampaignToday($scope.wholechildArray[i].id);

                        }

                    }
                    //$scope.parentchildcampaignToday();
                    console.log("parentr today");
                }
            };

        }

        //PARENT INSIGHTS TODAY
//        $scope.formattedtodaychilddate = $filter('date')(new Date(), 'yyyy-MM-dd');
        $scope.totalallTodayparentimpressions = 0;
        $scope.totalallTodayparentclicks = 0;
        $scope.totalallTodayparentspend = 0;
        $scope.totalallTodayparentaction = 0;

        $scope.parentchildcampaignToday = function (childID)
        {
            var date = new Date();
            var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
            console.log(_utc);
            $scope.formattedtodaydate = $filter('date')(_utc, 'yyyy-MM-dd');

            // alert('Today');

            //console.log(child_id);
            $rootScope.progressLoader = "block";
            $scope.parentToday = true;
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + childID + '&insightsDate=' + $scope.formattedtodaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //alert('Todaysuccess')
                console.log(response.data.adCampaignInsights);
                if (response.data.appStatus == '0') {// success
                    //alert('today parent response')
                    $rootScope.progressLoader = "none";


                    angular.forEach(response.data.adCampaignInsights, function (value, key) {

                        $scope.adimpressionsallTodayparent = response.data.adCampaignInsights[key][childID].impressions;
                        $scope.adclicksallTodayparent = response.data.adCampaignInsights[key][childID].clicks;
                        $scope.adspendallTodayparent = response.data.adCampaignInsights[key][childID].spend;
                        $scope.adcallToActionTodayallparent = response.data.adCampaignInsights[key][childID].callToAction;


                    });


                    $scope.totalallTodayparentimpressions += $scope.adimpressionsallTodayparent;
                    $scope.totalallTodayparentclicks += $scope.adclicksallTodayparent;
                    $scope.totalallTodayparentspend += $scope.adspendallTodayparent;
                    $scope.totalallTodayparentaction += $scope.adcallToActionTodayallparent;

                    console.log($scope.totalallTodayparentimpressions + '---' + $scope.totalallTodayparentclicks + '---' + $scope.totalallTodayparentspend + '---' + $scope.totalallTodayparentaction)
                    plotValuesparentToday($scope.totalallTodayparentimpressions, $scope.totalallTodayparentclicks, $scope.totalallTodayparentaction, $scope.totalallTodayparentspend);
//                    $scope.facebook($scope.adimpressions, $scope.adclicks, $scope.adcallToAction, $scope.adspend, overall);
                    //PIECHART
                    if ($scope.totalallYesterdayparentimpressions > $scope.totalallTodayparentimpressions)
                    {
                        $scope.uparrow = false;
                        $scope.downarrow = true;
                        $scope.equalarrow = false;

                    }
                    else if ($scope.totalallYesterdayparentimpressions < $scope.totalallTodayparentimpressions)
                    {
                        $scope.uparrow = true;

                        $scope.downarrow = false;
                        $scope.equalarrow = false;
                    }
                    else
                    {   //alert('hi')
                        $scope.uparrow = false;
                        $scope.downarrow = false;
                        $scope.equalarrow = true;
                    }

                    if ($scope.totalallYesterdayparentclicks > $scope.totalallTodayparentclicks)
                    {
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = true;
                        $scope.equalarrow2 = false;
                    }

                    else if ($scope.totalallYesterdayparentclicks < $scope.totalallTodayparentclicks)
                    {
                        $scope.uparrow2 = true;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = false;
                    }
                    else {
                        // alert('hi')
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = true;
                    }

                    if ($scope.totalallYesterdayparentspend > $scope.totalallTodayparentspend)
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = true;
                        $scope.equalarrow4 = false;
                    }

                    else if ($scope.totalallYesterdayparentspend < $scope.totalallTodayparentspend)
                    {
                        $scope.uparrow4 = true;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = false;
                    }
                    else
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = true;
                        // alert('hi')
                    }

                    if ($scope.totalallYesterdayparentaction > $scope.totalallTodayparentaction)
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = true;
                        $scope.equalarrow3 = false;
                    }
                    else if ($scope.totalallYesterdayparentaction < $scope.totalallTodayparentaction)
                    {
                        $scope.uparrow3 = true;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = false;
                    }
                    else
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = true;
                        //alert('hi')
                    }
                    $scope.network = false;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.advtoday = false;
                    $scope.advoverall = false;

                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = true;
                    //PIECHART
                    $scope.parentcampaignToday = true;
                    $scope.parentcampaign = false;
                    $scope.wcampaignserivcetoday = false;

                    $scope.nettabselection = false;
                    $scope.advertisergraph = false;
                    $scope.childgraph = false;
                    $scope.message = true;
                    $scope.alladvgraph = false;
                    $scope.parentgraph = false;

                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;



                    $scope.img = true;
                    $scope.overallData = false;
                    $scope.currentData = true;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');
                }

                else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.noingightsparenttoday = true;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    //$scope.noingightsparenttoday-false;
                    $scope.network = false;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.overallchildcampaign = false;
                    $scope.todaychildcampaign = false;
                    $scope.advoverall = false;
                    $scope.advtoday = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;
                    $scope.parentcampaignToday = false;
                    $scope.parentcampaign = false;
                    $scope.wcampaignserivcetoday = false;
                    $scope.nettabselection = false;
                    $scope.advertisergraph = false;
                    $scope.childgraph = false;
                    $scope.message = true;
                    $scope.alladvgraph = false;
                    $scope.parentgraph = false;
                    $scope.img = false;
                    $scope.overallData = false;
                    $scope.currentData = false;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');


                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            for(var i=0;i<$scope.wholechildArray.length;i++)
                            {
                                if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                                $scope.errorMsg = "Insight Details are not available for " + $scope.wholechildArray[i].parentName;
                                }
                            }
                        }
                    }

                }
//                   
            })
        }

        $scope.totalallYesterdayparentimpressions = 0;
        $scope.totalallYesterdayparentclicks = 0;
        $scope.totalallYesterdayparentspend = 0;
        $scope.totalallYesterdayparentaction = 0;

        $scope.parentchildcampaignYesterday = function ()
        {
            $scope.date = new Date();
            $scope.tomorrow = new Date();
            $scope.tomorrow.setDate($scope.tomorrow.getDate() - 1);
            $scope.formattedyesterdaydate = $filter('date')($scope.tomorrow, 'yyyy-MM-dd');
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + $scope.childID + '&insightsDate=' + $scope.formattedyesterdaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adparentcampaignimpressionyesterday = response.data.adCampaignInsights[key][$scope.childId].impressions;
                        $scope.adparentcampaignclicksyesterday = response.data.adCampaignInsights[key][$scope.childId].clicks;
                        $scope.adparentcampaignspendyesterday = response.data.adCampaignInsights[key][$scope.childId].spend;
                        $scope.adparentcampaigncallToActionyesterday = response.data.adCampaignInsights[key][$scope.childId].callToAction;

                    });

                    $scope.totalallYesterdayparentimpressions += $scope.adparentcampaignimpressionyesterday;
                    $scope.totalallYesterdayparentclicks += $scope.adparentcampaignclicksyesterday;
                    $scope.totalallYesterdayparentspend += $scope.adparentcampaignspendyesterday;
                    $scope.totalallYesterdayparentaction += $scope.adparentcampaigncallToActionyesterday;


                    //console.log("after : " + $scope.adcampaignimpressionyesterday + '-->' + $scope.adcampaignclicksyesterday + '-->' + $scope.adcampaignspendyesterday + '-->' + $scope.adcampaigncallToActionyesterday);
                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            for(var i=0;i<$scope.wholechildArray.length;i++)
                            {
                                if ($scope.parent_id == $scope.wholechildArray[i].parentid) {
                                $scope.errorMsg = "Insight Details are not available for " + $scope.wholechildArray[i].parentName;
                                }
                            }
                        }
                    }
                }

            });

        };





        $scope.test = function (parentobj, _index) {
            console.log(parentobj)
            console.log($scope.wholeParentArray)
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                //angular.element('#parent' + (i+1)).removeClass('selectparent');
                var el = angular.element('#parent' + (i + 1));
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";

            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";

            }
            else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";

            }
        }



        $scope.childselection = function (_index, _obj)
        {
            var date = new Date();
            var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
            console.log(_utc);
            $scope.formattedtodaydate = $filter('date')(_utc, 'yyyy-MM-dd');

            $scope.childselectedToday = true;
            $scope.childIndex = _index;
            $scope.childData = _obj;
            $scope.childId = _obj.id;
            console.log(_obj.id)
            $scope.selectedvalue = '';
            $scope.selectedvalue = _obj.name;
            $scope.show=true;
            var overall = "overall";
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";

            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + $scope.childId + '&insightsDate=' + $scope.formattedtodaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adCampaignInsights, function (value, key) {

                        $scope.adcampaignimpressionsToday = response.data.adCampaignInsights[key][$scope.childId].impressions;
                        $scope.adcampaignclicksToday = response.data.adCampaignInsights[key][$scope.childId].clicks;
                        $scope.adcampaignspendToday = response.data.adCampaignInsights[key][$scope.childId].spend;
                        $scope.adcampaigncallToActionToday = response.data.adCampaignInsights[key][$scope.childId].callToAction;


                    });
                    //alert("Campaign" + $scope.adcampaignimpressionsToday + " " + $scope.adcampaignclicksToday + " " + $scope.adcampaignspendToday + " " + $scope.adcampaigncallToActionToday);


                    // angular.element('#child' + _index).addClass('selectchild');



                    plotValueschildToday($scope.adcampaignimpressionsToday, $scope.adcampaignclicksToday, $scope.adcampaigncallToActionToday, $scope.adcampaignspendToday);
                    //$scope.facebook($scope.adcampaignimpressions, $scope.adcampaignclicks, $scope.adcampaigncallToAction, $scope.adcampaignspend, overall);
                    //$scope.graphtoverall=true;
                    $scope.childselectedYesterday();
                    if ($scope.adcampaignimpressionyesterday > $scope.adcampaignimpressionsToday)
                    {
                        $scope.uparrow = false;
                        $scope.downarrow = true;
                        $scope.equalarrow = false;

                    }
                    else if ($scope.adcampaignimpressionyesterday < $scope.adcampaignimpressionsToday)
                    {
                        $scope.uparrow = true;

                        $scope.downarrow = false;
                        $scope.equalarrow = false;
                    }
                    else
                    {   //alert('hi')
                        $scope.uparrow = false;
                        $scope.downarrow = false;
                        $scope.equalarrow = true;
                    }

                    if ($scope.adcampaignclicksyesterday > $scope.adcampaignclicksToday)
                    {
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = true;
                        $scope.equalarrow2 = false;
                    }

                    else if ($scope.adcampaignclicksyesterday < $scope.adcampaignclicksToday)
                    {
                        $scope.uparrow2 = true;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = false;
                    }
                    else {
                        // alert('hi')
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = true;
                    }

                    if ($scope.adcampaignspendyesterday > $scope.adcampaignspendToday)
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = true;
                        $scope.equalarrow4 = false;
                    }

                    else if ($scope.adcampaignspendyesterday < $scope.adcampaignspendToday)
                    {
                        $scope.uparrow4 = true;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = false;
                    }
                    else
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = true;
                        // alert('hi')
                    }

                    if ($scope.adcampaigncallToActionyesterday > $scope.adcampaigncallToActionToday)
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = true;
                        $scope.equalarrow3 = false;
                    }
                    else if ($scope.adcampaigncallToActionyesterday < $scope.adcampaigncallToActionToday)
                    {
                        $scope.uparrow3 = true;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = false;
                    }
                    else
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = true;
                        //alert('hi')
                    }

                    $scope.network = false;
                    $scope.overall = false;
                    $scope.today = true;
                    $scope.advoverall = false;
                    $scope.advtoday = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;
//                    $scope.overallchildcampaign=false;
//                    $scope.todaychildcampaign=false;

                    $scope.childgraph = false;
                    $scope.nettabselection = false;
                    $scope.message = true;
                    $scope.parentgraph = false;

                    $scope.img = true;
//                    $scope.woserivce = false;
//                    $scope.wserivce = false;
                    $scope.wcampaignserivceoverall = false;
                    $scope.wcampaignserivcetoday = true;
                    $scope.wadvserivceoverall = false;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;


                    $scope.overallData = false;
                    $scope.currentData = true;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');

                    console.log(_obj.id)
                    $scope.bool[_obj.parentid] = true;
                    for (i = 0; i < $scope.wholeParentArray.length; i++)
                    {
                        if ($scope.wholeParentArray[i].id != _obj.parentid)
                        {
                            var el = angular.element('#parent' + (i + 1));
                            el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                        }
                    }
                    //$scope.childCmapaignInstightsOverall();
                } else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.overallData = false;
                    $scope.network = false;
                    $scope.currentData = false;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.advoverall = false;
                    $scope.advtoday = false;
                    $scope.childgraph = false;
                    $scope.nettabselection = false;
                    $scope.message = true;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = true;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsparenttoday = false;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';                            
                            $scope.errorMsg = "Insight Details are not available for " +_obj.name;
                        }
                    }

                }

            });
            $scope.show=false;
            $scope.childCmapaignInstightsOverall();


        }


        $scope.childselectedYesterday = function ()
        {
            $scope.date = new Date();
            $scope.tomorrow = new Date();
            $scope.tomorrow.setDate($scope.tomorrow.getDate() - 1);
            $scope.formattedyesterdaydate = $filter('date')($scope.tomorrow, 'yyyy-MM-dd');
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + $scope.childId + '&insightsDate=' + $scope.formattedyesterdaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adcampaignimpressionyesterday = response.data.adCampaignInsights[key][$scope.childId].impressions;
                        $scope.adcampaignclicksyesterday = response.data.adCampaignInsights[key][$scope.childId].clicks;
                        $scope.adcampaignspendyesterday = response.data.adCampaignInsights[key][$scope.childId].spend;
                        $scope.adcampaigncallToActionyesterday = response.data.adCampaignInsights[key][$scope.childId].callToAction;

                    });
                    console.log("after : " + $scope.adcampaignimpressionyesterday + '-->' + $scope.adcampaignclicksyesterday + '-->' + $scope.adcampaignspendyesterday + '-->' + $scope.adcampaigncallToActionyesterday);
                } else {// failed
                    $rootScope.progressLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }

            });

        };




        $scope.childCmapaignInstightsOverall = function ()
        {
            var overall = "overall";
            $scope.childselected = true;



            $rootScope.progressLoader = "block";

            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadcampaigninsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adCampaignId=' + $scope.childId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adCampaignInsights, function (value, key) {

                        $scope.adcampaignimpressions = response.data.adCampaignInsights[key][$scope.childId].impressions;
                        $scope.adcampaignclicks = response.data.adCampaignInsights[key][$scope.childId].clicks;
                        $scope.adcampaignspend = response.data.adCampaignInsights[key][$scope.childId].spend;
                        $scope.adcampaigncallToAction = response.data.adCampaignInsights[key][$scope.childId].callToAction;


                    });

                    plotValueschildOverall($scope.adcampaignimpressions, $scope.adcampaignclicks, $scope.adcampaigncallToAction, $scope.adcampaignspend);
                    $scope.facebookchild($scope.adcampaignimpressions, $scope.adcampaignclicks, $scope.adcampaigncallToAction, $scope.adcampaignspend, overall);
                    //$scope.graphtoverall=true;
                    $scope.network = true;
                    $scope.overall = true;
                    $scope.today = false;
                    $scope.advtoday = false;
                    $scope.advoverall = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;
//                    $scope.overallchildcampaign=true;
//                    $scope.todaychildcampaign=false;

                    $scope.childgraph = true;
                    $scope.advgraph = false;
                    $scope.parentgraph = false;
                    $scope.nettabselection = true;
                    $scope.message = false;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;
                    $scope.img = false;
//                    $scope.woserivce = false;
//                    $scope.wserivce = false;
                    $scope.wcampaignserivceoverall = true;
                    $scope.wcampaignserivcetoday = false;
                    $scope.overallData = true;
                    $scope.currentData = false;
                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');
                    //console.log(_obj.id)

                    $scope.bool[$scope.childData.parentid] = true;
                    for (i = 0; i < $scope.wholeParentArray.length; i++)
                    {
                        if ($scope.wholeParentArray[i].id != $scope.childData.parentid)
                        {
                            var el = angular.element('#parent' + (i + 1));
                            el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                        }
                    }
                    //$scope.childCmapaignInstightsToday();
                } else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.noingightschildoverall = true;
                    $scope.network = false;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.advtoday = false;
                    $scope.advoverall = false;
                    $scope.childgraph = false;
                    $scope.advgraph = false;
                    $scope.nettabselection = false;
                    $scope.message = true;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsparenttoday = false;
                    //$scope.noingightschildoverall=false;
                    $scope.overallData = false;
                    $scope.currentData = false;
                    $scope.img = false;
                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = "Insight Details are not available for " +$scope.selectedvalue;
                        }
                    }
                }

            });

            $scope.readCorrespondingInsightsOverall = function ()
            {
                if ($scope.childselected == true)
                {
                    $scope.childCmapaignInstightsOverall();
                    console.log("child overall");
                }
            };
            $scope.readCorrespondingInsightsToday = function ()
            {
                if ($scope.childselectedToday == true)
                {
                    $scope.childselection($scope.childIndex, $scope.childData);
                    console.log("child today");
                }
            };
        }

        $scope.parenttoggle = false;
        $scope.fetchChildAndPush = function (_id,_name) {

            $scope.wholechildArray = [];
            

            queryStr = "userNetworkMapId=" + $scope.userNetworkMapId + "&" + "parentCampaignId=" + _id;
            $http({
                method: 'GET',
                url: apiTPBase + "/readadcampaign" + "?" + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log("trying to get child")
                var index = 0;
                if (response.data.appStatus == '0') {
                    $scope.childCampaigns = response.data.adcampaigns;
                    //console.log($scope.childCampaigns)
                    var count = 0;
                    angular.forEach($scope.childCampaigns, function (value, key) {
                        var JsonObj = $scope.childCampaigns[key]
                        var array = [];
                        for (var j in JsonObj) {
                            if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                array[+j] = JsonObj[j];
                                var _obj = {
                                    "id": array[+j].campaignId,
                                    "name": array[+j].campaignDetails.name,
                                    "type": "child",
                                    "parentName" :_name,
                                    "parentid": _id
                                }
                                count++;
                                //console.log(_obj);
                                $scope.wholechildArray.push(_obj);
                                //console.log($scope.wholechildArray)

                            }
                        }
                        //console.log($scope.wholechildArray);
                    })
                    
                } else {
                    console.log('readadcampaign failed');
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });

        }



        //$scope.readadaccoutnInsights();

        //readadaccoutnInsightsToday
        //$scope.formattedtodaydate = $filter('date')(new Date(), 'yyyy-MM-dd');
        $scope.advertiser=function()
        {
            
            $scope.selectedvalue="Select Campaign";
            $scope.readadaccoutnInsightsadvToday();
            $scope.readadaccoutnInsights();
            
        }
        $scope.readadaccoutnInsightsadvToday = function () {
            var date = new Date();
            var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
            //console.log(_utc);
            $scope.formattedtodaydate = $filter('date')(_utc, 'yyyy-MM-dd');
            $scope.accountsinsightadvtoday = true;

            //alert($window.localStorage.getItem("userId"));
            var today = "today";
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adAccountId=' + $scope.adaccountid + '&insightsDate=' + $scope.formattedtodaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {// success
                    $scope.count++;

                    $rootScope.progressLoader = "none";

                    //console.log("before : "+$scope.adimpressions1+'-->'+$scope.adclicks1+'-->'+$scope.adspend1+'-->'+$scope.adcallToAction1);
                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adimpressionstoday = response.data.adAccountInsights[key][$scope.adaccountid].impressions;
                        $scope.adclickstoday = response.data.adAccountInsights[key][$scope.adaccountid].clicks;
                        $scope.adspendtoday = response.data.adAccountInsights[key][$scope.adaccountid].spend;
                        $scope.adcallToActiontoday = response.data.adAccountInsights[key][$scope.adaccountid].callToAction;
                        //console.log("after : "+$scope.adimpressions1+'-->'+$scope.adclicks1+'-->'+$scope.adspend1+'-->'+$scope.adcallToAction1);



                    });
                    plotValuesadvtoday($scope.adimpressionstoday, $scope.adclickstoday, $scope.adcallToActiontoday, $scope.adspendtoday);
//                    $scope.facebook($scope.adimpressionstoday, $scope.adclickstoday, $scope.adcallToActiontoday, $scope.adspendtoday, today);


                    $scope.readadaccoutnInsightsYesterday();
                    if ($scope.adimpressionyesterday > $scope.adimpressionstoday)
                    {
                        $scope.uparrow = false;
                        $scope.downarrow = true;
                        $scope.equalarrow = false;

                    }
                    else if ($scope.adimpressionyesterday < $scope.adimpressionstoday)
                    {
                        $scope.uparrow = true;

                        $scope.downarrow = false;
                        $scope.equalarrow = false;
                    }
                    else
                    {   //alert('hi')
                        $scope.uparrow = false;
                        $scope.downarrow = false;
                        $scope.equalarrow = true;
                    }

                    if ($scope.adclicksyesterday > $scope.adclickstoday)
                    {
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = true;
                        $scope.equalarrow2 = false;
                    }

                    else if ($scope.adclicksyesterday < $scope.adclickstoday)
                    {
                        $scope.uparrow2 = true;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = false;
                    }
                    else {
                        // alert('hi')
                        $scope.uparrow2 = false;
                        $scope.downarrow2 = false;
                        $scope.equalarrow2 = true;
                    }

                    if ($scope.adspendyesterday > $scope.adspendtoday)
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = true;
                        $scope.equalarrow4 = false;
                    }

                    else if ($scope.adspendyesterday < $scope.adspendtoday)
                    {
                        $scope.uparrow4 = true;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = false;
                    }
                    else
                    {
                        $scope.uparrow4 = false;
                        $scope.downarrow4 = false;
                        $scope.equalarrow4 = true;
                        // alert('hi')
                    }

                    if ($scope.adcallToActionyesterday > $scope.adcallToActiontoday)
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = true;
                        $scope.equalarrow3 = false;
                    }
                    else if ($scope.adcallToActionyesterday < $scope.adcallToActiontoday)
                    {
                        $scope.uparrow3 = true;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = false;
                    }
                    else
                    {
                        $scope.uparrow3 = false;
                        $scope.downarrow3 = false;
                        $scope.equalarrow3 = true;
                        //alert('hi')
                    }
                    $scope.network = false;
                    $scope.today = false;
                    $scope.overall = false;
                    $scope.overallchildcampaign = false;
                    $scope.todaychildcampaign = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;


                    $scope.advtoday = true;
                    $scope.advoverall = false;

                    $scope.nettabselection = false;
                    $scope.message = true;
                    $scope.advgraph = false;
                    $scope.childgraph = false;
                    $scope.parentgraph = false;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;

                    $scope.currentData = true;
                    $scope.overallData = false;
                    $scope.img = true;
                    $scope.woserivce = false;
                    $scope.wserivce = false;
                    $scope.wcampaignserivceoverall = false;
                    $scope.wcampaignserivcetoday = false;
                    $scope.wadvserivceoverall = false;
                    $scope.wadvserivcetoday = true;
                    //$scope.currentData=true;
                    //$scope.overallData=false;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');

                } else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.nettabselection = false;
                    $scope.network = false;
                    $scope.noingightsadvtoday = true;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;
                    $scope.advtoday = false;
                    $scope.advoverall = false;
                    $scope.currentData = false;
                    $scope.overallData = false;
                    $scope.advgraph = false;
                    $scope.parentgraph = false;
                    $scope.message = true;
                    angular.element('#today').css('background', '#009688');
                    angular.element('#today').css('color', '#ffffff');
                    angular.element('#overall').css('background', '#ffffff');

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }


            });

        };

        //readadaccoutnInsightsYesterday



        $scope.readadaccoutnInsightsYesterday = function () {
            $scope.date = new Date();
            $scope.tomorrow = new Date();
            $scope.tomorrow.setDate($scope.tomorrow.getDate() - 1);
            $scope.formattedyesterdaydate = $filter('date')($scope.tomorrow, 'yyyy-MM-dd');
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adAccountId=' + $scope.adaccountid + '&insightsDate=' + $scope.formattedyesterdaydate,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {

                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adimpressionyesterday = response.data.adAccountInsights[key][$scope.adaccountid].impressions;
                        $scope.adclicksyesterday = response.data.adAccountInsights[key][$scope.adaccountid].clicks;
                        $scope.adspendyesterday = response.data.adAccountInsights[key][$scope.adaccountid].spend;
                        $scope.adcallToActionyesterday = response.data.adAccountInsights[key][$scope.adaccountid].callToAction;

                        //plotValues($scope.adimpressions,$scope.adclicks,$scope.adcallToAction,$scope.adspend);
                    });
                    //console.log("after : "+$scope.adimpressionyesterday+'-->'+$scope.adclicksyesterday+'-->'+$scope.adspendyesterday+'-->'+$scope.adcallToActionyesterday);
                } else {// failed
                    $rootScope.progressLoader = "none";

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });

        };
        //$scope.readadaccoutnInsightsadvToday();

        $scope.readadaccoutnInsights = function () {
            $scope.accountsadvoverall = true;
            var overall = "overall";
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: appSettings.apiTPBase + '/readadaccountsinsights?userNetworkMapId=' + $scope.userNetworkMapId + '&adAccountId=' + $scope.adaccountid,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
                //console.log('response');
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";

                    angular.forEach(response.data.adAccountInsights, function (value, key) {

                        $scope.adadvimpressions = response.data.adAccountInsights[key][$scope.adaccountid].impressions;
                        $scope.adadvclicks = response.data.adAccountInsights[key][$scope.adaccountid].clicks;
                        $scope.advadspend = response.data.adAccountInsights[key][$scope.adaccountid].spend;
                        $scope.advcallToAction = response.data.adAccountInsights[key][$scope.adaccountid].callToAction;


                    });
                    //console.log($scope.adadvimpressions+"-"+$scope.adadvclicks+"-"+$scope.advadspend+"-"+$scope.advcallToAction);
//                    if($scope.adimpressions && $scope.adclicks && $scope.adspend && $scope.adcallToAction){

                    plotValuesadvOverall($scope.adadvimpressions, $scope.adadvclicks, $scope.advcallToAction, $scope.advadspend);


                    $scope.facebookadv($scope.adadvimpressions, $scope.adadvclicks, $scope.advcallToAction, $scope.advadspend, overall);
                    $scope.network = true;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.advoverall = true;
                    $scope.advtoday = false;
                    $scope.parentcampaignoverall = false;
                    $scope.parentcampaignToday = false;

                    $scope.graphfacebook = true;
                    $scope.nettabselection = true;
                    //$scope.advertisergraph=true;
                    $scope.childgraph = false;
                    $scope.advgraph = true;
                    $scope.parentgraph = false;
                    //$scope.alladvgraph=false;
                    $scope.message = false;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsadvoverall = false;
                    $scope.noingightsparenttoday = false;

                    $scope.img = false;
                    $scope.woserivce = false;
                    $scope.wserivce = false;
                    $scope.wcampaignserivceoverall = false;
                    $scope.wadvserivceoverall = true;
                    $scope.noingights = false;
                    $scope.overallData = true;
                    $scope.currentData = false;
                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');
                    //}
//                else{
//                    $scope.nodata=true;
//                }
                } else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.noingightsadvoverall = true;
                    $scope.noingightsadvtoday = false;
                    $scope.noingightschildtoday = false;
                    $scope.noingightschildoverall = false;
                    $scope.noingightsoveralltoday = false;
                    $scope.noingightsparenttoday = false;
                    $scope.network = false;
                    $scope.overallData = false;
                    $scope.currentData = false;
                    $scope.overall = false;
                    $scope.today = false;
                    $scope.advoverall = false;
                    $scope.advtoday = false;
                    $scope.graphfacebook = false;
                    $scope.nettabselection = false;
                    //$scope.advertisergraph=true;
                    $scope.childgraph = false;
                    $scope.advgraph = false;
                    $scope.message = true;
                    //$scope.alladvgraph=false;
                    //$scope.message=false;

                    angular.element('#today').css('background', '#ffffff');
                    angular.element('#today').css('color', '#000000');
                    angular.element('#overall').css('background', '#009688');

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            });
            $scope.readCorrespondingInsightsOverall = function ()
            {
                console.log('over all ' + $scope.accountsadvoverall)
                //$scope.insights='overall';
                if ($scope.accountsadvoverall == true)
                {
                    $scope.readadaccoutnInsights();
                    console.log("advertiser overall");
                }

            };
            $scope.readCorrespondingInsightsToday = function ()
            {
                // $scope.insights='today';
                console.log('today ' + $scope.accountsinsightadvtoday)
                if ($scope.accountsinsightadvtoday == true)
                {
                    $scope.readadaccoutnInsightsadvToday();
                    console.log("advertiser today");
                }
            };
        };


        //$scope.readadaccoutnInsights();

        $scope.facebookchild = function (_impressions, _clicks, _action, _spend, _todayOverall) {


            if (_todayOverall == "overall") {

                var doughnutLength4 = $("#sampleChartchild").find("svg").length;

                if (doughnutLength4 > 0) {

                }
                else {

                    $scope.facebookoverallchild(_impressions, _clicks, _action, _spend);
                }



                $scope.graphfacebook = true;

//                                 angular.element('#today').removeClass('disabled')
//                                 angular.element('#overall').addClass('disabled')


            }

        };




        $scope.facebookoverallchild = function (_impressions, _clicks, _action, _spend)
        {
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count": _impressions, "me": _impressions},
                {"quarter": "Facebook", "metrics": "Clicks", "count": _clicks, "me": _clicks},
                {"quarter": "Facebook", "metrics": "Actions", "count": _action, "me": _action},
                {"quarter": "Facebook", "metrics": "Spend", "count": _spend, "me": _spend},
                {"quarter": "Twitter", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0}

            ];
            // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#sampleChartchild",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "count",
                    item: "metrics"

                },
                scaling: {
                    x: 4,
                    columny: 1,
                    liney: 1
                },
                //scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " "
                },
                tooltip: {
                    container: "#sampleChartchild",
                    //width : 240,
                    bindings: [
                        {label: "Metrics", bindWith: "metrics"},
                        {label: "Count", bindWith: "me"}
                    ]
                }


            };

            var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);


            //console.log(document.getElementById("sampleChartoverall").children[0].children[0].children[0].children[2]);

//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[3].style.opacity = 0.0;
//            for (var i = 0; i <= 13; i++)
//            {
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[7].children[i].children[1]).css('text-anchor', '');
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[6].children[i].children[1]).css('text-anchor', 'end');
//            }


        }
        //Facebook Graph


        $scope.facebookadv = function (_impressions, _clicks, _action, _spend, _todayOverall) {


            if (_todayOverall == "overall") {

                var doughnutLength4 = $("#sampleChartadv").find("svg").length;

                if (doughnutLength4 > 0) {

                }
                else {

                    $scope.facebookoveralladv(_impressions, _clicks, _action, _spend);
                }





//                                 angular.element('#today').removeClass('disabled')
//                                 angular.element('#overall').addClass('disabled')


            }

        };




        $scope.facebookoveralladv = function (_impressions, _clicks, _action, _spend)
        {
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count": _impressions, "me": _impressions},
                {"quarter": "Facebook", "metrics": "Clicks", "count": _clicks, "me": _clicks},
                {"quarter": "Facebook", "metrics": "Actions", "count": _action, "me": _action},
                {"quarter": "Facebook", "metrics": "Spend", "count": _spend, "me": _spend},
                {"quarter": "Twitter", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0}

            ];
            // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#sampleChartadv",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "count",
                    item: "metrics"

                },
                scaling: {
                    x: 4,
                    columny: 1,
                    liney: 1
                },
                //scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " "
                },
                tooltip: {
                    container: "#sampleChartadv",
                    //width : 240,
                    bindings: [
                        {label: "Metrics", bindWith: "metrics"},
                        {label: "Count", bindWith: "me"}
                    ]
                }


            };

            var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);


            //console.log(document.getElementById("sampleChartoverall").children[0].children[0].children[0].children[2]);

//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[3].style.opacity = 0.0;
//            for (var i = 0; i <= 13; i++)
//            {
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[7].children[i].children[1]).css('text-anchor', '');
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[6].children[i].children[1]).css('text-anchor', 'end');
//            }


        }
        //Facebook Graph

        $scope.facebookparentoverall = function (_impressions, _clicks, _action, _spend, _todayOverall) {


            if (_todayOverall == "overall") {

                var doughnutLength4 = $("#sampleChartchild").find("svg").length;

                if (doughnutLength4 > 0) {

                }
                else {
                    $scope.facebookparentoverall(_impressions, _clicks, _action, _spend);
                }



            }

        };


        $scope.facebookparentoverall = function (_impressions, _clicks, _action, _spend)
        {
            $("#sampleChartparent").empty();
            var sampleData1 = [
                {"quarter": "Facebook", "metrics": "Impressions", "count": _impressions, "me": _impressions},
                {"quarter": "Facebook", "metrics": "Clicks", "count": _clicks, "me": _clicks},
                {"quarter": "Facebook", "metrics": "Actions", "count": _action, "me": _action},
                {"quarter": "Facebook", "metrics": "Spend", "count": _spend, "me": _spend},
                {"quarter": "Twitter", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Twitter", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Instagram", "metrics": "Spend", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Impressions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Clicks", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Actions", "count": 0, "me": 0},
                {"quarter": "Google", "metrics": "Spend", "count": 0, "me": 0}

            ];
            // Defining options for rendering Bar chart.
            var options = {
                container: {
                    id: "#sampleChartparent",
                    titlePos: 25,
                    width: 400,
                    height: 300
                },
                // margin: {top: 40, right: 20, bottom: 80, left: 50},
                //  base: "x",
                axisRange: {y: {min: 0, max: 100}},
                bindings: {
                    x: "quarter",
                    columny: "me",
                    liney: "count",
                    item: "metrics"

                },
                scaling: {
                    x: 4,
                    columny: 1,
                    liney: 1
                },
                //scaleFormat: {x: "", y: ""},
                ticks: {
                    x: 5,
                    columny: 10,
                    liney: 10
                },
                tickerAngle: {
                    x: 0
                },
                columnGloss: 'no',
                padding: 0.3,
                labels: {
                    x: " ",
                    columny: " ",
                    liney: " "
                },
                tooltip: {
                    container: "#sampleChartparent",
                    //width : 240,
                    bindings: [
                        {label: "Metrics", bindWith: "metrics"},
                        {label: "Count", bindWith: "me"}
                    ]
                }


            };

            var bar_graph = cviz.widget.LineColumn.Runner(options).graph();
            // console.log('iam here');
            //Actual function call to render the Bar graph
            bar_graph.render(sampleData1);


            //console.log(document.getElementById("sampleChartoverall").children[0].children[0].children[0].children[2]);

//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[1].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[2].children[3].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[0].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[1].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[2].style.opacity = 0.0;
//            document.getElementById("sampleChartoverall").children[0].children[0].children[2].children[3].children[3].style.opacity = 0.0;
//            for (var i = 0; i <= 13; i++)
//            {
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[7].children[i].children[1]).css('text-anchor', '');
//                $(document.getElementById("sampleChartoverall").children[0].children[0].children[6].children[i].children[1]).css('text-anchor', 'end');
//            }


        }


    }]);