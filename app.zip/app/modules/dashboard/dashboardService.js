dashboard.factory('accountDashBoardGetPost', ['$http', '$q','$timeout', 'catalyst', 'httpApi', '$rootScope', function($http, $q, $timeout, catalyst, httpApi, $rootScope) {
    var obj = {};
    var baseUrl = catalyst.serviceUrl1
    obj.isLocal = catalyst.isLocal;
    var _config = {};
    _config.cache = 'false';
    _config.async = 'false';
	 
    obj.fetchParentCompaignByAdv = function(_queryStr, _parameters,_headers){
		var url = "";
        if(this.isLocal == false){
			url = baseUrl+"fetchparentcampaignsbyadvertiser"+"?"+_queryStr;
        }
	 return httpApi.get(url, _parameters,_headers);
    }
     /*
    obj.post = function(filterCode, requestId, data){
        switch(filterCode){
            
            case 'configAddNewCIGroup':
            	url = "http://localhost:8080/cnapws/user/fetchparentcampaignsbyadvertiser?advertiserId=10002"
            break;
            
        }
        return httpApi.post(url, data);
    }
    */
    return obj;
}]); 
dashboard.service('dashboardService', ['$q', 'apiService', function ($q, apiService) {
        var dashboardService = {};
        dashboardService.createCampaignService = createCampaignService;

        return dashboardService;

    }]);
/*
dashboard.service('accountDashBoardService', ['$http', '$q', 'Flash', 'apiService', function ($http, $q, Flash, apiService) {

    var dashboardService = {};


    //service to communicate with users model to verify login credentials
    var accessLogin = function (parameters) {
        var deferred = $q.defer();
        apiService.get("users", parameters).then(function (response) {
            if (response)
                deferred.resolve(response);
            else
                deferred.reject("Something went wrong while processing your request. Please Contact Administrator.");
        },
            function (response) {
                deferred.reject(response);
            });
        return deferred.promise;
    };

    //service to communicate with users to include a new user
    var registerUser = function (parameters) {
        var deferred = $q.defer();
        apiService.create("users", parameters).then(function (response) {
            if (response)
                deferred.resolve(response);
            else
                deferred.reject("Something went wrong while processing your request. Please Contact Administrator.");
        },
            function (response) {
                deferred.reject(response);
            });
        return deferred.promise;
    };

    dashboardService.accessLogin = accessLogin;
    dashboardService.registerUser = registerUser;

    return dashboardService;

}]);
*/