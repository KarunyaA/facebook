var dashboard = angular.module('dashboard', ['ui.router', 'ngAnimate', 'ngMaterial','oc.lazyLoad']);

dashboard.config(['$stateProvider','$ocLazyLoadProvider', function ($stateProvider,$ocLazyLoadProvider) {

        $stateProvider.state('app.accountdashboard', {
            url: '/accountdashboard',
            templateUrl: 'app/modules/dashboard/views/accountdashboard.html',
            controller: 'AccountDashboardController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard'
            }
        });

        //advertiser Dashboard page state
        $stateProvider.state('app.advertiserdashboard', {
            url: '/advertiserdashboard',
            templateUrl: 'app/modules/dashboard/views/advertiserdashboard.html',
            controller: 'AdvertiserDashboardController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard'
            }
        });
        
        //fblogin Dashboard page state
        $stateProvider.state('app.fblogin', {
            url: '/fblogin',
            templateUrl: 'app/modules/dashboard/views/fblogin.html',
            controller: 'fbLoginController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard'
            }
        });

	$stateProvider.state('app.addopsteam', {
            url: '/addopsteam',
            templateUrl: 'app/modules/dashboard/views/addopsteam.html',
            controller: 'optsteamcreatecontroller',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard'
            }
        });
		
        //opsTeam Dashboard page state
        $stateProvider.state('app.opsteamdashboard', {
            url: '/opsteamdashboard',
            templateUrl: 'app/modules/dashboard/views/opsteamdashboard.html',
            controller: 'OpsteamDashboardController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard'
            }
        });

        //dashboard home page state
        $stateProvider.state('app.parentcampaign', {
            url: '/parentcampaign',
            templateUrl: 'app/modules/dashboard/views/parentcampaign.html',
            controller: 'HomeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Home'
            }
        });
        
      
        

        //create campaign template page state
        $stateProvider.state('app.campaigntemplate', {
            url: '/campaigntemplate',
            templateUrl: 'app/modules/dashboard/views/campaigntemplate.html',
            controller: 'campaigntemplateController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Template'
            }
        });      

        //create campaign page state
        $stateProvider.state('app.campaigndetails', {
            url: '/campaigndetails',
            templateUrl: 'app/modules/dashboard/views/campaigndetails.html',
            controller: 'campaignController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Details'
            }
        });
        
        
        //Expected Vs Actual page state
        $stateProvider.state('app.expectedactual', {
            url: '/expectedactual',
            templateUrl: 'app/modules/dashboard/views/expectedactual.html',
            controller: 'expectedvsactualController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Expected Vs Actual'
            }
        });      
        //create metric_comparison page state
        $stateProvider.state('app.metriccomparison', {
            url: '/metriccomparison',
            templateUrl: 'app/modules/dashboard/views/metriccomparison.html',
            controller: 'metriccomparisonController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Metric comparison'
            }
        });
        //create metric_comparison_advertiser page state
        $stateProvider.state('app.metriccomparisonadv', {
            url: '/metriccomparisonadv',
            templateUrl: 'app/modules/dashboard/views/metriccomparisonadv.html',
            controller: 'metriccomparisonadvController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Metric comparison'
            }
        });
        
        //create metric_comparison_ops team page state
        $stateProvider.state('app.metriccomparisonops', {
            url: '/metriccomparisonops',
            templateUrl: 'app/modules/dashboard/views/metriccomparisonops.html',
            controller: 'metriccomparisonopsController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Metric comparison'
            }
        });
        
        //dashboard profile details updation page state
        $stateProvider.state('app.editprofiledetails', {
            url: '/editprofiledetails',
            templateUrl: 'app/modules/dashboard/views/editprofiledetails.html',
            controller: 'profiledetailsController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Edit profile details'
            }
        });
        
        //accountdashboard add advertiser page state
        $stateProvider.state('app.addadvertiser', {
            url: '/addadvertiser',
            templateUrl: 'app/modules/dashboard/views/addadvertiser.html',
            controller: 'addadvertiserController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Add advertiser'
            }
        });
        
        

        
        //campaign audience page state
        $stateProvider.state('app.campaignaudience', {
            url: '/campaignaudience',
            templateUrl: 'app/modules/dashboard/views/campaignaudience.html',
            controller: 'campaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience'
            }
        });
		
		//create campaign page state
        $stateProvider.state('app.campaignplan', {
            url: '/campaignplan',
            templateUrl: 'app/modules/dashboard/views/campaignplan.html',
            controller: 'createCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'createCampaignPlanController'
            }
        });
		//create campaign page state
        $stateProvider.state('app.campaignsummary', {
            url: '/campaignsummary',
            templateUrl: 'app/modules/dashboard/views/campaignsummary.html',
            controller: 'campaignSummaryController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Summary'
            }
        });
        
        
        //campaign create  page state
        $stateProvider.state('app.campaigncreative', {
            url: '/campaigncreative',
            templateUrl: 'app/modules/dashboard/views/campaigncreative.html',
            controller: 'campaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'campaign creative'
            }
        });


        //skills page state
        $stateProvider.state('app.adDashboard', {
            url: '/adDashboard',
            templateUrl: 'app/modules/dashboard/views/updatedadDashboard.html',
            controller: 'dashboardController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'dashboardController'
            }
        });
        
        //skills page state
        $stateProvider.state('app.updatedadDashboardadv', {
            url: '/adDashboard',
            templateUrl: 'app/modules/dashboard/views/updatedadDashboard.html',
            controller: 'dashboardadvController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'dashboardController'
            }
        });

        //education page state
        $stateProvider.state('app.networkdetails', {
            url: '/networkdetails',
            templateUrl: 'app/modules/dashboard/views/education.html',
            controller: 'EducationController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Dashboard Home'
            }
        });

        //Experience page state
        $stateProvider.state('app.currencydetails', {
            url: '/currencydetails',
            templateUrl: 'app/modules/dashboard/views/experience.html',
            controller: 'ExperienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Experience'
            }
        });

        //Recent Projects page state
        $stateProvider.state('app.currencyconversion', {
            url: '/currencyconversion',
            templateUrl: 'app/modules/dashboard/views/recent.html',
            controller: 'RecentController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Recent Projects'
            }
        });
        
        $stateProvider.state('app.performancecampaignsummary', {
            url: '/performancecampaignsummary',
            templateUrl: 'app/modules/dashboard/views/performancecampaignsummary.html',
            controller: 'performancecampaignsummaryController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Performance Campaign Summary'
            }
        });
        
        $stateProvider.state('app.overallbudget', {
            url: '/overallbudget',
            templateUrl: 'app/modules/dashboard/views/overallbudget.html',
            controller: 'overallbudget',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Overall Budget'
            }
        });
		
		/*twitter section starts here*/
		
		//create twitter campaign template page state
        $stateProvider.state('app.twittercampaigntemplate', {
            url: '/twittercampaigntemplate',
            templateUrl: 'app/modules/twitter/campaigntemplate.html',
            controller: 'campaigntemplateController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Template'
            }
        });
		
		//create twitter campaign details page state
        $stateProvider.state('app.twittercampaigndetails', {
            url: '/twittercampaigndetails',
            templateUrl: 'app/modules/twitter/campaigndetails.html',
            controller: 'twittercampaigndetailsController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Details'
            }
        });
		
		//campaign audience page state VARSHA
        $stateProvider.state('app.twEngCampaignaudience', {
            url: '/twittertecampaignaudience',
            templateUrl: 'app/modules/twitter/tweetengagements/views/campaignaudience.html',
            controller: 'twEngCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		$stateProvider.state('app.webVisitsCampaignaudience', {
            url: '/twitterwvcampaignaudience',
            templateUrl: 'app/modules/twitter/websitevisits/views/campaignaudience.html',
            controller: 'webVisitsCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		$stateProvider.state('app.videoViewsCampaignaudience', {
            url: '/twittervvcampaignaudience',
            templateUrl: 'app/modules/twitter/videoviews/views/campaignaudience.html',
            controller: 'videoViewsCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		$stateProvider.state('app.followersCampaignaudience', {
            url: '/twitterfwcampaignaudience',
            templateUrl: 'app/modules/twitter/followers/views/campaignaudience.html',
            controller: 'followersCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		$stateProvider.state('app.awarenessCampaignaudience', {
            url: '/twitterawcampaignaudience',
            templateUrl: 'app/modules/twitter/awareness/views/campaignaudience.html',
            controller: 'awarenessCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		$stateProvider.state('app.installsofyourappCampaignaudience', {
            url: '/twitterappcampaignaudience',
            templateUrl: 'app/modules/twitter/installsofyourapp/views/campaignaudience.html',
            controller: 'installsofyourappCampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Audience Twitter'
            }
        });
		//create twitter campaign plan page state
        $stateProvider.state('app.twEngCampaignplan', {
            url: '/twittertecampaignplan',
            templateUrl: 'app/modules/twitter/tweetengagements/views/campaignplan.html',
            controller: 'twEngCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });
        $stateProvider.state('app.webVisitsCampaignplan', {
            url: '/twitterwvcampaignplan',
            templateUrl: 'app/modules/twitter/websitevisits/views/campaignplan.html',
            controller: 'webVisitsCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });    
        $stateProvider.state('app.videoViewsCampaignplan', {
            url: '/twittervvcampaignplan',
            templateUrl: 'app/modules/twitter/videoviews/views/campaignplan.html',
            controller: 'videoViewsCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });
		$stateProvider.state('app.followersCampaignplan', {
            url: '/twitterfwcampaignplan',
            templateUrl: 'app/modules/twitter/followers/views/campaignplan.html',
            controller: 'folloewersCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });
		$stateProvider.state('app.awarenessCampaignplan', {
            url: '/twitterawcampaignplan',
            templateUrl: 'app/modules/twitter/awareness/views/campaignplan.html',
            controller: 'awarenessCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });
		$stateProvider.state('app.installsofyourappCampaignplan', {
            url: '/twitterappcampaignplan',
            templateUrl: 'app/modules/twitter/installsofyourapp/views/campaignplan.html',
            controller: 'installsofyourappCampaignplanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign plan'
            }
        });
		//create twitter campaign creative page state
        $stateProvider.state('app.twEngCampaigncreative', {
            url: '/twittertecampaigncreative',
            templateUrl: 'app/modules/twitter/tweetengagements/views/campaigncreative.html',
            controller: 'twEngCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });
        $stateProvider.state('app.webVisitsCampaigncreative', {
            url: '/twitterwvcampaigncreative',
            templateUrl: 'app/modules/twitter/websitevisits/views/campaigncreative.html',
            controller: 'webVisitsCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });	
        $stateProvider.state('app.videoViewsCampaigncreative', {
            url: '/twittervvcampaigncreative',
            templateUrl: 'app/modules/twitter/videoviews/views/campaigncreative.html',
            controller: 'videoViewsCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });		
		$stateProvider.state('app.followersCampaigncreative', {
            url: '/twitterfwcampaigncreative',
            templateUrl: 'app/modules/twitter/followers/views/campaigncreative.html',
            controller: 'followersCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });		
		$stateProvider.state('app.awarenessCampaigncreative', {
            url: '/twitterawcampaigncreative',
            templateUrl: 'app/modules/twitter/awareness/views/campaigncreative.html',
            controller: 'awarenessCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });
		$stateProvider.state('app.installsofyourappCampaigncreative', {
            url: '/twitterappcampaigncreative',
            templateUrl: 'app/modules/twitter/installsofyourapp/views/campaigncreative.html',
            controller: 'installsofyourappCampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign Creative'
            }
        });		
        //create twitter campaign summary page state
        $stateProvider.state('app.twittercampaignsummary', {
            url: '/twittercampaignsummary',
            templateUrl: 'app/modules/twitter/campaignsummary.html',
            controller: 'twittercampaignsummaryController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Twitter Campaign sumamry'
            }
        });
		
		/*twitter section ends here*/

                //REPORTS 
        
        //create Reports Landing Page

         $stateProvider.state('app.reportsLanding', {
            url: '/reportslanding',
            templateUrl: 'app/modules/reports/reportslanding.html',
            controller: 'reportslandingController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Reports Landing Page'
            }
        });
        //create Campaign Effectiveness report page
         $stateProvider.state('app.campaigneffectivenessReport', {
            url: '/campaigneffectivenessreport',
            templateUrl: 'app/modules/reports/effectivenessreport/views/campaigneffectivenessreport.html',
            controller: 'campaigneffectiveController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Effectiveness Report'
            }
        });
        
         $stateProvider.state('app.actionareaIdentifierReport', {
            url: '/actionareaidentifier',
            templateUrl: 'app/modules/reports/actionareaIdentifierReport/views/actionareaidentifier.html',
            controller: 'actionAreaIdentifierReportController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Action Area Identifier'
            }
        });

        $stateProvider.state('app.funnelFlowReport', {
            url: '/funnelflow',
            templateUrl: 'app/modules/reports/funnelFlow/views/funnelflow.html',
            controller: 'funnelFlowController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Reports Landing Page'
            }
        });
		
		//** FB objective wise states */ 
		$stateProvider.state('app.fbcampaigndetails', {
            url: '/fbcampaigndetails',
            templateUrl: 'app/modules/facebook/campaigndetails.html',
            controller: 'campaignController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Details'
            }
        });
		
		$stateProvider.state('app.fbcampaignsummary', {
            url: '/fbcampaignsummary',
            templateUrl: 'app/modules/facebook/campaignsummary.html',
            controller: 'campaignSummaryController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Summary'
            }
        });
		
		$stateProvider.state('app.fbcampaigntemplate', {
            url: '/fbcampaigntemplate',
            templateUrl: 'app/modules/facebook/campaigntemplate.html',
            controller: 'campaigntemplateController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Template'
            }
        });
		
		//** Boost your post objective states */
		$stateProvider.state('app.bypcampaignaudience', {
            url: '/bypcampaignaudience',
            templateUrl: 'app/modules/facebook/boostyourposts/views/campaignaudience.html',
            controller: 'bypcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.bypcampaignplan', {
            url: '/bypcampaignplan',
            templateUrl: 'app/modules/facebook/boostyourposts/views/campaignplan.html',
            controller: 'bypcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.bypcampaigncreative', {
            url: '/bypcampaigncreative',
            templateUrl: 'app/modules/facebook/boostyourposts/views/campaigncreative.html',
            controller: 'bypcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		//** Promote your page states */
		$stateProvider.state('app.pypcampaignaudience', {
            url: '/pypcampaignaudience',
            templateUrl: 'app/modules/facebook/promoteurpage/views/campaignaudience.html',
            controller: 'pypcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.pypcampaignplan', {
            url: '/pypcampaignplan',
            templateUrl: 'app/modules/facebook/promoteurpage/views/campaignplan.html',
            controller: 'pypcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.pypcampaigncreative', {
            url: '/pypcampaigncreative',
            templateUrl: 'app/modules/facebook/promoteurpage/views/campaigncreative.html',
            controller: 'pypcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		
		
		//** Reach people near your business states*/
		
		$stateProvider.state('app.rpcampaignaudience', {
            url: '/rpcampaignaudience',
            templateUrl: 'app/modules/facebook/reachpeople/views/campaignaudience.html',
            controller: 'rpcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.rpcampaignplan', {
            url: '/rpcampaignplan',
            templateUrl: 'app/modules/facebook/reachpeople/views/campaignplan.html',
            controller: 'rpcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.rpcampaigncreative', {
            url: '/rpcampaigncreative',
            templateUrl: 'app/modules/facebook/reachpeople/views/campaigncreative.html',
            controller: 'rpcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		//** Increase brand awareness states*/
		
		$stateProvider.state('app.ibacampaignaudience', {
            url: '/ibacampaignaudience',
            templateUrl: 'app/modules/facebook/brandawareness/views/campaignaudience.html',
            controller: 'ibacampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.ibacampaignplan', {
            url: '/ibacampaignplan',
            templateUrl: 'app/modules/facebook/brandawareness/views/campaignplan.html',
            controller: 'ibacreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.ibacampaigncreative', {
            url: '/ibacampaigncreative',
            templateUrl: 'app/modules/facebook/brandawareness/views/campaigncreative.html',
            controller: 'ibacampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		
		//** Send people to your website states*/
		
		$stateProvider.state('app.spcampaignaudience', {
            url: '/spcampaignaudience',
            templateUrl: 'app/modules/facebook/sendpeople/views/campaignaudience.html',
            controller: 'spcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.spcampaignplan', {
            url: '/spcampaignplan',
            templateUrl: 'app/modules/facebook/sendpeople/views/campaignplan.html',
            controller: 'spcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.spcampaigncreative', {
            url: '/spcampaigncreative',
            templateUrl: 'app/modules/facebook/sendpeople/views/campaigncreative.html',
            controller: 'spcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		//** Get installs of your app */
			$stateProvider.state('app.apinstcampaignaudience', {
            url: '/apinstcampaignaudience',
            templateUrl: 'app/modules/facebook/appinstalls/views/campaignaudience.html',
            controller: 'apinstcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.apinstcampaignplan', {
            url: '/apinstcampaignplan',
            templateUrl: 'app/modules/facebook/appinstalls/views/campaignplan.html',
            controller: 'apinstcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.apinstcampaigncreative', {
            url: '/apinstcampaigncreative',
            templateUrl: 'app/modules/facebook/appinstalls/views/campaigncreative.html',
            controller: 'apinstcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		//** Raise attendance at your events */
			$stateProvider.state('app.eventscampaignaudience', {
            url: '/eventscampaignaudience',
            templateUrl: 'app/modules/facebook/raiseattendance/views/campaignaudience.html',
            controller: 'eventscampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.eventscampaignplan', {
            url: '/eventscampaignplan',
            templateUrl: 'app/modules/facebook/raiseattendance/views/campaignplan.html',
            controller: 'eventscreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.eventscampaigncreative', {
            url: '/eventscampaigncreative',
            templateUrl: 'app/modules/facebook/raiseattendance/views/campaigncreative.html',
            controller: 'eventscampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
			//** Get video views */
			$stateProvider.state('app.videocampaignaudience', {
            url: '/videocampaignaudience',
            templateUrl: 'app/modules/facebook/videoviews/views/campaignaudience.html',
            controller: 'videocampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.videocampaignplan', {
            url: '/videocampaignplan',
            templateUrl: 'app/modules/facebook/videoviews/views/campaignplan.html',
            controller: 'videocreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.videocampaigncreative', {
            url: '/videocampaigncreative',
            templateUrl: 'app/modules/facebook/videoviews/views/campaigncreative.html',
            controller: 'videocampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		//** Collect leads for your business states*/
		$stateProvider.state('app.leadscampaignaudience', {
            url: '/leadscampaignaudience',
            templateUrl: 'app/modules/facebook/leads/views/campaignaudience.html',
            controller: 'leadscampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.leadscampaignplan', {
            url: '/leadscampaignplan',
            templateUrl: 'app/modules/facebook/leads/views/campaignplan.html',
            controller: 'leadscreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.leadscampaigncreative', {
            url: '/leadscampaigncreative',
            templateUrl: 'app/modules/facebook/leads/views/campaigncreative.html',
            controller: 'leadscampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
		
		//** Increase conversions on website states */
		$stateProvider.state('app.convcampaignaudience', {
            url: '/convcampaignaudience',
            templateUrl: 'app/modules/facebook/conversions/views/campaignaudience.html',
            controller: 'convcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.convcampaignplan', {
            url: '/convcampaignplan',
            templateUrl: 'app/modules/facebook/conversions/views/campaignplan.html',
            controller: 'convcreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.convcampaigncreative', {
            url: '/convcampaigncreative',
            templateUrl: 'app/modules/facebook/conversions/views/campaigncreative.html',
            controller: 'convcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });

		
		//** Get people to claim your offer states */
		$stateProvider.state('app.offerscampaignaudience', {
            url: '/offerscampaignaudience',
            templateUrl: 'app/modules/facebook/offers/views/campaignaudience.html',
            controller: 'offerscampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            }
        });

		 $stateProvider.state('app.offerscampaignplan', {
            url: '/offerscampaignplan',
            templateUrl: 'app/modules/facebook/offers/views/campaignplan.html',
            controller: 'offerscreateCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            }
        });
				
		 $stateProvider.state('app.offerscampaigncreative', {
            url: '/offerscampaigncreative',
            templateUrl: 'app/modules/facebook/offers/views/campaigncreative.html',
            controller: 'offerscampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            }
        });
		
			//** Dynamic Forms **//
	
	    $stateProvider.state('app.dynamicforms', {
            url: '/dynamicforms',
            templateUrl: 'app/modules/dynamicforms/campaigndetails.html',
            controller: 'dynamnicampaigndetailcontroller',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Details'
            },
	       resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load(['app/modules/dynamicforms/campaigndetails.js','app/modules/dynamicforms/campaigntemplate.js']);
                    }]
            }
        });
		
		$stateProvider.state('app.dynamiccampaigndetails', {
            url: '/dynamiccampaigndetails',
            templateUrl: 'app/modules/dynamicforms/campaigndetails.html',
            controller: 'dynamnicampaigndetailcontroller',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Details'
            },
	       resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/campaigndetails.js');
                    }]
            }
        });
		
       $stateProvider.state('app.dynamnicbypcampaignaudience', {
            url: '/dynamnicbypcampaignaudience',
            templateUrl: 'app/modules/dynamicforms/boostyourposts/views/campaignaudience.html',
            controller: 'dynamnicbypcampaignaudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/boostyourposts/controllers/campaignaudience.js');
                    }]
            }
        });

		 $stateProvider.state('app.dynamnicbypcampaignplan', {
            url: '/dynamnicbypcampaignplan',
            templateUrl: 'app/modules/dynamicforms/boostyourposts/views/campaignplan.html',
            controller: 'dynamnicbypCampaignPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/boostyourposts/controllers/campaignplan.js');
                    }]
            }
        });
				
		 $stateProvider.state('app.dynamnicbypcampaigncreative', {
            url: '/dynamnicbypcampaigncreative',
            templateUrl: 'app/modules/dynamicforms/boostyourposts/views/campaigncreative.html',
            controller: 'dynamnicbypcampaigncreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign creative'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/boostyourposts/controllers/campaigncreative.js');
                    }]
            }
        });

        $stateProvider.state('app.dynamiccampaignsummary', {
            url: '/dynamniccampaignsummary',
            templateUrl: 'app/modules/dynamicforms/campaignsummary.html',
            controller: 'dynamiccampaignSummaryController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Campaign Summary'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/campaignsummary.js');
                    }]
            }
        });

		  $stateProvider.state('app.dynamicrpaudience', {
            url: '/dynamicrpaudience',
            templateUrl: 'app/modules/dynamicforms/reachpeople/views/campaignaudience.html',
            controller: 'dynamnicRPAudienceController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Audience'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/reachpeople/controllers/campaignaudience.js');
                    }]
            }
        });
		  $stateProvider.state('app.dynamicrpplan', {
            url: '/dynamicrpplan',
            templateUrl: 'app/modules/dynamicforms/reachpeople/views/campaignplan.html',
            controller: 'dynamicRPPlanController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Plan'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/reachpeople/controllers/campaignplan.js');
                    }]
            }
        });
		  $stateProvider.state('app.dynamicrpcreative', {
            url: '/dynamicrpcreative',
            templateUrl: 'app/modules/dynamicforms/reachpeople/views/campaigncreative.html',
            controller: 'dynamnicRPCreativeController',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Create Campaign Creative'
            },
			resolve: {
                loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        console.log($ocLazyLoad);
                        return $ocLazyLoad.load('app/modules/dynamicforms/reachpeople/controllers/campaigncreative.js');
                    }]
            }
        });
		
		

    }]);