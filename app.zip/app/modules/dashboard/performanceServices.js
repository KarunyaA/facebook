app.factory('performanceServices', ['$rootScope', '$http', '$q', 'appSettings', '$window', function($rootScope, $http, $q, appSettings, $window){

        var performanceServices = {};
        var wsBase = appSettings.apiBase;
        var imageServerBase = appSettings.apiImageServer;
        var facebookBase = appSettings.apiTPBase;
        var twitterBase = appSettings.apiTwitterBase;
        var fbNetwork = appSettings.fbNetwork;
        var twNetwork = appSettings.twNetwork;
        $rootScope.serviceResponses = {};
        var headerForGet = {
                headers: {
                'userId': '',
                'accessToken': ''
            }
        };
        var headerForPost = {
            headers: {
                'Content-Type': "application/json"
            }
        };
        
        var getUserIdAndAccessToken = function(userId,accessToken) {
            headerForGet.headers.userId = userId;
            headerForGet.headers.accessToken = accessToken;
        };

        var loadcurrencydata = function() {
            var deferred = $q.defer();
            var url = 'localData/currencyData.json';
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url).success(function (data){
                    if(data.appStatus == 0) {
                        $rootScope.serviceResponses[url] = data;
                    }
                    deferred.resolve(data);          
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var getaccountdetails = function (accountId) {
            var queryString = '/user/getaccountdetails?accountId=' + accountId;
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var downloadimages = function (filepaths) {
            var queryString = '/downloadimages';
            var searchString = '/downloadimages/' + filepaths;
            var deferred = $q.defer();
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths": [filepaths]
            };
            if($rootScope.serviceResponses.hasOwnProperty(searchString)) {
                deferred.resolve($rootScope.serviceResponses[searchString]);
            } else {
                $http.post(imageServerBase + queryString, parameters, headerForPost).success(function (response) {
                    $rootScope.serviceResponses[searchString] = response;
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var advertiserdatafetch = function(accountId) {
            var queryString = '/user/advertiserdatafetch?accountId=' + accountId;
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var fetchallnetwork = function() {
            var queryString = '/user/fetchallnetwork';
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var fetchadvertisernetwork = function(accountId) {
            var queryString = '/user/fetchadvertisernetwork?accountId=' + accountId;
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var readadaccounts = function(userNetworkMapId, network) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                var queryString = '/readadaccounts?networkMapId=' + userNetworkMapId;
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                var queryString = '/readadaccounts?userNetworkMapId=' + userNetworkMapId;
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var fetchparentcampaignsbyadvertiser = function(advertiserId) {
            var deferred = $q.defer();
            var queryString = '/user/fetchparentcampaignsbyadvertiser?advertiserId=' + advertiserId;
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var readadcampaign = function(userNetworkMapId, parentCampaignId, network, adAccountId) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                if(adAccountId==undefined && parentCampaignId!=undefined)
                {
                    var queryString = '/readadcampaign' + '?' + 'userNetworkMapId=' + userNetworkMapId + '&' + 'parentCampaignId=' + parentCampaignId;
                }
                else
                {
                    var queryString = '/readadcampaign' + '?' + 'userNetworkMapId=' + userNetworkMapId + '&' + 'networkAdAccountId=' + adAccountId;
                }
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                if(adAccountId==undefined && parentCampaignId!=undefined)
                {
                var queryString = '/readcampaign' + '?' + 'userNetworkMapId=' + userNetworkMapId + '&' + 'parentCampaignId=' + parentCampaignId;
                }
                else
                {
                var queryString = '/readcampaign' + '?' + 'userNetworkMapId=' + userNetworkMapId + '&' + 'adAccountId=' + adAccountId;  
                }
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var readlineitems = function(userNetworkMapId, adAccountId) {
            var deferred = $q.defer();
                var queryString = '/readlineitems' + '?' + 'userNetworkMapId=' + userNetworkMapId + '&' + 'adAccountId=' + adAccountId;
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                } 
            return deferred.promise;
        };
        var readadaccountsinsights = function(userNetworkMapId, adAccountId, from, to, breakDown, network, saveDecider) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                var queryString = '/readadaccountsinsights?userNetworkMapId=' +  userNetworkMapId + "&adAccountId=" + adAccountId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                var queryString = '/readadaccountsinsights?userNetworkMapId=' +  userNetworkMapId + "&adAccountId=" + adAccountId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var readadcampaigninsights = function(userNetworkMapId, adCampaignId, from, to, insightsDate, breakDown, network, saveDecider) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                var queryString = '/readadcampaigninsights?userNetworkMapId=' +  userNetworkMapId + "&adCampaignId=" + adCampaignId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to;
                    if(breakDown != undefined && breakDown != '' && breakDown != null) {
                        queryString = queryString + '&breakDown=' + breakDown;
                    }
                } else if (insightsDate != undefined && insightsDate != '' && insightsDate != null) {
                    queryString = queryString + '&insightsDate=' + insightsDate;
                }
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                var queryString = '/readadcampaigninsights?userNetworkMapId=' +  userNetworkMapId + "&adCampaignId=" + adCampaignId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to;
                    if(breakDown != undefined && breakDown != '' && breakDown != null) {
                        queryString = queryString + '&breakDown=' + breakDown;
                    }
                } else if (insightsDate != undefined && insightsDate != '' && insightsDate != null) {
                    queryString = queryString + '&insightsDate=' + insightsDate;
                }
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var getadaccountbudget = function(userNetworkMapId, adAccountId, from, to, breakDown, network, saveDecider) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                var queryString = '/getadaccountbudget?adAccountId=' + adAccountId + '&userNetworkMapId=' + userNetworkMapId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                var queryString = '/getadaccountbudget?adAccountId=' + adAccountId + '&userNetworkMapId=' + userNetworkMapId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var getcampaignbudget = function(userNetworkMapId, adCampaignIds, from, to, breakDown, network, saveDecider) {
            var deferred = $q.defer();
            if(network == fbNetwork) {
                var queryString = '/getadcampaignbudget?adCampaignId=' + adCampaignIds + '&userNetworkMapId=' + userNetworkMapId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = facebookBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            } else if (network == twNetwork) {
                var queryString = '/getadcampaignbudget?adCampaignId=' + adCampaignIds + '&userNetworkMapId=' + userNetworkMapId;
                if(from != undefined && to != undefined && from != '' && to != '' && from != null && to != null) {
                    queryString = queryString + "&fromDate=" + from + "&toDate=" + to + '&breakDown=' + breakDown;
                }
                var url = twitterBase + queryString;
                if($rootScope.serviceResponses.hasOwnProperty(url)) {
                    deferred.resolve($rootScope.serviceResponses[url]);
                } else {
                    $http.get(url , headerForGet).success(function (response) {
                        if(response.appStatus == 0 && saveDecider) {
                            $rootScope.serviceResponses[url] = response;
                        }
                        deferred.resolve(response);
                    }).catch(function (data) {
                        deferred.resolve(data);
                    });
                }
            }
            return deferred.promise;
        };
        
        var getreporttype = function () {
            var queryString = '/user/readreporttype';
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var getreportrunhistory = function (fromArchived , toArchived) {
            var queryString = '/user/readreportrunhistory';
            if (fromArchived != undefined && toArchived != undefined && fromArchived != "" && toArchived != "") {
               queryString = queryString + '?fromDate=' +fromArchived + '&toDate=' +toArchived;
            }
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        var readsubsription = function (reportTypes) {
            var queryString = '/user/readsubscriptions?reportId=' +reportTypes;
            var deferred = $q.defer();
            var url = wsBase + queryString;
            if($rootScope.serviceResponses.hasOwnProperty(url)) {
                deferred.resolve($rootScope.serviceResponses[url]);
            } else {
                $http.get(url , headerForGet).success(function (response) {
                    if(response.appStatus == 0) {
                        $rootScope.serviceResponses[url] = response;
                    }
                    deferred.resolve(response);
                }).catch(function (data) {
                    deferred.resolve(data);
                });
            }
            return deferred.promise;
        };
        
        performanceServices.getaccountdetails = getaccountdetails;
        performanceServices.downloadimages = downloadimages;
        performanceServices.advertiserdatafetch = advertiserdatafetch;
        performanceServices.fetchallnetwork = fetchallnetwork;
        performanceServices.fetchadvertisernetwork = fetchadvertisernetwork;
        performanceServices.readadaccounts = readadaccounts;
        performanceServices.fetchparentcampaignsbyadvertiser = fetchparentcampaignsbyadvertiser;
        performanceServices.readadcampaign = readadcampaign;
        performanceServices.readadcampaigninsights = readadcampaigninsights;
        performanceServices.getcampaignbudget = getcampaignbudget;
        performanceServices.readadaccountsinsights = readadaccountsinsights;
        performanceServices.getadaccountbudget = getadaccountbudget;
        performanceServices.loadcurrencydata = loadcurrencydata;
        performanceServices.getUserIdAndAccessToken = getUserIdAndAccessToken;
        performanceServices.readlineitems = readlineitems;
        performanceServices.getreporttype = getreporttype;
        performanceServices.getreportrunhistory = getreportrunhistory;
        performanceServices.readsubsription = readsubsription;
        return performanceServices;
}]);