dashboard.directive('errorPopup', ['facebookGetPost', '$window', '$filter', '$timeout', '$state', 'appSettings', '$q', '$animate', 'apiService', '$sce', 'globalData', function (facebookGetPost, $window, $filter, $timeout, $state, appSettings, $q, $animate, apiService, $sce, globalData) {
        return{
            restrict: 'E',
            templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/errorPopup.html',
            transclude: true,
            scope: {
                data: "="
            },
            link: function (scope, element, attr) {

                scope.data = {
                    errorpopupHeading: "",
                    errorMsg: ""
                }

                scope.showPopup = function () {
                    scope.popFlag = true;
                    //scope.$root.progressLoader = "none";
                    angular.element($('body').css("overflow-y", "scroll"))
                    scope.$emit('progressLoader', {value: "none"});
                    scope.editAdsetErrorMsg = "block";
                }



                scope.resetSelection = function () {

                    //scope.$root.progressLoader = "none";
                    scope.$emit('progressLoader', {value: "none"});
                    angular.element($('body').css("overflow-y", "scroll"));
                    scope.failure_update_popup = false;
                    scope.editAdsetErrorMsg = "none";
                }


                scope.$on('errorpopupdata', function (event, args) {
                    console.log(args);
                    scope.data.errorpopupHeading = args.title;
                    scope.data.errorMsg = args.message;

                    scope.showPopup();

                })

            }
        }
    }]);