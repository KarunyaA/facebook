var dynamicForm = angular.module('app', ['replicator', 'dashboard']);
dynamicForm.controller("dynamnicampaigndetailcontroller", ['$rootScope', '$scope', '$http', '$state', '$location', 'loginService', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', '$filter', '$timeout', 'netWorkData', 'facebookGetPost',
    function ($rootScope, $scope, $http, $state, $location, loginService, Flash, apiService, $window, appSettings, globalData, $filter, $timeout, netWorkData, facebookGetPost) {

        var vm = this;
        vm.getData = {};
        console.log(vm)
        $scope.editAdsetErrorMsg = 'none';
        $scope.firstActiveDiv = 'yes';

        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.data = {};
        $scope.comVar = {};
        $scope.objective = ""
        $scope.campaignName = ""
        $scope.isRequired = '';
        $scope.testVar = "Test Var"
        $scope.config = {};
        var apiTPBase = appSettings.apiTPBase;

        $scope.path = "../CNAP_UI_Repo/";
        $scope.pageContent = {};
        $scope.stepTitleContent = {}

        $scope.errorpopupdata = {
            popupTitle: "",
            popupMessage : ""
        }
        //$window.localStorage.setItem("parentCampaignId", "12");

        $scope.selected = function (value) {
            vm.getData.objective = value;
            //console.log(vm.getData.objective);
        }
        function process(key, value) {

            $scope.data[key] = value;
            //console.log($scope.data);
            $scope.stepTitleContent[key] = value;

        }

        function traverse(o, func) {
            for (var i in o) {
                func.apply(this, [i, o[i]]);
                if (o[i] !== null && typeof (o[i]) == "object") {
                    //going one step down in the object tree!!
                    traverse(o[i], func);
                }
            }

        }
        $scope.$on('content', function () {
            alert('sdfsd');
            console.log($scope.pageContent[i])
        });
        $scope.$on('progressLoader', function (event , args) {
            
            $scope.progressLoader = args.value;
        });

        $scope.fetchData = function (details) {
            angular.forEach(details, function (val, key) {
                var JsonObj = details[key].fieldset.fields;
                $scope.config = details[key].fieldset.fields;
                var array = [];
                // console.log(JsonObj);
                for (var i in JsonObj) {
                    if (JsonObj.hasOwnProperty(i)) {
                        array[+i] = JsonObj[i];
                        $scope.pageContent[i] = array[+i];
                        //	console.log($scope.pageContent[i]);
                        //traverse(JsonObj[i],process);
                    }
                }

            });
            var campaignState = $window.localStorage.getItem("campaignState")
            if (campaignState == "edit") {
                $timeout(function () {
                    $scope.getEditCampaignDetails();
                    //alert('sassdf')
                }, 1000);

            }
        }
        $scope.loadLocalJson = function () {
            $http.get($scope.path + "app/modules/dynamicforms/data/details-form.json").success(function (data) {
                var details = data.campaignDetails;
                $scope.pageContent = data.campaignDetails;
                $scope.fetchData(details);
                angular.forEach(details, function (val, key) {
                    $scope['step' + (key + 1)] = details[key];
                    $scope.drawStepLine();
                });
            });
            /* var xmlPath =$scope.path + "app/modules/dynamicforms/data/details-form.xml"
             $http.get(xmlPath,  
             {  
             transformResponse: function(cnv)  
             {  
             var x2js = new X2JS();  
             var aftCnv = x2js.xml_str2json(cnv);  
             return aftCnv;  
             }  
             }).success(function(response)  
             {  
             console.log(response.root.campaignDetails);  
             var details = response.root.campaignDetails;
             $scope.pageContent= response.root.campaignDetails;
             $scope.fetchData(details);
             angular.forEach(details, function (val, key){
             $scope['step'+(key+1)]= details[key];				   
             $scope.drawStepLine();
             });
             
             });   */




        }
        $scope.drawStepLine = function () {
            var everythingLoaded = setInterval(function () {
                if (/loaded|complete/.test(document.readyState)) {
                    clearInterval(everythingLoaded);
                    $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                    $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                    var offsetHeight2 = document.getElementById('step2container').offsetHeight;
                    var fStep = $(".vr");
                    fStep.css('height', (($scope.lsValue - $scope.fsValue) - (offsetHeight2 + 22)));
                }
            }, 1000);
        }

        $scope.data = 'none';
        $scope.add = function () {
            var xmlPath = $scope.path + "app/modules/dynamicforms/data/details-form.xml"
            /* $http.get($scope.path + "app/modules/dynamicforms/data/details-form.xml").success(function (data){
             
             console.log(data.facebook);
             
             }); */

            $http.get(xmlPath,
                    {
                        transformResponse: function (cnv)
                        {
                            var x2js = new X2JS();
                            var aftCnv = x2js.xml_str2json(cnv);
                            return aftCnv;
                        }
                    }).success(function (response)
            {
                console.log(response.root.campaignDetails);
            });

        };

        $scope.init = function () {
            $scope.loadLocalJson();
            // $scope.add();



        }
        $scope.getEditCampaignDetails = function () {
            var campaignStatus = $rootScope.campaignStatus;
            var campaignId = $window.localStorage.getItem("campaignId")
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&adCampaignId=" + campaignId;

            facebookGetPost.readadcampaign(queryStr, headers).then(function (response) {
                console.log(response);
                $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                if (response.data.appStatus == '0') {
                    $scope.campaignDetails = globalData.getKeyValues(response, campaignId)
                    console.log($scope.campaignDetails)
                    vm.getData.objective = $scope.campaignDetails.campaignDetails.objective;
                    vm.getData.campaignName = $scope.campaignDetails.campaignDetails.name;
                    console.log(vm.getData.objective);
                    $scope.objective = $scope.campaignDetails.campaignDetails.objective;
                    $scope.name = $scope.campaignDetails.campaignDetails.name;


                } else {

                }


            })
        }

        $scope.init()


        $scope.$watch('vm.getData.objective', function (newVal, oldVal) {
            console.log(newVal);
            if (newVal) {
                $window.localStorage.setItem("marketingObjective", newVal);
                $scope.objectiveFlag = true;
                var SObj = $filter('filter')($scope.objectiveArray, function (d) {
                    return d.Key === newVal;
                }, true)[0];
                $window.localStorage.setItem("marketingObjectiveName", SObj.Value);
                angular.element('#step1').css('background-color', '#95D2B1');
                angular.element('.is-div-disabled').css('pointer-events', 'auto');
            }
        }, true)

        $scope.$watch('vm.getData.campaignName', function (newVal, oldVal) {
            if (newVal) {
                $scope.nameFlag = true;
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#mandatory').removeClass("required");
            } else {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element('#mandatory').addClass("required");
            }
        }, true)

        $scope.objectiveArray = [
            {Key: "APP_INSTALLS", Value: "Get installs of your app"},
            {Key: "BRAND_AWARENESS", Value: "Increase brand awareness"},
            {Key: "EVENT_RESPONSES", Value: "Raise attendance at your events"},
            {Key: "CANVAS_APP_ENGAGEMENT", Value: "Increase engagements on your app"},
            {Key: "LEAD_GENERATION", Value: "Collect leads for your business"},
            {Key: "LINK_CLICKS", Value: "Send people to your website"},
            {Key: "OFFER_CLAIMS", Value: "Get people to claim your offer"},
            {Key: "CONVERSIONS", Value: "Increase conversions on website"},
            {Key: "PAGE_LIKES", Value: "Promote your page"},
            {Key: "POST_ENGAGEMENT", Value: "Boost your posts"},
            {Key: "REACH", Value: "Reach people near your business"},
            {Key: "VIDEO_VIEWS", Value: "Get video views"}

        ];

        $scope.gotoParentCampaign = function () {
            $rootScope.freezeFlag = false;
        }
        $scope.moveNextStep = function () {
            //$state.go('app.dynamnicbypcampaignaudience');
            $rootScope.campaignSteps[0] = true;
            if ($window.localStorage.getItem("marketingObjective") == "POST_ENGAGEMENT") {
                $state.go('app.dynamnicbypcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                $state.go('app.pypcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "REACH") {
                $state.go('app.dynamicrpaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "BRAND_AWARENESS") {
                $state.go('app.ibacampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "LINK_CLICKS") {
                $state.go('app.spcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "APP_INSTALLS") {
                $state.go('app.apinstcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "EVENT_RESPONSES") {
                $state.go('app.eventscampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "VIDEO_VIEWS") {
                $state.go('app.videocampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "LEAD_GENERATION") {
                $state.go('app.leadscampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "CONVERSIONS") {
                $state.go('app.convcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "OFFER_CLAIMS") {
                $state.go('app.offerscampaignaudience');
            }
        }
        function saveCampaignDataToLocalDB(response, campaignId) {

            var networkMapId = $window.localStorage.getItem("userNetworkMapId");
            var sTime = response.start_time;
            if (response.start_time.indexOf('1970') == 0) {
                sTime = response.updated_time;
            }
            var parentId = $window.localStorage.getItem("parentID");
            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": networkMapId,
                "parentCampaignId": parentId,
                "adAccountId": response.account_id,
                "campaignId": campaignId,
                "campaignDetails": {
                    "id": campaignId,
                    "account_id": response.account_id,
                    "buying_type": "AUCTION",
                    "can_use_spend_cap": true,
                    "configured_status": "PAUSED",
                    "created_time": response.created_time,
                    "effective_status": "PAUSED",
                    "name": response.name,
                    "objective": response.objective,
                    "spend_cap": "5000000",
                    "start_time": sTime,
                    "status": "PAUSED",
                    "updated_time": response.updated_time
                }
            }
            facebookGetPost.savecampaigndata("", parameters).then(function (response) {

                if (response.data.appStatus == '0') { // success
                    $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                    $scope.moveNextStep();
                } else { // failed
                    $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                    $scope.popupTitle = "Error";
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.message;
                    } else {
                        $scope.popupMessage = response.data.errorMessage;
                    }
                    $scope.$broadcast('errorpopupdata', {
                        id: "errorpopupdata", title: $scope.popupTitle , message: $scope.popupMessage
                    })
                }

            });

        }
        $scope.getCampaignDetailsFromFB = function () {
            var headers = {
                "userId": $scope.userId,
                "accessToken": $scope.accessToken
            }
            var queryStr = "?campaignId=" + $window.localStorage.getItem('campaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            facebookGetPost.getcampaignbycampaignid(queryStr, headers).then(function (response) {
                console.log(response)
                if (response.data.appStatus == '0') { // success
                    saveCampaignDataToLocalDB(response.data.campaign, $window.localStorage.getItem('campaignId'))

                } else { // failed
                    $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                    $scope.popupTitle = "Error";
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.message;
                    } else {
                        $scope.popupMessage = response.data.errorMessage;
                    }
                    $scope.$broadcast('errorpopupdata', {
                        id: "errorpopupdata", title: $scope.popupTitle , message: $scope.popupMessage
                    })
                }
            })
        }
        $scope.createCampaign = function () {
            $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"block"});
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "networkAdAccountId": $window.localStorage.getItem("networkAdAccountId"),
                "campaignStatus": "PAUSED",
                "objective": vm.getData.objective,
                "campaignName": vm.getData.campaignName
            }

            facebookGetPost.createcampaign("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response)
                    var campId = response.data.campaignId;
                    $window.localStorage.setItem('campaignId', campId)
                    $scope.getCampaignDetailsFromFB();

                } else {
                    $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                    $scope.popupTitle = "Error";
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.message;
                    } else {
                        $scope.popupMessage = response.data.errorMessage;
                    }
                    $scope.$broadcast('errorpopupdata', {
                        id: "errorpopupdata", title: $scope.popupTitle , message: $scope.popupMessage
                    })
                }

            })

        }

    }])
