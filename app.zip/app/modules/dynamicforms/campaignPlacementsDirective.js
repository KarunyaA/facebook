dashboard.directive('campaignPlacements',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/placements.html',	
	transclude:true,
	scope:{
		data:"="
	},
	link:function(scope,element,attr){

	scope.data = {
                 regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]			
			}
		scope.init = function(){
	          //default placement selection
          
		  var campaignState = $window.localStorage.getItem("campaignState");
		  if(campaignState == "create"){
			    scope.data.campaignAudiencePlacementsWiFi = "1";              
                scope.data.placementsValues.push('desktoprightcolumn');
                scope.data.placementsValues.push('desktopnewsfeed');
                $window.localStorage.setItem("campaignAudienceplacementsValues", scope.data.placementsValues);
                angular.element('#step3').css('background-color', '#95D2B1');
		  }	
		}



  scope.setCheckedVal = function (val, condition) {
            var idxx = scope.data.placementsValues.indexOf(val);
            if (idxx > -1 && condition == 'insert') {
                scope.data.placementsValues.splice(idxx, 1);
            } else {
                scope.data.placementsValues.push(val);
            }

            //REMOVE DUPLICATION
            var count = 0;
            var unique = function (origArr) {
                var newArr = [],
                        origLen = origArr.length,
                        found, x, y;
                for (x = 0; x < origLen; x++) {
                    found = undefined;
                    for (y = 0; y < newArr.length; y++) {
                        if (origArr[x] === newArr[y]) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        newArr.push(origArr[x]);
                        if (newArr[x] == "mobilenewsfeed") {
                            scope.data.campaignAudienceMobileDevice = "All mobile devices"
                            count = 1;
                        }
                    }
                }
                return newArr;
            }

            scope.data.placementsValues = unique(scope.data.placementsValues);
            if (scope.data.placementsValues.length == 0) {
                angular.element('#step3').css('background-color', '#c2c2c2');
            } else {
                angular.element('#step3').css('background-color', '#95D2B1');
            }

            if (count == 1) {
                scope.data.mobileView = true;
            } else {
                scope.data.mobileView = false;
                scope.data.campaignAudienceMobileDevice = '';
            }
            if (condition == 'insert') {
                scope.$root.freezeFlag = true;
                scope.$root.overLayAudience = true;
            }
            ;
            $window.localStorage.setItem("campaignAudienceplacementsValues", scope.data.placementsValues);
        };




        //var arrayVal=[];
        scope.device_platforms = [];
        scope.facebook_positions = [];
        scope.publisher_platforms = [];
        scope.instagram_positions = [];

        scope.setPlacements = function (val) {
            //console.log(val);

            if (val == 'mobilenewsfeed') {

                scope.device_platforms.push("mobile");
                scope.facebook_positions.push("feed");
                scope.publisher_platforms.push("facebook");

            } else if (val == 'desktopnewsfeed') {

                scope.device_platforms.push("desktop");
                scope.facebook_positions.push("feed");
                scope.publisher_platforms.push("facebook");

            } else if (val == 'desktoprightcolumn') {

                scope.device_platforms.push("desktop");
                scope.publisher_platforms.push("facebook");
                scope.facebook_positions.push("right_hand_column");

            } else if (val == 'instagram') {

                scope.publisher_platforms.push("instagram");
                scope.instagram_positions.push("stream");
                scope.device_platforms.push("mobile", "desktop");

            } else if (val == 'audiencenetwork') {

                scope.publisher_platforms.push("facebook", "audience_network");
                scope.facebook_positions.push("feed");
                scope.device_platforms.push("mobile", "desktop");

            }
            //REMOVE DUPLICATION
            var unique = function (origArr) {
                var newArr = [],
                        origLen = origArr.length,
                        found, x, y;
                for (x = 0; x < origLen; x++) {
                    found = undefined;
                    for (y = 0; y < newArr.length; y++) {
                        if (origArr[x] === newArr[y]) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        newArr.push(origArr[x]);
                    }
                }
                return newArr;
            }

            scope.device_platforms = unique(scope.device_platforms);
            scope.facebook_positions = unique(scope.facebook_positions);
            scope.publisher_platforms = unique(scope.publisher_platforms);
            scope.instagram_positions = unique(scope.instagram_positions);


            scope.data.placementsKeyValues = {
                "device_platforms": scope.device_platforms,
                "facebook_positions": scope.facebook_positions,
                "publisher_platforms": scope.publisher_platforms,
                "instagram_positions": scope.instagram_positions
            }

            //console.log('PlacementsKeyValues : $$$$$');
            //console.log(scope.PlacementsKeyValues);
        };



        scope.setWiFi = function (val) {
            if (val) {
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", val);
            } else {
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", val);
            }
        }



        scope.sendcampaignAudienceMobileDevice = function (campaignAudienceMobileDevice) {
            scope.data.campaignAudienceMobileDevice = campaignAudienceMobileDevice;
            $window.localStorage.setItem("campaignAudienceMobileDevice", scope.data.campaignAudienceMobileDevice);
            angular.element('#step3').css('background-color', '#95D2B1');
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
        }


        //MOBILE CAMPAIGN PLACEMENTS ARRAY DETAILS
        if ($window.localStorage.getItem("marketingObjective") == 'POST_ENGAGEMENT' || $window.localStorage.getItem("marketingObjective") == 'REACH') {
            scope.data.PlacementsArr = {
                "data":
                        [
                            {
                                "name": "Mobile News Feed",
                                "id": "mobilenewsfeed",
                                "pic": "fa fa-mobile"
                            },
                            {
                                "name": "Desktop News Feed",
                                "id": "desktopnewsfeed",
                                "pic": "fa fa-desktop"
                            },
                            {
                                "name": "Desktop Right Column",
                                "id": "desktoprightcolumn",
                                "pic": "fa fa-desktop"
                            }
                        ]
            };
            scope.data.MobileDeviceArr = {
                "data":
                        [
                            {
                                "name": "All mobile devices",
                                "id": "allmobiledevices"
                            },
                            {
                                "name": "Android devices only",
                                "id": "Android"
                            },
                            {
                                "name": "IOS devices only",
                                "id": "iOS"
                            },
                            {
                                "name": "Feature phones only",
                                "id": "Feature_Phone"
                            }
                        ]
            };
            scope.data.campaignAudienceMobileDevice = 'All mobile devices';
        }

		
		scope.init();

		scope.$on('placementsData', function (event,args) {
			 console.log(args);
				if(args.id == "mobileData"){
					scope.data.campaignAudienceMobileDevice= args.value;
					//scope.data.mobileView=args.value.mobileView;
					//scope.data.campaignAudiencePlacementsWiFi= args.value.campaignAudiencePlacementsWiFi;
				}
				else if(args.id =="placements"){
					scope.data.placementsValues= args.value.placementsValues;
				}else if(args.id =="setValue"){
					   scope.setCheckedVal(args.placement,args.value);
				}else if(args.id == "setPlacements"){;
				     scope.setPlacements(args.value);
			       }else if(args.id == "mobileView"){
					   scope.data.campaignAudienceMobileDevice= args.value.campaignAudienceMobileDevice;
					   scope.data.mobileView=args.value.mobileView;
				   }else if(args.id =="wifi"){
					   scope.data.campaignAudiencePlacementsWiFi= args.value.campaignAudiencePlacementsWiFi;
				   }
		  	
		}) 
		
}

}
}]);