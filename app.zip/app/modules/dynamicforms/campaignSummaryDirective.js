dashboard.directive('campaignSummary',['facebookGetPost','$window','$filter',function(facebookGetPost,$window,$filter){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/campaignSummaryTemplate.html',	
	transclude:true,
	scope:true,
	link:function(scope,element,attr){
		
		
	}
}


}]);