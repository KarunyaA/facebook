dashboard.directive('creativeUpload',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/creativeUploadTemplate.html',	
	transclude:true,
	scope:true,
	link:function(scope,element,attr){
		 var vm = this;
		 vm.getData = {};
		 var apiTPBase = appSettings.apiTPBase;		 
         scope.inputTypeFile = true; // TO be removed
		 scope.browselibraryvideos = "none";
		 scope.isFormDirty="";
		 
		//*** Browse Library - Image API calls ***/
        scope.getAdAccountAdCreative = function () {
            scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
            if(!scope.isFormDirty) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
           
             angular.element($('.panel-collapse.collapse.in').removeClass("in"));     
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            var queryStr = "?adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            scope.browselibrary = "none";
            scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"));
            scope.uniqueArray = "";

            facebookGetPost.getadimages(queryStr, headers).then(function (response) {              
                if (response.data.appStatus == '0') {// success
                    scope.mainLoader = "none";
                    scope.browselibrary = "block";
                    var arrAdAccountCreativeallData = [];

                    angular.forEach(response.data.adImages, function (v, k) {
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if (JsonObj[i]) {
                                var s_images = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
                    scope.uniqueArray = scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
					console.log(scope.uniqueArray);
                } else {
                   //scope.$root.progressLoader = "none";
					scope.mainLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
						//scope.$emit('imagefields',{id:"showerror",value:response});
                    }
                }
            });           
        }
		
		//*** Browse Library - Image Selection in Popup ***/
        scope.changeSelection = function (image_hash) {
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
            }
        }
		
		//** Browse Library - Image Done button **/
		 scope.getBrowseLibraryImagekey = function (data) {
            scope.imagesSource = data.imageSources;
            console.log(scope.imagesSource);
            if (scope.imagesSource === undefined) {
                console.log('Choose one from library');
                return true;
            }
			// scope.$emit('imagefields',{id:"createadcreative",value:scope.imagesSource});
             scope.creativeAdCreative(scope.imagesSource);
             angular.element($('body').css("overflow-y", "scroll"));
             scope.browselibrary = "none";
        }

		//** Upload Image functionality **/
		
        scope.getCampaignfiles = function (element) {
            if (element.files[0] != undefined) {
                scope.deleteImgThumbnail();
                angular.element($('.panel-collapse.collapse.in').removeClass("in"));
                if (scope.textBodyContent == "") {
                    document.getElementById("textBodyContent").style.borderColor = "#ff0000";
                    window.scrollTo(0, document.body.scrollHeight);
                    scope.errTextMsg = "block";
                    angular.element($('.btnCampaignCreative').prop('disabled', true));                   
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                } else {
                    scope.$root.progressLoader = 'block';
                    document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
                    scope.errTextMsg = "none";
                    angular.element($('.btnCampaignCreative').prop('disabled', false));                  
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    scope.step2_green = true;
                    scope.$apply(function (scope) {
                        scope.$root.uploadedfilename = element.files[0];
                    });
                    console.log(scope.$root.uploadedfilename);
                    var reader = new FileReader();
                    reader.onload = function () {
                        scope.dataURL = reader.result;
                    };
                    $timeout(function () {                     
                        var parameters = new FormData();
                        parameters.append('userId', $window.localStorage.getItem("userId"));
                        parameters.append('accessToken', $window.localStorage.getItem("accessToken"));
                        parameters.append('userNetworkMapId', $window.localStorage.getItem("userNetworkMapId"));
                        parameters.append('type', 'IMAGE');
                        parameters.append('adAccountId', $window.localStorage.getItem("networkAdAccountId"));
                        parameters.append('imageFile', element.files[0]);
                        var headers = {
                            'Content-Type': undefined,
                            'dataType': 'jsonp',
                            'async': 'false'
                        }
                        var url = apiTPBase + "/createadimage";

                        if (typeof (element.files[0]) == "object") {
                            facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                                console.log(response);
                                scope.$root.progressLoader = 'none';
                                if (response.status == "200" && response.data.appStatus == 0) {
                                    scope.deleteImgThumbnail();
                                    scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                                    scope.hashUrl = response.data.adImageDetails.images.bytes.url;
                                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
                                    scope.creativeAdCreative(scope.hashVal);
									// scope.$emit('imagefields',{id:"createadcreative",value:scope.hashVal});
                                } else {
                                    scope.$root.progressLoader = "none";
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                                        scope.showErrorPopup(response);
										//scope.$emit('imagefields',{id:"showerror",value:response});
                                    }
                                }
                            });

                        }

                    }, 1000);
                    reader.readAsDataURL(element.files[0]);
                }//else
            }
        };
		
		
		
		//*** Delete Image Thumbnail ***/
		 scope.deleteImgThumbnail = function () {
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            scope.imgthumbnaildiv = false;
            //scope.deleteAdCreative();			
            angular.element('#step2').css('background-color', '#c2c2c2');
            angular.element('#step3').css('background-color', '#c2c2c2');
            angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
            angular.element('#collapseDesktop').removeClass('in');
            angular.element('#collapseTwo1').removeClass('in');
            angular.element('#collapseThree1').removeClass('in');
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        }

		//** Browse Library Video **/
		 scope.browseExistingVideos = function (element) {

            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

            if(!scope.isFormDirty) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            scope.browselibrary = "none";
            scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            scope.uniqueArray = "";

            facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                console.log(response);


                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    scope.mainLoader = "none";
                    scope.existVideosList = response.data.data;

                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function (v, k) {
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if (JsonObj[i]) {
                                var s_images = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });

                    scope.existVideosList = arrAdAccountCreativeallDataVideo;

                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
						//scope.$emit('imagefields',{id:"showerror",value:response});
                    }
                }

                scope.$root.progressLoader = "none";
                scope.browselibraryvideos = "block";
                //scope.existVideosList = response.data.adVideos;
            });
        };
		
		 //** Browse Library - Video Selection **/
		
		   scope.getExistingVideosID = function (videoID) {
            if (angular.element($("#" + videoID).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + videoID).parent(".galleryImages").addClass('sel_bk_color'));
            }

         }		
		 
		
		//** Browse Library - Video  Done button functionality**/
        scope.getBrowseLibraryVideoID = function (data) {
            scope.videoID = data.videoSources;
            scope.hashVal = data.videoSources;
            if (scope.videoID === undefined) {
                console.log('Choose one from library');
                return true;
            }

            scope.creativeAdCreative(scope.videoID);
		     //scope.$emit('imagefields',{id:"createadcreative",value:scope.videoID});
            scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
        };
		
		//** Upload Video functionality **/
        scope.getCampaignVideoFiles = function (element) {
            if (element.files[0] != undefined) {
                
			    scope.$root.progressLoader = 'block';
                scope.deleteVidThumbnail();
                console.log(element.files[0]);
                var parameters = new FormData();
                parameters.append('userId', $window.localStorage.getItem("userId"));
                parameters.append('accessToken', $window.localStorage.getItem("accessToken"));
                parameters.append('userNetworkMapId', $window.localStorage.getItem("userNetworkMapId"));
                parameters.append('adAccountId', $window.localStorage.getItem("networkAdAccountId"));
                parameters.append('source', element.files[0]);
                var headers = {
                    'Content-Type': undefined,
                    'dataType': 'jsonp',
                    'async': 'false'
                }
                var url = apiTPBase + "/createadvideo";

                if (typeof (element.files[0]) == "object") {

                    facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {
                        //console.log(response);					
                        if (response.data.appStatus == '0') {
                            scope.deleteVidThumbnail();
                            scope.newvideoID = response.data.adVideoId;
                            scope.callGetadvideos(scope.newvideoID);
                        } else {
                            scope.$root.progressLoader = "none";
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
                                scope.showErrorPopup(response);
								//scope.$emit('imagefields',{id:"showerror",value:response});
                            }
                        }
                    });
                }
		    }
		};
		//** To fetch uploaded video **/
		scope.callGetadvideos = function (newvideoID) {

            var modalErr = $(".video_error_popupcreative");
            modalErr.hide();

            $timeout(function () {
                var queryStr = "?adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&videoId=" + newvideoID;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                scope.mainLoader = "block";

                facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos, function (key, value) {
                            angular.forEach(key, function (adVideoID) {
                                if (newvideoID == adVideoID.id) {
                                    scope.pictureFormat = adVideoID.format;
                                    scope.videoStatus = adVideoID.status;
                                    angular.forEach(scope.pictureFormat, function (ulrVal) {
                                        if (ulrVal.filter == "native") {
                                            scope.imageURLValue = ulrVal.picture;
                                            //scope.videoSource = adVideoID.source;
                                        }
                                    });
                                }
                            })
                        });
                        scope.$root.progressLoader = 'none';
                        scope.checkCreatedVideoStatus(newvideoID);
                    } else {
                        scope.$root.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(response);
							//scope.$emit('imagefields',{id:"showerror",value:response});
                        }
                    }
                });

            }, 0);

        }
		
		//** To check uploaded video status ***/
        scope.checkCreatedVideoStatus = function (newvideoID) {
            scope.newvideoID = newvideoID;
            if (scope.videoStatus) {
                if (scope.videoStatus.video_status == "ready") {
                    console.log(scope.newvideoID + "|" + scope.imageURLValue);
                    scope.creativeAdCreative(scope.newvideoID + "|" + scope.imageURLValue);
					//var creativeID = scope.newvideoID + "|" + scope.imageURLValue ;
					// scope.$emit('imagefields',{id:"createadcreative",value:creativeID});
                } else if (scope.videoStatus.video_status == "error") {
                    scope.popupTitle = 'Error';
                    scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popupcreative");
                    modalErr.show();
                } else {
                    scope.popupTitle = 'Video Status Error';
                    scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popupcreative");
                    modalErr.show();
                
                }
            }
        }
		

		//*** Browse Library cancel functionality***/
		scope.closePopup = function () {
            scope.editAdsetErrorMsg = "none";
            scope.mainLoader = "none";
            scope.browseImgSuccessMsg = "none";
            scope.browselibrary = "none";
            scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
            vm.getData = {};
            if (scope.thumbnail != '' && scope.formatSelected == scope.fbadvertFormat) {
                if (scope.fbadvertFormat == "fbsingleimage") {
                    scope.imgthumbnaildiv = true;
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                } else if (scope.fbadvertFormat == "fbsinglevideo") {
                    scope.vidthumbnaildiv = true;
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                } else if (scope.fbadvertFormat == "fbslideshow") {
                    scope.slideShowCreate = false;
                    scope.slideShowSuccess = true;
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                }
            }
        }
		
		 //** Video Thumbnail delete function** /
		 scope.deleteVidThumbnail = function () {
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            scope.vidthumbnaildiv = false;            
            angular.element('#step2').css('background-color', '#c2c2c2');
            angular.element('#step3').css('background-color', '#c2c2c2');
            angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
            angular.element('#collapseDesktop').removeClass('in');
            angular.element('#collapseTwo1').removeClass('in');
            angular.element('#collapseThree1').removeClass('in');
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        }

		 scope.detectChange = function () {
            if (scope.$root.uploadedfilename == undefined) {
                console.log('no image');
                console.log('yes image');
                scope.$root.progressLoader = 'none';
				scope.formatSelected = $window.localStorage.getItem('formatSelected');
				scope.fbadvertFormat = $window.localStorage.getItem('fbadvertFormat');
                if (scope.thumbnail != '' && scope.formatSelected == scope.fbadvertFormat) {
                    if (scope.fbadvertFormat == "fbsingleimage") {
                        scope.imgthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if (scope.fbadvertFormat == "fbsinglevideo") {
                        scope.vidthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if (scope.fbadvertFormat == "fbslideshow") {
                        scope.slideShowCreate = false;
                        scope.slideShowSuccess = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    }
                }
            }
            else {
                console.log('yes image');
                scope.$root.progressLoader = 'none';
                if (scope.thumbnail != '' && scope.formatSelected == scope.fbadvertFormat) {
                    if (scope.fbadvertFormat == "fbsingleimage") {
                        scope.imgthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if (scope.fbadvertFormat == "fbsinglevideo") {
                        scope.vidthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if (scope.fbadvertFormat == "fbslideshow") {
                        scope.slideShowCreate = false;
                        scope.slideShowSuccess = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    }
                }
            }
            document.body.onfocus = null;
        }
        scope.getFocus = function () {
            scope.imgthumbnaildiv = false;
            $timeout(function () {
                document.body.onfocus = scope.detectChange();
            }, 1500);
        }

		
		//****** Slideshow functionalities*****////
		       //ENABLE SLIDESHOW POPUP
        scope.onSlideshowSuccess = false;
        scope.onCreateSlideShow = false;
        scope.addSlideshow = true;
        scope.previewSlideShowImage = false;
        scope.previewSlideShowVideo = false;
        scope.displaySelectedImages = false;
        scope.displaySelectedVideos = false;
        scope.displaySelectedImagesBtn = true;
        scope.displaySelectedVideosBtn = false;
        scope.aspectRatioOptions = [
            {
                "id": "Original",
                "name": "Original "
            },
            {
                "id": "Square",
                "name": "Square (1:1)"
            },
            {
                "id": "Rectangle",
                "name": "Rectangle (16:9)"
            },
            {
                "id": "Vertical",
                "name": "Vertical (2:3)"
            }
        ]

        scope.imageDurationOptions = [
            {
                "id": "0.5 seconds",
                "value": "500",
                "key": "0.5"
            },
            {
                "id": "1 seconds",
                "value": "1000",
                "key": "01"
            },
            {
                "id": "2 seconds",
                "value": "2000",
                "key": "02"
            },
            {
                "id": "3 seconds",
                "value": "3000",
                "key": "03"
            },
            {
                "id": "4 seconds",
                "value": "4000",
                "key": "04"
            },
            {
                "id": "5 seconds",
                "value": "5000",
                "key": "05"
            }
        ]


        scope.musicOptions = [
            {
                "id": "None",
                "name": "None"
            },
            {
                "id": "Chillwave",
                "name": "Chillwave"
            },
            {
                "id": "Dreamy",
                "name": "Dreamy"
            },
            {
                "id": "Timelapse",
                "name": "Timelapse"
            },
            {
                "id": "Space Trip",
                "name": "Space Trip"
            },
            {
                "id": "Dance",
                "name": "Dance"
            },
            {
                "id": "Workday",
                "name": "Workday"
            },
            {
                "id": "Longboard",
                "name": "Longboard"
            },
            {
                "id": "Jazzy Samba",
                "name": "Jazzy Samba"
            },
            {
                "id": "Electric Coconut",
                "name": "Electric Coconut"
            },
            {
                "id": "Action",
                "name": "Action"
            },
            {
                "id": "Happy Zone",
                "name": "Happy Zone"
            },
            {
                "id": "Garage Groove",
                "name": "Garage Groove"
            },
            {
                "id": "Blues Country",
                "name": "Blues Country"
            },
            {
                "id": "Wonder",
                "name": "Wonder"
            },
            {
                "id": "Wonder",
                "name": "Wonder"
            },
            {
                "id": "Homecoming",
                "name": "Homecoming"
            },
            {
                "id": "Good Memories",
                "name": "Good Memories"
            },
            {
                "id": "Swamp",
                "name": "Swamp"
            }

        ]
        scope.enableSlideShow = function () {
          //  if (!scope.frmCreateNewAdvert.$valid) {
           //     window.scrollTo(0, document.body.scrollHeight);
          //      return;
          //  }
            scope.showSlideShowBrowser = true;
            scope.aspectRatio = "Original";
            scope.imageDuration = "1000";
            scope.slideShowTransition = "none";
            scope.musicValue = "None";
            scope.onCreateSlideShow = true;
            scope.createSlideShowBrowser = true;
            var slideshowpopup = $(".creativeSlideShow");
            slideshowpopup.show();
            angular.element($('body').css("overflow-y", "hidden"));

        }

        scope.selectAspectRatio = function (selectedRatio) {

            console.log(selectedRatio);

        }
        scope.durationToBeDisplayed = [];
        scope.selectImageDuration = function (selectedDuration) {

            angular.forEach(scope.imageDurationOptions, function (getID) {
                if (selectedDuration == getID.value) {
                    scope.displayTime = getID.key;
                }
            })

            console.log(scope.displayTime);
            var display = 0;
            if (scope.displaySelectedImages) {

                if (scope.selectedSlideShowImages.length != 0) {
                    scope.durationToBeDisplayed = [];

                    for (i = 0; i < scope.selectedSlideShowImages.length; i++) {

                        display = parseFloat(display) + parseFloat(scope.displayTime);
                        var sampleVal = parseFloat(display.toFixed(2));
                        console.log(sampleVal);
                        if (sampleVal <= 9) {
                            sampleVal = "0:0" + sampleVal;
                        } else {
                            sampleVal = "0:" + sampleVal;
                        }
                        console.log(sampleVal);
                        scope.durationToBeDisplayed.push({"timeSlot": sampleVal});
                        console.log(scope.durationToBeDisplayed);
                    }
                } else {
                    scope.durationToBeDisplayed = [];
                    scope.displayTime = 1;
                    for (i = 0; i < scope.selectedSlideShowImages.length; i++) {

                        display = parseFloat(display) + parseFloat(scope.displayTime);
                        var sampleVal = parseFloat(display.toFixed(2));
                        console.log(sampleVal);
                        if (sampleVal <= 9) {
                            sampleVal = "0:0" + sampleVal;
                        } else {
                            sampleVal = "0:" + sampleVal;
                        }
                        console.log(sampleVal);
                        scope.durationToBeDisplayed.push({"timeSlot": sampleVal});
                        console.log(scope.durationToBeDisplayed);
                    }
                }
            } else if (scope.displaySelectedVideos) {

                if (scope.selectedSlideShowVideos.length != 0) {
                    scope.durationToBeDisplayed = [];

                    for (i = 0; i < scope.selectedSlideShowVideos.length; i++) {

                        display = parseFloat(display) + parseFloat(scope.displayTime);
                        var sampleVal = parseFloat(display.toFixed(2));
                        console.log(sampleVal);
                        if (sampleVal <= 9) {
                            sampleVal = "0:0" + sampleVal;
                        } else {
                            sampleVal = "0:" + sampleVal;
                        }
                        console.log(sampleVal);
                        scope.durationToBeDisplayed.push({"timeSlot": sampleVal});
                        console.log(scope.durationToBeDisplayed);
                    }
                } else {
                    scope.durationToBeDisplayed = [];
                    scope.displayTime = 1;
                    for (i = 0; i < scope.selectedSlideShowVideos.length; i++) {

                        display = parseFloat(display) + parseFloat(scope.displayTime);
                        var sampleVal = parseFloat(display.toFixed(2));
                        console.log(sampleVal);
                        if (sampleVal <= 9) {
                            sampleVal = "0:0" + sampleVal;
                        } else {
                            sampleVal = "0:" + sampleVal;
                        }
                        console.log(sampleVal);
                        scope.durationToBeDisplayed.push({"timeSlot": sampleVal});
                        console.log(scope.durationToBeDisplayed);
                    }
                }
            }
            //	scope.createSlideshow(); 


        }

        scope.selectMusic = function (selectedMusic) {

            console.log(selectedMusic);
        }


        scope.cancelSlideShow = function () {
            scope.showSlideShowBrowser = false;
            scope.addSlideshow = true;
            scope.createSlideShowBrowser = false;
            scope.showSelectImages = false;
            scope.showSelectVideos = false;
            scope.selectedSlideShowImages = [];
            scope.durationToBeDisplayed = [];
            scope.selectedImages = [];
            scope.selectedVideos = [];
            scope.selectedSlideShowVideos = [];
            scope.onCreateSlideShow = false;
            scope.previewSlideShowVideo = false;
            scope.previewSlideShowImage = false;
            scope.displaySelectedImagesBtn = true;
            scope.displaySelectedVideosBtn = false;
            angular.element($('body').css("overflow-y", "scroll"));
        }

        scope.slideShowBrowserImage = [];
        scope.getSlideShowImageBrowser = function () {

            console.log(scope.slideShowBrowser);
            scope.displaySelectedImages = true;
            scope.displaySelectedVideos = false;
            scope.displaySelectedImagesBtn = true;
            scope.displaySelectedVideosBtn = false;
            scope.selectedSlideShowVideos = [];
            scope.selectedVideos = [];
            scope.durationToBeDisplayed = [];
            scope.$root.progressLoader = "block";

            scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
          //  if (!scope.frmCreateNewAdvert.$valid) {
          //      window.scrollTo(0, document.body.scrollHeight);
         //       return;
         //   }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");


            var queryStr = "?adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            scope.browselibrary = "none";
            scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            scope.uniqueArray = "";

            facebookGetPost.getadimages(queryStr, headers).then(function (response) {             
                if (response.data.appStatus == '0') {// success
                    scope.showSelectImages = true;
                    scope.showSelectVideos = false;
                    var addImagesPopup = $(".selectImagesSlideshow");
                    addImagesPopup.show();
                    angular.element($('body').css("overflow-y", "scroll"));
                    scope.$root.progressLoader = "none";

                    scope.mainLoader = "none";
                    var arrAdAccountCreativeallData = [];

                    angular.forEach(response.data.adImages, function (v, k) {
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if (JsonObj[i]) {
                                var s_images = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        scope.slideShowBrowserImage = s_images;
                                    }

                                }

                            }
                        }
                    });
                    scope.slideShowImageArray = scope.removeDuplicates(arrAdAccountCreativeallData, "hash");


                } else {
					     scope.mainLoader = "none";
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });

        }

        scope.selectedImages = [];
        scope.selectedSlideShowImages = [];

        scope.getSelectedImages = function (image) {
            console.log(image);
            if (image.Selected) {
                if (scope.selectedImages.indexOf(image) == -1) {
                    scope.selectedImages.push(image);
                }

            } else {
                scope.selectedImages.splice(scope.selectedImages.indexOf(image), 1);
            }

        }
        scope.deleteSelectedImg = function (image) {
            if (scope.selectedSlideShowImages) {
                scope.selectedSlideShowImages.splice(scope.selectedSlideShowImages.indexOf(image), 1);
                $timeout(function () {
                    return $animate.enabled(false, angular.element('#slides_control').carousel({interval: scope.myInterval, cycle: true}));
                });
                scope.selectImageDuration(scope.imageDuration);
            }
            if (scope.selectedSlideShowVideos) {
                scope.selectedSlideShowVideos.splice(scope.selectedSlideShowVideos.indexOf(image), 1);
                $timeout(function () {
                    return $animate.enabled(false, angular.element('#slides_control').carousel({interval: scope.myInterval, cycle: true}));
                });
                scope.selectImageDuration(scope.imageDuration);

            }

        }

        scope.addSlideShowImages = function () {

            console.log("Add Images");
            console.log(scope.selectedSlideShowImages);
            scope.selectedSlideShowImages = angular.extend(scope.selectedSlideShowImages, scope.selectedImages);         
            scope.showSelectImages = false;
            scope.selectImageDuration(scope.imageDuration);
            angular.element($('body').css("overflow-y", "scroll"));
        }

        scope.addMoreSlideShowImages = function () {
            if (scope.selectedSlideShowImages.length > 0) {
                scope.showSelectImages = true;
                scope.showSelectVideos = false;
            } else if (scope.selectedSlideShowVideos.length > 0) {
                scope.showSelectVideos = true;
                scope.showSelectImages = false;
            }

            $timeout(function () {
                return $animate.enabled(false, angular.element('#slides_control').carousel({interval: scope.myInterval, cycle: true}));
            });

        }

        scope.cancelAddImages = function () {

            scope.showSelectImages = false;
            scope.selectImageDuration(scope.imageDuration);
            angular.element($('body').css("overflow-y", "scroll"));

        }


        scope.uploadSlideShowImage = function (uploadedFiles) {
            console.log(uploadedFiles);

            scope.$root.progressLoader = 'block';

            angular.element($('.btnCampaignCreative').prop('disabled', false));
            angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
            scope.$apply(function (scope) {
                scope.uploadedfilename = uploadedFiles.files[0];
            });
            var reader = new FileReader();
            reader.onload = function () {
                scope.dataURL = reader.result;
            };
            $timeout(function () {

                var parameters = new FormData();
                parameters.append('userId', $window.localStorage.getItem("userId"));
                parameters.append('accessToken', $window.localStorage.getItem("accessToken"));
                parameters.append('userNetworkMapId', $window.localStorage.getItem("userNetworkMapId"));
                parameters.append('type', 'IMAGE');
                parameters.append('adAccountId', $window.localStorage.getItem("networkAdAccountId"));
                parameters.append('imageFile', uploadedFiles.files[0]);
                var headers = {
                    'Content-Type': undefined,
                    'dataType': 'jsonp',
                    'async': 'false'
                }
                var url = apiTPBase + "/createadimage";

                if (typeof (uploadedFiles.files[0]) == "object") {
                    facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                        console.log(response);
                        scope.$root.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
                            scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                            scope.hashUrl = response.data.adImageDetails.images.bytes.url;

                            scope.getUploadedImage(response.data.adImageDetails.images.bytes.hash, scope.uploadedfilename);
                            /* var imageObj=
                             {
                             "thumbnail_url": scope.hashVal,
                             "url":scope.hashUrl,
                             "id":scope.uploadedfilename.name,
                             Selected:false
                             }
                             scope.slideShowImageArray.push(imageObj);*/

                        } else {
                            scope.$root.progressLoader = "none";
                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                            } else {
                                scope.showErrorPopup(response);
                            }
                        }
                    });

                }

            }, 1000);
            reader.readAsDataURL(uploadedFiles.files[0]);

        }

        scope.getUploadedImage = function (hashVal, uploadedfilename) {
            console.log(hashVal);
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + hashVal;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getadimages(queryStr, headers).then(function (response) {
                console.log(response);
                if (response.status == "200" && response.data.appStatus == '0') {

                    scope.mainLoader = "none";
                    console.log('image hash servic success');

                    var JsonObj = response.data.adImages[0];
                    var array = [];
                    for (var j in JsonObj) {
                        if (JsonObj.hasOwnProperty(j)) {
                            array[+j] = JsonObj[j];
                            console.log(JsonObj[j].url);
                            scope.imagePreviewSrc[i] = JsonObj[j].url;
                            console.log(i);
                            var imageObj =
                                    {
                                        "thumbnail_url": scope.imagePreviewSrc[i],
                                        "url": scope.imagePreviewSrc[i],
                                        "id": uploadedfilename.name,
                                        Selected: false
                                    }
                            scope.slideShowImageArray.push(imageObj);

                        }
                    }

                } else {
					     scope.mainLoader = "none";
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });


        }

        scope.pictureFormat = [];
        scope.getSlideshowVideos = function () {

            // var queryStr = "adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") +"&adVideoId="+scope.slideshowID;
            angular.element($('body').css("overflow-y", "hidden"))
            scope.uniqueArray = "";
            scope.$root.progressLoader = 'block';
            $timeout(function () {

                var promises = [];
                var queryStr = '/getadvideos?userNetworkMapId=' + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + scope.networkAdAccountId + "&videoId=" + scope.slideshowID;
                var headerVal = {
                    headers: {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    }
                };
                promises.push(apiService.getTp(queryStr, headerVal).then(function (resp) {
                    if (resp.appStatus == 0) {
                        scope.mainLoader = "none";
						 scope.$root.progressLoader = "none";
                        console.log(resp);
                        angular.forEach(resp.adVideos, function (key, value) {
                            angular.forEach(key, function (adVideoID) {
                                if (scope.slideshowID == adVideoID.id) {
                                    scope.pictureFormat = adVideoID.format;
                                    scope.videoStatus = adVideoID.status;
                                    angular.forEach(scope.pictureFormat, function (ulrVal) {
                                        if (ulrVal.filter == "native") {
                                            scope.imageURLValue = ulrVal.picture;
                                            scope.slideShowSource = adVideoID.source;
                                        }
                                    })
                                }
                            })
                        })

                        scope.generateSlideshowPreview(resp);
                    } else {
                        scope.$root.progressLoader = "none";
                        if (resp.appStatus > 0 && (resp.errorMessage == 'Access token is invalid or expired' || resp.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(resp);
                        }
                    }
                }));
                $q.all(promises).finally(function () {
                    console.log("PROMISE");
                    console.log(promises);
                    scope.$root.progressLoader = 'none';
                    scope.checkCreatedSlideStatus();
                });
            }, 0);

        }
        scope.checkCreatedSlideStatus = function () {

            if (scope.videoStatus) {
                if (scope.videoStatus.video_status == "ready") {
                    scope.slideShowCreate = false;
                    scope.slideShowSuccess = true;
                    scope.creativeAdCreative(scope.slideshowID);
					// scope.$emit('imagefields',{id:"createadcreative",value:scope.slideshowID});
                } else if (scope.videoStatus.video_status == "error") {
                    scope.slideShowCreate = true;
                    scope.slideShowSuccess = false;
                    scope.selectedSlideShowImages = [];
                    scope.cancelSlideShow();
                    scope.popupTitle = 'Video Status Error';
                    scope.popupMessage = "Error while fetching created slideshow ";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".error_popupcreative");
                    modalErr.show();
                } else if (scope.videoStatus.video_status == "processing") {
                    scope.slideShowCreate = false;
                    scope.slideShowSuccess = true;
                    scope.getSlideshowVideos();
                }
            }


        }

        scope.generateSlideshowPreview = function (response) {
            angular.forEach(response.adVideos, function (key, value) {
                angular.forEach(key, function (adVideoID) {
                    if (scope.slideshowID == adVideoID.id) {
                        scope.iFrameValue = adVideoID.format;
                        angular.forEach(scope.iFrameValue, function (ulrVal) {
                            if (ulrVal.filter == "native") {
                                scope.video_Source = ulrVal.picture;

                            }
                        })
                    }
                })
            })

            scope.slideShowPreview = scope.video_Source;
            scope.slideshowGIF = scope.video_GIF;       
        }


        scope.imageURL = [];
        scope.createImageSlideShow = function () {

            console.log(scope.selectedSlideShowImages);
            console.log(scope.imageDuration);
            console.log(scope.slideShowTransition);
            scope.imageURL = [];
            if (scope.selectedSlideShowImages.length > 0) {
                angular.forEach(scope.selectedSlideShowImages, function (images) {
                    if (images.url.includes("?")) {
                        scope.splicedVal = images.url.slice(0, images.url.indexOf("?"));
                        if (scope.imageURL.indexOf(scope.splicedVal) == -1) {
                            scope.imageURL.push(scope.splicedVal);
                        }
                    } else {
                        if (scope.imageURL.indexOf(images.url) == -1) {
                            scope.imageURL.push(images.url);
                        }
                    }
                })
            }
            if (scope.selectedSlideShowVideos.length > 0) {
                scope.imageURL = [];
                angular.forEach(scope.selectedSlideShowVideos, function (images) {
                    scope.videoURL = images.picture.slice(0, images.picture.indexOf("?"));
                    if (scope.imageURL.indexOf(scope.videoURL) == -1) {
                        scope.imageURL.push(scope.videoURL);
                    }
                })
            }

            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adAccountId": $window.localStorage.getItem("networkAdAccountId"),
                "slideShowSpec": {
                    "images_urls": scope.imageURL,
                    "duration_ms": scope.imageDuration,
                    "transition_ms": 200

                }
            };


            var promises = [];
            /* promises.push($http({
             method: 'POST',
             url: apiTPBase + '/createadslideshow',
             data: parameters,
             headers: {
             'Content-Type': "application/json"
             }
             }) */
            promises.push(facebookGetPost.createadslideshow("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response);
                    scope.slideshowID = response.data.adVideoId;                  
                    scope.showSlideshowSuccessPopup();
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            }));
            $q.all(promises).finally(function () {
                console.log("PROMISE");
                console.log(promises);
            });

        }
        scope.showSlideshowSuccessPopup = function () {           
            scope.onSlideshowSuccess = true;
            scope.showSlideShowBrowser = false;
            scope.popupTitle = "Slideshow Creation";
            scope.popupMessage = "Slideshow created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popupcreative");
            successReq.show();

        }

        scope.closeSlideshowSuccessPopup = function () {
            scope.onSlideshowSuccess = false;
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popupcreative");
            scope.networkErrorPopup = 'none';
            successReq.hide();
            scope.getSlideshowVideos();

            scope.showSlideShowBrowser = false;

        }

        //** Create slideshow **/
        scope.createSlideshow = function () {

            scope.myInterval = parseInt(scope.imageDuration);
            scope.activeSlide = 0;
            $timeout(function () {

                return $animate.enabled(false, angular.element('#slides_control').carousel({interval: scope.myInterval, cycle: true}));
            });
            scope.addSlideshow = false;
            if (scope.selectedSlideShowImages.length != 0) {

                scope.previewSlideShowImage = true;
                scope.previewSlideShowVideo = false;
                scope.createImageSlideShow();
            }
            if (scope.selectedSlideShowVideos.length != 0) {
                scope.previewSlideShowImage = false;
                scope.previewSlideShowVideo = true;
                scope.createImageSlideShow();
            }


            console.log(scope.selectedSlideShowImages);
            angular.element($('body').css("overflow-y", "scroll"));
        };

        scope.deleteSelectedSlide = function () {
            scope.slideShowSuccess = false;
            scope.slideShowCreate = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            angular.element('#step2').css('background-color', '#c2c2c2');
            angular.element('#step3').css('background-color', '#c2c2c2');
            angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
            angular.element('#collapseDesktop').removeClass('in');
            angular.element('#collapseTwo1').removeClass('in');
            angular.element('#collapseThree1').removeClass('in');
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        }
        //** Selected Slideshow image rearrangin code **/
        scope.onDropComplete = function (index, obj, evt) {

            if (scope.selectedSlideShowImages.length > 0) {
                var otherObj = scope.selectedSlideShowImages[index];
                var otherIndex = scope.selectedSlideShowImages.indexOf(obj);
                scope.selectedSlideShowImages[index] = obj;
                scope.selectedSlideShowImages[otherIndex] = otherObj;
                console.log(scope.selectedSlideShowImages);
            }
            if (scope.selectedSlideShowVideos.length > 0) {
                var otherObj = scope.selectedSlideShowVideos[index];
                var otherIndex = scope.selectedSlideShowVideos.indexOf(obj);
                scope.selectedSlideShowVideos[index] = obj;
                scope.selectedSlideShowVideos[otherIndex] = otherObj;
                console.log(scope.selectedSlideShowVideos);
            }
        }

//** Slideshow video code starts here **/				
        scope.slideShowVideoArray = []
        scope.getSlideShowVideoBrowser = function () {

            scope.displaySelectedImages = false;
            scope.displaySelectedVideos = true;
            scope.displaySelectedImagesBtn = false;
            scope.displaySelectedVideosBtn = true;
            scope.selectedSlideShowImages = [];
            scope.selectedImages = [];
            scope.durationToBeDisplayed = [];
            if (!scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            scope.$root.progressLoader = "block";

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId");
            scope.browselibrary = "none";
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            scope.uniqueArray = "";

            facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                console.log(response);

                scope.browseVideoArray = [];
                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    scope.mainLoader = "none";
                    scope.browseVideoArray = response.data.data;

                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function (v, k) {
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if (JsonObj[i]) {
                                var s_images = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });

                    scope.slideShowVideoArray = arrAdAccountCreativeallDataVideo;
                    scope.showSelectImages = false;
                    scope.showSelectVideos = true;
                    var addVideosPopup = $(".selectVideosSlideshow");
                    addVideosPopup.show();
                    angular.element($('body').css("overflow-y", "hidden"));


                } else {
					scope.mainLoader="none";
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }

                scope.$root.progressLoader = "none";
            });
        }


        scope.selectedSlideShowVideos = [];
        scope.selectedVideos = [];


        scope.getSelectedVideos = function (video) {
            console.log(video);
            if (video.Selected) {
                scope.selectedVideos.push(video);
            } else {
                scope.selectedVideos.splice(scope.selectedVideos.indexOf(video), 1);
            }

        }
        scope.addSlideShowVideos = function () {

            console.log("Add Videos");
            console.log(scope.selectedSlideShowVideos);          		
            scope.selectedSlideShowVideos = angular.extend(scope.selectedSlideShowVideos, scope.selectedVideos);
            scope.showSelectVideos = false;
            scope.selectImageDuration(scope.imageDuration);
            angular.element($('body').css("overflow-y", "scroll"));
        }

        scope.cancelAddVideos = function () {

            scope.showSelectVideos = false;
            scope.selectImageDuration(scope.imageDuration);
            angular.element($('body').css("overflow-y", "scroll"));

        }



        scope.uploadSlideShowVideo = function (element) {
            scope.$root.progressLoader = 'block';
            var parameters = new FormData();
            parameters.append('userId', $window.localStorage.getItem("userId"));
            parameters.append('accessToken', $window.localStorage.getItem("accessToken"));
            parameters.append('userNetworkMapId', $window.localStorage.getItem("userNetworkMapId"));
            parameters.append('adAccountId', $window.localStorage.getItem("networkAdAccountId"));
            parameters.append('source', element.files[0]);
            var headers = {
                'Content-Type': undefined,
                'dataType': 'jsonp',
                'async': 'false'
            }
            var url = apiTPBase + "/createadvideo";

            if (typeof (element.files[0]) == "object") {

                facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {

                    if (response.status == "200") {
                      //  scope.newvideoID = response.data.id;
						scope.newvideoID = response.data.adVideoId;
                       // scope.getUploadedvideos(response.data.id);
					   scope.getUploadedvideos(response.data.adVideoId);
                    } else {
                        scope.$root.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(response);
                        }
                    }

                });

            }

        }
        scope.getUploadedvideos = function (newvideoID) {
            console.log(newvideoID);
            var modalErr = $(".video_error_popupcreative");
            modalErr.hide();

            $timeout(function () {
                var queryStr = "?adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&videoId=" + newvideoID;
                scope.mainLoader = "block";
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }

                facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos, function (key, value) {
                            angular.forEach(key, function (adVideoID) {
                                if (newvideoID == adVideoID.id) {
                                    scope.pictureFormat = adVideoID.format;
                                    scope.videoStatus = adVideoID.status;
                                    if (scope.videoStatus) {
                                        if (scope.videoStatus.video_status == "ready") {

                                            angular.forEach(scope.pictureFormat, function (ulrVal) {
                                                if (ulrVal.filter == "native") {
                                                    var videoObj =
                                                            {
                                                                "picture": ulrVal.picture,
                                                                "id": adVideoID.id,
                                                                Selected: false
                                                            }
                                                    scope.slideShowVideoArray.push(videoObj);
                                                    console.log(scope.slideShowVideoArray);

                                                }
                                            });
                                        } else if (scope.videoStatus.video_status == "error") {
                                            scope.popupTitle = 'Error';
                                            scope.popupMessage = "Video Status Error";
                                            angular.element($('body').css("overflow-y", "hidden"))
                                            var modalErr = $(".error_popupcreative");
                                            modalErr.show();
                                        } else {
                                            scope.popupTitle = 'Video Status Error';
                                            scope.popupMessage = "processing error, would you like to continue...";
                                            angular.element($('body').css("overflow-y", "hidden"))
                                            var modalErr = $(".video_error_popupcreative");
                                            modalErr.show();

                                        }
                                    }

                                }
                            })
                        });
                        scope.$root.progressLoader = 'none';
                    } else {
						scope.mainLoader="none";
                        scope.$root.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(response);
                        }
                    }

                });

            }, 0);
        }
		
	   scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popupcreative");
            modalApproveReq.hide();
        }
		
	 scope.showPreviewThumbnail = function(args){
			    if (args.fbadvertFormat == "fbsingleimage") {
                        scope.thumbnail = args.thumbnail;
                        scope.thumbnailVideo = args.thumbnailVideo;
                        scope.thumbnailSlideshow =   args.thumbnailSlideshow;
                        scope.thumbnailCarousel =  args.thumbnailCarousel;
                        scope.imgthumbnaildiv =  args.imgthumbnaildiv;						
					} else if (args.fbadvertFormat == "fbsinglevideo") {
                        scope.thumbnail = args.thumbnail;
                        scope.thumbnailVideo = args.thumbnailVideo;
                        scope.thumbnailCarousel =  args.thumbnailCarousel;
                        scope.thumbnailSlideshow =  args.thumbnailSlideshow;
                        scope.vidthumbnaildiv = args.vidthumbnaildiv; 				
                    } else if (args.fbadvertFormat == "fbslideshow") {
                        scope.thumbnail = args.thumbnail;
                        scope.thumbnailVideo = args.thumbnailVideo;
                        scope.thumbnailSlideshow =  args.thumbnailSlideshow;
                        scope.thumbnailCarousel = args.thumbnailCarousel;
                        scope.slideShowCreate = args.slideShowCreate;
                        scope.slideShowSuccess = args.slideShowSuccess;
                        scope.slideShowPreview = args.slideShowPreview;
                    }
		   }
		   
		   	scope.showSuccessPopup = function () {
            //console.log('success popup here123');
            scope.popupTitle = "Assigning creative";
            scope.popupMessage = "Ad created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show();

        }
        scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            scope.networkErrorPopup = 'none';
            successReq.hide();


        }
		   
		   //** Create Ad Creative API Calls ***/
		   
	 scope.creativeAdCreative = function (imageHashVal) {
            scope.$root.progressLoader = "block";
            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
            if (isCreativeAdCreativeId) {
                scope.deleteAdCreative(imageHashVal);
                $window.localStorage.removeItem("adCreativeId");
                if ($window.localStorage.removeItem("deleteAdCreativeStatus")) {
                    scope.networkErrorPopup = 'block';
                    return;
                }
            } else {
                scope.proceedToCreateAdCreative(imageHashVal);
            }
        }

		
      scope.proceedToCreateAdCreative = function (imageHashVal) {
            scope.objid = imageHashVal.split('|')[0];
            scope.objurl = imageHashVal.split('|')[1];
            //console.log(scope.objurl);
            $window.localStorage.setItem("campaignMediaURL", scope.objurl);

            scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            //$window.localStorage.setItem("campaignHeadline", scope.campaignHeadline);

            scope.pageIdVal = scope.selectedTarget;
            //console.log(scope.marketingObjective);
            console.log(scope.fbadvertFormat);
            if (scope.fbadvertFormat == 'fbsingleimage') {
                if (scope.marketingObjective == "POST_ENGAGEMENT") {
                    scope.objectType = 'PHOTO';
                    scope.objectStorySpec = {
                         "page_id": scope.selectedTarget,						
                        "photo_data": {
                            "caption": scope.textBodyContent,
                            "image_hash": scope.objid
                        }
                    }

                }else if (scope.marketingObjective == "REACH") {
                    scope.objectType = "SHARE";
						scope.valAddWebsiteUrl = $window.localStorage.getItem("valAddWebsiteUrl");
                    if (scope.valAddWebsiteUrl) {
                        scope.objectStorySpec = {
                            "page_id": scope.pageIdVal,
                            "link_data": {
                                "link": scope.webURL,
                                "message": scope.textBodyContent,
                                "description":scope.newsfeedlinkdesc,
                                "name": scope.campaignHeadline,//"ADVIMEDIA SARL",
                                "image_hash": scope.objid,
                            }
                        }
                        if(scope.callToDirectionValue != "" && scope.callToDirectionValue != undefined && scope.callToDirectionValue != null)
                        {
                            var calltoaction = {
                                "call_to_action": {
                                    "type":scope.callToDirectionValue
                                }
                            };
                            scope.objectStorySpec.link_data = angular.extend({},scope.objectStorySpec.link_data,calltoaction);
                        }
                        if(scope.displayLink != "" && scope.displayLink != undefined && scope.displayLink != null)
                        {
                            var displink = {
                                "caption": scope.displayLink
                            };
                            scope.objectStorySpec.link_data = angular.extend({},scope.objectStorySpec.link_data,displink);
                        }
                    } else {
                        scope.objectStorySpec = {
                            "page_id": scope.pageIdVal,                          
                            "photo_data": {
                                "caption": scope.textBodyContent,
                                "image_hash": scope.objid,
                            }
                        };
                    }
                }

                $window.localStorage.setItem("campaignMediaFormat", "Single Image");
            } else if (scope.fbadvertFormat == 'fbsinglevideo') {
                if (scope.marketingObjective == "POST_ENGAGEMENT") {
                    scope.objectType = 'VIDEO';
                    scope.objectStorySpec = {
                     "page_id": scope.selectedTarget, 						
                        "video_data": {
                            "message": scope.textBodyContent,
                            "video_id": scope.objid,
                            "image_url": scope.objurl
                        }
                    }
                }
				else if (scope.marketingObjective == "REACH") {
                    scope.valAddWebsiteUrl = $window.localStorage.getItem("valAddWebsiteUrl");
                    scope.object_type = "VIDEO";				
					   if (scope.valAddWebsiteUrl == true) {                                     
                            scope.objectStorySpec = {
                                "page_id": scope.pageIdVal,
                                "video_data": {
                                    "video_id": scope.objid,
                                    "message": scope.textBodyContent,
                                    "link_description": scope.newsfeedlinkdesc,
                                    "title": scope.campaignHeadline,
                                    "call_to_action":
                                            {
                                                "type": scope.callToDirectionValue,
                                                "value":
                                                        {
                                                            "link_caption": scope.displayLink,
                                                            "link": scope.webURL,
//                                                            "link_description": scope.newsfeedlinkdesc,
                                                            "link_format": "VIDEO_LPP",
//                                                            "link_title": scope.campaignHeadline
                                                        }
                                            },
                                    "image_url": scope.objurl
                                }
                            }                    
                        scope.objectType = "VIDEO";
                    } else {
                        scope.objectStorySpec = {
                            "page_id": scope.pageIdVal,
                            "video_data": {
                                "video_id": scope.objid,
                                "message": scope.textBodyContent,
                                "image_url": scope.objurl

                            }
                        }
                        scope.objectType = "VIDEO";
                    }
                }
                $window.localStorage.setItem("campaignMediaFormat", "Single Video");
            } else if (scope.fbadvertFormat == 'fbslideshow') {
                scope.objectType = "VIDEO";
                if (scope.objurl) {
                    scope.imageURLValue = scope.objurl;
                }
                $window.localStorage.setItem("campaignMediaFormat", "Slideshow");
                scope.object_type = "VIDEO";
                if (scope.marketingObjective == "POST_ENGAGEMENT") {
                    scope.objectStorySpec = {
                         "page_id": scope.pageIdVal, 						
                        "video_data": {
                            "message": scope.textBodyContent,
                            "video_id": scope.objid,
                            "image_url": scope.imageURLValue
                        }
                    }
                }else if(scope.marketingObjective == "REACH"){	
						scope.valAddWebsiteUrl = $window.localStorage.getItem("valAddWebsiteUrl");				
						if(scope.valAddWebsiteUrl){												
								scope.objectStorySpec = {
									"page_id": scope.pageIdVal,
									"video_data": {
										"video_id": scope.objid,
										"message": scope.textBodyContent,
                                        "link_description": scope.newsfeedlinkdesc,
                                        "title": scope.campaignHeadline,
										"call_to_action": {
											"type": scope.callToDirectionValue,
											"value": {											
												"link_caption":scope.displayLink,
												"link":scope.webURL
//												"link_description":scope.newsfeedlinkdesc,
//												"link_title": scope.campaignHeadline											
											}
										},
										"image_url": scope.imageURLValue
									}
								}
							}
							else {
									scope.objectStorySpec = {
									"page_id": scope.pageIdVal,
									"video_data": {
										"message": scope.textBodyContent,
										"video_id": scope.objid ,
										"image_url":scope.imageURLValue 
														
											}
									}
							}
					}
				

            }

            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": scope.networkAdAccountId, //101870703634673,                    
                "objectType": scope.objectType,
                "objectStorySpec": JSON.stringify(scope.objectStorySpec),
                "body": scope.textBodyContent,
                "name": "optional fields"
            };

			
            if (scope.campaignURLParameter != '' && scope.campaignURLParameter != 'undefined' && scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
			
			if (scope.campaignHeadline != '' && scope.campaignHeadline != 'undefined' && scope.campaignHeadline != null){
                var title = {
                        "title": scope.campaignHeadline
                }
                parameters = angular.extend({},parameters,title);
            }
			
            scope.$root.progressLoader = 'block';
            // if (scope.deleteSuccessFlag == true) {
            facebookGetPost.createadcreative("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {                  
                    scope.adCreativeId = response.data.adCreativeId;
                    scope.showSlideShowBrowser = false;
                    $window.localStorage.setItem("adCreativeId", scope.adCreativeId);
                    scope.browselibraryPopupHeading = "Browse Library";
                    scope.browselibrarySuccessMsg = "successfully uploaded";
                    scope.createAd();
					scope.$emit('imagefields',{id:"preview"});
                  //  scope.desktopCreativePreview();
                   // scope.mobileCreativePreview();
                  //  scope.rightColumnCreativePreview();                 
                    scope.browselibrary = "none";
                    scope.objurl = "";
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));                
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    scope.step2_green = true;
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                } else {
                    scope.mainLoader = "none";
                    scope.$root.progressLoader = "none";
                    scope.slideShowSuccess = false;
                    scope.slideShowCreate = true;
                    scope.showErrorPopup(response);
                    scope.showSlideShowBrowser = false;
                    angular.element($('.btnCampaignCreative').prop('disabled', true));                  
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");                  
                }
            });
        }
		
	   scope.createAd = function () {
            scope.$root.progressLoader = "block";
            scope.mainLoader = "block";		
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": scope.networkAdAccountId,
                "adsetId": $window.localStorage.getItem("adsetId"),				
                "creativeId": $window.localStorage.getItem("adCreativeId"),
                "name": "Demo Ad",
                "status": "PAUSED"
            };

            facebookGetPost.createad("", parameters).then(function (response) {
                scope.mainLoader = "none";
                if (response.data.appStatus == 0) {
                    scope.adId = response.data.adId;
                    $window.localStorage.setItem("adId", scope.adId);                  
                    scope.getAd();
                    angular.element($('.btnCampaignCreative').prop('disabled', false));                 
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    scope.step2_green = true;
                } else {
                    scope.$root.progressLoader = "none"
                    scope.showErrorPopup(response.data);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));                   
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                    angular.element('#step2').css('background-color', '#c2c2c2');
                    angular.element('#step3').css('background-color', '#c2c2c2');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
                }
            });
        }
		
	 scope.getAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getad(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.$root.progressLoader = "block";
                    scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify(scope.adData));
                  //  globalData.setLocal("adId", $window.localStorage.getItem("adId"), scope.adData);
                    scope.saveAd(scope.adData);
                    scope.formatSelected = scope.fbadvertFormat;
					scope.fielddata.fbadvertFormat = scope.fbadvertFormat;				
				    $window.localStorage.setItem("fbadvertFormat",scope.fbadvertFormat);
				    $window.localStorage.setItem("formatSelected", scope.formatSelected);
                    console.log("success scope.getAd");
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
	 scope.saveAd = function (adData) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": adData
            };

            facebookGetPost.saveaddatapost("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    scope.$root.progressLoader = "block";
                    scope.showSuccessPopup(response.data.successMessage);
                    // scope.getAdCreative();
                    scope.getAdSetAdCreative();
                    scope.networkErrorPopup = "none";
                    scope.popupTitleError = "";
                    scope.popupTitleError = "";
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
		   scope.getAdSetAdCreative = function () {

            var queryStr = "?adSetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getadsetadcreative(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.$root.progressLoader = "none";
                    scope.mainLoader = "none";
                    scope.adCreativeDatailsResponse = response.data.fbAdSetCreativeResponse.data[0];
                    scope.saveAdAccountAdCreative(scope.adCreativeDatailsResponse)
                   // globalData.setLocal("adCreativeId", $window.localStorage.getItem("adCreativeId"), scope.adCreativeDatailsResponse);
                    //scope.fbadvertFormat = "fbslideshow";
                    if (scope.fbadvertFormat == "fbsingleimage") {
                        scope.thumbnail = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailVideo = "images/campaign/single-video.png";
                        scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
						scope.imgthumbnaildiv=true;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbsingleimage",thumbnail:scope.adCreativeDatailsResponse.thumbnail_url, thumbnailVideo:"images/campaign/single-video.png",
						thumbnailSlideshow:"images/campaign/slide-show.png",thumbnailCarousel:"images/campaign/carousel.svg",imgthumbnaildiv:true});
                    } else if (scope.fbadvertFormat == "fbsinglevideo") {
						scope.thumbnail = "images/campaign/single-image.png";
                        scope.thumbnailVideo = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
                        scope.thumbnailSlideshow = "images/campaign/slide-show.png";
						scope.vidthumbnaildiv=true;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbsinglevideo",thumbnail:"images/campaign/single-image.png", thumbnailVideo:scope.adCreativeDatailsResponse.thumbnail_url,
						thumbnailSlideshow:"images/campaign/slide-show.png",thumbnailCarousel:"images/campaign/carousel.svg",vidthumbnaildiv:true});
						
                    } else if (scope.fbadvertFormat == "fbslideshow") {   
						scope.thumbnail = "images/campaign/single-image.png";
                        scope.thumbnailVideo = "images/campaign/single-video.png";
                        scope.thumbnailSlideshow = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
						scope.slideShowCreate=false;
						scope.slideShowSuccess=true;
						scope.slideShowPreview=scope.adCreativeDatailsResponse.thumbnail_url;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbslideshow",thumbnail:"images/campaign/single-image.png", thumbnailVideo:"images/campaign/single-video.png",
						thumbnailSlideshow:scope.adCreativeDatailsResponse.thumbnail_url,thumbnailCarousel:"images/campaign/carousel.svg",slideShowCreate:false,slideShowSuccess:true,slideShowPreview:scope.adCreativeDatailsResponse.thumbnail_url});						
                    }
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });

        }
		
	   scope.saveAdAccountAdCreative = function (respGetAdCreativeObj) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetID": $window.localStorage.getItem("adsetId"),
                "adCreativeID": $window.localStorage.getItem("adCreativeId"),
                "adCreativeDetails": respGetAdCreativeObj,
            };

            facebookGetPost.saveadsetadcreative("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    scope.$root.campaignSteps[3] = true;
                    scope.$root.progressLoader = "none";
                    scope.mainLoader = "none";
                
					    angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
					scope.$emit('uploadsection',{id:"setLine"});
                    //scope.$root.step = 4;
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
	 scope.deleteAdCreative = function (imageHashVal) {
            scope.$root.progressLoader = 'block';
            var isCreateAd = $window.localStorage.getItem("adId");
            var isAdDetails = $window.localStorage.getItem("adData");

            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.deleteadcreative(queryStr, headers).then(function (response) {
                //alert(response.data.appStatus)
                if (response.data.appStatus == '0') {// success
                    //scope.creativeAdCreative(hashVal);
                    scope.networkErrorPopup = 'none';
                    scope.popupTitleError = '';
                    scope.popupMessageError = '';
                    $window.localStorage.setItem("deleteAdCreativeStatus", "true");
                    // scope.deleteSuccessFlag = true;
                    if (isCreateAd) {
                        scope.deleteAd();
                    }
                    scope.proceedToCreateAdCreative(imageHashVal);

                } else {// failed
                    scope.$root.progressLoader = "none";
//                      scope.deleteSuccessFlag = false;
                    if (response.data.appStatus > 0 && (response.data.errorId == 10006)) {
                        $window.localStorage.setItem("deleteAdCreativeStatus", "true");
//                        scope.deleteSuccessFlag = true;
                        if (isCreateAd) {
                            scope.deleteAd();
                        }
                        scope.proceedToCreateAdCreative(imageHashVal);
                    } else if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                    $window.localStorage.setItem("deleteAdCreativeStatus", "false");

                }

            });
        }

		
		 scope.deleteAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.deletead(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log("success delete ad");
                    scope.networkErrorPopup = 'none';
                    scope.popupTitleError = "";
                    scope.popupMessageError = '';
//                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
//                    if (isCreativeAdCreativeId) {
//                        scope.deleteAdCreative();
//                    }
                    scope.getAdForDelete();
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
	 scope.getAdForDelete = function () {
            console.log('get ad');
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getad(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify(scope.adData));

                    console.log(scope.adData);
                    scope.saveAdforDelete(scope.adData);
                    //scope.saveAd(scope.adData);
                    console.log("success scope.getAd");
                } else {// failed
                    console.log("failed getad");
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.$root.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(response);
                        }
                    }
                }
            });
        }
		
	  scope.saveAdforDelete = function () {

            //console.log(scope.adData)
            scope.adDataFromLocal = JSON.parse($window.localStorage.getItem("adData"));

            scope.adDataTemp = {
                "status": "DELETED"
            };

            var camR = {};
            for (var key in scope.adDataFromLocal) {
                camR[key] = scope.adDataFromLocal[key];
            }
            for (var key in scope.adDataTemp) {
                camR[key] = scope.adDataTemp[key];
            }
            scope.adDataFromLocal = camR;
            console.log(scope.adData);

            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": scope.adDataFromLocal
            };

            facebookGetPost.saveaddata("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    scope.$root.progressLoader = "none";
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }


        scope.showErrorPopup = function (response) {
            if (response.hasOwnProperty("data"))
            {
                if (response.data.networkError)
                {
                    if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined)
                    {
                        scope.popupTitle = response.data.networkError.error_user_title;
                        scope.popupMessage = response.data.networkError.error_user_msg;
                    } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined)
                    {

                        scope.popupTitle = "Error";
                        scope.popupMessage = response.data.networkError.message;
                    }
                } else {
                    scope.popupTitle = "Error";
                    scope.popupMessage = response.data.errorMessage;
                }
            } else {
                if (response.networkError) {
                    if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                        scope.popupTitle = response.networkError.error_user_title;
                        scope.popupMessage = response.networkError.error_user_msg;
                    } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                        scope.popupTitle = "Error";
                        scope.popupMessage = response.networkError.message;
                    }
                } else {
                    scope.popupTitle = "Error";
                    scope.popupMessage = response.errorMessage;
                }

            }
            var modalApproveReq = $(".error_popup"); // Get the modal Approve req
            modalApproveReq.show();
        };
		

		scope.init = function(){
		   scope.$emit('uploadsection',{id:"setLine"});
		}
		scope.init();
		scope.$on('uploadsection',function(events,args){			
			 if(args.id == "createdAd"){
                  scope.createAd();				 
			  }else if(args.id == "thumbnailchange"){				
				  scope.imgthumbnaildiv = args.image;
				  scope.vidthumbnaildiv = args.video;
				  scope.slideShowCreate = args.slideshowcreate;
				  scope.slideShowSuccess = args.slideshowsuccess;
			  }else if(args.id == "formvalidation"){
				  if(args.value == "validForm"){
					   scope.isFormDirty = true;
				  }else if(args.value == "invalidForm"){
					    scope.isFormDirty = false;
						scope.imgthumbnaildiv = args.image;
						scope.vidthumbnaildiv = args.video;
						scope.slideShowCreate = args.slideshowcreate;
						scope.slideShowSuccess = args.slideshowsuccess;
				  }			
			  }
		})

}
}
}]);