dashboard.directive('bidAmount',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/bidAmountTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },                          							
		link:function(scope,element,attr){
		scope.fielddata = {
			bidAmountVal:"",
			bidAmount:"",
			manualbidtxt:"",
		}
		scope.campaignState = $window.localStorage.getItem("campaignState");
		scope.manualbidtxt = "per post engagement";
		scope.selectBidAmount = function (bidvalue) {
			console.log(bidvalue);
			if (bidvalue == 1) {
				scope.showText = false;
			}
			else{
				scope.showText = true;
			}
			scope.$emit('selectbid',{value:bidvalue});
		}
		
		scope.saveBidAmount = function (value) {
				scope.bidAmount = value;
				scope.$emit('bidAmount',{value:scope.bidAmount});
                scope.validation();
        }
			
				if (scope.campaignState == "create") {		
					console.log('bid amount directive');
					scope.bidAmountVal = 1;
					
				}
				scope.$on('manualbidtxt', function (event,args) {
				console.log(args.value);
				scope.manualbidtxt = args.value;
				});	
				
				scope.$on('bidauto', function (event,args) {
				console.log(args.value);
				scope.bidAmountVal = args.value;
				});	
				
				scope.$on('bidmanual', function (event,args) {
				console.log(args.value);
				scope.bidAmountVal = args.value;
				scope.showText = true;
				scope.autoBid = false; 
				scope.bidAmount = args.value1;
				});	
				
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 