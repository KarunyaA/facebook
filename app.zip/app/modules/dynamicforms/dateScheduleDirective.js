dashboard.directive('dateSchedule',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/dateScheduleTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },                          							
		link:function(scope,element,attr){
		scope.fielddata = {
			campaignPlanFormSchedule:"",
			scheduleStartDate:"",
			scheduleEndDate:"",
		}
		scope.campaignState = $window.localStorage.getItem("campaignState");
		
			
		scope.selectSchedule = function (value) {
		console.log(value);
        if (value == "1") {
		scope.campaignPlanFormSchedule = 1;
        scope.setDate = false;
        scope.enddateselected=false;
                scope.todayDate = new Date();
                var currentDate = $filter('date')(scope.todayDate, 'yyyy-M-d hh:mm a');
                scope.scheduleStartDate = new Date(currentDate);
                scope.scheduleEndDate = 0; //$filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:');
        } else {
				scope.campaignPlanFormSchedule = 2;
				scope.enddateselected=false;
				scope.setDate = true;
                scope.todayDate = new Date();
                scope.scheduleEndDate = scope.endDate;
                var currentDate = $filter('date')(scope.todayDate, 'yyyy-M-d hh:mm a');
                scope.scheduleStartDate = new Date(currentDate);
                scope.scheduleEndDate = 0;

        }

				$window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
                $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);
                //scope.checkMandatoryField();
				scope.validation();
        }
		
		scope.onDateChange1 = function (selectedDate) {
        console.log(selectedDate);
                scope.scheduleStartDate = selectedDate;
                console.log(scope.scheduleStartDate)
                $window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
				scope.$emit('scheduleStartDate',{value:scope.scheduleStartDate});
        }
        scope.onDateChange2 = function (selectedDate) {
				console.log(selectedDate);
                scope.scheduleEndDate = selectedDate;
                console.log(scope.scheduleEndDate)
                $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);
                scope.diffDate(scope.scheduleStartDate , scope.scheduleEndDate );
				scope.$emit('scheduleEndDate',{value:scope.scheduleEndDate});
                //scope.checkMandatoryField();
				scope.validation();
        }
        
        scope.diffDate = function(date1, date2){
			console.log(date2);
            var dateOut1 = new Date(date1); // it will work if date1 is in ISO format
            var dateOut2 = new Date(date2);
            var timeDiff = Math.abs(date2.getTime() - date1.getTime());
			console.log(timeDiff);
            scope.diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
            if (Date.parse(scope.scheduleEndDate) >= Date.parse(scope.scheduleStartDate)) {
                scope.enddateselected=true;
				scope.$emit('enddateselected',{value:scope.enddateselected,value1:scope.diffDays});
				console.log('true');
            }else
            {
				console.log('false');
                scope.enddateselected=false;
				scope.$emit('enddateselected',{value:scope.enddateselected});
            }
        };
        
        scope.onTimeChange1 = function (selectedTime) {
        console.log(selectedTime);
                scope.scheduleStartDate = selectedTime;
                console.log(scope.scheduleStartDate)
                $window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
				console.log(scope.enddateselected);
        }
        scope.onTimeChange2 = function (selectedTime) {
        console.log(selectedTime);
                //$scope.checkMandatoryField();
				scope.validation();
                scope.scheduleEndDate = selectedTime;
                console.log(scope.scheduleEndDate);
                $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);

        }
			
			//scope.init = function () {
				if (scope.campaignState == "create") {						
					console.log(scope.campaignPlanFormSchedule);
					scope.campaignPlanFormSchedule = 1;
					scope.selectSchedule(scope.campaignPlanFormSchedule);
					scope.campaignPlanFormBudget = "dailyBudget";
					
				}
				
				scope.$on('schedulingdetails', function (event,args) {
				console.log(args.value);
				scope.selectSchedule(args.value);
				});
				
				scope.$on('datediff', function (event,args) {
				console.log(args.value);
				console.log(args.value1);
				scope.scheduleStartDate = args.value;
				scope.scheduleEndDate = args.value1;
				scope.diffDate(args.value , args.value1);
				
				});
				
				scope.$on('campaignPlanFormBudgetValue',function(events,args){
				scope.campaignPlanFormBudgetValue = args.value;
				console.log(scope.campaignPlanFormBudgetValue);
				});
				
				scope.$on('budgetselect',function(events,args){
				scope.campaignPlanFormBudget = args.value;
				console.log(scope.campaignPlanFormBudget);
				});
				
		}
		
	}
	
}])
 