dashboard.directive('deliveryType',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/deliveryTypeTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },                          							
		link:function(scope,element,attr){
		scope.fielddata = {			
			deliverType:"",
			deliveryText:"",
			
		}
		
		scope.selectDeliveryType = function(value) {
            console.log(value);
            if (value == 1) {
               scope.deliverType = 1;
			   scope.$emit('deliverytype',{value:scope.deliverType});
            }else{
               scope.deliverType = 2;
			   scope.$emit('deliverytype',{value:scope.deliverType});
            } 
        };
		
		scope.opendeliveryType = function () {
        scope.deliveryType = true;
        }

		scope.campaignState = $window.localStorage.getItem("campaignState");
				if (scope.campaignState == "create") {		
					scope.deliveryType = false;
					scope.deliverType = 1;
					scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
					
				}
				else{
					scope.deliverType = 1;
					scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
				}
				
				scope.$on('bidmanual', function (event,args) {
				console.log(args.value);
				scope.bidAmountVal = args.value;
				scope.showText = true;
				scope.autoBid = false; 
				});	
				
				scope.$on('deliverytypeone', function (event,args) {
				console.log(args.value);
				scope.deliverType = 1;
                scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";

				});
				
				scope.$on('deliverytypetwo', function (event,args) {
				console.log(args.value);
				scope.deliverType = 2;
                scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";

				});
				
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 