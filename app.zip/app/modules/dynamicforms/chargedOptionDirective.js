dashboard.directive('chargedOption',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/chargedOptionTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },                          							
		link:function(scope,element,attr){
		scope.fielddata = {
			chargedoptions:"",
			impressions:"",
			radioimpressions:"",
			moreimpressions:"",
			
		}
		
		scope.impressions = false;
		scope.radioimpressions = false;
        scope.moreimpressions = false;
		scope.chargedoptions = "POST_ENGAGEMENT";
		scope.chargedOption = [
                {
                "id": "POST_ENGAGEMENT",
                        "name": "Post engagement",
                        "disabled": "false"
                },
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
        ]
		
		scope.openImpression = function () {
			scope.impressions = true;
			scope.radioimpressions = true;
			scope.moreimpressions = true;
        }
		
		scope.campaignState = $window.localStorage.getItem("campaignState");
		
			
				if (scope.campaignState == "create") {		
					
				}
				
		scope.$on('chargedoptionone', function (event,args) {
		console.log(args.value);
		scope.chargedoptions = args.value;		
		scope.chargedOption = [
                {
                "id": "POST_ENGAGEMENT",
                        "name": "Post engagement",
                        "disabled": "false"
                },
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
                ]
		});
		
		scope.$on('chargedoptiontwo', function (event,args) {
		console.log(args.value);
		scope.chargedoptions = args.value;
		scope.chargedOption = [
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
                ]		
		});
		
		scope.selectOption = function (value) {
			scope.chargedoptions = value;
			scope.$emit('selectoption',{value:scope.chargedoptions});
        }
				
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 