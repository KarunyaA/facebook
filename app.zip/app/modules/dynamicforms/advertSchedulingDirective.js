dashboard.directive('advertScheduling',['$rootScope','facebookGetPost','$window','$filter','$q',function($rootScope,facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',				
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/advertSchedulingTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },  		
		link:function(scope,element,attr,fbbudgetPlanCtrl){
		scope.fielddata = {						
			campaignPlanFormBudget:"",
			campaignPlanFormBudgetValue:"",
			budgetEditValue:"",
			budget:"",
			campaignPlanFormSchedule:"",
			scheduleStartDate:"",
			scheduleEndDate:"",
			advertSetName:"",
			bidAmountVal:"",
			bidAmount:"",
			manualbidtxt:"",
			chargedoptions:"",
			impressions:"",
			radioimpressions:"",
			moreimpressions:"",
			deliverType:"",
			deliveryText:"",
			runAdvert:"",
			AdvertText:"",
			showChart:"",
		}
		scope.runAdvert = 1;
        scope.AdvertText = "Run adverts all the time";
		scope.openRunAdverts = function () {
        scope.runAdverts = true;
        }
		
		scope.selectRunAdvert = function (value) {
			console.log(value);				
			if (value == 1) {
			scope.AdvertText = "Run adverts all the time";
			scope.showChart = false;
			console.log($rootScope.adsetSchedule);
			scope.$emit('advertone',{value:scope.showChart});
			} else {
			scope.AdvertText = "Run adverts on a schedule";
			scope.showChart = true;
			console.log($rootScope.adsetSchedule);
			scope.$emit('adverttwo',{value:scope.showChart});
			
			}
		}
		
		scope.$on('schedulingone', function (event,args) {
				console.log(args.value);
				scope.runAdvert = 1;
                scope.AdvertText = "Run adverts all the time";
                scope.showChart = false;

		});
		
		scope.$on('schedulingtwo', function (event,args) {
				console.log(args.value);
				scope.showChart = true;
                scope.runAdvert = 2;
                scope.AdvertText = "Run adverts on a schedule";

		});
		
		scope.campaignState = $window.localStorage.getItem("campaignState");
				if (scope.campaignState == "create") {		
					scope.AdvertText = "Run adverts all the time";
					scope.showChart = false;
				}
				
		}
	
	}
	
}])
 
 
  dashboard.controller("dayPartsChartController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'globalData', 'sharedService1',
                function ($rootScope, $scope, $state, catalyst, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile, appSettings, globalData, sharedService1) {
                var apiTPBase = appSettings.apiTPBase;
                        var apiBase = appSettings.apiBase;
                        $rootScope.adsetSchedule = [];
                        //sharedService1.store = $scope;
                        var data = [{
                        "day": "Monday",
                                "time": "12"
                        },
                        {
                        "day": "Tuesday",
                                "time": "3"
                        },
                        {

                        "day": "Wednesday",
                                "time": "6"
                        },
                        {

                        "day": "Thursday",
                                "time": "9"
                        },
                        {
                        "day": "Friday",
                                "time": "12"
                        },
                        {

                        "day": "Saturday",
                                "time": "3"
                        },
                        {
                        "day": "Sunday",
                                "time": "6"
                        }




                        ]

                        var svgns = "http://www.w3.org/2000/svg";
                        var _x = 130;
                        var _y = 85;
                        var day = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                        var time = ["12", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"]
                        var everyDay = [8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192];
                        var timeArray = ["12AM", "1AM", "2AM", "3AM", "4AM", "5AM", "6AM", "7AM", "8AM", "9AM", "10AM", "11AM", "12PM", "1PM", "2PM", "3PM", "4PM", "5PM", "6PM", "7PM", "8PM", "9PM", "10PM", "11PM", "12PM"]
                        var getSchedule = [2, 78, 94, 45, 56, 148, 149, 150, 151, 152, 153, 154];
                        var everyDayPart = [];
                        var totalWeekDays = 7;
                        var selectedTime = 0;
                        var selectedDay = 0;
                        var selectedTime = "";
                        var dragging = 0;
                        var startTime = 0;
                        var endTime = 60;
                        var dayFlag = false;
                        var timeFlag = false;
                        var canvas;
                        $scope.chartInit = function (obj) {


                        function reSchdeule1(flag) {
                        //	console.log('reSchdeule1')
                        var tmp2 = 1

                                for (var x = 116; x < 820; x += 30) {
                        for (var y = 75; y < 76; y += 35) {
                        //console.log(x+" "+y)
                        var xmlns = "http://www.w3.org/2000/svg"
                                var elem = document.createElementNS(xmlns, 'text');
                                //elem.setAttributeNS(null,"id","myText_"+tmp2);
                                elem.setAttributeNS(null, 'x', x);
                                elem.setAttributeNS(null, 'y', y);
                                elem.setAttributeNS(null, 'dx', '0,0,0,0,0');
                                elem.setAttributeNS(null, 'dy', '0,0,0,0,0');
                                elem.setAttributeNS(null, 'font-size', '12');
                                elem.setAttributeNS(null, 'color', '#484848');
                                elem.setAttributeNS(null, 'text-anchor', 'middle');
                                elem.setAttributeNS(null, 'cursor', 'pointer');
                                var lblText = document.createTextNode(time[tmp2 - 1]);
                                elem.append(lblText);
                                //console.log(elem);
                                //	console.log(document.getElementById('canvasElement'));
                                document.getElementById('canvasElement').appendChild(elem);
                                tmp2++;
                        }
                        }




                        var tmp1 = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 50; y < 56; y += 35) {
                        //var xmlns = "http://www.w3.org/2000/svg"
                        var txtRect = document.createElementNS(svgns, 'rect');
                                txtRect.setAttributeNS(null, "id", "myText_" + tmp1);
                                txtRect.setAttributeNS(null, 'x', x);
                                txtRect.setAttributeNS(null, 'y', y);
                                txtRect.setAttributeNS(null, 'height', '22');
                                txtRect.setAttributeNS(null, 'width', '28');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                txtRect.setAttributeNS(null, 'fill', '#7EC291');
                                txtRect.setAttributeNS(null, 'border', '1px solid red');
                                txtRect.setAttributeNS(null, 'cursor', 'pointer');
                                txtRect.setAttributeNS(null, 'timeFlag', 'false');
                                txtRect.setAttributeNS(null, 'opacity', 0);
                                document.getElementById('canvasElement').appendChild(txtRect);
                                tmp1++;
                        }
                        }




                        var tmp = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        var rect = document.createElementNS(svgns, 'rect');
                                //rect.setAttributeNS(null,"id","myRect_"+tmp);
                                rect.setAttributeNS(null, 'x', x);
                                rect.setAttributeNS(null, 'y', y);
                                rect.setAttributeNS(null, 'height', '22');
                                rect.setAttributeNS(null, 'width', '28');
                                //rect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                //rect.setAttributeNS(null, 'fill', '#7EC291');
                                rect.setAttributeNS(null, 'fill', '#ececec');
                                rect.setAttributeNS(null, 'border', '1px solid red');
                                rect.setAttributeNS(null, 'cursor', 'pointer');
                                rect.setAttributeNS(null, 'opacity', 1);
                                rect.setAttributeNS(null, 'flag', 0);
                                document.getElementById('canvasElement').appendChild(rect);
                                tmp++;
                        }
                        }




                        var tmp3 = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        var rect = document.createElementNS(svgns, 'rect');
                                rect.setAttributeNS(null, "id", "myRect_" + tmp3);
                                rect.setAttributeNS(null, 'x', x);
                                rect.setAttributeNS(null, 'y', y);
                                rect.setAttributeNS(null, 'height', '22');
                                rect.setAttributeNS(null, 'width', '28');
                                //rect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                rect.setAttributeNS(null, 'fill', '#FF8F00');
                                rect.setAttributeNS(null, 'border', '1px solid red');
                                rect.setAttributeNS(null, 'cursor', 'pointer');
                                rect.setAttributeNS(null, 'opacity', 0);
                                rect.setAttributeNS(null, 'flag', 0);
                                rect.setAttributeNS(null, 'sflag', '0');
                                rect.setAttributeNS(null, 'mflag', 'false');
                                document.getElementById('canvasElement').appendChild(rect);
                                tmp3++;
                        }
                        }




                        var tmp5 = 1

                                for (var x = 5; x < 30; x += 30) {
                        for (var y = 105; y < 260; y += 25) {
                        var xmlns = "http://www.w3.org/2000/svg"
                                var elem = document.createElementNS(xmlns, 'text');
                                elem.setAttributeNS(null, "id", "myDay_" + tmp4);
                                elem.setAttributeNS(null, 'x', x);
                                elem.setAttributeNS(null, 'y', y);
                                elem.setAttributeNS(null, 'height', '22');
                                elem.setAttributeNS(null, 'width', '80');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                elem.setAttributeNS(null, 'fill', '#000000');
                                elem.setAttributeNS(null, 'border', '1px solid red');
                                elem.setAttributeNS(null, 'cursor', 'pointer');
                                elem.setAttributeNS(null, 'dayFlag', 'false');
                                elem.setAttributeNS(null, 'opacity', 1);
                                var lblText = document.createTextNode(day[tmp5 - 1]);
                                elem.append(lblText);
                                document.getElementById('canvasElement').appendChild(elem);
                                tmp5++;
                        }
                        }




                        var tmp4 = 1

                                for (var x = 5; x < 30; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        //var xmlns = "http://www.w3.org/2000/svg"
                        var txtRect = document.createElementNS(svgns, 'rect');
                                txtRect.setAttributeNS(null, "id", "myDay_" + tmp4);
                                txtRect.setAttributeNS(null, 'x', x);
                                txtRect.setAttributeNS(null, 'y', y);
                                txtRect.setAttributeNS(null, 'height', '22');
                                txtRect.setAttributeNS(null, 'width', '80');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                txtRect.setAttributeNS(null, 'fill', '#7EC291');
                                txtRect.setAttributeNS(null, 'border', '1px solid red');
                                txtRect.setAttributeNS(null, 'cursor', 'pointer');
                                txtRect.setAttributeNS(null, 'dayFlag', 'false');
                                txtRect.setAttributeNS(null, 'opacity', 0);
                                document.getElementById('canvasElement').appendChild(txtRect);
                                tmp4++;
                        }
                        }



                        showEvtData(null, null);
                                //$scope.populateChart();
                                //prepopulateData();

                        }

                        setTimeout(reSchdeule1, 0, false)
                        }

                $scope.chartInit();
                        function checkIfEveryDay(id) {
                        var rectNo = id.split('_')[1]
                                for (var i = 0; i < everyDay.length; i++) {
                        if (everyDay[i] == rectNo) {
                        //return i;
                        }
                        }
                        return null;
                        }

                function createSchedule(selected, schedule) {
                $scope.populateChart();
                }




                var resetFlag = 0

                        function showEvtData(evt, _this) {
                        for (var i = 1; i < 500; i++) {

                        var rectElement = document.getElementById('myRect_' + i);
                                if (rectElement) {

                        if (!rectElement.hasAttribute('sFlag')) {
                        rectElement.sFlag = '0'
                        }

                        console.log(rectElement.sFlag)
                                if (!rectElement.hasAttribute('mFlag')) {
                        rectElement.mFlag = '0'
                        }

                        rectElement.onmouseup = function (evt) {
                        var rectObj = evt.target;
                                var day = checkIfEveryDay(evt.target.id);
                                if (day == null) {

                        if (rectObj.style.opacity == 1) {
                        rectObj.style.opacity = 0;
                                rectObj.sflag = '0';
                        } else {

                        rectObj.style.opacity = 1;
                                rectObj.sflag = '1';
                        }

                        console.log(rectObj.id + " : " + rectObj.sflag)
                                createSchedule(evt.target.id);
                        } else {
                        var startLen = day * totalWeekDays;
                                var endLen = startLen + totalWeekDays;
                                for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1))
                                //console.log(dayElement.id)                                                                                                    
                                if (dayElement) {
                        if (dayElement.flag == 1) {
                        reset(dayElement)
                        } else {
                        reset1(dayElement)
                        }
                        if (dayElement.style.opacity == 1) {
                        dayElement.style.opacity = 0;
                        } else {
                        dayElement.style.opacity = 1;
                        }
                        }
                        }




                        createSchedule(evt.target.id, 'All');
                        }
                        }



                        }
                        }



                        for (var i = 1; i <= 7; i++) {

                        var weekElement = document.getElementById('myDay_' + i);
                                if (weekElement) {

                        if (weekElement.hasAttribute('dayFlag') == true) {
                        weekElement.dayFlag = 'false';
                        }

                        weekElement.onmouseup = function (evt) {
                        var _obj = evt.target;
                                var day = Number(evt.target.id.split('_')[1]);
                                var startLen = (day - 1) * totalWeekDays;
                                var endLen = day + totalWeekDays;
                                for (var i = 1; i <= 240; i++) {

                        var elmNo = day + ((i - 1) * totalWeekDays);
                                var dayElement = document.getElementById('myRect_' + elmNo);
                                if (dayElement) {

                        if (_obj.dayFlag == "false") {
                        dayElement.sflag = '2';
                        } else {

                        dayElement.sflag = '0';
                        }
                        }
                        }
                        for (var i = 1; i <= 240; i++) {
                        var elmNo = day + ((i - 1) * totalWeekDays);
                                var dayElement = document.getElementById('myRect_' + elmNo);
                                if (dayElement) {
                        if (dayElement.sflag == "2") {
                        dayElement.style.opacity = 1;
                        } else {
                        dayElement.style.opacity = 0;
                        }


                        }




                        }
                        if (_obj.dayFlag == "true") {
                        _obj.dayFlag = 'false';
                        } else {
                        _obj.dayFlag = 'true';
                        }
                        createSchedule(evt.target.id);
                        }
                        }
                        }
                        for (var i = 1; i <= 24; i++) {




                        var textElement = document.getElementById('myText_' + i);
                                if (textElement) {

                        if (textElement.hasAttribute('timeFlag') == true) {
                        textElement.timeFlag = 'false';
                        }

                        textElement.onmouseup = function (evt) {
                        var _obj = evt.target;
                                var day = evt.target.id.split('_')[1];
                                var startLen = (day - 1) * totalWeekDays;
                                var endLen = startLen + totalWeekDays;
                                for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1));
                                console.log(dayElement.id + " : " + dayElement.sflag + " : " + _obj.timeFlag)
                                if (_obj.timeFlag == "false") {
                        dayElement.sflag = '2';
                        } else {

                        dayElement.sflag = '0';
                        }
                        }
                        for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1));
                                if (dayElement.sflag == "2") {
                        dayElement.style.opacity = 1;
                        } else {
                        dayElement.style.opacity = 0;
                        }




                        }
                        if (_obj.timeFlag == "true") {
                        _obj.timeFlag = 'false';
                        } else {
                        _obj.timeFlag = 'true';
                        }
                        createSchedule(evt.target.id);
                        }
                        }
                        }
                        }

                $scope.getTimePosition = function (_time) {
                for (var i = 0; i < timeArray.length; i++) {
                if (timeArray[i] == _time) {
                return i;
                }

                }




                }



                $scope.myTimer = function () {
                console.log($rootScope.chartArray)
                        for (var i = 0; i < $rootScope.chartArray.length; i++) {
                var rectElement = document.getElementById('myRect_' + $rootScope.chartArray[i]);
                        if (rectElement) {
                console.log(rectElement);
                        rectElement.style.opacity = 1;
                }
                }
                clearInterval(idInter);
                }
                var idInter = setInterval($scope.myTimer, 2000);
                        $scope.populateChart = function () {
                        $rootScope.adsetSchedule = [];
                                var scheduleArray = [];
                                for (var i = 1; i < 200; i++) {
                        var rectElement = document.getElementById('myRect_' + i);
                                if (rectElement) {
                        var obj = rectElement.id;
                                if (rectElement.style.opacity == 1) {
                        scheduleArray.push(obj);
                        }
                        }
                        }
                        var sTime = 0;
                                var eTime = 0;
                                angular.forEach(scheduleArray, function (value, key) {
                                var selectedNo = scheduleArray[key].split('_')[1];
                                        var selectedPosition = selectedNo / totalWeekDays;
                                        console.log('selected position ' + parseInt(selectedPosition));
                                        if (selectedNo % 7 == 0) {
                                selectedTime = timeArray[parseInt(selectedPosition) - 1];
                                } else {
                                selectedTime = timeArray[parseInt(selectedPosition)];
                                }
                                selectedDay = (parseInt(selectedPosition) * 7) - selectedNo;
                                        selectedDay = selectedDay * ( - 1);
                                        console.log('selected time ' + selectedTime);
                                        console.log('selected no ' + selectedNo);
                                        console.log('selected day ' + selectedDay);
                                        var tPosition = $scope.getTimePosition(selectedTime);
                                        tPosition = tPosition + 1;
                                        if (tPosition == 1) {
                                sTime = startTime;
                                        eTime = endTime;
                                } else {
                                sTime = endTime * (tPosition - 1);
                                        eTime = (endTime * tPosition);
                                }
                                console.log('start Time ' + sTime);
                                        console.log('end time ' + eTime);
                                        var arr = [];
                                        arr.push(selectedDay);
                                        var obj = {

                                        "start_minute": sTime,
                                                "end_minute": eTime,
                                                "days": arr
                                        }



                                $rootScope.adsetSchedule.push(obj);
                                });
                                console.log($rootScope.adsetSchedule);
                                day.push(day);
                                var obj = {

                                "start_minute": 0,
                                        "end_minute": 60,
                                        "days": day
                                };
                                $rootScope.chartChange = true;
                        }



                }
        ]);