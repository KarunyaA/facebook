dashboard.directive('creativePreview',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/creativePreviewTemplate.html',	
	transclude:true,
	scope:true,
    link:function(scope,element,attr){
	
	scope.init = function(){
		    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
		    scope.$emit('uploadsection',{id:"setLine"});
	}
	scope.init();
	
			
		//*** Preview Section API calls***/
		     scope.desktopCreativePreview = function () {
            scope.progressLoaderPreveiw = "block";
            scope.previewCategory = "DESKTOP_FEED_STANDARD";
            scope.adCreativeId = $window.localStorage.getItem("adCreativeId");

            var queryStr = "?networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + scope.adCreativeId + "&adFormat=" + scope.previewCategory;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                console.log(response);
                scope.progressLoaderPreveiw = "none";

                if (response.data.previewFb[0].preview) {
                    scope.progressLoaderPreveiw = "none";
                    scope.RetryDesktopPreview = "none";
                    scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    scope.iframeSourcebody = scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+scope.embedSrcDesktop);
                    scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    scope.desktopPreview = {src: scope.embedSrcDesktop, title: "Desktop Preview"};
                } else {
                    scope.RetryDesktopPreview = "block";
                    scope.progressLoaderPreveiw = "none";
                }


            });
        }
		

        scope.mobileCreativePreview = function () {
            scope.progressLoaderPreveiw = "block";
            scope.previewCategory = "MOBILE_FEED_STANDARD";
            scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + scope.adCreativeId + "&adFormat=" + scope.previewCategory;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                scope.progressLoaderPreveiw = "none";
                if (response.data.previewFb[0].preview) {
                    scope.RetryDesktopPreview = "none";
                    scope.progressLoaderPreveiw = "none";
                    scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    scope.iframeSourcebody = scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+scope.embedSrcDesktop);
                    scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    scope.mobilePreview = {src: scope.embedSrcDesktop, title: "Mobile Preview"};
                } else {
                    scope.RetryDesktopPreview = "block";
                    scope.progressLoaderPreveiw = "none";
                }


            });
        }

        scope.rightColumnCreativePreview = function () {
            scope.progressLoaderPreveiw = "block";
            scope.previewCategory = "RIGHT_COLUMN_STANDARD";
            scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + scope.adCreativeId + "&adFormat=" + scope.previewCategory;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                scope.progressLoaderPreveiw = "none"
                if (response.data.previewFb[0].preview) {
                    scope.RetryDesktopPreview = "none";
                    scope.progressLoaderPreveiw = "none";
                    scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    scope.iframeSourcebody = scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+scope.embedSrcDesktop);
                    scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    scope.rightColumnPreview = {src: scope.embedSrcDesktop, title: "Right Column Preview"};
                } else {
                    scope.RetryDesktopPreview = "block";
                    scope.progressLoaderPreveiw = "none";
                }


            });
        }
		
	
			scope.$on('previewsection',function(events,args){
					scope.desktopCreativePreview();
                    scope.mobileCreativePreview();
                    scope.rightColumnCreativePreview(); 
			})
	
	}
}


}]);