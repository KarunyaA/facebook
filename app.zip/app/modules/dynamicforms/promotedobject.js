dashboard.directive('promotedObject', ['facebookGetPost', '$window', '$filter', '$timeout', '$state', 'appSettings', '$q', '$animate', 'apiService', '$sce', 'globalData', function (facebookGetPost, $window, $filter, $timeout, $state, appSettings, $q, $animate, apiService, $sce, globalData) {
        return{
            restrict: 'E',
            templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/promotedobject.html',
            transclude: true,
            scope: {
                data: "="
            },
            link: function (scope, element, attr) {

                scope.data = {
                    regionArray: [],
                    countryArray: [],
                    cityArray: [],
                    campaignAudienceLocationsArr: [],
                    campaignAudienceLocationType: "",
                    mapLocation: false,
                    campaignAudienceLocationTarget: "everyone",
                    campaignAudienceAgeFrom: "18",
                    campaignAudienceAgeTo: "65",
                    campaignAudienceGender: "all",
                    campaignAudienceLanguage: "",
                    campaignAudienceLanguageArr: [],
                    campaignAudienceLanguageKeyArr: [],
                    LanguageKeyValues: "",
                    placementsValues: [],
                    campaignAudiencePlacementsWiFi: "1",
                    campaignAudienceMobileDevice: "",
                    mobileView: false,
                    PlacementsArr: [],
                    MobileDeviceArr: [],
                    placementsKeyValues: [],
                    campaignAudienceDTJSON: [],
                    DetailedTargetingArr: [],
                    DTselectionkey: [],
                    DTselection: [],
                    demographicsArray: [],
                    interestsArray: [],
                    behaviorsArray: [],
                    campaignAudienceCampaignTarget: ""
                }

                var apiTPBase = appSettings.apiTPBase;
                var apiBase = appSettings.apiBase;
                scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
                scope.$root.networkAccessToken = $window.localStorage.getItem("networkAccessToken");

                scope.sendcampaignAudienceCampaignTarget = function (campaignAudienceCampaignTarget) {
                    scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
                    $window.localStorage.setItem("campaignAudienceTarget", scope.campaignAudienceCampaignTarget);
                    scope.$root.freezeFlag = true;
                    scope.$root.overLayAudience = true;

                    if (scope.data.campaignAudienceCampaignTarget == "")
                    {
                        angular.element('#step1').css('background-color', '#c2c2c2');
                        angular.element('#mandatory').addClass("mandatory");
                    }
                    else
                    {
                        angular.element('#step1').css('background-color', '#95D2B1');
                        angular.element('#mandatory').removeClass("mandatory");
                    }

                };
                
                scope.getCampaignTarget = function () {
                    //alert(scope.promotionObjective);
                    console.log(scope.promotionObjective);
                    scope.campaignAudienceCampaignTargetLoader = true;
                    if (scope.promotionObjective == 'page') {

                        var querystr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                        var headers = {
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken")
                        };
                        //FOR PAGE
                        facebookGetPost.fetchuserpromotablepages(querystr, headers).then(function (response) {
                            if (response) {
                                response.data.fbUserPromotablePagesResponse = [{
                                 id:"726949550817444",
                                 name:"Digital Books"			
                                 },{
                                 id:"222",
                                 name:"Sample Page"
                                 }] 
                                scope.pageCampaignTargetArr = response.data.fbUserPromotablePagesResponse;
                                $window.localStorage.setItem("pageCampaignTargetArr", JSON.stringify(scope.pageCampaignTargetArr));
                                scope.campaignAudienceCampaignTargetArr = scope.pageCampaignTargetArr;
                                scope.campaignAudienceCampaignTargetLoader = false;

                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    scope.$root.progressLoader = "none";
                                    scope.editAdsetErrorMsg = 'block';
                                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                                        scope.errorpopupHeading = response.data.networkError.error_user_title;
                                        scope.errorMsg = response.data.networkError.error_user_msg;
                                    } else {
                                        scope.errorpopupHeading = 'Error';
                                        scope.errorMsg = response.data.errorMessage;
                                    }
                                }
                            }
                        });

                        scope.FBName = 'Page';

                        $window.localStorage.setItem("campaignAudienceTargetType", "page");
                    } else if (scope.promotionObjective == 'app') {

                        var querystr = "?networkAdAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                        var headers = {
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken")
                        };
                        //FOR APP
                        facebookGetPost.getuserpromotedconnections(querystr, headers).then(function (response) {
                            if (response.data.appStatus == 0) {
                                scope.appCampaignTargetArr = response.apps;
                                scope.campaignAudienceCampaignTargetArr = scope.appCampaignTargetArr;
                                scope.campaignAudienceCampaignTargetLoader = false;

                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    scope.$root.progressLoader = "none";
                                    scope.editAdsetErrorMsg = 'block';
                                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                                        scope.errorpopupHeading = response.data.networkError.error_user_title;
                                        scope.errorMsg = response.data.networkError.error_user_msg;
                                    } else {
                                        scope.errorpopupHeading = 'Error';
                                        scope.errorMsg = response.data.errorMessage;
                                    }
                                }
                            }
                        });

                        scope.FBName = 'App';

                        $window.localStorage.setItem("campaignAudienceTargetType", "app");
                    } else if (scope.promotionObjective == 'event') {

                        var querystr = "?networkAdAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                        var headers = {
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken")
                        };
                        //FOR EVENT
                        facebookGetPost.getuserpromotedconnections(querystr, headers).then(function (response) {
                            if (response.data.appStatus == 0) {
                                var promises = [];
                                //CHECK IF EVENT IS CORRECT OR NOT

                                angular.forEach(response.events, function (value, key) {

                                    var query = value.id + "?access_token=" + scope.$root.networkAccessToken + "&fields=is_page_owned";
                                    facebookGetPost.getfacebookgraph(query).then(function (response) {
                                        if (response.data.appStatus == 0) {
                                            if (eventstatusresponse.is_page_owned) {
                                                var M_Obj = {id: eventstatusresponse.id, name: value.name};
                                                promises.push(M_Obj);
                                                scope.eventCampaignTargetArr = promises;
                                                scope.campaignAudienceCampaignTargetArr = scope.eventCampaignTargetArr;
                                            }
                                        }
                                        else {
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            } else {
                                                scope.$root.progressLoader = "none";
                                                scope.editAdsetErrorMsg = 'block';
                                                if (response.data.networkError != '' && response.data.networkError != undefined) {
                                                    scope.errorpopupHeading = response.data.networkError.error_user_title;
                                                    scope.errorMsg = response.data.networkError.error_user_msg;
                                                } else {
                                                    scope.errorpopupHeading = 'Error';
                                                    scope.errorMsg = response.data.errorMessage;
                                                }
                                            }
                                        }

                                    });

                                });
                                scope.campaignAudienceCampaignTargetLoader = false;
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    scope.$root.progressLoader = "none";
                                    scope.editAdsetErrorMsg = 'block';
                                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                                        scope.errorpopupHeading = response.data.networkError.error_user_title;
                                        scope.errorMsg = response.data.networkError.error_user_msg;
                                    } else {
                                        scope.errorpopupHeading = 'Error';
                                        scope.errorMsg = response.data.errorMessage;
                                    }
                                }
                            }
                        });

                        scope.FBName = 'Event';
                        $window.localStorage.setItem("campaignAudienceTargetType", "event");
                    }
                    ;

                };
                
                scope.init = function () {

                    if ($window.localStorage.getItem("marketingObjective") == 'REACH') {

                        scope.promotionObjective = 'page';
                        angular.element('#step2').css('background-color', '#C2C2C2');
                    }

                    scope.getCampaignTarget();

                }

                scope.init();
                

                scope.$on('promotedobjectdata', function (event, args) {
                    console.log(args);
                    scope.data.campaignAudienceCampaignTarget = args.value;

                })

            }
        }
    }]);