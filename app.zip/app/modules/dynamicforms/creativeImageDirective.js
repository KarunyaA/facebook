dashboard.directive('creativeImage',['facebookGetPost','$window','$filter',function(facebookGetPost,$window,$filter){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/creativeTemplate.html',
	transclude:true,
	scope:{		
		fielddata:'='
		
	},
	link:function(scope,element,attr){
		scope.marketingObjective="";
		scope.fielddata ={};		
		scope.fielddata = {
			campaignAudienceCampaignTarget:"",
			selectedTarget:"",
			textBodyContent:"",
			radioDestination:"",
			messengertextBodyContent:"",
			campaignWebURL:"",
			campaignHeadline1:"",
			learnMoreUrl:"",
			seeMoreUrl:"",
			displayURLoptional:"",
			deepLink:"",
			valAddWebsiteUrl:"",
			webURL:"",
			displayLink:"",
			campaignHeadline:"",
			newsfeedlinkdesc:"",
			callToDirectionValue:"",
			pixelTracking:"",
			campaignURLParameter:"",
			campaignLandingView:"",			
		}

	scope.getPromotablePage = function () {
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');

            facebookGetPost.fetchuserpromotablepages(queryStr, headers).then(function (response) {
                console.log(response);
				console.log("facebook page");

				  response.data.fbUserPromotablePagesResponse = [{

								id:"726949550817444",
								name:"Digital Books"			
							},{
								id:"222",
								name:"Sample Page"

							}]; 

                scope.campaignAudienceCampaignTargetLoader = false;               
                scope.connectFBVal=response.data.fbUserPromotablePagesResponse;
            })
        };
		
		
		scope.init = function(){
			
			 scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
			 scope.getPromotablePage();
				if (scope.selectedTarget == "undefined") {
					scope.selectedTarget = "";
				}	
			scope.marketingObjective = $window.localStorage.getItem("marketingObjective");				
			scope.selectAdvertFormat(scope.marketingObjective);
			scope.$emit('uploadsection',{id:"setLine"});
		};
		
			scope.selectAdvertFormat = function(args){
			    if (args == "POST_ENGAGEMENT") { //Boost your post
                        scope.advertPreviewHeading = "Page and Text";
                        scope.isConnectFBPage = true;
                        scope.isText = true;
                        scope.useExistingPostLink = true;                      
                    }else if(args == "REACH"){
                    //Reach People near your business
                        scope.advertPreviewHeading = "Page and Text";
						scope.isConnectFBPage = true;
						scope.isText = true;
						scope.useExistingPostLink = true; 
						scope.isAddWebsiteUrl = true;
						scope.isCreateShowandHideOptionWrap1 = true;
						scope.fielddata.isCreateShowAdvOption=true;
						if(scope.fielddata.valAddWebsiteUrl){
								scope.isWebsiteurl = true;
                                scope.isDisplayLinkOptional = true;
								scope.isHeadline1 = true;
								scope.isNewsFeedLinkDesc = true;
								scope.isCallToActionOptional = true;
								scope.fielddata.callToDirection = scope.reachPeopleImageAndCarousel;
                                scope.fielddata.callToDirectionValue = "NO_BUTTON";   
						}else{
								scope.isWebsiteurl = false;
                                scope.isDisplayLinkOptional = false;
								scope.isHeadline1 = false;
								scope.isNewsFeedLinkDesc = false;
								scope.isCallToActionOptional = false;
								scope.fielddata.callToDirection = scope.reachPeopleImageAndCarousel;
                                scope.fielddata.callToDirectionValue = "NO_BUTTON"; 
						}
						
					}
		 	  }
	
		    
				scope.init();
		
				scope.assignCreativeData = function(objective,value){
					if(objective == "POST_ENGAGEMENT"){
							scope.fielddata.selectedTarget = value.object_story_spec.page_id;
							scope.fielddata.textBodyContent = value.body;
					  }else if(objective == "REACH"){						                        
                                if (value.object_type == "SHARE" || value.object_type == "PHOTO" ) {
                                    if(scope.carouseladvent == true){
                                        scope.isHeadline = false;
                                        scope.isDestination = false;
                                        scope.isWebURL = false;	
                                        scope.isNewsFeedLinkDesc = false;
                                        scope.isWebsiteurl = false;
                                        scope.isCallToActionOptional = true;
                                        scope.isSeeMoreURL = true;
                                        scope.isAddWebsiteUrl = false;								
                                        scope.textBodyContent = value.object_story_spec.link_data.message;
										 scope.fielddata.textBodyContent = scope.textBodyContent;
                                        scope.selectedTarget = value.object_story_spec.page_id;
										 scope.fielddata.selectedTarget = scope.selectedTarget;
                                        if(value.object_story_spec.link_data.call_to_action!= "undefined"){
                                            scope.callToDirectionValue = value.object_story_spec.link_data.call_to_action.type;
                                        scope.fielddata.callToDirectionValue = scope.callToDirectionValue;
										}
                                        if (value.object_story_spec.link_data.link != "" || value.object_story_spec.link_data.link != "undefined") {
                                            scope.seeMoreUrl = value.object_story_spec.link_data.link;
											scope.fielddata.seeMoreUrl = scope.seeMoreUrl;
                                        }
										
                                    }
                                    else{
                                        if(value.object_story_spec.hasOwnProperty("link_data"))
                                        {
                                            scope.textBodyContent = value.object_story_spec.link_data.message;
											scope.fielddata.textBodyContent = scope.textBodyContent;
                                            scope.selectedTarget = value.object_story_spec.page_id;
												 scope.fielddata.selectedTarget = scope.selectedTarget;
												 scope.fielddata.campaignHeadline = value.object_story_spec.name;
                                            if(value.object_story_spec.link_data.call_to_action)
                                            {
                                                scope.callToDirectionValue = value.object_story_spec.link_data.call_to_action.type;
												  scope.fielddata.callToDirectionValue = scope.callToDirectionValue;
												  
							
                                            }
                                            else
                                            {
                                                scope.callToDirectionValue = "";
												  scope.fielddata.callToDirectionValue = scope.callToDirectionValue;
                                            }
                                            scope.fielddata.valAddWebsiteUrl = true;
                                            scope.checkAddWebsiteUrl(false);
                                            scope.newsfeedlinkdesc = value.object_story_spec.link_data.description;
											 scope.fielddata.newsfeedlinkdesc = scope.newsfeedlinkdesc;
                                            scope.webURL = value.object_story_spec.link_data.link;
											scope.fielddata.webURL = scope.webURL;
                                            if(value.object_story_spec.link_data.caption)
                                            {
                                                scope.displayLink = value.object_story_spec.link_data.caption;
												scope.fielddata.displayLink = scope.displayLink;
                                            }
                                            else
                                            {
                                                scope.displayLink = "";
												scope.fielddata.displayLink = scope.displayLink;
                                            }
                                            scope.campaignHeadline = value.object_story_spec.link_data.name;
											scope.fielddata.campaignHeadline = scope.campaignHeadline;
                                        }
                                        else if(value.object_story_spec.hasOwnProperty("photo_data"))
                                        {
                                            scope.fielddata.textBodyContent = value.body;
                                            scope.fielddata.selectedTarget = value.object_story_spec.page_id;
                                            scope.fielddata.valAddWebsiteUrl = false;
                                            scope.fielddata.newsfeedlinkdesc = "";
                                            scope.fielddata.displayLink = "";
                                            scope.fielddata.campaignHeadline = "";
                                            scope.fielddata.callToDirectionValue = "";
                                            scope.fielddata.webURL = "";
                                            scope.checkAddWebsiteUrl(false);
                                        }

                                        if(value.url_tags)
                                        {
                                            scope.fielddata.campaignURLParameter = value.url_tags;
                                        }
                                        else
                                        {
                                            scope.fielddata.campaignURLParameter = "";
                                        }
                                    }
                                }
                            
					  }					
				}
								       
				scope.selectPromotable = function(selectedTarget){					
					scope.$emit('imagefields',{id:"selectpromotable",target:selectedTarget});
				}	
				
				scope.sendBodyContent=function(textBodyContent){
					scope.$emit('imagefields',{id:"sendbodycontent",value:textBodyContent});
				}
				
				scope.getwebURL = function(getwebURL){
					scope.$emit('imagefields',{id:"getwebURL",value:getwebURL});
				}
				scope.getDisplayLink = function(getDisplayLink){
					scope.$emit('imagefields',{id:"getDisplayLink",value:getDisplayLink});
				}
				scope.sendHeadline = function(sendHeadline){
					scope.$emit('imagefields',{id:"sendHeadline",value:sendHeadline});
				}
				scope.sendnewsfeedlinkdesc = function(sendnewsfeedlinkdesc){
					scope.$emit('imagefields',{id:"sendnewsfeedlinkdesc",value:sendnewsfeedlinkdesc});
				}
				scope.selectCallToAction = function(selectCallToAction){
					scope.$emit('imagefields',{id:"selectCallToAction",value:selectCallToAction});
				}
				scope.selectcampaignURLParameter = function(selectcampaignURLParameter){
					scope.$emit('imagefields',{id:"selectcampaignURLParameter",value:selectcampaignURLParameter});
				}
				
				
			
		scope.getWebURLVal = function(){
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
			//scope.setLine();
		}			
        scope.checkAddWebsiteUrl = function (isThumbnail) {
            $window.localStorage.setItem("valAddWebsiteUrl", isThumbnail);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
			var obj = $window.localStorage.getItem("marketingObjective");
			var fbadvertFormat = $window.localStorage.getItem("fbadvertFormat");
            if(scope.fielddata.valAddWebsiteUrl) {
                switch (obj) {                   
                    case "REACH":
                        if(fbadvertFormat != "fbcarosel")
                        {
                            if(fbadvertFormat == "fbsinglevideo" ||fbadvertFormat == "fbslideshow")
                            {
                                scope.isDisplayLinkOptional = false;
                                scope.isDisplayLink = true;
                                scope.isCallToAction = true;
                                scope.isCallToActionOptional = false;
                            }
                            else if(fbadvertFormat == "fbsingleimage")
                            {                             
								scope.isWebsiteurl = true;
                                scope.isDisplayLinkOptional = true;
								scope.isHeadline1 = true;
								scope.isNewsFeedLinkDesc = true;
								scope.isCallToActionOptional = true;
								scope.fielddata.callToDirection = scope.reachPeopleImageAndCarousel;
                                scope.fielddata.callToDirectionValue = "NO_BUTTON";                               
                            }							
                        }
                        else
                        {
                            scope.isHeadline1 = false;
                            scope.isDisplayLink = false;
                            scope.isDisplayLinkOptional = false;
                        }
                        break;
                  }
            }
            else {
                switch (obj) {                  
                    case "REACH":
                        if(fbadvertFormat != "fbcarosel")
                        {
                            if(fbadvertFormat == "fbsinglevideo" || fbadvertFormat == "fbslideshow")
                            {
                                scope.isDisplayLink = false;
                                scope.isDisplayLinkOptional = false;
                            }
                            else if(fbadvertFormat == "fbsingleimage")
                            {
                                scope.isDisplayLinkOptional = false;
                            }
                            scope.isWebsiteurl = false;
                            scope.isHeadline1 = false;
                            scope.isCallToActionOptional = false;
                            scope.isNewsFeedLinkDesc = false;
                            scope.isCallToAction1 = false;
                            scope.isCallToAction = false;
                        }
                        break;
                 }
            }
            if(isThumbnail != false){
					scope.$emit('imagefields',{id:"removeThumbnail"});
					scope.$emit('imagefields',{id:"checkMandatoryVal"});
					// scope.removeThumbnail();
					// scope.checkMandatoryVal();
			}   
        };
		
		
		scope.createShowAdvancedOption = function () {
            scope.fielddata.isCreateHideAdvOption = true;
            scope.fielddata.isCreateShowAdvOption = false;        
            scope.isUrlParam = true;                                              
			scope.$emit('imagefields',{id:"removeThumbnail"});
			scope.$emit('imagefields',{id:"checkMandatoryVal"});
        };
		
		scope.createHideAdvancedOption = function () {
				scope.fielddata.isCreateHideAdvOption = false;
				scope.fielddata.isCreateShowAdvOption = true;      
				scope.isUrlParam = false;
				scope.$emit('imagefields',{id:"removeThumbnail"});
			    scope.$emit('imagefields',{id:"checkMandatoryVal"});
		};
		
  scope.reachPeopleImageAndCarousel = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "CALL_NOW",
                "name": "Call Now - Phone"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "Get Directions - Street address"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }, {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SAVE",
                "name": "Save"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }
        ];
        
			
			   scope.$on('creativeimage', function (event,args) {
				if(args.id == "objective"){
					scope.marketingObjective = args.objective;
					scope.selectAdvertFormat(scope.marketingObjective);
				}else if(args.id == "creativeData"){
					scope.assignCreativeData(args.objective,args.value);
				}			 
				
		       })
	
	
	}
	
	
}


}]);