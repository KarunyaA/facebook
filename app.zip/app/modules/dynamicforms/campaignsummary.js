var dynamicForm=angular.module('app',['replicator','dashboard']); 
dynamicForm.controller("dynamiccampaignSummaryController", ['$rootScope', '$scope', '$http', '$state', '$location', 'loginService', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', '$filter','netWorkData','facebookGetPost','parser',
function($rootScope, $scope, $http, $state, $location, loginService, Flash, apiService, $window, appSettings, globalData, $filter, netWorkData, facebookGetPost, parser) {
        
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        
        $scope.campaignStatus = '';
        $scope.adStatus = '';
        $scope.adSetStatus = '';
        
        $scope.fifthActiveDiv = 'yes';
        $scope.viewPlacements = false;
        $scope.editAdsetErrorMsg = 'none';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = true;
        $scope.fifthActiveDivImg = false;

        var apiTPBase = appSettings.apiTPBase;
        vm.showDetails = true;
        $scope.campaignplan = [];
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.objective = ''; //Test variable, Not needed remove this decularation
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};
        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        $scope.placement = [];
        $scope.adminUserRole = false;
        $scope.imageSources = [];
        $scope.FBLanguageDetails = [];

        $scope.MediaType = '';
        $scope.languagesValue = '';
        $scope.campaignAudienceLanguageArr = [];
        $scope.campaignAudienceLocationsArr = [];
        var flag = true;
        $rootScope.progressLoader = "block";
        $rootScope.freezeFlag  = false;
		$scope.campaignData = [];
		$scope.facebookReplicatorData = [];
		$scope.objectiveMappingCopy = [];
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
			var modalApproveerr = $(".error_popup_replicator");
            modalApproveerr.hide();
			modalApproveerr =  $(".objective_error_popup_replicator");
+          	modalApproveerr.hide();
        }
		
		$scope.marketingObjName = [
			{
			"id": "POST_ENGAGEMENT",
			"objName": [ {"name": "Boost your posts"} ]
			},
			{
			"id": "PAGE_LIKES",
			"objName": [ {"name": "Promote your page"} ]
			},
			{
			"id": "REACH",
			"objName": [ {"name": "Reach people near your business"} ]
			},
			{
			"id": "BRAND_AWARENESS",
			"objName": [ {"name": "Increase brand awareness"} ]
			},
			{
			"id": "LINK_CLICKS",
			"objName": [ {"name": "Send people to your website"} ]
			},
			{
			"id": "APP_INSTALLS",
			"objName": [ {"name": "Get installs of your app"} ]
			},
			{
			"id": "EVENT_RESPONSES",
			"objName": [ {"name": "Raise attendance at your events"} ]
			},
			{
			"id": "VIDEO_VIEWS",
			"objName": [ {"name": "Get video views"} ]
			},
			{
			"id": "LEAD_GENERATION",
			"objName": [ {"name": "Collect leads for your business"} ]
			},
			{
			"id": "CONVERSIONS",
			"objName": [ {"name": "Increase conversions on website"} ]
			},
			{
			"id": "CANVAS_APP_ENGAGEMENT",
			"objName": [ {"name": "Increase engagements on your app"} ]
			},
			{
			"id": "OFFER_CLAIMS",
			"objName": [ {"name": "Get people to claim your offer"} ]
			}
		]
        function checkMarketingObjective(){
         //MOBILE CAMPAIGN PLACEMENTS ARRAY DETAILS
        if ($window.localStorage.getItem("marketingObjective") == 'POST_ENGAGEMENT') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    },
                    {
                        "name": "Feature Phones Only",
                        "id": "Feature_Phone"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'PAGE_LIKES') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    },
                    {
                        "name": "Feature Phones Only",
                        "id": "Feature_Phone"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'REACH') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    },
                    {
                        "name": "Feature Phones Only",
                        "id": "Feature_Phone"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'BRAND_AWARENESS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'LINK_CLICKS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'APP_INSTALLS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name" : "Desktop News Feed Placements",
                        "id" : "desktopnewsfeed",
                        "pic" : "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = "";
        } else if ($window.localStorage.getItem("marketingObjective") == 'EVENT_RESPONSES') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    },
                    {
                        "name": "Feature Phones Only",
                        "id": "Feature_Phone"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'VIDEO_VIEWS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'LEAD_GENERATION') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'CONVERSIONS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    }
                ]
            };
        } else if ($window.localStorage.getItem("marketingObjective") == 'CANVAS_APP_ENGAGEMENT') {
            $scope.PlacementsArr = {
                "data": [

                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    },
                    {
                        "name": "Desktop Right Column Placements",
                        "id": "desktoprightcolumn",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = "";
        } else if ($window.localStorage.getItem("marketingObjective") == 'OFFER_CLAIMS') {
            $scope.PlacementsArr = {
                "data": [{
                        "name": "Mobile News Feed Placements",
                        "id": "mobilenewsfeed",
                        "pic": "fa fa-mobile"
                    },
                    {
                        "name": "Desktop News Feed Placements",
                        "id": "desktopnewsfeed",
                        "pic": "fa fa-desktop"
                    }
                ]
            };
            $scope.MobileDeviceArr = {
                "data": [{
                        "name": "All Mobile Devices",
                        "id": "allmobiledevices"
                    },
                    {
                        "name": "Android Devices Only",
                        "id": "Android"
                    },
                    {
                        "name": "IOS Devices Only",
                        "id": "iOS"
                    },
                    {
                        "name": "Feature Phones Only",
                        "id": "Feature_Phone"
                    }
                ]
            };
        }
	}
        $scope.defaultreadCampaign = function(){
            $rootScope.progressLoader = "block";
            var campaignId = $window.localStorage.getItem("campaignId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&" + "adCampaignId=" + campaignId
           
			facebookGetPost.readadcampaign(queryStr, headers).then(function(response) {
                if (response.data.appStatus == '0') {
                    var jsonObj = response.data.adcampaigns;
                    angular.forEach(jsonObj, function(value, key) {
                        var JsonObj = jsonObj[key];
                        //console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.campaignDetails = array[+i];
                                //console.log('before campaignDetails');
                                //console.log($scope.campaignDetails);
                                $window.localStorage.setItem("campaignId", $scope.campaignDetails.campaignId);
                                if ($scope.campaignDetails != undefined && $scope.campaignDetails != null & $scope.campaignDetails != " ") {
                                    $scope.objectiveValue = $scope.campaignDetails.campaignDetails.objective;
									angular.forEach($scope.marketingObjName, function(value, key) {
										if ($scope.objectiveValue == $scope.marketingObjName[key].id){
											$scope.objNameList = $scope.marketingObjName[key].objName;
										}
									})
									
									$scope.objectiveNameValue = $scope.objNameList[0].name;								
                                    $window.localStorage.setItem("marketingObjective", $scope.objectiveValue);
                                    $scope.campaignNamevalue = $scope.campaignDetails.campaignDetails.name;
                                    checkMarketingObjective();
                                    $scope.readAdSet($scope.campaignDetails);
                                }
								$scope.facebookReplicatorData.push($scope.campaignDetails);
                            }
                        }
                    });
					
					
                } else {
                    //console.log('campaign fetch failed');
                            if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        }   else {
                $rootScope.progressLoader = "none";
                $scope.showErrorPopup(response);
        }
                }
            });
	}
		
        $scope.readAdSet = function(campaignDetails){
                $rootScope.progressLoader = "block";
		var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
        }
		var queryStr = '?adCampaignId=' + $window.localStorage.getItem('campaignId') + '&' + 'userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId')
              
				facebookGetPost.readadset(queryStr, headers).then(function(response) {
                    if (response.data.appStatus == '0') {
                      //  $rootScope.progressLoader = "none";
                        var jsonObj = response.data.adsets;
                        angular.forEach(jsonObj, function(value, key) {
                            var JsonObj = jsonObj[key];
                            //console.log(JsonObj);
                            var array = [];
                            for (var i in JsonObj) {
                                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                    array[+i] = JsonObj[i];
                                    $scope.adsetDetails = array[+i];
                                    $window.localStorage.setItem("adsetId", $scope.adsetDetails.adsetId);
                                    //$scope.getAdDetails(campaignDetails,$scope.adsetDetails);
                                    $scope.getAdCreativeIdFromFaceBook(campaignDetails,$scope.adsetDetails);
									$scope.facebookReplicatorData.push($scope.adsetDetails);
                                }
                            }
                        });
						$window.localStorage.setItem("facebookReplicatorData", JSON.stringify($scope.facebookReplicatorData));
						
                    } else {
                        //console.log('campaign adset failed');
                        $rootScope.progressLoader = "none";
                               if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    }
                });
		}
	$scope.getAdCreativeIdFromFaceBook = function(campaignDetails,adsetDetails){
              $rootScope.progressLoader = "block";
			var adId = $window.localStorage.getItem("adId");
			//console.log("adId ::: "+adId);
                        if(adId!='' && adId!=null && adId!=undefined){
                           // var queryStr = "https://graph.facebook.com/v2.8/"+adId+"?access_token="+$window.localStorage.getItem("networkAccessToken")+"&fields=creative";
							var queryStr = "?adId=" + adId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
                            
							facebookGetPost.getcreativeid(queryStr).then(function(response) {
                                console.log('*******----------->');
                                var resp =response.data.ads;
								angular.forEach(resp, function(val,key)
								{
												angular.forEach(val, function(val1,key1)
												{
												 if (val1.creative.id) {// success                                
												$window.localStorage.setItem("adCreativeId", val1.creative.id)
												//$scope.readAdCreative();
												$scope.getAdDetails(campaignDetails,adsetDetails);
												}else{
												$rootScope.progressLoader = "none";
												$scope.editAdsetErrorMsg = 'block';
												$scope.errorpopupHeading = 'Error';
												$scope.errorMsg = 'Campaign process flow was not complete. Please navigate from parent campaign screen.';

											    }
												});
								});

                               
                            });
                        }else{
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = 'Campaign process flow was not complete. Please navigate from parent campaign screen.';
                        }
		}
        $scope.getAdDetails = function(campaignDetails, adsetDetails) {
            $rootScope.progressLoader = "block";
            var adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
			
			facebookGetPost.getadcreative(queryStr, headers).then(function(response) {
               // $rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) { // success
                    $scope.adCreativeDetails = response.data.fbAdCreativeResponse;
                    $scope.advertypeforEdit = response.data.fbAdCreativeResponse.object_type;
                    $scope.imageSources = [];
                    $scope.imageSources.push(response.data.fbAdCreativeResponse.thumbnail_url);
                if(typeof($scope.adCreativeDetails.object_story_spec) !== "undefined") {
                    if(typeof($scope.adCreativeDetails.object_story_spec.link_data) !== "undefined" || typeof($scope.adCreativeDetails.object_story_spec.photo_data) !== "undefined"){
                            if($scope.adCreativeDetails.object_story_spec.link_data != undefined){
							   if($scope.adCreativeDetails.object_story_spec.link_data.child_attachments != undefined){
										$scope.MediaType = "Carousel";
								  }
								else{
                        if ($scope.advertypeforEdit == "VIDEO") {
                            $scope.MediaType = "Single Video";
                        } else if ($scope.advertypeforEdit == "PHOTO") {
                            $scope.MediaType = "Single Image";
                        } else if ($scope.advertypeforEdit == "SHARE") {
                            $scope.MediaType = "Single Image";
                        }
                    }
								  
                            }else if ($scope.advertypeforEdit == "VIDEO") {
                                $scope.MediaType = "Single Video";
                            } else if ($scope.advertypeforEdit == "PHOTO") {
                                $scope.MediaType = "Single Image";
                            } else if ($scope.advertypeforEdit == "SHARE") {
                                $scope.MediaType = "Single Image";
                            }
                    }else{
                        if ($scope.advertypeforEdit == "VIDEO") {
                            $scope.MediaType = "Single Video";
                        } else if ($scope.advertypeforEdit == "PHOTO") {
                            $scope.MediaType = "Single Image";
                        } else if ($scope.advertypeforEdit == "SHARE") {
                            $scope.MediaType = "Single Image";
                        }
                    }
                    
                        if(typeof($scope.adCreativeDetails.object_story_spec.video_data) !== "undefined"){
                            if(typeof($scope.adCreativeDetails.object_story_spec.video_data.video_id) !== "undefined"){
                                $scope.MediaType = "Single Video";
                            }
                        }
                    }
					
                    if($scope.adCreativeDetails.object_type == "PAGE")
                    {
                        $scope.MediaType = "Single Image";
                    }
                    if(flag == true){
                        flag = false;
                        $scope.prePopulateValues(campaignDetails,adsetDetails,$scope.MediaType);
                    }
                    

                } else { // failed
                    //console.log("failed");
                           if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }
		
		$scope.checkCurrencyCode = function(_code) {
			console.log($scope.currencyList);
			angular.forEach($scope.currencyList, function(value, key) {				
				if($scope.currencyList[key].currency == _code){
					console.log($scope.currencyList[key].currencyCode+" --- "+_code);
					$scope.currencyValue = $scope.currencyList[key].currencyCode;					
					console.log($scope.currencyValue);
					return $scope.currencyList[key].currencyCode;
					
				}
			});
			
			$scope.currencyCode = $scope.currencyValue;			
		}
		
	function callPrePopulate(){
			//$scope.prePopulateValues()
		}
	
	
		$scope.loadCurrencyCode = function(){
			$http.get("localData/currencyData.json").success(function (data){
				$scope.currencyList = data.currencyList;
				console.log($scope.currencyList);
			});
		}

        $scope.init = function() {
                    
            $rootScope.progressLoader = "block";
            console.log(objectiveMapping);
			$scope.objectiveMappingCopy =  objectiveMapping;
            //FOR CAMPAIGN STATUS AND AD STATUS AND ADSET STATUS CHECKING 
            readCampaign('checking');
            readAdsetDetails('checking');
            getAd('checking');
            
            
            $rootScope.step = 5;
            $scope.overLay = false;
           
            $scope.campaignState = $window.localStorage.getItem("campaignState")

            if ($window.localStorage.getItem("role") == "Account") {
                $scope.adminUserRole = true;
            } else {
                $scope.adminUserRole = false;
            }
            $scope.defaultreadCampaign();
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            $scope.todayDate = new Date();
            $scope.minDate = new Date();
            $scope.campaignplan.accountCountryName = "India"
            $scope.campaignplan.currency = "Indian Rupee"
            $scope.campaignplan.description = "Asia/Kolkata"
            $scope.campaignplan.adAccName = "Digi Live"
            $scope.campaignplan.advertSetName = "createAdsetTest1"
            
            $scope.readadAccountId();
            // $rootScope.progressLoader = "none";
			$scope.loadCurrencyCode();
			
			$scope.setLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
						$scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
						var offsetHeight2 = document.getElementById('step2container').offsetHeight;
						var fStep = $(".vr");
						fStep.css('height', (($scope.lsValue - $scope.fsValue)));
					}
				}, 10);
			};
			$scope.setLine();
        }

        
        $scope.readadAccountId = function () {
            
            $rootScope.progressLoader = "block";
			 var queryStr = "?networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			 var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
			
			facebookGetPost.readadaccounts(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    //$rootScope.progressLoader = "none";
                    //console.log(response.data.fbReadAdAccountResponse);
                    angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {
                        $scope.currency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                    });
					$scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
					 console.log("currency = "+$scope.currency);
					 console.log("currency = "+$scope.currencyCode);
                    //console.log("currency = "+$scope.currency)
                   /* if ($scope.currency == "INR") {
                        $scope.inr = true;
                        $scope.usd = false;
						$scope.eur = false;
						$scope.gpb = false;
                    } else if ($scope.currency == "USD") {
                        $scope.inr = false;
                        $scope.usd = true;
						$scope.eur = false;
						$scope.gpb = false;
                    } else if ($scope.currency == "EUR") {
                        $scope.inr = false;
                        $scope.usd = false;
						$scope.eur = true;
						$scope.gpb = false;
                    } else if ($scope.currency == "GPB") {
                        $scope.inr = false;
                        $scope.usd = false;
						$scope.eur = false;
						$scope.gpb = true;
                    } */
                } else {// failed
                    $rootScope.progressLoader = "none";

                           if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                }

            });

        };
        
    /*    $scope.fetchAdsetDetails = function(cDetails) {
            $http({
                url: apiTPBase + '/readadset?adCampaignId=' + cDetails.data.campaignId + '&' + 'userNetworkMapId=' + $window.localStorage.getItem('userNetworkMapId'),
                //url : apiTPBase +'/readadset?adCampaignId='+'23842528654890109'+'&'+'userNetworkMapId='+$window.localStorage.getItem('userNetworkMapId'),
                dataType: 'json',
                method: 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function(response) {
                console.log(response)
                if (response.appStatus == 0) {
                    angular.forEach(response.adsets, function(value, key) {
                        var JsonObj = response.adsets[key]
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                console.log(i)
                                $window.localStorage.setItem("adsetId", i)
                                //globalData.setLocal("adset", i,  array[+i]);
                                //$scope.prePopulateValues($scope.campaignDetails, i)
                            }
                        }
                    });
                }
            }).error(function(error) {
                //alert(error);
            });

        }*/
        $scope.getDetailedTargetingDetails = function(aDetails) {
            $scope.targetingArray = aDetails.adsetDetails.targeting.user_adclusters //JSON.parse($window.localStorage.getItem("campaignAudienceDTselection"));
            $scope.targetingDisplayArray = [];
            angular.forEach($scope.targetingArray, function(value, index) {
                $scope.targetingDisplayArray.push(value.name);
            });

            $scope.interestsArray = aDetails.adsetDetails.targeting.interests;
            angular.forEach($scope.interestsArray, function(value, index) {
                $scope.targetingDisplayArray.push(value.name);
            });

            $scope.behaviorsArray = aDetails.adsetDetails.targeting.behaviors;
            angular.forEach($scope.behaviorsArray, function(value, index) {
                $scope.targetingDisplayArray.push(value.name);
            });
        };
		/*
        $scope.prePopulateFromLocalStorage = function(aDetails, cDetails) {
            if (cDetails != undefined && cDetails != null & cDetails != " ") {
                $scope.objectiveValue = $window.localStorage.getItem("marketingObjectiveName");
                $scope.campaignNamevalue = cDetails.data.campaignDetails.name
            }
            console.log(cDetails.data.campaignDetails.name)
            if (aDetails != undefined && aDetails != null & aDetails != " ") {
                $scope.agefromValue = aDetails.data.fbAdsetDetails.targeting.age_min
                $scope.agetoValue = aDetails.data.fbAdsetDetails.targeting.age_max
                $scope.genderValue = $window.localStorage.getItem("campaignAudienceGender");
                $scope.languagesValue = $window.localStorage.getItem("campaignAudienceLanguage");

                $scope.mobileDeviceValue = aDetails.data.fbAdsetDetails.targeting.device_platforms;
                if (aDetails.data.fbAdsetDetails.daily_budget == 0) {
                    $scope.dailybudget = aDetails.data.fbAdsetDetails.lifetime_budget;
                } else {
                    $scope.dailybudget = aDetails.data.fbAdsetDetails.daily_budget;
                }
                $scope.campaignMediaFormat = $window.localStorage.getItem("campaignMediaFormat");
                $scope.targetAudiencevalue = aDetails.data.fbAdsetDetails.targeting.geo_locations.countries;
                $scope.getDetailedTargetingDetails();
                $scope.campaignAudienceLocations = $window.localStorage.getItem("campaignAudienceLocationsArr");
                $scope.mobilenewfeed = $window.localStorage.getItem("campaignAudiencePlacementsValues");
                $scope.mobileDeviceValue = $window.localStorage.getItem("campaignAudienceMobileDevice");
                console.log($scope.dailybudget)

            }
        }*/
        $scope.prePopulateValues = function(cDetails,aDetails,MediaType) {
            
            $rootScope.progressLoader = "block";
            $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken")           
            if (aDetails.adsetDetails != undefined && aDetails.adsetDetails != null & aDetails.adsetDetails != " ") {
                $scope.agefromValue = aDetails.adsetDetails.targeting.age_min;
                $scope.agetoValue = aDetails.adsetDetails.targeting.age_max;
                var gender = "";
                if(aDetails.adsetDetails.targeting.genders != undefined){
                    if (aDetails.adsetDetails.targeting.genders[0] == 1) {
                        gender = "Men";
                    } else if (aDetails.adsetDetails.targeting.genders[0] == 2) {
                        gender = "Women";
                    }
                } else {
                    gender = "All";
                }
				
                $scope.genderValue = gender;
                $scope.languagesValue = aDetails.adsetDetails.targeting.locales //$window.localStorage.getItem("campaignAudienceLanguage");

                $scope.mobileDeviceValue = aDetails.adsetDetails.targeting.device_platforms;

                if (aDetails.adsetDetails.daily_budget == 0) {
                    $scope.dailybudget = aDetails.adsetDetails.lifetime_budget;
                } else {
                    $scope.dailybudget = aDetails.adsetDetails.daily_budget;
                }               
                $scope.getDetailedTargetingDetails(aDetails);
                $scope.scheduleStartDate = aDetails.adsetDetails.start_time;
                $scope.scheduleEndDate = aDetails.adsetDetails.end_time;
                //FOR COUNTRY
                //console.log("countries here : " + aDetails.adsetDetails.targeting.geo_locations.countries);
                if (aDetails.adsetDetails.targeting.geo_locations.countries != '' && aDetails.adsetDetails.targeting.geo_locations.countries != undefined) {
                    //console.log('--------');
                    angular.forEach(aDetails.adsetDetails.targeting.geo_locations.countries, function(val, key) {
					 var querystr = '?type=adgeolocationmeta&countries=["' + val + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {
                            $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                            $scope.campaignAudienceLocationsArr.push($scope.FBCountryDetails.countries[val].name);

                        })

                    });
                }

                //FOR REGION
                if (aDetails.adsetDetails.targeting.geo_locations.regions != '' && aDetails.adsetDetails.targeting.geo_locations.regions != undefined) {

                    angular.forEach(aDetails.adsetDetails.targeting.geo_locations.regions, function(val, key) {
					     var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {
                            $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                            $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + $scope.FBCountryDetails.countries[val.country].name);

                        })
                    });

                }

                //FOR CITIES
                if (aDetails.adsetDetails.targeting.geo_locations.cities != '' && aDetails.adsetDetails.targeting.geo_locations.cities != undefined) {

                    angular.forEach(aDetails.adsetDetails.targeting.geo_locations.cities, function(val, key) {
					       var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                            $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                            $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + val.region + ' / ' + $scope.FBCountryDetails.countries[val.country].name);

                        })

                    });
                }


                $scope.mobilenewfeed = '';
				$scope.mobileNewsArray=[];
                $scope.devicePlatforms=[];
				$scope.facebookPositions=[];
                
				$scope.devicePlatforms = angular.forEach(aDetails.adsetDetails.targeting.device_platforms, function(value, key) {
					if (aDetails.adsetDetails.targeting.device_platforms[key] != 'undefined') {
						if (key < aDetails.adsetDetails.targeting.device_platforms.length) {
							$scope.devicePlatforms.push(value);
						}
					}
				})
				
				$scope.facebookPositions=angular.forEach(aDetails.adsetDetails.targeting.facebook_positions, function(value, key) {
					if (aDetails.adsetDetails.targeting.facebook_positions[key] != 'undefined') {
						if (key < aDetails.adsetDetails.targeting.facebook_positions.length) {
							$scope.facebookPositions.push(value);
						}
					}
				})
				
				if($scope.facebookPositions.indexOf("feed") != -1 && $scope.devicePlatforms.indexOf("mobile") != -1){
					 $scope.mobileNewsArray.push("Mobile News Feed");
				}
				
				if($scope.facebookPositions.indexOf("feed") != -1 && $scope.devicePlatforms.indexOf("desktop") != -1){
					 $scope.mobileNewsArray.push("Desktop News Feed");
				}
				
				if($scope.facebookPositions.indexOf("right_hand_column") != -1 && $scope.devicePlatforms.indexOf("desktop") != -1){
					 $scope.mobileNewsArray.push("Desktop Right Column");
				}
				
				angular.forEach($scope.mobileNewsArray,function(value,key){
					if(key != $scope.mobileNewsArray.length - 1){
						$scope.mobilenewfeed+=value+', ';
					}else{
						$scope.mobilenewfeed+=value;
					}
				})
				console.log(aDetails.adsetDetails.targeting.user_device);				
				
                //console.log(aDetails.adsetDetails.targeting.user_os);
                $scope.campaignAudienceMobileDevice = '';
                if((aDetails.adsetDetails.targeting.user_os!='' && aDetails.adsetDetails.targeting.user_os!=undefined)){ 
                    if (aDetails.adsetDetails.targeting.user_os[0] == 'Android' || aDetails.adsetDetails.targeting.user_os[0] == 'iOS') {
                        //console.log($scope.MobileDeviceArr);
                        var sobject = $filter('filter')($scope.MobileDeviceArr.data, function(d) {
                            return d.id == aDetails.adsetDetails.targeting.user_os;
                        })[0];
                        $scope.campaignAudienceMobileDevice = sobject.name;
                    }
                }
                //console.log('campaignAudienceMobileDevice ::::: ');
                //console.log(aDetails.adsetDetails.targeting);
                if((aDetails.adsetDetails.targeting.user_device!='' && aDetails.adsetDetails.targeting.user_device!=undefined)){ 
                    if(aDetails.adsetDetails.targeting.user_device == 'Feature_Phone') {
                        var sobject = $filter('filter')($scope.MobileDeviceArr.data, function(d) {
                            return d.id == aDetails.adsetDetails.targeting.user_device;
                        })[0];
                        $scope.campaignAudienceMobileDevice = sobject.name;
                    }
                }

				if($scope.mobileNewsArray.indexOf("Mobile News Feed") != -1 && aDetails.adsetDetails.targeting.user_os==undefined &&(aDetails.adsetDetails.targeting.user_device == ''|| aDetails.adsetDetails.targeting.user_device == undefined)){
					$scope.campaignAudienceMobileDevice = 'All Mobile Devices';
				}
				
				if( $scope.campaignAudienceMobileDevice == ''){
					$scope.viewPlacements = false;
				}else{
					$scope.viewPlacements = true;
				}				


                $scope.getAdDetails();
                $scope.campaignMediaFormat = MediaType; //$window.localStorage.getItem("campaignMediaFormat");
                //$scope.imageSources.push($window.localStorage.getItem("campaignMediaURL"));

                //LANGUAGE FB SERVICE DETAILS
				var queryStr ="?type=adLocale" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
               
				facebookGetPost.demographictargetingsearch(queryStr).then(function(response) {
                                    $rootScope.progressLoader = "none";
                    $scope.FBLanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
                    angular.forEach(aDetails.adsetDetails.targeting.locales, function(val){                        
                        var sObj = $filter('filter')($scope.FBLanguageDetails, function(d){return d.key == val;})[0];
                        $scope.campaignAudienceLanguageArr.push(sObj.name);                            
                    });
                    
                    /*var sObj = $filter('filter')($scope.FBLanguageDetails, function(d) {						
                        return d.key == aDetails.adsetDetails.targeting.locales
                    })[0];
                    if(sObj!='' && sObj!=undefined && aDetails.adsetDetails.targeting.locales!=undefined){
                        $scope.languagesValue = sObj.name;
                    }*/

                });
                
            }
            
            //$rootScope.progressLoader = "none";
        }


        $scope.todayDate = new Date();
       
        $scope.getEditCampaignDetails = function() {
            var campaignId = $window.localStorage.getItem('campaignId')
            var adsetId = $window.localStorage.getItem('adsetId')
            var campaignDetails = globalData.getLocal(campaignId)
            var adsetDetails = globalData.getLocal(adsetId)
            if (campaignDetails != undefined && campaignDetails != null & campaignDetails != " ") {
                $scope.objectiveValue = campaignDetails.data.campaignDetails.objective
                //$scope.campaignNamevalue = campaignDetails.data.campaignDetails.name
            }
            console.log(campaignDetails)
            console.log(adsetDetails);
            if (adsetDetails != undefined && adsetDetails != null & adsetDetails != " ") {
                $scope.agefromValue = adsetDetails.data.adsetDetails.targeting.age_min
                $scope.agetoValue = adsetDetails.data.adsetDetails.targeting.age_max
                $scope.genderValue = $window.localStorage.getItem("campaignAudienceGender");
                $scope.languagesValue = $window.localStorage.getItem("campaignAudienceLanguage");

                $scope.mobileDeviceValue = adsetDetails.data.adsetDetails.targeting.device_platforms;
                $scope.targetAudiencevalue = $window.localStorage.getItem("campaignaudienceDetailedTargeting");


                $scope.mobileDeviceValue_1 = $window.localStorage.getItem("MFeedcampaignAudiencePlacements");
                $scope.mobileDeviceValue_2 = $window.localStorage.getItem("DFeedcampaignAudiencePlacements");
                $scope.mobileDeviceValue_3 = $window.localStorage.getItem("DRColumncampaignAudiencePlacements");
                $scope.campaignAudienceLocations = $window.localStorage.getItem("campaignAudienceLocationsArr");

                $scope.dailybudget = adsetDetails.data.adsetDetails.daily_budget;

                if (adsetDetails.data.adsetDetails.daily_budget == 0) {
                    $scope.dailybudget = adsetDetails.data.adsetDetails.lifetime_budget;
                } else {
                    $scope.dailybudget = adsetDetails.data.adsetDetails.daily_budget;
                }

                if (adsetDetails.data.adsetDetails.end_time == null || adsetDetails.data.adsetDetails.end_time == undefined || adsetDetails.data.adsetDetails.end_time == " ") {
                    $scope.scheduleStartDate = adsetDetails.data.adsetDetails.start_time
                    $scope.scheduleEndDate = adsetDetails.data.adsetDetails.start_time
                } else {

                }

                $scope.placement.push($scope.mobileDeviceValue_1)
                $scope.placement.push($scope.mobileDeviceValue_2)
                $scope.placement.push($scope.mobileDeviceValue_3)
            }

        }
        /*End of summary Page Temp Variables*/
        $scope.selectBudget = function(_obj) {

            if (_obj.name == "Daily Budget") {
                $scope.campaignplan.budgetValue = "20"
            } else {
                $scope.campaignplan.budgetValue = "50"
            }
        }
        $scope.selectAdvertDelivery = function(_obj) {
            $scope.campaignplan.advertDelivery = _obj.name

        }
        $scope.selectSchedule = function(value) {
            if (value == 1) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
            }
        }
        $scope.onDateChange1 = function(selectedDate) {
            $scope.startDate = selectedDate

            var _date = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');

            if ($scope.startDate > $scope.todayDate) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');
            } else {
                console.log('less than')
            }
        }
        $scope.onDateChange2 = function(selectedDate) {
            $scope.endDate = selectedDate
            console.log($scope.endDate)
            if ($scope.endDate > $scope.startDate) {
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.endDate), 'yyyy-mm-dd HH:mm:ss');
                console.log($scope.campaignplan.scheduleEndDate)
            } else {
                console.log('less than')
            }
        }
        $scope.selectBidAmount = function(value) {
            if (value == 1) {
                $scope.showText = false;
                $scope.campaignplan.bidAmount = "1000"
            } else {
                $scope.showText = true;
            }
        }
        $scope.saveBidAmount = function(value) {
            $scope.campaignplan.bidAmount = value;

        }
        $scope.gotoParentCampaign = function() {
            $rootScope.campaignSteps[4] = true;
            console.log($rootScope.campaignSteps);
            $state.go('app.parentcampaign');
			$rootScope.freezeFlag = false;
        }
        $scope.init();
        /*  $scope.postCampaignPlan = function (data) {
              console.log($scope.campaignplan)

              var headers = {
                  "Content-Type": "application/json"
              }

              var parameters = {
                  "userId": $window.localStorage.getItem("userId"),
                  "accessToken": $window.localStorage.getItem("accessToken"),
                  "networkAdAccountId": "114680145658525",
                  "dailyBudget": $scope.campaignplan.budgetValue,
                  "isAutobid": "true",
                  "adlabels": [
                      {"name": "adLabelN1"}
                  ],
                  "name": $scope.campaignplan.advertSetName,
                  "billingEvent": "IMPRESSIONS",
                  "campaignId": "23842529546860715",
                  "targeting": {
                      "geo_locations": {
                          "countries": ["US"]}
                  },
                  "status": "PAUSED",
                  //"networkAccessToken": "EAAFMB7HwTnoBAE5hdTzFbPQgcKsGOaOX9RUWpZAshWv7dMxqTHx7TbofgdUpWClS5qlz0IhskZCWK7Rkd1Voo8YgcgIlvsGsH5ijA4FX7AqiFgQuIzOdYFgKr1bfAmEOGEKuGbq9afcssTBDj3u52YVOOKuTMwIXPcXVO8uQZDZD",
                  "networkAccessToken" : $window.localStorage.getItem("networkAccessToken"),
                  "userNetworkMapId": "300013"
              }
          }*/
        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */
        $scope.result = 'pass';

        function getCampaignDetailsFromFB(campaignId) {
            var headers = {
                "Content-Type": "application/json",
                "userId": $scope.userId,
                "accessToken": $scope.accessToken
            }
            console.log(campaignId)
            var queryStr = "?campaignId=" + campaignId + "&" + "userNetworkMapId=300002";
          
			facebookGetPost.getcampaignbycampaignid(queryStr, headers).then(function(response) {
                console.log(response);
                if (response.data.appStatus == '0') { // success

                } else { // failed
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }

                }
            });
        }
        //saveCampaignDataToLocalDB();
        vm.createCampaignObjective = function(data) {

            if (data.objective == undefined) {
                alert('Please Select Marketing Objective');
                return true;
            }
            loginService.campService(data).then(function(response) {
                if (response.appStatus == 0) {
                    console.log(response.campaignId);
                    $window.localStorage.setItem("campaignId", response.campaignId);
                    $window.localStorage.setItem("objective", data.objective);
                    getCampaignDetailsFromFB(response.campaignId);
                    $state.go('app.campaignaudience');
                } else {
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }

            });
        };
        vm.campSummaryAction = function(data) {
            
            console.log('updatecampaign status ::: ');
            $rootScope.progressLoader = "block";            
            
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "campaignId": $window.localStorage.getItem("campaignId"),
                "status": "ACTIVE"
            };
           
			facebookGetPost.updatecampaign("", parameters).then(function(response) {
                console.log(response);
                $rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    $scope.updateadset();
                } else {
                           if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    
                }
            });
                        
            
//            var fbCampUrl = "https://graph.facebook.com/v2.8/" + fbCampaignId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
//            $http({
//                url: fbCampUrl
//            }).then(function(response) {
//                $rootScope.progressLoader = "none";
//                $scope.updateadset();
//            }).catch(function(error) {
//                $rootScope.progressLoader = "none";
//                if(error.data.error.code=='190'){
//                    $window.localStorage.setItem("TokenExpired",true);
//                    $state.go('login');
//                }else{
//                    $rootScope.progressLoader = "none";
//                    $scope.editAdsetErrorMsg = 'block';
//                    if(error.data.error.error_user_title!='' && error.data.error.error_user_title!=undefined && error.data.error.error_user_title!=null){
//                        $scope.errorpopupHeading = error.data.error.error_user_title;
//                        $scope.errorMsg = error.data.error.error_user_msg;
//                    }else{
//                        $scope.errorpopupHeading = 'Error';
//                        $scope.errorMsg = error.data.error.message;
//                    }
//                    
//                }
//            });

    
        };

        $scope.updateadset = function(){
            
            console.log('updateadset ::: ');            
            $rootScope.progressLoader = "block";
            
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetId": $window.localStorage.getItem("adsetId"),
                "status": "ACTIVE"
            };
           
			facebookGetPost.updateadset("", parameters).then(function(response) {
                console.log(response);
                //$rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    $scope.updatead();
                } else {
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    
                }
            });
            
//            var fbSetId = $window.localStorage.getItem("adsetId");
//            var fbSetUrl = "https://graph.facebook.com/v2.8/" + fbSetId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
//            $http({
//                url: fbSetUrl
//            }).then(function(response) {
//                $rootScope.progressLoader = "none";
//                $scope.updatead();
//            }).catch(function(error) {
//                //console.log(error);
//                $rootScope.progressLoader = "none";
//                if(error.data.error.code=='190'){
//                    $window.localStorage.setItem("TokenExpired",true);
//                    $state.go('login');
//                }else{
//                    $rootScope.progressLoader = "none";
//                    $scope.editAdsetErrorMsg = 'block';
//                    if(error.data.error.error_user_title!='' && error.data.error.error_user_title!=undefined && error.data.error.error_user_title!=null){
//                        $scope.errorpopupHeading = error.data.error.error_user_title;
//                        $scope.errorMsg = error.data.error.error_user_msg;
//                    }else{
//                        $scope.errorpopupHeading = 'Error';
//                        $scope.errorMsg = error.data.error.message;
//                    }
//                }
//            });           
           
            
        };

        $scope.updatead = function(){       
            
            console.log('updatead ::: ');
            $rootScope.progressLoader = "block";
            
            
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "status": "ACTIVE"
            };
           
			facebookGetPost.updatead("", parameters).then(function(response) {
                console.log(response);
                //$rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    getAd('save');
                } else {
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    
                }
            });
            
            
//            var fbAdId = $window.localStorage.getItem("adId");
//            var fbAdUrl = "https://graph.facebook.com/v2.8/" + fbAdId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
//            $http({
//                url: fbAdUrl
//            }).then(function(response) {
//                console.log(response);
//                $rootScope.progressLoader = "none";
//                //here final call for get-add / save-add / get-adset / save-adset / get-campaign / save-campaign
//                getAd('save');
//            }).catch(function(error) {
//                console.log(error);
//                $rootScope.progressLoader = "none";
//                if(error.data.error.code=='190'){
//                    $window.localStorage.setItem("TokenExpired",true);
//                    $state.go('login');
//                }else{
//                    $rootScope.progressLoader = "none";
//                    $scope.editAdsetErrorMsg = 'block';
//                    if(error.data.error.error_user_title!='' && error.data.error.error_user_title!=undefined && error.data.error.error_user_title!=null){
//                        $scope.errorpopupHeading = error.data.error.error_user_title;
//                        $scope.errorMsg = error.data.error.error_user_msg;
//                    }else{
//                        $scope.errorpopupHeading = 'Error';
//                        $scope.errorMsg = error.data.error.message;
//                    }
//                }
//            });            
            
        };
            
            
        //-------------------------------
        function getAd (conditions) {
            
            console.log('getAd ::: ');
            $rootScope.progressLoader = "block";
            
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
          
			facebookGetPost.getad(queryStr, headers).then(function(response) {
                console.log(response);
               // $rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') { // success
                    $scope.adData = response.data.adData; // need to change adsets instead of adData when backend change
                    console.log('@@@@@@@@@@@ adStatus = '+response.data.adData.status);
                    $scope.adStatus = response.data.adData.status;
                    if(conditions!='checking'){
                        $scope.saveAd($scope.adData);
                    }
                    console.log("get Ad success");
                } else { // failed
                    console.log("failed");
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    //Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }
        $scope.saveAd = function(adData) {
            console.log('saveAd ::: ');
            $rootScope.progressLoader = "block";
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": adData
            };
            
			facebookGetPost.saveaddata("", parameters).then(function(response) {
                console.log(response.data.appStatus);
               // $rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    //$rootScope.progressLoader = "none";
                    readAdsetDetails('save');

                } else {
                    console.log('failed')
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    //Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }

        $scope.getAdCreative = function() { 
            var queryStr = "?adsetid=" + $window.localStorage.getItem("adsetId") + "&networkmapid=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           
			facebookGetPost.getadcreative(queryStr, headers).then(function(response) {
                //console.log(response);
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";// success
                    $scope.fbAdCreativeResp = response.data.fbAdCreativeResponse;
                    for (var i = 0; i < response.data.fbAdCreativeResponse.data.length; i++) {
                        if ($window.localStorage.getItem("adCreativeId") == response.data.fbAdCreativeResponse.data[i].id) {
                            $scope.respAdCreativeObj = response.data.fbAdCreativeResponse.data[i];
                        }
                    }                    
                    $scope.saveAdAccountAdCreative($scope.respAdCreativeObj);
                } else { // failed
                    console.log("failed");
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }

        $scope.saveAdAccountAdCreative = function(respGetAdCreativeObj) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetID": $window.localStorage.getItem("adsetId"), //"101870703634673", // remove from config or b4 services
                "adCreativeID": $window.localStorage.getItem("adCreativeId"),
                "adCreativeDetails": respGetAdCreativeObj,
            };
           
			facebookGetPost.saveadsetadcreative("", parameters).then(function(response) {
                console.log(response);
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    readAdsetDetails('save');
                } else {
                    console.log('failed')
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    //$rootScope.progressLoader = "none";
                    //Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }
        function readAdsetDetails (conditions) {
            
            console.log('readAdsetDetails ::: ');
            $rootScope.progressLoader = "block";
            
            var netWorkMapId = $window.localStorage.getItem('userNetworkMapId');
            var adsetId = $window.localStorage.getItem('adsetId');
			var headers = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + netWorkMapId + "&adSetId=" + adsetId;
            
			facebookGetPost.getadset(queryStr,headers).then(function(response) {
                console.log('@@@@@@@@ adSetStatus = '+response.data.adsets.status);
                $scope.adSetStatus = response.data.adsets.status;
                //$rootScope.progressLoader = "none";
                if(conditions!='checking'){
                    $scope.saveAdSet(response);
                }
                
            });
        }
        $scope.saveAdSet = function(adsetDetails) {
            console.log(adsetDetails);
            console.log('saveAdSet ::: ');
            $rootScope.progressLoader = "block";
            var parameters = {
                "userId": $window.localStorage.getItem('userId'),
                "accessToken": $window.localStorage.getItem('accessToken'),
                "fbAdsetId": $window.localStorage.getItem("adsetId"),
                "fbAdsetDetails": adsetDetails.data.adsets,
                "userNetworkMapId": $window.localStorage.getItem('userNetworkMapId')
            }
           
			facebookGetPost.saveadsetdata("", parameters).then(function(response) {
                console.log(response);
                //$rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    readCampaign('save');
                } else {
                           if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                }

            })
        }
        function readCampaign(conditions) {
            
            console.log('readCampaign ::: ');
            $rootScope.progressLoader = "block";
            
            var headers = {
                "Content-Type": "application/json",
                "userId": $scope.userId,
                "accessToken": $scope.accessToken
            }
            var queryStr = "?campaignId=" + $window.localStorage.getItem('campaignId') + "&" + "userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            
			facebookGetPost.getcampaignbycampaignid(queryStr, headers).then(function(response) {
                //console.log(response);
                //$rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') { // success
                    console.log('@@@@@@@@@@@ campaignStatus = '+response.data.campaign.status);
                    $scope.campaignStatus = response.data.campaign.status;
                    if(conditions!='checking'){
                        $scope.saveCampaign(response);
                    }

                } else { // failed
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                }
            });
        }
        $scope.saveCampaign = function(response) {
            
            console.log('saveCampaign ::: ');
            $rootScope.progressLoader = "block";
            
            var networkMapId = $window.localStorage.getItem("userNetworkMapId");
            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": networkMapId,
                "parentCampaignId": $window.localStorage.getItem("parentCampaignId"),
                "adAccountId": response.data.campaign.account_id,
                "campaignId": $window.localStorage.getItem("campaignId"),
                "campaignDetails": response.data.campaign
            }
           
			facebookGetPost.savecampaigndata("", parameters).then(function(response) {
                console.log(response);

                if (response.data.appStatus == '0') { // success
                    console.log('campaign Save success')
                    //$rootScope.progressLoader = "none";
                    $scope.successPopup();
                } else { // failed
                    $rootScope.progressLoader = "none";
                    
                          if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                                $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                         $scope.showErrorPopup(response);
                        }
                    
                    //$scope.successPopup();
                }
            });

        }
        
        $scope.showErrorPopup = function(response) {
        console.log(response);
        if(response.hasOwnProperty("data")){
                                                if (response.data.networkError) {
                                                                if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined) {
                                                                                $scope.popupTitle = response.data.networkError.error_user_title;
                                                                                $scope.popupMessage = response.data.networkError.error_user_msg;
                                                } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {

                $scope.popupTitle = "Error";
                $scope.popupMessage = response.data.networkError.message;
                                                                }
                                                }else{
                                                                $scope.popupTitle = "Error";
                $scope.popupMessage = response.data.errorMessage;
                                                }
                                }else {
                                                if (response.networkError) {
                                                                if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                                                                                $scope.popupTitle = response.networkError.error_user_title;
                                                                                $scope.popupMessage = response.networkError.error_user_msg;
                                                                } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                                                                                $scope.popupTitle = "Error";
                                                                                $scope.popupMessage = response.networkError.message;
                                                                                }
                                                }else{
                                                                $scope.popupTitle = "Error";
                $scope.popupMessage = response.errorMessage;
                                                                }
               
                                                }

        var modalApproveReq = $(".error_popup"); // Get the modal Approve req
                modalApproveReq.show();
        }

        //----------------------------

        $scope.accountItems = [{
            "id": 1,
            "name": "Linux",
            "description": null,
            "code": null
        }, {
            "id": 2,
            "name": "Windows",
            "description": null,
            "code": null
        }]
        $scope.currencyItems = [{
            "id": 1,
            "name": "Linux",
            "description": null,
            "code": null
        }, {
            "id": 2,
            "name": "Windows",
            "description": null,
            "code": null
        }]
        $scope.timeZoneItems = [{
            "id": 1,
            "name": "Linux",
            "description": null,
            "code": null
        }, {
            "id": 2,
            "name": "Windows",
            "description": null,
            "code": null
        }]
        $scope.budgetItems = [{
            "id": 1,
            "name": "Daily Budget",
            "description": null,
            "code": null
        }, {
            "id": 2,
            "name": "Lifetime Budget",
            "description": null,
            "code": null
        }]
        $scope.advertItems = [{
                "id": 1,
                "name": "NONE",
                "description": null,
                "code": null
            },
            {
                "id": 2,
                "name": "APP_INSTALLS",
                "description": null,
                "code": null
            },
            {
                "id": 3,
                "name": "BRAND_AWARENESS",
                "description": null,
                "code": null
            },
            {
                "id": 4,
                "name": "CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 5,
                "name": "ENGAGED_USERS",
                "description": null,
                "code": null
            },
            {
                "id": 6,
                "name": "EXTERNAL",
                "description": null,
                "code": null
            },
            {
                "id": 7,
                "name": "EVENT_RESPONSES",
                "description": null,
                "code": null
            },
            {
                "id": 8,
                "name": "IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 9,
                "name": "LEAD_GENERATION",
                "description": null,
                "code": null
            },
            {
                "id": 10,
                "name": "LINK_CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 11,
                "name": "OFFER_CLAIMS",
                "description": null,
                "code": null
            },
            {
                "id": 12,
                "name": "OFFSITE_CONVERSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 13,
                "name": "PAGE_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 14,
                "name": "PAGE_LIKES",
                "description": null,
                "code": null
            },
            {
                "id": 15,
                "name": "POST_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 16,
                "name": "REACH",
                "description": null,
                "code": null
            },
            {
                "id": 17,
                "name": "SOCIAL_IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 18,
                "name": "VIDEO_VIEWS",
                "description": null,
                "code": null
            },
            {
                "id": 19,
                "name": "APP_DOWNLOADS",
                "description": null,
                "code": null
            }
        ];
        var modalSuccessPop = $(".success-popup"); // Get the modal Success req
		var modalReplicatorPop = $(".replicator-popup"); //Get the replicator nodal
		var modalNetworkPop = $(".network-popup"); // Get the network nodal
        $scope.successPopup = function() {
            modalSuccessPop.show();
            angular.element($('body').css("overflow-y", "hidden"))
        }
        $scope.closeSuccessPopup = function() {
            modalSuccessPop.hide();
            angular.element($('body').css("overflow-y", "scroll"))
            //	console.log('success')
            $rootScope.campaignSteps[4] = true;
            //$rootScope.step = 5;

            $rootScope.campaignGoLive = false;
            console.log($rootScope.campaignGoLive);
            $state.go('app.parentcampaign');
        }
		
		$scope.openReplicatorPopup = function() {
			 modalSuccessPop.hide();
            angular.element($('body').css("overflow-y", "scroll"));           
            $rootScope.campaignSteps[4] = true;            
            $rootScope.campaignGoLive = false;
            console.log($rootScope.campaignGoLive);
			modalReplicatorPop.show();
		}
		
		$scope.$on('details-loaded', function() {
			$scope.setLine();	
		});
		/*$scope.openConfirmPopup = function(){
			var modalSuccessPop = $(".replicator-popup");
			 modalSuccessPop.show();
		}*/
		$scope.openNetworkPopup = function(){
			angular.element('.replicator-pop-up-ok').css('opacity', 0.8);
			angular.element('.replicator-pop-up-ok').css('pointer-events', 'none');
			modalReplicatorPop.hide();
			//var modalSuccessPop = $(".network-popup");
			 modalNetworkPop.show();
		}
		
		$scope.checkReplicator = function(){
			//var heads = document.getElementsByTagName("ui-view");
			console.log($scope.netName);			
			var isNetworkReplicationApplicable = false;
			//var cNetwork = $rootScope.currentNetwork;
			var cNetwork = "Facebook";
			console.log(cNetwork);
			//$rootScope.campaignData  = JSON.parse($window.localStorage.getItem("campaignData"));			
			$rootScope.campaignData  = JSON.parse($window.localStorage.getItem("facebookReplicatorData"));			
			console.log($rootScope.campaignData);
			$window.localStorage.setItem("campaignState", "replication");
			$rootScope.targetedNetwork = $scope.netName;
			console.log($rootScope.targetedNetwork);
			$rootScope.campaignObjective = parser.getParsedObject($rootScope.campaignData, 'objective');
			//$rootScope.campaignObjective = "PAGE_LIKES";
			console.log($rootScope.campaignObjective);			
			 //parser.getSetParser(cNetwork, $rootScope.campaignObjective, $rootScope.targetedNetwork);
			var sourceNetwork = cNetwork.toLowerCase();
			var targetNetwork = $rootScope.targetedNetwork.toLowerCase();
			var replicableNetworks = Object.keys($scope.objectiveMappingCopy[0]);			
			if(replicableNetworks.indexOf(targetNetwork) > -1) {
				isNetworkReplicationApplicable	 = true;	
			}
			
			if(isNetworkReplicationApplicable == true) {
				//check objective
				angular.forEach($scope.objectiveMappingCopy, function (value, key) {
					console.log($scope.objectiveMappingCopy[key][sourceNetwork].length);
					for(var i=0;i<=$scope.objectiveMappingCopy[key][sourceNetwork].length;i++){
						if ($rootScope.campaignObjective == $scope.objectiveMappingCopy[key][sourceNetwork][i]) {
							if($scope.objectiveMappingCopy[key][targetNetwork].length >0) {
								parser.getSetParser(cNetwork, $rootScope.campaignObjective, $rootScope.targetedNetwork);
								var fbData = parser.facebookParser("", "");
								//console.log(fbData);
								var modalSuccessPop = $(".replicator-popup");
								modalSuccessPop.hide();
								var modalSuccessPop = $(".network-popup");
								modalSuccessPop.hide();
								$rootScope.campaignSteps = [false,false,false,false,false]; 
								break;
							} else {
								var modalSuccessPop = $(".network-popup");
								modalSuccessPop.hide();
								var modalerrPop = $(".objective_error_popup_replicator");
								modalerrPop.show();	
							}
						} 
					}
				});
			} else {
				var modalSuccessPop = $(".network-popup");
				modalSuccessPop.hide();
				var modalerrPop = $(".error_popup_replicator");
				modalerrPop.show();
			}	
			$scope.networkNames = "";
			
		}
		
		
		$scope.selectNetwork = function (_name) {
			angular.element('.replicator-pop-up-ok').css('opacity', 1);
			angular.element('.replicator-pop-up-ok').css('pointer-events', 'auto');
			$scope.netName = _name;
        }
		
		 $scope.menuItems = [{
                title: "All",
                img: "images/accountDashboard/all.svg",
                icon: "glyphicon glyphicon-search",
                state: false

            },
            {
                title: "Facebook",
                img: "images/accountDashboard/facebook.svg",
                icon: "\uf09a",
                state: false

            },
            {
                title: "Twitter",
                img: "images/accountDashboard/twitter.svg",
                icon: "\uf099",
                state: false

            },
            {
                title: "LinkedIn",
                img: "images/accountDashboard/linked_in.svg",
                icon: "\uf0e1",
                state: true


            },
            {
                title: "Google Adsense",
                img: "images/accountDashboard/google_adsense.svg",
                icon: "\uf1a0",
                state: true

            },
            {
                title: "Instagram",
                img: "images/accountDashboard/instagram.svg",
                icon: "\uf16d",
                state: true

            },
            {
                title: "Cognizant AdServer",
                img: "images/accountDashboard/cts-small.png",
                icon: "\uf0d5",
                state: true

            },
            {
                title: "Bing",
                img: "images/accountDashboard/bing.svg",
                icon: "\uf0e2",
                state: true

            }
        ];
		
		
    }
]);


app.directive('setConncetor',function () {
	return {
	   restrict: 'A',
	   replace:false,
	   template: '',
	   link: function ($scope) {               
			  $scope.$emit('details-loaded');
	   }
	}
}) ;