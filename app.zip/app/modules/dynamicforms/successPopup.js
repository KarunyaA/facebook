dashboard.directive('successPopup', ['facebookGetPost', '$window', '$filter', '$timeout', '$state', 'appSettings', '$q', '$animate', 'apiService', '$sce', 'globalData', function (facebookGetPost, $window, $filter, $timeout, $state, appSettings, $q, $animate, apiService, $sce, globalData) {
        return{
            restrict: 'E',
            templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/successPopup.html',
            transclude: true,
            scope: {
                data: "="
            },
            link: function (scope, element, attr) {

                scope.data = {
                    popupTitle: "",
                    popupMessage: ""
                }

                scope.showPopup = function () {
                    scope.popFlag = true;
                    //scope.$root.progressLoader = "none";
                    angular.element($('body').css("overflow-y", "scroll"))
                    scope.$emit('progressLoader', {value: "none"});
                    var successReq = $(".success_popup");
                    successReq.show();
                }



                scope.closeSuccessPopup = function () {

                    //scope.$root.progressLoader = "none";
                    scope.$emit('progressLoader', {value: "none"});
                    angular.element($('body').css("overflow-y", "scroll"));
                    var successReq = $(".success_popup");
                    $scope.networkErrorPopup = 'none';
                    successReq.hide();
                }


                scope.$on('successpopupdata', function (event, args) {
                    console.log(args);
                    scope.data.popupTitle = args.title;
                    scope.data.popupMessage = args.message;

                    scope.showPopup();

                })

            }
        }
    }]);