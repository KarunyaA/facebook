dashboard.directive('advertName',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/advertNameTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",			
        },                          							
		link:function(scope,element,attr){
		scope.fielddata = {
			advertSetName:"",
		}
		scope.campaignState = $window.localStorage.getItem("campaignState");
		
		scope.getAdvertSetName = function (_value) {
				console.log(_value);
                scope.advertSetName = _value;
                //$scope.checkMandatoryField();
				scope.$emit('advertname',{value:scope.advertSetName});
				scope.validation();
        }
			//scope.init = function () {
				if (scope.campaignState == "create") {						
					console.log(scope.advertSetName);
					
				}
				else{
					scope.$on('advertname', function (event,args) {
					console.log(args.value);
					scope.advertSetName = args.value;
					});
					
				}
				
				
				
				
			
			//}
				
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 