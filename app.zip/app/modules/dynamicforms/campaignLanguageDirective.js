dashboard.directive('languageSearch',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/languageSearch.html',	
	transclude:true,
	scope:{
		data:"="
	},
	link:function(scope,element,attr){

	scope.data = {
                  regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]					
			}

			
        //FETCH LANGUAGE DETAILS
        scope.getLanguageDetails = function () {
            if (scope.data.campaignAudienceLanguage != '' && scope.data.campaignAudienceLanguage != undefined) {
                scope.ngLanLoader = true;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                var querystr = "?type=adlocale&q=" + scope.data.campaignAudienceLanguage + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');

                facebookGetPost.demographictargetingsearch(querystr, headers).then(function (response) {

                    if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    ;
                    if (response.data.appStatus > 0 && scope.data.campaignAudienceLanguage != '') {
                        scope.errLan = 0;
                    } else if (response.data.appStatus == 0 && scope.data.campaignAudienceLanguage != '') {
                        scope.errLan = 1;
                        scope.LanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
                    }
                    scope.ngLanLoader = false;
                    scope.$root.freezeFlag = true;
                    scope.$root.overLayAudience = true;
                })

            } else {
                scope.LanguageDetails = undefined;
                scope.errLan = 1;
            }
        }

        scope.$watch('data.campaignAudienceLanguage', function () {
            if (scope.LanguageDetails != 'undefined' && scope.LanguageDetails != '' && scope.LanguageDetails != null) {
                scope.addLanguage(scope.data.campaignAudienceLanguage);
            }
        });

       // scope.campaignAudienceLanguageKeyArr = [];
        scope.addLanguage = function (val) {
            if (val != '' && val.length > 2) {
                var Rdata = scope.LanguageDetails.find(function (ele) {
                    return trim(ele.name) === trim(val);
                });
                var Edata = scope.data.campaignAudienceLanguageArr.find(function (ele) {
                    return trim(ele) === trim(val);
                });
                if (Rdata && !Edata) {
                    scope.data.campaignAudienceLanguageArr.push(val);
                    scope.data.campaignAudienceLanguageKeyArr.push(Rdata.key);
                    scope.data.campaignAudienceLanguage = '';
                } else {
                    console.log('language already exist!');
                }
            }
            ;
            $window.localStorage.setItem("campaignAudienceLanguageArr", scope.data.campaignAudienceLanguageArr);
            scope.data.LanguageKeyValues = {
                "locales": scope.data.campaignAudienceLanguageKeyArr
            }
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
           // scope.setLine();
			scope.$emit('details-loaded');
        };

        scope.removeLanguage = function (item) {

            var Rdata = scope.DefaultLanguageDetails.find(function (ele) {
                return trim(ele.name) === trim(item);
            });
            scope.data.campaignAudienceLanguageKeyArr.splice(scope.data.campaignAudienceLanguageKeyArr.indexOf(Rdata.key), 1);
            scope.data.campaignAudienceLanguageArr.splice(scope.data.campaignAudienceLanguageArr.indexOf(item), 1);

            console.log('campaignAudienceLanguageKeyArr ::: ');
            console.log(scope.data.campaignAudienceLanguageKeyArr);
            $window.localStorage.setItem("campaignAudienceLanguageArr", scope.data.campaignAudienceLanguageArr);
            scope.data.LanguageKeyValues = {
                "locales": scope.data.campaignAudienceLanguageKeyArr
            }
            console.log(scope.data.LanguageKeyValues);

            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
            //scope.setLine();
			scope.$emit('details-loaded');
        };
		
	   function isString(value) {
            return typeof value == 'string';
        };
        
        function trim(value) {
            return isString(value) ? value.replace(/^\s*/, '').replace(/\s*$/, '') : value;
        };
        
			
		scope.init = function(){
									
            //DEFAULT LANGUANGE DETAILS LOADING		
            var querystr5 ="?type=adLocale" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            facebookGetPost.demographictargetingsearch(querystr5).then(function (response) {
                scope.DefaultLanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
            });
				
		}

		scope.init();
		
		scope.$on('languageData', function (event,args) {
		 console.log(args);
			scope.data.campaignAudienceLanguage=args.value.campaignAudienceLanguage;
			scope.data.campaignAudienceLanguageArr=args.value.campaignAudienceLanguageArr;
			scope.data.campaignAudienceLanguageKeyArr=args.value.campaignAudienceLanguageKeyArr;
			scope.data.LanguageKeyValues=args.value.LanguageKeyValues;
		})
}




}
}]);