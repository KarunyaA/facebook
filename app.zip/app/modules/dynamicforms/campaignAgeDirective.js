dashboard.directive('ageContent',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/ageContent.html',	
	transclude:true,
	scope:{
		data:"="
	},
	link:function(scope,element,attr){

	scope.data = {
               regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]				
			}

	    scope.ageFromArr = function (min, max, step) {
            step = step || 1;
            var input = [];
            for (var i = min; i <= max; i += step) {
                input.push(i);
            }
            return input;
        };

		  scope.sendcampaignAudienceAgeFrom = function(campaignAudienceAgeFrom){
				if(campaignAudienceAgeFrom <= scope.data.campaignAudienceAgeTo){
					scope.data.campaignAudienceAgeFrom = campaignAudienceAgeFrom;
				}else{
					scope.data.campaignAudienceAgeTo = scope.data.campaignAudienceAgeFrom;
				}
				$window.localStorage.setItem("campaignAudienceAgeFrom", scope.data.campaignAudienceAgeFrom);
				scope.$root.freezeFlag = true;
				scope.$root.overLayAudience = true;
			}    
			scope.sendcampaignAudienceAgeTo = function(campaignAudienceAgeTo){
				if(scope.data.campaignAudienceAgeFrom <= scope.data.campaignAudienceAgeTo){
					scope.data.campaignAudienceAgeTo = campaignAudienceAgeTo;
				}else{
					scope.data.campaignAudienceAgeTo = scope.data.campaignAudienceAgeFrom;
				}
				$window.localStorage.setItem("campaignAudienceAgeTo", scope.data.campaignAudienceAgeTo);
				scope.$root.freezeFlag = true;
				scope.$root.overLayAudience = true;
			}
		
		
        scope.$watch('campaignAudienceAgeTo', function (newVal, oldVal) {
            if (newVal != 'undefined' && newVal != '' && newVal != null) {
                if (newVal < scope.data.campaignAudienceAgeFrom) {
                    scope.data.campaignAudienceAgeTo = scope.data.campaignAudienceAgeFrom;
                };
            }
        }, true);

		
		
		scope.init = function(){
				scope.data.campaignAudienceAgeFrom = '18';
				scope.data.campaignAudienceAgeTo = '65';
		}
		
		scope.init();
		
		scope.$on('ageData', function (event,args) {
			console.log(args);
			scope.data.campaignAudienceAgeFrom=args.value.campaignAudienceAgeFrom.toString();
			scope.data.campaignAudienceAgeTo=args.value.campaignAudienceAgeTo.toString();		  	
		})
}

}
}]);