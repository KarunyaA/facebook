dashboard.directive('fbCarousel',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData)
{
    return {	
		
        restrict: 'E',
		transclude:true,
		scope:true,
        templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/fbcreativecarousel-directive.html',
		link:function(scope,elements,attr){
			
			scope.fielddata = {
					fbadvertFormat:"fbsingleimage",
					campaignAudienceCampaignTarget:"",
					selectedTarget:"",
					textBodyContent:"",
					radioDestination:"",
					messengertextBodyContent:"",
					campaignWebURL:"",
					campaignHeadline1:"",
					learnMoreUrl:"",
					seeMoreUrl:"",
					displayURLoptional:"",
					deepLink:"",
					valAddWebsiteUrl:"",
					webURL:"",
					displayLink:"",
					campaignHeadline:"",
					newsfeedlinkdesc:"",
					callToDirectionValue:"",
					pixelTracking:"",
					campaignURLParameter:"",
					campaignLandingView:"",
					isCreateHideAdvOption:false,
					isCreateShowAdvOption:true	
								
				}

			  var apiTPBase = appSettings.apiTPBase;
			    var vm = this;
      
				scope.selectMedia = function (val,index) {
            scope.imageFormat = "imagemediaUpdate";            
            scope.media=true;
			scope.mediaarrow=true;
			scope.cardarrow=false;
			scope.campaignState = $window.localStorage.getItem("campaignState");
			if(scope.campaignState == 'create'){
					scope.showVideoPrev[index] = false;
					console.log(index);
				}
			//scope.setLine();
			  scope.$emit('uploadsection',{id:"setLine"});
			
        }

		
		//Carousel advent code start
		
		scope.tabs = [{
			title: '1'
		},
		{
		title: '2'
		}];

		$timeout(function () {		
			if(scope.tabs.length == 2){
			console.log(scope.tabs.length);
			angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
			angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
			}
		},1000);
		
			//Carousel card textbox model
		 
		scope.sendCardHeadline = function (val,index) {
		console.log(index);
		if(scope.fbadvertFormat == 'fbcarosel'){			
			scope.cardHeadline = val;			
			// scope.headlinecontents = [];
			 scope.headlinecontents[index] = scope.cardHeadline[index];
                         if(scope.cardHeadline[index]!=null && scope.cardHeadline[index]!="" && scope.cardHeadline[index]!=undefined)
                        {
                            angular.element("#cardHeadline"+index).removeClass("required");
                        }else
                        {
                            angular.element("#cardHeadline"+index).addClass("required");
                        } 
			 console.log(scope.headlinecontents);					
			$window.localStorage.setItem("cardHeadline", JSON.stringify(scope.headlinecontents));
		}
		     
        };
		
		scope.sendCardDescription = function (val,index) {
		
		if(scope.fbadvertFormat == 'fbcarosel'){			
			scope.cardDescription = val;			
			// scope.descriptioncontents = [];
			 scope.descriptioncontents[index] = scope.cardDescription[index];	
			console.log(scope.descriptioncontents);			 
			$window.localStorage.setItem("cardDescription", JSON.stringify(scope.descriptioncontents));
		}
		 
             
        };
		
		scope.sendcardwebURL = function (val,index) {			
		if(scope.fbadvertFormat == 'fbcarosel'){			
			scope.cardwebURL = val;			
			// scope.weburlcontents = [];
			scope.weburlcontents[index] = scope.cardwebURL[index];
                        if(scope.cardwebURL[index]!=null && scope.cardwebURL[index]!="" && scope.cardwebURL[index]!=undefined)
                        {
                            angular.element("#cardwebURL"+index).removeClass("mandatory");
                        }else
                        {
                            angular.element("#cardwebURL"+index).addClass("mandatory");
                        } 
			$window.localStorage.setItem("cardwebURL", JSON.stringify(scope.weburlcontents));
			console.log(scope.weburlcontents);	
		}
		 
             
        };
	
		  
  scope.cardSelection = function(index){	
  
	var len = scope.tabs.length + 1;
	var len1 = scope.tabs.length - 1;
    var numLbl =  len;
	
	if(index == numLbl - 2 && index !=2){	
		
		//$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","420px");
		if(index == 3){
			$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","185px");
		}
		else if(index == 4){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","230px");}
		else if(index == 5){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","265px");}
		else if(index == 6){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","312px");}
		else if(index == 7){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","355px");}
		else if(index == 8){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","392px");}
		else if(index == 9){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","436px");}
		
	}
  
		 $timeout(function () {
		//console.log($('#contentBlock'+index+' .cardContainer .mediaBlock').height());
		var imgSelector = $('#contentBlock'+index+' .cardContainer .mediaBlock').height();
		if(imgSelector > 500){
			scope.mediaarrow = false;
			scope.cardarrow = true;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		else{
			scope.mediaarrow = true;
			scope.cardarrow = false;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		},300);
		
  	}
	
	  scope.addTab = function($index) {
		var len = scope.tabs.length + 1;
		var numLbl =  len;

		if(numLbl <=10){
			scope.cardHeadline[numLbl-1] = "";
			scope.cardDescription[numLbl-1] = "";
			scope.cardwebURL[numLbl-1] = "";
		    scope.showImgPrev[numLbl-1] = false;
			scope.showVideoPrev[numLbl-1] = false;			
			scope.leftStyle = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) + 42;
			//console.log(scope.leftStyle);
			$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",scope.leftStyle);			
			 scope.tabs.push({
			  title: numLbl     			  
			});			   
			for(i=0;i<scope.tabs.length;i++){
					scope.tabs[i].title = (i+1);		
					angular.element($('.cards-content '+'#contentBlock'+i+' .removeCard').css("display", "block"));						
			}		
		}
  };
 
		
        scope.selectMedia1 = function (val,index) {
            scope.imageFormat = "videomediaUpdate";            
            scope.media=true;
            //scope.createCards();  
			scope.mediaarrow=false;
			scope.cardarrow=true;
			scope.campaignState = $window.localStorage.getItem("campaignState");			
				if(scope.campaignState == 'create'){
					scope.showImgPrev[index] = false;
					console.log(index);
				} 
			
			  scope.$emit('uploadsection',{id:"setLine"});
        }
		
		 scope.selectMedia2 = function (val) {
            scope.imageFormat = "videoviewsmediaUpdate";            
            scope.media=false;
            //scope.createCards();  
			scope.mediaarrow=false;
			scope.cardarrow=false;		
			
        }
		
		    scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }

		
		 scope.selectImagePopup = function (index) {
		 
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if (scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
				else{
					
				//scope.$root.progressLoader = 'block';
                document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
				 //	document.getElementById("seeMoreUrl").style.borderColor = "#A9A9A9";
                scope.errTextMsg = "none";
				angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
               /* angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); */
                scope.step2_green=true;
				scope.uploadimgcount = index;
				angular.element($('body').css("overflow", "hidden"));
				var createPopup = $(".selectImagePopup");// Get the modal Reject req
				scope.mainLoader = "block";
			      //scope.browseImageLibrary = "none";
			 scope.browseCarouselImage="none";
			var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId");  
			var headers = {
							"userId": $window.localStorage.getItem("userId"),
							"accessToken": $window.localStorage.getItem("accessToken")
						}			//scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            scope.uniqueArray1 = "";
           
			facebookGetPost.getadimages(queryStr, headers).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    scope.mainLoader = "none";					
                    //scope.browselibrary = "block";
					//scope.browseImageLibrary="block";
					 scope.browseCarouselImage="block";
                   createPopup.show();
                    var arrAdAccountCreativeallData = [];
					console.log(response.data.adImages.length);
                    angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    }); 
					scope.uniqueArray1 = scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
					//console.log(uniqueArray1);
					console.log(arrAdAccountCreativeallData);
                    console.log(scope.respGetAdCreativeObj);
					
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                       // scope.$root.progressLoader = "none";
                        scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            scope.errorpopupHeading = response.data.networkError.error_user_title;
                            scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            scope.errorpopupHeading = 'Error';
                            scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
			
			}
			
		 }
		 
		 
		  scope.selectVideoPopup = function (index) {
		  
		  
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if (scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
			else {	
			
			 document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";				
             scope.errTextMsg = "none";
             angular.element($('.btnCampaignCreative').prop('disabled', false));
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			 angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
			scope.uploadimgcount = index;
			angular.element($('body').css("overflow", "hidden"));
            var createPopup = $(".selectVideoPopup");// Get the modal Reject req
            
			scope.mainLoader = "block";
			
			 var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
			 angular.element($('body').css("overflow-y", "hidden"));
			 var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
			 scope.uniqueArrayVideo = "";
            
			facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
			
			 if (response.data.appStatus == '0') {// success
                             createPopup.show();
				console.log(response.data);
                 scope.mainLoader = "none";		
               // scope.browselibraryvideos = "block";
                //console.log(response.data.data);
                scope.existVideosList = response.data.data;
				
				var arrAdAccountCreativeallDataVideo = [];
                     angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
					// scope.uniqueArrayVideo = scope.removeDuplicates(arrAdAccountCreativeallDataVideo, "id");                  
					scope.uniqueArrayVideo = arrAdAccountCreativeallDataVideo;                  
                    console.log(scope.uniqueArrayVideo);
					
			}
		 else {// failed
                    console.log("failed scope.getAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        scope.$root.progressLoader = "none";
//                        scope.editAdsetErrorMsg = 'block';
                        scope.showErrorPopup(response);
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
			
            });
			
			} 
			
		 }
		 
		 
		 
		 
		 scope.selectImage = function(){
			scope.imagePreviewSrc[scope.uploadimgcount] = scope.selectedImagegallery;	
			$('#imagePreview'+scope.uploadimgcount).attr('src', scope.selectedImagegallery);	
			$('#imagePreview'+scope.uploadimgcount).attr('class', scope.selectedImagegalleryHash);	
			scope.showImgPrev[scope.uploadimgcount] = true;
			//scope.closePopup();
			angular.element($('body').css("overflow-y", "scroll"));
			
			angular.element($('#fbImagepopup').css("display","none"));		
		
			console.log($('#imagePreview'+scope.uploadimgcount).attr('src'));
		//	scope.selectedImagegalleryArray.push($('#imagePreview'+scope.uploadimgcount).attr('src'));
			scope.selectedImagegalleryArray[scope.uploadimgcount]=($('#imagePreview'+scope.uploadimgcount).attr('src'));
			console.log(scope.selectedImagegalleryArray);
			
			scope.uniqueImageSelectionArray[scope.uploadimgcount]=($('#imagePreview'+scope.uploadimgcount).attr('class'));
			console.log(scope.uniqueImageSelectionArray);
			//scope.setLine();
			  scope.$emit('uploadsection',{id:"setLine"});
			scope.browseCarouselImage="none";
		 } 
		 
		 scope.closeImagePopup = function(){
			 
			
			 scope.browseCarouselImage="none";
			 angular.element($('body').css("overflow-y", "scroll"));
		 }
		 
		 
		  scope.selectVideo = function(){
			scope.imagePreviewVideoSrc[scope.uploadimgcount] = scope.selectedImagegallery;	
			$('#imagePreviewVideo'+scope.uploadimgcount).attr('src', scope.selectedImagegallery);
			$('#imagePreviewVideo'+scope.uploadimgcount).attr('class', scope.selectedImagegalleryVideo);				
			scope.showVideoPrev[scope.uploadimgcount] = true;
			//scope.closePopup();
			angular.element($('body').css("overflow-y", "scroll"));
			angular.element($('#fbVideopopup').css("display","none"));
			//scope.previewing = true;
			//angular.element($('.cards-content .imgprv').css("visibility", "visible"));
			console.log($('#imagePreviewVideo'+scope.uploadimgcount).attr('src'));
		//	scope.selectedImagegalleryArray.push($('#imagePreviewVideo'+scope.uploadimgcount).attr('src'));
			scope.selectedImagegalleryArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('src'));
			scope.selectedImagegalleryArrayVideo[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));
			console.log(scope.selectedImagegalleryArray);			
			scope.uniqueImageSelectionArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));
			
			  scope.$emit('uploadsection',{id:"setLine"});
            vm.getData = {};
		 }
		 
		
			scope.selectedImagePush = [];
		scope.changeSelectionImage = function (image_hash) {
			
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImagesCarousel').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImagesCarousel").addClass('sel_bk_color'));
				console.log($('.sel_bk_color label img').attr('src'));
				scope.selectedImagegallery = $('.sel_bk_color label img').attr('src');
				scope.selectedImagegalleryHash = image_hash;
				console.log(scope.selectedImagegalleryHash);
				scope.selectedImagePush.push(image_hash);
            }
			// scope.selectedImagePush.push(image_hash);
        }
		 
		
		 scope.changeSelectionVideo = function (videoID1) {
			console.log(videoID1);
           
				 if (angular.element($(".galleryVideos #" + videoID1).is(':checked'))) {				 
					angular.element($('.galleryVideos').removeClass('sel_bk_color1'));
                angular.element($(".galleryVideos #" + videoID1).parent(".galleryVideos").addClass('sel_bk_color1'));	

						console.log($('.sel_bk_color1 label img').attr('src'));
				scope.selectedImagegallery = $('.sel_bk_color1 label img').attr('src');
				scope.selectedImagegalleryVideo = $('.sel_bk_color1 label img').attr('class');
				scope.selectedImagegalleryHash = videoID1;
				console.log(scope.selectedImagegalleryHash);
				scope.selectedImagePush.push(videoID1);
				
				//Code to remove duplicate hash value from array
				/* scope.uniqueImageSelectionArray = scope.selectedImagePush.filter(function( item, index, inputArray)
					{
						return inputArray.indexOf(item) == index;
					});
			
			console.log(scope.uniqueImageSelectionArray); */
				
            }

        }
		 
		  scope.deleteImg = function (index) {
			//console.log(index);
            scope.uploading = true;
            scope.previewing = false;
			console.log($('#imagePreview'+index).attr('src'));
			$('#imagePreview'+index).attr('src', '#');			
			scope.showImgPrev[index] = false;
//                        scope.selectedImagegalleryArray[index]="";
        }
		
		 scope.deleteImgVideo = function (index) {
			//console.log(index);
            scope.uploading = true;
            scope.previewing = false;
			console.log($('#imagePreviewVideo'+index).attr('src'));
			$('#imagePreviewVideo'+index).attr('src', '#');			
			scope.showVideoPrev[index] = false;
//                        scope.selectedImagegalleryArray[index]="";
        }
		 
		 //Image Upload section carousel
		 
		   scope.uploadFile = function (files) {
		   
            scope.$apply(function (scope) {
                scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {			
                $('#imagePreview'+scope.uploadimgcount).attr('src', e.target.result);				
				scope.showImgPrev[scope.uploadimgcount] = true;
                scope.dataURL = reader.result;                
                scope.splittedData = scope.dataURL.split(',')[1]; 
				scope.mainLoader = "block";
            };
            
			 $timeout(function () {                    				
			scope.mainLoader = "block";
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
			parameters.append('type','IMAGE');
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('imageFile',files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadimage";

					 if (typeof (files[0]) == "object") {                  
					facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                        console.log(response);
						scope.$root.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
							scope.mainLoader = "none";
							angular.element($('body').css("overflow-y", "scroll"));
							angular.element($('#fbImagepopup').css("display","none"));	
                            scope.hashVal = response.data.adImageDetails.images.bytes.hash;
							console.log(scope.hashVal);
                            scope.hashUrl = response.data.adImageDetails.images.bytes.url;
							console.log(scope.hashUrl);
                            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
							
                          scope.imagePreviewSrc[scope.uploadimgcount] = scope.hashUrl;	
						  $('#imagePreview'+scope.uploadimgcount).attr('src', scope.hashUrl);
						  $('#imagePreview'+scope.uploadimgcount).attr('class', scope.hashVal);						
							scope.showImgPrev[scope.uploadimgcount] = true;
							scope.selectedImagePush.push(scope.hashVal);
							scope.uniqueImageSelectionArray[scope.uploadimgcount]=($('#imagePreview'+scope.uploadimgcount).attr('class'));
							console.log(scope.uniqueImageSelectionArray);
							scope.selectedImagegalleryArray[scope.uploadimgcount]=($('#imagePreview'+scope.uploadimgcount).attr('src'));
							console.log(scope.selectedImagegalleryArray);
                        }
                        else {
                            console.log('failed scope.getCampaignfiles');
							scope.showErrorPopup(response.data);
							scope.mainLoader = "none";
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }															
                    });
					
					}
																			
                }, 1000);
			
			
			
            reader.readAsDataURL(files[0]);
          
        };
		


		scope.validateCarousel = function()
                {
					
					
                    console.log("validated");
                    console.log(scope.selectedImagegalleryArray);
                    scope.index = [];
				
					 for(var i=0;i<scope.tabs.length;i++)
                    {
                        if(scope.headlinecontents[i]=="" || scope.headlinecontents[i]==undefined || scope.headlinecontents[i]==null)
                        {
                            if(scope.index.indexOf(i)==-1)
                            {
                                scope.index.push(i);
                            }
                        }
                        if(scope.weburlcontents[i]=="" || scope.weburlcontents[i]==undefined || scope.weburlcontents[i]==null)
                        {
                            if(scope.index.indexOf(i)==-1)
                            {
                                scope.index.push(i);
                            }
                        }
                        if(scope.selectedImagegalleryArray[i]=="" || scope.selectedImagegalleryArray[i]==undefined || scope.selectedImagegalleryArray[i]==null)
                        {
                            if(scope.index.indexOf(i)==-1)
                            {
                                scope.index.push(i);
                            }
                        }
                    }
					
				
				
                    if(scope.index.length==0)
                    {
                        for(i=0;i<scope.tabs.length;i++)
                        {
                            console.log(scope.tabs[i].title-1);
                            angular.element('#mainCntr #'+(scope.tabs[i].title-1)).removeClass("mandatory_red");
                        }
                        angular.element('#step2').css('background-color', '#95D2B1');
                        console.log("if")
                        scope.createCarousel();
                    }
                    else
                    {
                        for(i=0;i<scope.tabs.length;i++)
                        {
                            for(j=0;j<scope.index.length;j++)
                            {
                                angular.element('#mainCntr #'+scope.index[j]).addClass("mandatory_red");
                                if(scope.index[j]!= (scope.tabs[i].title - 1))
                                {
                                    angular.element('#mainCntr #'+(scope.tabs[i].title-1)).removeClass("mandatory_red");
                                }
                            }
                            
                        }
                        angular.element('#step2').css('background-color', '#c2c2c2');
                    }
                };

	
		scope.createCarousel = function(){
			
			angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); 			
			if(scope.selectedImagegalleryArray.length >= 2){
			scope.mainLoader = "block";
					 var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
						if (isCreativeAdCreativeId) {
							scope.deleteAdCreative();
							$window.localStorage.removeItem("adCreativeId");
							if ($window.localStorage.removeItem("deleteAdCreativeStatus")) { //alert("dfdsf")
								scope.networkErrorPopup = 'block';
								return;
							}
						}
					console.log(scope.selectedImagegalleryArray);
					 scope.pageIdVal = scope.selectedTarget;
					 scope.objectType = "SHARE";
					 
			if(scope.marketingObjective == "REACH"){	
				console.log('other obj exclusing video and app installs');
				if (scope.callToDirectionValue != '' && scope.callToDirectionValue != undefined && scope.callToDirectionValue != 'null') {
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<scope.selectedImagegalleryArray.length; i++)  {
					
					if(scope.selectedImagegalleryArray[i].indexOf('png') != -1 || scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: scope.cardwebURL[i], image_hash: scope.uniqueImageSelectionArray[i], name: scope.cardHeadline[i], description: scope.cardDescription[i], call_to_action: {type: scope.callToDirectionValue} }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: scope.cardwebURL[i], picture: scope.selectedImagegalleryArray[i], name: scope.cardHeadline[i], caption: scope.carddisplaylink[i], description: scope.cardDescription[i], video_id: scope.selectedImagegalleryArrayVideo[i], call_to_action: {type: scope.callToDirectionValue} }
					
					);
					}					
					}					
					var link_data1 = {
								"link":  scope.seeMoreUrl,
                                "message": scope.textBodyContent,  
								"caption": scope.displayURLoptional,
                                "call_to_action": {
                                        "type": scope.callToDirectionValue //"LEARN_MORE"
                                    },
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log(scope.objectStorySpec);  
				}
					
				else{
					var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<scope.selectedImagegalleryArray.length; i++)  {
					
					if(scope.selectedImagegalleryArray[i].indexOf('png') != -1 || scope.selectedImagegalleryArray[i].indexOf('safe_image') != -1)
						{
						console.log('image selected');
					child_attachments.push(
					
					{link: scope.cardwebURL[i], image_hash: scope.uniqueImageSelectionArray[i], name: scope.cardHeadline[i], description: scope.cardDescription[i] }
					
					);
					}
					else{
						console.log('video selected');
						child_attachments.push(
					
					{link: scope.cardwebURL[i], picture: scope.selectedImagegalleryArray[i], name: scope.cardHeadline[i], description: scope.cardDescription[i], caption: scope.carddisplaylink[i], video_id: scope.selectedImagegalleryArrayVideo[i] }
					
					);
					}					
					}
					
					var link_data1 = {
								"link":  scope.seeMoreUrl,
                                "message": scope.textBodyContent,  
								"caption": scope.displayURLoptional,                                
								"multi_share_end_card": false,
								"multi_share_optimized": false
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log(scope.objectStorySpec);
				}
			}
			
				
				var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": scope.networkAdAccountId, //101870703634673,                    
                    "objectType": scope.objectType,
                    "objectStorySpec": JSON.stringify(scope.objectStorySpec),
                    "body": scope.textBodyContent,
                    "name": "optional fields"
                            
                };
				
				 if (scope.campaignURLParameter != '' && scope.campaignURLParameter != 'undefined' && scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
					
			
			facebookGetPost.createadcreative("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {
					scope.mainLoader = "none";                   
                    scope.adCreativeId = response.data.adCreativeId;                  
                    $window.localStorage.setItem("adCreativeId", scope.adCreativeId);
                    scope.browselibraryPopupHeading = "Browse Library";
                    scope.browselibrarySuccessMsg = "successfully uploaded";
                    scope.createAd();
					scope.$emit('imagefields',{id:"preview"});
                   // scope.desktopCreativePreview();
                   // scope.mobileCreativePreview();
                   // scope.rightColumnCreativePreview();                    
                    scope.browselibrary = "none";
					angular.element('#step1').css('background-color', '#95D2B1');                  
					angular.element('#step3').css('background-color', '#95D2B1');                					
					 angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));                
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    scope.step2_green = true;
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                }
                else {
                    vm.getData = {};
                    scope.mainLoader = "none";
                    scope.$root.progressLoader = "none";
                    scope.showMediaErrorPopup(response);
					angular.element($('.btnCampaignCreative').prop('disabled', true));					
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");                    
                }
            });  
					
			}
			
		}
		
	
//Carousel video file upload

scope.getCampaignVideoFilesCarousel = function (element) {
			scope.$root.progressLoader = 'block';            
            scope.$apply(function (scope) {
                scope.uploadedfilename = element.files[0];
            });
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('source',element.files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadvideo";
			
			
            if (typeof (element.files[0]) == "object") {            
				facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {
                    //console.log(response);
					scope.mainLoader = "none";
                    if (response.data.appStatus == '0') {
                        scope.newvideoID = response.data.adVideoId;
                        console.log(scope.newvideoID);
						scope.callGetadvideosCarousel(scope.newvideoID);
						angular.element($('body').css("overflow-y", "scroll"));
						angular.element($('#fbVideopopup').css("display","none"));
                       
                    } else {
                        console.log("failed scope.getCampaignVideoFiles");
						scope.showErrorPopup(response.data);
						scope.mainLoader = "none";
                    }
                });

            }
        };	
		
		
		scope.callGetadvideosCarousel = function(newvideoID){
            console.log('getvideocarousel');
            var modalErr = $(".video_error_popup_carousel");
			angular.element($('body').css("overflow-y", "scroll"));
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "?adAccountId=" + scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID;
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
				}
                scope.mainLoader = "block";
               
				facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
                                    scope.pictureFormat = adVideoID.format;
                                    scope.videoStatus = adVideoID.status;
                                    angular.forEach( scope.pictureFormat,function(ulrVal){
                                        if(ulrVal.filter == "native"){
                                            scope.imageURLValue = ulrVal.picture;
                                            scope.slideShowSource = adVideoID.source;											
											scope.imagePreviewVideoSrc[scope.uploadimgcount] = scope.imageURLValue;	
											$('#imagePreviewVideo'+scope.uploadimgcount).attr('src', scope.imageURLValue);
											$('#imagePreviewVideo'+scope.uploadimgcount).attr('class', scope.slideShowSource);
											scope.showVideoPrev[scope.uploadimgcount] = true;
											scope.selectedImagePush.push(scope.hashVal);
											scope.uniqueImageSelectionArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));
											console.log(scope.uniqueImageSelectionArray);											
											scope.selectedImagegalleryArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('src'));
											scope.selectedImagegalleryArrayVideo[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));
											console.log(scope.selectedImagegalleryArray);	
                                        }
                                    });
                                }
                            })									
                        });
                        scope.$root.progressLoader = 'none';
                        scope.checkCreatedVideoStatusCarousel(newvideoID);
                    } else {// failed
                    console.log("failed scope.getAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        scope.$root.progressLoader = "none";
                        scope.editAdsetErrorMsg = 'block';
                        scope.showErrorPopup(response);
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
                });
            
            },0);

        }
		
		
		scope.checkCreatedVideoStatusCarousel = function(newvideoID){
            scope.newvideoID = newvideoID;
            if(scope.videoStatus){
                if(scope.videoStatus.video_status == "ready"){
					console.log('video upload success');
                    console.log(scope.newvideoID+"|"+scope.imageURLValue);
					scope.imagePreviewVideoSrc[scope.uploadimgcount] = scope.imageURLValue;	
					$('#imagePreviewVideo'+scope.uploadimgcount).attr('src', scope.imageURLValue);
					$('#imagePreviewVideo'+scope.uploadimgcount).attr('class', scope.newvideoID);
					scope.showVideoPrev[scope.uploadimgcount] = true;
					scope.selectedImagePush.push(scope.hashVal);
					scope.uniqueImageSelectionArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));										
					scope.selectedImagegalleryArray[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('src'));
					scope.selectedImagegalleryArrayVideo[scope.uploadimgcount]=($('#imagePreviewVideo'+scope.uploadimgcount).attr('class'));
					console.log(scope.selectedImagegalleryArray);	
                    //scope.creativeAdCreative(scope.newvideoID+"|"+scope.slideShowSource);
                }else if(scope.videoStatus.video_status == "error"){
                    scope.popupTitle = 'Error';
                    scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                }else{
                    scope.popupTitle = 'Video Status Error';
                    scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                    //scope.callGetadvideos(newvideoID);
                }			
            }			
        }
		 


scope.removeTab = function($index) {

	if(scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
	}
	else{

    console.log("Removing tab: " + $index);
	//scope.cardHeadline[$index] = "";
	//scope.cardDescription[$index] = "";
	//scope.cardwebURL[$index] = "";	
	scope.selectedImagegalleryArray.splice($index, 1); 
        scope.imagePreviewVideoSrc.splice($index, 1);
        scope.showVideoPrev.splice($index, 1);
        scope.cardHeadline.splice($index,1);
        scope.cardwebURL.splice($index,1);
        scope.cardDescription.splice($index,1);
        scope.tabs.splice($index, 1);	
	scope.leftStyle1 = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) - 42;
	console.log(scope.leftStyle1);
	$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",scope.leftStyle1);	
	for(i=0;i<scope.tabs.length;i++){
			scope.tabs[i].title = (i+1);
	}
	if(scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock2 .removeCard').css("display", "none"));
	}
	}
     
  };
  
  
        scope.createAd = function () {
			scope.$root.progressLoader = "block";		
			scope.mainLoader = "block";
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": scope.networkAdAccountId,
                "adsetId": $window.localStorage.getItem("adsetId"),
                "creativeId": $window.localStorage.getItem("adCreativeId"),
                "name": "Demo Ad",
                "status": "PAUSED"
            };
            
			facebookGetPost.createad("", parameters).then(function (response) {
                scope.mainLoader = "none";
                if (response.data.appStatus == 0) {
                    scope.adId = response.data.adId;
                    $window.localStorage.setItem("adId", scope.adId);
                    //scope.desktopCreativePreview();
                    //scope.mobileCreativePreview();
                    //scope.rightColumnCreativePreview();
                    scope.getAd();
					angular.element($('.btnCampaignCreative').prop('disabled', false));
					//angular.element($('.accordianRole').prop('disabled', false));
					angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('pointer-events','auto');
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                                        scope.step2_green=true;
                }
                else {
                    scope.$root.freezeFlag = false;
                    scope.$root.step = 3;
                    vm.getData = {};
                    scope.$root.progressLoader = "none"
                    scope.showErrorPopup(response.data);
					angular.element($('.btnCampaignCreative').prop('disabled', true));
					//angular.element($('.accordianRole').prop('disabled', true));
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                    angular.element('#step2').css('background-color', '#c2c2c2');
                    angular.element('#step3').css('background-color', '#c2c2c2');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
                }
            });
        }
	 
	 scope.getAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getad(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.$root.progressLoader = "block";
                    scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify(scope.adData));
                    globalData.setLocal("adId", $window.localStorage.getItem("adId"), scope.adData);
                    scope.saveAd(scope.adData);
                    scope.formatSelected = scope.fbadvertFormat;
					scope.fielddata.fbadvertFormat = scope.fbadvertFormat;				
				 $window.localStorage.setItem("fbadvertFormat",scope.fbadvertFormat);
				    $window.localStorage.setItem("formatSelected", scope.formatSelected);
                    console.log("success scope.getAd");
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
	 scope.saveAd = function (adData) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": adData
            };

            facebookGetPost.saveaddatapost("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    scope.$root.progressLoader = "block";
                    scope.showSuccessPopup(response.data.successMessage);
                    // scope.getAdCreative();
                    scope.getAdSetAdCreative();
                    scope.networkErrorPopup = "none";
                    scope.popupTitleError = "";
                    scope.popupTitleError = "";
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
		   scope.getAdSetAdCreative = function () {

            var queryStr = "?adSetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getadsetadcreative(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.$root.progressLoader = "none";
                    scope.mainLoader = "none";
                    scope.adCreativeDatailsResponse = response.data.fbAdSetCreativeResponse.data[0];
                    scope.saveAdAccountAdCreative(scope.adCreativeDatailsResponse)
                    globalData.setLocal("adCreativeId", $window.localStorage.getItem("adCreativeId"), scope.adCreativeDatailsResponse);
                    //scope.fbadvertFormat = "fbslideshow";
                    if (scope.fbadvertFormat == "fbsingleimage") {
                        scope.thumbnail = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailVideo = "images/campaign/single-video.png";
                        scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
						scope.imgthumbnaildiv=true;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbsingleimage",thumbnail:scope.adCreativeDatailsResponse.thumbnail_url, thumbnailVideo:"images/campaign/single-video.png",
						thumbnailSlideshow:"images/campaign/slide-show.png",thumbnailCarousel:"images/campaign/carousel.svg",imgthumbnaildiv:true});
                    } else if (scope.fbadvertFormat == "fbsinglevideo") {
						scope.thumbnail = "images/campaign/single-image.png";
                        scope.thumbnailVideo = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
                        scope.thumbnailSlideshow = "images/campaign/slide-show.png";
						scope.vidthumbnaildiv=true;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbsinglevideo",thumbnail:"images/campaign/single-image.png", thumbnailVideo:scope.adCreativeDatailsResponse.thumbnail_url,
						thumbnailSlideshow:"images/campaign/slide-show.png",thumbnailCarousel:"images/campaign/carousel.svg",vidthumbnaildiv:true});
						
                    } else if (scope.fbadvertFormat == "fbslideshow") {   
						scope.thumbnail = "images/campaign/single-image.png";
                        scope.thumbnailVideo = "images/campaign/single-video.png";
                        scope.thumbnailSlideshow = scope.adCreativeDatailsResponse.thumbnail_url;
                        scope.thumbnailCarousel = "images/campaign/carousel.svg";
						scope.slideShowCreate=false;
						scope.slideShowSuccess=true;
						scope.slideShowPreview=scope.adCreativeDatailsResponse.thumbnail_url;
						scope.$emit('imagefields',{id:"thumbnail",fbadvertFormat:"fbslideshow",thumbnail:"images/campaign/single-image.png", thumbnailVideo:"images/campaign/single-video.png",
						thumbnailSlideshow:scope.adCreativeDatailsResponse.thumbnail_url,thumbnailCarousel:"images/campaign/carousel.svg",slideShowCreate:false,slideShowSuccess:true,slideShowPreview:scope.adCreativeDatailsResponse.thumbnail_url});						
                    }
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });

        }
		
	   scope.saveAdAccountAdCreative = function (respGetAdCreativeObj) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetID": $window.localStorage.getItem("adsetId"),
                "adCreativeID": $window.localStorage.getItem("adCreativeId"),
                "adCreativeDetails": respGetAdCreativeObj,
            };

            facebookGetPost.saveadsetadcreative("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    scope.$root.campaignSteps[3] = true;
                    scope.$root.progressLoader = "none";
                    scope.mainLoader = "none";
                    angular.element('#step3').css('background-color', '#95D2B1');
					scope.$emit('uploadsection',{id:"setLine"});
					
			    angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
			
                    //scope.$root.step = 4;
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
	 
	 
	  scope.deleteAdCreative = function (imageHashVal) {
            scope.$root.progressLoader = 'block';
            var isCreateAd = $window.localStorage.getItem("adId");
            var isAdDetails = $window.localStorage.getItem("adData");

            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.deleteadcreative(queryStr, headers).then(function (response) {
                //alert(response.data.appStatus)
                if (response.data.appStatus == '0') {// success
                    //scope.creativeAdCreative(hashVal);
                    scope.networkErrorPopup = 'none';
                    scope.popupTitleError = '';
                    scope.popupMessageError = '';
                    $window.localStorage.setItem("deleteAdCreativeStatus", "true");
                    // scope.deleteSuccessFlag = true;
                    if (isCreateAd) {
                        scope.deleteAd();
                    }
                    scope.proceedToCreateAdCreative(imageHashVal);

                } else {// failed
                    scope.$root.progressLoader = "none";
//                      scope.deleteSuccessFlag = false;
                    if (response.data.appStatus > 0 && (response.data.errorId == 10006)) {
                        $window.localStorage.setItem("deleteAdCreativeStatus", "true");
//                        scope.deleteSuccessFlag = true;
                        if (isCreateAd) {
                            scope.deleteAd();
                        }
                        scope.proceedToCreateAdCreative(imageHashVal);
                    } else if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                    $window.localStorage.setItem("deleteAdCreativeStatus", "false");

                }

            });
        }

		
		 scope.deleteAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.deletead(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log("success delete ad");
                    scope.networkErrorPopup = 'none';
                    scope.popupTitleError = "";
                    scope.popupMessageError = '';
//                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
//                    if (isCreativeAdCreativeId) {
//                        scope.deleteAdCreative();
//                    }
                    scope.getAdForDelete();
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }
		
	 scope.getAdForDelete = function () {
            console.log('get ad');
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.getad(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify(scope.adData));

                    console.log(scope.adData);
                    scope.saveAdforDelete(scope.adData);
                    //scope.saveAd(scope.adData);
                    console.log("success scope.getAd");
                } else {// failed
                    console.log("failed getad");
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.$root.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            scope.showErrorPopup(response);
                        }
                    }
                }
            });
        }
		
	  scope.saveAdforDelete = function () {

            //console.log(scope.adData)
            scope.adDataFromLocal = JSON.parse($window.localStorage.getItem("adData"));

            scope.adDataTemp = {
                "status": "DELETED"
            };

            var camR = {};
            for (var key in scope.adDataFromLocal) {
                camR[key] = scope.adDataFromLocal[key];
            }
            for (var key in scope.adDataTemp) {
                camR[key] = scope.adDataTemp[key];
            }
            scope.adDataFromLocal = camR;
            console.log(scope.adData);

            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": scope.adDataFromLocal
            };

            facebookGetPost.saveaddata("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    scope.$root.progressLoader = "none";
                } else {
                    scope.$root.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        scope.showErrorPopup(response);
                    }
                }
            });
        }

        scope.showErrorPopup = function (response) {
            if (response.hasOwnProperty("data"))
            {
                if (response.data.networkError)
                {
                    if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined)
                    {
                        scope.popupTitle = response.data.networkError.error_user_title;
                        scope.popupMessage = response.data.networkError.error_user_msg;
                    } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined)
                    {

                        scope.popupTitle = "Error";
                        scope.popupMessage = response.data.networkError.message;
                    }
                } else {
                    scope.popupTitle = "Error";
                    scope.popupMessage = response.data.errorMessage;
                }
            } else {
                if (response.networkError) {
                    if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                        scope.popupTitle = response.networkError.error_user_title;
                        scope.popupMessage = response.networkError.error_user_msg;
                    } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                        scope.popupTitle = "Error";
                        scope.popupMessage = response.networkError.message;
                    }
                } else {
                    scope.popupTitle = "Error";
                    scope.popupMessage = response.errorMessage;
                }

            }
            var modalApproveReq = $(".error_popup"); // Get the modal Approve req
            modalApproveReq.show();
        };

		scope.removeThumbnail = function(){
					scope.carouseladvent1 = true;
					scope.carouseladventEdit2 = false;
					scope.carouseladventEdit3 = false;
					scope.carouseladventEdit4 = false;
					scope.carouseladventEdit5 = false;
					scope.carouseladventEdit6 = false;
					scope.carouseladventEdit7 = false;
					scope.carouseladventEdit8 = false;
					scope.carouseladventEdit9 = false;
                    for(var i=0; i<10;i++){
                    //scope.removeTab(i);
                    scope.cardHeadline[i] = "";
                    scope.cardDescription[i] = "";
                    scope.cardwebURL[i] = "";
                    scope.getwebURL[i] = "";
                    scope.showImgPrev[i] = false;
                    scope.showVideoPrev[i] = false;
                    angular.element('.carouseladventEdit2 ').css('left' , '140px');
                    if(i >= 2){
                    //scope.tabs.splice(i, 1);
                    scope.tabs = [{
                            title: '1'
                        },
                        {
                            title: '2'
                        }];
                    }                                     
                }			
		}
		
		scope.getCarouselEdit = function(args){
			 scope.adCreativeDetails = args.value ;
			$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","435px");
						scope.fbadvertFormat = "fbcarosel";
                        scope.$root.progressLoader = "none";
						console.log('fbcarousel adven');
					    scope.carouseladvent = true;
						scope.cardHeadline = [];
						scope.cardwebURL = [];
						scope.cardDescription = [];
						scope.carddisplaylink = [];
						scope.headlinecontents = [];
						scope.weburlcontents = [];
						scope.descriptioncontents = [];
						scope.selectedImagegalleryArray = [];
						scope.imagePreviewSrc = [];
						scope.imagePreviewVideoSrc = [];
						scope.child_attachments = scope.adCreativeDetails.object_story_spec.link_data.child_attachments;
						scope.child_attachmentslength = scope.adCreativeDetails.object_story_spec.link_data.child_attachments.length;
						console.log(scope.child_attachmentslength);	

						if(scope.child_attachmentslength > 2){
							for(var i = 3;i <= scope.child_attachmentslength; i++){
							var len = scope.tabs.length + 1;
							console.log(len);
							var numLbl =  len;
							scope.tabs.push({
							  title: numLbl
							});									
							}							
							if(scope.child_attachmentslength == 3){scope.carouseladventEdit3 = true;}
							else if(scope.child_attachmentslength == 4){scope.carouseladventEdit4 = true;}
							else if(scope.child_attachmentslength == 5){scope.carouseladventEdit5 = true;}
							else if(scope.child_attachmentslength == 6){scope.carouseladventEdit6 = true;}
							else if(scope.child_attachmentslength == 7){scope.carouseladventEdit7 = true;}
							else if(scope.child_attachmentslength == 8){scope.carouseladventEdit8 = true;}
							else if(scope.child_attachmentslength == 9){scope.carouseladventEdit9 = true;}
							
						}
						else{
							scope.carouseladventEdit2 = true;
						}
					
						for(var i = 0;i<scope.child_attachmentslength; i++){
							if (scope.child_attachments[i].name != undefined) {
							console.log(scope.child_attachments[i].link);
							scope.cardHeadline[i] =  scope.child_attachments[i].name;
							scope.headlinecontents[i] = scope.cardHeadline[i];
							scope.cardwebURL[i] =  scope.child_attachments[i].link;
							scope.weburlcontents[i] = scope.cardwebURL[i];
							scope.cardDescription[i] =  scope.child_attachments[i].description;
							scope.descriptioncontents[i] = scope.cardDescription[i];
                            scope.carddisplaylink[i] = scope.child_attachments[i].caption;
							}
						}	
							
							for(var i = 0;i<scope.child_attachmentslength; i++){
								(function(i)
								{
										if(typeof(scope.child_attachments[i].picture) == "undefined"){
											//scope.mainLoader = "block";
											console.log(i);
											
										//Get add image service using Hash value
										
												var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + scope.child_attachments[i].image_hash;
												
												var headers1 = {
																"userId": $window.localStorage.getItem("userId"),
																"accessToken": $window.localStorage.getItem("accessToken")
															   }
												
												facebookGetPost.getadimages(queryStr1, headers1).then(function (response) {
													console.log(response);
													if (response.status == "200" && response.data.appStatus == '0') {
													console.log(i);
													scope.mainLoader = "none";
													console.log('image hash servic success');
													var JsonObj = response.data.adImages[0];
													 var array = [];
													for (var j in JsonObj) {
														if (JsonObj.hasOwnProperty(j)) {
															array[+j] = JsonObj[j];
															console.log(JsonObj[j].url);
															scope.imagePreviewSrc[i] = JsonObj[j].url;
															console.log(i);														
															scope.selectedImagegalleryArray[i] = scope.imagePreviewSrc[i];
															console.log(scope.selectedImagegalleryArray[i]);
															scope.uniqueImageSelectionArray[i] = JsonObj[j].hash;
															console.log(scope.uniqueImageSelectionArray);
															scope.showImgPrev[i] = true;														
															//scope.adCreativeDetails(array[+i]);
														}
													}
														
													}else{
															if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
																$window.localStorage.setItem("TokenExpired",true);
																$state.go('login');
															}else{
																$rootScope.progressLoader = "none";
																scope.editAdsetErrorMsg = 'block';
																if(response.networkError!='' && response.networkError!=undefined){
																	scope.errorpopupHeading = response.networkError.error_user_title;
																	scope.errorMsg = response.networkError.error_user_msg;

																	scope.errorpopupHeading = 'Error';
																	scope.errorMsg = response.networkError.message;
																}else{
																	scope.errorpopupHeading = 'Error';
																	scope.errorMsg = response.errorMessage;
																}
															}
														}
													});
												
										}
										else{
											console.log(i);
											console.log(scope.child_attachments[i].picture);
											console.log($('#imagePreviewVideo'+i).attr('id'));
											scope.imagePreviewVideoSrc[i] = scope.child_attachments[i].picture;
											scope.selectedImagegalleryArray[i] = scope.imagePreviewVideoSrc[i];
											//scope.selectedImagegalleryArray[i] = scope.child_attachments[i].video_id;
											console.log(scope.imagePreviewSrc[i]);
											scope.showVideoPrev[i] = true;
											
										}
								})(i);
									
							}
							  scope.$emit('uploadsection',{id:"setLine"});
							
		}
		
		scope.$on('carouselchanges',function(events,args){
			if(args.id == "removeThumbnail"){
				scope.removeThumbnail();
			}if(args.id == "carouselEdit"){
			      console.log("In directive -- Received data");
				scope.getCarouselEdit(args);
			}
			  
		})
		
		
	//Carousel advent code end
		}

    };
  }
]);  
