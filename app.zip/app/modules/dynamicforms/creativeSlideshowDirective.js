dashboard.directive('creativeSlideshow',['facebookGetPost','$window','$filter',function(facebookGetPost,$window,$filter){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/creativeTemplate.html',
	transclude:true,
	scope:{		
		fielddata:"="
		
      },
		link:function(scope,element,attr){
		scope.marketingObjective="";
		//scope.connectFBVal=[];
		scope.fielddata = {
			campaignAudienceCampaignTarget:"",
			selectedTarget:"",
			textBodyContent:"",
			radioDestination:"",
			messengertextBodyContent:"",
			campaignWebURL:"",
			campaignHeadline1:"",
			learnMoreUrl:"",
			seeMoreUrl:"",
			displayURLoptional:"",
			deepLink:"",
			valAddWebsiteUrl:"",
			webURL:"",
			displayLink:"",
			campaignHeadline:"",
			newsfeedlinkdesc:"",
			callToDirectionValue:"",
			pixelTracking:"",
			campaignURLParameter:"",
			campaignLandingView:"",			
		}
		

		scope.getPromotablePage = function () {
				var headers = {
					"userId": $window.localStorage.getItem("userId"),
					"accessToken": $window.localStorage.getItem("accessToken")
				}
				var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');

				facebookGetPost.fetchuserpromotablepages(queryStr, headers).then(function (response) {
					console.log(response);
					console.log("facebook page");
				/* 	 response.data.fbUserPromotablePagesResponse = [{
								id:"726949550817444",
								name:"Digital Books"			
							},{
								id:"222",
								name:"Sample Page"
							}]; */ 
					scope.campaignAudienceCampaignTargetLoader = false;               
					scope.connectFBVal=response.data.fbUserPromotablePagesResponse;
				})
			};

		scope.init = function(){
			 scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
			 scope.getPromotablePage();
				if (scope.selectedTarget == "undefined") {
					scope.selectedTarget = "";
				}	
			scope.marketingObjective = $window.localStorage.getItem("marketingObjective");				
			scope.selectAdvertFormat(scope.marketingObjective);
			scope.$emit('uploadsection',{id:"setLine"});
		};
		
			scope.selectAdvertFormat = function(args){
			    if (args == "POST_ENGAGEMENT") { //Boost your post
                        scope.advertPreviewHeading = "Page and Text";
                        scope.isConnectFBPage = true;
                        scope.isText = true;
                        scope.useExistingPostLink = true;                      
                    }else if(args == "REACH"){
						 //Reach People near your business
                        scope.advertPreviewHeading = "Page and Text";
						scope.isConnectFBPage = true;
						scope.isText = true;
						scope.useExistingPostLink = true; 
						scope.isAddWebsiteUrl = true;
						scope.isCreateShowandHideOptionWrap1 = true;
						scope.fielddata.isCreateShowAdvOption=true;
							if(scope.fielddata.valAddWebsiteUrl){
								scope.isWebsiteurl = true;
								scope.isDisplayLink = true;
								scope.isHeadline1 = true;
								scope.isNewsFeedLinkDesc =true;
								scope.isCallToAction =true;
								scope.fielddata.callToDirection = scope.reachPeopleVideoAndSlideShow;
                                scope.fielddata.callToDirectionValue = "LEARN_MORE"; 
						}else{
							scope.isWebsiteurl = false;
								scope.isDisplayLink = false;
								scope.isHeadline1 = false;
								scope.isNewsFeedLinkDesc =false;
								scope.isCallToAction =false;
								scope.fielddata.callToDirection = scope.reachPeopleVideoAndSlideShow;
                                scope.fielddata.callToDirectionValue = "LEARN_MORE"; 
						}
					}
			}
		    
		scope.init();
				
		scope.selectPromotable = function(selectedTarget){
			scope.$emit('imagefields',{id:"selectpromotable",target:selectedTarget});
		}	
		
		scope.sendBodyContent=function(textBodyContent){
			scope.$emit('imagefields',{id:"sendbodycontent",value:textBodyContent});
		}
		
		
			scope.getwebURL = function(getwebURL){
					scope.$emit('imagefields',{id:"getwebURL",value:getwebURL});
				}
				scope.getDisplayLink = function(getDisplayLink){
					scope.$emit('imagefields',{id:"getDisplayLink",value:getDisplayLink});
				}
				scope.sendHeadline = function(sendHeadline){
					scope.$emit('imagefields',{id:"sendHeadline",value:sendHeadline});
				}
				scope.sendnewsfeedlinkdesc = function(sendnewsfeedlinkdesc){
					scope.$emit('imagefields',{id:"sendnewsfeedlinkdesc",value:sendnewsfeedlinkdesc});
				}
				scope.selectCallToAction = function(selectCallToAction){
					scope.$emit('imagefields',{id:"selectCallToAction",value:selectCallToAction});
				}
				scope.selectcampaignURLParameter = function(selectcampaignURLParameter){
					scope.$emit('imagefields',{id:"selectcampaignURLParameter",value:selectcampaignURLParameter});
				}
				
				
			scope.checkAddWebsiteUrl = function (isThumbnail) {
            $window.localStorage.setItem("valAddWebsiteUrl", isThumbnail);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
			var obj = $window.localStorage.getItem("marketingObjective");
			var fbadvertFormat = $window.localStorage.getItem("fbadvertFormat");
            if(scope.fielddata.valAddWebsiteUrl) {
                switch (obj) {                   
                    case "REACH":
                        if(fbadvertFormat != "fbcarosel")
                        {
                            if(fbadvertFormat == "fbsinglevideo" ||fbadvertFormat == "fbslideshow")
                            {                           
								scope.isWebsiteurl = true;
								scope.isDisplayLink = true;
								scope.isHeadline1 = true;
								scope.isNewsFeedLinkDesc =true;
								scope.isCallToAction =true;
								scope.fielddata.callToDirection = scope.reachPeopleVideoAndSlideShow;
                                scope.fielddata.callToDirectionValue = "LEARN_MORE";  
                            }
                            else if(fbadvertFormat == "fbsingleimage")
                            {                             
								scope.isWebsiteurl = true;
                                scope.isDisplayLinkOptional = true;
								scope.isHeadline1 = true;
								scope.isNewsFeedLinkDesc = true;
								scope.isCallToActionOptional = true;
								scope.fielddata.callToDirection = scope.reachPeopleImageAndCarousel;
                                scope.fielddata.callToDirectionValue = "LEARN_MORE";                               
                            }							
                        }
                        else
                        {
                            scope.isHeadline1 = false;
                            scope.isDisplayLink = false;
                            scope.isDisplayLinkOptional = false;
                        }
                        break;
                  }
            }
            else {
                switch (obj) {                  
                    case "REACH":
                        if(fbadvertFormat != "fbcarosel")
                        {
                            if(fbadvertFormat == "fbsinglevideo" || fbadvertFormat == "fbslideshow")
                            {
                                scope.isDisplayLink = false;
                                scope.isDisplayLinkOptional = false;
                            }
                            else if(fbadvertFormat == "fbsingleimage")
                            {
                                scope.isDisplayLinkOptional = false;
                            }
                            scope.isWebsiteurl = false;
                            scope.isHeadline1 = false;
                            scope.isCallToActionOptional = false;
                            scope.isNewsFeedLinkDesc = false;
                            scope.isCallToAction1 = false;
                            scope.isCallToAction = false;
                        }
                        break;
                 }
            }
            if(isThumbnail != false){
					scope.$emit('imagefields',{id:"removeThumbnail"});
					scope.$emit('imagefields',{id:"checkMandatoryVal"});
					// scope.removeThumbnail();
					// scope.checkMandatoryVal();
			}   
        };
		
		
		scope.createShowAdvancedOption = function () {
            scope.fielddata.isCreateHideAdvOption = true;
            scope.fielddata.isCreateShowAdvOption = false;        
            scope.isUrlParam = true;                                              
			scope.$emit('imagefields',{id:"removeThumbnail"});
			scope.$emit('imagefields',{id:"checkMandatoryVal"});
        };
		
		scope.createHideAdvancedOption = function () {
				scope.fielddata.isCreateHideAdvOption = false;
				scope.fielddata.isCreateShowAdvOption = true;      
				scope.isUrlParam = false;
				scope.$emit('imagefields',{id:"removeThumbnail"});
			    scope.$emit('imagefields',{id:"checkMandatoryVal"});
		};
		
		   scope.reachPeopleVideoAndSlideShow = [
            {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "CALL_NOW",
                "name": "Call Now - Phone"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "Get Directions - Street address"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }, {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }
        ];

			 scope.$on('creativeslideshow', function (event,args) {
				if(args.id == "objective"){
					scope.marketingObjective = args.objective;
					scope.selectAdvertFormat(scope.marketingObjective);
				}			 
				
		       })
		
	}

}



}]);