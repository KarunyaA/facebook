dashboard.directive('progressPopup', ['facebookGetPost', '$window', '$filter', '$timeout', '$state', 'appSettings', '$q', '$animate', 'apiService', '$sce', 'globalData', function (facebookGetPost, $window, $filter, $timeout, $state, appSettings, $q, $animate, apiService, $sce, globalData) {
        return{
            restrict: 'E',
            templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/progressLoader.html',
            transclude: true,
            scope: {
                data: "="
            },
            link: function (scope, element, attr) {

                scope.data = {
                    progressLoader: ""
                }


                scope.$on('progressloaderdata', function (event, args) {
                    console.log(args);
                    scope.data.progressLoader = args.value;

                    //scope.showPopup();

                })

            }
        }
    }]);