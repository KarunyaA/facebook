dashboard.directive('creativeCarousel',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/creativeTemplate.html',
	transclude:true,
	scope:{		
		fielddata:'='
		
	},
	link:function(scope,element,attr){
		scope.marketingObjective="";		
		scope.fielddata = {
			campaignAudienceCampaignTarget:"",
			selectedTarget:"",
			textBodyContent:"",
			radioDestination:"",
			messengertextBodyContent:"",
			campaignWebURL:"",
			campaignHeadline1:"",
			learnMoreUrl:"",
			seeMoreUrl:"",
			displayURLoptional:"",
			deepLink:"",
			valAddWebsiteUrl:"",
			webURL:"",
			displayLink:"",
			campaignHeadline:"",
			newsfeedlinkdesc:"",
			callToDirectionValue:"",
			pixelTracking:"",
			campaignURLParameter:"",
			campaignLandingView:"",
			isCards:"",
			isCreateHideAdvOption:false,
			isCreateShowAdvOption:true,
			callToDirection:[]			
		}

	scope.getPromotablePage = function () {
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');

            facebookGetPost.fetchuserpromotablepages(queryStr, headers).then(function (response) {
                console.log(response);
				console.log("facebook page");
                scope.campaignAudienceCampaignTargetLoader = false;
				/*  response.data.fbUserPromotablePagesResponse = [{
								id:"726949550817444",
								name:"Digital Books"			
							},{
								id:"222",
								name:"Sample Page"
							}]   */
                scope.connectFBVal=response.data.fbUserPromotablePagesResponse;
            })
        };
		
		
		scope.init = function(){
			 scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");			 
			 scope.getPromotablePage();
				if (scope.selectedTarget == "undefined") {
					scope.selectedTarget = "";
				}	
		   // scope.fielddata.selectedTarget = 726949550817444;
			scope.marketingObjective = $window.localStorage.getItem("marketingObjective");				
			scope.selectAdvertFormat(scope.marketingObjective);
		};
		
			scope.selectAdvertFormat = function(args){
			    if (args == "REACH") {
					scope.isConnectFBPage = true;
					scope.isText=true;
					scope.isSeeMoreURL=true;
					scope.isMoreDisplayURLOptional =true;
					scope.isCallToActionOptional = true;
					scope.isCreateShowandHideOptionWrap1 =true;
					scope.fielddata.isCreateShowAdvOption=true;
					scope.fielddata.isCreateHideAdvOption =false;
					scope.fielddata.callToDirection =scope.reachPeopleImageAndCarousel;
					scope.fielddata.callToDirectionValue = "NO_BUTTON";				                                
                    scope.isNewsFeedLinkDesc = false;
                    scope.isEvent = false;				   
				    scope.isUrlParam=false;	
					scope.isCards=true;		
					
					
                    if (scope.marketingObjective == "REACH") { //Reach People near your business
                        if(scope.fielddata.textBodyContent == "" || scope.fielddata.textBodyContent == null || scope.fielddata.textBodyContent == undefined || scope.fielddata.seeMoreUrl == "" || scope.fielddata.seeMoreUrl == null || scope.fielddata.seeMoreUrl == undefined){
                            $timeout( function(){
                                angular.element('.sectionBrowseCarosel').css('pointer-events' , 'none');
                            }, 1000 );
                            
                        }else{
                            angular.element('.sectionBrowseCarosel').css('pointer-events' , 'auto');
                        }

                        scope.advertPreviewHeading = "Page and Text";
					
                    }
			    }
		    }
		    
		
				
				
		scope.createShowAdvancedOption = function () {
            scope.fielddata.isCreateHideAdvOption = true;
            scope.fielddata.isCreateShowAdvOption = false;        
            scope.isUrlParam = true;                                              
			scope.$emit('imagefields',{id:"removeThumbnail"});
			scope.$emit('imagefields',{id:"checkMandatoryVal"});
        };
				
		 scope.createHideAdvancedOption = function () {
				scope.fielddata.isCreateHideAdvOption = false;
				scope.fielddata.isCreateShowAdvOption = true;      
				scope.isUrlParam = false;
				scope.$emit('imagefields',{id:"removeThumbnail"});
			    scope.$emit('imagefields',{id:"checkMandatoryVal"});
			};
				
				scope.selectPromotable = function(selectedTarget){
					
					scope.$emit('imagefields',{id:"selectpromotable",target:selectedTarget});
				}	
				
				scope.sendBodyContent=function(textBodyContent){
					scope.$emit('imagefields',{id:"sendbodycontent",value:textBodyContent});
				}
				
				scope.getMoreURL = function(seeMoreUrl){
					scope.$emit('imagefields',{id:"getMoreURL",value:seeMoreUrl});
				}
				scope.getDisplayURLoptional = function(displayURLoptional){
					scope.$emit('imagefields',{id:"getDisplayURLoptional",value:displayURLoptional});
				}
				scope.selectCallToAction = function(callToDirectionValue){
					scope.$emit('imagefields',{id:"selectCallToAction",value:callToDirectionValue});
				}
				scope.selectcampaignURLParameter = function(campaignURLParameter){
					scope.$emit('imagefields',{id:"selectcampaignURLParameter",value:campaignURLParameter});
				}
				       
        scope.reachPeopleImageAndCarousel = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "CALL_NOW",
                "name": "Call Now - Phone"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "Get Directions - Street address"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }, {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SAVE",
                "name": "Save"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }
        ];
        
     
			  scope.init();	
			 scope.$on('creativecarousel', function (event,args) {
				if(args.id == "objective"){
					scope.marketingObjective = args.objective;
					scope.selectAdvertFormat(scope.marketingObjective);
				}			 
				
		       })
		
	}
	
	
}
}]);

