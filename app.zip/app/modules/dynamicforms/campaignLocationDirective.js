dashboard.directive('locationSearch',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/locationSearch.html',	
	transclude:true,
	scope:{
		data:"="
	},
	link:function(scope,element,attr){

		scope.data = {
			      regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]					
			}
			
	    var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        scope.$root.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
	
	    scope.everyoneArr = [];
        scope.LocationTargetArr = [
            {Key: "everyone", Value: "Everyone in this location"},
            {Key: "home", Value: "People who live in this location"},
            {Key: "recent", Value: "People recently in this location"},
            {Key: "travel_in", Value: "People travelling in this location"}
        ];

	     scope.locationStatusArr = [
            {Key: "Include", Value: "Include"}
        ];

             scope.sendcampaignAudienceLocationTarget = function (campaignAudienceLocationTarget) {
				scope.data.campaignAudienceLocationTarget = campaignAudienceLocationTarget;
				$window.localStorage.setItem("campaignAudienceLocationTarget", scope.data.campaignAudienceLocationTarget);
				scope.$root.freezeFlag = true;
				scope.$root.overLayAudience = true;
            }
			 scope.sendcampaignAudienceLocationType = function (campaignAudienceLocationType) {
               scope.data.campaignAudienceLocationType = campaignAudienceLocationType;
               $window.localStorage.setItem("campaignAudienceLocationType", scope.data.campaignAudienceLocationType);
               scope.$root.freezeFlag = true;
               scope.$root.overLayAudience = true;
            }
						
		//FETCH LOCATION DETAILS
        scope.getLocationDetails = function () {

            if (scope.campaignAudienceLocations != "" && scope.campaignAudienceLocations != undefined)
            {
                scope.ngLocLoader = true;
                //GET LOCATION SEARCH RESULT BY LETTER
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                //var querystr = "search?type=adgeolocation&q=" + scope.campaignAudienceLocations + "&access_token=" + $rootScope.networkAccessToken;
                var querystr = "?type=adgeolocation&q=" + scope.campaignAudienceLocations + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.targetingsearchadlocale(querystr, headers).then(function (response) {
                    if (JSON.stringify(response.data.fbTargetingSearchAdLocaleResponse.data) == "[]") {
                        scope.errLoc = 0;
                    } else {
                        scope.errLoc = 1;
                        scope.LocationDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                        scope.data.mapLocation = true;
                    }
                    scope.ngLocLoader = false;
                    //scope.setLine();
					scope.$emit('details-loaded');

                })

            } else {
                scope.errLoc = 1;
            }
        };
		
        scope.$watch('campaignAudienceLocations', function () {
            if (scope.LocationDetails != 'undefined' && scope.LocationDetails != '' && scope.LocationDetails != null) {
                scope.addGeoLocation(scope.campaignAudienceLocations);
            }
            ;
        });

		
     
        scope.addGeoLocation = function (val) {
            if (val != '' && val.length > 2) {
                var SVal = val.split("/")[0];
                var Rdata = scope.LocationDetails.find(function (ele) {
                    return trim(ele.name) === trim(SVal);
                });
                var Edata = scope.data.campaignAudienceLocationsArr.find(function (ele) {
                    if (trim(ele.split("/")[0]) == trim(SVal)) {
                        return true;
                    } else {
                        return false;
                    }
                });
                if (Rdata && !Edata) {
                    scope.data.campaignAudienceLocationsArr.push(val);
                    if (Rdata.type == 'country') {
                        scope.data.countryArray.push(Rdata.country_code);
                    } else if (Rdata.type == 'region') {
                        var r_obj = {"key": Rdata.key};
                        scope.data.regionArray.push(r_obj);
                    } else if (Rdata.type == 'city') {
                        var c_obj = {"key": Rdata.key};
                        scope.data.cityArray.push(c_obj);
                    }
                    scope.campaignAudienceLocations = '';
                    $window.localStorage.setItem("regionArray", JSON.stringify(scope.data.regionArray));
                    $window.localStorage.setItem("countryArray", JSON.stringify(scope.data.countryArray));
                    $window.localStorage.setItem("cityArray", JSON.stringify(scope.data.cityArray));

                } else {
                    scope.errorMsgLoc = "Invalid location";
                }

            }
            if (scope.data.campaignAudienceLocationsArr.length == 0)
            {
                angular.element('#step2').css('background-color', '#c2c2c2');
                angular.element('#campaignAudienceLocations').addClass("required");

            } else
            {
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#campaignAudienceLocations').removeClass("required");
            }
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
           // scope.setLine();
			scope.$emit('details-loaded');
        };
		
		
        function isString(value) {
            return typeof value == 'string';
        };
        

        function trim(value) {
            return isString(value) ? value.replace(/^\s*/, '').replace(/\s*$/, '') : value;
        };
        

        scope.removeGeoLocation = function (item) {
            var SVal = item.split("/")[0];

            var headers = {
                "userId": scope.userId,
                "accessToken": scope.accessToken
            }
				
			var querystr = "?type=adgeolocation&q=" + SVal+ "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.targetingsearchadlocale(querystr, headers).then(function (response) {
                scope.SingleLocationDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
				
				
                var Rdata = scope.SingleLocationDetails.find(function (ele) {
                    return trim(ele.name) === trim(SVal);
                });
                scope.data.campaignAudienceLocationsArr.splice(scope.data.campaignAudienceLocationsArr.indexOf(item), 1);
                if (Rdata) {
                    if (Rdata.type == 'country') {
                        scope.data.countryArray.splice(scope.data.countryArray.indexOf(Rdata.country_code), 1);
                    } else if (Rdata.type == 'region') {
                        scope.data.regionArray.splice(scope.data.regionArray.indexOf(Rdata.key), 1);
                    } else if (Rdata.type == 'city') {
                        scope.data.cityArray.splice(scope.data.cityArray.indexOf(Rdata.key), 1);
                    }
                    $window.localStorage.setItem("regionArray", JSON.stringify(scope.data.regionArray));
                    $window.localStorage.setItem("countryArray", JSON.stringify(scope.data.countryArray));
                    $window.localStorage.setItem("cityArray", JSON.stringify(scope.data.cityArray));

                }
                if (scope.data.campaignAudienceLocationsArr.length == 0)
                {
                    angular.element('#step2').css('background-color', '#c2c2c2');
                    angular.element('#campaignAudienceLocations').addClass("required");
                    //scope.setLine();
					scope.$emit('details-loaded');

                } else
                {
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#campaignAudienceLocations').removeClass("required");
                   // scope.setLine();
					scope.$emit('details-loaded');
                }

            })

            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
            scope.$emit('details-loaded');
			//setLine();
        };
		
		
		
		scope.init = function(){
			
			var campaignState = $window.localStorage.getItem("campaignState");
			scope.data.campaignAudienceLocationType = 'Include';
            if (campaignState == "create")
            {               
                 scope.data.campaignAudienceLocationTarget = 'everyone';
				
		    }   
			if (scope.data.campaignAudienceLocationTarget) {
                $window.localStorage.setItem("campaignAudienceLocationTarget", scope.data.campaignAudienceLocationTarget);
            }
			if (scope.data.campaignAudienceLocationType) {
                $window.localStorage.setItem("campaignAudienceLocationType", scope.data.campaignAudienceLocationType);
            }

		}
		scope.init();
		
			scope.$on('locationData', function (event,args) {
			 console.log(args);
			 	scope.data.regionArray= args.value.regionArray;
				scope.data.countryArray= args.value.countryArray;
				scope.data.cityArray= args.value.cityArray;
				scope.data.campaignAudienceLocationsArr= args.value.campaignAudienceLocationsArr;				
				scope.data.mapLocation= args.value.mapLocation;
				scope.data.campaignAudienceLocationTarget= args.value.campaignAudienceLocationTarget;
		  	
		})
	
   }
}
}]);