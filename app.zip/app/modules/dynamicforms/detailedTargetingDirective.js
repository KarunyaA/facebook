dashboard.directive('fbdetailedTargeting',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		transclude:true,			
		scope:{
			data:"="		 
		},	
		template:		
    '<div class="detailedtargetting">'+
      '<div class="tbl-lbl">Detailed targeting'+
	  '</div>'+ 
		'<div class="detailed-right" >'+
				'<div class="detailed-input"> '+
	               '<input type="text" autocomplete="off" id="campaignAudienceDetailedTargeting" placeholder="Add demographics, interests or behaviours..." class="autosearch-txt-box unstyled dropdown-toggle" readonly />'+                    
                                    '<div class="browsebutton"><button ng-click="showDetailTargetingListing()" data-toggle="dropdown" list="DetailedTargetingList" ng-model="campaignAudienceDetailedTargeting" class="autosearch-txt-box unstyled dropdown-toggle btnBrowseTargeting" type="button">Browse</button>'
                                      + ' <div class="dropdown-menu" ng-hide="detailtargetinglisting" ng-click="$event.stopPropagation()">'                        
                                         + ' <ul ng-repeat="val in data.DetailedTargetingArr| filter : campaignAudienceDetailedTargeting" >'
                                                +'<li ng-click="sendDetailTargetingKey(val.Key)"> {{val.Value}}'
												+'<i class="fa fa-search" aria-hidden="true"></i> </li>'
                                           +'</ul>'
                                       +' </div> '
                                    +'</div>'
                                    +'<div id="collapseTargeting" ng-if="detailtargetingsearch" class="dropdown-search"  ng-click="$event.stopPropagation()">'
                                        +'<div class="drop-list">'
                                            +'<i ng-click="showDetailTargeting()" class="fa">&#xf0d9;</i>'
                                           +' <input type="text" ng-model="campaignAudienceDetailedTargetingSearch" ng-if="showSearchKeyword" placeholder="{{SearchPlaceholder}}" autocomplete="off" class="autosearch-txt-box unstyled" ng-change="searchDetailTargeting(campaignAudienceDetailedTargetingSearch)">'
                                        +'</div>'
                                        +'<div class="drop-search" id="scroll">'
                                            +'<div ng-show="!DemographicChildLeafDetails.length">'
                                                +'<img alt="" src="images/Spinning-Loader.gif" class="ajax-loader"/>'
                                            +'</div>'
                                            +'<div ng-repeat="val in DemographicChildLeafDetails| filter: searchBy track by $index">'
                                                +'<div class="hd-detail" ng-click="DTtoggleSearchSelection(val.id, val.path, val.name, hdDetailedTargeting)">'
                                                    +'<div class="hd-detail1">'
                                                        +'<span ng-repeat="cval in val.path"><span ng-if="$index > 0"> / </span>{{cval}}'
														+'<span ng-if="hdDetailedTargeting == \'more\'"> / {{val.name}}'
														+'</span>'
														+'</span>'
                                                    +'</div>'
                                                    +'<div class="hd-detail2">'
                                                        +'<input type="checkbox" name="selectedDT[]" ng-checked="data.DTselectionkey.indexOf(val.id) > - 1" />'
                                                    +'</div>'
                                                +'</div>'
                                            +'</div>'
                                        +'</div>'
                                    +'</div>'
									+'</div>'
									+'</div>'	
							 +'<div>'                           
                            +'<div class="detail-prev">'
                               +'<span ng-hide="!data.DTselection.length">'
                                    +'<div class="detail-prev1" ng-repeat="val in data.DTselection track by $index" set-connector>'
                                        +'{{val.name}}'
                                        +'<a ng-click="removeDT(val.name, val.id)" ng-class="{\'avoid-clicks\':$root.noEdit}">'
                                            +'<i class="fa fa-trash" aria-hidden="true"></i></a>'                                        
                                   +' </div></span></div> </div>'
								   +'</div>',
                                               							
		link:function(scope,element,attr){	
	
	
	      scope.data ={
		    regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]			
	}

		scope.DemographicLeafDetails =[];
		scope.InterestsLeafDetails=[];
		scope.BehaviorsLeafDetails=[];
		scope.MoreLeafDetails=[];
        scope.campaignAudienceMoreDTJSON = [];
        scope.MobileKey = [];
        var camR = {};
        scope.campaignDetailedTargetingArr = [];
        scope.searchDemo = [];	
		scope.detailtargetingsearch =false;		
		scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        scope.$root.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
		scope.data.DetailedTargetingArr = JSON.parse($window.localStorage.getItem("detailedTargetingArr"));
	
		scope.showDetailTargetingListing = function(){
			scope.detailtargetinglisting = false;
			scope.detailtargetingsearch = false;
		};
    

		
		scope.init = function(){

		     //DEMOGRAPHIC LEAF DETAILS
			var demographicsPromise = [];
             var querystr1 ="?type=adTargetingCategory&class=demographics" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            demographicsPromise.push(facebookGetPost.demographictargetingsearch(querystr1).then(function (response) {
                scope.demographicsResponse = response.data.fbDemographicTargetingSearchResponse.data;
            }));
			$q.all(demographicsPromise).finally(function(){
				if(scope.demographicsResponse){
					scope.DemographicLeafDetails =    scope.demographicsResponse;	
				}
				
			})

            //INTEREST LEAF DETAILS
			var interestPromise = [];
            var querystr2 = "?type=adTargetingCategory&class=interests" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            interestPromise.push(facebookGetPost.demographictargetingsearch(querystr2).then(function (response) {
                scope.interestResponse = response.data.fbDemographicTargetingSearchResponse.data;
            }));
				$q.all(interestPromise).finally(function(){
				if(scope.interestResponse){
					scope.InterestsLeafDetails = scope.interestResponse;	
				}
				
			})

            //BEHAVIOURS LEAF DETAILS
			var behaviourPromise = [];
            var querystr3 = "?type=adTargetingCategory&class=behaviors" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            behaviourPromise.push(facebookGetPost.demographictargetingsearch(querystr3).then(function (response) {
                scope.behaviourResponse = response.data.fbDemographicTargetingSearchResponse.data;
            }));
			$q.all(behaviourPromise).finally(function(){
				if(scope.behaviourResponse){
					scope.BehaviorsLeafDetails = scope.behaviourResponse;	
				}
				
			})
						
            //MORE LEAF DETAILS
			var moreleafpromise =[];
            var querystr4 =  "?userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId') +"&adAccountId=" + $window.localStorage.getItem('networkAdAccountId') + "&limitType=user_adclusters";
            moreleafpromise.push(facebookGetPost.getfacebookgraph(querystr4).then(function (response) {
               
                scope.moreLeafResponse = response.data.fbTargetingBrowseResponse;
				 scope.$root.progressLoader = "none";

            }));
			$q.all(moreleafpromise).finally(function(){
				if(scope.moreLeafResponse){
					scope.MoreLeafDetails = scope.moreLeafResponse;
									
				}
				
			})
		}	
		

	
		var w = angular.element($window);
        w.bind('click', function (e) {
            if (this) {
                setTimeout(scope.showWindowDetailTargetingListing, 50);
            }
        });

        scope.showWindowDetailTargetingListing = function () {
            scope.$apply(function () {
                scope.detailtargetinglisting = false;
                scope.detailtargetingsearch = false;
            });
        };
        scope.sendDetailTargetingKey = function (val) {
            $('.drop-search').show();
            $('.drop-list').show();
            $("#collapseTargeting").addClass('dropdown-search');
            scope.detailtargetinglisting = true;
            scope.detailtargetingsearch = true;
            scope.SearchPlaceholder = val;
            scope.hdDetailedTargeting = val;
            scope.DemographicChildLeafDetails = '';
            scope.showSearchKeyword = 1;		
            if (scope.hdDetailedTargeting == 'demographics') {
                scope.DemographicChildLeafDetails = scope.DemographicLeafDetails;
            } else if (scope.hdDetailedTargeting == 'interests') {
                scope.DemographicChildLeafDetails = scope.InterestsLeafDetails;
            } else if (scope.hdDetailedTargeting == 'behaviors') {
                scope.DemographicChildLeafDetails = scope.BehaviorsLeafDetails;
            } else if (scope.hdDetailedTargeting == 'more') {
                angular.forEach(scope.DemographicLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                angular.forEach(scope.InterestsLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                angular.forEach(scope.BehaviorsLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                scope.DemographicChildLeafDetails = scope.MoreLeafDetails;
            };
        
            scope.searchDemo = scope.DemographicChildLeafDetails;
			console.log(scope.detailtargetingsearch);
        };

		 scope.searchDetailTargeting = function (searchElement) {         
            searchElement = searchElement.toLowerCase();
            var arrTargeting = angular.copy(scope.searchDemo);
            if (searchElement != undefined && searchElement != "" && searchElement != 'undefined')
            {
                if (searchElement.length != 0) {
                    var array = angular.copy(arrTargeting);
                    scope.DemographicChildLeafDetails = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].name.toLowerCase().includes(searchElement))
                            scope.DemographicChildLeafDetails.push(array[i]);
                    }
                } else {
                    scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
                }
            } else {
                scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
            }             
       }

        // Detail targeting Search Toggle selection    
     scope.DTtoggleSearchSelection = function (DTSearchId, DTSearchPath, DTSearchName, hiddenname) {

            var dt_val = '';

            angular.forEach(DTSearchPath, function (val) {
                dt_val += val + ' / ';
            });
            var lnk_dtl = '';
            if (hiddenname == 'more') {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val + DTSearchName, 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            } else {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val.substr(0, dt_val.length - 2), 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            }

            var idx = scope.data.DTselection.indexOf(DTSearchPath);
            var idxx = scope.data.DTselectionkey.indexOf(DTSearchId);

            if (idxx > -1) {
                scope.data.DTselection.splice(idxx, 1);
                scope.data.DTselectionkey.splice(idxx, 1);				
                //console.log('hiddenname : '+hiddenname);
                if (hiddenname == 'demographics') {
                    scope.data.demographicsArray.splice(idxx, 1);
                } else if (hiddenname == 'interests') {
                    scope.data.interestsArray.splice(idxx, 1);
                } else if (hiddenname == 'behaviors') {
                    scope.data.behaviorsArray.splice(idxx, 1);
                } else if (hiddenname == 'more') {
                    scope.data.demographicsArray.splice(idxx, 1);
                }
                ;
                scope.data.campaignAudienceDTJSON={
                    "user_adclusters": scope.data.demographicsArray,
                    "interests": scope.data.interestsArray,
                    "behaviors": scope.data.behaviorsArray
                };
            } else {
                scope.data.DTselection.push(DTSearchPath);
                scope.data.DTselectionkey.push(DTSearchId);				
                if (hiddenname == 'demographics') {
                    var DKey = {"id": DTSearchId};
                    scope.data.demographicsArray.push(DKey);
                } else if (hiddenname == 'interests') {
                    var IKey = {"id": DTSearchId};
                    scope.data.interestsArray.push(IKey);
                } else if (hiddenname == 'behaviors') {
                    var BKey = {"id": DTSearchId};
                    scope.data.behaviorsArray.push(BKey);
                } else if (hiddenname == 'more') {
                    var MKey = {"id": DTSearchId};
                    scope.data.demographicsArray.push(MKey);
                }
                ;

                scope.data.campaignAudienceDTJSON={
                    "user_adclusters": scope.data.demographicsArray,
                    "interests": scope.data.interestsArray,
                    "behaviors": scope.data.behaviorsArray
                };
            }
			scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
           // scope.setLine();
		   scope.$emit('details-loaded');
        };
				
		 scope.$on('DTtoggleSearchSelection', function (event,args) {
			 console.log(args);
		  	scope.DTtoggleSearchSelection(args.id,args.path,args.name,args.rootpath);
		})
		 scope.showDetailTargeting = function () {
            scope.showSearchKeyword = 0;
            scope.campaignAudienceDetailedTargetingSearch = "";
            scope.detailtargetinglisting = false;
            scope.detailtargetingsearch = true;
            $('.drop-search').hide();
            $('.drop-list').hide();
            $('dropdown-menu').hide();
            $("#collapseTargeting").removeClass('dropdown-search');
            
        };
		    scope.removeDT = function (name, id) {
            var idx = scope.data.DTselectionkey.indexOf(id);
            scope.data.DTselectionkey.splice(idx, 1);
            var idxx = scope.data.DTselection.indexOf(name);
            scope.data.DTselection.splice(idx, 1);

            angular.forEach(scope.data.demographicsArray, function (val, key) {
                if (val.id == id) {
                    scope.data.demographicsArray.splice(key, 1);
                }
            });
            angular.forEach(scope.data.interestsArray, function (val, key) {
                if (val.id == id) {
                    scope.data.interestsArray.splice(key, 1);
                }
            });
            angular.forEach(scope.data.behaviorsArray, function (val, key) {
                if (val.id == id) {
                    scope.data.behaviorsArray.splice(key, 1);
                }
            });
            scope.data.campaignAudienceDTJSON={
                "user_adclusters": scope.data.demographicsArray,
                "interests": scope.data.interestsArray,
                "behaviors": scope.data.behaviorsArray
            };
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
           // scope.setLine();
			scope.$emit('details-loaded');
        };

		
		scope.init();
		

		
		  scope.$on('detaileddata', function (event,args) {
			 console.log(args);
			 
			 scope.data.campaignAudienceDTJSON= args.value.campaignAudienceDTJSON;			
			 scope.data.DTselectionkey= args.value.DTselectionkey;
			 scope.data.DTselection= args.value.DTselection;
			 scope.data.demographicsArray= args.value.demographicsArray;
			 scope.data.interestsArray= args.value.interestsArray;
			 scope.data.behaviorsArray= args.value.behaviorsArray;
			 
		  	
		})
		
		
		}

		//controller:'',
		//bindToController:true,
	}
	
}])
 