var dynamicForm=angular.module('app',['replicator','dashboard']); 
dynamicForm.controller("dynamnicbypcampaignaudienceController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', 'netWorkData', '$timeout', 'facebookGetPost',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData, $timeout, facebookGetPost) {

        var vm = this;
        var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
        $scope.selectedObjective = $window.localStorage.getItem("marketingObjective");
        $scope.campaignAudienceLanguageArr = [];
		$scope.campaignAudienceLocationsArr=[];
        $scope.campaignAudienceCampaignConversionPixelArr = [];
        $scope.campaignAudienceCampaignOfferArr = [];
        $scope.editAdsetErrorMsg = 'none';
        $scope.promotionObjective = 'no';
        $scope.placementsValues = [];
        $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
        vm.showDetails = true;
        vm.home = {};
        $scope.secondActiveDiv = 'yes';
        $scope.campaignAudienceCampaignTargetLoader = false;
        $scope.campaignAudienceCampaignOfferLoader = false;
        $scope.campaignAudienceCampaignConversionPixelLoader = false;
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.ngLanLoader = false;
        $scope.ngLocLoader = false;
        $scope.reverse = true;
        $scope.currentPage = 1;
        $scope.campaignAudienceGender = 'all';
        $scope.campaignAudienceAgeFrom = '18';
        $scope.campaignAudienceAgeTo = '65';
        $scope.campaignAudienceLanguage = '';
        $scope.campaignAudienceLocationType = 'Include';
        $scope.FBName = '';
        $scope.selectedData = null;
        $scope.campaignAudienceCampaignTargetType = false;
        $scope.demographics = false;
        $scope.interests = false;
        $scope.behaviors = false;
        $scope.more = false;
        $scope.viewPromotion = true;
        $scope.audienceNum = 1;
        $scope.mobileView = false;
        $scope.adsetDetailsJSON = {}
        $scope.errLoc = 1;
        $scope.adminUserRole = false;
        $scope.offerobjective = false;
        $scope.campaignAudienceGender1 = "";
		     $scope.DTselectionkey = [];
        $scope.DTselection = [];
        $scope.campaignAudienceDTJSON = [];
        $scope.demographicsArray = [];
        $scope.interestsArray = [];
        $scope.behaviorsArray = [];
        $scope.moreArray = [];

			$scope.locationData = {
				regionArray : [],
				countryArray:[],
				cityArray:[],
				campaignAudienceLocationsArr:[],
				campaignAudienceLocationType:"",
				mapLocation:false,
              	campaignAudienceLocationTarget:"everyone"
			}
			$scope.ageData = {
				 campaignAudienceAgeFrom:"",
				 campaignAudienceAgeTo:""
			}
			$scope.genderData ={
				campaignAudienceGender :"all"
			}
			$scope.languageData = {
				 campaignAudienceLanguage:"",
				 campaignAudienceLanguageArr:[],
				 campaignAudienceLanguageKeyArr:[],
				 LanguageKeyValues:""
			}
            $scope.placementsData = {
                placementsValues :[],
                campaignAudiencePlacementsWiFi:"1",
                campaignAudienceMobileDevice:"",
                mobileView:false,
                PlacementsArr:[],
                MobileDeviceArr:[],
                placementsKeyValues:[]
            }
		$scope.detaileddata ={
		     campaignAudienceDTJSON:[],
			 DetailedTargetingArr:[],
             DTselectionkey:[],
			 DTselection:[],
			 demographicsArray:[],
			 interestsArray:[],
			 behaviorsArray:[]			
	}
        $scope.promotedobjectdata = {
            popupTitle: "",
            popupMessage: ""
        }

		$scope.path = "../CNAP_UI_Repo/";
		$scope.pageContent={};
		$scope.stepTitleContent={}
	   
        $scope.charExist = function (n) {
            if (n.indexOf('Checkbox') !== -1) {
                return 'Checkbox';
            } else if (n.indexOf('Search') !== -1) {
                return 'Search';
            } else {
                return 'Dropdown';
            }
        };


        //DEFAULT SELECTION
        

        $scope.DetailedTargetingArr = [
            {Key: "demographics", Value: "Demographics"},
            {Key: "interests", Value: "Interests"},
            {Key: "behaviors", Value: "Behaviours"},
            {Key: "more", Value: "More Categories"}
        ];
		$window.localStorage.setItem("detailedTargetingArr", JSON.stringify($scope.DetailedTargetingArr));
        $scope.DetailedTargetingSecondArr = [
            {Key: "Education", Value: "Education"},
            {Key: "EthnicAffinity", Value: "Ethnic Affinity"},
            {Key: "Generation", Value: "Generation"},
            {Key: "Home", Value: "Home"}
        ];


        $scope.wifiArr = {
            "wireless_carrier": [
                "Wifi"
            ]
        }
        
        $scope.showErrorPopup = function (response) {
            if (response.hasOwnProperty("data"))
            {
                if (response.data.networkError)
                {
                    if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined) 
                    {
                        $scope.popupTitle = response.data.networkError.error_user_title;
                        $scope.popupMessage = response.data.networkError.error_user_msg;
                    } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined) 
                    {

                        $scope.popupTitle = "Error";
                        $scope.popupMessage = response.data.networkError.message;
                    }
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.data.errorMessage;
                }
            } else {
                if (response.networkError) {
                    if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                        $scope.popupTitle = response.networkError.error_user_title;
                        $scope.popupMessage = response.networkError.error_user_msg;
                    } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                        $scope.popupTitle = "Error";
                        $scope.popupMessage = response.networkError.message;
                    }
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.errorMessage;
                }

            }
            var modalApproveReq = $(".error_popup"); // Get the modal Approve req
            modalApproveReq.show();
        };
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }

	  function isString(value) {
            return typeof value == 'string';
        };
        
        function trim(value) {
            return isString(value) ? value.replace(/^\s*/, '').replace(/\s*$/, '') : value;
        };
        
		
            $scope.setLine = function () {
                var everythingLoaded = setInterval(function () {
                    if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                        if ($scope.audienceNum == "2") {
                            $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                            $scope.ssValue = angular.element(document.getElementById('step2')).offset().top;
                            $scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                            var offsetHeight3 = document.getElementById('step3container').offsetHeight;
                            var fStep = $(".vr");
                            fStep.css('height', (($scope.lsValue - $scope.fsValue)));
                        } else if ($scope.audienceNum == "1") {
                            $scope.fsValue = angular.element(document.getElementById('step2')).offset().top;
                            $scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                            var offsetHeight2 = document.getElementById('step3container').offsetHeight;
                            var fStep = $(".vr");
                            fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
                        }
                    }
                }, 10);
            }
			
				
		$scope.data = 'none';
		$scope.add = function(){
			var xmlPath =$scope.path + "app/modules/dynamicforms/data/details-form.xml"
			/* $http.get($scope.path + "app/modules/dynamicforms/data/details-form.xml").success(function (data){
				
				console.log(data.facebook);
		  
            }); */
			
			$http.get(xmlPath,  
			{  
				transformResponse: function(cnv)  
				{  
					var x2js = new X2JS();  
					var aftCnv = x2js.xml_str2json(cnv);  
					return aftCnv;  
				}  
			}).success(function(response)  
			{  
				console.log(response.root.campaignDetails);  
			});  
			
		};
			
		$scope.fetchData = function(details){			
			angular.forEach(details, function (val, key){
				var JsonObj= details[key].fieldset.fields;
				$scope.config = details[key].fieldset.fields;
				   var array = [];
				 // console.log(JsonObj);
				for (var i in JsonObj) {				
					if (JsonObj.hasOwnProperty(i)) {
						array[+i] = JsonObj[i];
						$scope.pageContent[i] = array[+i];
					//	console.log($scope.pageContent[i]);
						//traverse(JsonObj[i],process);
					}
				}
				  
			});
			
						
            $scope.viewConversion = false;
            $rootScope.step = 2;
            if ($rootScope.campaignSteps[1] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }

            var campaignState = $window.localStorage.getItem("campaignState");
            $scope.campstate = $window.localStorage.getItem("campaignState");
            angular.element('#step1').css('background-color', '#C2C2C2');


            if ($scope.campaignAudienceLocationTarget) {
                $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
            }

            if ($window.localStorage.getItem("marketingObjective") == 'POST_ENGAGEMENT') {
                $scope.promotionObjective = 'no';
                $scope.viewPromotion = false;
            }


            if ($scope.viewPromotion) {
                $scope.audienceNum = 2;
            } else if ($scope.viewConversion) {
                $scope.audienceNum = 2;
            } else {
                $scope.audienceNum = 1;
            }

            $scope.FBName = 'App';
            $window.localStorage.setItem("campaignAudienceTargetType", "app");
            if (campaignState == "edit") {
                if ($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;
                } else {
                    $scope.adminUserRole = false;
                }
                var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.getEditAdsetDetails(campaignDetails);
            }

            $scope.setLine();
		
		} 	
		$scope.loadLocalJson = function(){
			 $http.get($scope.path + "app/modules/dynamicforms/data/boostyourposts/audience-form.json").success(function (data){
				var details = data.audienceDetails;
				$scope.pageContent=data.audienceDetails;
				$scope.fetchData(details);
				angular.forEach(details, function (val, key){
				   $scope['step'+(key+1)]= details[key];
				 console.log($scope['step'+(key+1)]);
				   $scope.setLine();
				});
			}); 
	/* 		var xmlPath =$scope.path + "app/modules/dynamicforms/data/details-form.xml"
			$http.get(xmlPath,  
			{  
				transformResponse: function(cnv)  
				{  
					var x2js = new X2JS();  
					var aftCnv = x2js.xml_str2json(cnv);  
					return aftCnv;  
				}  
			}).success(function(response)  
			{  
				console.log(response.root.campaignDetails);  
				var details = response.root.campaignDetails;
				$scope.pageContent= response.root.campaignDetails;
				$scope.fetchData(details);
				angular.forEach(details, function (val, key){
				   $scope['step'+(key+1)]= details[key];				   
				   $scope.setLine();
				});
				
			});  */ 
			
		} 
		
		function process(key,value) {
		
			$scope.data[key] = value;
			//console.log($scope.data);
			$scope.stepTitleContent[key] = value;
			
		}

		function traverse(o,func) {
			for (var i in o) {
				func.apply(this,[i,o[i]]);  
				if (o[i] !== null && typeof(o[i])=="object") {
					//going one step down in the object tree!!
					traverse(o[i],func);
				}
			}
			
		}
		$scope.$on('content', function () {
            alert('sdfsd');
			console.log($scope.pageContent[i])
        });
		
        $scope.init = function () {
            $rootScope.overLayAudience = false;
            $rootScope.freezeFlag = false;

			$scope.loadLocalJson();

        }

        $scope.$on('details-loaded', function () {
            $scope.setLine();
        });
      
	      $scope.MobileDeviceArr = {
                "data":
                        [
                            {
                                "name": "All mobile devices",
                                "id": "allmobiledevices"
                            },
                            {
                                "name": "Android devices only",
                                "id": "Android"
                            },
                            {
                                "name": "IOS devices only",
                                "id": "iOS"
                            },
                            {
                                "name": "Feature phones only",
                                "id": "Feature_Phone"
                            }
                        ]
            };

        $scope.emptycheckforMandatoryfields = function ()
        {
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            console.log($scope.campaignAudienceCampaignTarget);
            if ($scope.campaignAudienceCampaignTarget == "" || $scope.campaignAudienceCampaignTarget == undefined || $scope.campaignAudienceCampaignTarget == null)
            {
                angular.element('#mandatory').addClass("mandatory");
            } else
            {
                angular.element('#mandatory').removeClass("mandatory");
            }
            console.log($scope.campaignAudienceLocationsArr.length)
            if ($scope.campaignAudienceLocationsArr.length == 0)
            {

                angular.element('#campaignAudienceLocations').addClass("required");
            } else
            {
                angular.element('#campaignAudienceLocations').removeClass("required");
            }
        };

        $scope.prePopulateValues = function (response) {
            $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"block"});
            $scope.campaignAudienceLocationsArr = [];
            var campaignId = $window.localStorage.getItem('campaignId');
            angular.forEach(response.adsets, function (value, key) {
                var JsonObj = response.adsets[key];
                var array = [];
                for (var i in JsonObj) {
                    if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                        var DTDetails = array[+i] = JsonObj[i];
                        //GET LOCATIONS                    
                        if (DTDetails.adsetDetails.targeting.geo_locations.countries != '' && DTDetails.adsetDetails.targeting.geo_locations.countries != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(DTDetails.adsetDetails.targeting.geo_locations.countries, function (val, key) {

							    var querystr = '?type=adgeolocationmeta&countries=["' + val + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {
                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    $scope.mapLocation = true;
									$scope.locationData.mapLocation = true;
                                    $scope.countryArray.push(val);
									$scope.locationData.countryArray.push(val);
                                    $scope.campaignAudienceLocationsArr.push($scope.FBCountryDetails.countries[val].name);
									$scope.locationData.campaignAudienceLocationsArr.push($scope.FBCountryDetails.countries[val].name);
									console.log($scope.locationData.campaignAudienceLocationsArr);
                                    $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.setLine();								
									$scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});
                                })

                            });
                            $scope.setLine();
                        }

                        if (DTDetails.adsetDetails.targeting.geo_locations.regions != '' && DTDetails.adsetDetails.targeting.geo_locations.regions != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(DTDetails.adsetDetails.targeting.geo_locations.regions, function (val, key) {

                                  //var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + $rootScope.networkAccessToken;
                                var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    var r_obj = {"key": val.key};
                                    $scope.regionArray.push(r_obj);
									$scope.locationData.regionArray.push(r_obj);
                                    $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
                                    $scope.locationData.campaignAudienceLocationsArr.push(val.name + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
									console.log($scope.locationData.campaignAudienceLocationsArr);
									$window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.emptycheckforMandatoryfields();	
									$scope.mapLocation = true;
									$scope.locationData.mapLocation = true;									
									 $scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});
									
                                })
                            });
                        }
                        if (DTDetails.adsetDetails.targeting.geo_locations.cities != '' && DTDetails.adsetDetails.targeting.geo_locations.cities != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(DTDetails.adsetDetails.targeting.geo_locations.cities, function (val, key) {
								//var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + $rootScope.networkAccessToken;
                                var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    var c_obj = {"key": val.key};
                                    //alert(c_obj);
                                    $scope.cityArray.push(c_obj);
									$scope.locationData.cityArray.push(c_obj);
                                    $scope.mapLocation = true;
									$scope.locationData.mapLocation = true;
                                    $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + val.region + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
                                    $scope.locationData.campaignAudienceLocationsArr.push(val.name + ' / ' + val.region + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
									$window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.emptycheckforMandatoryfields();
									 $scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});
                                })
                            });
                        }
                        $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);


                        //GET CONNECTION
                        if (DTDetails.adsetDetails.targeting.wireless_carrier != '') {
                            $scope.campaignAudiencePlacementsWiFi = 1;
                            $window.localStorage.setItem("campaignAudiencePlacementsWiFi", $scope.campaignAudiencePlacementsWiFi);
                        } else {
                            $scope.campaignAudiencePlacementsWiFi = 0;
                            $window.localStorage.setItem("campaignAudiencePlacementsWiFi", $scope.campaignAudiencePlacementsWiFi);
                        }
						//$scope.$broadcast('placementsData',{id:"wifi",value:$scope.campaignAudiencePlacementsWiFi});
                        //GET AGE
                        $scope.campaignAudienceAgeFrom = DTDetails.adsetDetails.targeting.age_min;
						$scope.ageData.campaignAudienceAgeFrom = DTDetails.adsetDetails.targeting.age_min;
                        $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
                        $scope.campaignAudienceAgeTo = DTDetails.adsetDetails.targeting.age_max;
						$scope.ageData.campaignAudienceAgeTo = DTDetails.adsetDetails.targeting.age_max;
                        $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
						 $scope.$broadcast('ageData',{id:"ageData",value:$scope.ageData});

                        //GET GENDER
                        $scope.campaignAudienceGender1 = DTDetails.adsetDetails.targeting.genders;
                        if ($scope.campaignAudienceGender1 == '1') {
                            $scope.campaignAudienceGender = 'men';
                        } else if ($scope.campaignAudienceGender1 == '2') {
                            $scope.campaignAudienceGender = 'women';
                        } else {
                            $scope.campaignAudienceGender = 'all';
                        }
						$scope.genderData.campaignAudienceGender = $scope.campaignAudienceGender;
                        $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
						$scope.$broadcast('genderData',{value:$scope.genderData});
                        //GET LANGUANGE
                        $scope.campaignAudienceLanguageKey = DTDetails.adsetDetails.targeting.locales;
                        $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);

                        //GET LANGUANGE
                        $scope.campaignAudienceLanguageKey = DTDetails.adsetDetails.targeting.locales;
                        $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);

                        //LANGUAGE FB SERVICE DETAILS
                        $scope.ngLanLoader = true;
                        $scope.campaignAudienceLanguageKeyArr = [];
                        $scope.campaignAudienceLanguageArr = [];						
					    var querystr ="?type=adLocale" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                        facebookGetPost.demographictargetingsearch(querystr).then(function (response) {
                            $scope.FBLanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;					
                            angular.forEach(DTDetails.adsetDetails.targeting.locales, function (val) {
                                var sObj = $filter('filter')($scope.FBLanguageDetails, function (d) {
                                    return d.key == val;
                                })[0];
                                $scope.campaignAudienceLanguageKeyArr.push(sObj.key);
                                $scope.campaignAudienceLanguageArr.push(sObj.name);
								$scope.languageData.campaignAudienceLanguageKeyArr.push(sObj.key);
								$scope.languageData.campaignAudienceLanguageArr.push(sObj.name);
								console.log($scope.languageData.campaignAudienceLanguageArr);
                            });
                            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
                            $scope.LanguageKeyValues = {
                                "locales": $scope.campaignAudienceLanguageKeyArr
                            }
                            $scope.ngLanLoader = false;
                           $scope.languageData.LanguageKeyValues =  $scope.LanguageKeyValues ;
						   $scope.$broadcast('languageData',{id:"languageData",value:$scope.languageData});
                        })
                        $scope.demographicsArray = [];
                        $scope.interestsArray = [];
                        $scope.behaviorsArray = [];

                        //GET DETAIL TARGETING                    
                        if (DTDetails.adsetDetails.targeting.user_adclusters != '' && DTDetails.adsetDetails.targeting.user_adclusters != undefined) {
                            angular.forEach(DTDetails.adsetDetails.targeting.user_adclusters, function (val, key) {
                                var s_obj = {"id": val.id};
                                $scope.demographicsArray.push(s_obj);
								$scope.detaileddata.demographicsArray.push(s_obj);
                                $scope.DTselection.push(val);
								$scope.detaileddata.DTselection.push(val);
                                $scope.DTselectionkey.push(val.id);
								$scope.detaileddata.DTselectionkey.push(val.id);
								console.log($scope.DTselectionkey);								 
								$scope.$broadcast('detaileddata',{id:"detaileddata",value:$scope.detaileddata});
								 
                            });
                        }
                        if (DTDetails.adsetDetails.targeting.interests != '' && DTDetails.adsetDetails.targeting.interests != undefined) {
                            angular.forEach(DTDetails.adsetDetails.targeting.interests, function (val, key) {
                                $scope.DTselection.push(val);
                                var s_obj = {"id": val.id};
                                $scope.interestsArray.push(s_obj);
								$scope.detaileddata.interestsArray.push(s_obj);
                                $scope.DTselectionkey.push(val.id);
								$scope.detaileddata.DTselectionkey.push(val.id);								
								console.log($scope.DTselectionkey);
								$scope.detaileddata.DTselection.push(val);								
								$scope.$broadcast('detaileddata',{id:"detaileddata",value:$scope.detaileddata});
								 
                            });
                        }
                        if (DTDetails.adsetDetails.targeting.behaviors != '' && DTDetails.adsetDetails.targeting.behaviors != undefined) {
                            angular.forEach(DTDetails.adsetDetails.targeting.behaviors, function (val, key) {
                                $scope.DTselection.push(val);
                                var s_obj = {"id": val.id};
                                $scope.behaviorsArray.push(s_obj);
								$scope.detaileddata.behaviorsArray.push(s_obj);
                                $scope.DTselectionkey.push(val.id);
								$scope.detaileddata.DTselectionkey.push(val.id);
								console.log($scope.DTselectionkey);
								$scope.detaileddata.DTselection.push(val);
								 $scope.$broadcast('detaileddata',{id:"detaileddata",value:$scope.detaileddata});
                            });
                        }

                        //GET LOCATION TYPE [EVERY-ONE etc..]
                        if (DTDetails.adsetDetails.targeting.geo_locations.location_types == '') {
                            $scope.campaignAudienceLocationTarget = 'everyone';
							$scope.locationData.campaignAudienceLocationTarget = 'everyone';
                        } else {
                            $scope.campaignAudienceLocationTarget = DTDetails.adsetDetails.targeting.geo_locations.location_types;
							$scope.locationData.campaignAudienceLocationTarget = DTDetails.adsetDetails.targeting.geo_locations.location_types;
                        }
                        $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
						$scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});

                        //GET PLACEMENTS
                        angular.forEach(DTDetails.adsetDetails.targeting.publisher_platforms, function (val, key) {
                            if (val == 'facebook') {
                                angular.forEach(DTDetails.adsetDetails.targeting.facebook_positions, function (value1, key1) {
                                    angular.forEach(DTDetails.adsetDetails.targeting.device_platforms, function(value2, key2){
                                        if(value2 == 'desktop') {
                                            if(value1=="feed"){
                                           // $scope.setCheckedVal('desktopnewsfeed','prefill');
                                            $scope.$broadcast('placementsData',{id:"setValue",placement:"desktopnewsfeed",value:"prefill"});
                                        }else{
                                           // $scope.setCheckedVal('desktoprightcolumn','prefill');
                                             $scope.$broadcast('placementsData',{id:"setValue",placement:"desktoprightcolumn",value:"prefill"});
                                        }
                                        }else if(value2 == 'mobile') {
                                           // $scope.setCheckedVal('mobilenewsfeed','prefill');
                                             $scope.$broadcast('placementsData',{id:"setValue",placement:"mobilenewsfeed",value:"prefill"});
                                        }
                                    });                             
                                });
                            }
                            if (val == 'audience_network') {
                                //$scope.setCheckedVal('audiencenetwork', 'prefill');
                                $scope.$broadcast('placementsData',{id:"setValue",placement:"audiencenetwork",value:"prefill"});
                            }
                        });

                        if (DTDetails.adsetDetails.targeting.instagram_positions == 'stream') {
                            //$scope.setCheckedVal('instagram', 'prefill');
                             $scope.$broadcast('placementsData',{id:"setValue",placement:"instagram",value:"prefill"});
                        }
                        $window.localStorage.setItem("campaignAudienceplacementsValues", $scope.placementsData.placementsValues);



                        //GET MOBILE DEVICE DATAS
                        if ($window.localStorage.getItem("marketingObjective") != 'CANVAS_APP_INSTALLS' || $window.localStorage.getItem("marketingObjective") != 'CANVAS_APP_ENGAGEMENT') {
                            $scope.campaignAudienceMobileDevice = 'All mobile devices';
                            $scope.placementsData.campaignAudienceMobileDevice = 'All mobile devices';
                            $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);							
							  
							   $scope.$broadcast('placementsData',{id:"mobileData",value:$scope.placementsData.campaignAudienceMobileDevice});
                        }
                        if ($scope.MobileDeviceArr != undefined && (DTDetails.adsetDetails.targeting.user_os != '' && DTDetails.adsetDetails.targeting.user_os != undefined) || (DTDetails.adsetDetails.targeting.user_device != '' && DTDetails.adsetDetails.targeting.user_device != undefined)) {
                            //console.log(DTDetails.adsetDetails.targeting.user_device);
                            if (DTDetails.adsetDetails.targeting.user_os == 'Android' || DTDetails.adsetDetails.targeting.user_os == 'iOS') {
                                var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                                    return d.id == DTDetails.adsetDetails.targeting.user_os;
                                })[0];
                                $scope.campaignAudienceMobileDevice = sobject.name;
                                $scope.placementsData.campaignAudienceMobileDevice = sobject.name;
                            } else if (DTDetails.adsetDetails.targeting.user_device == 'Feature_Phone') {
                                var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                                    return d.id == DTDetails.adsetDetails.targeting.user_device;
                                })[0];
                                $scope.campaignAudienceMobileDevice = sobject.name;
                                $scope.placementsData.campaignAudienceMobileDevice = sobject.name;
                            } else {
                                $scope.campaignAudienceMobileDevice = 'All mobile devices';
                                $scope.placementsData.campaignAudienceMobileDevice = 'All mobile devices';
                            }
                            $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);							
							$scope.$broadcast('placementsData',{id:"mobileData",value:$scope.placementsData.campaignAudienceMobileDevice});
                        }

                    }
                }
            });
            
            if ($scope.campaignAudienceGender1 == '' || $scope.campaignAudienceGender1 == undefined || $scope.campaignAudienceGender1 == null) {
                if ($scope.campaignAudienceGender == '1') {
                    $scope.campaignAudienceGender = 'men';
                } else if ($scope.campaignAudienceGender == '2') {
                    $scope.campaignAudienceGender = 'women';
                } else {
                    $scope.campaignAudienceGender = 'all';
                }
            }
            $scope.genderData.campaignAudienceGender =  $scope.campaignAudienceGender;			
			$scope.$broadcast('genderData',{id:"genderData",value:$scope.genderData});
           /* $scope.campaignPlacementsArray1 = $window.localStorage.getItem("campaignAudienceplacementsValues");
            $scope.splitPlacements = $scope.campaignPlacementsArray1.split(",");
            $scope.array1 = [];
            
            for(var i=0; i<$scope.splitPlacements.length; i++){
                $scope.array1.push($scope.splitPlacements[i]);
                
            }
            console.log(JSON.stringify($scope.array1,null,2));
            
            for(var i=0; i<$scope.array1.length; i++){
                if($scope.array1[i] == 'desktopnewsfeed'){
                    $scope.placementsValues.push('desktopnewsfeed')
                }
                if($scope.array1[i] == 'desktoprightcolumn'){
                    $scope.placementsValues.push('desktoprightcolumn')
                }
                
                if($scope.array1[i] == 'mobilenewsfeed'){
                    $scope.placementsValues.push('mobilenewsfeed')
                    $scope.mobileView = true;
                }
                
                
            }*/
            
            $scope.campaignAudienceCampaignTargetType = $window.localStorage.getItem("campaignAudienceTargetType");
            console.log("promotionObjective :::: " + $scope.promotionObjective);
            if ($scope.promotionObjective != 'no' && $scope.promotionObjective != '' && $scope.promotionObjective != 'false' && $scope.promotionObjective != undefined && $scope.promotionObjective != null) {
                $scope.getCampaignTarget();
            } else {
                $scope.campaignAudienceCampaignTargetType = '';
            }


            $scope.campaignAudienceLocationType = $window.localStorage.getItem("campaignAudienceLocationType");
            $scope.campaignAudienceAgeFrom = $window.localStorage.getItem("campaignAudienceAgeFrom");
			$scope.ageData.campaignAudienceAgeFrom = $window.localStorage.getItem("campaignAudienceAgeFrom");
            $scope.campaignAudienceAgeTo = $window.localStorage.getItem("campaignAudienceAgeTo");
			$scope.ageData.campaignAudienceAgeTo = $window.localStorage.getItem("campaignAudienceAgeTo");
            $scope.campaignAudienceGender = $window.localStorage.getItem("campaignAudienceGender");
			$scope.genderData.campaignAudienceGender =  $scope.campaignAudienceGender;
            $scope.campaignAudienceLanguageKey = $window.localStorage.getItem("campaignAudienceLanguageKey");
            $scope.campaignAudienceLanguage = $window.localStorage.getItem("campaignAudienceLanguage");
			$scope.languageData.campaignAudienceLanguage = $window.localStorage.getItem("campaignAudienceLanguage");
            $scope.campaignAudienceDTJSON = $window.localStorage.getItem("campaignAudienceDTJSON");
			
            $scope.campaignAudienceDTselection = JSON.parse($window.localStorage.getItem("campaignAudienceDTselection"));
            $scope.campaignAudiencePlacementsWiFi = $window.localStorage.getItem("campaignAudiencePlacementsWiFi");
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget");
			$scope.locationData.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            if ($scope.campaignAudiencePlacementsWiFi == 1) {
                $scope.campaignAudiencePlacementsWiFi = 1;
            } else {
                $scope.campaignAudiencePlacementsWiFi = 0;
            }
             $scope.placementsData.campaignAudiencePlacementsWiFi = $scope.campaignAudiencePlacementsWiFi;
			 
            $scope.campaignAudienceDTJSON = JSON.parse($scope.campaignAudienceDTJSON);
			 //$scope.detaileddata.campaignAudienceDTJSON = JSON.parse($scope.campaignAudienceDTJSON);
			//$scope.$broadcast('detaileddata',{id:"detaileddata",value:$scope.detaileddata});
            if (response.adsets.length == '0') {
                angular.forEach($scope.campaignAudienceDTselection, function (value, key) {
                    //$scope.DTtoggleSearchSelection(value.id, value.path, value.rname, value.rootpath);
							if(value){
						//var data={value.id, value.path, value.rname, value.rootpath};
				       	$scope.$broadcast('DTtoggleSearchSelection',{id:value.id,path:value.path,name:value.rname,rootpath:value.rootpath});
					}
                });
                if ($window.localStorage.getItem("campaignAudienceplacementsValues")) {
                    if ($window.localStorage.getItem("campaignAudienceplacementsValues").length > 0) {
                        $scope.placementsValues = $window.localStorage.getItem("campaignAudienceplacementsValues").split(',');
                         $scope.placementsData.placementsValues = $window.localStorage.getItem("campaignAudienceplacementsValues").split(',');
                        $window.localStorage.setItem("campaignAudienceplacementsValues", $scope.placementsValues);
						 $scope.$broadcast('placementsData',{id:"placements",value:$scope.placementsData});

                    }
					if($scope.placementsValues.indexOf("mobilenewsfeed")>-1){
						$scope.mobileView = true;
                        $scope.placementsData.mobileView = true;
						$scope.campaignAudienceMobileDevice = $window.localStorage.getItem("campaignAudienceMobileDevice");
                        $scope.placementsData.campaignAudienceMobileDevice = $window.localStorage.getItem("campaignAudienceMobileDevice");
						 $scope.$broadcast('placementsData',{id:"mobileView",value:$scope.placementsData});
					}
						
                }

                if ($window.localStorage.getItem("campaignAudienceLocationsArr")) {
                    if ($window.localStorage.getItem("campaignAudienceLocationsArr").length > 0) {
                        $scope.mapLocation = true;
                        $scope.campaignAudienceLocationsArr = $window.localStorage.getItem("campaignAudienceLocationsArr").split(',');
                        $scope.regionArray = JSON.parse($window.localStorage.getItem("regionArray"));
                        $scope.countryArray = JSON.parse($window.localStorage.getItem("countryArray"));
                        $scope.cityArray = JSON.parse($window.localStorage.getItem("cityArray"));
						$scope.locationData.mapLocation = true;
						$scope.locationData.campaignAudienceLocationsArr = $window.localStorage.getItem("campaignAudienceLocationsArr").split(',');
						$scope.locationData.regionArray = $window.localStorage.getItem("regionArray");
						$scope.locationData.countryArray = $window.localStorage.getItem("countryArray");
						$scope.locationData.cityArray = $window.localStorage.getItem("cityArray");
						$scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});
                    }
                }
                if ($window.localStorage.getItem("campaignAudienceLanguageArr")) {
                    if ($window.localStorage.getItem("campaignAudienceLanguageArr").length > 0) {
                        $scope.campaignAudienceLanguageArr = $window.localStorage.getItem("campaignAudienceLanguageArr").split(',');
						$scope.languageData.campaignAudienceLanguageArr = $window.localStorage.getItem("campaignAudienceLanguageArr").split(',');
                        $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
                    }
					$scope.$broadcast('languageData',{id:"languageData",value:$scope.languageData});
                }
                if ($window.localStorage.getItem("campaignAudienceLocationTarget")) {
                    $scope.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget");
					$scope.locationData.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget");
                    $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
					$scope.$broadcast('locationData',{id:"locationData",value:$scope.locationData});
                }

            }
            if ($window.localStorage.getItem("campaignAudienceMobileDevice")) {
                $scope.campaignAudienceMobileDevice = $window.localStorage.getItem("campaignAudienceMobileDevice");
                  $scope.placementsData.campaignAudienceMobileDevice = $window.localStorage.getItem("campaignAudienceMobileDevice");
				 $scope.$broadcast('placementsData',{id:"mobileData",value:$scope.placementsData.campaignAudienceMobileDevice});
            }
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            angular.element('#step3').css('background-color', '#95D2B1');
            $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});

        };

        $scope.getEditAdsetDetails = function () {

            if ($scope.promotionObjective != 'no') {
                try {
                    $scope.getAdCreativeForEdit();
                } catch (err) {
                    console.log('error on promotive objective' + err);
                }
            }
            ;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var querystr = "?adCampaignId=" + $window.localStorage.getItem("campaignId") + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
            facebookGetPost.readadset(querystr, headers).then(function (response) {
                console.log(response);
                if (response.data.appStatus == 0) {

                    if (response.data.adsets.length > 1) {
                        $scope.editAdsetErrorMsg = 'block';
                        $scope.errorpopupHeading = 'Adset Error';
                        $scope.errorMsg = 'Please try again as there has been an error in AdSet Creation. If the error persists, please contact CAdConciergeSupport@cognizant.com';
                    } else {
                        $scope.prePopulateValues(response.data);
                    }
                } else {
                    $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $scope.showErrorPopup(response);
                    }
                }
            });

        };

        $scope.init();

        $scope.countryArray = [];
        $scope.regionArray = [];
        $scope.cityArray = [];


        $scope.$watch('campaignAudienceCampaignTarget', function (newVal, oldVal) {
            //alert(newVal);
            if (newVal != 'undefined' && newVal != '' && newVal != 'null' && newVal != undefined && newVal != null) {
                // angular.element('#step2').css('background-color', '#95D2B1');
                //$rootScope.freezeFlag = true;
                //$rootScope.overLayAudience = true;
            } else {
                // angular.element('#step2').css('background-color', '#C2C2C2');
            }
        }, true);

        $scope.$watch('campaignAudienceDetailedTargeting', function (newVal, oldVal) {
            console.log(newVal);
            $window.localStorage.setItem("campaignaudienceDetailedTargeting", newVal);
        }, true);




        $scope.searchBy = function (item) {

            if ($scope.campaignAudienceDetailedTargetingSearch == undefined) {
                return true;
            } else {
                if (item.name.toLowerCase().indexOf($scope.campaignAudienceDetailedTargetingSearch.toLowerCase()) != -1) {
                    return true;
                }
            }
            return false;
        };


        $scope.campaignAudienceMoreDTJSON = [];
        $scope.MobileKey = [];
        var camR = {};

        function capitalizeString(inputString) {
            return inputString.substring(0, 1).toUpperCase() + inputString.substring(1);
        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
            $rootScope.freezeFlag = false;
        }
        $scope.moveNextStep = function () {
            $rootScope.campaignSteps[1] = true;
            $state.go('app.dynamnicbypcampaignplan');
        }

        $scope.sendcampaignAudienceConnection = function (campaignAudienceConnection) {
            $scope.campaignAudienceConnection = campaignAudienceConnection;
            $window.localStorage.setItem("campaignAudienceConnection", $scope.campaignAudienceConnection);
            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
        }

        $scope.sendcampaignAudienceCampaignOffer = function (campaignAudienceCampaignOffer) {
            $scope.campaignAudienceCampaignOffer = campaignAudienceCampaignOffer;
            $window.localStorage.setItem("campaignAudienceCampaignOffer", $scope.campaignAudienceCampaignOffer);
            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
        }

        $scope.sendcampaignAudienceCampaignConversionPixel = function (campaignAudienceCampaignConversionPixel) {
            $scope.campaignAudienceCampaignConversionPixel = campaignAudienceCampaignConversionPixel;
            $window.localStorage.setItem("campaignAudienceCampaignConversionPixel", $scope.campaignAudienceCampaignConversionPixel);
            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
        }

        $scope.sendcampaignAudienceCampaignTarget = function (campaignAudienceCampaignTarget) {
            $scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
            if ($window.localStorage.getItem("marketingObjective") == 'OFFER_CLAIMS') {
                $scope.campaignAudienceCampaignOfferArr = [];
                $scope.campaignAudienceCampaignOffer = '';
                $scope.getPageOffers();
            }

            if ($scope.campaignAudienceCampaignTarget == "")
            {
                angular.element('#step1').css('background-color', '#c2c2c2');
                angular.element('#mandatory').addClass("mandatory");
            } else
            {
                angular.element('#step1').css('background-color', '#95D2B1');
                angular.element('#mandatory').removeClass("mandatory");
            }

        }

        $scope.campaignAudienceLocationsJSON = [];
        $scope.campaignAudienceGenderValue = [];
        $scope.campaignAudienceLocationTargetValue = [];

        function hasSubjectID(object, key) {
            return object ? hasOwnProperty.call(object, key) : false;
        }

        $scope.createCampaignAudience = function (locationData,ageData,genderData,detaileddata,languageData,placementsData) {
       console.log(locationData);
	     console.log(ageData);
		   console.log(genderData);
		     console.log(detaileddata);
			   console.log(languageData);
			     console.log(placementsData);
            if ($window.localStorage.getItem("campaignAudienceGender") == 'all') {
                $scope.campaignAudienceGenderValue.push();
            } else if ($window.localStorage.getItem("campaignAudienceGender") == 'men') {
                $scope.campaignAudienceGenderValue.push('1');
            } else if ($window.localStorage.getItem("campaignAudienceGender") == 'women') {
                $scope.campaignAudienceGenderValue.push('2');
            }
            if (locationData.campaignAudienceLocationTarget != '') {
                if (locationData.campaignAudienceLocationTarget == 'everyone') {
                    $scope.campaignAudienceLocationTargetValue.push();
                } else {
                    $scope.campaignAudienceLocationTargetValue.push(locationData.campaignAudienceLocationTarget);
                }
            }

            var mobileParameter = '';
            $scope.MobileTypes = [];


            if (placementsData.campaignAudienceMobileDevice != '' && placementsData.campaignAudienceMobileDevice != null && placementsData.campaignAudienceMobileDevice != undefined) {
                var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                    return d.name === placementsData.campaignAudienceMobileDevice;
                })[0];
                var isSubjectId = hasSubjectID(sobject, 'id');
                if (isSubjectId == true) {
                    if (sobject.id == 'Android' || sobject.id == 'iOS') {
                        mobileParameter = 'user_os';
                        $scope.MobileTypes.push(sobject.id);
                    } else if (sobject.id == 'Feature_Phone') {
                        mobileParameter = 'user_device';
                        $scope.MobileTypes.push(sobject.id);
                    } else {
                        mobileParameter = 'user_device';
                        $scope.MobileTypes.push();
                    }
                }
            }

            if (mobileParameter != '' && mobileParameter != null && mobileParameter != undefined) {

                $scope.campaignAudienceLocationsJSON = {
                    "age_min": ageData.campaignAudienceAgeFrom,
                    "age_max":ageData.campaignAudienceAgeTo,
                    "geo_locations": {
                        "countries":locationData.countryArray,
                        "regions":locationData.regionArray,
                        "cities": locationData.cityArray,
                        "location_types": $scope.campaignAudienceLocationTargetValue
                    },
                    "genders": $scope.campaignAudienceGenderValue,
                    [mobileParameter]: $scope.MobileTypes
                };
            } else {
                $scope.campaignAudienceLocationsJSON = {
                    "age_min":ageData.campaignAudienceAgeFrom,
                    "age_max": ageData.campaignAudienceAgeTo,
                    "geo_locations": {
                        "countries": locationData.countryArray,
                        "regions": locationData.regionArray,
                        "cities": locationData.cityArray,
                        "location_types": $scope.campaignAudienceLocationTargetValue
                    },
                    "genders": $scope.campaignAudienceGenderValue
                };
            }

            //LOOPING FOR DETAIL TARGETING
            var camR = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camR[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in detaileddata.campaignAudienceDTJSON) {
                camR[key] = detaileddata.campaignAudienceDTJSON[key];
            }
            $scope.campaignAudienceLocationsJSON = camR;


            $scope.device_platforms = [];
            $scope.facebook_positions = [];
            $scope.publisher_platforms = [];
            $scope.instagram_positions = [];


            angular.forEach(placementsData.placementsValues, function (val, key) {
               // $scope.setPlacements(val);
                 $scope.$broadcast('placementsData',{id:"setPlacements",value:val});
            });


            //LOOPING FOR PLACEMENT
            var camP = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camP[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in placementsData.placementsKeyValues) {
                camP[key] = placementsData.placementsKeyValues[key];
            }
            $scope.campaignAudienceLocationsJSON = camP;


            //LOOPING FOR LANGUAGE
            var camL = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camL[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in languageData.LanguageKeyValues) {
                camL[key] = languageData.LanguageKeyValues[key];
            }
            $scope.campaignAudienceLocationsJSON = camL;

            if ($scope.campaignAudiencePlacementsWiFi) {
                var wifiL = {};
                for (var key in $scope.campaignAudienceLocationsJSON) {
                    wifiL[key] = $scope.campaignAudienceLocationsJSON[key];
                }
                for (var key in $scope.wifiArr) {
                    wifiL[key] = $scope.wifiArr[key];
                }
                $scope.campaignAudienceLocationsJSON = wifiL;
            }
            $scope.getAndSaveCampaignData();

        };

        $scope.getAndSaveCampaignData = function () {
            var campaignDetails = $window.localStorage.getItem("campaignId");
            if (campaignDetails == undefined) {
                var campaignId = $rootScope.campaignId;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&adCampaignId=" + campaignId;
                facebookGetPost.readadcampaign(queryStr, headers).then(function (response) {
                    console.log(response);
                    if (response.data.appStatus == '0') {
                        campaignDetails = response.data.adcampaigns;
                        $scope.appendAudienceData();
                    } else {
                        $scope.$broadcast('progressloaderdata',{id:"progressloaderdata", value:"none"});
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $scope.showErrorPopup(response);
                        }

                    }

                })

            } else {
                $scope.appendAudienceData();
            }

        }

        $scope.appendAudienceData = function () {

            var campaignDetails = $window.localStorage.getItem("campaignId");
            if ($scope.campaignAudienceCampaignTarget != 'undefined' && $scope.campaignAudienceCampaignTarget != '' && $scope.campaignAudienceCampaignTarget != null && $scope.campaignAudienceCampaignTarget != 'null') {
                if ($scope.campaignAudienceCampaignTargetArr != 'undefined' && $scope.campaignAudienceCampaignTargetArr != '' && $scope.campaignAudienceCampaignTargetArr != null && $scope.campaignAudienceCampaignTargetArr != 'null') {
                    var sobj = $filter('filter')($scope.campaignAudienceCampaignTargetArr, function (d) {
                        return d.id === $scope.campaignAudienceCampaignTarget;
                    }, true)[0];
                    $scope.hdcampaignAudienceCampaignTargetName = sobj.name;
                }
            }
            $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
            $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
            $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);
            $window.localStorage.setItem("campaignAudienceLanguage", $scope.campaignAudienceLanguage);
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $window.localStorage.setItem("hdcampaignAudienceCampaignTargetName", $scope.hdcampaignAudienceCampaignTargetName);            
            $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
            $window.localStorage.setItem("campaignAudienceLocationsJSON", JSON.stringify($scope.campaignAudienceLocationsJSON));
            $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);
            $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
            $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
			
            $window.localStorage.setItem("campaignAudienceDTJSON", JSON.stringify($scope.campaignAudienceDTJSON));
            $window.localStorage.setItem("campaignAudienceDTselection", JSON.stringify($scope.DTselection));
            $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);

            var obj = {
                "campaignAudienceLanguageKey": $scope.campaignAudienceLanguageKey,
                "campaignAudienceLocationTarget": $window.localStorage.getItem("campaignAudienceLocationTarget"),
                "campaignAudienceTarget": $scope.campaignAudienceCampaignTarget,
                "campaignAudienceTargetType": $window.localStorage.getItem("campaignAudienceTargetType"),
                "campaignAudienceLocationsArr": $scope.campaignAudienceLocationsArr,
                "campaignAudienceLocationsJSON": JSON.stringify($scope.campaignAudienceLocationsJSON),
                "campaignAudienceLocationType": $scope.campaignAudienceLocationType,
                "campaignAudienceAgeFrom": $scope.campaignAudienceAgeFrom,
                "campaignAudienceAgeTo": $scope.campaignAudienceAgeTo,
                "campaignAudienceGender": $scope.campaignAudienceGender,
                "campaignAudienceLanguage": $scope.campaignAudienceLanguage,
                "campaignAudienceplacementsValues": $window.localStorage.getItem("campaignAudienceplacementsValues"),
                "campaignAudienceDTJSON": JSON.stringify($scope.campaignAudienceDTJSON),
                "campaignAudienceMobileDevice": $window.localStorage.getItem("campaignAudienceMobileDevice")
            }
            var campaignResult = {};
            for (var key in campaignDetails.data) {
                campaignResult[key] = campaignDetails.data[key]
            }
            for (var key in obj) {
                campaignResult[key] = obj[key];
            }
            globalData.setLocal("campaign", $window.localStorage.getItem("campaignId"), campaignResult);
            $rootScope.freezeFlag = false;
            $scope.moveNextStep();

        }



        $('.with-access').keyup(function (e) {
            var code = (e.keyCode ? e.keyCode : e.which);
            console.log(code);
            switch (code) {
                case 65: // a
                    $('#all').prop('checked', true);
                    break;
                case 77: // m
                    $('#men').prop('checked', true);
                    break;
                case 87: // w
                    $('#women').prop('checked', true);
                    break;
            }
        });
    }]);

app.directive('setConnector', function () {
    return {
        restrict: 'A',
        replace: false,
        template: '',
        link: function ($scope) {
            $scope.$emit('details-loaded');
        }
    }
});