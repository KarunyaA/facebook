var dynamicForm=angular.module('app',['replicator','dashboard']); 
dynamicForm.controller("dynamnicbypcampaigncreativeController", ['$rootScope', '$scope', '$http', '$q', '$state', '$location', 'dashboardService', 'apiService', 'Flash', '$window', 'appSettings', '$sce', '$timeout', 'globalData', '$animate', '$filter', 'facebookGetPost',
    function ($rootScope, $scope, $http, $q, $state, $location, dashboardService, apiService, Flash, $window, appSettings, $sce, $timeout, globalData, $animate, $filter, facebookGetPost) {

   $scope.PostIdOption = true;
        $scope.myInterval = 500;
        $scope.imgthumbnaildiv = false;
        $scope.vidthumbnaildiv = false;
        $scope.previewing = false;
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        var apiTPBase = appSettings.apiTPBase;
        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
        $scope.fourthActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.browseImgSuccessMsg = "none";
        $scope.browselibrary = "none";
        $scope.browselibraryvideos = "none";
        $scope.mainLoader = "none";
        $scope.errTextMsg = "none";
        $scope.errHeadlineTextMsg = "none";
        $scope.errLandingviewTextMsg = "none";
        $scope.uniqueArray = [];
        $scope.uniqueImageSelectionArray = [];
        $scope.campaignAudienceCampaignOfferArr = [];
        $scope.textBodyContent = "";
        $scope.campaignHeadline = "";
        $scope.cardHeadline = "";
        $scope.cardDescription = "";
        $scope.cardwebURL = "";
        $scope.campaignLandingView = "Timeline";
        $scope.hashVal = "";
        $scope.imagesSource = "";
        $scope.objectType = 'PHOTO';
        $scope.networkErrorPopup = "none";
        $scope.slideShowCreate = true;
        $scope.advertCarousel = false;
        $scope.advertSingleImg = false;
        $scope.advertSingleVideo = false;
        $scope.advertSlideshow = false;
        $scope.step2_green = false;
        $scope.valAddWebsiteUrl = false;
        $scope.isHeadline = false;
        $scope.isCreateShowAdvOption = false;
        $scope.editAdsetErrorMsg = 'none';
        $scope.isCarousaltrafficText = false;
        $scope.campaignAudienceCampaignTargetLoader = true;
        $scope.campaignAudienceLandingViewLoader = false;
        //	$scope.deleteSuccessFlag = true;
        /*Carousel advent*/
        $scope.carouseladvent1 = true;
        $scope.showImgPrev = [];
        $scope.showVideoPrev = [];
        $scope.carouseladventEdit2 = false;
        $scope.carouseladventEdit3 = false;
        $scope.carouseladventEdit4 = false;
        $scope.carouseladventEdit5 = false;
        $scope.carouseladventEdit6 = false;
        $scope.carouseladventEdit7 = false;
        $scope.carouseladventEdit8 = false;
        $scope.carouseladventEdit9 = false;

        $scope.selectedImagegalleryArray = [];
        $scope.selectedImagegalleryArrayVideo = [];
        $scope.headlinecontents = [];
        $scope.descriptioncontents = [];
        $scope.weburlcontents = [];
        $scope.mediaImage = true;
        $scope.mediaVideo = true;
        $scope.carouseladvent = false;
        $scope.imageFormat = "imagemediaUpdate";
        $scope.imagePreviewSrc = "";
        $scope.imagePreviewVideoSrc = "";
        //$scope.showVideoPrev = false;
        //$scope.showImgPrev = false;
        //$scope.imageFormat1 = "videomediaUpdate";
        $scope.mediaarrow = true;
        $scope.previewing = false;
        $scope.counter = 1;
        $scope.isPixelTracking = false;
        $scope.isOfflineTracking = false;
        /*use Exist Post - start */
        $scope.existURLParam = false;
        $scope.exitShowAdvOption = true;
        $scope.exitHideAdvOption = false;
        $scope.selectedTarget = "";
        /*use Exist Post - end*/

        $scope.fbAccessToken = "";
        $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
        // $scope.marketingObjective = "LEAD_GENERATION";

        $scope.desktop = false;
        $scope.mobile = false;
        $scope.rightColumn = false;
        $scope.isLeadGen = false;

        // $scope.callToDirectionValue = 0;
        $scope.adminUserRole = false;
        $scope.accordianRole = false;
        $scope.webURL = "";
        $scope.adData = "";
        $scope.campaignEventLoader = false;
        $scope.uploadstep = '2';
        $scope.previewstep = '3';
        $scope.pageTabs = [];
        $scope.formatSelected = "";
		$scope.connectFBVal =[];
		$scope.fbadvertFormat = "";
		$scope.fielddata = {
					fbadvertFormat:"",
					campaignAudienceCampaignTarget:"",
					selectedTarget:"",
					textBodyContent:"",
					radioDestination:"",
					messengertextBodyContent:"",
					campaignWebURL:"",
					campaignHeadline1:"",
					learnMoreUrl:"",
					seeMoreUrl:"",
					displayURLoptional:"",
					deepLink:"",
					valAddWebsiteUrl:"",
					webURL:"",
					displayLink:"",
					campaignHeadline:"",
					newsfeedlinkdesc:"",
					callToDirectionValue:"",
					pixelTracking:"",
					campaignURLParameter:"",
					campaignLandingView:""					
				}

				
		$scope.getAdCreativeIdFromFaceBook = function () {
            var adId = $window.localStorage.getItem("adId");
            //var queryStr = adId + "?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&fields=creative";
			var queryStr = "?adId=" + adId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            facebookGetPost.getcreativeid(queryStr).then(function (response) {
				var resp =response.data.ads;
				angular.forEach(resp, function(val,key)
				{
					angular.forEach(val, function(val1,key1)
					{
					console.log(val[key1]);
					console.log(val1);
					$window.localStorage.setItem("adCreativeId", val1.creative.id);
					});
				});
				 var adCreativeId = $window.localStorage.getItem("adCreativeId");
				 if(adCreativeId){
						$scope.getAdCreativeForEdit();	 
				 }
				 
               /* if (response.data.creative.id) {// success
                    $window.localStorage.setItem("adCreativeId", response.data.creative.id)
                    $scope.getAdCreativeForEdit();
                }*/
            })
        }


        $scope.getAdCreativeForEdit = function () {
            var adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $rootScope.progressLoader = "block";

            facebookGetPost.getadcreative(queryStr, headers).then(function (response) {
                if (response.data.fbAdCreativeResponse.id) {
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    //angular.element($('.accordianRole').prop('disabled', false));
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green = true;
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
                    $scope.setLine();
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                } else {
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    //angular.element($('.accordianRole').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }
                if (response.data.appStatus == 0) {// success
				    $scope.$broadcast('previewsection');
                    //$scope.desktopCreativePreview();
                    //$scope.mobileCreativePreview();
                  //  $scope.rightColumnCreativePreview();
                    $scope.adCreativeDetails = response.data.fbAdCreativeResponse;

                    if (response.data.fbAdCreativeResponse.object_type == 'VIDEO') {
                        $scope.formatSelected = 'fbsinglevideo';
                    } else if (response.data.fbAdCreativeResponse.object_type == 'SHARE') {
                        if (response.data.fbAdCreativeResponse.object_story_spec.link_data.hasOwnProperty("child_attachments")) {
                            $scope.formatSelected = 'fbcarosel';
                        } else {
                            $scope.formatSelected = 'fbsingleimage';
                        }
                    } else if (response.data.fbAdCreativeResponse.object_type == 'PHOTO') {
                        $scope.formatSelected = 'fbsingleimage';
                    }
					  $window.localStorage.setItem("formatSelected", $scope.formatSelected);
                    $scope.advertypeforEdit = response.data.fbAdCreativeResponse.object_type;
                    if ($scope.adCreativeDetails.url_tags) {
                        $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                    }

                    if (typeof (response.data.fbAdCreativeResponse.object_story_spec) != "undefined") {
                        if (typeof (response.data.fbAdCreativeResponse.object_story_spec.video_data) != "undefined") {
                            $scope.advertypeforEdit = 'VIDEO';
                        }
                    }
                    $rootScope.progressLoader = "none";
                    $scope.mainLoader = "none";
                    //angular.element($('.cards-content .imgprv').css("visibility", "visible"));
                    //console.log($scope.adCreativeDetails.object_story_spec.link_data.child_attachments);

                    if ($scope.advertypeforEdit == "VIDEO") {
                        $scope.fbadvertFormat = "fbsinglevideo";
                        $rootScope.progressLoader = "none";
                    } else if ($scope.advertypeforEdit == "PHOTO" || $scope.advertypeforEdit == "PAGE") {
                        $scope.fbadvertFormat = "fbsingleimage";
                        $rootScope.progressLoader = "none";

                    } else if ($scope.advertypeforEdit == "SHARE") {
                        $scope.fbadvertFormat = "fbsingleimage";
                        $rootScope.progressLoader = "none";

                    } else if ($scope.advertypeforEdit == "SLIDESHOW") {
                        $scope.fbadvertFormat = "fbslideshow";
                        $rootScope.progressLoader = "none";

                    }
				$scope.fielddata.fbadvertFormat = $scope.fbadvertFormat;				
				 $window.localStorage.setItem("fbadvertFormat",$scope.fbadvertFormat);
                    if ($scope.fbadvertFormat == "fbsingleimage") {
                        $scope.thumbnail = response.data.fbAdCreativeResponse.thumbnail_url;
                        $scope.thumbnailVideo = "images/campaign/single-video.png";
                        $scope.thumbnailCarousel = "images/campaign/carousel.svg";
                        $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.imgthumbnaildiv = true;
                    } else if ($scope.fbadvertFormat == "fbsinglevideo") {
                        $scope.thumbnailVideo = response.data.fbAdCreativeResponse.thumbnail_url;
                        $scope.thumbnail = "images/campaign/single-image.png";
                        $scope.thumbnailCarousel = "images/campaign/carousel.svg";
                        $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.vidthumbnaildiv = true;
                    } else if ($scope.fbadvertFormat == "fbslideshow") {
                        $scope.thumbnailVideo = "images/campaign/single-video.png";
                        $scope.thumbnail = "images/campaign/single-image.png";
                        $scope.thumbnailSlideshow = response.data.fbAdCreativeResponse.thumbnail_url;
                        $scope.thumbnailCarousel = "images/campaign/carousel.svg";

                    }

                    if ($scope.marketingObjective == "POST_ENGAGEMENT") {
                        if ($scope.adCreativeDetails.object_story_spec) {
                           // $scope.textBodyContent = $scope.adCreativeDetails.body; //$window.localStorage.getItem("textBodyContent"); 
                           // $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							//$scope.fielddata.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							//$scope.fielddata.textBodyContent =  $scope.adCreativeDetails.body;
							 $scope.$broadcast('creativeimage',{id:"creativeData",objective:$scope.marketingObjective,value:$scope.adCreativeDetails});                         
                        }
                    }


                } else {
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $scope.showErrorPopup(response);
                    }
                }
            });
        }
        $scope.getAdForEdit = function () {
            var queryStr = "?adsetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            facebookGetPost.readaddata(queryStr, headers).then(function (response) {
                //console.log(response.data.ads);
                if (response.data.appStatus == '0') {// success
                    angular.forEach(response.data.ads, function (value, key) {
                        var JsonObj = response.data.ads[key];
                        //console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                //$scope.adCreativeDetails(array[+i]);
                            }
                        }
                    });
                } else {
                    $rootScope.progressLoader = "none";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $scope.showErrorPopup(response);
                    }
                }
            });
        }
		       $scope.setLine = function () {
                var everythingLoaded = setInterval(function () {
                    if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                        $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                        $scope.ssValue = angular.element(document.getElementById('step2')).offset().top;
                        $scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                        var offsetHeight3 = document.getElementById('step3container').offsetHeight;
                        var fStep = $(".vr");
                        fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));

                    }
                }, 10);
            };
			
	    $scope.path = "../CNAP_UI_Repo/";
		$scope.pageContent={};
		$scope.stepTitleContent={};
	   

		$scope.fetchData = function(details){			
			angular.forEach(details, function (val, key){
				var JsonObj= details[key].fieldset.fields;
				$scope.config = details[key].fieldset.fields;
				   var array = [];
				 // console.log(JsonObj);
				for (var i in JsonObj) {				
					if (JsonObj.hasOwnProperty(i)) {
						array[+i] = JsonObj[i];
						$scope.pageContent[i] = array[+i];
					//	console.log($scope.pageContent[i]);
						//traverse(JsonObj[i],process);
					}
				}				  
			});			
            $window.localStorage.setItem("fbadvertFormat",$scope.fbadvertFormat);
            $scope.connectFBVal1 = $window.localStorage.getItem("pageCampaignTargetArr");
           // $scope.connectFBVal = "";
            $scope.campaignAudienceTargetType = $window.localStorage.getItem("campaignAudienceTargetType");         
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");        
            if ($scope.campaignPromateURL != "" && $scope.campaignPromateURL != "undefined" && $scope.campaignPromateURL != null) {
                $scope.selectedTarget = "";
            }
            $scope.campaignPromateURL = $window.localStorage.getItem("hdcampaignAudienceCampaignTargetName");
            angular.element($('.btnCampaignCreative').prop('disabled', true));            
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            $scope.previewSection();         
            $scope.checkPreview();
            var campaignState = $window.localStorage.getItem("campaignState");
            $scope.campState = $window.localStorage.getItem("campaignState");           
            if (campaignState == "create") {
				 angular.element('#step1').css('background-color', '#C2C2C2');
				$scope.fbadvertFormat = "fbsingleimage";
                $scope.thumbnail = "images/campaign/single-image.png";
                $scope.thumbnailVideo = "images/campaign/single-video.png";
                $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
            }
            if (campaignState == "edit") {
                if($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;
                }else{
                    $scope.adminUserRole = false;
                }
                $scope.textBodyContent = $window.localStorage.getItem("textBodyContent");
                $scope.selectedTarget = $window.localStorage.getItem("selectedTarget");
                $scope.getAdCreativeIdFromFaceBook();
            }
            $scope.setLine();
            $scope.setFixLine = function () {
                var everythingLoaded = setInterval(function () {
                    if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                        $scope.exfsValue = angular.element(document.getElementById('existingStep1')).offset().top;
                        $scope.exssValue = angular.element(document.getElementById('existingStep2')).offset().top;
                        var exStep = $(".vline");
                        exStep.css('height', (($scope.exssValue - $scope.exfsValue)));
                    }
                }, 10);
            };
            $scope.imagePreviewSrc = [];
            $scope.imagePreviewVideoSrc = [];
		}

	  $scope.loadLocalJson = function(){
			 $http.get($scope.path + "app/modules/dynamicforms/data/boostyourposts/creative-form.json").success(function (data){
				var details = data.creativeDetails;
				$scope.pageContent=data.creativeDetails;
				$scope.fetchData(details);
				angular.forEach(details, function (val, key){
				   $scope['step'+(key+1)]= details[key];
				   console.log($scope['step'+(key+1)]);
				  
				});
			}); 
	/* 		var xmlPath =$scope.path + "app/modules/dynamicforms/data/details-form.xml"
			$http.get(xmlPath,  
			{  
				transformResponse: function(cnv)  
				{  
					var x2js = new X2JS();  
					var aftCnv = x2js.xml_str2json(cnv);  
					return aftCnv;  
				}  
			}).success(function(response)  
			{  
				console.log(response.root.campaignDetails);  
				var details = response.root.campaignDetails;
				$scope.pageContent= response.root.campaignDetails;
				$scope.fetchData(details);
				angular.forEach(details, function (val, key){
				   $scope['step'+(key+1)]= details[key];				   
				   $scope.setLine();
				});				
			});  */ 			
		} 		
		function process(key,value) {		
			$scope.data[key] = value;
			//console.log($scope.data);
			$scope.stepTitleContent[key] = value;
		}
		function traverse(o,func) {
			for (var i in o) {
				func.apply(this,[i,o[i]]);  
				if (o[i] !== null && typeof(o[i])=="object") {
					//going one step down in the object tree!!
					traverse(o[i],func);
				}
			}			
		}
		$scope.$on('content', function () {
            alert('sdfsd');
			console.log($scope.pageContent[i])
        });
				
    $scope.init = function () {

            angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
            console.log(angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle"));
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
            $rootScope.freezeFlag = false;
            $rootScope.overLayAudience = false;
            $rootScope.step = 4;
            if ($rootScope.campaignSteps[3] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }
            $scope.loadLocalJson();
			 $scope.setLine();
        }


        $scope.sendcampaignAudienceCampaignTarget = function (campaignAudienceCampaignTarget) {
            $scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $rootScope.freezeFlag = true;
        }

       

        $scope.getExistingPost = function (pageId) {

            $scope.existingPostArr = [{
                    id: 1,
                    name: "dummydataFacebook",
                    picture: "",
                    permalink_url: "",
                    type: ""
                }, {
                    id: 2,
                    name: "dummydataTwitter",
                    picture: "",
                    permalink_url: "",
                    type: ""
                }];
            $scope.selectedPostPage = '';
            var pageObj = $filter('filter')($scope.connectFBVal, function (d) {
                return d.id == pageId;
            })[0];

            $scope.selectedPostPageLoader = true;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&pageId=" + pageId + "&pageAccessToken=" + pageObj.access_token;

            facebookGetPost.getpagefeed(queryStr, headers).then(function (response) {
                //console.log(response);
                $scope.selectedPostPageLoader = false;
                angular.forEach(response.feedsInPage, function (val, key) {
                    var JsonObj = response.feedsInPage[key];
                    angular.forEach(JsonObj, function (v, k) {
                        angular.forEach(v.story_tags, function (vv, kk) {
                            if (vv.id != pageId && v.type == 'page') {
                                var ExistingObj =
                                        {
                                            id: vv.id,
                                            name: vv.name,
                                            picture: v.picture,
                                            permalink_url: v.permalink_url,
                                            type: v.type
                                        }
                                $scope.existingPostArr.push(ExistingObj);
                            }
                        });
                    });
                });
            })
        }

        $scope.showExistingPost = function () {
            console.log($scope.existingPostArr);

            $scope.existingpost = true;
            var selectExistingPopup = $(".exisitingposterror");
            selectExistingPopup.show();
            angular.element($('body').css("overflow-y", "scroll"));
            var postObj = $filter('filter')($scope.existingPostArr, function (d) {
                return d.id == $scope.selectedPostPage;
            })[0];
            $scope.postHeading = postObj.name;
            $scope.postImage = postObj.picture;
            $scope.permalinkUrl = postObj.permalink_url;
            $scope.Error = "Error";
        }

        $scope.exisitingposterror = function ()
        {
            $scope.existingpost = false;
        }
        $scope.PostIdCancel = function ()
        {
            console.log("working fine")
            $scope.PostIdOption = true;
            $scope.postidtext = false;

        }
        $scope.PostIdSubmit = function ()
        {
            console.log("working fine")
            $scope.PostIdOption = true;
            $scope.postidtext = false;
            $scope.existingpost = true;
            var selectExistingPopup = $(".exisitingposterror");
            selectExistingPopup.show();
            $scope.Error = "Error";

        }
        $scope.PostIdOptionFun = function ()
        {

            $scope.PostIdOption = false;
            $scope.postidtext = true;

        }
        $scope.addExistingPost = function () {

            $scope.objectType = "SHARE";
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": $scope.networkAdAccountId,
                "objectType": $scope.objectType,
                "body": "test body",
                "name": "test name",
                "objectStoryId": $scope.selectedTarget + "_" + $scope.selectedPostPage
            };
            if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null) {
                var urlparams = {
                    "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({}, parameters, urlparams);
            }
            console.log(parameters);

            facebookGetPost.createadcreative("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {
                    $rootScope.progressLoader = "block";
                    $scope.adCreativeId = response.data.adCreativeId;

                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.hideExistingPost();
                    //$scope.createAd();
					$scope.$broadcast('uploadsection',{id:"createdAd"});
                    $scope.desktopCreativePreview_1();
                    $scope.mobileCreativePreview_1();
                    $scope.rightColumnCreativePreview_1();
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green = true;
                } else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                    $scope.showMediaErrorPopup(response);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }

            });

        }

        $scope.hideExistingPost = function () {
            $scope.showExistingPopup = false;
            angular.element($('body').css("overflow-y", "scroll"));
        }

        $scope.checkPreview = function () {

            var preview = $window.localStorage.getItem("campaignAudiencePlacementsValues");
            preview = "mobilenewsfeed,desktoprightcolumn,desktopnewsfeed";
            var arr = preview.split(',');
            angular.forEach(arr, function (value, key) {
                //console.log(arr[key])
                if (arr[key] == 'mobilenewsfeed') {
                    $scope.mobile = true;
                }
                if (arr[key] == 'desktoprightcolumn') {
                    $scope.rightColumn = true;
                }
                if (arr[key] == 'desktopnewsfeed') {
                    $scope.desktop = true;
                }
                if (arr[key] == 'instagram') {
                    $scope.instagramfeed = true;
                }
            });


            //mobilenewsfeed,desktoprightcolumn,desktopnewsfeed
        }


        $scope.fetChPreview = function () {
            var queryStr = "act_" + $scope.networkAdAccountId + "/generatepreviews?access_token=" + $rootScope.networkAccessToken;

            facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                //console.log(response);
            });
        }

        $scope.createnewadvert = true;
        $scope.useexisting = false;
        $scope.createid = function ()
        {
            var linkcr = document.getElementById("linkcr");
            linkcr.style.color = "#484848";
            var linkex = document.getElementById("linkex");
            linkex.style.color = " #094281";

            $scope.createnewadvert = true;
            $scope.useexisting = false;
            console.log("create id is working");
        }


        $scope.existingid = function ()
        {
            $scope.createnewadvert = false;
            $scope.useexisting = true;

            console.log("existing id is working");
            var linkcr = document.getElementById("linkcr");
            linkcr.style.color = "#094281";
            var linkex = document.getElementById("linkex");
            linkex.style.color = " #484848";

        }

        $scope.selectAdvertFormat = function (mode,value) {

            if (mode == 'insert') {
                $rootScope.freezeFlag = true;
                angular.element($('.btnCampaignCreative').prop('disabled', true));
                //angular.element($('.accordianRole').prop('disabled', true));							
                angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            } else {
                $rootScope.freezeFlag = false;
            }
			if(value != undefined){
			    $scope.fbadvertFormat = value;
                $window.localStorage.setItem("fbadvertFormat", $scope.fbadvertFormat);           
			}
         
            $scope.isCreateShowandHideOptionWrap1 = false;
            $scope.isPixelTracking = false;
            $scope.isOfflineTracking = false;
            $scope.isDeepLink = false;
				$scope.fielddata.fbadvertFormat = $scope.fbadvertFormat;				
				 $window.localStorage.setItem("fbadvertFormat",$scope.fbadvertFormat);
				$scope.formatSelected =  $window.localStorage.getItem("formatSelected");
            if ($scope.formatSelected == $scope.fbadvertFormat) {
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                //angular.element($('.accordianRole').prop('disabled', false));
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                if ($scope.formatSelected == 'fbsingleimage') {
                    $scope.imgthumbnaildiv = true;
                } else if ($scope.formatSelected == 'fbslideshow') {
                    $scope.slideShowSuccess = true;
                    $scope.slideShowCreate = false;
                } else {
                    $scope.vidthumbnaildiv = true;
                }
				$scope.$broadcast('uploadsection',{id:"thumbnailchange",image:$scope.imgthumbnaildiv,video:$scope.vidthumbnaildiv,slideshowcreate:$scope.slideShowCreate,slideshowsuccess:$scope.slideShowSuccess});

                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                $scope.step2_green = true;
				  angular.element('#step1').css('background-color', '#95D2B1');
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
				$scope.checkMandatoryVal();
            }
            else {
                $scope.imgthumbnaildiv = false;
                $scope.vidthumbnaildiv = false;
                $scope.slideShowSuccess = false;
                $scope.slideShowCreate = true;
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element('#step3').css('background-color', '#C2C2C2');
                angular.element('#collapseDesktop').removeClass('in');
                angular.element('#collapseTwo1').removeClass('in');
                angular.element('#collapseThree1').removeClass('in');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
				$scope.$broadcast('uploadsection',{id:"thumbnailchange",image:$scope.imgthumbnaildiv,video:$scope.vidthumbnaildiv,slideshowcreate:$scope.slideShowCreate,slideshowsuccess:$scope.slideShowSuccess});
				$scope.checkMandatoryVal();           
		   }
            switch ($scope.fbadvertFormat) {
                case "fbsingleimage": // Single image
					$scope.useExistingPostLink = true;
                    $scope.$broadcast('creativeimage',{id:"objective",objective:$scope.marketingObjective});

                    break;
                case "fbsinglevideo": // Single Video
					$scope.useExistingPostLink = true;
					$scope.$broadcast('creativevideo',{id:"objective",objective:$scope.marketingObjective});
					break;		

                case "fbslideshow":  // Slide show
                    $scope.useExistingPostLink = true;
					$scope.$broadcast('creativeslideshow',{id:"objective",objective:$scope.marketingObjective});
                    break;
            }

        }

        $scope.exitPostShowAdvanceOption = function () {
            $scope.existURLParam = true;
            $scope.exitShowAdvOption = false;
            $scope.exitHideAdvOption = true;
            $scope.setFixLine();
        }
        $scope.exitPostHideAdvanceOption = function () {
            $scope.existURLParam = false;
            $scope.exitShowAdvOption = true;
            $scope.exitHideAdvOption = false;
        }

        $scope.previewSection = function () {
            if ($scope.marketingObjective == "POST_ENGAGEMENT") {

                $scope.fbadvertFormat = "fbsingleimage";
                $scope.advertSingleImg = true;
                $scope.advertSingleVideo = true;
                $scope.advertSlideshow = true;
                $scope.selectAdvertFormat('defaultLoad');

            }
        }


        $scope.changeAdvertFormat = function () {
            // alert($scope.fbadvertFormat);
            //console.log($scope.fbadvertFormat);
        }
        $scope.init();
   
        $scope.$watchCollection(function () {
            if ($scope.frmCreateNewAdvert)
                return $scope.frmCreateNewAdvert;
        }, function () {
            if ($scope.frmCreateNewAdvert)
                if (($scope.frmCreateNewAdvert.$invalid == true))
                    $scope.inputTypeFile = false;
                else
                    $scope.inputTypeFile = true;
        }, true);


        $scope.inputTypeFile = false;



		
	$scope.showPreviewThumbnail = function(args){
		 if (args.fbadvertFormat == "fbsingleimage") {
                        $scope.thumbnail = args.thumbnail;
                        $scope.thumbnailVideo = args.thumbnailVideo;
                        $scope.thumbnailSlideshow =   args.thumbnailSlideshow;
                        $scope.thumbnailCarousel =  args.thumbnailCarousel;
                        $scope.imgthumbnaildiv =  args.imgthumbnaildiv;						
					} else if (args.fbadvertFormat == "fbsinglevideo") {
                        $scope.thumbnail = args.thumbnail;
                        $scope.thumbnailVideo = args.thumbnailVideo;
                        $scope.thumbnailCarousel =  args.thumbnailCarousel;
                        $scope.thumbnailSlideshow =  args.thumbnailSlideshow;
                        $scope.vidthumbnaildiv = args.vidthumbnaildiv; 				
                    } else if (args.fbadvertFormat == "fbslideshow") {
                        $scope.thumbnail = args.thumbnail;
                        $scope.thumbnailVideo = args.thumbnailVideo;
                        $scope.thumbnailSlideshow =  args.thumbnailSlideshow;
                        $scope.thumbnailCarousel = args.thumbnailCarousel;
                        $scope.slideShowCreate = args.slideShowCreate;
                        $scope.slideShowSuccess = args.slideShowSuccess;
                        $scope.slideShowPreview = args.slideShowPreview;
                    }
	}	
	$scope.previewSectionCalls = function(){
		$scope.$broadcast('previewsection');
	}
		
	    $scope.$on('imagefields',function(events,args){
			  if(args.id=="selectpromotable"){
				  $scope.connectFBVal = events.targetScope.connectFBVal;
				  $scope.selectPromotable(args.target);
			  }else if(args.id=="sendbodycontent"){
				  $scope.sendBodyContent(args.value);
			  }else if(args.id=="createadcreative"){
				  $scope.creativeAdCreative(args.value);		
			  }else if(args.id == "showerror"){
				  $scope.showErrorPopup(args.value);
			  }else if(args.id == "preview"){
				  $scope.previewSectionCalls();
			  }else if(args.id == "thumbnail"){
				  $scope.showPreviewThumbnail(args);
			  }else if(args.id == "setLine"){
				  $scope.setLine();
			  }			
		}); 
	
        $scope.desktopCreativePreview_1 = function () {

            if ($scope.selectedPostPage != '' && $scope.selectedPostPage != undefined && $scope.selectedPostPage != null) {
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "DESKTOP_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + $scope.adCreativeId + "&adFormat=" + $scope.previewCategory;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                var queryStr = "?" + $scope.facebookGraphCall;

                facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.progressLoaderPreveiw = "none";
                        $scope.RetryDesktopPreview = "none";
                        $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.desktopPreview1 = {src: $scope.embedSrcDesktop, title: "Desktop Preview"};
                    } else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }

        }

        $scope.mobileCreativePreview_1 = function () {

            if ($scope.selectedPostPage != '' && $scope.selectedPostPage != undefined && $scope.selectedPostPage != null) {
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "MOBILE_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
                var queryStr = $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;

                facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                        $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.mobilePreview1 = {src: $scope.embedSrcDesktop, title: "Mobile Preview"};
                    } else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }

        }

        $scope.rightColumnCreativePreview_1 = function () {

            if ($scope.selectedPostPage != '' && $scope.selectedPostPage != undefined && $scope.selectedPostPage != null) {
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "RIGHT_COLUMN_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
                var queryStr = $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;

                facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                    $scope.progressLoaderPreveiw = "none"
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                        $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.rightColumnPreview1 = {src: $scope.embedSrcDesktop, title: "Right Column Preview"};
                    } else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }

        }
 
        $scope.showErrorPopup = function (response) {
            if (response.hasOwnProperty("data"))
            {
                if (response.data.networkError)
                {
                    if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined)
                    {
                        $scope.popupTitle = response.data.networkError.error_user_title;
                        $scope.popupMessage = response.data.networkError.error_user_msg;
                    } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined)
                    {

                        $scope.popupTitle = "Error";
                        $scope.popupMessage = response.data.networkError.message;
                    }
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.data.errorMessage;
                }
            } else {
                if (response.networkError) {
                    if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                        $scope.popupTitle = response.networkError.error_user_title;
                        $scope.popupMessage = response.networkError.error_user_msg;
                    } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                        $scope.popupTitle = "Error";
                        $scope.popupMessage = response.networkError.message;
                    }
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.errorMessage;
                }

            }
            var modalApproveReq = $(".error_popup"); // Get the modal Approve req
            modalApproveReq.show();
        };
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }
        $scope.showSuccessPopup = function () {
            //console.log('success popup here123');
            $scope.popupTitle = "Assigning creative";
            $scope.popupMessage = "Ad created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show();

        }
        $scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            $scope.networkErrorPopup = 'none';
            successReq.hide();


        }
        $scope.showMediaErrorPopup = function (response) {

            if (response.data.networkError != '' && response.data.networkError != undefined) {
                if (response.data.networkError.error_user_title) {
                    $scope.popupTitle = response.data.networkError.error_user_title;
                    $scope.popupMessage = response.data.networkError.error_user_msg;
                } else {
                    $scope.popupTitle = 'Invalid Parameter';
                    $scope.popupMessage = response.data.errorMessage;
                }

            } else {
                $scope.popupTitle = 'Invalid Parameter';
                $scope.popupMessage = response.data.errorMessage;
            }
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }

        $scope.hidePopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".success_popup");
            modalApproveReq.hide();
        }

        $scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }


		
		$scope.checkMandatoryVal = function(){
			 if ($scope.selectedTarget != "" && $scope.selectedTarget != undefined && $scope.selectedTarget != null && $scope.textBodyContent != "" && $scope.textBodyContent != undefined && $scope.textBodyContent != null){
						angular.element('#step1').css('background-color', '#95D2B1');
						$scope.$broadcast('uploadsection',{id:"formvalidation",value:"validForm"});						
					}
					else{
						angular.element('#step1').css('background-color', '#C2C2C2');
						$scope.$broadcast('uploadsection',{id:"formvalidation",value:"invalidaForm"});					
					}
		}
         $scope.sendBodyContent = function (val) {
            $scope.textBodyContent = val;
			$scope.fielddata.textBodyContent=val;
            $scope.imgthumbnaildiv = false;
            $scope.vidthumbnaildiv = false;
            angular.element('#step2').css('background-color', '#C2C2C2');

            if ($scope.textBodyContent != null && $scope.textBodyContent != "" && $scope.textBodyContent != undefined)
            {
                angular.element('#textBodyContent').removeClass("mandatory");				
            } else
            {
                angular.element('#textBodyContent').addClass("mandatory");				
            }
            $window.localStorage.setItem("textBodyContent", $scope.textBodyContent);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            //angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; }*/
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
			$scope.checkMandatoryVal();

        };

		
		$scope.selectPromotable = function (pageId) {
            $scope.campaignAudienceCampaignTargetLoader = false;
            $scope.selectedTarget = pageId;
			$scope.fielddata.selectedTarget = pageId;
            //$scope.selectedTargetName = _name;
            if ($scope.selectedTarget != null && $scope.selectedTarget != "" && $scope.selectedTarget != undefined)
            {
                angular.element('#selectTargetObjective').removeClass("mandatory");				 
				angular.element('#step1').css('background-color', '#95D2B1');
            } else
            {
                angular.element('#selectTargetObjective').addClass("mandatory");
				angular.element('#step1').css('background-color', '#C2C2C2');
            }
            $window.localStorage.setItem("selectedTarget", $scope.selectedTarget);

            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            //angular.element($('.accordianRole').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please re-select image/video");

            $scope.getExistingPost(pageId);
			$scope.setLine();
			$scope.checkMandatoryVal();
        }
        $scope.saveAndProceedNextStep = function () {
            console.log("textBodyContent : " + $scope.textBodyContent);
            console.log("imagesSource : " + $scope.imagesSource);
            console.log("hashVal : " + $scope.hashVal);
            //  if(($scope.textBodyContent != "") && ($scope.imagesSource != "" || $scope.hashVal != "")){
            //angular.element($('.btnCampaignCreative').prop('disabled', false));
            $rootScope.freezeFlag = false;
            $rootScope.campaignSteps[3] = true;
            $rootScope.campaignSteps[4] = true;
            $state.go('app.dynamiccampaignsummary');
            /* }
             else{
             angular.element($('.btnCampaignCreative').prop('disabled', true));
             console.log("Please upload/browse image");
             }*/

        }
     
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }


        // Use Exist Post Services integration
        //$scope.fetchuserpromotablepages();
        $scope.promotableposts = function () {
            $http({
                method: 'GET',
                url: 'https://graph.facebook.com/585993311604680/promotable_posts?access_token=EAAJ4OaibPkYBAJVkRNZCKm1ZCuJZATHOaXJNz2TEvZAboSqlBjnsLdv0tZCTKON5ZBXe56y4hIDyOIxi8ulk4kIW5PypmTS1h06Imp3vj1gG3EPBu5LwAgzRGuJZBn87wS4Wf6ZCGIl2F8ZCbzxRlvDGOZAYJhYOUb32mJFUFFZC5mqSKQIJdcWZCnQe&limit=100&fields=name,description,link',
                /*headers: {
                 "userId": $window.localStorage.getItem("userId"),
                 "accessToken": $window.localStorage.getItem("accessToken")
                 }*/
            }).success(function (response) {
                console.log(response);

            }).error(function (error) {
                //alert(error);
            });
        }

        $scope.$on('details-loaded', function () {
            $scope.setLine();
        });



    }]);


//Directive code


dashboard.directive('compileHtml',
        function () {
            return {
                restrict: 'A',
                templateUrl: '../CNAP_UI_Repo/app/modules/dashboard/views/fbcreativecarousel-directive.html'
            };
        }
);

dashboard.directive('setConnector', function () {
    return {
        restrict: 'A',
        replace: false,
        template: '',
        link: function ($scope) {
            $scope.$emit('details-loaded');
        }
    }
});