dashboard.directive('gender',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
return{
	
	restrict:'E',
	templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/gender.html',	
	transclude:true,
	scope:{
		data:"="
	},
	link:function(scope,element,attr){

	scope.data = {
                    regionArray : [],
			countryArray:[],
			cityArray:[],
			campaignAudienceLocationsArr:[],
			campaignAudienceLocationType:"",
			mapLocation:false,
			campaignAudienceLocationTarget:"everyone",
			campaignAudienceAgeFrom:"18",
			campaignAudienceAgeTo:"65",
			campaignAudienceGender :"all",
			campaignAudienceLanguage:"",
			campaignAudienceLanguageArr:[],
			campaignAudienceLanguageKeyArr:[],
			LanguageKeyValues:"",
			placementsValues :[],
			campaignAudiencePlacementsWiFi:"1",
			campaignAudienceMobileDevice:"",
			mobileView:false,
			PlacementsArr:[],
			MobileDeviceArr:[],
			placementsKeyValues:[],
			campaignAudienceDTJSON:[],
			DetailedTargetingArr:[],
			DTselectionkey:[],
			DTselection:[],
			demographicsArray:[],
			interestsArray:[],
			behaviorsArray:[]							
			}

		scope.init = function(){
				scope.data.campaignAudienceGender = "all";				
		}
		
		 scope.sendGender = function (campaignAudienceGender) {
            scope.data.campaignAudienceGender = campaignAudienceGender;
            $window.localStorage.setItem("campaignAudienceGender", scope.data.campaignAudienceGender);
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
        }
		scope.init();
		
		scope.$on('genderData', function (event,args) {
			 console.log(args);
			 scope.data.campaignAudienceGender=args.value.campaignAudienceGender;
		  	
		})
}




}
}]);