dashboard.directive('budgetDropdown',['$rootScope','facebookGetPost','$window','$filter','$q',function($rootScope,facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/budgetDropdownTemplate.html',
		transclude:true,			
		scope:{		
		fielddata:"=",
		validation:"&",				
        },  			
		link:function(scope,element,attr){
		scope.fielddata = {
			campaignPlanFormBudget:"",
			campaignPlanFormBudgetValue:"",
			budgetEditValue:"",
			budget:"",
			campaignPlanFormSchedule:"",
			scheduleStartDate:"",
			scheduleEndDate:"",
			advertSetName:"",
			bidAmountVal:"",
			bidAmount:"",
			manualbidtxt:"",
			chargedoptions:"",
			impressions:"",
			radioimpressions:"",
			moreimpressions:"",
			deliverType:"",
			deliveryText:"",
			runAdvert:"",
			AdvertText:"",
			
		}
		scope.campaignState = $window.localStorage.getItem("campaignState");
		scope.campaignPlanFormBudget = "dailyBudget";
			 scope.budgetItems = [{
                "id": 1,
                        "name": "dailyBudget",
                        "description": "Daily Budget",
                        "code": null
                }, {
                "id": 2,
                        "name": "lifetimeBudget",
                        "description": "Lifetime Budget",
                        "code": null
                }]
				scope.selectBudget = function(budgetvalue){
					console.log(budgetvalue);
					//scope.$emit('budgetselection',{value:budgetvalue,value1:scope.budget});
					if(budgetvalue == "dailyBudget"){
						scope.budget = true;
						console.log(scope.budget);
						scope.$emit('budgetselection',{value:budgetvalue,value1:scope.budget});
					}
					else{
						scope.budget = false;
						console.log(scope.budget);
						scope.$emit('budgetselection',{value:budgetvalue,value1:scope.budget});
					}
				}
			//scope.init = function () {
				if (scope.campaignState == "create") {						
					scope.selectBudget("dailyBudget");
					//scope.selectBudget();
					scope.budget = true;
					
				}
				else{
					console.log(scope.campaignPlanFormBudgetValue);
					angular.element('#step2').css('background-color', '#95D2B1');
					angular.element('#step1').css('background-color', '#95D2B1');
					
					scope.$on('addetails', function (event,args) {
						console.log(args);
						console.log(args.value);
						scope.budgetEditValue = args.value.adsetDetails.lifetime_budget;
						console.log(scope.budgetEditValue);
						
						 if (scope.budgetEditValue != 0) {
					console.log(scope.budgetEditValue);
					scope.campaignPlanFormBudget = "lifetimeBudget"
					scope.campaignPlanFormBudgetValue = args.value.adsetDetails.lifetime_budget;
					var adserArr = args.value.adsetDetails.adset_schedule;
					scope.selectBudget("lifetimeBudget");
					//scope.prePopulateChart(adserArr);
					} else {
					scope.campaignPlanFormBudget = "dailyBudget"
					scope.campaignPlanFormBudgetValue = args.value.adsetDetails.daily_budget
					console.log(scope.campaignPlanFormBudgetValue);
					scope.selectBudget("dailyBudget");
					}
					});
					
				}
				
				scope.$watch('campaignPlanFormBudgetValue', function (newVal, oldVal) {
				scope.$emit('campaignPlanFormBudgetValue',{value:scope.campaignPlanFormBudgetValue});
				scope.validation();
				if (newVal) {				
				angular.element('#step1').css('background-color', '#95D2B1');
				} else
				{				
				angular.element('#step1').css('background-color', '#c2c2c2');
				}
				}, true);
				
				scope.setBudgetValue = function (value) {				
				scope.campaignPlanFormBudgetValue = value;				
				}
				
				
			
			//}
				
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 