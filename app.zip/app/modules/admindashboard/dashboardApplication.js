

var dashboard = angular.module('admindashboard', ['ui.router', 'ngAnimate','ngMaterial']);


dashboard.config(["$stateProvider", function ($stateProvider) {

    //dashboard home page state
    $stateProvider.state('appAdmin.adminhomedashboard', {
        url: '/adminhomedashboard',
        templateUrl: 'app/modules/admindashboard/views/admindashboard.html',
        controller: 'AdminDashboardHomeController',
        controllerAs: 'vm',
		parent: "appAdmin",
        data: {
            pageTitle: 'Admin Dashboard Home'
        }
    });

    //userdetail page state
    $stateProvider.state('appAdmin.adminuserdetails', {
        url: '/adminuserdetails',
        templateUrl: 'app/modules/admindashboard/views/userdetails.html',
        controller: 'UserdetailsController',
        controllerAs: 'vm',
		parent: "appAdmin",
        data: {
            pageTitle: 'UserDetails'
        }
    });

    //network page state
    $stateProvider.state('appAdmin.adminnetworkdetails', {
        url: '/adminnetworkdetails',
        templateUrl: 'app/modules/admindashboard/views/networkdetails.html',
        controller: 'NetworkdetailsController',
        controllerAs: 'vm',
		parent: "appAdmin",
        data: {
            pageTitle: 'Network Details'
        }
    });
	
    //currency detail page state
    $stateProvider.state('appAdmin.admincurrencydetails', {
        url: '/admincurrencydetails',
        templateUrl: 'app/modules/admindashboard/views/currencydetails.html',
        controller: 'CurrencydetailsController',
        controllerAs: 'vm',
		parent: "appAdmin",
        data: {
            pageTitle: 'Currency Details'
        }
    });
	
    //currency conversion page state
    $stateProvider.state('appAdmin.admincurrencyconversion', {
        url: '/admincurrencyconversion',
        templateUrl: 'app/modules/admindashboard/views/currencyconversion.html',
        controller: 'CurrencyconversionController',
        controllerAs: 'vm',
		parent: "appAdmin",
        data: {
            pageTitle: 'Currency '
        }
    });
	
	
}]);

dashboard.directive('fileModel', ['$parse', function ($parse) {
	return {
	   restrict: 'A',
	   link: function(scope, element, attrs) {
		  var model = $parse(attrs.fileModel);
		  var modelSetter = model.assign;
		  
		  element.bind('change', function(){
			 scope.$apply(function(){
				modelSetter(scope, element[0].files[0]);
			 });
		  });
	   }
	};
 }]);
