dashboard.service('dashboardService', ['$http', '$q', 'Flash', 'apiService', function ($http, $q, Flash, apiService) {
        var dashboardService = {};
        var updateAdvertiserDetailsService = function (param, updateFileParam) {

            var deferred = $q.defer();
            //Upload Logo File Header
            var fd = new FormData();
            fd.append('file', updateFileParam.file);
            fd.append('role', updateFileParam.role);
            fd.append('id', updateFileParam.id);
            fd.append('userId', updateFileParam.userId);
            fd.append('accessToken', updateFileParam.accessToken);
            
            var uploadConfigHeader = { 
                transformRequest: angular.identity,       
                headers: {
                        'Content-Type': undefined
                }
            };
            if(typeof(updateFileParam.file) == "object"){
                apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (logupload) {
                    if (logupload.appStatus == 0) {
                        param["logoUrl"] = logupload.successMessage;
                        apiService.create("/user/updateadvertiser", param).then(function (updateResponse) {
                            deferred.resolve(updateResponse);
                        },
                        function (updateResponse) {
                                deferred.reject(updateResponse);
                        });
                        return deferred.promise;
                    }else{
                        deferred.resolve(logupload);
                    }
                },
                function (logupload) {
                    deferred.reject(logupload);
                });
                return deferred.promise; 
            }
            else{   
                param["logoUrl"] = updateFileParam.file;
                apiService.create("/user/updateadvertiser", param).then(function (updateResponse) {
                    deferred.resolve(updateResponse);
                },
                function (updateResponse) {
                        deferred.reject(updateResponse);
                });
                return deferred.promise;
                
            }
        };
        
        dashboardService.updateAdvertiserDetailsService = updateAdvertiserDetailsService;

        return dashboardService;

    }]);
