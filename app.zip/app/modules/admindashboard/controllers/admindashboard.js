﻿dashboard.controller("AdminDashboardHomeController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window','appSettings',
function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {
    var vm = this;
    var apiBase = appSettings.apiBase;
    vm.showDetails = true;
    
    $scope.errorcheck_forgotpassword_reason_class = {red:false};
    $scope.AccountCreationRecords=[];
    vm.home = {}; 
        
        $scope.account_dropdown_values = [
            {Key : "All", Value : "All"},
            {Key : "Rejected", Value : "Rejected"},
            {Key : "Approved", Value : "Approved"},
            {Key : "Pending", Value : "Pending"}
        ];
        $scope.forgotpassword_dropdown_values = [
            {Key : "All", Value : "All"},
            {Key : "Rejected", Value : "Rejected"},
            {Key : "Approved", Value : "Approved"},
            {Key : "Pending", Value : "Pending"}
        ];

	$scope.account_text = true;
	$scope.account_confirmbtn = true;
	$scope.account_cancelbtn = true;
	$scope.account_success = false;
	$scope.account_btnOk = false;
	
	$scope.account_reject_text = true;
	$scope.account_reject_confirmbtn = true;
	$scope.account_reject_cancelbtn = true;
	$scope.account_reject_success = false;
	$scope.account_reject_btnOk = false;
	$scope.account_reject_textarea = true;
	
	$scope.forgotpassword_text = true;
	$scope.forgotpassword_confirmbtn = true;
	$scope.forgotpassword_cancelbtn = true;
	$scope.forgotpassword_success = false;
	$scope.forgotpassword_btnOk = false;
	
	$scope.forgotpassword_reject_text = true;
	$scope.forgotpassword_reject_confirmbtn = true;
	$scope.forgotpassword_reject_cancelbtn = true;
	$scope.forgotpassword_reject_success = false;
	$scope.forgotpassword_reject_btnOk = false;
	$scope.forgotpassword_reject_textarea = true;
	
	$scope.account_reverse = true;  
	$scope.forgotpassword_reverse = true;  
        /*$(".accFilterDropdown").select2({
            theme: "classic",
            closeOnSelect:false,
            width:"110px",
        });*/
	$scope.forgotpassword_reverse = true;  	  
	
	$scope.account_order = function (account_predicate) {  
	 $scope.account_reverse = ($scope.account_predicate === account_predicate) ? !$scope.account_reverse : false;  		 
            //$scope.account_targetID =  $(event.target).attr("id");
            $scope.account_targetID =  account_predicate;
            //alert(account_predicate);
            var IDs = $("#accountadminDashboard th[id]").not("#"+$scope.account_targetID).map(function() { return this.id; }).get().join('~');
            var results = IDs.split('~');
            angular.forEach(results,function(val){
                angular.element("#"+val).find(".fa-caret-down").css("padding-top","4px");
                angular.element("#"+val).find(".fa-caret-up").css("padding-top","9px");
            });            
            angular.element("#accountadminDashboard").find(".fa-caret-up").css({'display' : 'inline-block'});
            angular.element("#accountadminDashboard").find(".fa-caret-down").css({'display' : 'inline-block'});            
            if($scope.account_reverse == false){
                angular.element("#"+$scope.account_targetID).find(".fa-caret-down").css("padding-top","26px");
                angular.element("#"+$scope.account_targetID).find(".fa-caret-up").css("padding-top","10px");
                
                angular.element("#"+$scope.account_targetID).find(".fa-caret-down").css({'display' : 'none'});
                angular.element("#"+$scope.account_targetID).find(".fa-caret-up").css({'display' : 'inline-block'});
            }else{
                angular.element("#"+$scope.account_targetID).find(".fa-caret-up").css({'display' : 'none'});
                angular.element("#"+$scope.account_targetID).find(".fa-caret-down").css({'display' : 'inline-block'});
            }
	 $scope.account_predicate = account_predicate;
         
	};

	$scope.forgotpassword_order = function (forgotpassword_predicate) {  
	 $scope.forgotpassword_reverse = ($scope.forgotpassword_predicate === forgotpassword_predicate) ? !$scope.forgotpassword_reverse : false;  		 
            //$scope.forgotpassword_targetID =  $(event.target).attr("id");
            $scope.forgotpassword_targetID =  forgotpassword_predicate;
            //alert($scope.forgotpassword_targetID);
            var IDs = $("#forgotpasswordadminDashboard th[id]").not("#"+$scope.forgotpassword_targetID).map(function() { return this.id; }).get().join('~');
            var results = IDs.split('~');
            angular.forEach(results,function(val){
                angular.element("#"+val).find(".fa-caret-down").css("padding-top","4px");
                angular.element("#"+val).find(".fa-caret-up").css("padding-top","9px");
            });            
            angular.element("#forgotpasswordadminDashboard").find(".fa-caret-up").css({'display' : 'inline-block'});
            angular.element("#forgotpasswordadminDashboard").find(".fa-caret-down").css({'display' : 'inline-block'});            
            if($scope.forgotpassword_reverse == false){
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-down").css("padding-top","26px");
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-up").css("padding-top","10px");
                
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-down").css({'display' : 'none'});
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-up").css({'display' : 'inline-block'});
            }else{
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-up").css({'display' : 'none'});
                angular.element("#"+$scope.forgotpassword_targetID).find(".fa-caret-down").css({'display' : 'inline-block'});
            }
	 $scope.forgotpassword_predicate = forgotpassword_predicate;  
	};	
	
	
	//ACCOUNT SECTION START
	//ACCOUNT ACCEPT SECTION	
	$scope.approveAccountCreation = function(){
		//alert($scope.hd_accountId);
                
                $rootScope.progressLoader = "block";
		var parameters = {
				"accountId": $scope.hd_accountId,
				"userId": $window.localStorage.getItem("userId"),
				"status" : "Approve",
				"accessToken" : $window.localStorage.getItem("accessToken"),
				"reason" : null		
		};
			  
		$http({
                    
			url: apiBase +'/user/createuser',
			dataType: 'json',
			method: 'POST',
			data : parameters,
			headers: {
				"Content-Type": "application/json"
			}
		}).success(function(response){
			if(response.errorId > 0){
                                $rootScope.progressLoader = "none";
				$scope.accountapprove_error = true;
				$scope.account_text = false;
				$scope.account_success = false;
				$scope.account_btnOk = true;
				$scope.account_confirmbtn = false;
				$scope.account_cancelbtn = false;
				$scope.account_approve_error_span = response.errorMessage;
				//alert('Error : ' + response.errorMessage);
			}else{
                                $rootScope.progressLoader = "none";
				$scope.accountapprove_error = false;
				$scope.account_text = false;
				$scope.account_success = true;
				$scope.account_btnOk = true;
				$scope.account_confirmbtn = false;
				$scope.account_cancelbtn = false;
				//alert('Success : ' + response.successMessage);
			}
			$scope.refresh();
			//$scope.account_closeApproveReq();			
		}).error(function(error){
			//ERROR SECTION
			//alert(error);
		});
	};
	
	//ACCOUNT REJECT SECTION
	$scope.rejectAccountCreation = function(){
            
		var parameters = {
				"accountId": $scope.hd_accountId,
				"userId": $window.localStorage.getItem("userId"),
				"status" : "Reject",
				"accessToken" : $window.localStorage.getItem("accessToken"),
				"reason" : $scope.account_reason
		};
		$rootScope.progressLoader = "block";
		$http({
			url: apiBase +'/user/createuser',
			dataType: 'json',
			method: 'POST',
			data : parameters,
			headers: {
				"Content-Type": "application/json"
			}
		}).success(function(response){
			//alert(response.errorId);
			if(response.errorId > 0){
                            $rootScope.progressLoader = "none";
				$scope.accountreject_error = true;
				$scope.account_reject_text = false;
				$scope.account_reject_success = false;
				$scope.account_reject_btnOk = true;
				$scope.account_reject_confirmbtn = false;
				$scope.account_reject_cancelbtn = false;
				$scope.account_reject_textarea = false;
				$scope.account_reject_error_span = response.errorMessage;
				//alert('Error : ' + response.errorMessage);
			}else{
                                $rootScope.progressLoader = "none";
				$scope.accountreject_error = false;
				$scope.account_reject_text = false;
				$scope.account_reject_success = true;
				$scope.account_reject_btnOk = true;
				$scope.account_reject_confirmbtn = false;
				$scope.account_reject_cancelbtn = false;
				$scope.account_reject_textarea = false;
				//alert('Success : ' + response.successMessage);
			}
			$scope.refresh();
			//$scope.account_closeRejectReq();
		}).error(function(error){
			//ERROR SECTION
			//alert(error);
		});
	};
	
        
        //$scope.$watch('accountFilterDropdown', function(){
        $scope.sendaccountFilterDropdown = function(){
            if($scope.accountFilterDropdown=='' || $scope.accountFilterDropdown==null || $scope.accountFilterDropdown=='undefined'){
                $scope.accountFilterDropdown = 'All';
            }
            if($scope.accountFilterDropdown=='All'){
                var mul_array = $filter('filter')($scope.AccountCreationRecords); 
            }else if($scope.accountFilterDropdown=='Rejected'){
                var mul_array = $filter('filter')($scope.AccountCreationRecords, {'status' : 'Closed', 'reason' : '!'},true); 
            }else if($scope.accountFilterDropdown=='Approved'){
                var mul_array = $filter('filter')($scope.AccountCreationRecords, {'status' : 'Closed', 'reason' : "!!"},true); 
            }else if($scope.accountFilterDropdown=='Pending'){
                var mul_array = $filter('filter')($scope.AccountCreationRecords, {'status': 'Open'}); 
            }     
            $scope.FilterAccountCreationRecords = mul_array;            
            if($scope.FilterAccountCreationRecords!='' && $scope.FilterAccountCreationRecords!=undefined){
                $scope.account_totalItems = $scope.FilterAccountCreationRecords.length;  
            }else{
                $scope.account_totalItems = 0;
            }
            $scope.account_currentPage = 1;
            $scope.account_numPerPage = 10;			
            
            //alert("account_totalItems : "+$scope.account_totalItems);
            $scope.account_paginate = function (value) {
                    var begin, end, index;                                
                    begin = ($scope.account_currentPage - 1) * $scope.account_numPerPage;  
                    end = begin + $scope.account_numPerPage;  
                    index = $scope.FilterAccountCreationRecords.indexOf(value);
                    return (begin <= index && index < end);  
            };
            if(parseInt($scope.account_last_val) >= parseInt($scope.account_totalItems)){
                $scope.account_last_val = $scope.account_totalItems;
            }else{
                if(parseInt($scope.account_last_val) < parseInt($scope.account_totalItems)){
                    $scope.account_last_val = $scope.account_totalItems;                
                }else{
                    $scope.account_last_val = $scope.account_numPerPage;                
                }
            };            
            if($scope.account_last_val>=10 && $scope.account_first_val==1){
                $scope.account_last_val = 10;
            }
            if($scope.account_last_val<10 && $scope.account_first_val==1){
                $scope.account_last_val = $scope.account_totalItems;
            }
        };
        
        
        //$scope.$watch('forgotpasswordFilterDropdown', function(){
        $scope.sendforgotpasswordFilterDropdown = function(){    
            var mul_array = '';
            if($scope.forgotpasswordFilterDropdown=='' || $scope.forgotpasswordFilterDropdown==null || $scope.forgotpasswordFilterDropdown=='undefined'){
                $scope.forgotpasswordFilterDropdown = 'All';
            }
            if($scope.forgotpasswordFilterDropdown=='All'){
                var mul_array = $filter('filter')($scope.ForgotPasswordRecords); 
            }else if($scope.forgotpasswordFilterDropdown=='Rejected'){
                var mul_array = $filter('filter')($scope.ForgotPasswordRecords, {'approvalStatus' : 'Closed', 'reason' : '!'},true); 
            }else if($scope.forgotpasswordFilterDropdown=='Approved'){
                var mul_array = $filter('filter')($scope.ForgotPasswordRecords, {'approvalStatus' : 'Closed', 'reason' : "!!"},true); 
            }else if($scope.forgotpasswordFilterDropdown=='Pending'){
                var mul_array = $filter('filter')($scope.ForgotPasswordRecords, {'approvalStatus': 'Open'}); 
            };
            //console.log('fw : '+mul_array);
            $scope.FilterForgotPasswordRecords = mul_array;
            $scope.forgotpassword_currentPage = 1;
            if($scope.FilterForgotPasswordRecords!='' && $scope.FilterForgotPasswordRecords!=undefined){
                $scope.forgotpassword_totalItems = $scope.FilterForgotPasswordRecords.length;  
            }else{
                $scope.forgotpassword_totalItems = 0;
            }
            $scope.forgotpassword_numPerPage = 10;
            $scope.forgotpassword_paginate = function (value) {  
                    var begin, end, index;  
                    begin = ($scope.forgotpassword_currentPage - 1) * $scope.forgotpassword_numPerPage;  
                    end = begin + $scope.forgotpassword_numPerPage;  
                    index = $scope.FilterForgotPasswordRecords.indexOf(value);  
                    return (begin <= index && index < end);  
            };  
            if(parseInt($scope.forgotpassword_last_val) >= parseInt($scope.forgotpassword_totalItems)){
                $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;
            }else{
                if(parseInt($scope.forgotpassword_last_val) < parseInt($scope.forgotpassword_totalItems)){
                    $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;                
                }else{
                    $scope.forgotpassword_last_val = $scope.forgotpassword_numPerPage;                
                }               
            };
            if($scope.forgotpassword_last_val>=10 && $scope.forgotpassword_first_val==1){
                $scope.forgotpassword_last_val = 10;
            }
            if($scope.forgotpassword_last_val<10 && $scope.forgotpassword_first_val==1){
                $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;
            }
        };
        
	$scope.$watch("account_currentPage + account_numPerPage", function() {            
            var begin = (($scope.account_currentPage - 1) * $scope.account_numPerPage);
            var end = begin + $scope.account_numPerPage;
            if($scope.AccountCreationRecords){
				
                $scope.filteredTodos = $scope.AccountCreationRecords.slice(begin, end).length;
            }
            if($scope.account_currentPage <= 1){
                $scope.account_first_val = 1;
            }else{
                $scope.account_first_val = Math.round((parseInt($scope.account_currentPage)-1) * parseInt($scope.account_numPerPage)+1);
            };
            $scope.account_last_val = Math.round(parseInt($scope.account_currentPage) * parseInt($scope.filteredTodos));
            if(parseInt($scope.account_first_val) >= parseInt($scope.account_totalItems) || parseInt($scope.filteredTodos) <  parseInt($scope.account_numPerPage)){
                $scope.account_last_val = $scope.account_totalItems;
            };
            if(parseInt($scope.account_last_val) >= parseInt($scope.account_totalItems)){
                $scope.account_last_val = $scope.account_totalItems;
            }else{
                if(parseInt($scope.account_last_val) < parseInt($scope.account_totalItems)){
                    $scope.account_last_val = $scope.account_first_val+9;                
                }else{
                    $scope.account_last_val = $scope.account_numPerPage;                
                }         
            };
            if($scope.account_last_val>=10 && $scope.account_first_val==1){
                $scope.account_last_val = 10;
            }
            if($scope.account_last_val<10 && $scope.account_first_val==1){
                $scope.account_last_val = $scope.account_totalItems;
            }
        },true);
	//ACCOUNT SECTION END
	
	
	//FORGOT PASSWORD SECTION START
	//FORGOT PASSWORD ACCEPT SECTION	
	$scope.approveForgotPasswordCreation = function(){
		//alert($scope.hd_passwordResetId);
		var parameters = {
				"userId": $window.localStorage.getItem("userId"),
				"passwordResetId": $scope.hd_passwordResetId,
				"accessToken" : $window.localStorage.getItem("accessToken"),
				"action" : "Approve",
				"reason" : null		
		};
                $rootScope.progressLoader = "block";
		$http({
			url: apiBase +'/user/passwordresetaction',
			dataType: 'json',
			method: 'POST',
			data : parameters,
			headers: {
				"Content-Type": "application/json"
			}
		}).success(function(response){
			//alert(response.errorMessage);
			if(response.errorId > 0){
                            $rootScope.progressLoader = "none";
                            $scope.forgotpasswordapprove_error = true;
                            $scope.forgotpassword_text = false;
                            $scope.forgotpassword_success = false;
                            $scope.forgotpassword_btnOk = true;
                            $scope.forgotpassword_confirmbtn = false;
                            $scope.forgotpassword_cancelbtn = false;
                            $scope.forgotpassword_approve_error_span = response.errorMessage;
                            //alert('Error : ' + response.errorMessage);
			}else{
                            $rootScope.progressLoader = "none";
                            $scope.forgotpasswordapprove_error = false;
                            $scope.forgotpassword_text = false;
                            $scope.forgotpassword_success = true;
                            $scope.forgotpassword_btnOk = true;
                            $scope.forgotpassword_confirmbtn = false;
                            $scope.forgotpassword_cancelbtn = false;
                            //alert('Success : ' + response.successMessage);
			}
			$scope.refresh();
			//$scope.forgotpassword_closeApproveReq();			
		}).error(function(error){
			//ERROR SECTION
			//alert(error);
		});
	};
	
	//FORGOT PASSWORD REJECT SECTION
	$scope.rejectForgotPasswordCreation = function(){
		//alert($scope.forgotpassword_reason);
		var parameters = {
				"userId": $window.localStorage.getItem("userId"),
				"passwordResetId": $scope.hd_passwordResetId,
				"accessToken" : $window.localStorage.getItem("accessToken"),
				"action" : "Reject",
				"reason" : $scope.forgotpassword_reason
		};	
                $rootScope.progressLoader = "block";
		$http({
			url: apiBase +'/user/passwordresetaction',
			dataType: 'json',
			method: 'POST',
			data : parameters,
			headers: {
				"Content-Type": "application/json"
			}
		}).success(function(response){
			//alert(response.errorId);
			if(response.errorId > 0){
                                $rootScope.progressLoader = "none";
				$scope.forgotpasswordreject_error = true;
				$scope.forgotpassword_reject_text = false;
				$scope.forgotpassword_reject_success = false;
				$scope.forgotpassword_reject_btnOk = true;
				$scope.forgotpassword_reject_confirmbtn = false;
				$scope.forgotpassword_reject_cancelbtn = false;
				$scope.forgotpassword_reject_textarea = false;
				$scope.forgotpassword_reject_error_span = response.errorMessage;
				//alert('Error : ' + response.errorMessage);
			}else{
                                $rootScope.progressLoader = "none";
				$scope.forgotpasswordreject_error = false;
				$scope.forgotpassword_reject_text = false;
				$scope.forgotpassword_reject_success = true;
				$scope.forgotpassword_reject_btnOk = true;
				$scope.forgotpassword_reject_confirmbtn = false;
				$scope.forgotpassword_reject_cancelbtn = false;
				$scope.forgotpassword_reject_textarea = false;
				//alert('Success : ' + response.successMessage);
			}
			$scope.refresh();
			//$scope.forgotpassword_closeRejectReq();
		}).error(function(error){
			//ERROR SECTION
			//alert(error);
		});
	};
        
        $scope.$watch("forgotpassword_currentPage + forgotpassword_numPerPage", function() {
            //alert('hi');
            var begin = (($scope.forgotpassword_currentPage - 1) * $scope.forgotpassword_numPerPage);
            var end = begin + $scope.forgotpassword_numPerPage;
            if($scope.ForgotPasswordRecords!=undefined){
                $scope.filteredTodos = $scope.ForgotPasswordRecords.slice(begin, end).length;
            }
            if($scope.forgotpassword_currentPage <= 1){
                $scope.forgotpassword_first_val = 1;
            }else{
                $scope.forgotpassword_first_val = Math.round((parseInt($scope.forgotpassword_currentPage)-1) * parseInt($scope.forgotpassword_numPerPage)+1);
            };
            $scope.forgotpassword_last_val = 0;
            $scope.forgotpassword_last_val = Math.round(parseInt($scope.forgotpassword_currentPage) * parseInt($scope.filteredTodos));
            
            if(parseInt($scope.forgotpassword_first_val) >= parseInt($scope.forgotpassword_totalItems) || parseInt($scope.filteredTodos) <  parseInt($scope.forgotpassword_numPerPage)){
                $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;
            };
            if(parseInt($scope.forgotpassword_last_val) >= parseInt($scope.forgotpassword_totalItems)){
                $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;
            }else{
                if(parseInt($scope.forgotpassword_last_val) < parseInt($scope.forgotpassword_totalItems)){
                    $scope.forgotpassword_last_val = $scope.forgotpassword_first_val+9;
                }else{
                    $scope.forgotpassword_last_val = $scope.forgotpassword_numPerPage;                
                }                
            };
            if($scope.forgotpassword_last_val>=10 && $scope.forgotpassword_first_val==1){
                $scope.forgotpassword_last_val = 10;
            }
            if($scope.forgotpassword_last_val<10 && $scope.forgotpassword_first_val==1){
                $scope.forgotpassword_last_val = $scope.forgotpassword_totalItems;
            }
            
        },true);
	//FORGOT PASSWORD SECTION END
	
	//FOR DEFAULT LOADING
	$scope.refresh = function(){
                $rootScope.progressLoader = "block";
		//alert('refresh');
                $scope.accountFilterDropdown = 'All';
                $scope.forgotpasswordFilterDropdown = 'All';
		$http({
			url: apiBase +'/user/accountrequestretrieve',
			dataType: 'json',
			method: 'GET',
			headers: {
				"Content-Type": "application/json",
				"userId": $window.localStorage.getItem("userId"),
				"accessToken": $window.localStorage.getItem("accessToken")
			}
		}).success(function(response){
						$scope.AccountCreationRecords = [];
                        $rootScope.progressLoader = "none";
                        $scope.AccountCreationReject = $filter('filter')(response.accountList, {'status' : 'Closed', 'reason' : '!'},true);
                        $scope.AccountCreationApprove = $filter('filter')(response.accountList, {'status' : 'Closed', 'reason' : "!!"},true);
                        $scope.AccountCreationPending = $filter('filter')(response.accountList, {'status': 'Open'});
                        
                        var accountcreationResult=[];
                        if($scope.AccountCreationReject.length>0){
                            for(var key in $scope.AccountCreationReject) {                            
                                accountcreationResult[key]=$scope.AccountCreationReject[key];
                            }                             
                        }
                        if($scope.AccountCreationApprove.length>0){
                            for(var key in $scope.AccountCreationApprove){
                                accountcreationResult[accountcreationResult.length]=$scope.AccountCreationApprove[key];
                            } 
                        }
                        if($scope.AccountCreationPending.length>0){
                            for(var key in  $scope.AccountCreationPending){
                                accountcreationResult[accountcreationResult.length]= $scope.AccountCreationPending[key];
                            } 
                        }

		
							 for(var val in accountcreationResult) {                            
                                if(typeof(accountcreationResult[val]) == "object"){
                                	if($scope.AccountCreationRecords.indexOf(accountcreationResult[val]) == -1){
                                		$scope.AccountCreationRecords.push(accountcreationResult[val]);   			
                                	}                                  
                                }
                            }
                      //  $scope.AccountCreationRecords = accountcreationResult;
                        $scope.account_totalItems = $scope.AccountCreationRecords.length;  
                       	$scope.account_currentPage = 1;
                        $scope.account_numPerPage = 10;			
                        
			$scope.account_paginate = function (value) {
				var begin, end, index;                                
				begin = ($scope.account_currentPage - 1) * $scope.account_numPerPage;  
				end = begin + $scope.account_numPerPage;  
				index = $scope.AccountCreationRecords.indexOf(value);
				return (begin <= index && index < end);  
			};		
                        //alert("length : "+response.accountList.length);
		}).error(function(error){
                        $rootScope.progressLoader = "none";
			//ERROR SECTION
			$scope.account_totalItems = 0;
		});
		
		$http({
			url : apiBase+ '/user/passwordresetretrieve',
			dataType : 'json',
			method : 'GET',
			headers : {
				"Content-Type": "application/json",
				"userId": $window.localStorage.getItem("userId"),
				"accessToken": $window.localStorage.getItem("accessToken")
			}
		}).success(function(response){
                    
			//alert(response.passwordResetRequests.accountName);
                        var passwordrequestResult=[];
                        $scope.PasswordRequestReject = $filter('filter')(response.passwordResetRequests, {'approvalStatus' : 'Closed', 'reason' : '!'},true);
                        $scope.PasswordRequestApprove = $filter('filter')(response.passwordResetRequests, {'approvalStatus' : 'Closed', 'reason' : "!!"},true); 
                        $scope.PasswordRequestPending = $filter('filter')(response.passwordResetRequests, {'approvalStatus': 'Open'});
                        
                        var passwordrequestResult=[];
                        if($scope.PasswordRequestReject.length>0){
                            for(var key in $scope.PasswordRequestReject) {                            
                                if($scope.PasswordRequestReject[key].passwordResetId>0){
                                    passwordrequestResult[key]=$scope.PasswordRequestReject[key];
                                }
                            }                             
                        }
                        if($scope.PasswordRequestApprove.length>0){
                            for(var key in $scope.PasswordRequestApprove){
                                if($scope.PasswordRequestApprove[key].passwordResetId>0){
                                    passwordrequestResult[passwordrequestResult.length]=$scope.PasswordRequestApprove[key];
                                } 
                            }
                        }
                        if($scope.PasswordRequestPending.length>0){
                            for(var key in  $scope.PasswordRequestPending){
                                if($scope.PasswordRequestPending[key].passwordResetId>0){
                                    passwordrequestResult[passwordrequestResult.length]= $scope.PasswordRequestPending[key];
                                }
                            } 
                        }
			//$scope.ForgotPasswordRecords = response.passwordResetRequests;
                        $scope.ForgotPasswordRecords=passwordrequestResult;
			$scope.forgotpassword_currentPage = 1;
			$scope.forgotpassword_totalItems = $scope.ForgotPasswordRecords.length;  
			$scope.forgotpassword_numPerPage = 10;
		   
			$scope.forgotpassword_paginate = function (value) {  
				var begin, end, index;  
				begin = ($scope.forgotpassword_currentPage - 1) * $scope.forgotpassword_numPerPage;  
				end = begin + $scope.forgotpassword_numPerPage;  
				index = $scope.ForgotPasswordRecords.indexOf(value);  
				return (begin <= index && index < end);  
			};
	
		}).error(function(error){
			//ERROR SECTION
			//alert(error);
                        $scope.forgotpassword_totalItems = 0;
		});
	};	
	$scope.refresh();
	//$interval(function(){ $scope.refresh(), 600000000000});
		
	
	//Popup Reject
	var btn = $(".adminApprove");// Get the button that opens the modal
	var span = document.getElementsByClassName("close")[0];// Get the <span> element that closes the modal
	
	//FOR ACCOUNT POPUP SECTION
	$scope.account_popupRejectReq = function(hd_accountId){
		$scope.account_reason = '';
		$scope.hd_accountId = hd_accountId;
		$scope.accountreject_error = false;
		$scope.account_reject_text = true;
		$scope.account_reject_confirmbtn = true;
		$scope.account_reject_cancelbtn = true;
		$scope.account_reject_success = false;
		$scope.account_reject_btnOk = false;
		$scope.account_reject_textarea = true;
		var modalRejectReq = $(".account_modalReject");// Get the modal Reject req
		modalRejectReq.show();
	}
	$scope.account_closeRejectReq = function() {
		var modalRejectReq = $(".account_modalReject");// Get the modal Reject req
		modalRejectReq.hide();
	}
	$scope.account_popupApproveReq = function(hd_accountId){
          //      $rootScope.progressLoader = "none";	
		$scope.hd_accountId = hd_accountId;
		$scope.accountapprove_error = false;
		$scope.account_text = true;
		$scope.account_confirmbtn = true;
		$scope.account_cancelbtn = true;
		$scope.account_success = false;
		$scope.account_btnOk = false;
		var modalApproveReq = $(".account_modalApprove");// Get the modal Approve req
		modalApproveReq.show();
	}
	$scope.account_closeApproveReq = function() {
		var modalRejectReq = $(".account_modalApprove");// Get the modal Approve req
		modalRejectReq.hide();
	}
	
	//FOR FORGOT PASSWORD POPUP SECTION
	$scope.forgotpassword_popupRejectReq = function(hd_passwordResetId){
		$scope.forgotpassword_reason = '';
		$scope.hd_passwordResetId = hd_passwordResetId;
		$scope.forgotpassword_reject_text = true;
		$scope.forgotpassword_reject_confirmbtn = true;
		$scope.forgotpassword_reject_cancelbtn = true;
		$scope.forgotpassword_reject_success = false;
		$scope.forgotpassword_reject_btnOk = false;
		$scope.forgotpassword_reject_textarea = true;
		var modalRejectReq = $(".forgotpassword_modalReject");// Get the modal Reject req
		modalRejectReq.show();
	}
	$scope.forgotpassword_closeRejectReq = function() {
		var modalRejectReq = $(".forgotpassword_modalReject");// Get the modal Reject req
		modalRejectReq.hide();
	}
	$scope.forgotpassword_popupApproveReq = function(hd_passwordResetId){
                $scope.forgotpassword_approve_error_span = '';
		$scope.hd_passwordResetId = hd_passwordResetId;
		$scope.forgotpassword_text = true;
		$scope.forgotpassword_confirmbtn = true;
		$scope.forgotpassword_cancelbtn = true;
		$scope.forgotpassword_success = false;
		$scope.forgotpassword_btnOk = false;
                $scope.forgotpasswordapprove_error = false;
		var modalApproveReq = $(".forgotpassword_modalApprove");// Get the modal Approve req
		modalApproveReq.show();
	}
	$scope.forgotpassword_closeApproveReq = function() {
		var modalRejectReq = $(".forgotpassword_modalApprove");// Get the modal Approve req
		modalRejectReq.hide();
	}
        
          $scope.errorcheck_forgotpassword_reason= function(val)
        {
          
          if(val === undefined || val==="" || val===null)
          {
                $scope.errorcheck_forgotpassword_reason_class = {red:true};
               $scope.var_errorcheck_forgotpassword_reason = true;
          }
          else{
                $scope.var_errorcheck_forgotpassword_reason_class = {red:false};
          }
        };
        
        
         
	
}]);
