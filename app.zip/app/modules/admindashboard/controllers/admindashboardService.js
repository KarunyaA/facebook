﻿
dashboard.service('adminDash', ['$http', '$q', 'Flash', 'apiService', function ($http, $q, Flash, apiService) {

    var adminDash = {};
    //service to communicate with users to include a new user
    var getAdminDashboardService = function (parameters) {
        var deferred = $q.defer();
        apiService.get("user/accountRequestRetrieve", parameters).then(function (response) {
            if (response)
                deferred.resolve(response);
            else
                deferred.reject("Something went wrong while processing your request. Please Contact Administrator.");
        },
            function (response) {
                deferred.reject(response);
            });
        return deferred.promise;
    };
	
	//service to communicate with users to include a new user
    var AccountDetails = function (parameters) {
        var deferred = $q.defer();
		var configHeader = {
			headers : {
				'Content-Type': 'application/json;',
				'async': 'false;',
				'dataType': 'jsonp;'
			}
		}
        apiService.create("/user/createuser", parameters, configHeader).then(function (response) {
            if (response)
                deferred.resolve(response);
            else
                deferred.reject("Something went wrong while processing your request. Please Contact Administrator.");
        },
            function (response) {
                deferred.reject(response);
            });
        return deferred.promise;
    };
	
	adminDash.getAdminDashboardService = getAdminDashboardService;
	adminDash.AccountDetails = AccountDetails;

    return adminDash;

}]);
