dashboard.controller("UserdetailsController", ['$rootScope', '$scope','$http', '$state', '$location', 'dashboardService', 'Flash', '$q' ,'$window', 'appSettings',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, appSettings) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        $scope.isEdit = false;
        $scope.isEditTxt = true;
        $scope.isEnableUserEditPanel = false;
        $scope.isEnableUserInputFields = true;
        $scope.searchUserSuccessMsg = "none";
        $scope.searchUserErrorMsg = "none";
        $scope.editablePanel = "";
        $scope.onlyNumbers = /^\d+$/;
        $scope.var_opsphone_class = {red:false};
         $scope.var_pocname_class = {red:false};
         $scope.var_pocnumber_class =  {red:false};
        
        $scope.searchUserDetails = function(){  
            $rootScope.progressLoader = "block";
            $scope.uploadedfilename="";
             $scope.var_opsphone = false;
            $scope.var_pocname = false;
             $scope.var_pocnumber = false;
			 $scope.invalidImageSize = false;
             $scope.var_opsphone_class = {red:false};
         $scope.var_pocname_class = {red:false};
         $scope.var_pocnumber_class =  {red:false};
            
            $http({
                method: 'GET',
                url: apiBase + '/user/searchuser?searchedUserId='+$scope.searchUser,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.userType = response.data.searchedUser.userRole;
                    $scope.isEnableUserEditPanel =  true;
                    
                    //Temp fix, confirm with db role type 
                    
                    if($scope.userType == "Ops Team"){
                        $scope.opsTeamId = response.data.opsTeamId;
                        $scope.editablePanel = "Ops Team";
                        $scope.fetchOpsteamDetails($scope.opsTeamId);
                    }
                    if($scope.userType == "Advertiser"){
                        $scope.advertiserId = response.data.advertiserId;
                        $scope.responseData = response;
                        $scope.editablePanel = "advertiser";
                        $scope.fetchAdvertiserDetails($scope.advertiserId);
                    }
					if($scope.userType == "Account"){
						$rootScope.progressLoader = "none";
						$scope.searchUserErrorMsg = "block"; 
						$scope.userErrorPopupHeading = "Edit User";
						$scope.userSearchErrorMsg = "Admin cannot update account details";
						$scope.userType='none';
					}
                }else {// failed
					$rootScope.progressLoader = "none";
					$scope.searchUserErrorMsg = "block"; 
					$scope.userErrorPopupHeading = "Edit User";
					if(response.data.errorId==2026){
						$scope.userSearchErrorMsg = "Searched user not found";
					}else{
						$scope.userSearchErrorMsg = response.data.errorMessage;
					}					
					$scope.userType='none';
				}
            });
        }
        $scope.editUserDetails = function () {
            $scope.isEdit = $scope.isEdit ? false : true;
            $scope.isEditTxt = $scope.isEditTxt ? false : true;
            $scope.isEnableUserInputFields = false;
            $scope.var_opsphone = false;
            $scope.var_pocname = false;
             $scope.var_pocnumber = false;
              $scope.var_opsphone_class = {red:false};
         $scope.var_pocname_class = {red:false};
         $scope.var_pocnumber_class =  {red:false};
            
        }

        $scope.fetchOpsteamDetails = function(opsTeamId){
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + '/user/opsteamdatafetch?opsteamId='+opsTeamId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                $rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') {// success
					$scope.isEditTxt = true;
					$scope.isEdit = false;
					$scope.isEnableUserInputFields = true;
                    $scope.accountName = response.data.fetchOpsteamResponse.accountName;
                    $scope.advertiserName = response.data.fetchOpsteamResponse.advertiserName;
                    $scope.opsMemberName = response.data.fetchOpsteamResponse.opsMemberName;
                    $scope.opsPhone = response.data.fetchOpsteamResponse.opsPhone;
                    $scope.opsEmail = response.data.fetchOpsteamResponse.opsEmail;
                } else {// failed
                    $rootScope.progressLoader = "none";
                        $scope.searchUserErrorMsg = "block"; 
                        $scope.userErrorPopupHeading = "Edit User";
                        $scope.userSearchErrorMsg = response.data.errorMessage;
                }
            });
        }
        $scope.fetchAdvertiserDetails = function(advertiserId){
            $rootScope.progressLoader = "block";
            $http({
                method: 'GET',
                url: apiBase + '/user/advertiserdatafetch?advertiserId='+advertiserId,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                if (response.data.appStatus == '0') {// success
					$scope.isEditTxt = true;
					$scope.isEdit = false;
					$scope.isEnableUserInputFields = true;
                    console.log(response.data.advDataFetchResponse[0]);
                    $rootScope.progressLoader = "none";
                   $scope.accountName = response.data.accountName;
                    $scope.Name = response.data.advDataFetchResponse[0].advertiserName;
                    $scope.emailID = response.data.advDataFetchResponse[0].advertiserEmail;
                    $scope.pocName = response.data.advDataFetchResponse[0].pocName;
                    $scope.pocPhoneNumber = response.data.advDataFetchResponse[0].pocPhone;
                    $scope.logoUrllogoUrl = response.data.advDataFetchResponse[0].logoUrl;
                    $scope.hdDescription = response.data.advDataFetchResponse[0].description;
                } else {// failed
                    $rootScope.progressLoader = "none";
                        $scope.searchUserErrorMsg = "block"; 
                        $scope.userErrorPopupHeading = "Edit User";
                        $scope.userSearchErrorMsg = response.data.errorMessage;
                }
            });
        }
        
        $scope.updateOpsteamDetails = function(){
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "phoneNumber" : $scope.opsPhone,
                "opsTeamId" : $scope.opsTeamId
            };
            $rootScope.progressLoader = "block";
            $http({
                method: 'POST',
                url: apiBase + '/user/updateopsteam',
                data : parameters,
                headers:{
                    "Content-Type": "application/json"
                }
            }).then(function(response) {
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    $scope.searchUserSuccessMsg = "block";  
                    $scope.userSuccessPopupHeading = "Edit User";
                    $scope.userSearchSuccessMsg = "The mail has been sent with the updated details!";

                } else {// failed
                    $rootScope.progressLoader = "none";
                    $scope.searchUserErrorMsg = "block";  
                    $scope.userErrorPopupHeading = "Edit User";
                    $scope.userSearchErrorMsg = response.data.errorMessage;
                }
            });
        }
        $scope.updateAdvertiserDetails = function () {
            $rootScope.progressLoader = "block";
            var errorMessage;
            var file = $scope.getCompanyLogo;
            if(file == undefined){
                file = $scope.logoUrllogoUrl;
            }
            var updateParam = {
                "userId" : $window.localStorage.getItem("userId"),
                "advertiserId" : $scope.advertiserId,
                "pocName" : $scope.pocName,
                "pocNumber" : $scope.pocPhoneNumber,
                "description" : $scope.hdDescription,
                "accessToken" : $window.localStorage.getItem("accessToken")       
            };
             var updateFileParam = {
                 "role" : $scope.userType,
                 "id" : $scope.advertiserId,
                 "file" : file,
                 "userId" : $window.localStorage.getItem("userId"),
                 "accessToken" : $window.localStorage.getItem("accessToken") 
             };
            dashboardService.updateAdvertiserDetailsService(updateParam, updateFileParam).then(function (response) {
                    if(response.appStatus == 0){
                        $rootScope.progressLoader = "none";
                        $scope.searchUserSuccessMsg = "block";  
                        $scope.userSuccessPopupHeading = "Edit User";
                        $scope.userSearchSuccessMsg = "The mail has been sent with the updated details!";
                    } else {
                        $scope.searchUserErrorMsg = "none";  
                        $scope.userErrorPopupHeading = "Edit User";
                        $scope.userSearchErrorMsg = response.errorMessage;
                    }
            });
        }
        $scope.getuseruploadfilename = function(element) {
                $scope.$apply(function ($scope) {
                $scope.size = element.files[0].size;
                 
                if($scope.size < 25000)
                {
                    $scope.uploadedfilename = element.files[0];
                    $scope.logo = {red:false};
                    $scope.invalidImageSize = false;
					if(element.files[0].type.toUpperCase()=='IMAGE/PNG'||element.files[0].type.toUpperCase()=='IMAGE/JPEG'||element.files[0].type.toUpperCase()=='IMAGE/JPG'){
						$scope.uploadedfilename = element.files[0];
						$scope.logo = {red:false};
						$scope.invalidImageSize = false;
					}else{
						$scope.logo = {red:true};
						$scope.invalidImageSize = true;
						$scope.imageErrorMsg = ' Please upload supported file type(PNG,JPG,JPEG)';		
						$scope.uploadedfilename="";
					}
				}else{
                    $scope.logo = {red:true};
                    $scope.invalidImageSize = true;
					$scope.imageErrorMsg = '  Max file size of 25KB';
					$scope.uploadedfilename="";
				}

            });
				
        };
        $scope.closeEditUserPanel = function(){
            $scope.isEnableUserEditPanel = false;
            $scope.isEnableUserInputFields = true;
            $scope.isEdit = $scope.isEdit ? false : true;
            $scope.isEditTxt = $scope.isEditTxt ? false : true;
			$scope.searchUser = "";
        }
        $scope.closePopup = function(){
            $scope.isEnableUserEditPanel = false;
            $scope.isEnableUserInputFields = true;
            $scope.isEdit = $scope.isEdit ? false : true;
            $scope.isEditTxt = $scope.isEditTxt ? false : true;
            $scope.searchUserErrorMsg = "none";
            $scope.searchUserSuccessMsg = "none";
			$scope.searchUser = "";

        }
        $scope.closeErrorPopup = function(){
            $scope.isEnableUserEditPanel = true;
            $scope.isEnableUserInputFields = false;
            $scope.isEdit = true;
            $scope.isEditTxt = false;
            $scope.searchUserErrorMsg = "none";
            $scope.searchUserSuccessMsg = "none";
			$scope.searchUser="";
        }
        window.onclick = function() {
            $scope.searchUserErrorMsg = "none";
            $scope.searchUserSuccessMsg = "none";
        }
        
        $scope.errorcheck_search = function(val)
        {
			if(/(^[0-9]*[a-zA-Z]+[0-9]*[a-zA-Z]*[@])((((([a-z0-9])+(:|_))*)(([0-9]*[a-z]+[0-9]*)+)(((:|_)([a-z0-9])+)*))+)(([.][a-z]{2,5})+)$/.test(val)){
				$scope.var_search = false;
			}else{
				$scope.var_search = true;
			}
        };
        
        //ERROR VALIDATION 
        
      
        $scope.errorcheck_opsphone = function(val)
        {
          $scope.var_opsphone = false;
          if(val === undefined)
          {
                $scope.var_opsphone_class = {red:true};
               $scope.var_opsphone = true;
          }
          else{
                $scope.var_opsphone_class = {red:false};
          }
        };
        
        $scope.errorcheck_pocname= function(val)
        {
          $scope.var_pocname = false;
          if(val === undefined || val==="" || val.toLowerCase()==="null")
          {
				
                $scope.var_pocname_class = {red:true};
				$scope.var_pocname = true;
				$scope.pocErr = "Please enter valid POC name";
		  }
          else{
				if(/[-~!@#$%^&<>.\/\\,:;"'?|+=_()\*]/.test(val) || !isNaN(val)){
					$scope.pocErr = "  Please enter only alpha numeric characters";
					$scope.var_pocname_class = {red:true};
					$scope.var_pocname = true;
				}else{
					$scope.var_pocname_class = {red:false};
				}
			}
        };
         
        $scope.errorcheck_pocnumber= function(val)
        {
          $scope.var_pocnumber = false;
          if(val === undefined)
          {
               $scope.var_pocnumber_class =  {red:true};
               $scope.var_pocnumber = true;
          }
          else{
               $scope.var_pocnumber_class =  {red:false};
          }
        };
        
   

   

        
    }]);

dashboard.directive('validNumber', function() {
  return {
    require: '?ngModel',
    link: function(scope, element, attrs, ngModelCtrl) {
      if(!ngModelCtrl) {
        return; 
      }
      ngModelCtrl.$parsers.push(function(val) {
        if (angular.isUndefined(val)) {
            var val = '';
        }
        var clean = val.replace( /[^0-9]+/g, '');
        if (val !== clean) {
          ngModelCtrl.$setViewValue(clean);
          ngModelCtrl.$render();
        }
        return clean;
      });
      element.bind('keypress', function(event) {
        if(event.keyCode === 32) {
          event.preventDefault();
        }
      });
    }
  };
}); 
