dashboard.controller("NetworkdetailsController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {

        
        var vm = this;
        
        vm.showDetails = true;
        $scope.networkDetails = {};
        $scope.uploadSuccessURL=""
        vm.home = {};
        $scope.networkdetails_predicate = 'network_name';
        $scope.networkdetails_reverse = false;
        
         
        //$scope.logoURL = "images/global/logo-small.png";
        
        $scope.var_pocContact_class= {red:false};
        $scope.var_pocEmail_class= {red:false};
        $scope.var_networkName1_class= {red:false};
        $scope.var_networkUrl1_class= {red:false};
        $scope.var_locationAddress1_class= {red:false};
        $scope.var_locationAddress_class= {red:false};
        $scope.var_pocContact1_class= {red:false};
        $scope.var_pocEmail1_class= {red:false};
        $scope.logo = {red:false};
        
        
        
        
        String.prototype.compare = function (x) {
            if (!x.charCodeAt)
                return -1;
            var result = this.charCodeAt(0) - x.charCodeAt(0);
            if (!result)
                return this.substr(1).compare(x.substr(1));
            return result;
        }

        Array.prototype.sortAttr = function (attr, reverse) {
            var sorter = function (a, b) {
                var aa = a[attr];
                var bb = b[attr];
                if (aa + 0 == aa && bb + 0 == bb)
                    return aa - bb;
                else if (aa.compare)
                    return aa.compare(bb); // aa-bb does not work
                return 0;
            }
            this.sort(function (a, b) {
                var result = sorter(a, b);
                if (reverse)
                    result *= -1;
                return result;
            });
        };
                
        
        //Sorting with arrows
        $scope.networkdetails_order = function (networkdetails_predicate) {
            $scope.networkdetails_reverse = ($scope.networkdetails_predicate === networkdetails_predicate) ? !$scope.networkdetails_reverse : false;
            //$scope.networkdetails_targetID =  $(event.target).attr("id");
            $scope.networkdetails_predicate = networkdetails_predicate;
            $scope.networkdetails_targetID = networkdetails_predicate;
            //alert($scope.networkdetails_targetID);
            
             if (!$scope.flag) {
                $scope.Records.sortAttr(networkdetails_predicate);
                $scope.flag = true;
            } else {
                //console.log('reverse')
                $scope.Records.reverse();
                $scope.flag = false;
            }
            
            var IDs = $("#networkdetailsDashboard th[id]").not("#" + $scope.networkdetails_targetID).map(function () {
                return this.id;
            }).get().join('~');
            var results = IDs.split('~');
            angular.forEach(results, function (val) {
                angular.element("#" + val).find(".fa-caret-down").css("padding-top", "4px");
                angular.element("#" + val).find(".fa-caret-up").css("padding-top", "9px");
            });
            angular.element("#networkdetailsDashboard").find(".fa-caret-up").css({'display': 'inline-block'});
            angular.element("#networkdetailsDashboard").find(".fa-caret-down").css({'display': 'inline-block'});
            if ($scope.networkdetails_reverse == false) {
                //alert($scope.networkdetails_targetID);
                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-down").css("padding-top", "26px");
                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-up").css("padding-top", "10px");

                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-down").css({'display': 'none'});
                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-up").css({'display': 'inline-block'});
            } else {
                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-up").css({'display': 'none'});
                angular.element("#" + $scope.networkdetails_targetID).find(".fa-caret-down").css({'display': 'inline-block'});
            }
            

        };
        //Sorting with arrows


        $scope.isDiabled = true;


        //FOR DEFAULT LOADING
        $scope.network_fetch = function () {
            //alert($window.localStorage.getItem("userId"));
            $rootScope.progressLoader = "block";
             $http({
                method: 'GET',
                url: appSettings.apiBase + '/user/fetchallnetwork',
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function(response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    $rootScope.progressLoader = "none";
                    //$scope.Records = response.data.networkList;
                    $scope.networkDetailsArr = $filter('filter')(response.data.networkList, {'status':'1'});

                    $scope.Records = $scope.networkDetailsArr; 

                    $scope.totalItems = $scope.Records.length;
                    $scope.currentPage = 1;
                    //$scope.totalItems = 15;  
                    $scope.numPerPage = 10;
                    

                    $scope.paginate = function (value) {
                        var begin, end, index;
                        begin = ($scope.currentPage - 1) * $scope.numPerPage;
                        end = begin + $scope.numPerPage;
                        index = $scope.Records.indexOf(value);
                        return (begin <= index && index < end);
                    };

            var begin = (($scope.currentPage - 1) * $scope.numPerPage);
            var end = begin + $scope.numPerPage;
            if($scope.Records!=undefined){
                $scope.filteredTodos = $scope.Records.slice(begin, end).length;
            }
            if ($scope.currentPage <= 1) {
                $scope.first_val = 1;
            } else {
                $scope.first_val = Math.round((parseInt($scope.currentPage) - 1) * parseInt($scope.numPerPage) + 1);
            }
            $scope.last_val = Math.round(parseInt($scope.currentPage) * parseInt($scope.filteredTodos));
            if (parseInt($scope.first_val) >= parseInt($scope.totalItems) || parseInt($scope.filteredTodos) < parseInt($scope.numPerPage)) {
                $scope.last_val = $scope.totalItems;
            }
                } else {// failed
                    $rootScope.progressLoader = "none";
                }
                
                
            });
            
           /* $http({
                url: appSettings.apiBase + '/user/fetchallnetwork',
                dataType: 'json',
                method: 'GET',
                headers: {
                    "Content-Type": "application/json",
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken":  $window.localStorage.getItem("accessToken")
                }
            }).success(function (response) {

                $scope.Records = response.networkList;
                $scope.totalItems = $scope.Records.length;
                $scope.currentPage = 1;
                //$scope.totalItems = 15;  
                $scope.numPerPage = 10;


                $scope.paginate = function (value) {
                    var begin, end, index;
                    begin = ($scope.currentPage - 1) * $scope.numPerPage;
                    end = begin + $scope.numPerPage;
                    index = $scope.Records.indexOf(value);
                    return (begin <= index && index < end);
                };

            }).error(function (error) {
                //ERROR SECTION
                alert(error);
            });*/

        };
        $scope.network_fetch();

        $scope.$watch("currentPage + numPerPage", function () {
            var begin = (($scope.currentPage - 1) * $scope.numPerPage);
            var end = begin + $scope.numPerPage;
            if($scope.Records!=undefined){
                $scope.filteredTodos = $scope.Records.slice(begin, end).length;
            }
            if ($scope.currentPage <= 1) {
                $scope.first_val = 1;
            } else {
                $scope.first_val = Math.round((parseInt($scope.currentPage) - 1) * parseInt($scope.numPerPage) + 1);
            }
            $scope.last_val = Math.round(parseInt($scope.currentPage) * parseInt($scope.filteredTodos));
            if (parseInt($scope.first_val) >= parseInt($scope.totalItems) || parseInt($scope.filteredTodos) < parseInt($scope.numPerPage)) {
                $scope.last_val = $scope.totalItems;
            }
        }, true);
        
        
    
        //IMAGE UPLOAD
         $scope.getuploadfilename = function (element) {
			$scope.invalidImageSize = false;
            $scope.$apply(function ($scope) {
                $scope.size = element.files[0].size;
                if($scope.size < 25000)
                {
                    $scope.uploadedfilename = element.files[0];
					console.log($scope.uploadedfilename)
					$scope.giveFileName = $scope.uploadedfilename.name;
                    $scope.logo = {red:false};
                    $scope.invalidImageSize = false;
					if(element.files[0].type.toUpperCase()=='IMAGE/PNG'||element.files[0].type.toUpperCase()=='IMAGE/JPEG'||element.files[0].type.toUpperCase()=='IMAGE/JPG'){
						$scope.logo = {red:false};
						$scope.invalidImageSize = false;
					}else{
						$scope.logo = {red:true};
						$scope.invalidImageSize = true;
						$scope.imageErrorMsg = '  Please upload supported file type(PNG,JPG,JPEG)';
					}
                }else{
                    $scope.logo = {red:true};
                    $scope.invalidImageSize = true;
					$scope.imageErrorMsg = '  Max file size of 25KB';
                }
				$scope.checkUpdateButton();
            });
        }; 

        
        //updateNetwork and Logo Upload

        $scope.update_network = function () {
            var file = $scope.getCompanyLogo;
            var deferred = $q.defer();
            //Upload Logo File Header
            var fd = new FormData();
            fd.append('file', file);
            fd.append('role', 'Network');
            fd.append('id', $scope.hd_networkId);
            fd.append('userId', $window.localStorage.getItem("userId"));
            fd.append('accessToken', $window.localStorage.getItem("accessToken"));
            
            var uploadConfigHeader = { 
                transformRequest: angular.identity,       
                headers: {
                        'Content-Type': undefined
                }
            };
            $rootScope.progressLoader = "block";
            if(typeof(file) == "object"){
                //alert('file');
                apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (logupload) {
                    if (logupload.appStatus == 0) {
                        //param["logoUrl"] = logupload.successMessage;
                        $scope.uploadSuccessURL = logupload.successMessage;
						//alert('if');
                        var parameters = {
                            "networkId": $scope.hd_networkId,
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken"),
                            "locationAddress": $scope.locationAddress,
                            "pocContact": $scope.pocContact,
                            "pocEmail": $scope.pocEmail,
                            "networkUrl": $scope.networkUrl,
                            "logoUrl": $scope.uploadSuccessURL,
                            "status": "active",
                            "appId":"123456",
                            "appSecret":"asfsdfsdf",
							"appAccessToken":"EAAVnOZChfZA2gBAH8rTWU8C35xr4Sjbh3OzGJXMl9OjHfEeJN6XJSZB6TzGSFS3Mn7l0LmQMEvaxqK7bBJQnvgZAdfkiqODdOA81zWSkxsuT3Mngi0mze0QwewtZCdYhNG9ZBP2k7SxyBWmNtXpuISxPLOj5FsAWgiHbm79Yo2HgZDZD"
                        };
                        
                        apiService.create("/user/updatenetwork", parameters).then(function (updateResponse) {
                            if(updateResponse.appStatus==0)
                            {
                               
                            deferred.resolve(updateResponse);
                            //$scope.message_span = updateResponse.successMessage;
                            $scope.network_Edit = false;
                            $scope.network_Edit_Success = true;
                            
                            }
                             $scope.network_fetch();
                        },
                        function (updateResponse) {
                                deferred.reject(updateResponse);
                        });
                        return deferred.promise;
                    }else{
                        deferred.resolve(logupload);
                    }
                },
                function (logupload) {
                    deferred.reject(logupload);
                });
                return deferred.promise; 
            }else{   
                //alert('else');
                $rootScope.progressLoader = "block";
                var parameters = {
                            "networkId": $scope.hd_networkId,
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken"),
                            "locationAddress": $scope.locationAddress,
                            "pocContact": $scope.pocContact,
                            "pocEmail": $scope.pocEmail,
                            "networkUrl": $scope.networkUrl,
                            "logoUrl": $scope.logoURL,
                            "status": "active",
                            "appId":"123456",
                            "appSecret":"asfsdfsdf",
							"appAccessToken":"EAAVnOZChfZA2gBAH8rTWU8C35xr4Sjbh3OzGJXMl9OjHfEeJN6XJSZB6TzGSFS3Mn7l0LmQMEvaxqK7bBJQnvgZAdfkiqODdOA81zWSkxsuT3Mngi0mze0QwewtZCdYhNG9ZBP2k7SxyBWmNtXpuISxPLOj5FsAWgiHbm79Yo2HgZDZD"
                        };
                apiService.create("/user/updatenetwork", parameters).then(function (updateResponse) {
                    if(updateResponse.appStatus==0)
                            {
                            deferred.resolve(updateResponse);
                        
                            //$scope.message_span = updateResponse.successMessage;
                            $scope.network_Edit = false;
                            $scope.network_Edit_Success = true;
                            
                            }
                            else{
                               
                                $scope.network_Edit = false;
                                $scope.network_Edit_Error = true;
                            }
                    deferred.resolve(updateResponse);
                    
                    $scope.network_fetch();
                    
                },
                
                function (updateResponse) {
                        deferred.reject(updateResponse);
                });
                return deferred.promise;
                
            }
            
        };
        

        $scope.showSuccessFailureMessage = function (param1, param2) {
            if (param1 === "failure") {
                //$scope.network_Edit_Error = true
            } else {
                $scope.network_Edit_Success = true;
            }
            $scope.popupMessage = param2;
            
            //alert(param2);
        }


        $scope.edit_network = function (val) {

            $scope.hd_networkId = val;
            $scope.var_pocContact = false;
            $scope.var_pocEmail = false;
            $scope.var_pocContact_class= {red:false};
            $scope.var_pocEmail_class= {red:false};
            $scope.logo = {red:false};
            $scope.var_locationAddress_class= {red:false};
            $scope.invalidImageSize = false;
            $scope.var_locationAddress= false;
			$scope.uploadedfilename = null;
			$scope.giveFileName='';
            
            var modaledit_network = $(".edit_network_popup");// Get the modal Reject req
            modaledit_network.show();

            var single_object = $filter('filter')($scope.Records, function (d) {
                return d.networkId === $scope.hd_networkId;
            })[0];
            $scope.network_Edit = true;
            $scope.network_Edit_Success = false;
            $scope.network_Edit_Error = false;
			
            $scope.networkName = single_object.networkName;
            $scope.networkUrl = single_object.networkUrl;
            $scope.locationAddress = single_object.locationAddress;
            $scope.pocContact = single_object.pocContact;
            $scope.pocEmail = single_object.pocEmail;
			$scope.getCompanyLogo = '';
            $scope.logoURL = single_object.logoUrl;
            //console.log($scope.logoURL);
        }



        $scope.edit_network_success_close = function () {
            var modaledit_network_success_close = $(".edit_network_popup");// Get the modal Reject req
            modaledit_network_success_close.hide();
			angular.element('input[type=file]').val(null);
        }


        $scope.edit_network_fail_close = function () {

            var modaledit_network_fail_close = $(".edit_network_popup");// Get the modal Reject req
            modaledit_network_fail_close.hide();
        }
        //Edit Network POPUP

        //Delete Network POPUP
        $scope.delete_network = function (val) {

            $scope.hd_networkId = val;
            var modaldelete_network = $(".delete_network_popup");// Get the modal Reject req
            modaldelete_network.show();
            $scope.network_Delete = true;
            $scope.network_Delete_Success = false;
            var single_object = $filter('filter')($scope.Records, function (d) {
                return d.networkId === $scope.hd_networkId;
            })[0];

            $scope.networkName = single_object.networkName;
            $scope.networkUrl = single_object.networkUrl;
            $scope.locationAddress = single_object.locationAddress;
            $scope.pocContact = single_object.pocContact;
            $scope.pocEmail = single_object.pocEmail;
            $scope.logoURL = single_object.logoUrl;
        }



        $scope.delete_network_close = function () {

            var modaldelete_network_close = $(".delete_network_popup");// Get the modal Reject req
            modaldelete_network_close.hide();
            $scope.network_Delete = false;
            $scope.network_Delete_Success = true;
        }

        $scope.delete_network_close1 = function () {

            var modaldelete_network_close1 = $(".delete_network_popup");// Get the modal Reject req
            modaldelete_network_close1.hide();
        }
        //Delete Network POPUP


        //Add Network POPUP	
        $scope.add_network = function () {

            $scope.networkDetails = {};
			
			$scope.networkName1 = '';
			$scope.networkUrl1 = '';
			$scope.locationAddress1 = '';
			$scope.pocContact1 = '';
			$scope.pocEmail1 = '';
			$scope.getCompanyLogo = '';
			$scope.invalidImageSize = 'error';
			
            $scope.add_Network = true;
            $scope.add_Network_Success = false;
            $scope.var_pocEmail1 = false;
            $scope.var_networkName1 = false;
            $scope.var_networkUrl1 = false;
            $scope.var_locationAddress1= false;
            $scope.var_pocContact1= false;
            $scope.var_message_span_networkname = false;
            $scope.var_message_span_networkurl = false;
			$scope.add_Network_Fail = false;
            
            $scope.var_networkName1_class= {red:false};
            $scope.var_networkUrl1_class= {red:false};
            $scope.var_locationAddress1_class= {red:false};
            $scope.var_pocContact1_class= {red:false};
            $scope.var_pocEmail1_class= {red:false};
			$scope.logo = {red:false};
            $scope.invalidImageSize = false;
           
            
            var modaladd_network = $(".add_network_popup");// Get the modal Reject req
            modaladd_network.show();

        }

            //Reset Data
            $(document).ready(function() {
            $("#reset").click(function() {
                $("input").val("");
                 });
             });
            //Reset Data
                 


       /** $scope.create_Network1 = function () {
  
             $scope.add_Network = false;
            $scope.add_Network_Success = true;
             $scope.var_networkName1 = false;
              $scope.var_networkUrl1 = false;
               $scope.var_locationAddress1= false;
                 $scope.var_locationAddress1= false;
                  $scope.var_pocContact1= false;
                   $scope.var_pocEmail1= false;
            
            var modaladd_network = $(".add_network_popup");// Get the modal Reject req
            modaladd_network.show();
           
            
        }*/




        $scope.add_network_success_close = function () {
             $scope.var_message_span_networkname = false;
                    $scope.var_message_span_networkurl = false;
            var modaladd_network_success_close = $(".add_network_popup");// Get the modal Reject req
            modaladd_network_success_close.hide();
        }
        //Add Network POPUP


          $scope.create_Network =  function (_nObj, file) {
            var file = $scope.getCompanyLogo;
            var deferred = $q.defer();
            /**
             * Account Creation Rest API Header
             **/
            var configHeader = {
                headers: {
                    'Content-Type': 'application/json;',
                    'async': 'false;',
                    'dataType': 'jsonp;'
                }
            }
       

            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "locationAddress": $scope.locationAddress1,
                "pocContact": $scope.pocContact1,
                "pocEmail": $scope.pocEmail1,
                "networkUrl": $scope.networkUrl1,
                "logoUrl": $scope.logoURL1,
                "networkName": $scope.networkName1,
                "appId": "7061",
                "appSecret": "jfhsdjfhj",
				"appAccessToken":"EAAVnOZChfZA2gBAH8rTWU8C35xr4Sjbh3OzGJXMl9OjHfEeJN6XJSZB6TzGSFS3Mn7l0LmQMEvaxqK7bBJQnvgZAdfkiqODdOA81zWSkxsuT3Mngi0mze0QwewtZCdYhNG9ZBP2k7SxyBWmNtXpuISxPLOj5FsAWgiHbm79Yo2HgZDZD"
                //"status":"active"
            };

                 

            apiService.create("/user/createnetwork", parameters, configHeader).then(function (response) {
                if (response.appStatus == 0) {
                   
                    var fd = new FormData();
                    fd.append('file', file);
                    fd.append('role', 'Network');
                    fd.append('id', response.networkId );
                    fd.append('userId', $window.localStorage.getItem("userId"));
                    fd.append('accessToken', $window.localStorage.getItem("accessToken"));
                    var uploadConfigHeader = {
                        transformRequest: angular.identity,
                        headers: {
                            'Content-Type': undefined
                        }
                    };
                    apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (uploadResponse) {
                        if (uploadResponse.appStatus == 0) {
                            
                            //deferred.resolve(uploadResponse);
                            var updateParam = {
                                "networkId": response.networkId,
                                "logoUrl": uploadResponse.successMessage
                            };
                            $scope.Logosuccess = uploadResponse.successMessage;
                         
                                                       
                       var parameters = {
                            "networkId": response.networkId,
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken"),
                            "locationAddress": $scope.locationAddress1,
                            "pocContact": $scope.pocContact1,
                            "pocEmail": $scope.pocEmail1,
                            "networkUrl": $scope.networkUrl1,
                            "logoUrl": $scope.Logosuccess,
                            "networkName": $scope.networkName1,
                            "appId": "7061",
                            "appSecret": "jfhsdjfhj",
							"appAccessToken":"EAAVnOZChfZA2gBAH8rTWU8C35xr4Sjbh3OzGJXMl9OjHfEeJN6XJSZB6TzGSFS3Mn7l0LmQMEvaxqK7bBJQnvgZAdfkiqODdOA81zWSkxsuT3Mngi0mze0QwewtZCdYhNG9ZBP2k7SxyBWmNtXpuISxPLOj5FsAWgiHbm79Yo2HgZDZD"
                        };
                        
                        apiService.create("/user/updatenetwork", parameters).then(function (updateResponse) {
                            if(updateResponse.appStatus==0)
                            {
                            
                            deferred.resolve(updateResponse);
                            var modaladd_network = $(".add_network_popup");// Get the modal Reject req
                            modaladd_network.show();
                            $scope.logo = {red:false};
                            $scope.invalidImageSize = false;
                            $scope.add_Network = false;
                            $scope.add_Network_Success = true;
                            
                            
                             $scope.network_fetch();
                            
                            }
                             $scope.network_fetch();
                        },
                                    function (updateResponse) {
                                        deferred.reject(updateResponse);
                                    });
                            return deferred.promise;
                        } else {
                            deferred.resolve(uploadResponse);
                        }
                    },
                            function (uploadResponse) {
                                deferred.reject(uploadResponse);
                            });
                    return deferred.promise;
                }
                //Error validation for create network
                else {
					
                    if(response.errorId == 7008)
                    {
						console.log('1111');
                        $scope.var_networkName1_class= {red:true};
                        $scope.var_message_span_networkname = true;
						$scope.add_Network = true;
						$scope.add_Network_Fail = false;
                    }
                    else if(response.errorId == 7007)
                    {
						console.log('222222');
                        $scope.var_networkUrl1_class= {red:true};
                        $scope.var_message_span_networkurl = true;
						$scope.add_Network = true;
						$scope.add_Network_Fail = false;
                    }else{
						$scope.add_Network = false;
						$scope.add_Network_Fail = true;
					}
					$scope.failureMessageTxt = response.errorMessage;
                    deferred.resolve(response);
                }
                $scope.network_fetch();
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;

        };
        $scope.network_fetch();


        $scope.downloadAccountLogo = function (logoURL) {
            var apiImageServer = appSettings.apiImageServer;
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "filePaths": [logoURL]
            };
            $http({
                method: 'POST',
                url: apiImageServer + '/downloadimages',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }).then(function (resp) {
                $scope.accountLogo = resp.data.imageContent[$scope.logoURL];
            });
        }



        $scope.delete_network_detail = function () {
            //alert($scope.locationAddress + '::' + $scope.pocContact + '::' + $scope.pocEmail + '::' + $scope.networkUrl);
            var parameters = {
                "networkId": $scope.hd_networkId,
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "locationAddress": $scope.locationAddress,
                "pocContact": $scope.pocContact,
                "pocEmail": $scope.pocEmail,
                "networkUrl": $scope.networkUrl,
                "logoUrl": $scope.logoURL,
                "status": "delete",
                "appId":"123456",
                "appSecret":"asfsdfsdf",
				"appAccessToken":"EAAVnOZChfZA2gBAH8rTWU8C35xr4Sjbh3OzGJXMl9OjHfEeJN6XJSZB6TzGSFS3Mn7l0LmQMEvaxqK7bBJQnvgZAdfkiqODdOA81zWSkxsuT3Mngi0mze0QwewtZCdYhNG9ZBP2k7SxyBWmNtXpuISxPLOj5FsAWgiHbm79Yo2HgZDZD"
            };
            //console.log(parameters);
            $rootScope.progressLoader = "block";
            $http({
                url: appSettings.apiBase + "/user/updatenetwork",
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                if (response.errorId > 0) {
                   // alert(response.errorMessage);                                    
                    $rootScope.progressLoader = "none";
                    var modaldelete_network = $(".delete_network_popup");// Get the modal Reject req
                    modaldelete_network.show();
                    $scope.network_Delete = false;
                    $scope.network_Delete_Error  = true;
                    
                    $scope.showSuccessFailureMessage("failure", "response.errorMessage")
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.network_Delete = false;
                    $scope.network_Delete_Success = true;
                    

                }
                $scope.network_fetch();
            }).error(function (error) {
                //console.log('error')
                alert(error);
            });
        };
        
        
        $scope.downloadnetworkLogo = function(networkLogoUrl, loopKey){
                $scope.networkLogo = [];
                var apiImageServer = appSettings.apiImageServer;
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "filePaths" : [networkLogoUrl]
                };
                $http({
                    method: 'POST',
                    url: apiImageServer+'/downloadimages',
                    data : parameters,
                    headers: {
                        'Content-Type': "application/json"
                    }
                }).then(function(resp) {
                    if(resp.data.appStatus==0){
                        $scope.networkLogo[loopKey] = resp.data.imageContent[networkLogoUrl];
                    }
                });
            }
        
        
        //Error Validations
        
        
        
         $scope.errorcheck_locationAddress= function(val)
        {
         
			$scope.var_locationAddress= false;
			if( val === undefined || val=== "" || val.toLowerCase() === "null")
			{
				$scope.var_locationAddress_class= {red:true};
				$scope.var_locationAddress= true;
				$scope.editLocErr = "  Please enter valid address";
			}
			else
			{
				$scope.var_locationAddress_class = {red:false};
			}
          /*
          if (!$scope.var_pocContact && !$scope.var_pocEmail && !$scope.invalidImageSize)
            {
				console.log('here')
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               console.log('sadsa')
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            } */
			$scope.checkUpdateButton();
			
        };
		$scope.checkUpdateButton=function(){
			
			if($scope.var_pocEmail || $scope.var_pocContact || $scope.invalidImageSize || $scope.var_locationAddress){
				angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
			}else{
				angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
			}
		}
		
        //ADD NETWORK
        
        
        $scope.errorcheck_networkName1 = function(val)
        {
            $scope.var_networkName1 = false;
            $scope.var_message_span_networkname = false;           
			if( val == undefined || val =="" || val.toLowerCase()==="null"){
				$scope.networkMsg = "  Please enter valid network name";
				$scope.var_networkName1_class= {red:true};
				$scope.var_networkName1 = true;
			}else{
				if(/[-~!@#$%^&<>.\/\\,:;"'?|+=_()\*]/.test(val)){
					$scope.networkMsg = "  Please enter only alpha numeric characters";
					$scope.var_networkName1_class= {red:true};
					$scope.var_networkName1 = true;
				}else{
					$scope.var_networkName1_class= {red:false};
				}	
			}
          
        };
        
         $scope.errorcheck_networkUrl1= function(val)
        {
         
           $scope.var_networkUrl1 = false;
           $scope.var_message_span_networkurl = false;
             
          if( val === undefined || val=== "")
          {
              $scope.var_networkUrl1_class= {red:true};
              $scope.var_networkUrl1 = true;
          }
          
          else
          {
              $scope.var_networkUrl1_class= {red:false};
          }
          
         
          
        };
        
         $scope.errorcheck_locationAddress1= function(val)
        {
         
			$scope.var_locationAddress1= false;
			if( val == undefined || val== "" || val.toLowerCase()==="null")
			{
				$scope.var_locationAddress1_class= {red:true};
				$scope.var_locationAddress1= true;
				$scope.locationErr = "  Please enter valid address"
			}else{
				$scope.var_locationAddress1_class= {red:false};
			}
			
        };
        
         $scope.errorcheck_pocContact1= function(val)
        {
          
           $scope.var_pocContact1= false;
          if( val === undefined || val=== "")
          {
              $scope.var_pocContact1_class= {red:true};
              $scope.var_pocContact1= true;
          }
          else
          {
              $scope.var_pocContact1_class= {red:false};
          }
        };
        
        $scope.errorcheck_pocEmail1= function(val)
        {
        
           $scope.var_pocEmail1= false;
          if( val === undefined || val===""||val.toLowerCase()==="null" )
          {
              $scope.var_pocEmail1_class= {red:true};
              $scope.var_pocEmail1= true;
          }
          else{
              $scope.var_pocEmail1_class= {red:false};
          }
			if(/(^[0-9]*[a-zA-Z]+[0-9]*[a-zA-Z]*[@])((((([a-z0-9])+(:|_))*)(([0-9]*[a-z]+[0-9]*)+)(((:|_)([a-z0-9])+)*))+)(([.][a-z]{2,5})+)$/.test(val)){
				$scope.var_pocEmail1_class= {red:false};	
				$scope.var_pocEmail1 = false;				
			}else{
				$scope.var_pocEmail1_class= {red:true};
				$scope.var_pocEmail1 = true;
			}
		
        };
        
     
        
        //EDIT NETWORK
      
        $scope.errorcheck_pocContact = function(val)
        {
         
           $scope.var_pocContact = false;
          if( val === "" || val === undefined)
          {
              $scope.var_pocContact_class= {red:true};
              $scope.var_pocContact = true;
          }
          else{
              $scope.var_pocContact_class= {red:false};
          }
		  $scope.checkUpdateButton();
          /*
          if (!$scope.var_pocContact && !$scope.var_pocEmail && !$scope.var_locationAddress &&  !$scope.invalidImageSize)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            } */
        };
        
          $scope.errorcheck_pocEmail = function(val)
        {
         
           $scope.var_pocEmail = false;
			if( val === "" || val === undefined)
			{
			   $scope.var_pocEmail_class= {red:true};
			  $scope.var_pocEmail = true;
			}
			else
			{
			   $scope.var_pocEmail_class= {red:false};
			}
		  
			if(/(^[0-9]*[a-zA-Z]+[0-9]*[a-zA-Z]*[@])((((([a-z0-9])+(:|_))*)(([0-9]*[a-z]+[0-9]*)+)(((:|_)([a-z0-9])+)*))+)(([.][a-z]{2,5})+)$/.test(val)){
				$scope.var_pocEmail_class= {red:false};	
				$scope.var_pocEmail = false;				
			}else{
				$scope.var_pocEmail_class= {red:true};
				$scope.var_pocEmail = true;
			}					
			
		  $scope.checkUpdateButton();
          /*
          if (!$scope.var_pocContact && !$scope.var_pocEmail && !$scope.var_locationAddress &&  !$scope.invalidImageSize)
            {
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
            } else
            {
               
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
            } */
			
        };
       
        
        
       
        
        
    }]);

dashboard.directive('validNumber', function() {
  return {
    require: '?ngModel',
    link: function(scope, element, attrs, ngModelCtrl) {
      if(!ngModelCtrl) {
        return; 
      }
      ngModelCtrl.$parsers.push(function(val) {
        if (angular.isUndefined(val)) {
            var val = '';
        }
        var clean = val.replace( /[^0-9]+/g, '');
        if (val !== clean) {
          ngModelCtrl.$setViewValue(clean);
          ngModelCtrl.$render();
        }
        return clean;
      });
      element.bind('keypress', function(event) {
        if(event.keyCode === 32) {
          event.preventDefault();
        }
      });
    }
  };
}); 

function email() {
return {
    restrict: 'A',
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
        if (!ctrl) {
            return false;
        }

        function isValidEmail(value) {
            if (!value) {
                return false;
            }
            // Email Regex used by ASP.Net MVC
            var regex = /^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$/i;
            return regex.exec(value) != null;
        }

        scope.$watch(ctrl, function () {
            ctrl.$validate();
        });

        ctrl.$validators.email = function (modelValue, viewValue) {
            return isValidEmail(viewValue);
        };
    }
};
} 

