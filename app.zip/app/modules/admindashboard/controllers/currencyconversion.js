dashboard.controller("CurrencyconversionController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {
        var vm = this;

        vm.showDetails = true;
        vm.home = {};
        $scope.currencydetails_predicate = 'primaryCurrencyCode';
        $scope.currencydetails_reverse = false;
        $scope.diablep_currency = false;
        $scope.convclass={red:false}
        $scope.maxDate = "";
        $scope.maxDate1 = "";

        String.prototype.compare = function (x) {
            if (!x.charCodeAt)
                return -1;
            var result = this.charCodeAt(0) - x.charCodeAt(0);
            console.log(this.charCodeAt(0));
            console.log(x.charCodeAt(0));
            if (!result)
                return this.substr(1).compare(x.substr(1));
            return result;
        }

        Array.prototype.sortAttr = function (attr, reverse) {
            var sorter = function (a, b) {
                var aa = a[attr];
                var bb = b[attr];
                if (aa + 0 == aa && bb + 0 == bb)
                    return aa - bb;
                else if (aa.compare)
                    return aa.compare(bb); // aa-bb does not work
                return 0;
            }
            this.sort(function (a, b) {
                var result = sorter(a, b);
                if (reverse)
                    result *= -1;
                return result;
            });
        };
        //Sorting arrow change
        $scope.flag = false;
        $scope.currencydetails_order = function (currencydetails_predicate) {
            $scope.currencydetails_reverse = ($scope.currencydetails_predicate === currencydetails_predicate) ? !$scope.currencydetails_reverse : false;
            $scope.currencydetails_predicate = currencydetails_predicate;
            //$scope.currencydetails_targetID =  $(event.target).attr("id");
            $scope.currencydetails_targetID = currencydetails_predicate;
            //alert($scope.currencydetails_targetID);
            if (!$scope.flag) {
                $scope.currecnyconversionplan1data.sortAttr(currencydetails_predicate);
                $scope.flag = true;
            } else {
                console.log('reverse')
                $scope.currecnyconversionplan1data.reverse();
                $scope.flag = false;
            }

            var IDs = $("#currencydetailsDashboard th[id]").not("#" + $scope.currencydetails_targetID).map(function () {
                return this.id;
            }).get().join('~');
            var results = IDs.split('~');
            angular.forEach(results, function (val) {
                angular.element("#" + val).find(".fa-caret-down").css("padding-top", "4px");
                angular.element("#" + val).find(".fa-caret-up").css("padding-top", "9px");
            });
            angular.element("#currencydetailsDashboard").find(".fa-caret-up").css({'display': 'inline-block'});
            angular.element("#currencydetailsDashboard").find(".fa-caret-down").css({'display': 'inline-block'});
            if ($scope.currencydetails_reverse === false) {
                //alert($scope.currencydetails_targetID);
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css("padding-top", "26px");
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css("padding-top", "9px");

                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css({'display': 'none'});
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css({'display': 'inline-block'});
            } else {
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css({'display': 'none'});
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css({'display': 'inline-block'});
            }


        };


        //Sorting arrow change
        $scope.$watch("searchText", function (query) {
       //     console.log(query);
             var searchchar=query;                                                                          //storing query in searchchar
             $scope.finalsearch=[];
		$scope.currecnyconversionplan1data = $scope.tempArr;
            $scope.counted = $filter("filter")($scope.currecnyconversionplan1data, query);
            if (query === "" || query===undefined) {
                if($scope.tempArr){
                $scope.currecnyconversionplan1data = $scope.tempArr;
                // $scope.first_val = 1;
                // $scope.last_val = 1;
                //$scope.counted = 0;
                
                $scope.currentPage = 1;
            //    $scope.last_val = 1;
                $scope.last_val = 1;
                $scope.totalItems = $scope.currecnyconversionplan1data.length;
              if($scope.totalItems < 10)
              {
                  $scope.last_val = $scope.totalItems;
              }
              else
              {
                   $scope.last_val = 10;
              }
                $scope.numPerPage = 10;
                 
                //$scope.numPerPage = $scope.counted.length;
            }
            } else {                                                                        //search in coloum wise primary and secondary currency search.
               angular.forEach($scope.counted, function(value, key)
                {
               $scope.check=value;
                console.log($scope.check);
                 var i=0;
                  var arr=[];
                   angular.forEach($scope.check, function(value,key)
                 {
                  $scope.keyvalue= value;
                    if(i==2||i==3)
                       arr.push(value);
                     
                       i++;                                                             //to find primary and secondary key value pairs
                 });
                if(((arr.pop().toString().toLowerCase().indexOf(searchchar.toString().toLowerCase()))!=-1)||((arr.pop().toString().toLowerCase().indexOf(searchchar.toString().toLowerCase()))!=-1))
                 {
                     $scope.finalsearch.push($scope.check);
                 }
                
                });
              
              console.log($scope.finalsearch);
              
                $scope.currecnyconversionplan1data=$scope.finalsearch;
               $scope.currentPage = 1;
                $scope.totalItems = $scope.currecnyconversionplan1data.length;
                if($scope.totalItems < 10)
              {
                  $scope.last_val = $scope.totalItems;
              }
             $scope.numPerPage = 10;
            }

        });

        //FOR DEFAULT LOADING
        $scope.currency_plan_one = function () {
            //alert($windo.localStorage.getItem("accessToken"));
            $rootScope.progressLoader = "block";
			$http({
                method: 'GET',
                url: appSettings.apiBase + "/user/fetchallcurrencyplan",
                headers: {
                    "Content-Type": "application/json",
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }).then(function (response) {
				if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";					
					for(var $i=0; $i<response.data.currencyPlanList.length;$i++){
						$http({
							method: 'GET',
							url: appSettings.apiBase + "/user/fetchconversionrateforcurrencyplan?currencyPlanId="+response.data.currencyPlanList[$i].currencyPlanId,
							headers: {
								"Content-Type": "application/json",
								'userId': $window.localStorage.getItem("userId"),
								'accessToken': $window.localStorage.getItem("accessToken")
							}
						}).then(function (response) {
							//console.log(response);
							if (response.data.appStatus == '0') {
								$rootScope.progressLoader = "none";
								$scope.currecnyconversionplan1data = response.data.currencyConversionResults;
								//console.log($scope.currecnyconversionplan1data);
								$scope.tempArr = response.data.currencyConversionResults;
								$scope.totalItems = $scope.currecnyconversionplan1data.length;
								$scope.currentPage = 1;
								//$scope.totalItems = 15;  
								$scope.numPerPage = 10;
								$scope.curr_plan_1 = true;
								$scope.curr_plan_2 = false;
								//alert($scope.totalItems);
								$scope.checkIsLatest();
								$scope.paginate = function (value) {
									var begin, end, index;
									begin = ($scope.currentPage - 1) * $scope.numPerPage;
									end = begin + $scope.numPerPage;
									index = $scope.currecnyconversionplan1data.indexOf(value);
									return (begin <= index && index < end);
								};

							} else {// failed
								$rootScope.progressLoader = "none";
							}
						});
					}					
				}
				
			});
            
        };
        $scope.currency_plan_one();


        $scope.checkIsLatest = function () {
            //var _day = new Date();
            //console.log($scope.Records[0].date);
            //console.log(_day);
            $scope.maxDate = $scope.currecnyconversionplan1data[0].date;
            // console.log($scope.Records[0].date);
            for (var i = 1; i < $scope.currecnyconversionplan1data.length; i++) {

                if ($scope.currecnyconversionplan1data[i].date > $scope.maxDate) {

                    $scope.maxDate1 = $scope.currecnyconversionplan1data[0].date;
                    //console.log($scope.maxDate1);
                }


            }
            //console.log($scope.maxDate1);
        }

        $scope.$watch("currentPage + numPerPage", function () {
            var begin = (($scope.currentPage - 1) * $scope.numPerPage);
            var end = begin + $scope.numPerPage;
           

            $scope.filteredTodos = $scope.currecnyconversionplan1data.slice(begin, end).length;
            if($scope.totalItems>0)
            {
            if ($scope.currentPage <= 1) {
                $scope.first_val = 1;
            } else {
                $scope.first_val = Math.round((parseInt($scope.currentPage) - 1) * parseInt($scope.numPerPage) + 1);
            }
            }else
            {
                $scope.first_val = 0;
            }
            $scope.last_val = Math.round(parseInt($scope.currentPage) * parseInt($scope.filteredTodos));
            if (parseInt($scope.first_val) >= parseInt($scope.totalItems) || parseInt($scope.filteredTodos) < parseInt($scope.numPerPage)) {
                $scope.last_val = $scope.totalItems;
            }
        }, true);

        $scope.update_currency_rate = function () {
            
			//$scope.conversionRate = $scope.conversionRate.trim();
			console.log($scope.conversionRate);
            
            //alert($scope.hd_currencyConversionId+'::'+$scope.primaryCurrencyCode+'::'+$scope.secondaryCurrencyCode+'::'+$scope.conversionRate);
            var parameters = {
                "currencyId": $scope.hd_currencyId,
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "currencyPlanId": $scope.currencyPlanId,
                "primaryCurrencyCode": $scope.primaryCurrencyCode,
                "secondaryCurrencyCode": $scope.secondaryCurrencyCode,
                "conversionRate": $scope.conversionRate



            };
            $rootScope.progressLoader = "block";
            $http({
                url: appSettings.apiBase + "/user/updatecurrencyconversionrate",
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $scope.txtboxdiv = false;
				//console.log(response);
                if (response.errorId > 0) {
                    $rootScope.progressLoader = "none";
                    //alert(response.errorMessage);
                    $scope.message_span = response.errorMessage;
                    
                    var modaledit_currency = $(".edit_currency_popup");// Get the modal Reject req
                    modaledit_currency.show();
                    $scope.Edit_currency_rate = false;
                    $scope.Edit_currency_rate_success = false;
                    $scope.Edit_currecny_rate_failure = true;
                    
                } else {
                     $rootScope.progressLoader = "none";
//                    
                     var modaledit_currency = $(".edit_currency_popup");// Get the modal Reject req
                    modaledit_currency.show();                    
                    $scope.Edit_currency_rate = false;
                    $scope.Edit_currency_rate_success = true;
                    $scope.showSuccessFailureMessage("success", "Currency conversion rate is updated successfully!")
                    $scope.message_span = "Currency conversion details updated successfully!";
                    
                }
                $scope.currency_plan_one();
                //$scope.currencydetails_closeUpdateReq();                                    
            }).error(function (error) {
                alert(error);
            });
        };



        $scope.showSuccessFailureMessage = function (param1, param2) {
            if (param1 == "failure") {
                $scope.Edit_currecny_rate_failure = true
            } else {
                $scope.Edit_currency_rate_success = true;
            }
            $scope.popupMessage = param2;
        }



        $scope.currency_plan_two = function () {
            //alert('i am here');
            $http({
                url: appSettings.apiBase + '/user/fetchconversionrateforcurrencyplan?currencyPlanId=500002',
                dataType: 'json',
                method: 'GET',
                headers: {
                    "Content-Type": "application/json",
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken"),
                }
            }).success(function (response) {

                $scope.Records = response.currencyConversionResults;
                $scope.totalItems = $scope.Records.length;
                $scope.currentPage = 1;
                //$scope.totalItems = 15;  
                $scope.numPerPage = 2;
                $scope.curr_plan_1 = false;
                $scope.curr_plan_2 = true;

                $scope.paginate = function (value) {
                    var begin, end, index;
                    begin = ($scope.currentPage - 1) * $scope.numPerPage;
                    end = begin + $scope.numPerPage;
                    index = $scope.Records.indexOf(value);
                    return (begin <= index && index < end);
                };

            }).error(function (error) {
                //ERROR SECTION
                alert(error);
            });

        };

        $scope.isDiabled = true;

        //Default text-radio display
        $scope.curr_plan_1 = true;
        $scope.curr_plan_2 = false;
        //Default text-radio display


        $scope.paginate = function (value) {
            var begin, end, index;
            begin = ($scope.currentPage - 1) * $scope.numPerPage;
            end = begin + $scope.numPerPage;
            index = $scope.records.indexOf(value);
            return (begin <= index && index < end);
        };

        //Search with Primary Currency code & Secondary Code

    
     
        //Search with Primary Currency code & Secondary Code*/
        
        $scope.edit_currency = function (currencyConversionId, currencyPlanId) {
			
			$scope.currencyPlanId = currencyPlanId;
            $scope.hd_currencyConversionId = currencyConversionId;
             $scope.convclass.red=false;
            var modaledit_currency = $(".edit_currency_popup");// Get the modal Reject req
            modaledit_currency.show();

            $scope.Edit_currency_rate = true;
            $scope.Edit_currency_rate_success = false;
            $scope.conv_rate_empty=false;
            
            var single_object = $filter('filter')($scope.currecnyconversionplan1data, function (d) {
                return d.currencyConversionId === $scope.hd_currencyConversionId;
            })[0];
            $scope.network_Edit = true;
            $scope.network_Edit_Success = false;
            $scope.primaryCurrencyCode = single_object.primaryCurrencyCode;
            $scope.secondaryCurrencyCode = single_object.secondaryCurrencyCode;
            $scope.conversionRate = single_object.conversionRate;
        }
        
        $scope.conversionrate_empty_check = function (val)
        {
			angular.element(".spacekey").on("keydown", function (e) {
				return e.which !== 32;				
			});
            $scope.conv_rate_empty=false;
			//console.log(val);
            if(val==="" || val==undefined || val==null)
            {
                $scope.convclass.red=true;
               $scope.conv_rate_empty=true;
			   //console.log(val);
			  
            }
            else
            {
                 $scope.convclass.red=false;
                $scope.conv_rate_empty=false;
				
            }  
        }

        //Radio Button 2 display text
        $scope.radio_button_2 = function () {
            //alert('hii');
            //If DIV is visible it will be hidden and vice versa.
            $scope.curr_plan_1 = false;
            $scope.curr_plan_2 = true;
        }
        //Radio Button 2 display text

        //Radio Button 1 display text
        $scope.radio_button_1 = function () {
            //alert('hii');
            //If DIV is visible it will be hidden and vice versa.
            $scope.curr_plan_1 = true;
            $scope.curr_plan_2 = false;
        }
        //Radio Button 1 display text              

        $scope.ShowHide = function () {
            //alert('hii');
            //If DIV is visible it will be hidden and vice versa.
            $scope.Edit_currency_rate = false;
            $scope.Edit_currency_rate_success = true;
        }





        $scope.edit_currency_rate = function () {
            var modaledit_currency_rate = $(".edit_currency_popup");// Get the modal Reject req
            modaledit_currency_rate.show();
            $scope.Edit_currency_rate = true;
            $scope.Edit_currency_rate_success = false;

        }



        $scope.edit_currency_success_close = function () {

            var modaledit_network_success_close = $(".edit_currency_popup");// Get the modal Reject req
            modaledit_network_success_close.hide();
        }
		
        $scope.edit_currency_fail_close = function () {

            var modaledit_network_success_close = $(".edit_currency_popup");// Get the modal Reject req
            modaledit_network_success_close.hide();
        }
		
		angular.element(".spacekey").on("keydown", function (e) {
				return e.which !== 32;				
			});

    }
]);

dashboard.directive('validNumber', function() {
  return {
    require: '?ngModel',
    link: function(scope, element, attrs, ngModelCtrl) {
      if(!ngModelCtrl) {
        return; 
      }
      ngModelCtrl.$parsers.push(function(val) {
        if (angular.isUndefined(val)) {
            var val = '';
        }
        var clean = val.replace( /[^0-9.]+/g, '');
        var decimalCheck = clean.split('.');

            if(!angular.isUndefined(decimalCheck[1])) {
                decimalCheck[1] = decimalCheck[1].slice(0,2);
                clean =decimalCheck[0] + '.' + decimalCheck[1];
            }
        if (val !== clean) {
            
          ngModelCtrl.$setViewValue(clean);
          ngModelCtrl.$render();
        }
    
            return clean;
        
      });
      element.bind('keypress', function(event) {
        if(event.keyCode === 32) {
          event.preventDefault();
        }
      });
    }
  };
});  