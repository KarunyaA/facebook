dashboard.controller("CurrencydetailsController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings) {
        var vm = this;
        var apiBase = appSettings.apiBase;
        vm.showDetails = true;
        vm.home = {};
        $scope.currencydetails_predicate = 'action';

        $scope.currencydetails_reverse = false;

        $scope.txtboxdiv = true;
        $scope.currencydetails_createbtn = false;
        $scope.currencydetails_updatebtn = false;
        $scope.currencydetails_cancelbtn = true;
        $scope.currencydetails_success = false;
        $scope.currencydetails_error = false;
        $scope.currencydetails_btnOk = false;
        $scope.currClass = {red:false};
        $scope.codeClass = {red:false};
        $scope.countryClass = {red:false};
        String.prototype.compare = function (x) {
            if (!x.charCodeAt)
                return -1;
            var result = this.charCodeAt(0) - x.charCodeAt(0);
            if (!result)
                return this.substr(1).compare(x.substr(1));
            return result;
        }

        Array.prototype.sortAttr = function (attr, reverse) {
            var sorter = function (a, b) {
                var aa = a[attr];
                var bb = b[attr];
                if (aa + 0 == aa && bb + 0 == bb)
                    return aa - bb;
                else if (aa.compare)
                    return aa.compare(bb); // aa-bb does not work
                return 0;
            }
            this.sort(function (a, b) {
                var result = sorter(a, b);
                if (reverse)
                    result *= -1;
                return result;
            });
        };
        //Sorting arrow change
        $scope.flag = false;
        $scope.currencydetails_order = function (currencydetails_predicate) {
            $scope.currencydetails_reverse = ($scope.currencydetails_predicate === currencydetails_predicate) ? !$scope.currencydetails_reverse : false;
            $scope.currencydetails_predicate = currencydetails_predicate;
            //$scope.currencydetails_targetID =  $(event.target).attr("id");
            $scope.currencydetails_targetID = currencydetails_predicate;
            //alert($scope.currencydetails_targetID);
            if (!$scope.flag) {
                $scope.ListCurrencyDetails.sortAttr(currencydetails_predicate);
                $scope.flag = true;
            } else {
                console.log('reverse')
                $scope.ListCurrencyDetails.reverse();
                $scope.flag = false;
            }

            var IDs = $("#currencydetailsDashboard th[id]").not("#" + $scope.currencydetails_targetID).map(function () {
                return this.id;
            }).get().join('~');
            var results = IDs.split('~');
            angular.forEach(results, function (val) {
                angular.element("#" + val).find(".fa-caret-down").css("padding-top", "4px");
                angular.element("#" + val).find(".fa-caret-up").css("padding-top", "9px");
            });
            angular.element("#currencydetailsDashboard").find(".fa-caret-up").css({'display': 'inline-block'});
            angular.element("#currencydetailsDashboard").find(".fa-caret-down").css({'display': 'inline-block'});
            if ($scope.currencydetails_reverse === false) {
                //alert($scope.currencydetails_targetID);
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css("padding-top", "26px");
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css("padding-top", "10px");

                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css({'display': 'none'});
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css({'display': 'inline-block'});
            } else {
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-up").css({'display': 'none'});
                angular.element("#" + $scope.currencydetails_targetID).find(".fa-caret-down").css({'display': 'inline-block'});
            }


        };

        $scope.currencydetails_CreateReq = function () {
            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "currencyCode": $scope.currencyCode,
                "description": $scope.currencyName,
                "countryName": $scope.countryName
            };
            $rootScope.progressLoader = "block";
            $http({
                url: apiBase + '/user/createcurrency',
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $rootScope.progressLoader = "none";
                $scope.txtboxdiv = false;
                if (response.errorId > 0) {
                    //alert('Error : ' + response.errorMessage);
                    $scope.error_id=response.errorId;
                    if($scope.error_id==10000)
                    {
                        $scope.curr_code_alreadyexist=true;
                        $scope.txtboxdiv = true;
                        $scope.currencydetails_cancelbtn = true;
                        $scope.currencydetails_createbtn = true;
                        $scope.currencydetails_updatebtn = false;
                        $scope.currencydetails_success = false;
                        $scope.currencydetails_error = false;
                        $scope.currencydetails_btnOk = false;
                    }
                    else
                    {
                        $scope.curr_code_alreadyexist=false;
                    $scope.currencydetails_createbtn = false;
                    $scope.currencydetails_updatebtn = false;
                    $scope.currencydetails_cancelbtn = false;
                    $scope.currencydetails_success = false;
                    $scope.currencydetails_error = true;
                    $scope.currencydetails_btnOk = true;
                    }
                } else {
                    $rootScope.progressLoader = "none";
                    //alert('Success : ' + response.successMessage);
                    $scope.currencydetails_createbtn = false;
                    $scope.currencydetails_updatebtn = false;
                    $scope.currencydetails_cancelbtn = false;
                    $scope.currencydetails_success = true;
                    $('#message_span').html('The Currency is added successfully!');
 
                $scope.currencydetails_error = false;
                    $scope.currencydetails_btnOk = true;
                }
                $scope.refresh();
                //$scope.currencydetails_closeUpdateReq();			
            }).error(function (error) {
                alert(error);
            });
        };
           
        $scope.currencydetails_UpdateReq = function () {
            //alert($scope.hd_currencyId);
            var parameters = {
                "currencyId": $scope.hd_currencyId,
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "currencyCode": $scope.currencyCode,
                "description": $scope.currencyName,
                "countryName": $scope.countryName
            };
            $rootScope.progressLoader = "block";
            $http({
                url: apiBase + '/user/updatecurrencydetails',
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $scope.txtboxdiv = false;
                //alert(response.errorId);
                if (response.errorId > 0) {
                    //alert('Error : ' + response.errorMessage);
                    $scope.currencydetails_createbtn = false;
                    $scope.currencydetails_updatebtn = false;
                    $scope.currencydetails_cancelbtn = false;
                    $scope.currencydetails_success = false;
                    $scope.currencydetails_error = true;
                    $scope.currencydetails_btnOk = true;
                } else {
                    $rootScope.progressLoader = "none";
                    //alert('Success : ' + response.successMessage);
                    $scope.currencydetails_createbtn = false;
                    $scope.currencydetails_updatebtn = false;
                    $scope.currencydetails_cancelbtn = false;
                    $scope.currencydetails_success = true;
                    $('#message_span').html('Currency plan details is updated successfully!');
                    $scope.currencydetails_error = false;
                    $scope.currencydetails_btnOk = true;
                }
                $scope.refresh();
                //$scope.currencydetails_closeUpdateReq();			
            }).error(function (error) {
                alert(error);
            });
        };

        //FETCH CURRENCT DETAILS
        $scope.refresh = function () {
            $rootScope.progressLoader = "block";
            $http({
                url: apiBase + '/user/fetchallcurrency',
                dataType: 'json',
                method: 'GET',
                headers: {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
            }).success(function (response) {
                $rootScope.progressLoader = "none";
                $scope.ListCurrencyDetails = response.currencyList;
                $scope.tempArr = response.currencyList;
                $scope.currencydetails_totalItems = $scope.ListCurrencyDetails.length;
                //$scope.currencydetails_totalItems = 5;  
                $scope.currencydetails_currentPage = 1;
                $scope.currencydetails_numPerPage = 10;

                $scope.currencydetails_paginate = function (value) {
                    var begin, end, index;
                    begin = ($scope.currencydetails_currentPage - 1) * $scope.currencydetails_numPerPage;
                    end = begin + $scope.currencydetails_numPerPage;
                    index = $scope.ListCurrencyDetails.indexOf(value);
                    return (begin <= index && index < end);
                };

            }).error(function (error) {
                $rootScope.progressLoader = "none";
                alert(error);
            });
        };
        $scope.refresh();

        $scope.$watch("currencydetails_currentPage + currencydetails_numPerPage", function () {
            var begin = (($scope.currencydetails_currentPage - 1) * $scope.currencydetails_numPerPage);
            var end = begin + $scope.currencydetails_numPerPage;
			if($scope.ListCurrencyDetails){
				$scope.filteredTodos = $scope.ListCurrencyDetails.slice(begin, end).length;	
			}
            
            if ($scope.currencydetails_currentPage <= 1) {
                $scope.first_val = 1;
            } else {
                $scope.first_val = Math.round((parseInt($scope.currencydetails_currentPage) - 1) * parseInt($scope.currencydetails_numPerPage) + 1);
            }
            $scope.last_val = Math.round(parseInt($scope.currencydetails_currentPage) * parseInt($scope.filteredTodos));
            if (parseInt($scope.first_val) >= parseInt($scope.currencydetails_totalItems) || parseInt($scope.filteredTodos) < parseInt($scope.currencydetails_numPerPage)) {
                $scope.last_val = $scope.currencydetails_totalItems;
            }
        }, true);

        $scope.$watch("currencySearch", function (query) {
			
			$scope.ListCurrencyDetails = $scope.tempArr;
            $scope.counted = $filter("filter")($scope.ListCurrencyDetails, query);
            //if($scope.counted!='' && $scope.counted!=undefined){
                if (query === "" || query=="undefined") {

                    $scope.ListCurrencyDetails = $scope.tempArr;
                    //$scope.counted = 0;
                    $scope.currencydetails_currentPage = 1;
                    $scope.currencydetails_totalItems = $scope.ListCurrencyDetails.length;
                    
                    $scope.currencydetails_numPerPage = 10;

                } else {
                    $scope.ListCurrencyDetails = $scope.counted;
                    $scope.currencydetails_currentPage = 1;
                    $scope.currencydetails_totalItems = $scope.counted.length;
                    $scope.currencydetails_numPerPage = $scope.counted.length;
                    if ($scope.counted.length > 10) {
                        $scope.currencydetails_currentPage = 1;
                        $scope.currencydetails_numPerPage = 10;
                        $scope.currencydetails_totalItems = $scope.counted.length;
                    }
                    //$scope.numPerPage = 10;					
                }
            //}

        });

        $scope.nameemptycheck = function(val)
        {
          
            $scope.currnameempty=false;
           
            if( val==="" || val===undefined || val.toLowerCase()==="null")
            {
               $scope.currClass.red=true;
               $scope.currnameempty=true;
            }
            else
            {
                $scope.currClass.red=false;
                $scope.currnameempty=false;
            }  
        }

        $scope.codeemptycheck = function(val)
        {
            $scope.currcodeempty=false;
            $scope.curr_code_alreadyexist=false;
            if(val=="" || val==undefined || val.toLowerCase()==="null" )
            {
               $scope.codeClass.red=true;
               $scope.currcodeempty=true;
            }
            else 
            {
                 
                $scope.codeClass.red=false;
                $scope.currcodeempty=false;
            } 
            
        }
         $scope.countrynameemptycheck = function(val)
         {
            $scope.countrynameempty=false;
            if(val==="" || val===undefined || val.toLowerCase()==="null" )
            {
                $scope.countryClass.red=true;
                 $scope.countrynameempty=true;
            }
            else
            {
                $scope.countryClass.red=false;
                 $scope.countrynameempty=false;
            } 
            
        }



        //FOR CURRENCY EDIT POPUP SECTION
        $scope.currencydetails_closeUpdateReq = function () {
            var modalUpdateReq = $(".currencydetails_modalUpdate");
            modalUpdateReq.hide();
        }
        $scope.currencydetails_popupUpdateReq = function (hd_currencyId) {
            $scope.hd_currencyId = hd_currencyId;
            $('#currencyTitle').html('Edit Currency');
            $scope.countryClass.red=false;
            $scope.codeClass.red=false;
            $scope.currClass.red=false;
            $scope.disablecurrencyCode = true;
            $scope.disablecountryName = true;
            $scope.currnameempty=false;
            $scope.currcodeempty=false;
            $scope.countrynameempty=false;
            $scope.txtboxdiv = true;
            $scope.curr_code_alreadyexist=false;
            $scope.currencydetails_createbtn = false;
            $scope.currencydetails_updatebtn = true;
            $scope.currencydetails_cancelbtn = true;
            $scope.currencydetails_success = false;
            $scope.currencydetails_error = false;
            $scope.currencydetails_btnOk = false;
            
            var modalUpdateReq = $(".currencydetails_modalUpdate");
            modalUpdateReq.show();

            var single_object = $filter('filter')($scope.ListCurrencyDetails, function (d) {
                return d.currencyId === hd_currencyId;
            })[0];
            $scope.currencyCode = single_object.currencyCode;
            $scope.currencyName = single_object.description;
            $scope.countryName = single_object.countryName;

        }

        $scope.currencydetails_popupCreateReq = function () {
            $scope.countryClass.red=false;
            $scope.codeClass.red=false;
            $scope.currClass.red=false;
            $scope.currencyCode = '';
            $scope.currencyName = '';
            $scope.countryName = '';
            $('#currencyTitle').html('Add New Currency');
            $scope.disablecurrencyCode = false;
            $scope.disablecountryName = false;
            $scope.txtboxdiv = true;
            $scope.currnameempty=false;
            $scope.currcodeempty=false;
            $scope.countrynameempty=false;
            $scope.curr_code_alreadyexist=false;
            $scope.currencydetails_createbtn = true;
            $scope.currencydetails_updatebtn = false;
            $scope.currencydetails_cancelbtn = true;
            $scope.currencydetails_success = false;
            $scope.currencydetails_error = false;
            $scope.currencydetails_btnOk = false;
//            var elem = document.getElementById('curnam');
//            elem.style.borderColor="#E2E2E2";
//            var elem1= document.getElementById('counnam');
//            elem1.style.borderColor="#E2E2E2";
//            var elem2 = document.getElementById('curcod');
//            elem2.style.borderColor="#E2E2E2";
            var modalCreateReq = $(".currencydetails_modalUpdate");
            modalCreateReq.show();

        }

    }]);

dashboard.directive('capitalize', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (input) {
                return input ? input.toUpperCase() : "";
            });
            element.css("text-transform", "uppercase");
        }
    };
});

dashboard.directive('onlyDigits', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                if (val) {
                    var digits = val.replace(/[^a-z.A-Z. ]/g, '');
                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return digits;
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
});

