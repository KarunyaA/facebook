dashboard.controller("actionAreaIdentifierReportController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window','appSettings','globalData','netWorkData','twitterGetPost','performanceServices',
function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData,twitterGetPost,performanceServices) {

$scope.advertiserDropDown = [];
$scope.networkmaparrayonload = [];
$scope.InActiveCampaignData = [];
$scope.activeCampaignData = [];
$scope.avgOfImpressions;
$scope.advertiserId = "";
$scope.avgOfActions;
$scope.filter = false;
$scope.graphData = [];
$scope.advData = [];
$scope.campaignStatus = "campaignActive";
 $rootScope.progressLoader = "block";
$scope.userRole = $window.localStorage.getItem('role');
$scope.color1 = 'High Impressions and High actions';
$scope.color2 = 'High Impressions and Low actions';
$scope.color3 = 'Low Impressions and Low actions';
$scope.color4 = 'Low Impressions and High actions';
$scope.arrayOfImpressions = [];
$scope.arrayOfActions = [];
$scope.noError = "";
$scope.gotGraph = false;
var graphRunner;
$scope.error=[];
var errorHeader = [];
$scope.errorpopup2Heading="We're sorry something went wrong!";
var errorString = [];
var errornetwork =[];
var CompletionStatus=false;
var errorcount=true;
$scope.zeroBubble = [];

var data = [
  {
    "campaignId": "23842589938930109",
    "campaignStatus": "PAUSED",
    "campaignName": "campaignN1",
    "networkname": "Facebook",
    "impressions": 20,
    "actions": -63,
    "spend": 1000
  },
  {
    "campaignId": "23842604315040109",
    "campaignStatus": "PAUSED",
    "campaignName": "Promote Your Page",
    "networkname": "Facebook",
    "impressions": 30,
    "actions": 40,
    "spend": 700
  },
  {
    "campaignId": "23842604315530109",
    "campaignStatus": "PAUSED",
    "campaignName": "Reach People near",
    "networkname": "Facebook",
    "impressions": -5342,
    "actions": -63,
    "spend": 400
  },
  {
    "campaignId": "23842599185030109",
    "campaignStatus": "PAUSED",
    "campaignName": "increase",
    "networkname": "Facebook",
    "impressions": -100,
    "actions": 150,
    "spend": 400
  },
  {
    "campaignId": "23842599185320109",
    "campaignStatus": "PAUSED",
    "campaignName": "get",
    "networkname": "Facebook",
    "impressions": 60,
    "actions": 60,
    "spend": 0
  },
  
  {
    "campaignId": "7vu7q",
    "campaignStatus": "PAUSED",
    "campaignName": "TEST33",
    "impressions": 20,
    "actions": 10,
    "spend": 0,
    "networkname": "Twitter"
  }
];
//slide toggle
angular.element("#box-inner").animate({
    width: "toggle"
});

angular.element(document).ready(function (){
    angular.element("#slide-toggle").click(function(){
        angular.element("#box-inner").animate({
            width: "toggle"
        });
    });
});
    
$scope.checkUserRole = function(){
//    console.log($scope.userRole);
    if($scope.userRole == 'Account'){
        $scope.account = true;
    }else{
        $scope.account = false;
    }
};

$scope.moveHome = function(){
  $state.go('app.reportsLanding');
};

$scope.downloadExcel = function(){
  graphRunner.graph().download('csv', 
    'https://visualization-coe.cognizant.com/cviz-utilities/export',
    'https://visualization-coe.cognizant.com/cviz/widgets/area-chart/area-chart.css', 
    'Bubble Chart');
    //while executing this code, the output file downloaded will be "myareaChartWidget.pdf".
};


$scope.downloadPDF = function(){
    graphRunner.graph().download('pdf', 
        'https://visualization-coe.cognizant.com/cviz-utilities/export',
        'https://visualization-coe.cognizant.com/cviz/widgets/area-chart/area-chart.css', 
        'Bubble Chart'
    ); 
};

$scope.checkUserRole();

$scope.getAdvertiserDetails = function (){
    $rootScope.progressLoader = "block";
    var promises = [];
    var getAdvertiserDetails = false;
    promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response){
        if (response.appStatus == '0') {
          //  $rootScope.progressLoader = "none";
            // success
            
            getAdvertiserDetails = true;
            $scope.advertiserdetails = response.advDataFetchResponse;
//            console.log($scope.advertiserdetails);
        } 
        else{
            $rootScope.progressLoader = "none";
            $scope.noError = "false";
            $scope.errorMessage = response.errorMessage;
            //$rootScope.progressLoader = "none";
            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
            } else {
                $rootScope.progressLoader = "none";
               // $scope.editAdsetErrorMsg = 'block';
                if (response.networkError != '' && response.networkError != undefined) {
                    if (response.networkError.message != '' && response.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.networkError.message;
                    } else {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                    }
                } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.errorMessage;
                }
            }
        }
    }));
    $q.all(promises).finally(

            function(){
                if(getAdvertiserDetails)
                {
                    $scope.fillDropDowns();
                }
            });
};
//fill dropdown advertiser
 $scope.fillDropDowns = function()
{   
    var promises = [];
    
    for(i=0; i<$scope.advertiserdetails.length; i++)
    {
        var obj = {
            "advertiserName":$scope.advertiserdetails[i].advertiserName,
            "advertiserId":$scope.advertiserdetails[i].advertiserId
        };
        $scope.advertiserDropDown.push(obj);
        //console.log($scope.advertiserDropDown);
    }
    $scope.allnetworks();
};

$scope.allnetworks = function ()
        {
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response){
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                }
                else{
                    $rootScope.progressLoader = "none";
                    $scope.noError = "false";
                    $scope.errorMessage = response.errorMessage;
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        //$scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(allnetworks)
                        {
                          $scope.networksforacc();
                        }
                    });
        };
        
        $scope.networksforacc = function ()
        {
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                }
                else{
                    $rootScope.progressLoader = "none";
                    $scope.noError = "false";
                    $scope.errorMessage = response.errorMessage;
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        //$scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                function(){
                    if(networksforaccount)
                    {
                         $scope.getusernetworkmapids();
                    }
                });
        };
        
        $scope.getusernetworkmapids = function ()
        {
            var promises = [];
            var readAdAccountSuccess = false;
            angular.forEach($scope.advertiserdetails, function (val, key){
                var networkdetailobj=[];
                
                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){   
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){   
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl
                                };
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.networkmaparrayonload.push(obj);
//                console.log(JSON.stringify($scope.networkmaparrayonload,null,2));
            });
            //$scope.errors = angular.copy($scope.networkmaparrayonload);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++)
            {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.networkmaparrayonload[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                            if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function(response)
                                {    
                                    if(response.appStatus == 0)
                                    {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
                                        {
                                            var campaign = [];
                                            $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["campaigns"] = campaign;
                                        });
                                    }
                                    else
                                    {
                                        $rootScope.progressLoader = "none";
                                        $scope.noError = "false";
                                        $scope.errorMessage = response.errorMessage;
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                        {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        }
                                        else 
                                        {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) 
                                            {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                {
                                                        obj["Error"] = "Error";
                                                        obj["ErrorMessage"] = response.networkError.message;
                                                }
                                                else 
                                                {
                                                        obj["Error"] = response.networkError.error_user_title;
                                                        obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            }
                                            else 
                                            {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            //$scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                            else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function(response)
                                {
                                    if(response.appStatus == 0)
                                    {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.adAccounts,function(value,key)
                                        {
                                            angular.forEach(value,function(value2,key2)
                                            {
                                                var campaigns = [];
                                                $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=value2.twAdAccountId;
                                                $scope.networkmaparrayonload[i].networkDetails[j]["campaigns"] = campaigns;
                                            });
                                        });
                                    }
                                    else
                                    {
                                        $rootScope.progressLoader = "none";
                                        $scope.noError = "false";
                                        $scope.errorMessage = response.errorMessage;
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                        {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } 
                                        else 
                                        {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) 
                                            {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                {
                                                        obj["Error"] = "Error";
                                                        obj["ErrorMessage"] = response.networkError.message;
                                                }
                                                else
                                                {
                                                        obj["Error"] = response.networkError.error_user_title;
                                                        obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } 
                                            else
                                            {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            //$scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        if(readAdAccountSuccess)
                        {
                            $scope.fetchallchildandpush();
                        }
                        else
                        {
                            
                        }
                    });
        };
        $scope.fetchallchildandpush = function()
        {
            var promises = [];
            var campaignSuccess = false;
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")){
                    for(j=0; j<$scope.networkmaparrayonload[i].networkDetails.length; j++){
                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            (function(i,j)
                            {
                                //checking whether the parent network is Fb or twitter
                                if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                {    
                                    promises.push(performanceServices.readadcampaign($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,undefined,appSettings.fbNetwork,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId).then(function (response) 
                                    {
                                        if (response.appStatus == '0') 
                                        {
                                            campaignSuccess = true;
                                            angular.forEach(response.adcampaigns,function (val,key){
                                                angular.forEach(val,function(val1,key1){
        //                                            var insights = [];
                                                    var obj ={
                                                        "campaignId" : val1.campaignId,
                                                        "campaignStatus" : val1.campaignStatus,
                                                        "campaignName" : val1.campaignDetails.name,

                                                    };
                                                    $scope.networkmaparrayonload[i].networkDetails[j].campaigns.push(obj);

                                                });
                                            });


                                        }
                                        else 
                                        {
                                         //   $rootScope.progressLoader = "none";
                                            $scope.noError = "false";
                                            $scope.errorMessage = response.errorMessage;
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                            else 
                                            {
                                                 //   $rootScope.progressLoader = "none";
                            //                       $scope.editAdsetErrorMsg = 'block';
                                                     if (response.networkError != '' && response.networkError != undefined) {
                                                     if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                   $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                     $scope.errorMsg = response.networkError.message;
                                                     errorHeader.push($scope.errorpopupHeading);
                                                     errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                     errorString.push($scope.errorMsg);
                                                    } else {
                                                     $scope.errorpopupHeading = response.networkError.error_user_title;
                                                                  $scope.errorMsg = response.networkError.error_user_msg;
                                                          errorHeader.push($scope.errorpopupHeading);
                                                          errorString.push($scope.errorMsg);
                                                          errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             }
                                                      } else {
                                                          $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                          $scope.errorMsg = response.errorMessage;
                                                          errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                        errorHeader.push("Advertiser :<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Campaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignName+"</b>");
                                                          errorString.push($scope.errorMsg); $rootScope.progressLoader = "block";


                                                      }
                                            }
                                        }
                                    }));
                                }
                                else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                                {
                                    promises.push(performanceServices.readadcampaign($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,undefined,appSettings.twNetwork,$scope.networkmaparrayonload[i].networkDetails[j].adAccountId).then(function (response) 
                                    {
                                        if (response.appStatus == '0') 
                                        {
        //                                    var insights = [];
                                            campaignSuccess = true;
                                            for(k=0; k<response.campaign.length; k++){
                                                angular.forEach(response.campaign[k],function(val,key){
                                                    var obj = {
                                                        "campaignId" : val.twCampaignId,
                                                        "campaignStatus" : val.twCampaignStatus,
                                                        "campaignName" : val.twCampaignDetails.name,

                                                    };
                                                    $scope.networkmaparrayonload[i].networkDetails[j].campaigns.push(obj);
                                                });
                                            }

                                        }
                                        else 
                                        {
                                         //   $rootScope.progressLoader = "none";
                                            $scope.noError = "false";
                                            $scope.errorMessage = response.errorMessage;
                                            if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                            {
                                                $window.localStorage.setItem("TokenExpired", true);
                                                $state.go('login');
                                            }
                                            else 
                                            {
                                                //$rootScope.progressLoader = "none";
                            //                       $scope.editAdsetErrorMsg = 'block';
                                                     if (response.networkError != '' && response.networkError != undefined) {
                                                     if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                     $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                     $scope.errorMsg = response.networkError.message;
                                                     errorHeader.push($scope.errorpopupHeading);
                                                     errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                     errorString.push($scope.errorMsg);
                                                    } else {
                                                     $scope.errorpopupHeading = response.networkError.error_user_title;
                                                          $scope.errorMsg = response.networkError.error_user_msg;
                                                          errorHeader.push($scope.errorpopupHeading);
                                                          errorString.push($scope.errorMsg);
                                                          errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                             }
                                                      } else {
                                                          $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                          $scope.errorMsg = response.errorMessage;
                                                          errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                          errorHeader.push("Advertiser :<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Campaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignName+"</b>");
                                                          errorString.push($scope.errorMsg);
                                                          $rootScope.progressLoader = "block";


                                                      }
                                            }
                                        }
                                    }));
                                }
                            })(i,j);
                        }
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                    if(campaignSuccess)
                    {
                        $scope.readAdCampaignInsights();
                    }
                });
        };
        $scope.readAdCampaignInsights = function(){
            var insightsSuccess = false;
            var promises = [];
            
            for(i=0; i<$scope.networkmaparrayonload.length; i++){
                
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")){
                    for(j=0; j<$scope.networkmaparrayonload[i].networkDetails.length; j++){
                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("campaigns")){
                            for(k=0; k<$scope.networkmaparrayonload[i].networkDetails[j].campaigns.length; k++){
                                (function(i,j,k){
                                    
                                    if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                                    {    
                                        promises.push(performanceServices.readadcampaigninsights($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignId,undefined,undefined,undefined,undefined,appSettings.fbNetwork,true).then(function (response){
                                            if(response.appStatus == '0'){
                                                insightsSuccess = true;
                                                for(l=0; l<response.adCampaignInsights.length; l++){
                                                    angular.forEach(response.adCampaignInsights[l],function(val,key){
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["networkname"] = $scope.networkmaparrayonload[i].networkDetails[j].networkName;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["impressions"] = val.impressions;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["actions"] = val.callToAction;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["spend"] = val.spend;
                                                       
                                                    });
                                                }
                                            }
                                            else
                                            {
                                               if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                              {
                                                   $window.localStorage.setItem("TokenExpired", true);
                                                  $state.go('login');
                                                  }
                                              else {
                                           //  $rootScope.progressLoader = "none";
                    //                       $scope.editAdsetErrorMsg = 'block';
                                             if (response.networkError != '' && response.networkError != undefined) {
                                             if (response.networkError.message != '' && response.networkError.message != undefined) {
                                             $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                             $scope.errorMsg = response.networkError.message;
                                             errorHeader.push($scope.errorpopupHeading);
                                             errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                             errorString.push($scope.errorMsg);
                                            } else {
                                             $scope.errorpopupHeading = response.networkError.error_user_title;
                                                          $scope.errorMsg = response.networkError.error_user_msg;
                                                  errorHeader.push($scope.errorpopupHeading);
                                                  errorString.push($scope.errorMsg);
                                                  errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                     }
                                              } else {
                                                  $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                  $scope.errorMsg = response.errorMessage;
                                                  errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                  errorHeader.push("Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Campaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignName+"</b>");
                                                  errorString.push($scope.errorMsg);
                                                   $rootScope.progressLoader = "block";
                                                 

                                              }
                                                
                                                
                                                
                                                
                                            }}
                                        }));
                                    }else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork){
                                        promises.push(performanceServices.readadcampaigninsights($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignId,undefined,undefined,undefined,undefined,appSettings.twNetwork,true).then(function (response){
                                            if(response.appStatus == '0'){
                                                insightsSuccess = true;
                                                //var insights = [];
                                                for(l=0; l<response.adCampaignInsights.length; l++){
                                                    angular.forEach(response.adCampaignInsights[l],function(val,key){
                                                        //$scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["insights"] = obj;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["impressions"] = val.impressions;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["actions"] = val.callToAction;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["spend"] = val.spend;
                                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]["networkname"] = $scope.networkmaparrayonload[i].networkDetails[j].networkName;
                                                    });
                                                }
                                            }
                                            else
                                            {
                                               if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                              {
                                                   $window.localStorage.setItem("TokenExpired", true);
                                                  $state.go('login');
                                                  }
                                              else {
                                          //    $rootScope.progressLoader = "none";
                    //                       $scope.editAdsetErrorMsg = 'block';
                                             if (response.networkError != '' && response.networkError != undefined) {
                                             if (response.networkError.message != '' && response.networkError.message != undefined) {
                                             $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                             $scope.errorMsg = response.networkError.message;
                                             errorHeader.push($scope.errorpopupHeading);
                                             errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                             errorString.push($scope.errorMsg);
                                            } else {
                                             $scope.errorpopupHeading = response.networkError.error_user_title;
                                                          $scope.errorMsg = response.networkError.error_user_msg;
                                                  errorHeader.push($scope.errorpopupHeading);
                                                  errorString.push($scope.errorMsg);
                                                  errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                     }
                                              } else {
                                                  $scope.errorpopupHeading = "WE're sorry something went wrong!";
                                                  $scope.errorMsg = response.errorMessage;
                                                  errornetwork.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                                                  errorHeader.push("Advertiser:<b>"+$scope.networkmaparrayonload[i].advertiserName + "</b> <br> Campaign:<b>" + $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignName+"</b>");
                                                  errorString.push($scope.errorMsg);
                                                  $rootScope.progressLoader = "block";
                                                 

                                              }
                                             
                                            }}
                                            
                                        }));
                                    }
                                })(i,j,k)
                                    
                                
                            }
                            
                        }
                    }
                }
            }
         $q.all(promises).finally(
                    function(){
                    if(insightsSuccess)
                    {
                        CompletionStatus=true;
                        $scope.errorhandeler();
                        $scope.getCampaigns();
                    }
                }); 
        };

$scope.getCampaigns = function(){
    
    $scope.sumOfImpressions = 0;
    $scope.sumOfActions = 0;
    $scope.graphData = [];
    
    if($scope.advertiserId != "" && $scope.advertiserId != undefined) {
//        console.log('get active campaigns of that advertiser');
        for(i=0; i<$scope.networkmaparrayonload.length; i++) {
            if($scope.advertiserId == $scope.networkmaparrayonload[i].advertiserId) {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                    for(j=0; j<$scope.networkmaparrayonload[i].networkDetails.length; j++) {
                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("campaigns")) {
                            for(k=0; k<$scope.networkmaparrayonload[i].networkDetails[j].campaigns.length; k++) {
                                if($scope.campaignStatus == "campaignActive") {
                                    $scope.noError = "true";
                                    if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignStatus == "ACTIVE") {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].hasOwnProperty("spend")) {
                                            $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend = Math.round($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend);
                                            $scope.graphData.push($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]);
                                        }
                                    }
                                }
                                else if($scope.campaignStatus == "campaignInActive") {
                                    $scope.noError = "true";
                                    if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignStatus != "ACTIVE") {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].hasOwnProperty("spend")) {
                                            $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend = Math.round($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend);
                                            $scope.graphData.push($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]);
                                        }
                                    }
                                }
                            }
                        }else{
                            $scope.noError = "false";
                            $scope.errorMessage = 'no campaigns found under this advertiser';
//                            console.log('no campaigns found under this advertiser');
                        }
                    }
                }else{
                    $scope.noError = "false";
                    $scope.errorMessage = 'Advertiser not mapped to any network';
//                    console.log('Advertiser not mapped to any network');
                }
            }
        }
    } else {
        var noErrorCount = 0;
        for(i=0; i<$scope.networkmaparrayonload.length; i++) {
//            $scope.noError = true;
            if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                for(j=0; j<$scope.networkmaparrayonload[i].networkDetails.length; j++) {
                    if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("campaigns")) {
                        for(k=0; k<$scope.networkmaparrayonload[i].networkDetails[j].campaigns.length; k++) {
                            if($scope.campaignStatus == "campaignActive") {
                                if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignStatus == "ACTIVE") {
//                                    $scope.noError = true;
                                    if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].hasOwnProperty("spend")) {
                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend = Math.round($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend);
                                        $scope.graphData.push($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]);
                                    }
                                }
                            }
                            else if($scope.campaignStatus == "campaignInActive") {
                                if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].campaignStatus != "ACTIVE") {
//                                    $scope.noError = true;
                                    if($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].hasOwnProperty("spend")) {
                                        $scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend = Math.round($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k].spend);
                                        $scope.graphData.push($scope.networkmaparrayonload[i].networkDetails[j].campaigns[k]);
                                    }
                                }
                            }
                        }
                    }else{
//                        console.log($scope.noError, $scope.errorMessage);
//                        $scope.noError = false;
                        noErrorCount++;
                        $scope.errorMessage = 'no campaigns found under this advertiser';
//                        console.log('no campaigns found under this advertiser');
                    }
                }
            }else{
//                $scope.noError = false;
                //noErrorCount++;
                $scope.errorMessage = 'Advertiser not mapped to any network';
//                console.log('Advertiser not mapped to any network');
            }
            if(noErrorCount == $scope.networkmaparrayonload.length)
            {
//                console.log("no insights for any advertiser");
                $scope.noError = "false";
            }
            else
            {
                $scope.noError = "true";
            }
        }
    }
    
    // console.log(JSON.stringify($scope.networkmaparrayonload,null, 2)); 
//    console.log(JSON.stringify($scope.graphData, null, 2));
    if($scope.noError == "true")
    {
        $scope.calculateGraphData($scope.graphData);
    }
    else
    {
        $("#bubbleChart").empty();
        $scope.drawBubbleChart($scope.zeroBubble);
        $rootScope.progressLoader = "none";
    }
    //$scope.getValues($scope.sumOfImpressions, $scope.sumOfActions);
};

$scope.selectAdvertiser = function(){
//    console.log($scope.advertiserId);
    $scope.getCampaigns();
};

$scope.selectActiveCampaigns = function(){
//    console.log($scope.campaignStatus);
    $scope.getCampaigns();
};

$scope.selectInActiveCampaigns = function() {
//    console.log($scope.campaignStatus);
    $scope.getCampaigns();
};
//======================================= data load on select of advertiser ============================================//


       $scope.resetPopup1 = function() {
                       $scope.campSumErrors = "none";$scope.editAdsetErrorMsg="none";
                        angular.element("#errorScroll").scrollTop(0);
                        errorcount=false;
                        angular.element($('body').css("overflow-y", "scroll"));
                         var errorHeader = [];    
                        var errorString = [];
                        var errornetwork =[];
        };
         var p=0;
        $scope.errorhandeler =function()
        {
            $rootScope.progressLoader = "none";
          //  if(errorcount)
            {
                
                if((errorHeader.length)>0)
                {
                    
                   
                $scope.campSumErrors = 'block';
              angular.element($('body').css("overflow-y", "hidden"));
              angular.element("#campSumErrors").empty();	
               angular.element("#errorScroll").css("height","100px");
               angular.element("#errorScroll").css("overflow-y","none");
              angular.element("#lessErrors").css("display","none");	
	      angular.element("#moreErrors").css("display","flex");
            for(p;p<errorHeader.length;p++)
                {
                    var image;
                 
                   
                 if(errornetwork[p]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                            
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
                     
                    );
       
                    }else
                   
                { angular.element("#campSumErrors").append(

                              
                               "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[p] +                               						
                                "</div>" +                              
                                "</div>"
        
                    );
                }
                }
               
                }
            }
          
           
              
            };
       //"<img style='width: 30%;height: 30%;src='images/accountDashboard/facebook.svg'>"+
       //  $scope.campSumErrors='block';
           $scope.viewMoreErrors = function()
        {  var pp=0;
            angular.element("#campSumErrors").empty();	
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
             for(pp;pp<errorHeader.length;pp++)
                {
                    var image;
                  //  console.log(errorHeader[pp].indexOf('<br>'));
                  //  console.log(errorHeader[pp]);
                    
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: 70px; border-right: 1px solid #c5c5c5;float: left;padding-top: 12px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp]
                                 +"</div>" +"</div>"+ "</div>" 

                    );
       
                    }else
                  
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;height:110px;'>" +								    
								"<div style='width: 40px;height: 70px; border-right: 1px solid #c5c5c5;float: left;padding-top: 12px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/twitter.png'>"+
								"</div>"+
                                                                "<div style='height: 75px;'>"+
                                "<div style='width: 92%; margin-left: 45px;'>" + 								    
                                errorHeader[pp]+   
                                "</div>"+
                                "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp] +
                               								
                                "</div>" +    "</div>" + "</div>" 
        
                    );
                }
                }  
    
        };
    
        $scope.viewLessErrors = function()
        {
            var pp;
         angular.element("#campSumErrors").empty();			
          angular.element("#errorScroll").css("height","100px");
          angular.element("#errorScroll").css("overflow-y","hidden");
          angular.element("#lessErrors").css("display","none");	
	  angular.element("#moreErrors").css("display","flex");
          angular.element($('body').css("overflow-y", "none"));
          angular.element("#errorScroll").scrollTop(0);
            
          
           
            
            
            for(pp=0;pp<errorHeader.length;pp++)
                {
                    var image;
//                 console.log(errornetwork[pp]);
                   
                 if(errornetwork[pp]==="Facebook")
                    {
                   angular.element("#campSumErrors").append(

                             
                             "<div style='background:#F5F5F5;height:40px;margin-bottom:15px;'>" +								    
								"<div style='width: 40px;height: 40px; border-right: 1px solid #c5c5c5;float: left;padding-top: 8px;'>"+								
								"<img style='width: 20px;' src='images/accountDashboard/facebook.png'>"+
								"</div>"+                               
                               "<div style='width:100%;color:#ff0000;font-size:13px;;margin-left: 45px;'>" +
                                errorString[pp] +                               						
                                "</div>" +                              
                                "</div>"

                    );
       
                    }else
                   
                { angular.element("#campSumErrors").append(

                              
                                "<div style='background:#F5F5F5;padding-bottom:40px;'>" 
                                
                                +"<div class='secondhalferror'>"
                                +
                                "<div style='width:100%;color:#ff0000;font-size:13px; text-align:left;padding-left: 10px;'>" +
                                errorString[pp] +
                                "</div></div>" +"<div class='firsthalferror'><img src='images/accountDashboard/twitter.png' ></img></div>"+
                            "</div></div><br> <br>"
        
                    );
                }
                } 
        };


        $scope.calculateGraphData = function(inputArray){
    $scope.progressLoader = "none";
    $scope.sumOfImpressions = 0;
    $scope.sumOfActions = 0;
    var axis=0;
	var maxPositive = 0;
    var minNegative = 0;
	var highX = 0;
	var lowX = 0;
	var highY = 0;
	var lowY = 0;
	$scope.arrayOfImpressions = [];
	$scope.arrayOfActions = [];
    $scope.average = inputArray.length;
    for(i=0; i<inputArray.length; i++){
        if(inputArray[i].hasOwnProperty("spend")){
            if(inputArray[i].hasOwnProperty("impressions")){
                $scope.impressions = inputArray[i].impressions;
                $scope.sumOfImpressions = $scope.sumOfImpressions + $scope.impressions;
            }
            if(inputArray[i].hasOwnProperty("actions")){
                $scope.actions = inputArray[i].actions;
                $scope.sumOfActions = $scope.sumOfActions+ $scope.actions;
            }
        }
    }
    
    if($scope.sumOfImpressions == 0 && $scope.sumOfActions == 0){
//        console.log($scope.sumOfActions);
//        console.log($scope.impressions);
        setAxis = 10000;
    }else{
         $scope.avgOfActions = $scope.sumOfActions / $scope.average;
        $scope.avgOfImpressions = $scope.sumOfImpressions / $scope.average;

        for(i=0; i<inputArray.length; i++){
            if(inputArray[i].hasOwnProperty("impressions")){
                inputArray[i].impressions = Math.round(inputArray[i].impressions - $scope.avgOfImpressions);
                $scope.arrayOfImpressions.push(inputArray[i].impressions);
            }if(inputArray[i].hasOwnProperty("actions")){
                inputArray[i].actions = Math.round(inputArray[i].actions - $scope.avgOfActions);
                $scope.arrayOfActions.push(inputArray[i].actions);
            }
        }

        for(i=0; i<inputArray.length; i++){
            if(inputArray[i].hasOwnProperty("impressions") && inputArray[i].hasOwnProperty("actions")){
                $scope.imp = inputArray[i].impressions;
                $scope.act = inputArray[i].actions;
                if($scope.imp >=0 && $scope.act>=0){
                    inputArray[i]["color"] = $scope.color1;
                }else if($scope.imp >=0 && $scope.act<0){
                    inputArray[i]["color"] = $scope.color2;
                }else if($scope.imp<0 && $scope.act<0){
                    inputArray[i]["color"] = $scope.color3;
                }else if($scope.imp<0 && $scope.act>=0){
                    inputArray[i]["color"] = $scope.color4;
                }
            }
            if(inputArray[i].hasOwnProperty("networkname")){
                if(inputArray[i].networkname == 'Facebook'){
                    inputArray[i].networkname = 'Facebook';
                }else if(inputArray[i].networkname == 'Twitter'){
                    inputArray[i].networkname = 'Twitter';
                    }
            }
        }
        var maxNmins = [];
        var highX =(Math.max.apply(null, $scope.arrayOfActions));
        maxNmins.push(highX);
        var lowX = (Math.min.apply(null, $scope.arrayOfActions));
        maxNmins.push(lowX);
        var highY = (Math.max.apply(null, $scope.arrayOfImpressions));
        maxNmins.push(highY);
        var lowY = (Math.min.apply(null, $scope.arrayOfImpressions));
        maxNmins.push(lowY);

        var maxPositive = Math.max.apply(null, maxNmins);
        var minNegative = Math.min.apply(null, maxNmins);
        if(maxPositive > (-minNegative))
        {
            axis = maxPositive;
        }else{
            axis = -minNegative;
        }
        var setAxis = axis;
    }
   
        
//    console.log(JSON.stringify(inputArray, null, 2));
    $scope.drawBubbleChart(inputArray,setAxis);
};



        $scope.drawBubbleChart = function(dataTest, axis){
	//console.log(dataTest);
	//console.log(axis);
   $("#bubbleChart").empty();
   graphRunner = cviz.widget.BubbleChart.Runner({
     id : '1',
     container : {
        id : '#bubbleChart',
        title : '',
        contextBrush : 'yes',
        showGrid : 'no',
        showMarkers : 'yes',
        titlePos : '',
        width : 865,
        height : 400
      },
     bindings : {
        unique : ['impressions','actions'],
        y : 'impressions',
        x : 'actions',
        radius : 'spend',
        color : 'color'
     },
     axisRange : {
        x:{min:-axis,max:axis},
        y:{min:-axis, max:axis}
      },
     scaling : {
        x : 1,
        y : 1
     },
     fillConfig : 'fill',
     ticks : {y : 14},
     tickerAngle : {x : 0},
     radius : {
        min : 15,
        max : 30
     },
     labels : {
         x : 'actions', 
         y : 'impressions'
      },
     limits : {
         lower : 0,
         upper :0
       },
     upperLimit : {
         intersectAt : 'y',
         angle : 90
     },
     lowerLimit : {
        intersectAt :'x',
        angle : 90
     },
    tooltip : {
        width: '200px',
        background : 'orange',
        bindings: [
            {
               bindWith : 'networkname'
            },
            {  
               label : '$',
               bindWith : 'spend'},
            {
                bindWith : 'campaignName'
            }
        ]
     },
     utility : {
         print : {
               isPrintable : true,
   pageSize:'landscape',//l=landscape;p=portrait;or give width & height
               pageMargin : {
                    top : 100,
                    right : 100,
                    bottom : 100,
                    left : 100,
                    unit : 'cm'
                  }
               },
       download:{
               cssFileUrl : 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
               exportServiceUrl : 'https://visualization-coe.cognizant.com/cviz-utilities/export',
               fileName: 'demotest'
               }
           }
    });
        graphRunner.graph().render(dataTest);
        graphRunner.graph().update(dataTest);
};    
        //$scope.calculateGraphData(data);
        $scope.setUserIdAndAccessToken = function() {
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.getAdvertiserDetails();
        };
        $scope.setUserIdAndAccessToken();
}]);