dashboard.factory('reportApi', ['$http', '$q', '$timeout', 'catalyst', 'httpApi', '$rootScope', 'appSettings', function ($http, $q, $timeout, catalyst, httpApi, $rootScope, appSettings) {
        var obj = {};
        var baseUrl = catalyst.serviceUrl1;
        var baseUrl2 = catalyst.serviceUrl2;
        var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        var apiTwitterBase = appSettings.apiTwitterBase;

        obj.isLocal = false;
        var _config = {};
        _config.cache = 'false';
        _config.async = 'false';

        //----------------------------------------------get API----------------------------------------------------------------	 
        obj.advertiserdatafetch = function (_queryStr, _parameters) {
            var url = apiBase + "/user/advertiserdatafetch" + _queryStr;
            return httpApi.get(url, _parameters);
        }



        //----------------------------------------------post API----------------------------------------------------------------
        obj.fetchallnetwork = function (_queryStr, _parameters) {
            var url = apiBase + "/user/fetchallnetwork"+_queryStr;
            return httpApi.get(url, _parameters);
        }

        //----------------------------------------------Delete API----------------------------------------------------------------
        obj.fetchadvertisernetworks = function (_queryStr, _parameters) {
            var url = apiBase + "/user/fetchadvertisernetwork" + _queryStr;            
            return httpApi.get(url, _parameters);
        }

        return obj;
    }]);
