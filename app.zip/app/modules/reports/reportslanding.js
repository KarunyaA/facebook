dashboard.controller("reportslandingController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'twitterGetPost', 'apiService', '$q',
    function($rootScope, $scope, $state, catalyst, $location, Flash, $window, $http, $filter, $compile, appSettings, twitterGetPost, apiService, $q) {
      $scope.navigatePage=function(page){
          console.log(page);
          if(page == "camp"){
              $state.go('app.campaigneffectivenessReport');
          }
          if(page == "action"){
              $state.go('app.actionareaIdentifierReport');
          }
          if(page == "flow"){
              $state.go('app.funnelFlowReport');
          }
      };    
      
    }
]);