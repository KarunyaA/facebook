dashboard.controller("campaigneffectiveController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', 'appSettings', 'apiService', '$filter', '$timeout', 'globalData','performanceServices',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, appSettings, apiService, $filter, $timeout, globalData,performanceServices) {
        // $rootScope.progressLoader = "block";
        $scope.datedifference = 0;
        $scope.selectedParentChildCampaign = "";
        $scope.campaignSummaryMetrics = [];
        $scope.tableData = [];
        $scope.accountRole = true;
        $scope.networksforaccount = [];
        $scope.reportTypes = "reset";
        $scope.reportTypesArchived = "reset";
        $scope.userRole = $window.localStorage.getItem("role");
        $scope.todayDate = new Date().toISOString().slice(0, 10);
        $scope.selectedParentCampaign;
        $scope.selectedChildCampaign;
        $scope.wholeParentArrayOnLoad = [];
        $scope.wholeChildArrayOnLoad = [];
        $scope.totalSpendforAllNetwork = 0;
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.networkDropDownOnLoad = [];
        $scope.campaignDropDown = [];
        $scope.advertiserSelect = [];
        $scope.Advertisers = [];
        $scope.dateArray = [];
        $scope.dateDiff = 0;
        $scope.monthDiff = 0;
        $scope.yearDiff = 0;
        $scope.networksforaccount = [];
        $scope.advertiserdetails = {};
        $scope.bool = [];
        $scope.networksarrayforacc = [];
        $scope.wholeParentArray = [];
        $scope.wholechildArray = [];
        $scope.childIdArray = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforadvertiser = [];
        $scope.networkmaparray = [];
        $scope.networkmaparrayonload = [];
        $scope.errors = [];
        var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        var apiTwitterBase = appSettings.apiTwitterBase;
        $scope.barGraphDt = [];
        $scope.pieChartDataClicks = [];
        $scope.pieChartDataActions = [];
        $scope.pieChartDataEngagements = [];
        $scope.pie1 = [];
        $scope.pie2 = [];
        $scope.pie3 = [];
        $scope.pie4 = [];
        $scope.breakdown = "";
        $scope.tableinsights = [];
        $scope.reportHistory = [];
        $scope.reportType = [];
        $scope.archivedData = [];
        $scope.networkmaparrayonLoadData = [];
        $scope.tableDt = [];
        $scope.pieChartDataEngagements = [];
        $scope.pieChartDataClicks = [];
        $scope.pieChartDataActions = [];
        $scope.legends = false;
        var total = 0;
        var finalTotal = 0;
        var length;
        $scope.actions = false;
        $scope.engagements = false;
        $scope.type = 'table';
        var grouped_bar_graph;
        var dfc;
        var dfc1;
        var dfc2;
        var dfc4;
        var dfc5;
        var dfcpie1;
        var dfcpie2;
        var dfcpie3;
        var dfcpie4;
        angular.element('#apply').prop("disabled", true);
        $("#img2").css("pointer-events", "none");
        $("#img3").css("pointer-events", "none");
        $("#img2").css("opacity", "0.5");
        $("#img3").css("opacity", "0.5");
        angular.element("#box-inner").animate({
            width: "toggle"
        });

        angular.element(document).ready(function () {
            angular.element("#slide-toggle").click(function () {
                angular.element("#box-inner").animate({
                    width: "toggle"
                });
            });
        });

        angular.element("#box-inner1").animate({
            width: "toggle"
        });

        angular.element(document).ready(function () {
            angular.element("#slide-toggle1").click(function () {
                angular.element("#box-inner1").animate({
                    width: "toggle"
                });
            });
        });
        $scope.handleErrors = function ()
        {
            var errorCheck = false;
            $scope.errorHeader = [];
            $scope.errorString = [];
            for (a = 0; a < $scope.errors.length; a++)
            {
                if ($scope.errors[a].hasOwnProperty("networkDetails"))
                {
                    for (b = 0; b < $scope.errors[a].networkDetails.length; b++)
                    {
                        var netLogo = "";
                        if ($scope.errors[a].networkDetails[b].networkURL == appSettings.fbNetwork)
                        {
                            netLogo = "images/accountDashboard/facebook.svg";
                        } else if ($scope.errors[a].networkDetails[b].networkURL == appSettings.twNetwork)
                        {
                            netLogo = "images/accountDashboard/twitter.svg";
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("adAccountIdError"))
                        {
                            errorCheck = true;
                            var obj = {
                                "Advertiser": "Advertiser: ",
                                "AdvertiserValue": $scope.errors[a].advertiserName,
                                "NetworkLogo": netLogo,
                                "ParentCampaign": "",
                                "ParentCampaignValue": "",
                                "ChildCampaign": "",
                                "ChildCampaignValue": ""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].adAccountIdError.ErrorMessage);
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("parentCampaignError"))
                        {
                            errorCheck = true;
                            var obj = {
                                "Advertiser": "Advertiser: ",
                                "AdvertiserValue": $scope.errors[a].advertiserName,
                                "NetworkLogo": netLogo,
                                "ParentCampaign": "",
                                "ParentCampaignValue": "",
                                "ChildCampaign": "",
                                "ChildCampaignValue": ""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].parentCampaignError.ErrorMessage);
                        }
                        if ($scope.errors[a].networkDetails[b].hasOwnProperty("parent"))
                        {
                            for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++)
                            {
                                if ($scope.errors[a].networkDetails[b].parent[c].hasOwnProperty("childCampaignError"))
                                {
                                    errorCheck = true;
                                    var obj = {
                                        "Advertiser": "Advertiser: ",
                                        "AdvertiserValue": $scope.errors[a].advertiserName,
                                        "NetworkLogo": netLogo,
                                        "ParentCampaign": "Parent Campaign: ",
                                        "ParentCampaignValue": $scope.errors[a].networkDetails[b].parent[c].name,
                                        "ChildCampaign": "",
                                        "ChildCampaignValue": ""
                                    };
                                    $scope.errorHeader.push(obj);
                                    $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].childCampaignError.ErrorMessage);
                                }
                                for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++)
                                {
                                    if ($scope.errors[a].networkDetails[b].parent[c].campaigns[d].hasOwnProperty("campaignInsightsError"))
                                    {
                                        errorCheck = true;
                                        var obj = {
                                            "Advertiser": "Advertiser: ",
                                            "AdvertiserValue": $scope.errors[a].advertiserName,
                                            "NetworkLogo": netLogo,
                                            "ParentCampaign": "Parent Campaign: ",
                                            "ParentCampaignValue": $scope.errors[a].networkDetails[b].parent[c].name,
                                            "ChildCampaign": "Child Campaign: ",
                                            "ChildCampaignValue": $scope.errors[a].networkDetails[b].parent[c].campaigns[d].name
                                        };
                                        $scope.errorHeader.push(obj);
                                        $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].campaigns[d].campaignInsightsError.ErrorMessage);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (errorCheck)
            {
                angular.element("#errorScroll").css("height", "auto");
                angular.element("#errorScroll").css("overflow-y", "hidden");
                angular.element("#moreErrors").css("display", "flex");
                angular.element("#lessErrors").css("display", "none");
                $scope.campEffectReportErrors = 'block';
                angular.element("#campEffectReportErrors").empty();
                for (a = 0; a < $scope.errorHeader.length && a < 2; a++)
                {
                    angular.element("#campEffectReportErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:20px;'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                            "</div>" +
                            "</div>" +
                            "</div>"
                            );
                }
            } else {
                console.log("no errors");
            }
        };
        $scope.resetPopup = function () {
            $scope.editAdsetErrorMsg = 'none';
            $scope.campEffectReportErrors = "none";
            angular.element("#errorScroll").scrollTop(0);
        };

        $scope.loadBarGraph = function ()
        {
            $rootScope.progressLoader = "none";
            $('#campaignEffectivessReport_barGraph').empty();
            for (var i = 0; i < $scope.selectedcampaign.length; i++)
            {
                if ($scope.selectedcampaign[i].networkURL == appSettings.fbNetwork)
                {
                    $scope.actions = true;
                    $scope.engagements = false;
                } else if ($scope.selectedcampaign[i].networkURL == appSettings.twNetwork)
                {
                    $scope.engagements = true;
                    $scope.actions = false;
                }
            }
            if ($scope.barGraphDt.length != 0) {
                $scope.nographbar = false;
                grouped_bar_graph = cviz.widget.GroupedColumn.Runner({
                    id: "1",
                    container: {
                        id: '#campaignEffectivessReport_barGraph',
                        title: '',
                        titlePos: 15,
                        titleTooltip: 'Grouped Column',
                        width: 1500,
                        height: 450,
                        showGrid: 'yes',
                        contextBrush: 'yes',
                        showLines: 'yes'
                    },
                    bindings: {
                        x: 'campaign',
                        y: 'scale',
                        item: 'product',
                        group: 'product'
                    },
                    margin: {
                        top: 50,
                        right: 70,
                        bottom: 50,
                        left: 54
                    },
                    scaling: {x: 4, y: 1},
                    scaleFormat: {x: ' ', y: ' '},
                    ticks: {y: 10},
                    tickerAngle: {x: 0},
                    columnGloss: 'no',
                    padding: 0,
                    axisRange: {
                        y: {min: 0, max: $scope.maxImp}
                    },
                    labels: {x: 'Campaign', y: 'Scale'},
                    colors: {
                        'Impressions': '#03A9F4',
                        'Engagements': '#3ab94a',
                        'Clicks': '#ffc20b',
                        'Actions': '#b388ff'
                    },
                    tooltip: {
                        bindings: [{
                                label: 'campaign',
                                bindWith: 'campaign'
                            }, {
                                label: 'product',
                                bindWith: 'product'
                            }, {
                                label: 'scale',
                                bindWith: 'scale'
                            }]
                    },
                    labels: {x: " ", y: " "}
                })
                //Actual function call to render the Bar graph
                grouped_bar_graph.graph().render($scope.barGraphDt);
                $scope.legends = true;
                // Setting the height manually
                var $groupedColumn = $("#campaignEffectivessReport_barGraph").find("#grouped-column");
                $groupedColumn.css("margin-top", "-68px");
                // Applying style for y axis scale
                var $yAxis = $("#campaignEffectivessReport_barGraph").find("#grouped-column").find(".y.axis").find('g.tick');
                $yAxis.each(function (index) {
                    var $htmlVal = $(this).html();
                    $htmlVal = $htmlVal.replace("-5", "-20");
                    $(this).html($htmlVal);
                });
                // Applying style for x axis scale
                var $xAxis = $("#campaignEffectivessReport_barGraph").find("#grouped-column").find(".x.axis").first().find('g.tick');
                $xAxis.each(function (index) {
                    var $htmlVal = $(this).find('text').html();
                    $htmlVal = $htmlVal.replace("5", "20");
                    $(this).find('text').html($htmlVal);
                });
            } else {
                $scope.nographbar = true;
            }

        };
        $scope.nopiecount = 0;
        $scope.actioncount = 0;
        $scope.engagementcount = 0;
        $scope.loadpieChart = function ()
        {
            $scope.actioncount = 0;
            $scope.engagementcount = 0;
            $rootScope.progressLoader = "none";
            $scope.values1 = [];
            var total = 0;
            var finalTotal = 0;
            for (i = 0; i < $scope.selectedcampaign.length; i++) {
                if ($scope.selectedcampaign[i].networkUrl == appSettings.fbNetwork) {
                    $scope.actioncount++;
                } else if ($scope.selectedcampaign[i].networkUrl == appSettings.twNetwork) {
                    $scope.engagementcount++;
                }
            }
            angular.forEach($scope.pieChartDataClicks, function (v, k1)
            {
                total = total + v.Clicks;

            });
            angular.forEach($scope.pieChartDataClicks, function (v, k1)
            {
                if (v.Clicks != 0) {
                    finalTotal = (v.Clicks / total) * 100;
                    $scope.pie1 = {"campaignName": v.campaignName, "Clicks": v.Clicks, "PercentClicks": Math.round(finalTotal)};
                    $scope.values1.push($scope.pie1);
                } else {
                    $scope.pie1 = {"campaignName": v.campaignName, "Clicks": v.Clicks, "PercentClicks": 0};
                    $scope.values1.push($scope.pie1);
                }
            });
            //PIE_CHART1
            if ($scope.values1.length != 0) {
                $scope.nographpie1 = false;
                dfcpie1 = cviz.widget.DoughnutChart.Runner({
                    id: '1',
                    container: {
                        id: '#pieChart1',
                        title: 'Clicks',
                        width: 300,
                        height: 300,
                        titlePos: 20,
                        x: 0,
                        y: 0
                    },
                    bindings: {
                        pie: 'campaignName',
                        value: 'PercentClicks'
                    },
                    gloss: 'no',
                    margin: {
                        top: 40,
                        left: 50,
                        bottom: 30,
                        right: 10
                    },
                    radius: {
                        inner: 100,
                        outer: 0
                    },
                    tooltip: {
                        bindings: [
                            {label: 'campaignName', bindWith: 'campaignName'},
                            {label: 'Clicks', bindWith: 'Clicks'}]
                    }
                })
                dfcpie1.graph().render($scope.values1);
                document.getElementById("pieChart1").children[0].children[0].children[0].setAttribute('y', '160');
                document.getElementById("pieChart1").children[0].setAttribute('height', '400');
                $("#pieChart1 .arc path").css("fill-opacity", "1");
                $("#pieChart1 .arc path").eq(0).css("fill", "rgb(65,167,235)");
                $("#pieChart1 .arc path").eq(1).css("fill", "rgb(247,113,69)");
                $("#pieChart1 .arc path").eq(2).css("fill", "rgb(253,167,56)");
                $("#pieChart1 .arc path").eq(3).css("fill", "rgb(64,198,147)");
                $("#pieChart1 .arc path").eq(4).css("fill", "rgb(85,195,91)");
            } else {
                $scope.nographpie1 = true;
                $scope.pieChartDataClicks = [];
                $('#pieChart1').empty();
            }

            total = 0;
            finalTotal = 0;
            $scope.values2 = [];
            angular.forEach($scope.pieChartDataImpressions, function (v, k1)
            {
                total = total + v.Impressions;
            });
            angular.forEach($scope.pieChartDataImpressions, function (v, k1)
            {
                if (v.Impressions != 0) {
                    finalTotal = (v.Impressions / total) * 100;
                    $scope.pie2 = {"campaignName": v.campaignName, "Impressions": v.Impressions, "PercentageImp": Math.round(finalTotal)};
                    $scope.values2.push($scope.pie2);
                } else {
                    $scope.pie2 = {"campaignName": v.campaignName, "Impressions": v.Impressions, "PercentageImp": 0};
                    $scope.values2.push($scope.pie2);
                }
            });
            //PIE_CHART2
            if ($scope.values2.length != 0) {
                $scope.nographpie2 = false;
                dfcpie2 = cviz.widget.DoughnutChart.Runner({
                    id: '2',
                    container: {
                        id: '#pieChart2',
                        title: 'Impressions',
                        width: 300,
                        height: 300,
                        titlePos: 20,
                        x: 0,
                        y: 0
                    },
                    bindings: {
                        pie: 'campaignName',
                        value: 'PercentageImp'
                    },
                    gloss: 'no',
                    margin: {
                        top: 40,
                        left: 50,
                        bottom: 30,
                        right: 10
                    },
                    radius: {
                        inner: 100,
                        outer: 0
                    },
                    tooltip: {
                        bindings: [
                            {label: 'campaignName', bindWith: 'campaignName'},
                            {label: 'Impressions', bindWith: 'Impressions'}]
                    }
                })
                dfcpie2.graph().render($scope.values2);
                document.getElementById("pieChart2").children[0].children[0].children[0].setAttribute('y', '160');
                document.getElementById("pieChart2").children[0].setAttribute('height', '400');
                $("#pieChart2 .arc path").css("fill-opacity", "1");
                $("#pieChart2 .arc path").eq(0).css("fill", "rgb(65,167,235)");
                $("#pieChart2 .arc path").eq(1).css("fill", "rgb(247,113,69)");
                $("#pieChart2 .arc path").eq(2).css("fill", "rgb(253,167,56)");
                $("#pieChart2 .arc path").eq(3).css("fill", "rgb(64,198,147)");
                $("#pieChart2 .arc path").eq(4).css("fill", "rgb(85,195,91)");
            } else {
                $scope.nographpie2 = true;
                $scope.pieChartDataImpressions = [];
                $('#pieChart2').empty();

            }
            total = 0;
            finalTotal = 0;
            $scope.values3 = [];
            angular.forEach($scope.pieChartDataActions, function (v, k1)
            {
                if (v.actions != 0 && v.actions != null && v.actions != 'undefined') {
                    total = total + v.actions;
                } else {
                    total = total + 0;
                }
            });
            angular.forEach($scope.pieChartDataActions, function (v, k1)
            {
                if (v.actions != 0 && v.actions != null && v.actions != 'undefined') {
                    finalTotal = (v.actions / total) * 100;
                    $scope.pie3 = {"campaignName": v.campaignName, "actions": v.actions, "PercentageActions": Math.round(finalTotal)};
                    $scope.values3.push($scope.pie3);
                } else {
                    $scope.pie3 = {"campaignName": v.campaignName, "actions": 0, "PercentageActions": 0};
                    $scope.values3.push($scope.pie3);
                }
            });
            console.log(JSON.stringify($scope.values3, null, 2));
            if ($scope.values3.length != 0 && $scope.actioncount != 0) {
                $('#pieChart3').empty();
                $scope.nographpie3 = false;
                dfcpie3 = cviz.widget.DoughnutChart.Runner({
                    id: '3',
                    container: {
                        id: '#pieChart3',
                        title: 'Actions',
                        width: 300,
                        height: 300,
                        titlePos: 20
                    },
                    bindings: {
                        pie: 'campaignName',
                        value: 'PercentageActions',
                        color: 'campaignName'
                    },
                    colors: {
                        'Campaign1': 'rgb (233, 149, 137)',
                        'Campaign2': 'rgb (253, 174, 107)',
                        'Campaign3': 'rgb (184, 63, 83)',
                        'Campaign4': 'rgb (38, 110, 179)'
                    },
                    gloss: 'no',
                    margin: {
                        top: 40,
                        left: 50,
                        bottom: 30,
                        right: 10
                    },
                    radius: {
                        inner: 100,
                        outer: 0
                    },
                    tooltip: {
                        bindings: [
                            {label: 'campaignName', bindWith: 'campaignName'},
                            {label: 'actions', bindWith: 'actions'}]
                    }
                })
                dfcpie3.graph().render($scope.values3);
                document.getElementById("pieChart3").children[0].children[0].children[0].setAttribute('y', '160');
                document.getElementById("pieChart3").children[0].setAttribute('height', '400');
                $("#pieChart3 .arc path").css("fill-opacity", "1");
                $("#pieChart3 .arc path").eq(0).css("fill", "rgb(65,167,235)");
                $("#pieChart3 .arc path").eq(1).css("fill", "rgb(247,113,69)");
                $("#pieChart3 .arc path").eq(2).css("fill", "rgb(253,167,56)");
                $("#pieChart3 .arc path").eq(3).css("fill", "rgb(64,198,147)");
                $("#pieChart3 .arc path").eq(4).css("fill", "rgb(85,195,91)");
            } else if ($scope.values3.length == 0) {
                console.log($scope.values3.length);
                console.log('iiiiiiiiii')
                $scope.nographpie3 = true;
                $scope.pieChartDataActions = [];
                $('#pieChart3').empty();
            }
            total = 0;
            finalTotal = 0;
            $scope.values4 = [];
            angular.forEach($scope.pieChartDataEngagements, function (v, k1)
            {
                if (v.Engagements != 0 && v.Engagements != null && v.Engagements != 'undefined') {
                    total = total + v.Engagements;
                }
            });
            angular.forEach($scope.pieChartDataEngagements, function (v, k1)
            {
                if (v.Engagements != 0 && v.Engagements != null && v.Engagements != 'undefined') {
                    finalTotal = (v.Engagements / total) * 100;
                    $scope.pie4 = {"campaignName": v.campaignName, "Engagements": v.Engagements, "PercentageEngagements": Math.round(finalTotal)};
                    $scope.values4.push($scope.pie4);
                } else {
                    $scope.pie4 = {"campaignName": v.campaignName, "Engagements": 0, "PercentageEngagements": 0};
                    $scope.values4.push($scope.pie4);
                }

            });
            if ($scope.values4.length != 0 && $scope.engagementcount != 0) {
                $scope.nographpie4 = false;
                $('#pieChart4').empty();
                dfcpie4 = cviz.widget.DoughnutChart.Runner({
                    id: '4',
                    container: {
                        id: '#pieChart4',
                        title: 'Engagements',
                        width: 300,
                        height: 300,
                        titlePos: 20
                    },
                    bindings: {
                        pie: 'campaignName',
                        value: 'PercentageEngagements',
                        color: 'campaignName'
                    },
                    colors: {
                        'Campaign1': 'rgb (233, 149, 137)',
                        'Campaign2': 'rgb (253, 174, 107)',
                        'Campaign3': 'rgb (184, 63, 83)',
                        'Campaign4': 'rgb (38, 110, 179)'
                    },
                    gloss: 'no',
                    margin: {
                        top: 40,
                        left: 50,
                        bottom: 30,
                        right: 10
                    },
                    radius: {
                        inner: 100,
                        outer: 0
                    },
                    tooltip: {
                        bindings: [
                            {label: 'campaignName', bindWith: 'campaignName'},
                            {label: 'Engagements', bindWith: 'Engagements'}]
                    }
                });
                dfcpie4.graph().render($scope.values4);
                document.getElementById("pieChart4").children[0].children[0].children[0].setAttribute('y', '160');
                document.getElementById("pieChart4").children[0].setAttribute('height', '400');
                $("#pieChart4 .arc path").css("fill-opacity", "1");
                $("#pieChart4 .arc path").eq(0).css("fill", "rgb(65,167,235)");
                $("#pieChart4 .arc path").eq(1).css("fill", "rgb(247,113,69)");
                $("#pieChart4 .arc path").eq(2).css("fill", "rgb(253,167,56)");
                $("#pieChart4 .arc path").eq(3).css("fill", "rgb(64,198,147)");
                $("#pieChart4 .arc path").eq(4).css("fill", "rgb(85,195,91)");
                $("#pieChart4 circle").css("fill", "rgb(247,113,69)");
            } else {
                $scope.nographpie4 = true;
                $scope.pieChartDataEngagements = [];
                $('#pieChart4').empty();
            }
            length = $scope.pieChartDataClicks.length;
            var x = document.querySelectorAll('#pieChart1');
            for (var i = 3; i < length + 3; i++) {
                x[0].children[0].children[0].children[i].children[1].append('%');
            }

            var y = document.querySelectorAll('#pieChart2');
            for (var i = 3; i < length + 3; i++) {
                y[0].children[0].children[0].children[i].children[1].append('%');
            }
            if ($scope.actioncount != 0)
            {
                var y = document.querySelectorAll('#pieChart3');
                for (var i = 3; i < length + 3; i++) {
                    y[0].children[0].children[0].children[i].children[1].append('%');
                }
            }
            if ($scope.engagementcount != 0)
            {
                var y = document.querySelectorAll('#pieChart4');
                for (var i = 3; i < length + 3; i++) {
                    y[0].children[0].children[0].children[i].children[1].append('%');
                }
            }

        };

        $scope.arrowDirectionChange = function (parentobj, _index)
        {
            for (i = 0; i < $scope.wholeParentArray.length; i++)
            {
                if ($scope.wholeParentArray[i].id != parentobj.id)
                {
                    $scope.bool[$scope.wholeParentArray[i].id] = false;
                    var el = angular.element('#parent' + (i + 1));
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            $scope.bool[parentobj.id] = !$scope.bool[parentobj.id];
            if ($scope.bool[parentobj.id])
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
            } else
            {
                var el = angular.element('#parent' + _index);
                el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
            }
        };

        $scope.resetCalender = function () {
            $scope.from = "";
            $scope.to = "";
            $scope.from1 = "";
            $scope.to1 = "";
            $scope.mindate = "";
            $rootScope.progressLoader = "block";
            $scope.networkmaparray = angular.copy($scope.networkmaparrayonLoadData);
            $scope.resetFilter();
        };

        function localDateTimetoUTCDateTime(date) {
            var d = new Date(date);
            var utcDate = d.toUTCString();
            return new Date(utcDate).toISOString().slice(0, 10);
        }

        $scope.updateNetworkDropDown = function () {
            var networkArray = [];
            $scope.networkDropDown = [];
            var count;
            if ($scope.selectedAdvertiser.length == 0) {
                $scope.Advertisers = angular.copy($scope.advertiserDropDown);
            } else {
                $scope.Advertisers = angular.copy($scope.selectedAdvertiser);
            }
            for (var k = 0; k < $scope.Advertisers.length; k++)
            {
                for (i = 0; i < $scope.networkmaparray.length; i++)
                {
                    if ($scope.Advertisers[k].advertiserName == $scope.networkmaparray[i].advertiserName)
                    {
                        if ($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++)
                            {
                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    var obj = {
                                        "networkId": $scope.networkmaparray[i].networkDetails[j].networkId,
                                        "networkName": $scope.networkmaparray[i].networkDetails[j].networkName,
                                        "networkURL": $scope.networkmaparray[i].networkDetails[j].networkURL
                                    };
                                    count = 0;
                                    for (u = 0; u < networkArray.length; u++)
                                    {
                                        if (networkArray[u].networkId == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            count++;
                                    }
                                    if (count == 0)
                                        networkArray.push(obj);
                                }
                            }
                        }
                    }
                }
                $scope.networkDropDown = angular.copy(networkArray);
            }
        };

        $scope.updateCampaignDropDown = function ()
        {
            $scope.wholeParentArray = [];
            $scope.wholechildArray = [];
            $scope.tableinsights = [];
            var count;
            if ($scope.selectednewtwork.length == 0) {
                $scope.networks = angular.copy($scope.networkDropDown);
            } else {
                $scope.type = 'table';
                $scope.networks = angular.copy($scope.selectednewtwork);
            }
            for (var k = 0; k < $scope.Advertisers.length; k++)
            {
                for (var j = 0; j < $scope.networks.length; j++)
                {
                    for (var i = 0; i < $scope.networkmaparray.length; i++)
                    {
                        if ($scope.Advertisers[k].advertiserName == $scope.networkmaparray[i].advertiserName)
                        {
                            if ($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for (var t = 0; t < $scope.networkmaparray[i].networkDetails.length; t++)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[t].hasOwnProperty("adAccountId"))
                                    {
                                        if ($scope.networkmaparray[i].networkDetails[t].networkId == $scope.networks[j].networkId)
                                        {
                                            for (var y = 0; y < $scope.networkmaparray[i].networkDetails[t].parent.length; y++)
                                            {
                                                var obj = {
                                                    "id": $scope.networkmaparray[i].networkDetails[t].parent[y].id,
                                                    "name": $scope.networkmaparray[i].networkDetails[t].parent[y].name,
                                                    "type": "parent",
                                                };
                                                count = 0;
                                                for (u = 0; u < $scope.wholeParentArray.length; u++)
                                                {
                                                    if ($scope.wholeParentArray[u].id == $scope.networkmaparray[i].networkDetails[t].parent[y].id)
                                                        count++;
                                                }
                                                if (count == 0)
                                                    $scope.wholeParentArray.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (var k = 0; k < $scope.Advertisers.length; k++)
            {
                for (var j = 0; j < $scope.networks.length; j++)
                {
                    for (var i = 0; i < $scope.networkmaparray.length; i++)
                    {
                        if ($scope.Advertisers[k].advertiserName == $scope.networkmaparray[i].advertiserName)
                        {
                            if ($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for (var t = 0; t < $scope.networkmaparray[i].networkDetails.length; t++)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[t].hasOwnProperty("adAccountId"))
                                    {
                                        if ($scope.networkmaparray[i].networkDetails[t].networkId == $scope.networks[j].networkId)
                                        {
                                            for (var y = 0; y < $scope.networkmaparray[i].networkDetails[t].parent.length; y++)
                                            {
                                                for (var f = 0; f < $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns.length; f++)
                                                {
                                                    var obj = {
                                                        "id": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].id,
                                                        "name": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].name,
                                                        "type": "child",
                                                        "parentid": $scope.networkmaparray[i].networkDetails[t].parent[y].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[t].userNetworkMapId,
                                                        "networkUrl": $scope.networkmaparray[i].networkDetails[t].networkURL,
                                                        "networkName": $scope.networkmaparray[i].networkDetails[t].networkName,
                                                        "startDate": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].campStartDate,
                                                        "endDate": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].campEndDate,
                                                        "Objective": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].objective
                                                    };
                                                    count = 0;
                                                    for (u = 0; u < $scope.wholechildArray.length; u++)
                                                    {
                                                        if ($scope.wholechildArray[u].id == $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].id)
                                                            count++;
                                                    }
                                                    if (count == 0)
                                                    {
                                                        $scope.wholechildArray.push(obj);
                                                        if ($scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].insights.length != 0)
                                                        {
                                                            obj['insights'] = $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].insights;
                                                            obj['budget'] = $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].budget;
                                                            $scope.tableinsights.push(obj);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };

        $scope.updateNetworkCampaignDropDown = function ()
        {
            $scope.campaign = "";
            $scope.tableinsights = [];
            $scope.wholeParentArray = [];
            $scope.wholechildArray = [];
            var count;
            if ($scope.selectedAdvertiser.length == 0)
            {
                $scope.Advertisers = angular.copy($scope.advertiserDropDown);
            } else
            {
                $scope.Advertisers = angular.copy($scope.selectedAdvertiser);
            }
            for (var k = 0; k < $scope.selectednewtwork.length; k++)
            {
                for (var j = 0; j < $scope.Advertisers.length; j++)
                {
                    for (var i = 0; i < $scope.networkmaparray.length; i++)
                    {
                        if ($scope.Advertisers[j].advertiserName == $scope.networkmaparray[i].advertiserName)
                        {
                            if ($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for (var t = 0; t < $scope.networkmaparray[i].networkDetails.length; t++)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[t].hasOwnProperty("adAccountId"))
                                    {
                                        if ($scope.networkmaparray[i].networkDetails[t].networkId == $scope.selectednewtwork[k].networkId)
                                        {
                                            for (var y = 0; y < $scope.networkmaparray[i].networkDetails[t].parent.length; y++)
                                            {
                                                var obj = {
                                                    "id": $scope.networkmaparray[i].networkDetails[t].parent[y].id,
                                                    "name": $scope.networkmaparray[i].networkDetails[t].parent[y].name,
                                                    "type": "parent",
                                                };
                                                count = 0;
                                                for (u = 0; u < $scope.wholeParentArray.length; u++)
                                                {
                                                    if ($scope.wholeParentArray[u].id == $scope.networkmaparray[i].networkDetails[t].parent[y].id)
                                                        count++;
                                                }
                                                if (count == 0)
                                                    $scope.wholeParentArray.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (var k = 0; k < $scope.selectednewtwork.length; k++)
            {
                for (var j = 0; j < $scope.Advertisers.length; j++)
                {
                    for (var i = 0; i < $scope.networkmaparray.length; i++)
                    {
                        if ($scope.Advertisers[j].advertiserName == $scope.networkmaparray[i].advertiserName)
                        {
                            if ($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for (var t = 0; t < $scope.networkmaparray[i].networkDetails.length; t++)
                                {
                                    if ($scope.networkmaparray[i].networkDetails[t].hasOwnProperty("adAccountId"))
                                    {
                                        if ($scope.networkmaparray[i].networkDetails[t].networkId == $scope.selectednewtwork[k].networkId)
                                        {
                                            for (var y = 0; y < $scope.networkmaparray[i].networkDetails[t].parent.length; y++)
                                            {
                                                for (var f = 0; f < $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns.length; f++)
                                                {
                                                    var obj = {
                                                        "id": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].id,
                                                        "name": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].name,
                                                        "type": "child",
                                                        "parentid": $scope.networkmaparray[i].networkDetails[t].parent[y].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[t].userNetworkMapId,
                                                        "networkUrl": $scope.networkmaparray[i].networkDetails[t].networkURL,
                                                        "networkName": $scope.networkmaparray[i].networkDetails[t].networkName,
                                                        "startDate": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].campStartDate,
                                                        "endDate": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].campEndDate,
                                                        "Objective": $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].objective,
                                                        "networkId": $scope.networkmaparray[i].networkDetails[t].networkId
                                                    };
                                                    count = 0;
                                                    for (u = 0; u < $scope.wholechildArray.length; u++) {
                                                        if ($scope.wholechildArray[u].id == $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].id)
                                                            count++;
                                                    }
                                                    if (count == 0)
                                                    {
                                                        $scope.wholechildArray.push(obj);
                                                        if ($scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].insights.length != 0)
                                                        {
                                                            obj['insights'] = $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].insights;
                                                            obj['budget'] = $scope.networkmaparray[i].networkDetails[t].parent[y].campaigns[f].budget;
                                                            $scope.tableinsights.push(obj);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
        };

        $scope.updateTableforselectedCampaign = function ()
        {
            console.log(JSON.stringify($scope.networkmaparray, null, 2));
            $scope.tableinsights = [];
            for (i = 0; i < $scope.selectedcampaign.length; i++)
            {
                for (j = 0; j < $scope.networkmaparray.length; j++)
                {
                    if ($scope.networkmaparray[j].hasOwnProperty('networkDetails'))
                    {
                        for (k = 0; k < $scope.networkmaparray[j].networkDetails.length; k++)
                        {
                            if ($scope.networkmaparray[j].networkDetails[k].hasOwnProperty('adAccountId'))
                            {
                                for (var y = 0; y < $scope.networkmaparray[j].networkDetails[k].parent.length; y++)
                                {
                                    for (var f = 0; f < $scope.networkmaparray[j].networkDetails[k].parent[y].campaigns.length; f++)
                                    {
                                        if ($scope.networkmaparray[j].networkDetails[k].parent[y].campaigns[f].id == $scope.selectedcampaign[i].id)
                                        {
                                            if ($scope.networkmaparray[j].networkDetails[k].parent[y].campaigns[f].insights.length != 0)
                                            {
                                                $scope.selectedcampaign[i]['insights'] = $scope.networkmaparray[j].networkDetails[k].parent[y].campaigns[f].insights;
                                                $scope.selectedcampaign[i]['budget'] = $scope.networkmaparray[j].networkDetails[k].parent[y].campaigns[f].budget;
                                                $scope.tableinsights.push($scope.selectedcampaign[i]);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            console.log($scope.tableinsights);
        }

        $scope.resetFilter = function () {
            angular.element('#apply').prop("disabled", true);
            $('#pieChart1').empty();
            $('#pieChart2').empty();
            $('#pieChart3').empty();
            $('#pieChart4').empty();
            $('#campaignEffectivessReport_barGraph').empty();
            $scope.legends = false;
            $scope.type = 'table';
            $("#img2").css("pointer-events", "none");
            $("#img3").css("pointer-events", "none");
            $("#img2").css("opacity", "0.5");
            $("#img3").css("opacity", "0.5");
            $scope.network = "";
            $scope.campaign = "";
            $scope.advertiserDropDown = angular.copy($scope.advertiserOnLoad);
            $scope.networkDropDown = angular.copy($scope.networkDropDownOnLoad);
            $scope.wholeParentArray = angular.copy($scope.wholeParentArrayOnLoad);
            $scope.wholechildArray = angular.copy($scope.wholeChildArrayOnLoad);
            if ($scope.userRole == "Account") {
                $scope.selectedAdvertiser = [];
            }
            $scope.selectednewtwork = [];
            $scope.selectedcampaign = [];
            $scope.reportTypes = "reset";
            $scope.subscription = "";
            $scope.fillTableOnload();
        }
        $scope.fromAndToChanged = function () {
            $scope.mindate = $filter('date')($scope.from1, 'yyyy-MM-dd');
            $scope.from = $filter('date')($scope.from1, 'yyyy-MM-dd');
            $scope.to = $filter('date')($scope.to1, 'yyyy-MM-dd');
            if ($scope.from != undefined && $scope.to != undefined && $scope.from != "" && $scope.to != "") {
                if (new Date($scope.from) <= new Date($scope.to)) {
                    $rootScope.progressLoader = "block";
                    var date = new Date();
                    var hour = date.getHours();
                    var hour1 = hour > 10 ? '0' + hour : hour;
                    var min = date.getMinutes();
                    var min1 = min > 10 ? '0' + min : min;
                    var sec = date.getSeconds();
                    var sec1 = sec > 10 ? '0' + sec : sec;
                    var fromDateTime = $scope.from + " " + hour1 + ":" + min1 + ":" + sec1;
                    var toDateTime = $scope.to + " " + hour1 + ":" + min1 + ":" + sec1;
                    $scope.UTCFromDate = localDateTimetoUTCDateTime(fromDateTime);
                    $scope.UTCToDate = localDateTimetoUTCDateTime(toDateTime);
                    $scope.calculateDateDiff($scope.UTCFromDate, $scope.UTCToDate);
                } else {
                    $scope.from = "";
                    $scope.to = "";
                    $scope.from1 = "";
                    $scope.to1 = "";
                }
            }
        };

        $scope.calculateDateDiff = function (from, to) {
            $scope.currentDate = new Date(from);
            $scope.toDateNumber = new Date(to).getDate();
            $scope.toMonth = new Date(to).getMonth() + 1;
            $scope.toYear = new Date(to).getFullYear();
            $scope.fromDateNumber = new Date(from).getDate();
            $scope.fromMonth = new Date(from).getMonth() + 1;
            $scope.fromYear = new Date(from).getFullYear();
            $scope.monthDiff = $scope.toMonth - $scope.fromMonth;
            $scope.yearDiff = $scope.toYear - $scope.fromYear;
            $scope.breakdown = "";
            $scope.datedifference = 0;
            $scope.networkmaparray = [];
            $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
            while ($scope.currentDate <= new Date(to))
            {

                $scope.currentDate = new Date(new Date($scope.currentDate).getTime() + (1 * 24 * 60 * 60 * 1000));
                $scope.datedifference = $scope.datedifference + 1;
            }
            if ($scope.datedifference >= 1 && $scope.datedifference <= 7)
            {
                $scope.breakdown = "DAILY";
            } else if ($scope.yearDiff >= 1) {
                $scope.breakdown = "YEARLY";
            } else if ($scope.datedifference >= 8 && $scope.datedifference <= 31 && $scope.monthDiff <= 1) {
                $scope.breakdown = "WEEKLY";
            } else if ($scope.datedifference >= 8 && $scope.datedifference <= 31 && $scope.monthDiff > 1) {
                $scope.breakdown = "MONTHLY";
            } else if ($scope.monthDiff >= 1 && $scope.monthDiff <= 3) {
                $scope.breakdown = "MONTHLY";
            } else if ($scope.monthDiff > 3 && $scope.monthDiff <= 6) {
                $scope.breakdown = "QUARTERLY";
            } else if ($scope.monthDiff > 6 && $scope.monthDiff <= 12) {
                $scope.breakdown = "HALFYEARLY";
            } else if ($scope.monthDiff > 12 && $scope.yearDiff < 2) {
                $scope.breakdown = "HALFYEARLY";
            } else if ($scope.monthDiff > 12 && $scope.yearDiff >= 2) {
                $scope.breakdown = "YEARLY";
            }
            if ($scope.archived) {
                $scope.getReportRunHistory();
            } else {
                $scope.readcampaigninsights();
            }

        };


        $scope.getAdvertiserDetails = function () {
            var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response) {
                if (response.appStatus == '0') { // success
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (getAdvertiserDetails)
                        {
                            $scope.allnetworks();
                        }
                    });
        };

        $scope.allnetworks = function () {
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response) {
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (allnetworks)
                        {
                            $scope.networksforacc();
                        }
                    });
        };

        $scope.networksforacc = function ()
        {
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response) {
                if (response.appStatus == '0') { // success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                    for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                        angular.forEach($scope.allnetworksarray, function (val, key) {
                            if ($scope.networksarrayforacc[i].networkId == val.networkId) {
                                if (!$scope.networksforaccount.includes(val.networkName)) {
                                    var obj = {
                                        "networkName": val.networkName,
                                        "networkId": val.networkId
                                    };
                                    $scope.networksforaccount.push(obj);
                                }
                            }
                        });
                    }
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        if (networksforaccount)
                        {
                            $scope.getusernetworkmapids();
                        }
                    });
        };
        $scope.reportHistory = [];
        $scope.getReportRunHistory = function ()
        {
            $scope.reportHistory = [];
            var promises = [];
            promises.push(performanceServices.getreportrunhistory($scope.fromArchived ,$scope.toArchived).then(function (response)
            {
                if (response.appStatus == '0')
                {
                    var reportHistoryResponse = response.reportRunHistoryReadResponse;
                    angular.forEach(reportHistoryResponse, function (val, key)
                    {
                        angular.forEach(val, function (val1, key1)
                        {
                            var obj = val1;
                            $scope.reportHistory.push(obj);
                        });
                    });

                } else {

                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function () {
                        $scope.fillArchivedTable();
                    });

        };
        $scope.reportTypeArchived = [];
        $scope.getReportType = function ()
        {
            var reportType = false;
            var promises = [];
            $scope.reportType = [];
            $scope.archivedData = [];
            $scope.reportTypeArchived = [];
            promises.push(performanceServices.getreporttype().then(function (response)
            {
                if (response.appStatus == '0')
                {
                    reportType = true;
                    var report = response.reportTypeResponse;
                    angular.forEach(report, function (val, key)
                    {
                        angular.forEach(val, function (val1, key1)
                        {
                            var obj = {
                                "reportName": val1.reportName,
                                "reportType": val1.reportType,
                                "reportId": val1.reportId,
                                "reportDesc": val1.reportDescription
                            };
                            $scope.reportType.push(obj);
                            $scope.reportTypeArchived.push(obj);
                        });

                    });
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }))
            $q.all(promises).finally(
                    function () {
                        if (reportType)
                        {
                            if ($scope.from != undefined && $scope.to != undefined && $scope.from != "" && $scope.to != "")
                            {
                                $scope.checkSelectedDropdowns();
                            } else {
                                $scope.networkmaparrayonLoadData = angular.copy($scope.networkmaparray);
                                $scope.fillTableOnload();
                            }
                            $scope.handleErrors();
                        }
                    });
        };

        $scope.getusernetworkmapids = function ()
        {
            var promises = [];
            var readAdAccountSuccess = false;
            angular.forEach($scope.advertiserdetails, function (val, key) {
                var networkdetailobj = [];
                var i = 0;
                var obj = {
                    "advertiseremail": val.advertiserEmail,
                    "advertiserId": val.advertiserId,
                    "advertiserName": val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++) {
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId) {
                        for (var j = 0; j < $scope.allnetworksarray.length; j++) {
                            if ($scope.allnetworksarray[j].networkId == $scope.networksarrayforacc[i].networkId) {
                                var obj2 = {
                                    "networkId": $scope.allnetworksarray[j].networkId,
                                    "networkName": $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId": $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL": $scope.allnetworksarray[j].networkUrl
                                };
                                networkdetailobj.push(obj2);
                            }
                        }
                        ;
                        obj['networkDetails'] = networkdetailobj;
                    }
                }
                $scope.networkmaparrayonload.push(obj);
            });
            $scope.errors = angular.copy($scope.networkmaparrayonload);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails')) {
                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                        (function (i, j) {
                            if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function (response) {
                                    if (response.appStatus == 0) {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.fbReadAdAccountResponse, function (value, key) {
                                            var parent = [];
                                            $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"] = response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = response.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                            $scope.errors[i].networkDetails[j]["adAccountId"] = response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.errors[i].networkDetails[j]["parent"] = angular.copy(parent);
                                        });
                                    } else {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.networkError.message;
                                                } else {
                                                    obj["Error"] = response.networkError.error_user_title;
                                                    obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } else {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            } else if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function (response) {
                                    if (response.appStatus == 0) {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.adAccounts, function (value, key) {
                                            angular.forEach(value, function (value2, key2) {
                                                //                                                console.log(value2,key2);
                                                var parent = [];
                                                $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"] = value2.twAdAccountId;
                                                $scope.networkmaparrayonload[i].networkDetails[j]["currency"] = "";
                                                $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                                $scope.errors[i].networkDetails[j]["adAccountId"] = value2.twAdAccountId;
                                                $scope.errors[i].networkDetails[j]["parent"] = angular.copy(parent);
                                            });
                                        });
                                    } else {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } else {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.networkError.message;
                                                } else {
                                                    obj["Error"] = response.networkError.error_user_title;
                                                    obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } else {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                        })(i, j);
                    }
                }
            }
            $q.all(promises).finally(
                    function () {

                        if (readAdAccountSuccess) {
                            $scope.fillDropDowns();
                        } else {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };
        $scope.multiselectadvertiserDropDown = [];
        $scope.allnetworkDropDown = [];
        $scope.advertiserOnLoad = [];
        $scope.fillDropDowns = function () {
            var promises = [];
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                var obj = {
                    "advertiserName": $scope.networkmaparrayonload[i].advertiserName,
                    "advertiserId": $scope.networkmaparrayonload[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
                $scope.multiselectadvertiserDropDown.push(obj);
                $scope.advertiserOnLoad.push(obj);
                if ($scope.userRole != "Account") {
                    if ($scope.networkmaparrayonload[i].advertiserId == $window.localStorage.getItem("advertiserId")) {
                        $scope.selectedAdvertiser.push(obj);
                    }
                }
            }
            //===========================================================Network Drop Down==================================================================
            var allnetworkswithduplicate = [];
            var allnetworkswithoutduplicate = [];
            var allnetworkswithduplicateobjects = [];
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                        if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                            var obj = {
                                "networkId": $scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                "networkName": $scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                "networkURL": $scope.networkmaparrayonload[i].networkDetails[j].networkURL
                            };
                            allnetworkswithduplicate.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                            allnetworkswithduplicateobjects.push(obj);
                            $scope.allnetworkDropDown.push(obj);
                        }
                    }
                }
            }
            allnetworkswithoutduplicate = allnetworkswithduplicate.filter(function (elem, index, self) {
                return index == self.indexOf(elem);
            });
            for (i = 0; i < allnetworkswithoutduplicate.length; i++) {
                var obj = {
                    "networkId": "",
                    "networkName": allnetworkswithoutduplicate[i],
                    "networkURL": ""
                };
                $scope.networkDropDown.push(obj);
            }
            for (i = 0; i < $scope.networkDropDown.length; i++) {
                for (j = 0; j < allnetworkswithduplicateobjects.length; j++) {
                    if ($scope.networkDropDown[i].networkName == allnetworkswithduplicateobjects[j].networkName) {
                        $scope.networkDropDown[i].networkId = allnetworkswithduplicateobjects[j].networkId;
                        $scope.networkDropDown[i].networkURL = allnetworkswithduplicateobjects[j].networkURL;
                    }
                }
            }
            $scope.networkDropDownOnLoad = angular.copy($scope.networkDropDown);
            var parentSuccess = false;
            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                    (function (i) {
                        promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.networkmaparrayonload[i].advertiserId).then(function (response) {
                            if (response.appStatus == '0') { // success
                                parentSuccess = true;
                                $scope.campaigndetails = response.parentCampaigns;
                                for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                    if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                        for (var k = 0; k < $scope.campaigndetails.length; k++) {
                                            var _obj = {
                                                "id": $scope.campaigndetails[k].parentCampaignId,
                                                "name": $scope.campaigndetails[k].parentCampaignName,
                                                "type": "parent",
                                                "userNetworkMapId": $scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,
                                                "networkUrl": $scope.networkmaparrayonload[i].networkDetails[j].networkURL,
                                                "networkId": $scope.networkmaparrayonload[i].networkDetails[j].networkId
                                            };
                                            $scope.wholeParentArray.push(_obj);
                                        }
                                    }
                                }
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    $scope.errors[i].networkDetails[j]['parentCampaignError'] = obj;
                                }
                            }
                        }));
                    })(i);
                }
            }
            ;
            $q.all(promises).finally(
                    function () {
                        for (a = 0; a < $scope.wholeParentArray.length; a++) {
                            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {
                                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                        if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                            if ($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholeParentArray[a].userNetworkMapId) {
                                                var campaigns = [];
                                                var obj = {
                                                    "id": $scope.wholeParentArray[a].id,
                                                    "name": $scope.wholeParentArray[a].name,
                                                    "type": "Parent",
                                                    "campaigns": []
                                                };
                                                $scope.networkmaparrayonload[i].networkDetails[j].parent.push(obj);
                                                $scope.errors[i].networkDetails[j].parent.push(angular.copy(obj));
                                                //                                            }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (parentSuccess) {
                            $scope.fetchallchildandpush();
                        } else {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };
        $scope.wholechildArrayDropdown = [];

        $scope.fetchallchildandpush = function () {
            var promises = [];
            var campaignSuccess = false;
            console.log($scope.wholeParentArray);
            for (i = 0; i < $scope.wholeParentArray.length; i++) {

                (function (i) {
                    //checking whether the parent network is Fb or twitter
                    if ($scope.wholeParentArray[i].networkUrl == appSettings.fbNetwork) {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) {
                            if (response.appStatus == '0') {
                                campaignSuccess = true;
                                $scope.childCampaigns = response.adcampaigns;
                                var count = 0;
                                angular.forEach($scope.childCampaigns, function (value, key) {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) {
                                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].campaignId,
                                                "name": array[+j].campaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": array[+j].campaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl": $scope.wholeParentArray[i].networkUrl,
                                                "startDate": $filter('date')(array[+j].campaignDetails.start_time, 'yyyy-MMM-dd'),
                                                "endDate": $filter('date')(array[+j].campaignDetails.end_time, 'yyyy-MMM-dd'),
                                                "Objective": array[+j].campaignDetails.objective,
                                                "networkId": $scope.wholeParentArray[i].networkId

                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                            $scope.wholechildArrayDropdown.push(_obj);
                                        }
                                    }
                                });
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for (a = 0; a < $scope.errors.length; a++) {
                                        if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                            for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId) {
                                                    for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                        if ($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id) {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    } else if ($scope.wholeParentArray[i].networkUrl == appSettings.twNetwork) {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork,undefined).then(function (response) {
                            if (response.appStatus == '0') {
                                campaignSuccess = true;
                                angular.forEach(response.campaign, function (value, key) {
                                    angular.forEach(value, function (value2, key2) {
                                        var _obj = {
                                            "id": value2.twCampaignDetails.id,
                                            "name": value2.twCampaignDetails.name,
                                            "type": "child",
                                            "parentid": $scope.wholeParentArray[i].id,
                                            "status": value2.twCampaignStatus,
                                            "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                            "networkUrl": $scope.wholeParentArray[i].networkUrl,
                                            "startDate": $filter('date')(value2.twCampaignDetails.start_time, 'yyyy-MMM-dd'),
                                            "endDate": $filter('date')(value2.twCampaignDetails.end_time, 'yyyy-MMM-dd'),
                                            "Objective": value2.twCampaignDetails.objective,
                                            "networkId": $scope.wholeParentArray[i].networkId
                                        };
                                        $scope.wholechildArray.push(_obj);
                                        $scope.childIdArray.push(value2.twCampaignDetails.id);
                                    });
                                });
                            } else {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.networkError.message;
                                        } else {
                                            obj["Error"] = response.networkError.error_user_title;
                                            obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } else {
                                        obj["Error"] = "Error";
                                        obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for (a = 0; a < $scope.errors.length; a++) {
                                        if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                            for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId) {
                                                    for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                        if ($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id) {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    }
                })(i);
            }
            $q.all(promises).finally(
                    function () {

                        if (campaignSuccess) {
                            $scope.getTWcampaignObj();
                        } else
                        {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };

        $scope.getTWcampaignObj = function () {
            var promises = [];
            for (var i = 0; i < $scope.networkmaparrayonload.length; i++) {
                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {
                    for (var j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                        if ($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork) {

                            $scope.twADAccountId = $scope.networkmaparrayonload[i].networkDetails[j].adAccountId;
                            promises.push(performanceServices.readlineitems($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,$scope.twADAccountId).then(function (response) {
                                if (response.appStatus == '0') { // success
                                    $scope.lineItem = response.lineItems;

                                    angular.forEach($scope.lineItem, function (value, key) {

                                        var Jsonobj = $scope.lineItem[key];

                                        var array = [];

                                        for (var i in Jsonobj) {

                                            array[+i] = Jsonobj[i];
                                            $scope.iterated = array[+i];
                                            angular.forEach($scope.wholechildArray, function (value, key) {

                                                if (value.id == $scope.iterated.twCampaignId) {
                                                    $scope.wholechildArray[key]['Objective'] = $scope.iterated.twLineItemDetails.objective;
                                                }
                                            });
                                        }
                                    });
                                } else {
                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                                        $rootScope.progressLoader = "none";
                                        $scope.editAdsetErrorMsg = 'block';
                                        if (response.networkError != '' && response.networkError != undefined) {
                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                $scope.errorpopupHeading = 'Error';
                                                $scope.errorMsg = response.networkError.message;
                                            } else {
                                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                                $scope.errorMsg = response.networkError.error_user_msg;
                                            }
                                        } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.errorMessage;
                                        }
                                    }
                                }
                            }));
                            $q.all(promises).finally(
                                    function () {
                                        for (a = 0; a < $scope.wholechildArray.length; a++) {
                                            for (i = 0; i < $scope.networkmaparrayonload.length; i++) {

                                                if ($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails")) {

                                                    for (j = 0; j < $scope.networkmaparrayonload[i].networkDetails.length; j++) {
                                                        if ($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholechildArray[a].userNetworkMapId) {
                                                            //pushing FB campaigns into struct array
                                                            if ($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                                for (k = 0; k < $scope.networkmaparrayonload[i].networkDetails[j].parent.length; k++) {
                                                                    if ($scope.networkmaparrayonload[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid) {
                                                                        var insights = [];
                                                                        var obj = {
                                                                            "id": $scope.wholechildArray[a].id,
                                                                            "name": $scope.wholechildArray[a].name,
                                                                            "parentId": $scope.wholechildArray[a].parentid,
                                                                            "type": "child",
                                                                            "campStartDate": $scope.wholechildArray[a].startDate,
                                                                            "campEndDate": $scope.wholechildArray[a].endDate,
                                                                            "objective": $scope.wholechildArray[a].Objective,
                                                                            "status": $scope.wholechildArray[a].status,
                                                                            "insights": insights
                                                                        };
                                                                        $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns.push(obj);
                                                                        $scope.errors[i].networkDetails[j].parent[k].campaigns.push(angular.copy(obj));
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        var nonUniqueParentArray = [];
                                        var uniqueParentArray = [];
                                        var uniqueParentObjects = [];
                                        for (i = 0; i < $scope.wholeParentArray.length; i++) {
                                            nonUniqueParentArray.push($scope.wholeParentArray[i].id);
                                        }
                                        uniqueParentArray = nonUniqueParentArray.filter(function (elem, index, self) {
                                            return index == self.indexOf(elem);
                                        });
                                        for (i = 0; i < uniqueParentArray.length; i++) {
                                            var obj = {
                                                "id": uniqueParentArray[i],
                                                "name": "",
                                                "type": "parent"
                                            };
                                            uniqueParentObjects.push(obj);
                                        }
                                        for (i = 0; i < uniqueParentObjects.length; i++) {
                                            for (j = 0; j < $scope.wholeParentArray.length; j++) {
                                                if ($scope.wholeParentArray[j].id == uniqueParentObjects[i].id) {
                                                    uniqueParentObjects[i].name = $scope.wholeParentArray[j].name;
                                                }
                                            }
                                        }
                                        $scope.wholeParentArray = angular.copy(uniqueParentObjects);
                                        $scope.wholeParentArrayOnLoad = angular.copy($scope.wholeParentArray);
                                        $scope.wholeChildArrayOnLoad = angular.copy($scope.wholechildArray);
                                        $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
                                        $scope.readcampaigninsights();
                                    });


                        }
                    }
                }
            }
        };

        $scope.readcampaigninsights = function () {
            var insights = [];
            var promises = [];
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                        if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,$scope.from,$scope.to,undefined,undefined,appSettings.fbNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var resp = response.adCampaignInsights;
                                                    if (resp.length != 0) {
                                                        angular.forEach(resp, function (value, key) {
                                                            angular.forEach(value, function (value2, key2) {
                                                                var obj = {};
                                                                angular.forEach(value2, function (value3, key3) {
                                                                    if (key3 == "spend" || key3 == "clicks" || key3 == "impressions" || key3 == "callToAction") {
                                                                        var newchar = ' ';
                                                                        key3 = key3.split('_').join(newchar);
                                                                        if (key3 == "callToAction") {
                                                                            obj['actions'] = Math.round(parseFloat(value3));
                                                                        } else {
                                                                            obj[key3] = Math.round(parseFloat(value3));
                                                                        }
                                                                    }
                                                                });
                                                                insight[key2] = obj;
                                                            });
                                                        });
                                                        insights.push(insight);
                                                    }
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                    }
                                }
                            }
                        } else if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        (function (i, j, k, l) {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,$scope.from,$scope.to,undefined,undefined,appSettings.twNetwork,true).then(function (response) {
                                                var insight = {};
                                                if (response.appStatus == 0) {
                                                    var obj = {};
                                                    if (response.adCampaignInsights.length != 0) {
                                                        angular.forEach(response.adCampaignInsights, function (value, key) {
                                                            angular.forEach(value, function (value2, key2) {
                                                                obj['spend'] = value2.spend;
                                                                obj['clicks'] = value2.clicks;
                                                                obj['impressions'] = value2.impressions;
                                                                obj['engagements'] = value2.callToAction;
                                                            });
                                                        });

                                                        insight[$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id] = obj;
                                                        insights.push(insight);
                                                    }
                                                } else {
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.networkError.message;
                                                            } else {
                                                                obj["Error"] = response.networkError.error_user_title;
                                                                obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } else {
                                                            obj["Error"] = "Error";
                                                            obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for (a = 0; a < $scope.errors.length; a++) {
                                                            if ($scope.errors[a].hasOwnProperty("networkDetails")) {
                                                                for (b = 0; b < $scope.errors[a].networkDetails.length; b++) {
                                                                    if ($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId) {
                                                                        for (c = 0; c < $scope.errors[a].networkDetails[b].parent.length; c++) {
                                                                            for (d = 0; d < $scope.errors[a].networkDetails[b].parent[c].campaigns.length; d++) {
                                                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id) {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i, j, k, l);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $q.all(promises).finally(function () {
                for (i = 0; i < $scope.networkmaparray.length; i++) {
                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        angular.forEach(insights, function (value, key) {
                                            angular.forEach(value, function (value2, key2) {
                                                if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                    $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.push(value2);
                                                }
                                            });
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
                $scope.getcampaignbudget();
            });
        };

        $scope.getcampaignbudget = function () {
            var promises = [];
            var budgetCalls = [];
            var budget = 0;
            for (i = 0; i < $scope.networkmaparray.length; i++) {
                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                        if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork) {
                            var campaignIds = "";
                            var campFlag = false;
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        campFlag = true;
                                        campaignIds = campaignIds + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id + ",";
                                    }
                                }
                            }
                            if (campFlag) {
                                var obj = {
                                    "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                    "networkURL": $scope.networkmaparray[i].networkDetails[j].networkURL,
                                    "campaignIds": campaignIds
                                };
                                budgetCalls.push(obj);
                            }
                        } else if ($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork) {
                            var campaignIds = "";
                            var campFlag = false;
                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                        campFlag = true;
                                        campaignIds = campaignIds + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id + ",";
                                    }
                                }
                            }
                            if (campFlag) {
                                var obj = {
                                    "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                    "networkURL": $scope.networkmaparray[i].networkDetails[j].networkURL,
                                    "campaignIds": campaignIds
                                };
                                budgetCalls.push(obj);
                            }
                        }
                    }
                }
            }
            for (a = 0; a < budgetCalls.length; a++) {
                if (budgetCalls[a].networkURL == appSettings.fbNetwork) {
                    (function (a) {
                        promises.push(performanceServices.getcampaignbudget(budgetCalls[a].userNetworkMapId,budgetCalls[a].campaignIds,$scope.from,$scope.to,'YEARLY',appSettings.fbNetwork,true).then(function (response) {
                            if (response.appStatus == 0) {
                                angular.forEach(response.adcampaignbudget, function (value, key) {
                                    if (($scope.from == "" || $scope.from == undefined) && ($scope.to == "" || $scope.to == undefined)) {
                                        angular.forEach(value, function (val1, key2) {
                                            angular.forEach(val1, function (val2, key3) {
                                                for (i = 0; i < $scope.networkmaparray.length; i++) {
                                                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                                                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                                                            if ($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId) {
                                                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                                    for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                                                        for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                                                            if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                                                $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]['budget'] = parseFloat(val2.budget);

                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                        })
                                    } else if ($scope.from != "" && $scope.from != undefined && $scope.to != "" && $scope.to != undefined) {
                                        angular.forEach(value, function (val1, key2) {
                                            budget = 0;
                                            angular.forEach(val1, function (val2, key3) {
                                                angular.forEach(val2, function (val3, key4) {
                                                    budget = budget + parseFloat(val3.budget);
                                                })
                                            })
                                            for (i = 0; i < $scope.networkmaparray.length; i++) {
                                                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                                                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                                                        if ($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId) {
                                                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                                                        if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]['budget'] = budget;

                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        })
                                    }
                                });
                            }
                        }));
                    })(a);
                } else if (budgetCalls[a].networkURL == appSettings.twNetwork) {
                    (function (a) {
                        promises.push(performanceServices.getcampaignbudget(budgetCalls[a].userNetworkMapId,budgetCalls[a].campaignIds,$scope.from,$scope.to,'YEARLY',appSettings.twNetwork,true).then(function (response) {
                            if (response.appStatus == 0) {
                                angular.forEach(response.adcampaignbudget, function (value, key) {
                                    if (($scope.from == "" || $scope.from == undefined) && ($scope.to == "" || $scope.to == undefined)) {
                                        angular.forEach(value, function (val1, key2) {
                                            angular.forEach(val1, function (val2, key3) {
                                                for (i = 0; i < $scope.networkmaparray.length; i++) {
                                                    if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                                                        for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                                                            if ($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId) {
                                                                if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                                    for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                                                        for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                                                            if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                                                $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]['budget'] = parseFloat(val2.budget);

                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                        })
                                    } else if ($scope.from != "" && $scope.from != undefined && $scope.to != "" && $scope.to != undefined) {
                                        angular.forEach(value, function (val1, key2) {
                                            budget = 0;
                                            angular.forEach(val1, function (val2, key3) {
                                                angular.forEach(val2, function (val3, key4) {
                                                    budget = budget + parseFloat(val3.budget);
                                                })
                                            })
                                            for (i = 0; i < $scope.networkmaparray.length; i++) {
                                                if ($scope.networkmaparray[i].hasOwnProperty("networkDetails")) {
                                                    for (j = 0; j < $scope.networkmaparray[i].networkDetails.length; j++) {
                                                        if ($scope.networkmaparray[i].networkDetails[j].userNetworkMapId == budgetCalls[a].userNetworkMapId) {
                                                            if ($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId")) {
                                                                for (k = 0; k < $scope.networkmaparray[i].networkDetails[j].parent.length; k++) {
                                                                    for (l = 0; l < $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length; l++) {
                                                                        if ($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2) {
                                                                            $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l]['budget'] = budget;

                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        })
                                    }
                                });
                            }
                        }));
                    })(a);
                }
            }
            $q.all(promises).finally(function () {
                $scope.getReportType();
            });
        };
        $scope.networkmaparrayonLoadData1 = [];
        $scope.fillTableOnload = function () {
            var id;
            var name;
            var campStartDate;
            var campEndDate;
            var campstatus;
            var objective;
            var budget;
            var networkName;
            var totalSpend = 0;
            var totalBudget = 0;
            var totalImp = 0;
            var totalClicks = 0;
            var totalEng = 0;
            $scope.tableDt = [];
            var totalactions = 0;
            $scope.networkmaparrayonLoadData1 = [];
            if ($scope.from != undefined && $scope.to != undefined && $scope.from != "" && $scope.to != "") {
                $scope.networkmaparrayonLoadData1 = angular.copy($scope.networkmaparray);
            } else {
                $scope.networkmaparrayonLoadData1 = angular.copy($scope.networkmaparrayonLoadData);
            }
            for (var i = 0; i < $scope.networkmaparrayonLoadData1.length; i++) {
                if ($scope.networkmaparrayonLoadData1[i].hasOwnProperty('networkDetails')) {
                    //                   console.log($scope.networkmaparray[i].networkDetails);
                    for (var j = 0; j < $scope.networkmaparrayonLoadData1[i].networkDetails.length; j++) {

                        if ($scope.networkmaparrayonLoadData1[i].networkDetails[j].hasOwnProperty('parent')) {
                            for (var k = 0; k < $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent.length; k++) {
                                if ($scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].hasOwnProperty('campaigns')) {

                                    networkName = $scope.networkmaparrayonLoadData1[i].networkDetails[j].networkName;
                                    for (var x = 0; x < $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns.length; x++) {
                                        id = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].id;
                                        name = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].name;
                                        campStartDate = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].campStartDate == null ? "-" || "null" || "undefined" : $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].campStartDate;
                                        campEndDate = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].campEndDate == null || "null" || "undefined" ? "-" : $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].campEndDate;
                                        campstatus = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].status;
                                        objective = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].objective == "" || null || "null" || "undefined" ? "-" : $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].objective;
                                        budget = $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].budget == null || "null" || "undefined" ? 0 : $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].budget;
                                        ;
                                        if ($scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].hasOwnProperty('insights')) {

                                            var barGraphObj = {};

                                            for (var d = 0; d < $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights.length; d++) {
                                                var obj = {
                                                    "CampaignId": id,
                                                    "CampaignName": name,
                                                    "StartDate": campStartDate,
                                                    "EndDate": campEndDate,
                                                    "Status": campstatus,
                                                    "Networks": networkName,
                                                    "Objective": objective,
                                                    "Budget": budget,
                                                    "Spend": $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].spend,
                                                    "Impressions": $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].impressions,
                                                    "Clicks": $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].clicks,
                                                    "Engagements": $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].engagements == null || "null" || "undefined" ? 0 : $scope.networkmaparrayonLoadData[i].networkDetails[j].parent[k].campaigns[x].insights[d].engagements,
                                                    "Actions": $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].actions == null || "null" || "undefined" ? 0 : $scope.networkmaparrayonLoadData[i].networkDetails[j].parent[k].campaigns[x].insights[d].actions
                                                }
                                                totalSpend = totalSpend + $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].spend;
                                                totalBudget = totalBudget + budget;
                                                totalImp = totalImp + $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].impressions;
                                                totalClicks = totalClicks + $scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].clicks;
                                                totalEng = totalEng + ($scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].engagements == null || "null" || "undefined" ? 0 : $scope.networkmaparrayonLoadData[i].networkDetails[j].parent[k].campaigns[x].insights[d].engagements);
                                                totalactions = totalactions + ($scope.networkmaparrayonLoadData1[i].networkDetails[j].parent[k].campaigns[x].insights[d].actions == null || "null" || "undefined" ? 0 : $scope.networkmaparrayonLoadData[i].networkDetails[j].parent[k].campaigns[x].insights[d].actions);
                                                $scope.tableDt.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $rootScope.progressLoader = "none";
            if ($scope.tableDt.length != 0) {
                $scope.nograph = false;
                var obj1 = {
                    "CampaignId": "",
                    "CampaignName": "",
                    "StartDate": "",
                    "EndDate": "",
                    "Status": "",
                    "Networks": "",
                    "Objective": "Total",
                    "Budget": totalBudget,
                    "Spend": totalSpend,
                    "Impressions": totalImp,
                    "Clicks": totalClicks,
                    "Engagements": totalEng,
                    "Actions": totalactions
                }
                $scope.tableDt.push(obj1);
            } else {
                $scope.nograph = true;
            }
            $scope.basictable($scope.tableDt);
            $scope.detailtable($scope.tableDt);
        };

        $scope.filltableForFilters = function () {
            $scope.tableDt = [];
            var totalSpend = 0;
            var totalBudget = 0;
            var totalImp = 0;
            var totalClicks = 0;
            var totalEng = 0;
            var totalactions = 0;
            var tempBudg = 0;

            for (i = 0; i < $scope.tableinsights.length; i++) {
                tempBudg = $scope.tableinsights[i].budget == null ? parseInt("0") : $scope.tableinsights[i].budget
                if ($scope.tableinsights[i].Objective == undefined)
                {
                    var obj = {
                        "CampaignId": $scope.tableinsights[i].id,
                        "CampaignName": $scope.tableinsights[i].name,
                        "StartDate": $scope.tableinsights[i].startDate == null ? "-" : $scope.tableinsights[i].startDate,
                        "EndDate": $scope.tableinsights[i].endDate == null ? "-" : $scope.tableinsights[i].endDate,
                        "Status": $scope.tableinsights[i].status,
                        "Networks": $scope.tableinsights[i].networkName,
                        "Objective": "-",
                        "Budget": tempBudg
                    }
                } else
                {
                    var obj = {
                        "CampaignId": $scope.tableinsights[i].id,
                        "CampaignName": $scope.tableinsights[i].name,
                        "StartDate": $scope.tableinsights[i].startDate == null ? "-" : $scope.tableinsights[i].startDate,
                        "EndDate": $scope.tableinsights[i].endDate == null ? "-" : $scope.tableinsights[i].endDate,
                        "Status": $scope.tableinsights[i].status,
                        "Networks": $scope.tableinsights[i].networkName,
                        "Objective": $scope.tableinsights[i].Objective,
                        "Budget": tempBudg
                    }
                }
                totalBudget = totalBudget + tempBudg;
                for (j = 0; j < $scope.tableinsights[i].insights.length; j++) {
                    obj["Spend"] = $scope.tableinsights[i].insights[j].spend;
                    obj["Impressions"] = $scope.tableinsights[i].insights[j].impressions;
                    obj["Clicks"] = $scope.tableinsights[i].insights[j].clicks;
                    obj["Actions"] = $scope.tableinsights[i].insights[j].actions == null ? 0 : $scope.tableinsights[i].insights[j].actions;
                    obj["Engagements"] = $scope.tableinsights[i].insights[j].engagements == null ? 0 : $scope.tableinsights[i].insights[j].engagements;
                    totalSpend = totalSpend + $scope.tableinsights[i].insights[j].spend;
                    totalImp = totalImp + $scope.tableinsights[i].insights[j].impressions;
                    totalClicks = totalClicks + $scope.tableinsights[i].insights[j].clicks;
                    totalEng = totalEng + ($scope.tableinsights[i].insights[j].engagements == null ? 0 : $scope.tableinsights[i].insights[j].engagements);
                    totalactions = totalactions + ($scope.tableinsights[i].insights[j].actions == null ? 0 : $scope.tableinsights[i].insights[j].actions);
                    $scope.tableDt.push(obj);
                }

            }
            if ($scope.tableinsights.length != 0) {
                $scope.nograph = false;
                var obj1 = {
                    "CampaignId": "",
                    "CampaignName": "",
                    "StartDate": "",
                    "EndDate": "",
                    "Status": "",
                    "Networks": "",
                    "Objective": "Total",
                    "Budget": totalBudget,
                    "Spend": totalSpend,
                    "Impressions": totalImp,
                    "Clicks": totalClicks,
                    "Actions": totalactions,
                    "Engagements": totalEng
                }
                $scope.tableDt.push(obj1);
                $scope.basictable($scope.tableDt);
                $scope.detailtable($scope.tableDt);
            } else {
                $('#chart2').empty();
                $('#chart1').empty();
                $('#chart4').empty();
                $scope.nograph = true;
            }
        };
        $scope.maxImp = 10;
        $scope.fillPieBarForFilters = function () {
            $scope.pieChartDataClicks = [];
            $scope.pieChartDataActions = [];
            $scope.pieChartDataEngagements = [];
            $scope.pieChartDataImpressions = [];
            $scope.barGraphDt = [];
            $scope.maxImp = 10;
            for (i = 0; i < $scope.tableinsights.length; i++)
            {
                for (j = 0; j < $scope.tableinsights[i].insights.length; j++)
                {
                    var barGraphObj = {};
                    var pieObjClicks = {
                        "Clicks": $scope.tableinsights[i].insights[j].clicks,
                        "campaignName": $scope.tableinsights[i].name
                    }
                    if ($scope.maxImp < $scope.tableinsights[i].insights[j].clicks) {
                        $scope.maxImp = $scope.tableinsights[i].insights[j].clicks;
                    }
                    $scope.pieChartDataClicks.push(pieObjClicks);
                    var pieObjImpressions = {
                        "Impressions": $scope.tableinsights[i].insights[j].impressions,
                        "campaignName": $scope.tableinsights[i].name
                    }
                    if ($scope.maxImp < $scope.tableinsights[i].insights[j].impressions) {
                        $scope.maxImp = $scope.tableinsights[i].insights[j].impressions;
                    }
                    $scope.pieChartDataImpressions.push(pieObjImpressions);
                    // if ($scope.tableinsights[i].networkUrl == appSettings.fbNetwork) {

                    var pieObjActions = {
                        "actions": $scope.tableinsights[i].insights[j].actions,
                        "campaignName": $scope.tableinsights[i].name
                    }
                    if ($scope.maxImp < $scope.tableinsights[i].insights[j].actions) {
                        $scope.maxImp = $scope.tableinsights[i].insights[j].actions;
                    }
                    $scope.pieChartDataActions.push(pieObjActions);
                    //} else if ($scope.tableinsights[i].networkUrl == appSettings.twNetwork) {
                    var pieObjEngagements = {
                        "Engagements": $scope.tableinsights[i].insights[j].engagements,
                        "campaignName": $scope.tableinsights[i].name
                    }
                    if ($scope.maxImp < $scope.tableinsights[i].insights[j].engagements) {
                        $scope.maxImp = $scope.tableinsights[i].insights[j].engagements;
                    }
                    $scope.pieChartDataEngagements.push(pieObjEngagements);
                    barGraphObj = {
                        "product": "Impressions",
                        "scale": $scope.tableinsights[i].insights[j].impressions,
                        "campaign": $scope.tableinsights[i].name
                    };
                    $scope.barGraphDt.push(barGraphObj);
                    barGraphObj = {
                        "product": "Clicks",
                        "scale": $scope.tableinsights[i].insights[j].clicks,
                        "campaign": $scope.tableinsights[i].name
                    };
                    $scope.barGraphDt.push(barGraphObj);
                    if ($scope.tableinsights[i].networkUrl == appSettings.fbNetwork) {
                        barGraphObj = {
                            "product": "Actions",
                            "scale": $scope.tableinsights[i].insights[j].actions,
                            "campaign": $scope.tableinsights[i].name
                        };
                        $scope.barGraphDt.push(barGraphObj);
                    } else if ($scope.tableinsights[i].networkUrl == appSettings.twNetwork) {
                        if ($scope.tableinsights[i].insights[j].engagements != undefined && $scope.tableinsights[i].insights[j].engagements != "undefined") {
                            barGraphObj = {
                                "product": "Engagements",
                                "scale": $scope.tableinsights[i].insights[j].engagements,
                                "campaign": $scope.tableinsights[i].name
                            };
                            $scope.barGraphDt.push(barGraphObj);
                        }
                    }
                }
            }
            $scope.colorvalues = [];
            var color = ["#03A9F4", "#FFC107", "#b388ff", "#80cbc4", "#55C35B"];
            var tmp1 = $scope.pieChartDataClicks[0];
            var tmp2 = $scope.pieChartDataClicks[1];
            var tmp3 = $scope.pieChartDataClicks[2];
            var tmp4 = $scope.pieChartDataClicks[3];
            var tmp5 = $scope.pieChartDataClicks[4];
            var color1 = color[0];
            var color2 = color[1];
            var color3 = color[2];
            var color4 = color[3];
            var color5 = color[4];
            $scope.color = {};
            $scope.color[tmp1] = color1;
            $scope.color[tmp2] = color2;
            $scope.color[tmp3] = color3;
            $scope.color[tmp4] = color4;
            $scope.color[tmp4] = color5;
            $scope.pieChart = true;
            $scope.loadBarGraph();
            $scope.loadpieChart();
        };

        $scope.viewMoreErrors = function ()
        {
            angular.element("#errorScroll").css("height", "175px");
            angular.element("#errorScroll").css("overflow-y", "auto");
            angular.element("#moreErrors").css("display", "none");
            angular.element("#lessErrors").css("display", "flex");
            angular.element("#campEffectReportErrors").empty();
            for (a = 0; a < $scope.errorHeader.length; a++)
            {
                if ($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign != "")
                {
                    angular.element("#campEffectReportErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ChildCampaign + "<b>" + $scope.errorHeader[a].ChildCampaignValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                            "</div>" +
                            "</div>" +
                            "</div>"
                            );
                } else if ($scope.errorHeader[a].ParentCampaign == "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#campEffectReportErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                            "</div>" +
                            "</div>" +
                            "</div>"
                            );
                } else if ($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#campEffectReportErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                            "</div>" +
                            "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                            "</div>" +
                            "</div>" +
                            "</div>"
                            );
                }
            }
        };

        $scope.viewLessErrors = function ()
        {
            angular.element("#errorScroll").css("height", "auto");
            angular.element("#errorScroll").css("overflow-y", "hidden");
            angular.element("#moreErrors").css("display", "flex");
            angular.element("#lessErrors").css("display", "none");
            angular.element("#campEffectReportErrors").empty();
            for (a = 0; a < $scope.errorHeader.length && a < 2; a++)
            {
                angular.element("#campEffectReportErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:20px;'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='" + $scope.errorHeader[a].NetworkLogo + "' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                        "</div>" +
                        "</div>" +
                        "</div>"
                        );
            }
        };




        $scope.checkSelectedDropdowns = function () {
            if ($scope.selectedcampaign.length != 0) {
                $scope.updateTableforselectedCampaign();
                $scope.filltableForFilters();
            } else if ($scope.selectednewtwork.length != 0) {
                $scope.updateNetworkCampaignDropDown();
                $scope.filltableForFilters();
            } else if ($scope.selectedAdvertiser.length != 0) {
                $scope.selectednewtwork = [];
                $scope.selectedcampaign = [];
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.filltableForFilters();
            } else if ($scope.selectedAdvertiser.length == 0 && $scope.selectednewtwork.length == 0 && $scope.selectedcampaign.length == 0) {
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.networkmaparrayonLoadData = $scope.networkmaparray;
                $scope.fillTableOnload();
            }

        };

        $scope.ondefaultLoad = function () {
            $rootScope.progressLoader = "block";
            if ($scope.userRole != "Account") {
                $scope.accountRole = false;
            }
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.getAdvertiserDetails();
        };
        $scope.ondefaultLoad();

        $scope.filter = false;
        $scope.clickFilter = function () {
            if ($scope.filter == false) {
                $scope.filter = true;
            } else
                $scope.filter = false;
        };

        $window.scrollFunction = function (event, p)
        {
            angular.element(".effscroll4").scroll(function () {
                angular.element(".effscroll1").scrollLeft(angular.element(".effscroll4").scrollLeft());
            });
        };
        $window.wheelFunction = function (event, p)
        {
            event.preventDefault();
        }
        $window.wheelFunction1 = function (event, p)
        {
            event.preventDefault();
        }
        $window.scrollFunction2 = function (event, p)
        {
            angular.element(".effscroll5").scroll(function () {
                angular.element(".effscroll2").scrollLeft(angular.element(".effscroll5").scrollLeft());
            });
        };
        $window.scrollFunction3 = function (event, p)
        {
            angular.element(".effscroll6").scroll(function () {
                angular.element(".effscroll3").scrollLeft(angular.element(".effscroll6").scrollLeft());
            });
        };
        $scope.basictable = function (tabledata) {
            $scope.pieChartDataClicks = [];
            $scope.pieChartDataActions = [];
            $scope.pieChartDataEngagements = [];
            $scope.pieChart = false;
            var data = tabledata;
            $('#chart1').empty();
            $('#chart4').empty();
            dfc = cviz.widget.DynamicTable.Runner({
                id: '1',
                container: {
                    id: '#chart1',
                    filterable: false,
                    sortable: false
                },
                columnBindings: ['CampaignName', 'CampaignId', 'StartDate', 'EndDate',
                    'Status', 'Networks', 'Objective', 'Budget', 'Spend', 'Impressions', 'Clicks', 'Engagements', 'Actions'
                ],
                headerBindings: {
                    CampaignName: 'Campaign Name',
                    CampaignId: 'Campaign Id',
                    StartDate: 'Start Date',
                    EndDate: 'End Date',
                    Status: 'Status',
                    Networks: 'Networks',
                    Objective: 'Objective',
                    Budget: 'Budget',
                    Spend: 'Spend',
                    Impressions: 'Impressions',
                    Clicks: 'Clicks',
                    Engagements: 'Engagements',
                    Actions: 'Actions'

                },
                dataTypeBindings: {
                    CampaignName: 'String',
                    CampaignId: 'String',
                    StartDate: 'String',
                    EndDate: 'String',
                    Status: 'String',
                    Networks: 'String',
                    Objective: 'String',
                    Budget: 'number',
                    Spend: 'number',
                    Impressions: 'number',
                    Clicks: 'number',
                    Engagements: 'number',
                    Actions: 'number'
                },
                pager: {
                    pagerLength: 3,
                    recordsPerPage: tabledata.length,
                    position: 'bottom',
                    align: 'center'
                },
                classes: {
                    table: 'table1css'

                },
                utility: {
                    download: {
                        cssFileUrl: 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        exportServiceUrl: 'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        fileName: 'demotest'
                    }
                }
            });



            dfc4 = cviz.widget.DynamicTable.Runner({
                id: '1',
                container: {
                    id: '#chart4',
                    filterable: false,
                    sortable: false
                },
                columnBindings: ['CampaignName', 'CampaignId', 'StartDate', 'EndDate',
                    'Status', 'Networks', 'Objective', 'Budget', 'Spend', 'Impressions', 'Clicks', 'Engagements', 'Actions'
                ],
                headerBindings: {
                    CampaignName: 'Campaign Name',
                    CampaignId: 'Campaign Id',
                    StartDate: 'Start Date',
                    EndDate: 'End Date',
                    Status: 'Status',
                    Networks: 'Networks',
                    Objective: 'Objective',
                    Budget: 'Budget',
                    Spend: 'Spend',
                    Impressions: 'Impressions',
                    Clicks: 'Clicks',
                    Engagements: 'Engagements',
                    Actions: 'Actions'

                },
                dataTypeBindings: {
                    CampaignName: 'String',
                    CampaignId: 'String',
                    StartDate: 'String',
                    EndDate: 'String',
                    Status: 'String',
                    Networks: 'String',
                    Objective: 'String',
                    Budget: 'number',
                    Spend: 'number',
                    Impressions: 'number',
                    Clicks: 'number',
                    Engagements: 'number',
                    Actions: 'number'
                },
                pager: {
                    pagerLength: 3,
                    recordsPerPage: tabledata.length,
                    position: 'bottom',
                    align: 'center'
                },
                classes: {
                    table: 'table4css'

                },
                utility: {
                    download: {
                        cssFileUrl: 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        exportServiceUrl: 'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        fileName: 'demotest'
                    }
                }
            });

            dfc.graph().render(data);
            dfc4.graph().render(data);
            document.getElementById('chart1').children[1].children[1].children[tabledata.length - 1].style.background = '#fff8e1';
            for (i = 7; i < document.getElementById('chart1').children[1].children[1].children[tabledata.length - 1].childNodes.length; i++) {
                document.getElementById('chart1').children[1].children[1].children[tabledata.length - 1].children[i].style.backgroundColor = '#fff8e1';
            }
            for (i = 0; i < 5; i++) {
                document.getElementById('chart1').children[1].children[1].children[tabledata.length - 1].children[i].style.borderRight = '2px solid #fff8e1';
            }

            document.getElementById('chart4').children[1].children[1].children[tabledata.length - 1].style.background = '#fff8e1';
            for (i = 7; i < document.getElementById('chart4').children[1].children[1].children[tabledata.length - 1].childNodes.length; i++) {
                document.getElementById('chart4').children[1].children[1].children[tabledata.length - 1].children[i].style.backgroundColor = '#fff8e1';
            }
            for (i = 0; i < 5; i++) {
                document.getElementById('chart4').children[1].children[1].children[tabledata.length - 1].children[i].style.borderRight = '2px solid #fff8e1';
            }
            $rootScope.progressLoader = "none";
            var divHeight = angular.element(".effscroll4")[0].offsetHeight;
            var divHeight1 = angular.element(".effscroll5")[0].offsetHeight;
            if (divHeight >= 450 || divHeight1 >= 450)
            {
                $('.effscroll1').css('width', '100%');
                $('.effscroll2').css('width', '100%');
            } else
            {
                $('.effscroll1').css('width', '100.3%');
                $('.effscroll2').css('width', '100.3%');
            }
        };


        $scope.detailtable = function (tabledata) {
            $scope.pieChartDataClicks = [];
            $scope.pieChartDataActions = [];
            $scope.pieChartDataEngagements = [];
            $scope.pieChart = false;
            var data = tabledata;
            $('#chart2').empty();
            $('#chart5').empty();
            dfc1 = cviz.widget.DynamicTable.Runner({
                id: '1',
                container: {
                    id: '#chart2',
                    filterable: false,
                    sortable: false
                },
                columnBindings: ['CampaignName', 'CampaignId', 'StartDate', 'EndDate',
                    'Status', 'Networks', 'Objective', 'Budget', 'Spend', 'Impressions', 'Clicks', 'Engagements', 'Actions'
                ],
                headerBindings: {
                    CampaignName: 'Campaign Name',
                    CampaignId: 'Campaign Id',
                    StartDate: 'Start Date',
                    EndDate: 'End Date',
                    Status: 'Status',
                    Networks: 'Networks',
                    Objective: 'Objective',
                    Budget: 'Budget',
                    Spend: 'Spend',
                    Impressions: 'Impressions',
                    Clicks: 'Clicks',
                    Engagements: 'Engagements',
                    Actions: 'Actions'

                },
                dataTypeBindings: {
                    CampaignName: 'String',
                    CampaignId: 'String',
                    StartDate: 'String',
                    EndDate: 'String',
                    Status: 'String',
                    Networks: 'String',
                    Objective: 'String',
                    Budget: 'number',
                    Spend: 'number',
                    Impressions: 'number',
                    Clicks: 'number',
                    Engagements: 'number',
                    Actions: 'number'
                },
                pager: {
                    pagerLength: 3,
                    recordsPerPage: tabledata.length,
                    position: 'bottom',
                    align: 'center'
                },
                classes: {
                    table: 'table2css'

                },
                utility: {
                    download: {
                        cssFileUrl: 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        exportServiceUrl: 'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        fileName: 'demotest'
                    }
                }
            });
            dfc5 = cviz.widget.DynamicTable.Runner({
                id: '1',
                container: {
                    id: '#chart5',
                    filterable: false,
                    sortable: false
                },
                columnBindings: ['CampaignName', 'CampaignId', 'StartDate', 'EndDate',
                    'Status', 'Networks', 'Objective', 'Budget', 'Spend', 'Impressions', 'Clicks', 'Engagements', 'Actions'
                ],
                headerBindings: {
                    CampaignName: 'Campaign Name',
                    CampaignId: 'Campaign Id',
                    StartDate: 'Start Date',
                    EndDate: 'End Date',
                    Status: 'Status',
                    Networks: 'Networks',
                    Objective: 'Objective',
                    Budget: 'Budget',
                    Spend: 'Spend',
                    Impressions: 'Impressions',
                    Clicks: 'Clicks',
                    Engagements: 'Engagements',
                    Actions: 'Actions'

                },
                dataTypeBindings: {
                    CampaignName: 'String',
                    CampaignId: 'String',
                    StartDate: 'String',
                    EndDate: 'String',
                    Status: 'String',
                    Networks: 'String',
                    Objective: 'String',
                    Budget: 'number',
                    Spend: 'number',
                    Impressions: 'number',
                    Clicks: 'number',
                    Engagements: 'number',
                    Actions: 'number'
                },
                pager: {
                    pagerLength: 3,
                    recordsPerPage: tabledata.length,
                    position: 'bottom',
                    align: 'center'
                },
                classes: {
                    table: 'table5css'

                },
                utility: {
                    download: {
                        cssFileUrl: 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        exportServiceUrl: 'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        fileName: 'demotest'
                    }
                }
            });
            dfc1.graph().render(data);
            dfc5.graph().render(data);
            document.getElementById('chart2').children[1].children[1].children[tabledata.length - 1].style.background = '#fff8e1';
            for (i = 7; i < document.getElementById('chart2').children[1].children[1].children[tabledata.length - 1].childNodes.length; i++) {
                document.getElementById('chart2').children[1].children[1].children[tabledata.length - 1].children[i].style.backgroundColor = '#fff8e1';
            }
            for (i = 0; i < 5; i++) {
                document.getElementById('chart2').children[1].children[1].children[tabledata.length - 1].children[i].style.borderRight = '2px solid #fff8e1';
            }
            document.getElementById('chart5').children[1].children[1].children[tabledata.length - 1].style.background = '#fff8e1';
            for (i = 7; i < document.getElementById('chart5').children[1].children[1].children[tabledata.length - 1].childNodes.length; i++) {
                document.getElementById('chart5').children[1].children[1].children[tabledata.length - 1].children[i].style.backgroundColor = '#fff8e1';
            }
            for (i = 0; i < 5; i++) {
                document.getElementById('chart5').children[1].children[1].children[tabledata.length - 1].children[i].style.borderRight = '2px solid #fff8e1';
            }
            var divHeight = angular.element(".effscroll4")[0].offsetHeight;
            var divHeight1 = angular.element(".effscroll5")[0].offsetHeight;
            if (divHeight >= 450 || divHeight1 >= 450)
            {
                $('.effscroll1').css('width', '100%');
                $('.effscroll2').css('width', '100%');
            } else
            {
                $('.effscroll1').css('width', '100.3%');
                $('.effscroll2').css('width', '100.3%');
            }
        };


        $scope.archivedtable = function (archivedData) {
            var data = archivedData;
            $scope.pieChartDataClicks = [];
            $scope.pieChartDataActions = [];
            $scope.pieChartDataEngagements = [];
            $scope.pieChart = false;
            if (archivedData.length == 0) {
                $scope.noarchivedgraph = true;
                $('#chart3').empty();
            } else {
                $scope.noarchivedgraph = false;
                $('#chart3').empty();
                dfc2 = cviz.widget.DynamicTable.Runner({
                    id: '1',
                    container: {
                        id: '#chart3',
                        filterable: false,
                        sortable: false
                    },
                    columnBindings: ['reportName', 'reportDate', 'ReportFormat'],
                    headerBindings: {
                        reportName: 'Report Name',
                        reportDate: 'Report Date',
                        ReportFormat: 'Report Format'


                    },
                    dataTypeBindings: {
                        ReportName: 'String',
                        ReportDate: 'date',
                        ReportFormat: 'String'

                    },
                    pager: {
                        pagerLength: 3,
                        recordsPerPage: 10,
                        position: 'bottom',
                        align: 'center'
                    },
                    utility: {
                        download: {
                            cssFileUrl: 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                            exportServiceUrl: 'https://visualization-coe.cognizant.com/cviz-utilities/export',
                            fileName: 'demotest'
                        }
                    }
                });
                dfc2.graph().render(data);
                $rootScope.progressLoader = "none";
            }
        };
        $scope.archivedData = [];
        $scope.fillArchivedTable = function () {
            $scope.archivedData = [];
            $scope.archivedDatasearch = [];
            for (var i = 0; i < $scope.reportTypeArchived.length; i++)
            {
                for (var j = i; j < $scope.reportHistory.length; j++)
                {
                    (function (i, j)
                    {
                        if ($scope.reportTypeArchived[i].reportId == $scope.reportHistory[j].reportId)
                        {
                            var obj1 = {
                                "reportName": $scope.reportHistory[j].reportFileName,
                                "reportDate": $filter('date')($scope.reportHistory[j].reportDate, 'yyyy-MMM-dd'),
                                "ReportFormat": $scope.reportType[i].reportType,
                                "reportId": $scope.reportType[i].reportId
                            };
                            $scope.archivedData.push(obj1);
                        }
                    })(i, j);
                }
            }
            if ($scope.fromArchived != undefined && $scope.toArchived != undefined && $scope.fromArchived != "" && $scope.toArchived != "")
            {
                if ($scope.reportTypesArchived == "reset") {
                    $scope.archivedtable($scope.archivedData);
                } else {
                    angular.forEach($scope.archivedDataOnload, function (value, key) {
                        if ($scope.reportTypesArchived == value.reportId) {
                            $scope.archivedDatasearch.push(value);
                        }
                    });
                    $scope.archivedtable($scope.archivedDatasearch);
                }
            } else {
                $scope.archivedDataOnload = angular.copy($scope.archivedData);
                $scope.archivedtable($scope.archivedData);
            }


        }
        $scope.basic = true;
        $scope.detail = false;
        $scope.archived = false;
        $scope.tabselect = function (type) {
            if (type == 'BasicReport') {
                $scope.basic = true;
                $scope.detail = false;
                $scope.archived = false;
            } else if (type == 'DetailedReport') {
                $scope.detail = true;
                $scope.basic = false;
                $scope.archived = false;
            } else if (type == 'ArchivedReport') {
                $scope.archived = true;
                $scope.basic = false;
                $scope.detail = false;
                $scope.type = 'table';
                $scope.getReportRunHistory();
                $scope.fillArchivedTable();
            }
        };
        $scope.moveHome = function () {
            $state.go('app.reportsLanding');
        };

        $scope.adver = "";
        $scope.selectedAdvertiser = [];
        $scope.advertiserdropdownselection = function (val) {
            $scope.network = "";
            $scope.adver = "";
            $('#pieChart1').empty();
            $('#pieChart2').empty();
            $('#pieChart3').empty();
            $('#pieChart4').empty();
            $scope.pieChartDataClicks = [];
            $('#campaignEffectivessReport_barGraph').empty();
            $scope.type = 'table';
            $scope.legends = false;
            $("#img2").css("pointer-events", "none");
            $("#img3").css("pointer-events", "none");
            $("#img2").css("opacity", "0.5");
            $("#img3").css("opacity", "0.5");
            angular.forEach($scope.selectedAdvertiser, function (value, key) {
//                console.log(value);
                $scope.adver = $scope.adver + value.advertiserName + ",";
            });
            var index = $scope.selectedAdvertiser.indexOf(val);
            if (index > -1) {
                $scope.selectedAdvertiser.splice(index, 1);
            } else {
                $scope.selectedAdvertiser.push(val);
            }
            if ($scope.selectedAdvertiser.length != 0) {
                $scope.selectednewtwork = [];
                $scope.selectedcampaign = [];
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.filltableForFilters();
            } else {
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.fillTableOnload();
            }

        };

        $scope.network = "";
        $scope.selectednewtwork = [];
        $scope.networkDropdownselection = function (val) {
            $scope.selectedcampaign = [];
            $scope.network = "";
            $scope.campaigncount = 0;
            $('#pieChart1').empty();
            $('#pieChart2').empty();
            $('#pieChart3').empty();
            $('#pieChart4').empty();
            $scope.pieChartDataClicks = [];
            $('#campaignEffectivessReport_barGraph').empty();
            $scope.type = 'table';
            $scope.legends = false;
            $("#img2").css("pointer-events", "none");
            $("#img3").css("pointer-events", "none");
            $("#img2").css("opacity", "0.5");
            $("#img3").css("opacity", "0.5");
            var index = $scope.selectednewtwork.indexOf(val);
            if (index > -1) {
                $scope.selectednewtwork.splice(index, 1);
            } else {
                $scope.selectednewtwork.push(val);
            }
//            console.log($scope.selectednewtwork);
            angular.forEach($scope.selectednewtwork, function (value, key) {
                console.log(value);
                $scope.network = $scope.network + value.networkName + ",";
            });
            if ($scope.selectednewtwork.length != 0) {
                $scope.updateNetworkCampaignDropDown();
                $scope.filltableForFilters();
            } else if ($scope.selectednewtwork.length == 0) {
                $scope.updateCampaignDropDown();
                $scope.filltableForFilters();
            } else if ($scope.selectedAdvertiser.length == 0 && $scope.selectednewtwork.length == 0 && $scope.selectedcampaign.length == 0) {
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.fillTableOnload();
            }


        };

        $scope.disableid = [];
        $scope.map = {};
        $scope.selectedcampaign = [];
        $scope.limit = 5;
        $scope.campaigncount = 0;
        $scope.campaign = "";
        $scope.campaignDropdownselection = function (val) {

            var index = $scope.selectedcampaign.indexOf(val);
            $scope.campaign = "";
            if (index > -1) {
                $scope.campaigncount--;
                $scope.selectedcampaign.splice(index, 1);

            } else {
                $scope.campaigncount++;
                $scope.selectedcampaign.push(val);


            }
            angular.forEach($scope.selectedcampaign, function (value, key) {
//                    console.log(value);
                $scope.campaign = $scope.campaign + value.name + ",";
            });

            if ($scope.selectednewtwork.length == 0 && $scope.selectedcampaign.length == 0) {

                $('#pieChart1').empty();
                $('#pieChart2').empty();
                $('#pieChart3').empty();
                $('#pieChart4').empty();
                $scope.pieChartDataClicks = [];
                $('#campaignEffectivessReport_barGraph').empty();
                $scope.type = 'table';
                $scope.legends = false;
                $("#img2").css("pointer-events", "none");
                $("#img3").css("pointer-events", "none");
                $("#img2").css("opacity", "0.5");
                $("#img3").css("opacity", "0.5");
                $scope.updateNetworkDropDown();
                $scope.updateCampaignDropDown();
                $scope.fillTableOnload();
            } else if ($scope.selectedcampaign.length != 0) {
                $("#img2").removeAttr("style");
                $("#img3").removeAttr("style");
                $scope.updateTableforselectedCampaign();
                $scope.filltableForFilters();
                $scope.fillPieBarForFilters();
            }
            if ($scope.selectednewtwork.length != 0 && $scope.selectedcampaign.length == 0) {
                $('#pieChart1').empty();
                $('#pieChart2').empty();
                $('#pieChart3').empty();
                $('#pieChart4').empty();
                $scope.pieChartDataClicks = [];
                $('#campaignEffectivessReport_barGraph').empty();
                $scope.type = 'table';
                $scope.legends = false;
                $("#img2").css("pointer-events", "none");
                $("#img3").css("pointer-events", "none");
                $("#img2").css("opacity", "0.5");
                $("#img3").css("opacity", "0.5");
                $scope.updateNetworkCampaignDropDown();
                $scope.filltableForFilters();
            }
            $scope.checkMandatoryFieldForSaveSubscription();
        };
        $scope.searchAdvertiser = function ()
        {
            var arr = angular.copy($scope.multiselectadvertiserDropDown);
            if ($scope.searchAdver != undefined)
            {
                if ($scope.searchAdver.length != 0)
                {
                    var array = angular.copy(arr);
                    $scope.advertiserDropDown = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].advertiserName.toLowerCase().includes($scope.searchAdver))
                        {
                            $scope.advertiserDropDown.push(array[i]);
                        }
                    }
                } else
                {
                    $scope.advertiserDropDown = angular.copy(arr);
                }
            }
        }

        $scope.searchNetwork = function ()
        {
            var arrNetwork = angular.copy($scope.allnetworkDropDown);

            if ($scope.searchNet != undefined)
            {
                if ($scope.searchNet.length != 0)
                {
                    var array = angular.copy(arrNetwork);
                    $scope.networkDropDown = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].networkName.toLowerCase().includes($scope.searchNet))
                        {
                            $scope.networkDropDown.push(array[i]);
                        }
                    }
                } else
                {
                    $scope.networkDropDown = angular.copy(arrNetwork);
                }
            }



        };


        $scope.searchCampaign = function ()
        {

            var arrCampaign = angular.copy($scope.wholechildArrayDropdown);
            if ($scope.search != undefined)
            {
                if ($scope.search.length != 0)
                {
                    var array = angular.copy(arrCampaign);
                    $scope.wholechildArray = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].name.toLowerCase().includes($scope.search))
                        {
                            $scope.wholechildArray.push(array[i]);
                        }
                    }
                } else
                {
                    $scope.wholechildArray = angular.copy(arrCampaign);
                }
            }


        };
        var paramSubs = {};
        $scope.saveSubscription = function () {
            $scope.formRequestSubscription();
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'reportFilters': paramSubs,
            };
            $rootScope.progressLoader = "block";
            $http({
                url: apiBase + '/user/savereportsubscription',
                dataType: "json",
                method: "POST",
                data: parameters,
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $rootScope.progressLoader = "none";
                $scope.txtboxdiv = false;
                if (response.appStatus == '0') {// success
                    //getAdvertiserDetails = true;
                    $scope.subscriptionId = response.subscriptionId;
                    $scope.success = response.successMessage;
                    var modal_save_pup = $(".save_sub_pup");
                    modal_save_pup.show();
                } else {
                    $scope.success = response.errorMessage;
                    var modal_save_pup = $(".save_sub_pup");
                    modal_save_pup.show();
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.networkError.error_user_title;
                                $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }).error(function (error) {
                alert(error);
            });
        };

        $scope.campaignArray = [];
        $scope.networkArray = [];
        $scope.networkID = "";
        $scope.formRequestSubscription = function (subscribe) {

            $scope.campaignArray = [];
            $scope.networkArray = [];
            for (var i = 0; i < $scope.selectedcampaign.length; i++) {

                $scope.campaignArray.push($scope.selectedcampaign[i].id);
                $scope.networkArray.push($scope.selectedcampaign[i].networkId);
            }
            paramSubs = {
                "reportId": $scope.reportTypes,
                "subscriptionType": $scope.subscription,
                "networkId": $scope.networkArray,
                "campaigns": $scope.campaignArray
            }
        };


        $scope.download = function () {
            if ($scope.type == 'table' && ($scope.basic)) {
                dfc.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'BasicTableExcel');
            } else if ($scope.type == 'table' && ($scope.detail)) {
                dfc1.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'DetailedTableExcel');
            } else if ($scope.type == 'table' && ($scope.archived)) {
                dfc2.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'ArchivedTableExcel');
            } else if ($scope.type == 'pie') {

                dfcpie1.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_EXCEL1');
                dfcpie2.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_EXCEL2');
                dfcpie3.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_EXCEL3');

            } else if ($scope.type == 'bar') {

                grouped_bar_graph.graph().download('csv',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/widgets/grouped-column/grouped-column.css',
                        'myareaChartWidget');
            }
            //while executing this code, the output file downloaded will be "myareaChartWidget.pdf".
        };

        $scope.downloadPdf = function () {
            if ($scope.type == 'pie') {

                dfcpie1.graph().download('pdf',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_PDF1');
                dfcpie2.graph().download('pdf',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_PDF2');
                dfcpie3.graph().download('pdf',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
                        'PIE_PDF3');

            } else if ($scope.type == 'bar') {

                grouped_bar_graph.graph().download('pdf',
                        'https://visualization-coe.cognizant.com/cviz-utilities/export',
                        'https://visualization-coe.cognizant.com/cviz/widgets/grouped-column/grouped-column.css',
                        'myareaChartWidget');
            }
        };

        $scope.applySub = function () {

            var modal_save_pup = $(".save_sub_pup");
            modal_save_pup.show();
        }

        $scope.applySubClose = function () {

            var modal_save_close_pup = $(".save_sub_pup");
            modal_save_close_pup.hide();
        };

        $scope.checkIfSelected = function (val)
        {
            if ($scope.selectednewtwork.indexOf(val) > -1)
            {
                return true;
            } else
            {
                return false;
            }
        };
        $scope.checkIfSelectedcampaign = function (val)
        {
            if ($scope.selectedcampaign.indexOf(val) > -1)
            {
                return true;
            } else
            {
                return false;
            }
        };
        $scope.netwrk;
        $scope.network1 = [];
        $scope.campaigns = [];
        $scope.selectednewtworktemp = [];
        $scope.readsubsription = function (val) {
            $rootScope.progressLoader = "block";
            if ($scope.reportTypes == "reset") {
                $scope.resetFilter();
            } else {


                var promises = [];
                $scope.campaigns = [];
                $scope.selectedcampaign = [];
                $scope.selectednewtworktemp = [];
                $scope.selectednewtwork = [];
                $scope.network1 = [];
                $scope.campaigncount = 0;
                $scope.netwrk = "";
                promises.push(performanceServices.readsubsription($scope.reportTypes).then(function (response) {
                    if (response.appStatus == 0) {
                        $rootScope.progressLoader = "none";
                        var subscrip = response.subscriptionReadResponse;
                        angular.forEach(subscrip, function (value, key) {
                            angular.forEach(value, function (val1, key1) {
                                $scope.subscription = val1.reportFilters.subscriptionType;

                                $scope.network1 = val1.reportFilters.networkId;
                                for (var i = 0; i < $scope.network1.length; i++) {
                                    angular.forEach($scope.networkDropDown, function (val, key) {
                                        if ($scope.network1[i] == val.networkId) {
                                            $scope.selectednewtworktemp.push(val);
                                        }
                                    })
                                }
                                var nonUniqueNetworkArray = [];
                                var uniqueNetworktArray = [];
                                for (i = 0; i < $scope.selectednewtworktemp.length; i++) {
                                    nonUniqueNetworkArray.push($scope.selectednewtworktemp[i]);
                                }
                                uniqueNetworktArray = nonUniqueNetworkArray.filter(function (elem, index, self) {
                                    return index == self.indexOf(elem);
                                });
                                for (i = 0; i < uniqueNetworktArray.length; i++) {
                                    $scope.selectednewtwork.push(uniqueNetworktArray[i]);
                                }
                                $scope.updateNetworkCampaignDropDown();
                                $scope.campaigns = val1.reportFilters.campaigns;
                                for (var i = 0; i < $scope.campaigns.length; i++) {
                                    angular.forEach($scope.wholechildArray, function (val, key) {
                                        if ($scope.campaigns[i] == val.id) {
                                            $scope.campaigncount++;
                                            $scope.selectedcampaign.push(val);

                                        }
                                    })

                                }
                            })
                        });
                        $scope.network = "";
                        $scope.campaign = "";
                        angular.forEach($scope.selectednewtwork, function (value, key) {
//                            console.log(value);
                            $scope.network = $scope.network + value.networkName + ",";
                        });
                        angular.forEach($scope.selectedcampaign, function (value, key) {
                            $scope.campaign = $scope.campaign + value.name + ",";
                        });
                        $("#img2").removeAttr("style");
                        $("#img3").removeAttr("style");
                        $scope.updateTableforselectedCampaign();
                        $scope.filltableForFilters();
                        $scope.fillPieBarForFilters();
                    } else {
                        $scope.network = "";
                        $scope.campaign = "";
                        $scope.subscription = "";
                        $scope.nograph = true;
                        $scope.tableDt = [];
                        $scope.updateTableforselectedCampaign();
                        $scope.filltableForFilters();
                        $scope.fillPieBarForFilters();
                        $rootScope.progressLoader = "none";
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.networkError != '' && response.networkError != undefined) {
                                if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                                } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                                }
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                            }
                        }
                    }
                    $scope.checkMandatoryFieldForSaveSubscription();
                }))
            }
        }
        $scope.archivedDatasearch = [];
        $scope.readsubsriptionArchived = function () {
            $scope.archivedDatasearch = [];
            if ($scope.reportTypesArchived == "reset") {
                $scope.archivedtable($scope.archivedData);
            } else {
                angular.forEach($scope.archivedData, function (value, key) {
                    if ($scope.reportTypesArchived == value.reportId) {
                        $scope.archivedDatasearch.push(value);
                    }
                });
                $scope.archivedtable($scope.archivedDatasearch);
            }
        };

        $scope.fromAndToChangedArchived = function () {
            $scope.mindateArchived = $filter('date')($scope.from2, 'yyyy-MM-dd');
            $scope.fromArchived = $filter('date')($scope.from2, 'yyyy-MM-dd');
            $scope.toArchived = $filter('date')($scope.to2, 'yyyy-MM-dd');
            if ($scope.fromArchived != undefined && $scope.toArchived != undefined && $scope.fromArchived != "" && $scope.toArchived != "") {
                if (new Date($scope.fromArchived) <= new Date($scope.toArchived)) {
                    $rootScope.progressLoader = "block";
                    $scope.calculateDateDiff($scope.fromArchived, $scope.toArchived);
                } else {
                    $scope.fromArchived = "";
                    $scope.toArchived = "";
                    $scope.from2 = "";
                    $scope.to2 = "";
                }
            }
        };
        $scope.resetCalenderArchived = function () {
            $scope.fromArchived = "";
            $scope.toArchived = "";
            $scope.from2 = "";
            $scope.to2 = "";
            $scope.mindateArchived = "";
            $rootScope.progressLoader = "block";
            $scope.archivedDatasearch = [];
            if ($scope.reportTypesArchived == "reset") {
                $scope.archivedtable($scope.archivedData);
            } else {
                angular.forEach($scope.archivedDataOnload, function (value, key) {
                    if ($scope.reportTypesArchived == value.reportId) {
                        $scope.archivedDatasearch.push(value);
                    }
                });
                $scope.archivedtable($scope.archivedDatasearch);
            }

        };

        $scope.checkMandatoryFieldForSaveSubscription = function () {
            if ($scope.reportTypes != "reset" && $scope.campaigncount > 0 && $scope.subscription != "" && $scope.subscription != 'undefined' && $scope.subscription != null) {
                angular.element('#apply').prop("disabled", false);
            } else {
                angular.element('#apply').prop("disabled", true);
            }
        };
    }
]);
