dashboard.controller("funnelFlowController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$q', '$window', '$sce', 'appSettings', '$timeout','$filter','apiService','performanceServices',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $q, $window, $sce, appSettings, $timeout, $filter, apiService,performanceServices) 
    {
        $rootScope.progressLoader = "block";
        $scope.networkmaparrayonload = [];
        $scope.leftRendered = false;
        $scope.rightRendered = false;
        $scope.graphRendered = false;
        $scope.networkmaparray = [];
        $scope.advertiserdetails = [];
        $scope.allnetworksarray = [];
        $scope.networksarrayforacc = [];
        $scope.advertiserDropDown = [];
        $scope.networkDropDown = [];
        $scope.networkDropDownLeft = [];
        $scope.networkDropDownRight = [];
        $scope.networkDropDownOnLoad = [];
        $scope.wholeParentArray = [];
        $scope.wholeParentArrayLeft = [];
        $scope.wholeParentArrayRight = [];
        $scope.wholechildArray = [];
        $scope.wholechildArrayLeft = [];
        $scope.wholechildArrayRight = [];
        $scope.childCampaigns = [];
        $scope.wholeParentArrayOnLoad = [];
        $scope.wholeChildArrayOnLoad = [];
        $scope.advertiserIdLeft = "";
        $scope.networkIdLeft = "";
        $scope.selectedParentChildCampaignLeft = "";
        $scope.advertiserIdRight = "";
        $scope.networkIdRight = "";
        $scope.selectedParentChildCampaignRight = "";
        $scope.direction = "";
        $scope.selectedvalueLeft = "Select Campaign";
        $scope.selectedvalueRight = "Select Campaign";
        $scope.boolLeft = [];
        $scope.boolRight = [];
        $scope.errors = [];
        $scope.errorHeader = [];
        $scope.errorString = [];
        $scope.leftAvailability = "";
        $scope.rightAvailability = "";
        $scope.maxRange = 0;
        $scope.leftFunnelName = "";
        $scope.rightFunnelName = "";
        $scope.advertiserName = "";
        $scope.zeroGraph = [{"state": "Actions", "grade":"Noplot" ,"count": 0},
                            {"state": "Actions", "grade":"Plot_Actions" ,"count": 0},
                            {"state": "Clicks", "grade":"Noplot" ,"count": 0},	
                            {"state": "Clicks", "grade":"Plot_Clicks" ,"count": 0},
                            {"state": "Engagements", "grade":"Noplot" ,"count": 0},
                            {"state": "Engagements", "grade":"Plot_Engagements" ,"count": 0},
                            {"state": "Impressions", "grade":"Noplot" ,"count": 0},
                            {"state": "Impressions", "grade":"Plot_Impressions" ,"count": 0}];
        $scope.leftData = [{"state": "Actions", "grade":"Noplot" ,"count": 0},
                            {"state": "Actions", "grade":"Plot_Actions" ,"count": 0},
                            {"state": "Clicks", "grade":"Noplot" ,"count": 0},	
                            {"state": "Clicks", "grade":"Plot_Clicks" ,"count": 0},
                            {"state": "Engagements", "grade":"Noplot" ,"count": 0},
                            {"state": "Engagements", "grade":"Plot_Engagements" ,"count": 0},
                            {"state": "Impressions", "grade":"Noplot" ,"count": 0},
                            {"state": "Impressions", "grade":"Plot_Impressions" ,"count": 0}];
        $scope.rightData = [{"state": "Actions", "grade":"Noplot" ,"count": 0},
                            {"state": "Actions", "grade":"Plot_Actions" ,"count": 0},
                            {"state": "Clicks", "grade":"Noplot" ,"count": 0},
                            {"state": "Clicks", "grade":"Plot_Clicks" ,"count": 0},
                            {"state": "Engagements", "grade":"Noplot" ,"count": 0},
                            {"state": "Engagements", "grade":"Plot_Engagements" ,"count": 0},
                            {"state": "Impressions", "grade":"Noplot" ,"count": 0},
                            {"state": "Impressions", "grade":"Plot_Impressions" ,"count": 0}];
        var leftExcel = [{
                "state":"Actions",
                "count":0
            },{
                "state":"Impressions",
                "count":0
            },{
                "state":"Clicks",
                "count":0
            },{
                "state":"Engagements",
                "count":0
            }];
        var rightExcel = [{
                "state":"Actions",
                "count":0
            },{
                "state":"Impressions",
                "count":0
            },{
                "state":"Clicks",
                "count":0
            },{
                "state":"Engagements",
                "count":0
            }];
        var rightRunnerToDownloadPDF;
        var rightRunnerToDownloadEXCEL;
        var leftRunnerToDownloadPDF;
        var leftRunnerToDownloadEXCEL;
        $scope.allValues = {
            "LeftImpressions":0,
            "RightImpressions":0,
            "LeftEngagements":0,
            "RightEngagements":0,
            "LeftClicks":0,
            "RightClicks":0,
            "LeftActions":0,
            "RightActions":0
        };
        var leftRunner;
        var rightRunner;
        $scope.sampleData = [{"state": "Actions", "grade":"Noplot" ,"count": 50},	
                    {"state": "Actions", "grade":"Plot" ,"count": 40},
                    {"state": "Clicks", "grade":"Noplot" ,"count": 40},	
                    {"state": "Clicks", "grade":"Plot" ,"count": 60},
                    {"state": "Engagements", "grade":"Noplot" ,"count": 30},	
                    {"state": "Engagements", "grade":"Plot" ,"count": 80},
                    {"state": "Impressions", "grade":"Noplot" ,"count": 20},	
                    {"state": "Impressions", "grade":"Plot" ,"count": 100}];

        if($window.localStorage.getItem("role") == "Account")
        {
            $scope.accountRole = true;
        }
        else
        {
            $scope.accountRole = false;
        }
        
        angular.element($window).bind('resize', function()
        {
//            console.log("window just got resized");
            $scope.leftRendered = false;
            $scope.rightRendered = false;
            $scope.funnelHeight = angular.element("#leftFunnel").height();
            $scope.funnelWidth = angular.element("#leftWidth").width();
            if($scope.graphRendered)
            {
                $scope.plotLeftGraph($scope.leftData);
                $scope.plotRightGraph($scope.rightData);
            }
        });
        
        $scope.funnelFlowGotoHome = function()
        {
            $state.go('app.reportsLanding');
        };
        
        $scope.funnelFlowDownloadExcel = function()
        {
            $scope.leftFunnelName = "";
            $scope.rightFunnelName = "";
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.advertiserIdLeft != undefined && $scope.advertiserIdLeft != "")
                {
                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                    {
                        $scope.leftFunnelName = $scope.leftFunnelName + $scope.networkmaparray[i].advertiserName;
                    }
                }
                if($scope.advertiserIdRight != undefined && $scope.advertiserIdRight != "")
                {
                    if($scope.advertiserIdRight == $scope.networkmaparray[i].advertiserId)
                    {
                        $scope.rightFunnelName = $scope.rightFunnelName + $scope.networkmaparray[i].advertiserName;
                    }
                }
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if(!$scope.accountRole)
                {
                    $scope.leftFunnelName = $scope.advertiserName;
                    $scope.rightFunnelName = $scope.advertiserName;
                }
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkIdLeft != undefined && $scope.networkIdLeft != "")
                        {
                            if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                            {
                                $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].networkName;
                            }
                        }
                        if($scope.networkIdRight != undefined && $scope.networkIdRight != "")
                        {
                            if($scope.networkIdRight == $scope.networkmaparray[i].networkDetails[j].networkId)
                            {
                                $scope.rightFunnelName = $scope.rightFunnelName + "_" +  $scope.networkmaparray[i].networkDetails[j].networkName;
                            }
                        }
                    }
                }
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                        {
                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                            {
                                if($scope.selectedParentChildCampaignLeft != undefined && $scope.selectedParentChildCampaignLeft != "")
                                {
                                    if($scope.selectedParentChildCampaignLeft.type == "parent" && $scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                    {
                                        if(!$scope.leftFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                        {
                                            $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                        }
                                    }
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        if($scope.selectedParentChildCampaignLeft.type == "child" && $scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                        {
                                            if(!$scope.leftFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                            {
                                                $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                            }
                                            $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name;
                                        }
                                    }
                                }
                                if($scope.selectedParentChildCampaignRight != undefined && $scope.selectedParentChildCampaignRight != "")
                                {
                                    if($scope.selectedParentChildCampaignRight.type == "parent" && $scope.selectedParentChildCampaignRight.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                    {
                                        if(!$scope.rightFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                        {
                                            $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                        }
                                    }
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        if($scope.selectedParentChildCampaignRight.type == "child" && $scope.selectedParentChildCampaignRight.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                        {
                                            if(!$scope.rightFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                            {
                                                $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                            }
                                            $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if($scope.leftFunnelName == "")
            {
                $scope.leftFunnelName = "leftFunnelName";
            }
            if($scope.rightFunnelName == "")
            {
                $scope.rightFunnelName = "rightFunnelName";
            }
            if($scope.leftFunnelName == $scope.rightFunnelName)
            {
                $scope.leftFunnelName = "Left" + "_" + $scope.leftFunnelName;
                $scope.rightFunnelName = "Right" + "_" + $scope.rightFunnelName;
            }
            leftRunnerToDownloadEXCEL.graph().download('csv', 'https://visualization-coe.cognizant.com/cviz-utilities/export', 'https://visualization-coe.cognizant.com/cviz/widgets/stacked-column/stacked-column.css', $scope.leftFunnelName);
            rightRunnerToDownloadEXCEL.graph().download('csv', 'https://visualization-coe.cognizant.com/cviz-utilities/export', 'https://visualization-coe.cognizant.com/cviz/widgets/stacked-column/stacked-column.css', $scope.rightFunnelName);
        };
        
        $scope.funnelFlowDownloadPdf = function()
        {
            $scope.leftFunnelName = "";
            $scope.rightFunnelName = "";
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.advertiserIdLeft != undefined && $scope.advertiserIdLeft != "")
                {
                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                    {
                        $scope.leftFunnelName = $scope.leftFunnelName + $scope.networkmaparray[i].advertiserName;
                    }
                }
                if($scope.advertiserIdRight != undefined && $scope.advertiserIdRight != "")
                {
                    if($scope.advertiserIdRight == $scope.networkmaparray[i].advertiserId)
                    {
                        $scope.rightFunnelName = $scope.rightFunnelName + $scope.networkmaparray[i].advertiserName;
                    }
                }
                if(!$scope.accountRole)
                {
                    $scope.leftFunnelName = $scope.advertiserName;
                    $scope.rightFunnelName = $scope.advertiserName;
                }
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkIdLeft != undefined && $scope.networkIdLeft != "")
                        {
                            if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                            {
                                $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].networkName;
                            }
                        }
                        if($scope.networkIdRight != undefined && $scope.networkIdRight != "")
                        {
                            if($scope.networkIdRight == $scope.networkmaparray[i].networkDetails[j].networkId)
                            {
                                $scope.rightFunnelName = $scope.rightFunnelName + "_" +  $scope.networkmaparray[i].networkDetails[j].networkName;
                            }
                        }
                    }
                }
            }
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("parent"))
                        {
                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                            {
                                if($scope.selectedParentChildCampaignLeft != undefined && $scope.selectedParentChildCampaignLeft != "")
                                {
                                    if($scope.selectedParentChildCampaignLeft.type == "parent" && $scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                    {
                                        if(!$scope.leftFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                        {
                                            $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                        }
                                    }
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        if($scope.selectedParentChildCampaignLeft.type == "child" && $scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                        {
                                            if(!$scope.leftFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                            {
                                                $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                            }
                                            $scope.leftFunnelName = $scope.leftFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name;
                                        }
                                    }
                                }
                                if($scope.selectedParentChildCampaignRight != undefined && $scope.selectedParentChildCampaignRight != "")
                                {
                                    if($scope.selectedParentChildCampaignRight.type == "parent" && $scope.selectedParentChildCampaignRight.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                    {
                                        if(!$scope.rightFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                        {
                                            $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                        }
                                    }
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        if($scope.selectedParentChildCampaignRight.type == "child" && $scope.selectedParentChildCampaignRight.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                        {
                                            if(!$scope.rightFunnelName.includes($scope.networkmaparray[i].networkDetails[j].parent[k].name))
                                            {
                                                $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].name;
                                            }
                                            $scope.rightFunnelName = $scope.rightFunnelName + "_" + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if($scope.leftFunnelName == "")
            {
                $scope.leftFunnelName = "leftFunnelName";
            }
            if($scope.rightFunnelName == "")
            {
                $scope.rightFunnelName = "rightFunnelName";
            }
            if($scope.leftFunnelName == $scope.rightFunnelName)
            {
                $scope.leftFunnelName = "Left" + "_" + $scope.leftFunnelName;
                $scope.rightFunnelName = "Right" + "_" + $scope.rightFunnelName;
            }
            leftRunnerToDownloadPDF.graph().download('pdf', 'https://visualization-coe.cognizant.com/cviz-utilities/export', 'https://visualization-coe.cognizant.com/cviz/widgets/stacked-column/stacked-column.css', $scope.leftFunnelName);
//            rightRunner.graph().download('pdf', 'https://visualization-coe.cognizant.com/cviz-utilities/export', 'https://visualization-coe.cognizant.com/cviz/widgets/stacked-column/stacked-column.css', $scope.rightFunnelName);
            rightRunnerToDownloadPDF.graph().download('pdf', 'https://visualization-coe.cognizant.com/cviz-utilities/export', 'https://visualization-coe.cognizant.com/cviz/widgets/stacked-column/stacked-column.css', $scope.rightFunnelName);
        };
        
        $scope.nocampaignselection = function(direction)
        {
            $scope.direction = direction;
            if(direction == "Left")
            {
                $scope.selectedvalueLeft = "Select Campaign";
                $scope.selectedParentChildCampaignLeft = "";
            }
            else if(direction == "Right")
            {
                $scope.selectedvalueRight = "Select Campaign";
                $scope.selectedParentChildCampaignRight = "";
            }
            $scope.checkDropDownSelections();
        };
        
        $scope.arrowDirectionChange = function (parentobj, _index , direction) 
        {
            if(direction == "Left")
            {
                for (i = 0; i < $scope.wholeParentArrayLeft.length; i++)
                {
                    if ($scope.wholeParentArrayLeft[i].id != parentobj.id)
                    {
                        $scope.boolLeft[$scope.wholeParentArrayLeft[i].id] = false;
                        var el = angular.element('#parentLeft' + (i + 1));
                        el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                    }
                }
                $scope.boolLeft[parentobj.id] = !$scope.boolLeft[parentobj.id];
                if ($scope.boolLeft[parentobj.id])
                {
                    var el = angular.element('#parentLeft' + _index);
                    el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
                }
                else
                {
                    var el = angular.element('#parentLeft' + _index);
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
            else if(direction == "Right")
            {
                for (i = 0; i < $scope.wholeParentArrayRight.length; i++)
                {
                    if ($scope.wholeParentArrayRight[i].id != parentobj.id)
                    {
                        $scope.boolRight[$scope.wholeParentArrayRight[i].id] = false;
                        var el = angular.element('#parentRight' + (i + 1));
                        el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                    }
                }
                $scope.boolRight[parentobj.id] = !$scope.boolRight[parentobj.id];
                if ($scope.boolRight[parentobj.id])
                {
                    var el = angular.element('#parentRight' + _index);
                    el[0].childNodes[1].src = "images/accountDashboard/menu-up-arrow.svg";
                }
                else
                {
                    var el = angular.element('#parentRight' + _index);
                    el[0].childNodes[1].src = "images/accountDashboard/menu-arrow-right.svg";
                }
            }
        };
        
        $scope.updateNetworkDropDown = function(direction)
        {
            if(direction == "Left")
            {
                var networkArray = [];
                if($scope.advertiserIdLeft != "" && $scope.advertiserIdLeft != undefined)
                {
//                    console.log("netowrk drop down - advertiser selected");
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        var obj = {
                                            "networkId":$scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                            "networkName":$scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                            "networkURL":$scope.networkmaparrayonload[i].networkDetails[j].networkURL  
                                        };
                                        networkArray.push(obj);
                                    }
                                }
                            }
                        }
                    }
//                    console.log(networkArray);
                    $scope.networkDropDownLeft = angular.copy(networkArray);
                }
                else
                {
                    $scope.networkDropDownLeft = angular.copy($scope.networkDropDownOnLoad);
                }
            }
            else if(direction == "Right")
            {
                var networkArray = [];
                if($scope.advertiserIdRight != "" && $scope.advertiserIdRight != undefined)
                {
//                    console.log("netowrk drop down - advertiser selected");
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.advertiserIdRight == $scope.networkmaparray[i].advertiserId)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        var obj = {
                                            "networkId":$scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                            "networkName":$scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                            "networkURL":$scope.networkmaparrayonload[i].networkDetails[j].networkURL  
                                        };
                                        networkArray.push(obj);
                                    }
                                }
                            }
                        }
                    }
    //                console.log(networkArray);
                    $scope.networkDropDownRight = angular.copy(networkArray);
                }
                else
                {
                    $scope.networkDropDownRight = angular.copy($scope.networkDropDownOnLoad);
                }
            }
        };
        
        $scope.updateCampaignDropDown = function(direction)
        {
            if(direction == "Left")
            {
                $scope.wholeParentArrayLeft = [];
                $scope.wholechildArrayLeft = [];
                if($scope.advertiserIdLeft != "" && $scope.advertiserIdLeft != undefined)
                {
                    if($scope.networkIdLeft != "" && $scope.networkIdLeft != undefined)
                    {
//                        console.log("both advertiser and network selected left");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparrayonload[i].networkDetails[j].networkId == $scope.networkIdLeft)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent",
                                                        };
                                                    $scope.wholeParentArrayLeft.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdLeft)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdLeft)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                            "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                            "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                            "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                            };
                                                        $scope.wholechildArrayLeft.push(obj);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
//                        console.log("advertiser selected but no network left");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                var obj = {
                                                    "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                    "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                    "type":"parent"
                                                    };
                                                $scope.wholeParentArrayLeft.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdLeft)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                        "type":"child",
                                                        "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                        };
                                                    $scope.wholechildArrayLeft.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if($scope.networkIdLeft != "" && $scope.networkIdLeft != undefined)
                    {
//                        console.log("network selected but no advertiser left");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                var obj = {
                                                    "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                    "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                    "type":"parent"
                                                    };
                                                $scope.wholeParentArrayLeft.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                        "type":"child",
                                                        "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                        };
                                                    $scope.wholechildArrayLeft.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
//                        console.log("no advertiser and no network selected left");
                        $scope.wholeParentArrayLeft = [];
                        $scope.wholechildArrayLeft = [];
                        $scope.wholeParentArrayLeft = angular.copy($scope.wholeParentArrayOnLoad);
                        $scope.wholechildArrayLeft = angular.copy($scope.wholeChildArrayOnLoad);
                    }
                }
                var nonUniqueParentArray = [];
                var uniqueParentArray = [];
                var uniqueParentObjects = [];
                for(i=0;i<$scope.wholeParentArrayLeft.length;i++)
                {
                    nonUniqueParentArray.push($scope.wholeParentArrayLeft[i].id);
                }
                uniqueParentArray = nonUniqueParentArray.filter(function(elem, index, self) {
                    return index == self.indexOf(elem);
                });
                for(i=0;i<uniqueParentArray.length;i++)
                {
                    var obj = {
                        "id":uniqueParentArray[i],
                        "name":"",
                        "type":"parent"
                    };
                    uniqueParentObjects.push(obj);
                }
                for(i=0;i<uniqueParentObjects.length;i++)
                {
                    for(j=0;j<$scope.wholeParentArrayLeft.length;j++)
                    {
                        if($scope.wholeParentArrayLeft[j].id == uniqueParentObjects[i].id)
                        {
                            uniqueParentObjects[i].name = $scope.wholeParentArrayLeft[j].name;
                        }
                    }
                }
                $scope.wholeParentArrayLeft = angular.copy(uniqueParentObjects);
            }
            else if(direction == "Right")
            {
                $scope.wholeParentArrayRight = [];
                $scope.wholechildArrayRight = [];
                if($scope.advertiserIdRight != "" && $scope.advertiserIdRight != undefined)
                {
                    if($scope.networkIdRight != "" && $scope.networkIdRight != undefined)
                    {
//                        console.log("both advertiser and network selected right");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.advertiserIdRight == $scope.networkmaparray[i].advertiserId)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparrayonload[i].networkDetails[j].networkId == $scope.networkIdRight)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                        "type":"parent",
                                                        };
                                                    $scope.wholeParentArrayRight.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        var obj = {
                                                            "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                            "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                            "type":"child",
                                                            "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                            "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                            "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                            "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                            };
                                                        $scope.wholechildArrayRight.push(obj);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
//                        console.log("advertiser selected but no network right");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.advertiserIdRight == $scope.networkmaparray[i].advertiserId)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                var obj = {
                                                    "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                    "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                    "type":"parent"
                                                    };
                                                $scope.wholeParentArrayRight.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                        "type":"child",
                                                        "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                        };
                                                    $scope.wholechildArrayRight.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if($scope.networkIdRight != "" && $scope.networkIdRight != undefined)
                    {
//                        console.log("network selected but no advertiser right");
                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        if($scope.networkIdRight == $scope.networkmaparray[i].networkDetails[j].networkId)
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                var obj = {
                                                    "id":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                    "name":$scope.networkmaparray[i].networkDetails[j].parent[k].name,
                                                    "type":"parent"
                                                    };
                                                $scope.wholeParentArrayRight.push(obj);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        for(i=0;i<$scope.networkmaparray.length;i++)
                        {
                            if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        if($scope.networkIdRight == $scope.networkmaparray[i].networkDetails[j].networkId)
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    var obj = {
                                                        "id":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,
                                                        "name":$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].name,
                                                        "type":"child",
                                                        "parentid":$scope.networkmaparray[i].networkDetails[j].parent[k].id,
                                                        "status": $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].status,
                                                        "userNetworkMapId": $scope.networkmaparray[i].networkDetails[j].userNetworkMapId,
                                                        "networkUrl":$scope.networkmaparray[i].networkDetails[j].networkURL
                                                        };
                                                    $scope.wholechildArrayRight.push(obj);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
//                        console.log("no advertiser and no network selected right");
                        $scope.wholeParentArrayRight = [];
                        $scope.wholechildArrayRight = [];
                        $scope.wholeParentArrayRight = angular.copy($scope.wholeParentArrayOnLoad);
                        $scope.wholechildArrayRight = angular.copy($scope.wholeChildArrayOnLoad);
                    }
                }
                var nonUniqueParentArray = [];
                var uniqueParentArray = [];
                var uniqueParentObjects = [];
                for(i=0;i<$scope.wholeParentArrayRight.length;i++)
                {
                    nonUniqueParentArray.push($scope.wholeParentArrayRight[i].id);
                }
                uniqueParentArray = nonUniqueParentArray.filter(function(elem, index, self) {
                    return index == self.indexOf(elem);
                });
                for(i=0;i<uniqueParentArray.length;i++)
                {
                    var obj = {
                        "id":uniqueParentArray[i],
                        "name":"",
                        "type":"parent"
                    };
                    uniqueParentObjects.push(obj);
                }
                for(i=0;i<uniqueParentObjects.length;i++)
                {
                    for(j=0;j<$scope.wholeParentArrayRight.length;j++)
                    {
                        if($scope.wholeParentArrayRight[j].id == uniqueParentObjects[i].id)
                        {
                            uniqueParentObjects[i].name = $scope.wholeParentArrayRight[j].name;
                        }
                    }
                }
                $scope.wholeParentArrayRight = angular.copy(uniqueParentObjects);
            }
        };
        
        $scope.selectadvertiser = function(direction)
        {
            $scope.direction = direction;
            $scope.updateNetworkDropDown(direction);
            $scope.updateCampaignDropDown(direction);
            if(direction == "Left")
            {
                $scope.networkIdLeft = "";
                $scope.selectedParentChildCampaignLeft = "";
                $scope.selectedvalueLeft = "Select Campaign";
            }
            else if(direction == "Right")
            {
                $scope.networkIdRight = "";
                $scope.selectedParentChildCampaignRight = "";
                $scope.selectedvalueRight = "Select Campaign";
            }
            $scope.checkDropDownSelections();
        };
        
        $scope.selectnetwork = function(direction)
        {
            $scope.direction = direction;
            $scope.updateCampaignDropDown(direction);
            if(direction == "Left")
            {
                $scope.selectedParentChildCampaignLeft = "";
                $scope.selectedvalueLeft = "Select Campaign";
            }
            else if(direction == "Right")
            {
                $scope.selectedParentChildCampaignRight = "";
                $scope.selectedvalueRight = "Select Campaign";
            }
            $scope.checkDropDownSelections();
        };
        
        $scope.parentselection = function(_obj,direction)
        {
            $scope.direction = direction;
            if($scope.direction == "Left")
            {
                $scope.selectedvalueLeft = _obj.name;
                $scope.selectedParentChildCampaignLeft = _obj;
            }
            else if($scope.direction == "Right")
            {
                $scope.selectedvalueRight = _obj.name;
                $scope.selectedParentChildCampaignRight = _obj;
            }
            $scope.checkDropDownSelections();
        };
        
        $scope.childselection = function(_obj,direction)
        {
            $scope.direction = direction;
            if($scope.direction == "Left")
            {
                $scope.selectedvalueLeft = _obj.name;
                $scope.selectedParentChildCampaignLeft = _obj;
            }
            else if($scope.direction == "Right")
            {
                $scope.selectedvalueRight = _obj.name;
                $scope.selectedParentChildCampaignRight = _obj;
            }
            $scope.checkDropDownSelections();
        };
        
        $scope.handleErrors  = function()
        {
            var errorCheck = false;
            $scope.errorHeader = [];
            $scope.errorString = [];
    //        if(errorCheck)
            for(a=0;a<$scope.errors.length;a++)
            {
                if($scope.errors[a].hasOwnProperty("parentCampaignError"))
                {
                    errorCheck = true;
                    var obj = {
                        "Advertiser":"Advertiser: ",
                        "AdvertiserValue":$scope.errors[a].advertiserName,
                        "NetworkLogo":"",
                        "ParentCampaign":"",
                        "ParentCampaignValue":"",
                        "ChildCampaign":"",
                        "ChildCampaignValue":""
                    };
                    $scope.errorHeader.push(obj);
                    $scope.errorString.push($scope.errors[a].parentCampaignError.ErrorMessage);
                }
                if($scope.errors[a].hasOwnProperty("networkDetails"))
                {
                    for(b=0;b<$scope.errors[a].networkDetails.length;b++)
                    {
                        var netLogo = "";
                        if($scope.errors[a].networkDetails[b].networkURL == appSettings.fbNetwork)
                        {
                            netLogo = "images/accountDashboard/facebook.svg";
                        }
                        else if($scope.errors[a].networkDetails[b].networkURL == appSettings.twNetwork)
                        {
                            netLogo = "images/accountDashboard/twitter.svg";
                        }
                        if($scope.errors[a].networkDetails[b].hasOwnProperty("adAccountIdError"))
                        {
                            errorCheck = true;
                            var obj = {
                                "Advertiser":"Advertiser: ",
                                "AdvertiserValue":$scope.errors[a].advertiserName,
                                "NetworkLogo":netLogo,
                                "ParentCampaign":"",
                                "ParentCampaignValue":"",
                                "ChildCampaign":"",
                                "ChildCampaignValue":""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].adAccountIdError.ErrorMessage);
                        }
                        if($scope.errors[a].networkDetails[b].hasOwnProperty("parentCampaignError"))
                        {
                            errorCheck = true;
                            var obj = {
                                "Advertiser":"Advertiser: ",
                                "AdvertiserValue":$scope.errors[a].advertiserName,
                                "NetworkLogo":netLogo,
                                "ParentCampaign":"",
                                "ParentCampaignValue":"",
                                "ChildCampaign":"",
                                "ChildCampaignValue":""
                            };
                            $scope.errorHeader.push(obj);
                            $scope.errorString.push($scope.errors[a].networkDetails[b].parentCampaignError.ErrorMessage);
                        }
                        if($scope.errors[a].networkDetails[b].hasOwnProperty("parent"))
                        {
                            for(c=0;c<$scope.errors[a].networkDetails[b].parent.length;c++)
                            {
                                if($scope.errors[a].networkDetails[b].parent[c].hasOwnProperty("childCampaignError"))
                                {
                                    errorCheck = true;
                                    var obj = {
                                        "Advertiser":"Advertiser: ",
                                        "AdvertiserValue":$scope.errors[a].advertiserName,
                                        "NetworkLogo":netLogo,
                                        "ParentCampaign":"Parent Campaign: ",
                                        "ParentCampaignValue":$scope.errors[a].networkDetails[b].parent[c].name,
                                        "ChildCampaign":"",
                                        "ChildCampaignValue":""
                                    };
                                    $scope.errorHeader.push(obj);
                                    $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].childCampaignError.ErrorMessage);
                                }
                                for(d=0;d<$scope.errors[a].networkDetails[b].parent[c].campaigns.length;d++)
                                {
                                    if($scope.errors[a].networkDetails[b].parent[c].campaigns[d].hasOwnProperty("campaignInsightsError"))
                                    {
                                        errorCheck = true;
                                        var obj = {
                                            "Advertiser":"Advertiser: ",
                                            "AdvertiserValue":$scope.errors[a].advertiserName,
                                            "NetworkLogo":netLogo,
                                            "ParentCampaign":"Parent Campaign: ",
                                            "ParentCampaignValue":$scope.errors[a].networkDetails[b].parent[c].name,
                                            "ChildCampaign":"Child Campaign: ",
                                            "ChildCampaignValue":$scope.errors[a].networkDetails[b].parent[c].campaigns[d].name
                                        };
                                        $scope.errorHeader.push(obj);
                                        $scope.errorString.push($scope.errors[a].networkDetails[b].parent[c].campaigns[d].campaignInsightsError.ErrorMessage);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if(errorCheck)
            {
                $rootScope.progressLoader = "none";
                angular.element("#errorScroll").css("height","auto");
                angular.element("#errorScroll").css("overflow-y","hidden");
                angular.element("#moreErrors").css("display","flex");
                angular.element("#lessErrors").css("display","none");
                $scope.funnelFlowErrors = 'block';
                angular.element("#funnelFlowErrors").empty();
                for(a=0;a<$scope.errorHeader.length && a<2;a++)
                {
                    angular.element("#funnelFlowErrors").append(
                            "<div style='width:100%; display:flex; padding-bottom:20px;'>" +
                            "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                            "<div style='padding-right:10px;'>" +
                            "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                            "</div>" +
                            "</div>" +
                            "<div style='float:left; width:90%; padding-left:10px;'>" +
                            "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                            "</div>" + 
                            "</div>" +
                            "</div>"
                            );
                }
            }
            else
            {
//                console.log("no errors");
                if($scope.whatToCall[0] == "getAdvertiserDetails")
                {
                    $scope.whatToCall = [];
                    $scope.getAdvertiserDetails();
                }
                else if($scope.whatToCall[0] == "checkDropDownSelections")
                {
                    $scope.whatToCall = [];
                    $scope.checkDropDownSelections();
                }
            }
        };
        
        $scope.resetPopup = function() 
        {
            $scope.editAdsetErrorMsg = 'none';
            $scope.funnelFlowErrors = "none";
            angular.element("#errorScroll").scrollTop(0);
            console.log($scope.whatToCall);
            if($scope.whatToCall[0] == "getAdvertiserDetails")
            {
                $scope.whatToCall = [];
                $scope.getAdvertiserDetails();
            }
            else if($scope.whatToCall[0] == "checkDropDownSelections")
            {
                $scope.whatToCall = [];
                $scope.checkDropDownSelections();
            }
            //$rootScope.progressLoader = "block";
        };
        
        $scope.viewMoreErrors = function()
        {
            angular.element("#errorScroll").css("height","175px");
            angular.element("#errorScroll").css("overflow-y","auto");
            angular.element("#moreErrors").css("display","none");
            angular.element("#lessErrors").css("display","flex");
            angular.element("#funnelFlowErrors").empty();
            for(a=0;a<$scope.errorHeader.length;a++)
            {
                if($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign != "")
                {
                    angular.element("#funnelFlowErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ChildCampaign + "<b>" + $scope.errorHeader[a].ChildCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
                else if($scope.errorHeader[a].ParentCampaign == "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#funnelFlowErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
                else if($scope.errorHeader[a].ParentCampaign != "" && $scope.errorHeader[a].ChildCampaign == "")
                {
                    angular.element("#funnelFlowErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:40px;'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid #e6e6e6;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; padding:0px 0px 2.5px 0px;'>" + $scope.errorHeader[a].Advertiser + "<b>" + $scope.errorHeader[a].AdvertiserValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px;'>" + $scope.errorHeader[a].ParentCampaign + "<b>" + $scope.errorHeader[a].ParentCampaignValue + "</b>" +
                        "</div>" +
                        "<div style='width:100%; padding:2.5px 0px 0px 0px; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
                }
            }
        };
        
        $scope.viewLessErrors = function()
        {
            angular.element("#errorScroll").css("height","auto");
            angular.element("#errorScroll").css("overflow-y","hidden");
            angular.element("#moreErrors").css("display","flex");
            angular.element("#lessErrors").css("display","none");
            angular.element("#funnelFlowErrors").empty();
            for(a=0;a<$scope.errorHeader.length && a<2;a++)
            {
                angular.element("#funnelFlowErrors").append(
                        "<div style='width:100%; display:flex; padding-bottom:20px;'>" +
                        "<div style='float:left; width:10%; display:flex; flex-direction:column; justify-content:center; border-right:1px solid gainsboro;'>" +
                        "<div style='padding-right:10px;'>" +
                        "<img src='"+$scope.errorHeader[a].NetworkLogo+"' style='width:24px; height:24px; float:right;'>" +
                        "</div>" +
                        "</div>" +
                        "<div style='float:left; width:90%; padding-left:10px;'>" +
                        "<div style='width:100%; color:red;'>" + $scope.errorString[a] +
                        "</div>" + 
                        "</div>" +
                        "</div>"
                        );
            }
        };

        $scope.getAdvertiserDetails = function()
        {
            var promises = [];
            var getAdvertiserDetails = false;
            promises.push(performanceServices.advertiserdatafetch($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {
                    getAdvertiserDetails = true;
                    $scope.advertiserdetails = response.advDataFetchResponse;
                    if(!$scope.accountRole)
                    {
                        $scope.advertiserName = response.advDataFetchResponse[0].advertiserName;
                    }
                } 
                else{
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $scope.leftAvailability = "false";
                        $scope.rightAvailability = "false";
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(getAdvertiserDetails)
                        {
                            $scope.allnetworks();
                        }
                    });
        };
        
        $scope.allnetworks = function()
        {
            var allnetworks = false;
            var promises = [];
            promises.push(performanceServices.fetchallnetwork().then(function (response){
                if (response.appStatus == '0') {
                    allnetworks = true;
                    $scope.allnetworksarray = response.networkList;
                }
                else{
                    $scope.leftAvailability = "false";
                    $scope.rightAvailability = "false";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(allnetworks)
                        {
    //                            $scope.allnetworks();
                            $scope.networksforacc();
                        }
                    });
        };
        
        $scope.networksforacc = function()
        {
            var networksforaccount = false;
            var promises = [];
            promises.push(performanceServices.fetchadvertisernetwork($window.localStorage.getItem("accountId")).then(function (response){
                if (response.appStatus == '0') {// success
                    networksforaccount = true;
                    $scope.networksarrayforacc = response.advertiserNetworkList;
                }
                else{
                    $scope.leftAvailability = "false";
                    $scope.rightAvailability = "false";
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            if (response.networkError.message != '' && response.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.networkError.error_user_title;
                                    $scope.errorMsg = response.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(
                    function(){
                        if(networksforaccount)
                        {
                             $scope.getusernetworkmapids();
                        }
                    });
        };
        
        $scope.getusernetworkmapids = function()
        {
            var promises = [];
            var readAdAccountSuccess = false;
            angular.forEach($scope.advertiserdetails, function (val, key){
                var networkdetailobj=[];

                var i = 0;
                var obj={
                    "advertiseremail":val.advertiserEmail,
                    "advertiserId":val.advertiserId,
                    "advertiserName":val.advertiserName
                };
                for (i = 0; i < $scope.networksarrayforacc.length; i++){   
                    if (val.advertiserEmail == $scope.networksarrayforacc[i].userId){
                        for(var j = 0; j<$scope.allnetworksarray.length; j++){
                            if($scope.allnetworksarray[j].networkId==$scope.networksarrayforacc[i].networkId){   
                                var obj2={
                                    "networkId" : $scope.allnetworksarray[j].networkId,
                                    "networkName" : $scope.allnetworksarray[j].networkName,
                                    "userNetworkMapId" : $scope.networksarrayforacc[i].userNetworkMapId,
                                    "networkURL" : $scope.allnetworksarray[j].networkUrl
                                };
                                networkdetailobj.push(obj2);
                            }
                        };
                        obj['networkDetails']=networkdetailobj;
                    }
                }
                $scope.networkmaparrayonload.push(obj);
            });
            $scope.errors = angular.copy($scope.networkmaparrayonload);
            for (i = 0; i < $scope.networkmaparrayonload.length; i++)
            {
                if ($scope.networkmaparrayonload[i].hasOwnProperty('networkDetails')) 
                {
                    for(j=0; j< $scope.networkmaparrayonload[i].networkDetails.length; j++)
                    {
                        (function(i,j)
                        {
                            if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                            {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.fbNetwork).then(function(response)
                                {    
                                    if(response.appStatus == 0)
                                    {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.fbReadAdAccountResponse, function (value, key) 
                                        {
                                            var parent = [];
                                            $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                            $scope.errors[i].networkDetails[j]["adAccountId"]=response.fbReadAdAccountResponse[key].fbAdAccountId;
                                            $scope.errors[i].networkDetails[j]["parent"]= angular.copy(parent);
                                        });
                                    }
                                    else
                                    {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                        {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        }
                                        else 
                                        {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) 
                                            {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                {
                                                        obj["Error"] = "Error";
                                                        obj["ErrorMessage"] = response.networkError.message;
                                                }
                                                else 
                                                {
                                                        obj["Error"] = response.networkError.error_user_title;
                                                        obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            }
                                            else 
                                            {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                            else if($scope.networkmaparrayonload[i].networkDetails[j].networkURL == appSettings.twNetwork)
                            {
                                promises.push(performanceServices.readadaccounts($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,appSettings.twNetwork).then(function(response)
                                {
                                    if(response.appStatus == 0)
                                    {
                                        readAdAccountSuccess = true;
                                        angular.forEach(response.adAccounts,function(value,key)
                                        {
                                            angular.forEach(value,function(value2,key2)
                                            {
                                                var parent = [];
                                                $scope.networkmaparrayonload[i].networkDetails[j]["adAccountId"]=value2.twAdAccountId;
                                                $scope.networkmaparrayonload[i].networkDetails[j]["parent"] = parent;
                                                $scope.errors[i].networkDetails[j]["adAccountId"]=value2.twAdAccountId;
                                                $scope.errors[i].networkDetails[j]["parent"]= angular.copy(parent);
                                            });
                                        });
                                    }
                                    else
                                    {
                                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                        {
                                            $window.localStorage.setItem("TokenExpired", true);
                                            $state.go('login');
                                        } 
                                        else 
                                        {
                                            var obj = {};
                                            if (response.networkError != '' && response.networkError != undefined) 
                                            {
                                                if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                {
                                                        obj["Error"] = "Error";
                                                        obj["ErrorMessage"] = response.networkError.message;
                                                }
                                                else
                                                {
                                                        obj["Error"] = response.networkError.error_user_title;
                                                        obj["Error"] = response.networkError.error_user_msg;
                                                }
                                            } 
                                            else
                                            {
                                                    obj["Error"] = "Error";
                                                    obj["ErrorMessage"] = response.errorMessage;
                                            }
                                            $scope.errors[i].networkDetails[j]["adAccountIdError"] = obj;
                                        }
                                    }
                                }));
                            }
                        })(i,j);
                    }
                }
            }
            $q.all(promises).finally(
                    function(){
                        if(readAdAccountSuccess)
                        {
                            $scope.fillDropDowns();
                        }
                        else
                        {
                            $scope.handleErrors();
                            $rootScope.progressLoader = "none";
                        }
                    });
        };
        
        $scope.fillDropDowns = function()
        {
            var promises = [];
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                var obj = {
                    "advertiserName":$scope.networkmaparrayonload[i].advertiserName,
                    "advertiserId":$scope.networkmaparrayonload[i].advertiserId
                };
                $scope.advertiserDropDown.push(obj);
            }
    //===========================================================Network Drop Down==================================================================
            var allnetworkswithduplicate = [];
            var allnetworkswithoutduplicate = [];
            var allnetworkswithduplicateobjects = [];
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                        {
                            var obj = {
                                "networkId":$scope.networkmaparrayonload[i].networkDetails[j].networkId,
                                "networkName":$scope.networkmaparrayonload[i].networkDetails[j].networkName,
                                "networkURL":$scope.networkmaparrayonload[i].networkDetails[j].networkURL
                            };
                            allnetworkswithduplicate.push($scope.networkmaparrayonload[i].networkDetails[j].networkName);
                            allnetworkswithduplicateobjects.push(obj);
                        }
                    }
                }
            }
            allnetworkswithoutduplicate = allnetworkswithduplicate.filter(function(elem, index, self) {
                return index == self.indexOf(elem);
            });
            for(i=0;i<allnetworkswithoutduplicate.length;i++)
            {
                var obj = {
                    "networkId":"",
                    "networkName":allnetworkswithoutduplicate[i],
                    "networkURL":""
                };
                $scope.networkDropDown.push(obj);
            }
            for(i=0;i<$scope.networkDropDown.length;i++)
            {
                for(j=0;j<allnetworkswithduplicateobjects.length;j++)
                {
                    if($scope.networkDropDown[i].networkName == allnetworkswithduplicateobjects[j].networkName)
                    {
                        $scope.networkDropDown[i].networkId = allnetworkswithduplicateobjects[j].networkId;
                        $scope.networkDropDown[i].networkURL = allnetworkswithduplicateobjects[j].networkURL;
                    }
                }
            }
            $scope.networkDropDownOnLoad = angular.copy($scope.networkDropDown);
            $scope.networkDropDownLeft = angular.copy($scope.networkDropDown);
            $scope.networkDropDownRight = angular.copy($scope.networkDropDown);
    //==============================================================================================================================================
            var parentSuccess = false;
            for(i=0;i<$scope.networkmaparrayonload.length;i++)
            {
                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                {
                    (function(i)
                    {
                        promises.push(performanceServices.fetchparentcampaignsbyadvertiser($scope.networkmaparrayonload[i].advertiserId).then(function(response)
                        {
                            if (response.appStatus == '0') 
                            {// success
                                $scope.campaigndetails = response.parentCampaigns;
                                if($scope.campaigndetails.length > 0)
                                {
                                    parentSuccess = true;
                                }
                                else if($scope.campaigndetails.length == 0)
                                {
                                    var obj = {
                                        "Error":"Error",
                                        "ErrorMessage":"No parent campaigns found"
                                    };
                                    $scope.errors[i]['parentCampaignError'] = obj;
                                }
                                for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        for (var k = 0; k < $scope.campaigndetails.length; k++)
                                        {
                                            var _obj = {
                                                "id": $scope.campaigndetails[k].parentCampaignId,
                                                "name": $scope.campaigndetails[k].parentCampaignName,
                                                "type": "parent",
                                                "userNetworkMapId": $scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId,
                                                "networkUrl":$scope.networkmaparrayonload[i].networkDetails[j].networkURL
                                            };
                                            $scope.wholeParentArray.push(_obj);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                } else {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) 
                                    {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) 
                                        {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.networkError.message;
                                        }
                                        else
                                        {
                                                obj["Error"] = response.networkError.error_user_title;
                                                obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } 
                                    else
                                    {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    $scope.errors[i]['parentCampaignError'] = obj;
                                }
                            }
                        }));
                    })(i);
                }
            };

            $q.all(promises).finally(
                function()
                {
                    for(a=0;a<$scope.wholeParentArray.length;a++)
                    {
                        for(i=0;i<$scope.networkmaparrayonload.length;i++)
                        {
                            if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                            {
                                for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                {
                                    if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                    {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholeParentArray[a].userNetworkMapId)
                                        {
                                            var campaigns = [];
                                            var obj = {
                                                "id":$scope.wholeParentArray[a].id,
                                                "name":$scope.wholeParentArray[a].name,
                                                "type":"Parent",
                                                "campaigns":[]
                                            };
                                            $scope.networkmaparrayonload[i].networkDetails[j].parent.push(obj);
                                            $scope.errors[i].networkDetails[j].parent.push(angular.copy(obj));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(parentSuccess)
                    {
                        $scope.fetchallchildandpush();
                    }
                    else
                    {
                        $scope.handleErrors();
                        $rootScope.progressLoader = "none";
                    }
                });
        };
        
        $scope.fetchallchildandpush = function()
        {
            var promises = [];
            var campaignSuccess = false;
            for(i=0;i<$scope.wholeParentArray.length;i++)
            {
                (function(i)
                {
                    if($scope.wholeParentArray[i].networkUrl == appSettings.fbNetwork)
                    {    
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.fbNetwork,undefined).then(function (response) 
                        {
                            if (response.appStatus == '0') 
                            {
                                campaignSuccess = true;
                                $scope.childCampaigns = response.adcampaigns;
                                var count = 0;
                                angular.forEach($scope.childCampaigns, function (value, key) 
                                {
                                    var JsonObj = $scope.childCampaigns[key];
                                    var array = [];
                                    for (var j in JsonObj) 
                                    {
                                        if (JsonObj.hasOwnProperty(j) && !isNaN(+j)) 
                                        {
                                            array[+j] = JsonObj[j];
                                            var _obj = {
                                                "id": array[+j].campaignId,
                                                "name": array[+j].campaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": array[+j].campaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            count++;
                                            $scope.wholechildArray.push(_obj);
                                        }
                                    }
                                });
                            }
                            else 
                            {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                }
                                else 
                                {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) 
                                    {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) 
                                        {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.networkError.message;
                                        }
                                        else
                                        {
                                                obj["Error"] = response.networkError.error_user_title;
                                                obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } 
                                    else
                                    {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for(a=0;a<$scope.errors.length;a++)
                                    {
                                        if($scope.errors[a].hasOwnProperty("networkDetails"))
                                        {
                                            for(b=0;b<$scope.errors[a].networkDetails.length;b++)
                                            {
                                                if($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId)
                                                {
                                                    for(c=0;c<$scope.errors[a].networkDetails[b].parent.length;c++)
                                                    {
                                                        if($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id)
                                                        {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    }
                    else if($scope.wholeParentArray[i].networkUrl == appSettings.twNetwork)
                    {
                        promises.push(performanceServices.readadcampaign($scope.wholeParentArray[i].userNetworkMapId,$scope.wholeParentArray[i].id,appSettings.twNetwork,undefined).then(function (response) 
                        {
                            if (response.appStatus == '0') 
                            {
                                campaignSuccess = true;
                                angular.forEach(response.campaign,function(value,key)
                                {
                                    angular.forEach(value,function(value2,key2)
                                    {
                                        var _obj = {
                                                "id": value2.twCampaignDetails.id,
                                                "name": value2.twCampaignDetails.name,
                                                "type": "child",
                                                "parentid": $scope.wholeParentArray[i].id,
                                                "status": value2.twCampaignStatus,
                                                "userNetworkMapId": $scope.wholeParentArray[i].userNetworkMapId,
                                                "networkUrl":$scope.wholeParentArray[i].networkUrl
                                            };
                                            $scope.wholechildArray.push(_obj);
                                    });
                                });
                            }
                            else 
                            {
                                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) 
                                {
                                    $window.localStorage.setItem("TokenExpired", true);
                                    $state.go('login');
                                }
                                else 
                                {
                                    var obj = {};
                                    if (response.networkError != '' && response.networkError != undefined) 
                                    {
                                        if (response.networkError.message != '' && response.networkError.message != undefined) 
                                        {
                                                obj["Error"] = "Error";
                                                obj["ErrorMessage"] = response.networkError.message;
                                        }
                                        else
                                        {
                                                obj["Error"] = response.networkError.error_user_title;
                                                obj["Error"] = response.networkError.error_user_msg;
                                        }
                                    } 
                                    else
                                    {
                                            obj["Error"] = "Error";
                                            obj["ErrorMessage"] = response.errorMessage;
                                    }
                                    for(a=0;a<$scope.errors.length;a++)
                                    {
                                        if($scope.errors[a].hasOwnProperty("networkDetails"))
                                        {
                                            for(b=0;b<$scope.errors[a].networkDetails.length;b++)
                                            {
                                                if($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.wholeParentArray[i].userNetworkMapId)
                                                {
                                                    for(c=0;c<$scope.errors[a].networkDetails[b].parent.length;c++)
                                                    {
                                                        if($scope.errors[a].networkDetails[b].parent[c].id == $scope.wholeParentArray[i].id)
                                                        {
                                                            $scope.errors[a].networkDetails[b].parent[c]['childCampaignError'] = obj;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    }
                })(i);
            }
            $q.all(promises).finally(
                    function(){
                    if(campaignSuccess)
                    {
                        for(a=0;a<$scope.wholechildArray.length;a++)
                        {
                            for(i=0;i<$scope.networkmaparrayonload.length;i++)
                            {
                                if($scope.networkmaparrayonload[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparrayonload[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparrayonload[i].networkDetails[j].userNetworkMapId == $scope.wholechildArray[a].userNetworkMapId)
                                        {
                                            if($scope.networkmaparrayonload[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparrayonload[i].networkDetails[j].parent.length;k++)
                                                {
                                                    if($scope.networkmaparrayonload[i].networkDetails[j].parent[k].id == $scope.wholechildArray[a].parentid)
                                                    {
                                                        var insights = [];
                                                        var obj = {
                                                            "id":$scope.wholechildArray[a].id,
                                                            "name":$scope.wholechildArray[a].name,
                                                            "parentId":$scope.wholechildArray[a].parentid,
                                                            "type":"child",
                                                            "status":$scope.wholechildArray[a].status,
                                                            "insights":insights
                                                        };
                                                        $scope.networkmaparrayonload[i].networkDetails[j].parent[k].campaigns.push(obj);
                                                        $scope.errors[i].networkDetails[j].parent[k].campaigns.push(angular.copy(obj));
                                                   }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        var nonUniqueParentArray = [];
                        var uniqueParentArray = [];
                        var uniqueParentObjects = [];
                        for(i=0;i<$scope.wholeParentArray.length;i++)
                        {
                            nonUniqueParentArray.push($scope.wholeParentArray[i].id);
                        }
                        uniqueParentArray = nonUniqueParentArray.filter(function(elem, index, self) {
                            return index == self.indexOf(elem);
                        });
                        for(i=0;i<uniqueParentArray.length;i++)
                        {
                            var obj = {
                                "id":uniqueParentArray[i],
                                "name":"",
                                "type":"parent"
                            };
                            uniqueParentObjects.push(obj);
                        }
                        for(i=0;i<uniqueParentObjects.length;i++)
                        {
                            for(j=0;j<$scope.wholeParentArray.length;j++)
                            {
                                if($scope.wholeParentArray[j].id == uniqueParentObjects[i].id)
                                {
                                    uniqueParentObjects[i].name = $scope.wholeParentArray[j].name;
                                }
                            }
                        }
                        $scope.wholeParentArray = angular.copy(uniqueParentObjects);
                        $scope.wholeParentArrayOnLoad = angular.copy($scope.wholeParentArray);
                        $scope.wholeChildArrayOnLoad = angular.copy($scope.wholechildArray);
                        $scope.networkmaparray = angular.copy($scope.networkmaparrayonload);
                        $scope.wholeParentArrayLeft = angular.copy($scope.wholeParentArray);
                        $scope.wholeParentArrayRight = angular.copy($scope.wholeParentArray);
                        $scope.wholechildArrayLeft = angular.copy($scope.wholechildArray);
                        $scope.wholechildArrayRight = angular.copy($scope.wholechildArray);

                        $scope.readcampaigninsights();
                    }
                    else
                    {
                        $scope.handleErrors();
                        $rootScope.progressLoader = "none";
                    }

                });
        };
        
        $scope.readcampaigninsights = function()
        {
            var insights = [];
            var promises = [];
            for(i=0;i<$scope.networkmaparray.length;i++)
            {
                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                {
                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                    {
                        if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.fbNetwork)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        (function(i,j,k,l)
                                        {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,undefined,undefined,appSettings.fbNetwork,true).then(function(response)
                                            {
                                                var insight = {};
                                                if(response.appStatus == 0)
                                                {
                                                    var resp = response.adCampaignInsights;
                                                    angular.forEach(resp, function(value,key)
                                                    {
                                                        angular.forEach(value, function(value2,key2)
                                                        {
                                                            var obj = {};
                                                            obj['engagements'] = 0;
                                                            obj['clicks'] = value2.clicks;
                                                            obj['actions'] = value2.callToAction;
                                                            obj['impressions'] = value2.impressions;
                                                            insight[key2] = obj;
                                                        });
                                                    });
                                                    insights.push(insight);
                                                }
                                                else{
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) 
                                                        {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                            {
                                                                    obj["Error"] = "Error";
                                                                    obj["ErrorMessage"] = response.networkError.message;
                                                            }
                                                            else
                                                            {
                                                                    obj["Error"] = response.networkError.error_user_title;
                                                                    obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } 
                                                        else
                                                        {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for(a=0;a<$scope.errors.length;a++)
                                                        {
                                                            if($scope.errors[a].hasOwnProperty("networkDetails"))
                                                            {
                                                                for(b=0;b<$scope.errors[a].networkDetails.length;b++)
                                                                {
                                                                    if($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId)
                                                                    {
                                                                        for(c=0;c<$scope.errors[a].networkDetails[b].parent.length;c++)
                                                                        {
                                                                            for(d=0;d<$scope.errors[a].networkDetails[b].parent[c].campaigns.length;d++)
                                                                            {
                                                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id)
                                                                                {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i,j,k,l);
                                    }
                                }
                            }
                        }
                        else if($scope.networkmaparray[i].networkDetails[j].networkURL == appSettings.twNetwork)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        (function(i,j,k,l)
                                        {
                                            promises.push(performanceServices.readadcampaigninsights($scope.networkmaparray[i].networkDetails[j].userNetworkMapId,$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id,undefined,undefined,undefined,undefined,appSettings.twNetwork,true).then(function(response)
                                            {     
                                                var insight = {};
                                                if(response.appStatus == 0)
                                                { 
                                                    var obj = {};
                                                    angular.forEach(response.adCampaignInsights,function(value,key)
                                                    {
                                                        angular.forEach(value ,function(value2,key2)
                                                        {
                                                            obj['clicks'] = value2.clicks;
                                                            obj['actions'] = value2.callToAction;
                                                            obj['impressions'] = value2.impressions;
                                                            angular.forEach(value2.insightsDetails,function(value3,key3)
                                                            {
                                                                angular.forEach(value3,function(value4,key4)
                                                                {
                                                                    angular.forEach(value4.metrics,function(value5,key5)
                                                                    {
                                                                        angular.forEach(value5,function(value6,key6)
                                                                        {
                                                                            if(typeof(value6) == "number")
                                                                            {
                                                                                if(key5 == "engagements")
                                                                                {
                                                                                    obj['engagements'] = value6;
                                                                                }
                                                                            }
                                                                        });
                                                                    });

                                                                });
                                                            });
                                                        });
                                                    });
                                                    insight[$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id] = obj;
                                                    insights.push(insight);
                                                }
                                                else{
                                                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                                        $window.localStorage.setItem("TokenExpired", true);
                                                        $state.go('login');
                                                    } else {
                                                        var obj = {};
                                                        if (response.networkError != '' && response.networkError != undefined) 
                                                        {
                                                            if (response.networkError.message != '' && response.networkError.message != undefined) 
                                                            {
                                                                    obj["Error"] = "Error";
                                                                    obj["ErrorMessage"] = response.networkError.message;
                                                            }
                                                            else
                                                            {
                                                                    obj["Error"] = response.networkError.error_user_title;
                                                                    obj["Error"] = response.networkError.error_user_msg;
                                                            }
                                                        } 
                                                        else
                                                        {
                                                                obj["Error"] = "Error";
                                                                obj["ErrorMessage"] = response.errorMessage;
                                                        }
                                                        for(a=0;a<$scope.errors.length;a++)
                                                        {
                                                            if($scope.errors[a].hasOwnProperty("networkDetails"))
                                                            {
                                                                for(b=0;b<$scope.errors[a].networkDetails.length;b++)
                                                                {
                                                                    if($scope.errors[a].networkDetails[b].userNetworkMapId == $scope.networkmaparray[i].networkDetails[j].userNetworkMapId)
                                                                    {
                                                                        for(c=0;c<$scope.errors[a].networkDetails[b].parent.length;c++)
                                                                        {
                                                                            for(d=0;d<$scope.errors[a].networkDetails[b].parent[c].campaigns.length;d++)
                                                                            {
                                                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.errors[a].networkDetails[b].parent[c].campaigns[d].id)
                                                                                {
                                                                                    $scope.errors[a].networkDetails[b].parent[c].campaigns[d]['campaignInsightsError'] = obj;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }));
                                        })(i,j,k,l);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $q.all(promises).finally(function(){
                    for(i=0;i<$scope.networkmaparray.length;i++)
                    {
                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                        {
                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                            {
                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                {
                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                    {
                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                        {
                                            angular.forEach(insights, function(value,key)
                                            {
                                                angular.forEach(value, function(value2,key2)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == key2)
                                                    {
                                                        $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.push(value2);
                                                    }
                                                });
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
    //                console.log(JSON.stringify($scope.networkmaparray, null,2));
                    $scope.whatToCall = [];
                    $scope.whatToCall.push("checkDropDownSelections");
                    $scope.handleErrors();
            });
        };
        
        $scope.checkDropDownSelections = function()
        {
            if($scope.direction == "Left")
            {
                $scope.leftData = [{"state": "Actions", "grade":"Noplot" ,"count": 0},
                            {"state": "Actions", "grade":"Plot_Actions" ,"count": 0},
                            {"state": "Clicks", "grade":"Noplot" ,"count": 0},
                            {"state": "Clicks", "grade":"Plot_Clicks" ,"count": 0},
                            {"state": "Engagements", "grade":"Noplot" ,"count": 0},
                            {"state": "Engagements", "grade":"Plot_Engagements" ,"count": 0},
                            {"state": "Impressions", "grade":"Noplot" ,"count": 0},
                            {"state": "Impressions", "grade":"Plot_Impressions" ,"count": 0}];
            }
            else if($scope.direction == "Right")
            {
                $scope.rightData = [{"state": "Actions", "grade":"Noplot" ,"count": 0},
                            {"state": "Actions", "grade":"Plot_Actions" ,"count": 0},
                            {"state": "Clicks", "grade":"Noplot" ,"count": 0},
                            {"state": "Clicks", "grade":"Plot_Clicks" ,"count": 0},
                            {"state": "Engagements", "grade":"Noplot" ,"count": 0},
                            {"state": "Engagements", "grade":"Plot_Engagements" ,"count": 0},
                            {"state": "Impressions", "grade":"Noplot" ,"count": 0},
                            {"state": "Impressions", "grade":"Plot_Impressions" ,"count": 0}];
            }
            $scope.graphRendered = false;
            if($scope.direction == "Left")
            {
//                console.log("==========LEFT==========");
//                console.log("Advertiser",$scope.advertiserIdLeft);
//                console.log("Network",$scope.networkIdLeft);
//                console.log("ParentChild",$scope.selectedParentChildCampaignLeft);
//                console.log("==========LEFT==========");
//                $scope.plotLeftGraph($scope.sampleData);
//                $scope.plotRightGraph($scope.sampleData);
                if($scope.advertiserIdLeft != "" && $scope.advertiserIdLeft != undefined)
                {
                    if($scope.networkIdLeft != "" && $scope.networkIdLeft != undefined)
                    {
                        if($scope.selectedParentChildCampaignLeft != "" && $scope.selectedParentChildCampaignLeft != undefined)
                        {
                            if($scope.selectedParentChildCampaignLeft.type == "parent")
                            {
//                                console.log("left, advertiser, network, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                                            {
                                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                                {
                                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                    {
                                                                        for(n=0;n<$scope.leftData.length;n++)
                                                                        {
                                                                            if($scope.leftData[n].state == "Impressions")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                    $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                                    
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Engagements")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                    $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Clicks")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                    $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Actions")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                    $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignLeft.type == "child")
                            {
//                                console.log("left, advertiser, network, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                                                {
                                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                    {
                                                                        for(n=0;n<$scope.leftData.length;n++)
                                                                        {
                                                                            if($scope.leftData[n].state == "Impressions")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                    $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Engagements")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                    $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Clicks")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                    $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.leftData[n].state == "Actions")
                                                                            {
                                                                                if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                                {
                                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                    $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("left, advertiser, network");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.leftData.length;n++)
                                                                {
                                                                    if($scope.leftData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Actions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaignLeft != "" && $scope.selectedParentChildCampaignLeft != undefined)
                        {
                            if($scope.selectedParentChildCampaignLeft.type == "parent")
                            {
//                                console.log("left, advertiser, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.leftData.length;n++)
                                                                    {
                                                                        if($scope.leftData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Actions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignLeft.type == "child")
                            {
//                                console.log("left, advertiser, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.leftData.length;n++)
                                                                    {
                                                                        if($scope.leftData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Actions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("left, advertiser");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.advertiserIdLeft == $scope.networkmaparray[i].advertiserId)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                        {
                                                            for(n=0;n<$scope.leftData.length;n++)
                                                            {
                                                                if($scope.leftData[n].state == "Impressions")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                        $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Engagements")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                        $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Clicks")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                        $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Actions")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                        $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if($scope.networkIdLeft != "" && $scope.networkIdLeft != undefined)
                    {
                        if($scope.selectedParentChildCampaignLeft != "" && $scope.selectedParentChildCampaignLeft != undefined)
                        {
                            if($scope.selectedParentChildCampaignLeft.type == "parent")
                            {
//                                console.log("left, network, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].id)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.leftData.length;n++)
                                                                    {
                                                                        if($scope.leftData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Actions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignLeft.type == "child")
                            {
//                                console.log("left, network, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            if($scope.selectedParentChildCampaignLeft.id == $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.leftData.length;n++)
                                                                    {
                                                                        if($scope.leftData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.leftData[n].state == "Actions")
                                                                        {
                                                                            if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("left, network");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkIdLeft == $scope.networkmaparray[i].networkDetails[j].networkId)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                        {
                                                            for(n=0;n<$scope.leftData.length;n++)
                                                            {
                                                                if($scope.leftData[n].state == "Impressions")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                        $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Engagements")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                        $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Clicks")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                        $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.leftData[n].state == "Actions")
                                                                {
                                                                    if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                    {
                                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                        $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaignLeft != "" && $scope.selectedParentChildCampaignLeft != undefined)
                        {
                            if($scope.selectedParentChildCampaignLeft.type == "parent")
                            {
//                                console.log("left, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].id == $scope.selectedParentChildCampaignLeft.id)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.leftData.length;n++)
                                                                {
                                                                    if($scope.leftData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Actions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignLeft.type == "child")
                            {
//                                console.log("left, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.selectedParentChildCampaignLeft.id)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.leftData.length;n++)
                                                                {
                                                                    if($scope.leftData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.leftData[n].state == "Actions")
                                                                    {
                                                                        if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("left, nothing");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                    {
                                                        for(n=0;n<$scope.leftData.length;n++)
                                                        {
                                                            if($scope.leftData[n].state == "Impressions")
                                                            {
                                                                if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                {
                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                    $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                                }
                                                            }
                                                            else if($scope.leftData[n].state == "Engagements")
                                                            {
                                                                if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                {
                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                    $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                                }
                                                            }
                                                            else if($scope.leftData[n].state == "Clicks")
                                                            {
                                                                if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                {
                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                    $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                                }
                                                            }
                                                            else if($scope.leftData[n].state == "Actions")
                                                            {
                                                                if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                {
                                                                    $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                    $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if($scope.direction == "Right")
            {
//                console.log("==========RIGHT==========");
//                console.log("Advertiser",$scope.advertiserIdRight);
//                console.log("Network",$scope.networkIdRight);
//                console.log("ParentChild",$scope.selectedParentChildCampaignRight);
//                console.log("==========RIGHT==========");
                if($scope.advertiserIdRight != "" && $scope.advertiserIdRight != undefined)
                {
                    if($scope.networkIdRight != "" && $scope.networkIdRight != undefined)
                    {
                        if($scope.selectedParentChildCampaignRight != "" && $scope.selectedParentChildCampaignRight != undefined)
                        {
                            if($scope.selectedParentChildCampaignRight.type == "parent")
                            {
//                                console.log("right, advertiser, network, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].id == $scope.selectedParentChildCampaignRight.id)
                                                            {
                                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                                {
                                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                    {
                                                                        for(n=0;n<$scope.rightData.length;n++)
                                                                        {
                                                                            if($scope.rightData[n].state == "Impressions")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                    $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Engagements")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                    $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Clicks")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                    $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Actions")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                    $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignRight.type == "child")
                            {
//                                console.log("right, advertiser, network, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                    {
                                                        for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.selectedParentChildCampaignRight.id)
                                                                {
                                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                    {
                                                                        for(n=0;n<$scope.rightData.length;n++)
                                                                        {
                                                                            if($scope.rightData[n].state == "Impressions")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                    $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Engagements")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                    $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Clicks")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                    $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                            else if($scope.rightData[n].state == "Actions")
                                                                            {
                                                                                if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                                {
                                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                    $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("right, advertiser, network");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.rightData.length;n++)
                                                                {
                                                                    if($scope.rightData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Actions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaignRight != "" && $scope.selectedParentChildCampaignRight != undefined)
                        {
                            if($scope.selectedParentChildCampaignRight.type == "parent")
                            {
//                                console.log("right, advertiser, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == $scope.selectedParentChildCampaignRight.id)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.rightData.length;n++)
                                                                    {
                                                                        if($scope.rightData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Actions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignRight.type == "child")
                            {
//                                console.log("right, advertiser, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                    {
                                        if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                        {
                                            for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.selectedParentChildCampaignRight.id)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.rightData.length;n++)
                                                                    {
                                                                        if($scope.rightData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Actions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("right, advertiser");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].advertiserId == $scope.advertiserIdRight)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                        {
                                                            for(n=0;n<$scope.rightData.length;n++)
                                                            {
                                                                if($scope.rightData[n].state == "Impressions")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                        $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Engagements")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                        $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Clicks")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                        $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Actions")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                        $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if($scope.networkIdRight != "" && $scope.networkIdRight != undefined)
                    {
                        if($scope.selectedParentChildCampaignRight != "" && $scope.selectedParentChildCampaignRight != undefined)
                        {
                            if($scope.selectedParentChildCampaignRight.type == "parent")
                            {
//                                console.log("right, network, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].id == $scope.selectedParentChildCampaignRight.id)
                                                        {
                                                            for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.rightData.length;n++)
                                                                    {
                                                                        if($scope.rightData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Actions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignRight.type == "child")
                            {
//                                console.log("right, network, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                            {
                                                if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                                {
                                                    for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.selectedParentChildCampaignRight.id)
                                                            {
                                                                for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                                {
                                                                    for(n=0;n<$scope.rightData.length;n++)
                                                                    {
                                                                        if($scope.rightData[n].state == "Impressions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                                $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Engagements")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                                $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Clicks")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                                $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                        else if($scope.rightData[n].state == "Actions")
                                                                        {
                                                                            if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                            {
                                                                                $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                                $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("right, network");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].networkId == $scope.networkIdRight)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                        {
                                                            for(n=0;n<$scope.rightData.length;n++)
                                                            {
                                                                if($scope.rightData[n].state == "Impressions")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                        $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Engagements")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                        $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Clicks")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                        $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                                else if($scope.rightData[n].state == "Actions")
                                                                {
                                                                    if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                    {
                                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                        $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if($scope.selectedParentChildCampaignRight != "" && $scope.selectedParentChildCampaignRight != undefined)
                        {
                            if($scope.selectedParentChildCampaignRight.type == "parent")
                            {
//                                console.log("right, parent");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    if($scope.networkmaparray[i].networkDetails[j].parent[k].id == $scope.selectedParentChildCampaignRight.id)
                                                    {
                                                        for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.rightData.length;n++)
                                                                {
                                                                    if($scope.rightData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Actions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if($scope.selectedParentChildCampaignRight.type == "child")
                            {
//                                console.log("right, child");
                                for(i=0;i<$scope.networkmaparray.length;i++)
                                {
                                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                    {
                                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                        {
                                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                            {
                                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                                {
                                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                    {
                                                        if($scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].id == $scope.selectedParentChildCampaignRight.id)
                                                        {
                                                            for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                            {
                                                                for(n=0;n<$scope.rightData.length;n++)
                                                                {
                                                                    if($scope.rightData[n].state == "Impressions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                            $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Engagements")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                            $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Clicks")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                            $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                    else if($scope.rightData[n].state == "Actions")
                                                                    {
                                                                        if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                        {
                                                                            $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                            $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
//                            console.log("right, nothing");
                            for(i=0;i<$scope.networkmaparray.length;i++)
                            {
                                if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                                {
                                    for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                                    {
                                        if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                                        {
                                            for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                            {
                                                for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                                {
                                                    for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                                    {
                                                        for(n=0;n<$scope.rightData.length;n++)
                                                        {
                                                            if($scope.rightData[n].state == "Impressions")
                                                            {
                                                                if($scope.rightData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                                {
                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                                    $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                                }
                                                            }
                                                            else if($scope.rightData[n].state == "Engagements")
                                                            {
                                                                if($scope.rightData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                                {
                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                                    $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                                }
                                                            }
                                                            else if($scope.rightData[n].state == "Clicks")
                                                            {
                                                                if($scope.rightData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                                {
                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                                    $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                                }
                                                            }
                                                            else if($scope.rightData[n].state == "Actions")
                                                            {
                                                                if($scope.rightData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                                {
                                                                    $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                                    $scope.allValues.RightActions = $scope.rightData[n].count;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                for(i=0;i<$scope.networkmaparray.length;i++)
                {
                    if($scope.networkmaparray[i].hasOwnProperty("networkDetails"))
                    {
                        for(j=0;j<$scope.networkmaparray[i].networkDetails.length;j++)
                        {
                            if($scope.networkmaparray[i].networkDetails[j].hasOwnProperty("adAccountId"))
                            {
                                for(k=0;k<$scope.networkmaparray[i].networkDetails[j].parent.length;k++)
                                {
                                    for(l=0;l<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns.length;l++)
                                    {
                                        for(m=0;m<$scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights.length;m++)
                                        {
                                            for(n=0;n<$scope.leftData.length;n++)
                                            {
                                                if($scope.leftData[n].state == "Impressions")
                                                {
                                                    if($scope.leftData[n].grade == "Plot_Impressions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions!=undefined)
                                                    {
                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].impressions;
                                                        $scope.allValues.LeftImpressions = $scope.leftData[n].count;
                                                        $scope.allValues.RightImpressions = $scope.rightData[n].count;
                                                    }
                                                }
                                                else if($scope.leftData[n].state == "Engagements")
                                                {
                                                    if($scope.leftData[n].grade == "Plot_Engagements" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements!=undefined)
                                                    {
                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].engagements;
                                                        $scope.allValues.LeftEngagements = $scope.leftData[n].count;
                                                        $scope.allValues.RightEngagements = $scope.rightData[n].count;
                                                    }
                                                }
                                                else if($scope.leftData[n].state == "Clicks")
                                                {
                                                    if($scope.leftData[n].grade == "Plot_Clicks" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks!=undefined)
                                                    {
                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].clicks;
                                                        $scope.allValues.LeftClicks = $scope.leftData[n].count;
                                                        $scope.allValues.RightClicks = $scope.rightData[n].count;
                                                    }
                                                }
                                                else if($scope.leftData[n].state == "Actions")
                                                {
                                                    if($scope.leftData[n].grade == "Plot_Actions" && $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions!=undefined)
                                                    {
                                                        $scope.leftData[n].count = $scope.leftData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                        $scope.rightData[n].count = $scope.rightData[n].count + $scope.networkmaparray[i].networkDetails[j].parent[k].campaigns[l].insights[m].actions;
                                                        $scope.allValues.LeftActions = $scope.leftData[n].count;
                                                        $scope.allValues.RightActions = $scope.rightData[n].count;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for(i=0;i<$scope.leftData.length;i++)
            {
                if($scope.leftData[i].state == "Impressions")
                {
                    if($scope.leftData[i].grade == "Noplot")
                    {
                        $scope.leftData[i].count = 20;
                        $scope.rightData[i].count = 20;
                    }
                }
            }
            for(i=0;i<$scope.leftData.length;i++)
            {
                if($scope.leftData[i].state == "Engagements")
                {
                    if($scope.leftData[i].grade == "Noplot")
                    {
                        $scope.leftData[i].count = ((($scope.retrieveValue($scope.leftData,"Impressions","Plot_Impressions") - $scope.retrieveValue($scope.leftData,"Engagements","Plot_Engagements"))/2) + $scope.retrieveValue($scope.leftData,"Impressions","Noplot"));
                        $scope.rightData[i].count = ((($scope.retrieveValue($scope.rightData,"Impressions","Plot_Impressions") - $scope.retrieveValue($scope.rightData,"Engagements","Plot_Engagements"))/2) + $scope.retrieveValue($scope.rightData,"Impressions","Noplot"));
                    }
                }
            }
            for(i=0;i<$scope.leftData.length;i++)
            {
                if($scope.leftData[i].state == "Clicks")
                {
                    if($scope.leftData[i].grade == "Noplot")
                    {
                        $scope.leftData[i].count = ((($scope.retrieveValue($scope.leftData,"Engagements","Plot_Engagements") - $scope.retrieveValue($scope.leftData,"Clicks","Plot_Clicks"))/2) + $scope.retrieveValue($scope.leftData,"Engagements","Noplot"));
                        $scope.rightData[i].count = ((($scope.retrieveValue($scope.rightData,"Engagements","Plot_Engagements") - $scope.retrieveValue($scope.rightData,"Clicks","Plot_Clicks"))/2) + $scope.retrieveValue($scope.rightData,"Engagements","Noplot"));
                    }
                }
            }
            for(i=0;i<$scope.leftData.length;i++)
            {
                if($scope.leftData[i].state == "Actions")
                {
                    if($scope.leftData[i].grade == "Noplot")
                    {
                        $scope.leftData[i].count = ((($scope.retrieveValue($scope.leftData,"Clicks","Plot_Clicks") - $scope.retrieveValue($scope.leftData,"Actions","Plot_Actions"))/2) + $scope.retrieveValue($scope.leftData,"Clicks","Noplot"));
                        $scope.rightData[i].count = ((($scope.retrieveValue($scope.rightData,"Clicks","Plot_Clicks") - $scope.retrieveValue($scope.rightData,"Actions","Plot_Actions"))/2) + $scope.retrieveValue($scope.rightData,"Clicks","Noplot"));
                    }
                }
            }
//            console.log(JSON.stringify($scope.leftData,null,2));
//            console.log(JSON.stringify($scope.allValues,null,2));
            $rootScope.progressLoader = "none";
            var arrayToFindMax = [0,0,0,0,0,0,0,0];
            for(i=0;i<$scope.leftData.length;i++)
            {
                if($scope.leftData[i].state == "Impressions")
                {
                    arrayToFindMax[0] = arrayToFindMax[0] + $scope.leftData[i].count;
                    arrayToFindMax[4] = arrayToFindMax[4] + $scope.rightData[i].count;
                }
                else if($scope.leftData[i].state == "Engagements")
                {
                    arrayToFindMax[1] = arrayToFindMax[1] + $scope.leftData[i].count;
                    arrayToFindMax[5] = arrayToFindMax[5] + $scope.rightData[i].count;
                }
                else if($scope.leftData[i].state == "Clicks")
                {
                    arrayToFindMax[2] = arrayToFindMax[2] + $scope.leftData[i].count;
                    arrayToFindMax[6] = arrayToFindMax[6] + $scope.rightData[i].count;
                }
                else if($scope.leftData[i].state == "Actions")
                {
                    arrayToFindMax[3] = arrayToFindMax[3] + $scope.leftData[i].count;
                    arrayToFindMax[7] = arrayToFindMax[7] + $scope.rightData[i].count;
                }
            }
            $scope.maxRange = Math.max.apply(null, arrayToFindMax);
            for(i=0;i<leftExcel.length;i++)
            {
                if(leftExcel[i].state == "Impressions")
                {
                    leftExcel[i].count = $scope.retrieveValue($scope.leftData,"Impressions","Plot_Impressions");
                }
                else if(leftExcel[i].state == "Engagements")
                {
                    leftExcel[i].count = $scope.retrieveValue($scope.leftData,"Engagements","Plot_Engagements");
                }
                else if(leftExcel[i].state == "Clicks")
                {
                    leftExcel[i].count = $scope.retrieveValue($scope.leftData,"Clicks","Plot_Clicks");
                }
                else if(leftExcel[i].state == "Actions")
                {
                    leftExcel[i].count = $scope.retrieveValue($scope.leftData,"Actions","Plot_Actions");
                }
            }
            for(i=0;i<rightExcel.length;i++)
            {
                if(rightExcel[i].state == "Impressions")
                {
                    rightExcel[i].count = $scope.retrieveValue($scope.rightData,"Impressions","Plot_Impressions");
                }
                else if(rightExcel[i].state == "Engagements")
                {
                    rightExcel[i].count = $scope.retrieveValue($scope.rightData,"Engagements","Plot_Engagements");
                }
                else if(rightExcel[i].state == "Clicks")
                {
                    rightExcel[i].count = $scope.retrieveValue($scope.rightData,"Clicks","Plot_Clicks");
                }
                else if(rightExcel[i].state == "Actions")
                {
                    rightExcel[i].count = $scope.retrieveValue($scope.rightData,"Actions","Plot_Actions");
                }
            }
//            if($scope.direction == "Left")
//            {
//                if($scope.checkInsightsAvailability($scope.leftData))
//                {
//                    console.log("Left", "making left true");
//                    $scope.leftAvailability = "true";
//                    $scope.plotLeftGraph($scope.leftData);
//                }
//                else
//                {
//                    console.log("Left", "making left false");
//                    $scope.leftAvailability = "false";
//                    $scope.plotLeftGraph($scope.leftData);
//                    $scope.allValues.LeftImpressions = 0;
//                    $scope.allValues.LeftEngagements = 0;
//                    $scope.allValues.LeftClicks = 0;
//                    $scope.allValues.LeftActions = 0;
//                }
//            }
//            else if($scope.direction == "Right")
//            {
//                if($scope.checkInsightsAvailability($scope.rightData))
//                {
//                    console.log("Right", "making right true");
//                    $scope.rightAvailability = "true";
//                    $scope.plotRightGraph($scope.rightData);
//                }
//                else
//                {
//                    console.log("Right", "making right false");
//                    $scope.rightAvailability = "false";
//                    $scope.plotRightGraph($scope.rightData);
//                    $scope.allValues.RightImpressions = 0;
//                    $scope.allValues.RightEngagements = 0;
//                    $scope.allValues.RightClicks = 0;
//                    $scope.allValues.RightActions = 0;
//                }
//            }
//            else
//            {
                if($scope.checkInsightsAvailability($scope.leftData))
                {
//                    console.log("Both", "making left true");
                    $scope.leftAvailability = "true";
                    $scope.plotLeftGraph($scope.leftData);
                }
                else
                {
//                    console.log("Both", "making left false");
                    $scope.leftAvailability = "false";
                    $scope.plotLeftGraph($scope.leftData);
                    $scope.allValues.LeftImpressions = 0;
                    $scope.allValues.LeftEngagements = 0;
                    $scope.allValues.LeftClicks = 0;
                    $scope.allValues.LeftActions = 0;
                }
                if($scope.checkInsightsAvailability($scope.rightData))
                {
//                    console.log("Both", "making right true");
                    $scope.rightAvailability = "true";
                    $scope.plotRightGraph($scope.rightData);
                }
                else
                {
//                    console.log("Both", "making right false");
                    $scope.rightAvailability = "false";
                    $scope.plotRightGraph($scope.rightData);
                    $scope.allValues.RightImpressions = 0;
                    $scope.allValues.RightEngagements = 0;
                    $scope.allValues.RightClicks = 0;
                    $scope.allValues.RightActions = 0;
                }
//            }
        };
        
        $scope.plotLeftGraph = function (data)
        {
//            if(!$scope.leftRendered)
//            {
//                console.log($scope.maxRange);
                angular.element("#leftFunnel").empty();
                angular.element("#dummyLeft").empty();
                angular.element("#dummyLeftExcel").empty();
                leftRunner = cviz.widget.StackedColumn.Runner({
                                id : '1',	
                                container : {
                                    id : '#leftFunnel',
                                    title : '',
                                    titlePos : 5,
                                    width : $scope.funnelWidth,
                                    height : $scope.funnelHeight,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                  },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
            //                    margin : {
            //                        top : 27,
            //                        right : 22,
            //                        bottom : 57,
            //                        left : 90
            //                    },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 0 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
//                                tooltip : {
//                                    bindings: [
//                                         {label: 'Grade', bindWith: 'grade'}, 
//                                         {label: 'State', bindWith: 'state'}, 
//                                         {label: 'Count', bindWith: 'count'}]
//                                }

            //                    utility : {
            //                        download : {
            //                            cssFileUrl : 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
            //                            exportServiceUrl :'https://visualization-coe.cognizant.com/cviz-utilities/export',
            //                            fileName: 'demotest'
            //                            cssFileUrl and exportServerPath needs to be changed based on the environment
            //                        }
            //                    } 
                });
                leftRunner.graph().render($scope.zeroGraph);
                leftRunner.graph().update(data);
//            var x = document.querySelectorAll(".stack-groups");
//            x[0].children[5].children[1].style.fill = "rgb(73,193,247)";
//            x[0].children[4].children[1].style.fill = "rgb(146,215,152)";
//            x[0].children[3].children[1].style.fill = "rgb(255,210,76)";
//            x[0].children[2].children[1].style.fill = "rgb(200,169,255)";
            $scope.leftRendered = true;
            leftRunnerToDownloadPDF = cviz.widget.StackedColumn.Runner({
                                id : '3',	
                                container : {
                                    id : '#dummyLeft',
                                    title : '',
                                    titlePos : 5,
                                    width : 400,
                                    height : 770,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
                                margin : {
                                    top : 27,
                                    right : 22,
                                    bottom : 57,
                                    left : 90
                                },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 315 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
                });
                leftRunnerToDownloadPDF.graph().render(data);
                leftRunnerToDownloadEXCEL = cviz.widget.StackedColumn.Runner({
                                id : '5',	
                                container : {
                                    id : '#dummyLeftExcel',
                                    title : '',
                                    titlePos : 5,
                                    width : 400,
                                    height : 770,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
                                margin : {
                                    top : 27,
                                    right : 22,
                                    bottom : 57,
                                    left : 90
                                },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 315 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
                });
                leftRunnerToDownloadEXCEL.graph().render(leftExcel);
                
        };
        
        $scope.plotRightGraph = function(data)
        {
//            if(!$scope.rightRendered)
//            {
                angular.element("#rightFunnel").empty();
                angular.element("#dummyRight").empty();
                angular.element("#dummyRightExcel").empty();
                rightRunner = cviz.widget.StackedColumn.Runner({
                                id : '2',	
                                container : {
                                    id : '#rightFunnel',
                                    title : '',
                                    titlePos : 5,
                                    width : $scope.funnelWidth,
                                    height : $scope.funnelHeight,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
//                                margin : {
//                                    top : 27,
//                                    right : 22,
//                                    bottom : 57,
//                                    left : 90
//                                },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 0 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
//                                tooltip : {
//                                    bindings: [
//                                         {label: 'Grade', bindWith: 'grade'}, 
//                                         {label: 'State', bindWith: 'state'}, 
//                                         {label: 'Count', bindWith: 'count'}]
//                                }

            //                    utility : {
            //                        download : {
            //                            cssFileUrl : 'https://visualization-coe.cognizant.com/cviz/static/cviz-4.1.1.min.css',
            //                            exportServiceUrl :'https://visualization-coe.cognizant.com/cviz-utilities/export',
            //                            fileName: 'demotest'
            //                            cssFileUrl and exportServerPath needs to be changed based on the environment
            //                        }
            //                    } 
                });
                rightRunner.graph().render($scope.zeroGraph);
                rightRunner.graph().update(data);
//            }
//            else
//            {
                
//            }
//            var x = document.querySelectorAll(".stack-groups");
//            x[1].children[5].children[1].style.fill = "rgb(73,193,247)";
//            x[1].children[4].children[1].style.fill = "rgb(146,215,152)";
//            x[1].children[3].children[1].style.fill = "rgb(255,210,76)";
//            x[1].children[2].children[1].style.fill = "rgb(200,169,255)";
            $scope.graphRendered = true;
            $scope.rightRendered = true;
            rightRunnerToDownloadPDF = cviz.widget.StackedColumn.Runner({
                                id : '4',	
                                container : {
                                    id : '#dummyRight',
                                    title : '',
                                    titlePos : 5,
                                    width : 400,
                                    height : 770,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
                                margin : {
                                    top : 27,
                                    right : 22,
                                    bottom : 57,
                                    left : 90
                                },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 315 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
                });
                rightRunnerToDownloadPDF.graph().render(data);
                rightRunnerToDownloadEXCEL = cviz.widget.StackedColumn.Runner({
                                id : '6',	
                                container : {
                                    id : '#dummyRightExcel',
                                    title : '',
                                    titlePos : 5,
                                    width : 400,
                                    height : 770,
                                    showGrid : 'no',
                                    contextBrush: 'no'
                                },
                                bindings : {
                                    x : 'count',
                                    y : 'state',	
                                    item : 'grade'
                                  //color:'clr'
                                },	
                                colors: {
                                    "Noplot":"rgb(255, 255, 255)",
                                    "Plot_Actions":"rgb(200,169,255)",
                                    "Plot_Clicks":"rgb(255,210,76)",
                                    "Plot_Engagements":"rgb(146,215,152)",
                                    "Plot_Impressions":"rgb(73,193,247)"
                                },
                                axisRange : {
                                    x : {
                                        min: 0,
                                        max: $scope.maxRange
                                    }
                                },
                                base : 'y',
                                columnGloss : 'no',
                                margin : {
                                    top : 27,
                                    right : 22,
                                    bottom : 57,
                                    left : 90
                                },
                                scaling : {
                                    x : 1,
                                    y : 4 
                                },
                                padding : 0.1,	
                                tickerAngle : {
                                    x : 315 
                                },
                                labels : {
                                    x : '',
                                    y : ''
                                }
                });
                rightRunnerToDownloadEXCEL.graph().render(rightExcel);
        };
        
        $scope.retrieveValue = function(obj,insight,grade)
        {
            var valueToReturn = 0;
            angular.forEach(obj,function(value,key)
            {
                if(value.state == insight)
                {
                    if(value.grade == grade)
                    {
                        valueToReturn = value.count;
                    }
                }
            });
            return valueToReturn;
        };
        
        $scope.checkInsightsAvailability = function(obj)
        {
            var insightsAvailability = false;
            for(i=0;i<obj.length;i++)
            {
                if(obj[i].grade == "Plot_Impressions" || obj[i].grade == "Plot_Engagements" || obj[i].grade == "Plot_Clicks" || obj[i].grade == "Plot_Actions")
                {
                    if(obj[i].count != 0)
                    {
                        insightsAvailability = true;
                    }
                }
            }
            if(insightsAvailability)
            {
                return true;
            }
            else
            {
                return false;
            }
        };
        
//        PubSub.subscribe('1-stacked-column-render-complete', function(event, eventObject)
//        {
//            var x = document.querySelectorAll(".stack-groups");
//            x[0].children[5].children[1].style.fill = "rgb(73,193,247)";
//            x[0].children[4].children[1].style.fill = "rgb(146,215,152)";
//            x[0].children[3].children[1].style.fill = "rgb(255,210,76)";
//            x[0].children[2].children[1].style.fill = "rgb(200,169,255)";
//            x[1].children[5].children[1].style.fill = "rgb(73,193,247)";
//            x[1].children[4].children[1].style.fill = "rgb(146,215,152)";
//            x[1].children[3].children[1].style.fill = "rgb(255,210,76)";
//            x[1].children[2].children[1].style.fill = "rgb(200,169,255)";
//        });
        //$scope.getAdvertiserDetails();  
        $scope.setUserIdAndAccessToken = function() {
            performanceServices.getUserIdAndAccessToken($window.localStorage.getItem("userId"),$window.localStorage.getItem("accessToken"));
            $scope.getAdvertiserDetails();
        };
        $scope.setUserIdAndAccessToken();
    }]);

dashboard.directive('funnelHeight', function () 
{
    return {
        restrict: 'AE',
        link: function (scope, element, attrs) {
            scope.funnelHeight = element.height();
        }
    };
});

dashboard.directive('funnelWidth', function () 
{
    return {
        restrict: 'AE',
        link: function (scope, element, attrs) {
            scope.funnelWidth = element.width();
        }
    };
});