dashboard.controller("awarenessCampaigncreativeController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$window', 'appSettings', '$sce', '$timeout', 'twitterGetPost', '$q', 'globalData',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $window, appSettings, $sce, $timeout, twitterGetPost, $q, globalData) {
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        var apiTPBase = appSettings.apiTPBase;
        $scope.networkAdAccountId = appSettings.networkAdAccountId;
        $scope.isDisabled=true;
        $scope.fourthActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.browseImgSuccessMsg = "none";
        $scope.browselibrary = "none";
        $scope.mainLoader = "none";
        $scope.errTextMsg = "none";
        $scope.uniqueArray = [];
        $scope.hashVal = "";
        $scope.imagesSource = "";
        $scope.mediabutton=true;
        $scope.values=[];
        $scope.mediaUpdate = false;
        $scope.cardUpdate = false;
        $scope.isHeadline = true;
        $scope.rightNavCtrlbtn = 0;
        $scope.ctrlLimt = 0;
        $scope.isLeftBtnEnable = false;
        $scope.isrightBtnEnable = true;
        $scope.createCard = true;
        $scope.selectCard = false;
        $scope.uploading = true;
        $scope.previewing = false;
        $scope.uploadingcard = true;
        $scope.previewingcard = false;
        $scope.mediaandcard = false;
        $scope.mediaonly = true;
        $scope.carouselFlow = 1;
		$scope.checkVal=[];		
		$scope.mediaarrow=true;
        $scope.iosexpand = false;
        $scope.androidexpand = false;
        $scope.desktopexpand = false;
        $scope.mediapresent = true;
        $scope.lengthmultipleTweetId = 1;
        $scope.chkImage = 1;
        $scope.card = {};
        $scope.tweetedArray1 = [];
		$scope.tweeterIDArray=[];
		$scope.tweetsArray=[];
		$scope.tweetsArray1=[];
		$scope.statsData = [];
		$scope.deleteTweetId = [];
                
                
                $scope.combinedStatsimp = [];
		$scope.combinedStatseng = [];
		$scope.combinedStatsengrate = [];
        var tweetObj={};
		var lengthkey = 0;
		$scope.carouselincr = 0;
		$scope.multipleTweetIdedit = [];
		angular.element('.creativePreviewBlock').css('pointer-events', ' none');
		 //$scope.tweetObj = {};
            $scope.tweetsChecked = [];
            $scope.tweetsUnChecked = [];
		var apiTwitterBase = appSettings.apiTwitterBase;
         $scope.closePopupDetails = function () {
            $scope.editAdsetErrorMsg = "none";
        }
        
        $scope.previewTweet=function(val) {
            //alert('hi');
            window.open(val, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
        }
		
		$scope.fetchMediaforEdit = function () {
		$scope.mainLoader = "block";
            var promises = [];            
            $scope.promotedtweetID = [];
            
            $scope.deleteTweetIdLength = 0;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");

            promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                // console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.promotedArray = [];
                    $scope.promoteFetch = response.data.promotedTweets;

                    angular.forEach($scope.promoteFetch, function (value, key) {
                        var JsonObj = $scope.promoteFetch[key]                      
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweetsFetch = array[+i];								
                                angular.forEach($scope.iteratedtweetsFetch, function (value, key) {

                                    $scope.promotedTweetStatus = value.promotedTweetStatus;
                                    if ($scope.promotedTweetStatus != "DELETED" && $scope.promotedtweetID.includes(value.promotedTweetDetails.tweet_id) == false) {                                       
                                        $scope.promotedtweetID.push(value.promotedTweetDetails.tweet_id);
										
                                    }
                                })
								
                            }                          
                            
                        }                                             
                    });					
                  
                }
				else{
					$scope.mainLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none"; 
						$scope.editAdsetErrorMsg = 'block';						
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.data.networkError.message;
                            } else {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
               
            }));
			
			//$scope.readPromotedTweetsEdit();
			   $q.all(promises).finally(
                    function(){
						console.log('read promoted tweets for account done');
						console.log($scope.promotedtweetID);
						//$scope.readtweetbyID();
						$scope.getCombinedStatsvalue();
						
                    });
			
        }
		
				
		$scope.getCombinedStatsvalue = function(){
			
			var promises = [];
				var data = {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			};
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.promotedtweetID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
								
								 promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								//$scope.mainLoader = "block";
								if (response.data.appStatus == '0') {								
									$scope.statsData = response.data.stats;
									var JsonObj1 = $scope.statsData;
									angular.forEach(JsonObj1,function(value,key){
									var array1 = [];
									
									var impValue = globalData.getKeyValues(JsonObj1[key], 'impressions');
									
									if(typeof(impValue) == 'number'){
										$scope.combinedStatsimp[key] = impValue;
									} else {
										$scope.combinedStatsimp[key] = impValue[0];
									}
									
									var impValue1 = globalData.getKeyValues(JsonObj1[key], 'engagements');
									//tweetObj.engagements = impValue1;	
									if(typeof(impValue1) == 'number'){
										$scope.combinedStatseng[key] = impValue1;
									} else {
										$scope.combinedStatseng[key] = impValue1[0];
									}

									if($scope.combinedStatsimp[key] == 0 && $scope.combinedStatseng[key] == 0){
									$scope.combinedStatsengrate[key] = "0.0%";
									}
									else if($scope.combinedStatsimp[key] > 0 && $scope.combinedStatseng[key] == 0){
									$scope.combinedStatsengrate[key] = "0.0%";
									}
									else if($scope.combinedStatsimp[key] == $scope.combinedStatseng[key]){
										$scope.engratecheck = $scope.combinedStatseng[key] / $scope.combinedStatsimp[key];
										$scope.combinedStatsengrate[key] = $scope.engratecheck + '%';
									}
									else if($scope.combinedStatsimp[key] > 0 && $scope.combinedStatseng[key] > 0){
										$scope.engratecheck = $scope.combinedStatseng[key] / $scope.combinedStatsimp[key];
										
										if($scope.engratecheck < 1){
										$scope.combinedStatsengrate[key] = "0.0%";
										}
										else {
										
											$scope.combinedStatsengrate[key] = $scope.engratecheck + '%';
											
										}
									}
									   
										});
									}
									
									 else {										
										$scope.combinedStatsimp = 0;
                                        $scope.combinedStatseng = 0;
                                        $scope.combinedStatsengrate = 0;
										$scope.setLine();
										if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
											$window.localStorage.setItem("TokenExpired", true);
											$state.go('login');
										} else {
											$rootScope.progressLoader = "none"; 
											$scope.mainLoader="none";
											//$scope.editAdsetErrorMsg = 'block';						
											if (response.data.networkError != '' && response.data.networkError != undefined) {
												if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
														$scope.errorpopupHeading = 'Error';
														$scope.errorMsg = response.data.networkError.message;
												} else {
														$scope.errorpopupHeading = response.data.networkError.error_user_title;
														$scope.errorMsg = response.data.networkError.error_user_msg;
												}
											} else {
													$scope.errorpopupHeading = 'Error';
													$scope.errorMsg = response.data.errorMessage;
											}
										}
                                    }
									
                                }));
								
								
								$q.all(promises).finally(
                    function(){						
						console.log($scope.promotedtweetID);
						console.log($scope.combinedStatseng);
						console.log($scope.combinedStatsimp);
						console.log($scope.combinedStatsengrate);
						$scope.readtweetbyID();
						//$scope.getCombinedStatsvalue();
						
                    });
		}
		
		
		
		$scope.readtweetbyID = function(){				
			tweetObj = {};
				$scope.mainLoader = "block";
			if(lengthkey < $scope.promotedtweetID.length){
			
			//if(lengthkey < 5){
				 $scope.deleteTweetIdLength = $scope.deleteTweetId.length;
                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")

                    }; 
                        var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "id=" + $scope.promotedtweetID[lengthkey];
                        twitterGetPost.gettweetbyid(queryStr, data).then(function (response) {
                            if (response.data.appStatus == '0') {
							//console.log(k+" value after response");
						$scope.mediaResponse = response.data.tweetDetails;
                      
                        angular.forEach($scope.mediaResponse, function (value, key) {
                            var JsonObj = $scope.mediaResponse[key];
                             $scope.created_at = JsonObj.user.created_at.split(' ')[1] + ' ' + JsonObj.user.created_at.split(' ')[2];
                            //console.log(JSON.stringify($scope.extended_entities,null,2));
                            var array = [];
                                $scope.extended_entities = JsonObj.extended_entities;
                                if($scope.extended_entities!=undefined){
                            for (var i in $scope.extended_entities) {
                                if ($scope.extended_entities.hasOwnProperty(i)) {
                                    array[+i] = $scope.extended_entities;
                                    //console.log(array[+i]);
                                    $scope.iteratedtweets = array[+i];
                                     //console.log(JSON.stringify($scope.iteratedtweets,null,2));
                                  tweetObj= {
                                    "profile_image" : JsonObj.user.profile_image_url,
                                    "name" :JsonObj.user.name,
                                    "screenName" : JsonObj.user.screen_name,
                                    "created_at" : $scope.created_at,
                                    "text" : JsonObj.text,
                                    "tweeterID": JsonObj.id_str,
                                    "media_url" :   $scope.iteratedtweets.media[0].media_url,
                                    "impressions" : $scope.combinedStatsimp[lengthkey],
                                    "engagements": $scope.combinedStatseng[lengthkey],
                                    "engrate": $scope.combinedStatsengrate[lengthkey]
                                  }
                                }

                            }
							$scope.readstatsandpromoted();
                        }else{
                            tweetObj= {
                                    "profile_image" : JsonObj.user.profile_image_url,
                                    "name" :JsonObj.user.name,
                                    "screenName" : JsonObj.user.screen_name,
                                    "created_at" : $scope.created_at,
                                    "tweeterID": JsonObj.id_str,
                                    "text" : JsonObj.text,
                                    "impressions" : $scope.combinedStatsimp[lengthkey],
                                    "engagements": $scope.combinedStatseng[lengthkey],
                                    "engrate": $scope.combinedStatsengrate[lengthkey]
                                      
                                  }
								  
								  $scope.readstatsandpromoted();
                        }
						
						});
		
		}

			else{
					//$scope.mainLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
						$scope.mainLoader = "none";
                        $rootScope.progressLoader = "none"; 
						//$scope.editAdsetErrorMsg = 'block';		
						if(response.data.networkError.code == '144'){
							console.log('Error tweeet ID');
							lengthkey++;									
							$scope.readtweetbyID();
						}
                       else if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {

                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.data.networkError.message;
                                } else {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        } 
						else {

                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }

		
		});
		}
		else{
			$scope.mainLoader = "none";
			$scope.tweetsArray = $scope.tweetsArray1;
			$scope.setLine();
			var a=0;
			$timeout(function () {
						angular.forEach($scope.tweetsArray,function(value,index){
						
						var h2 = $("#parenttd"+a).height();      
							var tableHeight = $("#tablever").height(); 
						angular.element('.childtd'+a).css('height', h2);
						a=a+1;  
						angular.element('.vrtable1').css('height', tableHeight);
						angular.element('.vrtable2').css('height', tableHeight);
						angular.element('.vrtable3').css('height', tableHeight);
						});  
			 }, 2000);
			 $scope.setLine();
		
		}
		}
		
		
		$scope.readstatsandpromoted = function(){
			$scope.mainLoader = "block";
			var data = {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			};
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" +$scope.promotedtweetID[lengthkey];
                                //$scope.mainLoader = "block";
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {  
                                         /**since we are not getting stat id in read promoted tweet while using sandbox we are using below code lines**/   
                                     tweetObj.impressionspromoted = 0;
                                    tweetObj.engagementspromoted = 0;
                                    tweetObj.engratepromoted = "0.0%";
                                        
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        tweetObj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign"; 
                                        //$scope.getStats();                                   
                                    if($scope.campaignState == "edit"){
                                    if($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true){   
										$scope.checkVal[lengthkey] = true;
										$scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
										$scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
										$scope.checkTweet = $scope.promotedtweetID1.length; 
										
                                    }
                                    else{
                                    $scope.checkVal[lengthkey]=false;                                        
                                    }
                                    }
									
									   $scope.tweetsArray1.push(tweetObj);
										$scope.setTweetCheck($scope.promotedtweetID);                   
										lengthkey++;									
										$scope.readtweetbyID();
										console.log($scope.tweetsArray1);
										
                                  
                                    
                                    
                                    }else{										
                                        tweetObj.promotedCount = "Promoted-only - " + "Currently Unpromoted";
                                        tweetObj.impressionspromoted = 0;
                                        tweetObj.engagementspromoted = 0;
                                        tweetObj.engratepromoted = "0.0%";
                                       // $scope.getStats();
                                        	if($scope.campaignState == "edit"){
                                    if($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true){   
										$scope.checkVal[lengthkey] = true;
										$scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
										$scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
										$scope.checkTweet = $scope.promotedtweetID1.length; 
										
                                    }
                                    else{
                                    $scope.checkVal[lengthkey]=false;                                        
                                    }
                                    }
									
                                    $scope.tweetsArray1.push(tweetObj);
                                         $scope.setTweetCheck($scope.promotedtweetID);                   
                                         lengthkey++;									
                                         $scope.readtweetbyID();
                                         console.log($scope.tweetsArray1);
                                    }
                                    
                                })
								
		}
		
		$scope.getStats = function(){
			
			var promises = [];
				var data = {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			};
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.promotedtweetID[lengthkey] + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
								
								 promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								//$scope.mainLoader = "block";
								if (response.data.appStatus == '0') {								
									$scope.statsData = response.data.stats;
									var JsonObj1 = $scope.statsData;
									
									var array1 = [];
									
									var impValue = globalData.getKeyValues(JsonObj1, 'impressions');
									
									if(typeof(impValue) == 'number'){
										tweetObj.impressions = impValue;
									} else {
										tweetObj.impressions = impValue[0];
									}
									
									var impValue1 = globalData.getKeyValues(JsonObj1, 'engagements');
									//tweetObj.engagements = impValue1;	
									if(typeof(impValue1) == 'number'){
										tweetObj.engagements = impValue1;
									} else {
										tweetObj.engagements = impValue1[0];
									}

									if(tweetObj.impressions == 0 && tweetObj.engagements == 0){
									tweetObj.engrate = "0.0%";
									}
									else if(tweetObj.impressions > 0 && tweetObj.engagements == 0){
									tweetObj.engrate = "0.0%";
									}
									else if(tweetObj.impressions == tweetObj.engagements){
										$scope.engratecheck = tweetObj.engagements / tweetObj.impressions;
										tweetObj.engrate = $scope.engratecheck + '%';
									}
									else if(tweetObj.impressions > 0 && tweetObj.engagements > 0){
										$scope.engratecheck = tweetObj.engagements / tweetObj.impressions;
										
										if($scope.engratecheck < 1){
										tweetObj.engrate = "0.0%";
										}
										else {
										
											tweetObj.engrate = $scope.engratecheck + '%';
											
										}
									}
									
									if($scope.campaignState == "edit"){
                                                            if($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true){   
										$scope.checkVal[lengthkey] = true;$scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
										$scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
										$scope.checkTweet = $scope.promotedtweetID1.length; 

                                                                                }
                                                                                else{
                                                                                $scope.checkVal[lengthkey]=false;                                        
                                                                                }
                                                                                }
									
									   $scope.tweetsArray1.push(tweetObj);
										$scope.setTweetCheck($scope.promotedtweetID);                   
										lengthkey++;									
										$scope.readtweetbyID();
										
									}
									
									 else {										
										tweetObj.impressions = 0;
                                                                                tweetObj.engagements = 0;
                                                                                tweetObj.engrate = 0;
										$scope.setLine();
										if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
											$window.localStorage.setItem("TokenExpired", true);
											$state.go('login');
										} else {
                                                                                    $scope.mainLoader = "none";
											$rootScope.progressLoader = "none"; 
											//$scope.editAdsetErrorMsg = 'block';						
											if (response.data.networkError != '' && response.data.networkError != undefined) {
												if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
														$scope.errorpopupHeading = 'Error';
														$scope.errorMsg = response.data.networkError.message;
												} else {
														$scope.errorpopupHeading = response.data.networkError.error_user_title;
														$scope.errorMsg = response.data.networkError.error_user_msg;
												}
											} else {
													$scope.errorpopupHeading = 'Error';
													$scope.errorMsg = response.data.errorMessage;
											}
										}
                                    }
									
                                }));
		}
		
        $scope.init = function () {
		
		//$scope.mainLoader = "block";
			$rootScope.twitterFormData = vm.getData;
            // angular.element('#step1').css('background-color', '#95D2B1');
            // $scope.getPromotedOnlyTweets();
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            // angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
              $scope.d = new Date();
           // $scope.currentdate = $scope.d.getFullYear() + "-" + ('0' + ($scope.d.getMonth() + 1)).slice(-2) + "-" + $scope.d.getDate();
		    $scope.currentdate = $scope.d.getFullYear() + "-" + ('0' + ($scope.d.getMonth() + 1)).slice(-2) + "-" + ('0' + ($scope.d.getDate())).slice(-2);
            console.log($scope.currentdate);
            $scope.d.setDate($scope.d.getDate() - 7);
            $scope.curr_date = $scope.d.getDate();
            $scope.curr_month = $scope.d.getMonth() + 1;
            $scope.curr_year = $scope.d.getFullYear();           
            //$scope.weekdate = $scope.curr_year + "-" + ('0' + ($scope.curr_month)).slice(-2) + "-" + $scope.curr_date;
			$scope.weekdate = $scope.curr_year + "-" + ('0' + ($scope.curr_month)).slice(-2) + "-" + ('0' + ($scope.curr_date)).slice(-2);
            console.log($scope.weekdate);
            
            $scope.campaignState = $window.localStorage.getItem("campaignState");
			$scope.fetchMediaforEdit();
            if($scope.campaignState == "edit"){
                angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element($('#step1').css('background-color', 'rgb(149, 210, 177)'));
			    angular.element($('#step2').css('background-color', 'rgb(149, 210, 177)')); 
                //$window.localStorage.setItem("multipleTweetId", $scope.deleteTweetId);
				 $scope.mainLoader = "block";				
                 $scope.readPromotedTweetsEdit();
				 angular.element('.naviButtons #right').css('pointer-events' , 'auto');
				angular.element('.naviButtons #left').css('pointer-events' , 'auto');
				angular.element('.creativePreviewBlock').css('pointer-events', ' auto');
				//$scope.fetchMediaforEdit();
            }
			else{
				$window.localStorage.setItem("multipleTweetId", "");
				 
			}
        }

        //Get Promoted only Tweets
        $scope.getPromotedOnlyTweets = function () {
            var promises = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=none";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.tweetedArray = [];
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                       // console.log(JsonObj);
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                //console.log($scope.iteratedtweets);
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
								$scope.tweeterIDArray.push($scope.iteratedtweets.id_str);
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                if($scope.mediaurlcheck.hasOwnProperty('urls')){
                                    if($scope.mediaurlcheck.urls.length>0){
                                        $scope.expanded_url_length=$scope.mediaurlcheck.urls.length;
                                        $scope.expanded_url=$scope.mediaurlcheck.urls[0].expanded_url;
                                    }
                                }
                                else {
                                    $scope.expanded_url = "";
                                }
                                //console.log($scope.expanded_url);
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                $scope.values = $scope.iteratedtweets.text.split(" ");
                                $scope.link=$scope.values[$scope.values.length-1];
                                //console.log($scope.link);
								$scope.impressions =0;
                                $scope.engagements =0;
                                $scope.engrate =0;
								$scope.impressionspromoted =0;
                                $scope.engagementspromoted =0;
                                $scope.engratepromoted =0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                }
                                else {
                                    $scope.media_url = "";
                                }
                                
								if($scope.campaignState == "edit"){
                                    if($scope.promotedtweetID.includes($scope.tweeterID) == true){                                    
                                    $scope.checkVal[key] = true;                                    
                                    $scope.checkTweet = $scope.promotedtweetID.length;                                  
                                    }
                                    }
								
								var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
                                    "expanded_url":$scope.expanded_url,
                                    "IFrameURL": $scope.link,
									"impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
									"impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
								$scope.impressionsSum = [];
								$scope.engagementsSum = [];
								$scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
										
										//Stats service for promoted campaign
										$scope.promotedCampaign = response.data.promotedTweets;
										$scope.statID = [];
										angular.forEach($scope.promotedCampaign, function (value, key) {
											var JsonObj2 = $scope.promotedCampaign[key]
											var array2 = [];
											//$scope.statID = [];
											for (var i in JsonObj2) {
											if (JsonObj2.hasOwnProperty(i)) {
												array2[+i] = JsonObj2[i];
												$scope.statdata1 = array2[+i];
												//console.log($scope.statdata1.promotedTweetId);
												$scope.statID.push($scope.statdata1.promotedTweetId);												
												}												
												}
										})
										$scope.statIDsum = [];
										angular.forEach($scope.statID, function (value, key) {
											
											//Stats service
								var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {								
								if (response.data.appStatus == '0') {								
								$scope.statsDatapromote = response.data.stats;								
								 var JsonObj3 = $scope.statsDatapromote;
								//console.log(JsonObj1);
								var array3 = [];
								for (var j in JsonObj3) {
								if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                array3[+j] = JsonObj3[j];
								$scope.statdata3 = array3[+j];

								angular.forEach($scope.statdata3, function (value, key) {								
									
									$scope.impressionsSum1 = value.id_data[0].metrics.engagements;
									//console.log($scope.impressionsSum1);
									$scope.impressionsSum.push($scope.impressionsSum1);
									
									if($scope.impressionsSum1 !=0){
										//obj.impressions = value.id_data[0].metrics.impressions[0];
										$scope.impressionsSum.push($scope.impressionsSum1[0]);
										
									}
									$scope.engagementsSum1 = value.id_data[0].metrics.engagements;
									$scope.engagementsSum.push($scope.engagementsSum1);
									//console.log($scope.engagementsSum1);
									if($scope.engagementsSum1 !=0){										
										$scope.engagementsSum.push($scope.engagementsSum1[0]);										
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0){
									//console.log(obj.engrate);
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0){
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0){
									//obj.engrate = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
								});
								
								
									}
									}
									}
									
									 else {
										$scope.engagementsSum = 0;
                                        $scope.impressionsSum = 0;
                                        $scope.engrateSum = 0;
                                    }
									
                                }));
										
										})
										//console.log($scope.impressionsSum);
										$scope.statIDsum1 = 0;
										angular.forEach($scope.impressionsSum, function (value, key) {
											//$scope.statIDsum1 =[];
											$scope.statIDsum1 += $scope.impressionsSum[key];
											//nsole.log($scope.statIDsum1);
											})
											
											//console.log($scope.statIDsum1);
											
											obj.impressionspromoted = $scope.statIDsum1;
											//console.log(obj.impressionspromoted);
											
											$scope.statIDsum2 = 0;
											angular.forEach($scope.engagementsSum, function (value, key) {
											//$scope.statIDsum12 =[];
											$scope.statIDsum2 += $scope.engagementsSum[key];
											})
											obj.engagementspromoted = $scope.statIDsum2;
											//console.log(obj.engagementspromoted);
											
											$scope.statIDsum3 = 0;
											angular.forEach($scope.engrateSum, function (value, key) {
											//$scope.statIDsum3 =[];
											$scope.statIDsum3 += $scope.engrateSum[key];
											})
											obj.engratepromoted = $scope.statIDsum3;
											//console.log(obj.engratepromoted);
										
										//console.log($scope.statIDsum);
                                    }
                                    else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
										obj.impressionspromoted = 0;
										obj.engagementspromoted = 0;
										obj.engratepromoted = 0;
                                    }

                                }));
								
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								if (response.data.appStatus == '0') {
								$scope.statsData = response.data.stats;
								
								 var JsonObj1 = $scope.statsData;
								//console.log(JsonObj1);
								var array1 = [];
								for (var j in JsonObj1) {
                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                array1[+j] = JsonObj1[j];
								$scope.statdata = array1[+j];
								//console.log($scope.statdata);
								
								angular.forEach($scope.statdata, function (value, key) {
									obj.impressions = value.id_data[0].metrics.impressions;
									if(obj.impressions !=0){
										obj.impressions = value.id_data[0].metrics.impressions[0];
									}
									obj.engagements = value.id_data[0].metrics.engagements;
									if(obj.engagements !=0){
										obj.engagements = value.id_data[0].metrics.engagements[0];
									}
									if(obj.impressions == 0 && obj.engagements == 0){									
									obj.engrate = 0;
									}
									else if(obj.impressions > 0 && obj.engagements > 0){									
									$scope.engratecheck = obj.engagements / obj.impressions;
									console.log($scope.engratecheck);
										if(obj.engrate < 1){
									obj.engrate = 0;
									}
									}
								});
								
									}
									}
									}
									
									 else {
										obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }
									
                                }));
								
                                $scope.tweetedArray.push(obj);

                            }
                        }

                    });


                }
                else {
                    $scope.mainLoader = "none";
                    console.log(response.data.errorMessage);
					$scope.showErrorPopup(response);
                }
				
				$q.all(promises).finally(
                    function(){
                        $scope.mainLoader = "none";
                                var a=0;
                                angular.forEach($scope.tweetedArraySample,function(value,index){
                    var h2 = $("#parenttd"+a).height();
                    angular.element('#childtd'+a).css('height', h2);
                   angular.element('#childtd1'+a).css('height', h2);
                  angular.element('#childtd2'+a).css('height', h2);
                    a=a+1;  })
					    
                    });
				
            }));




        }

        //Get Organic Tweets
		 $scope.getOrganicTweets = function () {
            var promises = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=followers";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.tweetedArray = [];
                    //$scope.mainLoader = "none";
                    //console.log(response.data.successMessage);
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                       // console.log(JsonObj);
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                //console.log($scope.iteratedtweets);
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
								$scope.tweeterIDArray.push($scope.iteratedtweets.id_str);
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;							
								
                                //console.log($scope.mediaurlcheck);
                                if($scope.mediaurlcheck.hasOwnProperty('urls')){
                                    if($scope.mediaurlcheck.urls.length>0){
                                        $scope.expanded_url_length=$scope.mediaurlcheck.urls.length;
                                        $scope.expanded_url=$scope.mediaurlcheck.urls[0].expanded_url;
                                    }
                                }
                                else {
                                    $scope.expanded_url = "";
                                    //$(".tableCell .setcolumnheight").css("height", "75px");
                                }
                                //console.log($scope.expanded_url);
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                $scope.values = $scope.iteratedtweets.text.split(" ");
                                $scope.link=$scope.values[$scope.values.length-1];
                                //console.log($scope.link);
								$scope.impressions =0;
                                $scope.engagements =0;
                                $scope.engrate =0;
								$scope.impressionspromoted =0;
                                $scope.engagementspromoted =0;
                                $scope.engratepromoted =0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                   // $(".tableCell .setcolumnheight").css("height", "175px");
                                }
                                else {
                                    $scope.media_url = "";
                                    //$(".tableCell .setcolumnheight").css("height", "75px");
                                }
                                
								if($scope.campaignState == "edit"){
                                    //$scope.checkVal=true;
                                    if($scope.promotedtweetID.includes($scope.tweeterID) == true){                                    
                                    $scope.checkVal[key] = true;
                                    //console.log($scope.tweetObj.tweetsChecked);
                                    $scope.checkTweet = $scope.promotedtweetID.length;                                  
                                    
                                    }
                                    else{
                                    //$scope.checkVal=false;                                        
                                    }
                                    }
								
								var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
                                    "expanded_url":$scope.expanded_url,
                                    "IFrameURL": $scope.link,
									"impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
									"impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
								$scope.impressionsSum = [];
								$scope.engagementsSum = [];
								$scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
										//$scope.mainLoader = "none";
                                        //console.log(response.data.promotedTweets.length);
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
										
										
										//Stats service for promoted campaign
										$scope.promotedCampaign = response.data.promotedTweets;
										$scope.statID = [];
										angular.forEach($scope.promotedCampaign, function (value, key) {
											var JsonObj2 = $scope.promotedCampaign[key]
											var array2 = [];
											//$scope.statID = [];
											for (var i in JsonObj2) {
											if (JsonObj2.hasOwnProperty(i)) {
												array2[+i] = JsonObj2[i];
												$scope.statdata1 = array2[+i];
												//console.log($scope.statdata1.promotedTweetId);
												$scope.statID.push($scope.statdata1.promotedTweetId);												
												}												
												}
										})
										//$scope.statID.push($scope.statdata1.promotedTweetId);
										//console.log($scope.statID);
										$scope.statIDsum = [];
										
										angular.forEach($scope.statID, function (value, key) {
											//$scope.statIDsum[0] += $scope.statID[key];
											//console.log($scope.statIDsum);
											
											//Stats service
								var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {								
								if (response.data.appStatus == '0') {								
								$scope.statsDatapromote = response.data.stats;								
								 var JsonObj3 = $scope.statsDatapromote;
								//console.log(JsonObj1);
								var array3 = [];
								for (var j in JsonObj3) {
								if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                array3[+j] = JsonObj3[j];
								$scope.statdata3 = array3[+j];

								angular.forEach($scope.statdata3, function (value, key) {								
									
									$scope.impressionsSum1 = value.id_data[0].metrics.engagements;
									//console.log($scope.impressionsSum1);
									$scope.impressionsSum.push($scope.impressionsSum1);
									
									if($scope.impressionsSum1 !=0){
										//obj.impressions = value.id_data[0].metrics.impressions[0];
										$scope.impressionsSum.push($scope.impressionsSum1[0]);
										
									}
									$scope.engagementsSum1 = value.id_data[0].metrics.engagements;
									$scope.engagementsSum.push($scope.engagementsSum1);
									//console.log($scope.engagementsSum1);
									if($scope.engagementsSum1 !=0){										
										$scope.engagementsSum.push($scope.engagementsSum1[0]);										
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0){
									//console.log(obj.engrate);
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0){
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0){
									//obj.engrate = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
								});
								
								
									}
									}
									}
									
									 else {
										$scope.engagementsSum = 0;
                                        $scope.impressionsSum = 0;
                                        $scope.engrateSum = 0;
                                    }
									
                                }));
										
										})
										//console.log($scope.impressionsSum);
										$scope.statIDsum1 = 0;
										angular.forEach($scope.impressionsSum, function (value, key) {
											//$scope.statIDsum1 =[];
											$scope.statIDsum1 += $scope.impressionsSum[key];
											//nsole.log($scope.statIDsum1);
											})
											
											//console.log($scope.statIDsum1);
											
											obj.impressionspromoted = $scope.statIDsum1;
											//console.log(obj.impressionspromoted);
											
											$scope.statIDsum2 = 0;
											angular.forEach($scope.engagementsSum, function (value, key) {
											//$scope.statIDsum12 =[];
											$scope.statIDsum2 += $scope.engagementsSum[key];
											})
											obj.engagementspromoted = $scope.statIDsum2;
											//console.log(obj.engagementspromoted);
											
											$scope.statIDsum3 = 0;
											angular.forEach($scope.engrateSum, function (value, key) {
											//$scope.statIDsum3 =[];
											$scope.statIDsum3 += $scope.engrateSum[key];
											})
											obj.engratepromoted = $scope.statIDsum3;
											//console.log(obj.engratepromoted);
										
										//console.log($scope.statIDsum);
                                    }
                                    else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
										obj.impressionspromoted = 0;
										obj.engagementspromoted = 0;
										obj.engratepromoted = 0;
                                    }

                                }));
								
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								if (response.data.appStatus == '0') {
								$scope.statsData = response.data.stats;
								
								 var JsonObj1 = $scope.statsData;
								//console.log(JsonObj1);
								var array1 = [];
								for (var j in JsonObj1) {
                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                array1[+j] = JsonObj1[j];
								$scope.statdata = array1[+j];
								//console.log($scope.statdata);
								
								angular.forEach($scope.statdata, function (value, key) {
									//console.log(key);
									//console.log(value.id);
									//console.log(value.id_data[0].metrics.impressions);
									//console.log(value.id_data[0].metrics.engagements);
									obj.impressions = value.id_data[0].metrics.impressions;
									//console.log(obj.impressions);
									if(obj.impressions !=0){
										obj.impressions = value.id_data[0].metrics.impressions[0];
										//console.log(obj.impressions);
									}
									obj.engagements = value.id_data[0].metrics.engagements;
									if(obj.engagements !=0){
										obj.engagements = value.id_data[0].metrics.engagements[0];
										//console.log(obj.engagements);
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if(obj.impressions == 0 && obj.engagements == 0){
									//console.log(obj.engrate);
									obj.engrate = 0;
									}
									else if(obj.impressions > 0 && obj.engagements > 0){
									//obj.engrate = obj.engagements / obj.impressions;
									$scope.engratecheck = obj.engagements / obj.impressions;
									console.log($scope.engratecheck);
										if(obj.engrate < 1){
									obj.engrate = 0;
									}
									}
								});
								
									}
									}
									}
									
									 else {
										obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }
									
                                }));
								
                                $scope.tweetedArray.push(obj);

                            }
                        }

                    });


                }
                else {
                    $scope.mainLoader = "none";
                    console.log(response.data.errorMessage);
					$scope.showErrorPopup(response);
                }
				
				$q.all(promises).finally(
                    function(){
                         //$scope.onloadchild();
                        $scope.mainLoader = "none";
                    });
				
            }));

        }
		
        
        //Get All tweets in campaign
       $scope.getAllTweetsinCampaign = function () {
            var promises = [];
             $scope.tweetedArray = [];
             $scope.scopenone = [];
             $scope.scopefollowers = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=none" + "&" + "promotedTweetsOnly=true";
            var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=followers" + "&" + "promotedTweetsOnly=true";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                   // $scope.tweetedArray = [];
                    //$scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                        // console.log(JsonObj);
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
								$scope.impressions =0;
                                $scope.engagements =0;
                                $scope.engrate =0;
								$scope.impressionspromoted =0;
                                $scope.engagementspromoted =0;
                                $scope.engratepromoted =0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                   // $(".tableCell .setcolumnheight").css("height", "175px");
                                }
                                else {
                                    $scope.media_url = "";
                                    // $(".tableCell .setcolumnheight").css("height", "75px");
                                }
								
								if($scope.campaignState == "edit"){
                                    //$scope.checkVal=true;
                                    if($scope.promotedtweetID.includes($scope.tweeterID) == true){                                    
                                    $scope.checkVal[key] = true;
									//console.log($scope.tweetObj.tweetsChecked);
                                    $scope.checkTweet = $scope.promotedtweetID.length;                                  
                                    
                                    }
                                    else{
                                    //$scope.checkVal=false;                                        
                                    }
                                    }
								
                                var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
									"impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
									"impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
								$scope.impressionsSum = [];
							    $scope.engagementsSum = [];
								$scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                       // console.log(response.data.promotedTweets.length);
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
										
										
										//Stats service for promoted campaign
										$scope.promotedCampaign = response.data.promotedTweets;
										$scope.statID = [];
										angular.forEach($scope.promotedCampaign, function (value, key) {
											var JsonObj2 = $scope.promotedCampaign[key]
											var array2 = [];
											//$scope.statID = [];
											for (var i in JsonObj2) {
											if (JsonObj2.hasOwnProperty(i)) {
												array2[+i] = JsonObj2[i];
												$scope.statdata1 = array2[+i];
												//console.log($scope.statdata1.promotedTweetId);
												$scope.statID.push($scope.statdata1.promotedTweetId);												
												}												
												}
										})
										//$scope.statID.push($scope.statdata1.promotedTweetId);
										//console.log($scope.statID);
										$scope.statIDsum = [];
										
										angular.forEach($scope.statID, function (value, key) {
											//$scope.statIDsum[0] += $scope.statID[key];
											//console.log($scope.statIDsum);
											
											//Stats service
								var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {								
								if (response.data.appStatus == '0') {								
								$scope.statsDatapromote = response.data.stats;								
								 var JsonObj3 = $scope.statsDatapromote;
								//console.log(JsonObj1);
								var array3 = [];
								for (var j in JsonObj3) {
								if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                array3[+j] = JsonObj3[j];
								$scope.statdata3 = array3[+j];

								angular.forEach($scope.statdata3, function (value, key) {								
									
									$scope.impressionsSum1 = value.id_data[0].metrics.engagements;
									//console.log($scope.impressionsSum1);
									$scope.impressionsSum.push($scope.impressionsSum1);
									
									if($scope.impressionsSum1 !=0){
										//obj.impressions = value.id_data[0].metrics.impressions[0];
										$scope.impressionsSum.push($scope.impressionsSum1[0]);
										
									}
									$scope.engagementsSum1 = value.id_data[0].metrics.engagements;
									$scope.engagementsSum.push($scope.engagementsSum1);
									//console.log($scope.engagementsSum1);
									if($scope.engagementsSum1 !=0){										
										$scope.engagementsSum.push($scope.engagementsSum1[0]);										
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0){
									//console.log(obj.engrate);
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0){
									//obj.engrate = 0;
									$scope.engrateSum1 = 0;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
									else if($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0){
									//obj.engrate = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
									$scope.engrateSum.push($scope.engrateSum1);
									}
									
								});
								
								
									}
									}
									}
									
									 else {
										$scope.engagementsSum = 0;
                                        $scope.impressionsSum = 0;
                                        $scope.engrateSum = 0;
                                    }
									
                                }));
										
										})
										//console.log($scope.impressionsSum);
										$scope.statIDsum1 = 0;
										angular.forEach($scope.impressionsSum, function (value, key) {
											//$scope.statIDsum1 =[];
											$scope.statIDsum1 += $scope.impressionsSum[key];
											//nsole.log($scope.statIDsum1);
											})
											
											//console.log($scope.statIDsum1);
											
											obj.impressionspromoted = $scope.statIDsum1;
											//console.log(obj.impressionspromoted);
											
											$scope.statIDsum2 = 0;
											angular.forEach($scope.engagementsSum, function (value, key) {
											//$scope.statIDsum12 =[];
											$scope.statIDsum2 += $scope.engagementsSum[key];
											})
											obj.engagementspromoted = $scope.statIDsum2;
											//console.log(obj.engagementspromoted);
											
											$scope.statIDsum3 = 0;
											angular.forEach($scope.engrateSum, function (value, key) {
											//$scope.statIDsum3 =[];
											$scope.statIDsum3 += $scope.engrateSum[key];
											})
											obj.engratepromoted = $scope.statIDsum3;
											//console.log(obj.engratepromoted);
										
										//console.log($scope.statIDsum);
										
                                    }
                                    else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
										obj.impressionspromoted = 0;
										obj.engagementspromoted = 0;
										obj.engratepromoted = 0;
                                    }

                                }));
								
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								if (response.data.appStatus == '0') {
								$scope.statsData = response.data.stats;
								
								 var JsonObj1 = $scope.statsData;
								//console.log(JsonObj1);
								var array1 = [];
								for (var j in JsonObj1) {
                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                array1[+j] = JsonObj1[j];
								$scope.statdata = array1[+j];
								//console.log($scope.statdata);
								
								angular.forEach($scope.statdata, function (value, key) {
									//console.log(key);
									//console.log(value.id);
									//console.log(value.id_data[0].metrics.impressions);
									//console.log(value.id_data[0].metrics.engagements);
									obj.impressions = value.id_data[0].metrics.impressions;
									//console.log(obj.impressions);
									if(obj.impressions !=0){
										obj.impressions = value.id_data[0].metrics.impressions[0];
										//console.log(obj.impressions);
									}
									obj.engagements = value.id_data[0].metrics.engagements;
									if(obj.engagements !=0){
										obj.engagements = value.id_data[0].metrics.engagements[0];
										//console.log(obj.engagements);
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if(obj.impressions == 0 && obj.engagements == 0){
									//console.log(obj.engrate);
									obj.engrate = 0;
									}
									else if(obj.impressions > 0 && obj.engagements > 0){
									//obj.engrate = obj.engagements / obj.impressions;
									$scope.engratecheck = obj.engagements / obj.impressions;
									console.log($scope.engratecheck);
										if(obj.engrate < 1){
									obj.engrate = 0;
									}
									}
								});
								
									}
									}
									}
									
									 else {
										obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }
									
                                }));
								
                                $scope.scopenone.push(obj);
                                 //$scope.tweetedArray.push([$scope.scopenone]);
                                //console.log($scope.scopenone);

                            }
                            
                            
                        }

                    });
                        
                         promises.push(twitterGetPost.gettweet(queryStr1, data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                   // $scope.tweetedArray = [];
                    //$scope.tweetedArray2 = [];
                    //$scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                        // console.log(JsonObj);
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
								$scope.impressions =0;
                                $scope.engagements =0;
                                $scope.engrate =0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                   // $(".tableCell .setcolumnheight").css("height", "175px");
                                }
                                else {
                                    $scope.media_url = "";
                                    // $(".tableCell .setcolumnheight").css("height", "75px");
                                }
                                var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
									"impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
									"impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId")  + "&" + "tweetId=" + $scope.tweeterID;
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                       // console.log(response.data.promotedTweets.length);
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
                                    }
                                    else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
                                    }

                                }));
								
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								if (response.data.appStatus == '0') {
								$scope.statsData = response.data.stats;
								
								 var JsonObj1 = $scope.statsData;
								//console.log(JsonObj1);
								var array1 = [];
								for (var j in JsonObj1) {
                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                array1[+j] = JsonObj1[j];
								$scope.statdata = array1[+j];
								//console.log($scope.statdata);
								
								angular.forEach($scope.statdata, function (value, key) {
									//console.log(key);
									//console.log(value.id);
									//console.log(value.id_data[0].metrics.impressions);
									//console.log(value.id_data[0].metrics.engagements);
									obj.impressions = value.id_data[0].metrics.impressions;
									//console.log(obj.impressions);
									if(obj.impressions !=0){
										obj.impressions = value.id_data[0].metrics.impressions[0];
										//console.log(obj.impressions);
									}
									obj.engagements = value.id_data[0].metrics.engagements;
									if(obj.engagements !=0){
										obj.engagements = value.id_data[0].metrics.engagements[0];
										//console.log(obj.engagements);
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if(obj.impressions == 0 && obj.engagements == 0){
									//console.log(obj.engrate);
									obj.engrate = 0;
									}
									else if(obj.impressions > 0 && obj.engagements == 0){
									obj.engrate = 0;
									}
								});
								
									}
									}
									}
									
									 else {
										obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }
									
                                }));
								
                                $scope.scopefollowers.push(obj);
                               $scope.tweetedArray = $scope.scopefollowers.concat($scope.scopenone);
                               // $scope.tweetedArray;
                                //console.log($scope.tweetedArray);

                            }
                        }

                    });


                }
                else {
                    $scope.mainLoader = "none";
                    console.log(response.data.errorMessage);
					$scope.showErrorPopup(response);
                }
            }));
                        

                }
                else {
                    $scope.mainLoader = "none";
                    console.log(response.data.errorMessage);
					$scope.showErrorPopup(response);
                }
				
				$q.all(promises).finally(
                    function(){
                         //$scope.onloadchild();
                        $scope.mainLoader = "none";
                    }); 
				
            }));
            
            
            
        }

        //$scope.getPromotedOnlyTweets();
		
		//Get media only content
		 $scope.tweetsArray=[];
        var tweetObj={};
		 $scope.fetchMedia = function () {
            var promises = [];
            
                $scope.promotedtweetID = [];
               // $scope.deleteTweetId = [];
                $scope.deleteTweetIdLength = 0;
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "id=" + $window.localStorage.getItem("twtweetID");
                promises.push(twitterGetPost.gettweetbyid(queryStr, data).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mediaResponse = response.data.tweetDetails;
                        //console.log(JSON.stringify($scope.mediaResponse,null,2));

                        angular.forEach($scope.mediaResponse, function (value, key) {
                            var JsonObj = $scope.mediaResponse[key];
                            console.log(JSON.stringify(JsonObj,null,2));
                             $scope.created_at = JsonObj.user.created_at.split(' ')[1] + ' ' + JsonObj.user.created_at.split(' ')[2];
                            //console.log(JSON.stringify($scope.extended_entities,null,2));
                            var array = [];
                                $scope.extended_entities = JsonObj.extended_entities;
                                if($scope.extended_entities!=undefined){
                            for (var i in $scope.extended_entities) {
                                if ($scope.extended_entities.hasOwnProperty(i)) {
                                    array[+i] = $scope.extended_entities;
                                    //console.log(array[+i]);
                                    $scope.iteratedtweets = array[+i];
                                     console.log(JSON.stringify($scope.iteratedtweets,null,2));
                                  tweetObj= {
                                    "profile_image" : JsonObj.user.profile_image_url,
                                    "name" :JsonObj.user.name,
                                    "screenName" : JsonObj.user.screen_name,
                                    "created_at" : $scope.created_at,
                                    "text" : JsonObj.text,
                                    "tweeterID": JsonObj.id_str,
                                    "media_url" :   $scope.iteratedtweets.media[0].media_url
                                      
                                  }
                                }

                            }
                        }else{
                            tweetObj= {
                                    "profile_image" : JsonObj.user.profile_image_url,
                                    "name" :JsonObj.user.name,
                                    "screenName" : JsonObj.user.screen_name,
                                    "created_at" : $scope.created_at,
                                    "tweeterID": JsonObj.id_str,
                                    "text" : JsonObj.text
                                      
                                  }
                        }
                        
                        })
                        var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId")  + "&" + "tweetId=" + $window.localStorage.getItem("twtweetID");
                                //$scope.mainLoader = "block";
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        //$scope.mainLoader = "none";
										console.log(response.data);
                                        //console.log(response.data.promotedTweets.length);
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        tweetObj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
                                        /*obj.impressionspromoted = $scope.promotedTweetLength;
                                         obj.engagementspromoted = $scope.promotedTweetLength;
                                         obj.engratepromoted = $scope.promotedTweetLength; */
                                    }else{
										$scope.mainLoader = "none";
                                        tweetObj.promotedCount = "Promoted-only -" + "Currently Unpromoted";
										tweetObj.impressionspromoted = 0;
										tweetObj.engagementspromoted = 0;
										tweetObj.engratepromoted = "0.0%";
                                    }
                                }))
								
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $window.localStorage.getItem("twtweetID") + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
								
								 promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								//$scope.mainLoader = "block";
								if (response.data.appStatus == '0') {
								//$scope.mainLoader = "none";
								$scope.statsData = response.data.stats;
								console.log($scope.statsData);
								 var JsonObj1 = $scope.statsData;
								//console.log(JsonObj1);
								var array1 = [];
								for (var j in JsonObj1) {
                                                                if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                                                    array1[+j] = JsonObj1[j];
								$scope.statdata = array1[+j];
								
								angular.forEach($scope.statdata, function (value, key) {									
									tweetObj.impressions = value.id_data[0].metrics.impressions[0];
									console.log(tweetObj.impressions);
									if(tweetObj.impressions !=0){
										tweetObj.impressions = value.id_data[0].metrics.impressions[0];
										console.log(tweetObj.impressions);
									}
									tweetObj.engagements = value.id_data[0].metrics.engagements[0];
									if(tweetObj.engagements !=0){
										tweetObj.engagements = value.id_data[0].metrics.engagements[0];
										console.log(tweetObj.engagements);
									}
									//obj.engrate = obj.engagements / obj.impressions;
									
									if(tweetObj.impressions == 0 && tweetObj.engagements == 0){
									console.log(tweetObj.engrate);
									tweetObj.engrate = "0.0%";
									}
									else if(tweetObj.impressions > 0 && tweetObj.engagements == 0){
									tweetObj.engrate = "0.0%";
									}
									else if(tweetObj.impressions > 0 && tweetObj.engagements > 0){
									//obj.engrate = obj.engagements / obj.impressions;
									$scope.engratecheck = tweetObj.engagements / tweetObj.impressions;
									console.log($scope.engratecheck);
										if(tweetObj.engrate < 1){
									tweetObj.engrate = "0.0%";
									}
									}
								});
								
									}
									}
									$scope.setLine();
									    var a=0;
										angular.forEach($scope.tweetsArray,function(value,index){
										var h2 = $("#parenttd"+a).height();      
											var tableHeight = $("#tablever").height(); 
											console.log(tableHeight);
										angular.element('#childtd'+a).css('height', h2);
										angular.element('#childtd1'+a).css('height', h2);
										angular.element('#childtd2'+a).css('height', h2);
										a=a+1;  
										angular.element('.vrtable1').css('height', tableHeight);
										angular.element('.vrtable2').css('height', tableHeight);
										angular.element('.vrtable3').css('height', tableHeight);
										});
										$scope.mainLoader = "none";
									}
									
									 else {
										$scope.mainLoader = "none";
										tweetObj.impressions = 0;
                                        tweetObj.engagements = 0;
                                        tweetObj.engrate = 0;
										$scope.setLine();
                                    }
									$scope.setLine();
										var a=0;
										angular.forEach($scope.tweetsArray,function(value,index){
										var h2 = $("#parenttd"+a).height(); 
											var tableHeight = $("#tablever").height(); 	
											console.log(tableHeight);											
										angular.element('.childtd'+a).css('height', h2);
										
										a=a+1;
										angular.element('.vrtable1').css('height', tableHeight);
										angular.element('.vrtable2').css('height', tableHeight);
										angular.element('.vrtable3').css('height', tableHeight);
										});
                                }));
                        $scope.tweetsArray.splice(0,0,tweetObj);
                    }
                    console.log($scope.tweetsArray);
                }));

            
        }
		
		
		//$scope.fetchMedia();
		
		$scope.readPromotedTweetsEdit = function(){
		
        $scope.promotedtweetID1 = [];
        $scope.deleteTweetId = [];
        $scope.deleteTweetIdLength = 0;
             $scope.mainLoader = "block";
           //console.log('edit flow');
           var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
                
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&lineItemId=" + $window.localStorage.getItem("lineItemid");
            twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.promotedArray = [];
                    $scope.promoteFetch = response.data.promotedTweets;
                    // $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                   console.log(JSON.stringify(response.data, null, 2));

                    angular.forEach($scope.promoteFetch, function (value, key) {
                        var JsonObj = $scope.promoteFetch[key]
                        console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweetsFetch = array[+i];
//                                console.log(JSON.stringify($scope.iteratedtweetsFetch, null, 2));
                                //$scope.deleteTweetId = $scope.iteratedtweetsFetch.promotedTweetId;
                                angular.forEach($scope.iteratedtweetsFetch, function (value, key) {

                                    $scope.promotedTweetStatus = value.promotedTweetStatus;
                                    if ($scope.promotedTweetStatus != "DELETED") {                                       
                                        $scope.promotedtweetID1.push(value.promotedTweetDetails.tweet_id);
										$scope.deleteTweetId.push(value.promotedTweetDetails.id);
                                    }
                                })								
                            }                           
                            $window.localStorage.setItem("deleteTweetId", $scope.deleteTweetId);
							$scope.tweetsChecked.push($scope.deleteTweetId);
                        }
                        $scope.promotedtweetIDLength = $scope.deleteTweetId.length;                        
                    });
                    
                   
                }
 
                else {
                    $scope.mainLoader = "none";                  
                    console.log(response.data.errorMessage);
                    
                }
 
            });
             $scope.deleteTweetIdLength = $scope.deleteTweetId.length;
             
        }
		
        $scope.init();



        //Promoted Tweet Map
        $scope.createPromotedTweetMap = function () {
            //alert('hi');
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                'tweetIds': $window.localStorage.getItem("multipleTweetId")
            };
            var queryStr = "";
            twitterGetPost.createpromotedtweetsmap("", data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                    //$scope.tweetedArray =[];
                    // 
                    //angular.element($('.btnCampaignCreative').prop('disabled', true));
                    console.log(response.data.successMessage);
                    //console.log('Response for createpromotedtweetsmap POST call++');
                    console.log(response.data);
                    $scope.getPromotedTweetsForAccount();

                }
                else {
                    $scope.mainLoader = "none";
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    console.log(response.data);
                    console.log(response.data.errorMessage);
					$scope.showErrorPopup(response);
                }
            })
        }

        //Get Promoted tweet for Account
        $scope.getPromotedTweetsForAccount = function () {
            $scope.getTweetDetails = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "lineItemIds=" + $window.localStorage.getItem("lineItemid") + "&withDeleted=true";
            twitterGetPost.getpromotedtweetsforaccount(queryStr, data).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {

                    $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    //console.log(response.data);
                    $scope.getTweetDetails = response.data.promotedTweets;
                    console.log($scope.getTweetDetails);
                    
                    
                    if($scope.getTweetDetails.length == 0)
					{
						$scope.mainLoader = "none";            
						$rootScope.campaignSteps[3] = true;
						$rootScope.campaignSteps[4] = true;
						$state.go('app.twittercampaignsummary');
					}
					else{
						$scope.savePromotedTweets();
					} 
                    $scope.savePromotedTweets();
                    // $scope.mainLoader = "none"; 
                    //$state.go('app.twittercampaignsummary');
                }

                else {
                    $scope.mainLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
					$scope.showErrorPopup(response);
                }

            });



        }
     	$scope.setLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.fsValue = angular.element(document.getElementById('step1')).offset().top;					
							
						$scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                                              
                                                var fStep = $(".vr");						
                                                fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
                                                
					}
					}, 10);
			};
			$scope.setLine();

        //Save promoted tweets local DB
        $scope.savePromotedTweets = function () {
            
            
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                'tweetDetails': $scope.getTweetDetails
            };
            var queryStr = "";
            twitterGetPost.savepromotedtweets("", data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {

                    $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    console.log(response.data);
                    $scope.mainLoader = "none";
					$rootScope.campaignSteps[3] = true;
					$rootScope.campaignSteps[4] = true;
                    $state.go('app.twittercampaignsummary');
                }

                else {
                    $scope.mainLoader = "none";
                    //console.log(response.data);
                    //console.log(response.data.errorMessage);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
					$scope.showErrorPopup(response);
                }

            });



        }


        //Tweets popup functionality
        $scope.uploadFile = function (files) {
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').attr('src', e.target.result);
                $scope.dataURL = reader.result;
                //console.log($scope.dataURL);
                $scope.splittedData = $scope.dataURL.split(',')[1];
                // alert($scope.splitted);
                $scope.mainLoader = "block";
            };

            $timeout(function () {
                //console.log($scope.dataURL); 
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'mediaData': $scope.splittedData
                };
                if (typeof (files[0]) == "object") {
                    twitterGetPost.mediaupload("", data).then(function (response) {
                        console.log(response);

                        if (response.data.appStatus == 0) {
                            $scope.mainLoader = "none";
                            $scope.mediaID = response.data.mediaDetails.media_id_string;
                            console.log(response.data.successMessage);
                            console.log($scope.mediaID);
                            $window.localStorage.setItem("twMediaID", $scope.mediaID);


                        }
                        else {
                            console.log(response.data);
                            $scope.mainLoader = "none";
							$scope.showErrorPopup(response);
                            //alert('failed');
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }
                    });

                }

            }, 1000);
            console.log(files[0]);
            reader.readAsDataURL(files[0]);
            $scope.uploading = false;
            $scope.previewing = true;

        };

        //Update tweet content

        $scope.sendTweetContent = function (val) {
            $scope.tweetContent = val;
            $window.localStorage.setItem("tweetContents", $scope.tweetContent)

        };

        $scope.publishTweets = function () {
            $scope.gettweetmediaID = $window.localStorage.getItem("twMediaID");
            $scope.mainLoader = "block";

            if ($scope.gettweetmediaID == "" || $scope.gettweetmediaID == null || $scope.gettweetmediaID == undefined) {
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $window.localStorage.getItem("tweetContents")
                };

                twitterGetPost.createtweet("", data).then(function (response) {
                    console.log(response);

                    if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        console.log(response.data.successMessage);
                        //console.log($scope.mediaID);
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;
                       // $scope.getPromotedOnlyTweets();	
						$scope.fetchMedia();					   
                        $scope.closePopup();
                          angular.element($('.btnCampaignCreative').prop('disabled', false));
                    }
                    else {
                        console.log(response.data.errorMessage);
                        $scope.mainLoader = "none";
						$scope.showErrorPopup(response);
                        //alert('failed');
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                });
            }
            else {

                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $window.localStorage.getItem("tweetContents"),
                    'mediaIds': $window.localStorage.getItem("twMediaID")
                };

                twitterGetPost.createtweet("", data).then(function (response) {
                    console.log(response);

                    if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        console.log(response.data.successMessage);
                        //console.log($scope.mediaID);
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;
                        //$scope.getPromotedOnlyTweets();
						$scope.fetchMedia();
                        $scope.closePopup();

                    }
                    else {
                        console.log(response.data.errorMessage);
                        $scope.mainLoader = "none";
						$scope.showErrorPopup(response);
                        //alert('failed');
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                });
            }
        };

        $scope.closePopup = function () {
            //$scope.browseImgSuccessMsg = "none";
            //$scope.browselibrary = "none";
            angular.element($('body').css("overflow-y", "scroll"));
			$scope.tweetContent = " ";
            $scope.uploading = true;
            $scope.previewing = false;
			if($scope.campaignState == "create"){
						console.log($scope.campaignState == "create");
							//$scope.checkVal[0] = true;
							console.log($scope.checkVal[0]);
							
						}
        }

        //Select Tweet Types
        $scope.sendTweetTpe = function (val) {
            $scope.tweetselectedItem = val;
            //alert($scope.tweetselectedItem);
            if ($scope.tweetselectedItem == "Promoted only tweets") {
                //alert('promoted');
                $scope.getPromotedOnlyTweets();

            }
            else if ($scope.tweetselectedItem == "Organic Tweets") {
                //alert('organic');
                $scope.getOrganicTweets();
            }
            else if ($scope.tweetselectedItem == "All Tweets in Campaign") {
                //alert('all tweets');
                $scope.getAllTweetsinCampaign();
            }
        }

        
        $scope.saveAndProceedNextStep = function () {
			//$rootScope.campaignSteps[3] = true;
           // $rootScope.campaignSteps[4] = true;
			//$scope.createPromotedTweetMap();
             //$state.go('app.twittercampaignsummary');
           
            if($scope.campaignState == "edit"){
			$scope.deleteTweetIdLengthcheck = $window.localStorage.getItem("deleteTweetId");
			//console.log($scope.deleteTweetIdLength);
			console.log($scope.deleteTweetIdLengthcheck);
			if($scope.deleteTweetIdLengthcheck == null || $scope.deleteTweetIdLengthcheck == "undefined" || $scope.deleteTweetIdLengthcheck == " "){
				$scope.createPromotedTweetMap();
				//$state.go('app.twittercampaignsummary');
			}
			else{
				$scope.deletepromotedtweet();
				//$scope.createPromotedTweetMap();
			}
				
				
			}
			else{
				$scope.createPromotedTweetMap();
				
			}
			
			
        }
		
		 $scope.deletepromotedtweet = function(){
        
        
            angular.forEach($scope.deleteTweetId, function (value, key) {
             var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&promotedTweetId=" + $scope.deleteTweetId[key];
            $http({
                method: 'DELETE',
                url: apiTwitterBase + '/deletepromotedtweet?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                   
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log("success");
					$scope.createPromotedTweetMap();
                } else {// failed
                    console.log("failed");
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
            });
        }


        $scope.changeSelection = function (image_hash) {
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }


        $scope.twitterAccounts = [
            {
                accountName: "@adtech_live",
            }
        ]

        $scope.tweetsPromote = [
            {
                promoted: "Promoted only tweets",
            },
            {
                promoted: "Scheduled Tweets",
            },
            {
                promoted: "Organic Tweets",
            },
            {
                promoted: "All Tweets in Campaign",
            }
        ]

        $scope.tweetPopup = function () {
            //alert('popup');
			$scope.tweetContent = "";
            $scope.card.cardHeadline="";
            $scope.card.cardWebisteURL="";
            $scope.card.cardName="";
			$scope.headline="";
            angular.element($('body').css("overflow-y", "hidden"));
            var createPopup = $(".tweetCreatePopup");// Get the modal Reject req
            createPopup.show();

            //Tweets charcter count

            $scope.maxLength = 140;
            angular.element($('.input-tweets textarea').keyup(function () {
                //alert('enter');
                $scope.length = angular.element($('.input-tweets textarea')).val().length;
                $scope.charlength = $scope.maxLength - $scope.length;
                angular.element($('.input-tweets #chars')).text($scope.charlength);
            }));


            $scope.createBlock = true;
            $scope.mediaUpdate = true;
            $scope.cardUpdate = true;
            $scope.media=true;
            $scope.twitterFormat = "twittermediaUpdate";
            //$scope.twitterFormat = "twittercardUpdate";
            $scope.inputTypeFile = false;
			
			if($window.localStorage.getItem("twMediaID") != '' || $window.localStorage.getItem("twMediaID") != 'undefined' || $window.localStorage.getItem("twMediaID") != undefined ||  $window.localStorage.getItem("twMediaID") != null){
                $window.localStorage.setItem("twMediaID","");
            }

        }

        $scope.closePopup = function () {
            $scope.createBlock = false;
                    $scope.card.cardHeadline="";
                    $scope.card.cardWebisteURL="";
                    $scope.card.cardName="";
                    $scope.headline="";
                    $scope.websiteUrl="";
                    $scope.cardname="";
                    $scope.previewingcard=false;
                    $scope.previewing=false;
                    $scope.uploadingcard=true;
                    $scope.uploading=true;
            angular.element($('body').css("overflow-y", "scroll"));
        }

        $scope.selectMedia = function (twitterFormat) {
            $scope.twitterFormat = "twittermediaUpdate";
            $scope.mediabutton=true;
            $scope.cardbutton=false;
            $scope.cardselectbutton=false;
            $scope.previewingcard=false;
            $scope.uploadingcard=true;
            $scope.media=true;
			$scope.mediaarrow=true;
			$scope.cardarrow=false;
        }

        $scope.selectMedia1 = function (twitterFormat) {
            $scope.twitterFormat = "twittercardUpdate";
            $scope.mediabutton=false;
            $scope.cardbutton=true;
            $scope.cardselectbutton=false;
            $scope.previewing=false;
            $scope.uploading=true;
            $scope.media=false;
            $scope.createCards();  
			$scope.mediaarrow=false;
			$scope.cardarrow=true;			
        }


        //Tweets popup website card functionality
        $scope.uploadFilecard = function (files) {
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreviewcard').attr('src', e.target.result);
                $scope.dataURL = reader.result;
                //console.log($scope.dataURL);
                $scope.splittedData = $scope.dataURL.split(',')[1];
                // alert($scope.splitted);
                $scope.mainLoader = "block";
            };

            $timeout(function () {
                //console.log($scope.dataURL); 
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'mediaData': $scope.splittedData
                };
                if (typeof (files[0]) == "object") {
                    twitterGetPost.mediaupload("", data).then(function (response) {
                        console.log(response);

                        if (response.data.appStatus == 0) {
                            $scope.mainLoader = "none";
                            $scope.mediaID = response.data.mediaDetails.media_id_string;
                            console.log(response.data.successMessage);
                            console.log($scope.mediaID);
                            $window.localStorage.setItem("twMediaID", $scope.mediaID);
                            //$scope.createAccountCardWebsite();

                        }
                        else {
                            console.log(response.data);
                            $scope.mainLoader = "none";
							$scope.showErrorPopup(response);
                            //alert('failed');
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }
                    });

                }

            }, 1000);
            console.log(files[0]);
            reader.readAsDataURL(files[0]);
            $scope.uploadingcard = false;
            $scope.previewingcard = true;
            
        };
        
        $scope.createAccountCardWebsite = function (card) {
            //alert('hi');
            console.log($scope.card);
            //console.log($scope.card);
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'name': $scope.card.cardName,
                'imageMediaId': $scope.mediaID,
                'webSiteTitle':$scope.card.cardHeadline,
                'webSiteUrl':$scope.card.cardWebisteURL
            };
            var queryStr = "";
            twitterGetPost.createaccountcardwebsite("", data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                    //$scope.tweetedArray =[];
                    // 
                    //angular.element($('.btnCampaignCreative').prop('disabled', true));
                    $scope.createcardsuccess=response.data.accountCardWebSite;
                    console.log($scope.createcardsuccess);
                    $scope.preview_url=$scope.createcardsuccess.preview_url;
                    $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    //console.log('Response for createAccountCardWebsite POST call++');
                    //console.log(response.data);
                    //$scope.getPromotedTweetsForAccount();
                    //$scope.getPromotedOnlyTweets();
                    var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $scope.tweetContent+ " "+" " +$scope.preview_url
                };
                    twitterGetPost.createtweet("", data).then(function (response) {
                    console.log(response);

                    if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        //console.log(response.data.successMessage);
                        //console.log($scope.mediaID);
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;
                        //$scope.getPromotedOnlyTweets();
						$scope.fetchMedia();
                        $scope.closePopup();

                    }
                    else {
                        console.log(response.data.errorMessage);
                        $scope.mainLoader = "none";
						$scope.showErrorPopup(response);
                        //alert('failed');
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                });
                    
                }
                else {
                    $scope.mainLoader = "none";
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            })
        }
        
        $scope.getAccountCardWebsite=function(){
            $scope.mainLoader = "block";
            var promises = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");
            twitterGetPost.getaccountcardwebsite(queryStr, data).then(function (response){
                if (response.data.appStatus == '0') {
                    
                    $scope.mainLoader = "none";
                    //console.log(response.data.successMessage);
                    $scope.websitecards = response.data.accountCardWebSiteDetails;
                    angular.forEach($scope.websitecards, function (value, key) {
                        var JsonObj = $scope.websitecards[key]
                        var array = [];
                        loopCnt = key;
                       // console.log(JsonObj);
                        for (var i in JsonObj) {
                            
                            if (JsonObj.hasOwnProperty(i)) {
                                array[+i] = JsonObj[i];
                                //console.log(array[+i]);
                                $scope.iteratedtweets = array[+i];
                                //console.log($scope.iteratedtweets);
                                $scope.name = $scope.iteratedtweets.name;
                               // console.log($scope.name);
                                $scope.image=$scope.iteratedtweets.image;
                                //console.log($scope.image);
                                $scope.website_url=$scope.iteratedtweets.website_url;
                                //console.log($scope.website_url);
                                $scope.headline=$scope.iteratedtweets.website_title;
                                //console.log($scope.headline);
                                $scope.cardId=$scope.iteratedtweets.id;
                                //console.log($scope.cardId)
                                $scope.preview_url=$scope.iteratedtweets.preview_url;
//                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                var obj = {
                                    "headline": $scope.headline,
                                    "image": $scope.image,
                                    "cardname": $scope.name,
                                    "website_url": $scope.website_url,
                                    "cardId": $scope.cardId,
                                    "preview_url":$scope.preview_url
//                                    "created_at":$scope.created_at
                                 }
                                  
                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId")  + "&" + "tweetId=" + $scope.tweeterID;
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        //console.log(response.data.promotedTweets.length);
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
                                    }
                                    else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
                                    }

                                }));
                                $scope.tweetedArray1.push(obj);

                            }
                        }
                    })
                    //console.log($scope.tweetedArray1);
                }
                
            });
            
        }
      //  $scope.getAccountCardWebsite();
        
        
        $scope.createTweetCard=function(){
            var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $scope.tweetContent+ " "+" " +$scope.preview_url
                };
                    twitterGetPost.createtweet("", data).then(function (response) {
                        if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        console.log(response.data.successMessage);
                        //console.log($scope.mediaID);
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;
                        //$scope.getPromotedOnlyTweets();
                        $scope.fetchMedia();
						$scope.closePopup();

                    }
                    else {
                        console.log(response.data.errorMessage);
                        $scope.mainLoader = "none";
						$scope.showErrorPopup(response);
                        //alert('failed');
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                    })
        }
        
        $scope.showpreview=function(id){
            //console.log($scope.tweetedArray1);
            //console.log($scope.tweetedArray1.cardId+"asdd"+id);
            for(var i=0;i<$scope.tweetedArray1.length;i++)
            {
                   // console.log($scope.tweetedArray1[i].cardId);
                    console.log(id);
                if($scope.tweetedArray1[i].cardId==id){
                    
                    $scope.headline=$scope.tweetedArray1[i].headline;
                    $scope.websiteUrl=$scope.tweetedArray1[i].website_url;
                    $scope.cardname=$scope.tweetedArray1[i].cardname;
                }
            }
        }

		
		//Sandbox VERSION
		$scope.checkTweet = 0;		
		$scope.checkedTweet=[];
        $scope.setTweetCheck = function (item) {
            $scope.tweetObj = {};
            $scope.tweetObj.tweetsChecked = [];
            $scope.tweetObj.tweetsUnChecked = [];
            $scope.multipleTweetId = [];
			$scope.multipleTweetMediaURL = [];
            $scope.webpreviewTweets1 = [];
            $scope.multipleTweetIFrameURL = []; 
			  var index = $scope.checkedTweet.indexOf(item);
            if (index > -1) {
                $scope.checkedTweet.splice(index, 1);
            } else {
                $scope.checkedTweet.push(item);
            }

            $(".tableRowContent input:checkbox").each(function () {
                var $this = $(this);
                $scope.totalItems = angular.element($('.tweetcount')).html();
                $scope.totalItemsCount = parseInt($scope.totalItems);
				//console.log($scope.totalItemsCount);
                if ($this.is(":checked")) {
					    if($scope.checkedTweet.length > 1 ){
                            angular.element('.naviButtons #right').css('pointer-events' , 'auto');
                            angular.element('.naviButtons #left').css('pointer-events' , 'auto');
                        }else{
                             angular.element('.naviButtons #right').css('pointer-events' , 'none');
                             angular.element('.naviButtons #left').css('pointer-events' , 'none');
                        }
						console.log($scope.checkedTweet.length-1);
						
                    angular.element($('#step1').css('background-color', 'rgb(149, 210, 177)'));
					angular.element($('#step2').css('background-color', 'rgb(149, 210, 177)')); 
					angular.element('.creativePreviewBlock').css('pointer-events', ' auto');
                    $scope.tweetObj.tweetsChecked.push($this.attr("id"));
					console.log($scope.tweetObj.tweetsChecked);
                    $scope.checkTweet = $scope.tweetObj.tweetsChecked.length;
					console.log($scope.checkTweet);
					//vm.checkTweet1 = $scope.checkTweet;
					console.log(typeof($scope.checkTweet1));
                    angular.element($('.btnCampaignCreative').prop('disabled', false));

                } else {
				
					if($scope.carouselFlow > $scope.checkTweet){
						console.log('drop collapse');
						$scope.carouselFlow = $scope.checkTweet;
						 angular.element('.naviButtons #left').css('pointer-events' , 'auto');
						$('#collapseOne1').removeClass('in');
						$('#collapseTwo1').removeClass('in');
						$('#collapseThree1').removeClass('in');
					}
                                        $scope.carouselFlow=1;
                    $scope.tweetObj.tweetsUnChecked.push($this.attr("id"));
					//console.log($scope.tweetObj.tweetsUnChecked);
                    $scope.checkTweet = $scope.tweetObj.tweetsChecked.length;					
                    if ($scope.checkTweet >= 1) {
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                    }
					
                    else {
                        angular.element($('.btnCampaignCreative').prop('disabled', true));
                        $window.localStorage.setItem("multipleTweetId", " ");
                         angular.element($('#step1').css('background-color', '#C2C2C2'));
                         angular.element('.creativePreviewBlock').css('pointer-events', ' none');
						angular.element($('#step2').css('background-color', '#C2C2C2'));
		
                    }

                }
            });
			
            for (var i = 0; i < $scope.tweetObj.tweetsChecked.length; i++) {
                //console.log($scope.tweetObj.tweetsChecked[i]);  
                var twChk = $scope.tweetObj.tweetsChecked[i];
                $scope.multipleTweetId.push($scope.tweetsArray[twChk].tweeterID);
				if($scope.multipleTweetIdedit.includes($scope.tweetsArray[twChk].tweeterID) == false){
					$scope.multipleTweetIdedit.push($scope.tweetsArray[twChk].tweeterID);
				}
                $window.localStorage.setItem("multipleTweetId", $scope.multipleTweetId);
                $scope.multipleTweetIFrameURL.push($scope.tweetsArray[twChk].IFrameURL);
                $window.localStorage.setItem("multipleTweetIFrameURL", $scope.multipleTweetIFrameURL);                
			}
            
        }
		
		
		/*$scope.$watch('vm.checkTweet1', function(newVal, oldVal) {
			console.log(newVal);
			console.log($scope.carouselFlow);
            if (newVal < $scope.carouselFlow) {
				console.log('changed tweetcheck value');
				$scope.carouselFlow = newVal;				
                $('#collapseOne1').removeClass('in');
				$('#collapseTwo1').removeClass('in');
				$('#collapseThree1').removeClass('in');
				
                
            } else {
                
            }
        }, true)  */

        $scope.deleteImg = function () {

            $scope.uploading = true;
            $scope.previewing = false;
        }

        $scope.deleteImgCard = function () {

            $scope.uploadingcard = true;
            $scope.previewingcard = false;
        }


        //Carousel navigation
        $scope.expand = function () {
            if ($scope.iosexpand == true) {
                $('#accr1').removeClass('collapsed');
                $('#collapseOne1').addClass('in');
				//_key = _key+1;
                $scope.iphonePreview();
            }

            if ($scope.androidexpand == true) {
                $('#accr2').removeClass('collapsed');
                $('#collapseTwo1').addClass('in');
                $scope.androidPreview();
            }
            if ($scope.desktopexpand == true) {
                $('#accr3').removeClass('collapsed');
                $('#collapseThree1').addClass('in');
                $scope.webPreview();
            }
        }

       $scope.rightNavCtrl = function (obj) {
			console.log($scope.multipleTweetIdedit);
            $scope.trustedHtml = "";
            $scope.trustedHtmliphone = "";
            $scope.trustedHtmlandroid = "";
			$scope.carouselFlow = $scope.carouselFlow + 1;
			if($scope.campaignState != "edit1"){
				angular.element('.naviButtons #left').css('pointer-events' , 'auto');	
           // if ($scope.multipleTweetId.length > ($scope.rightNavCtrlbtn + 1)) {
			 if ($scope.multipleTweetId.length > $scope.rightNavCtrlbtn ) {
                // angular.element('.leftNavArrow').show();
				console.log($scope.multipleTweetId.length);								
                $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn + 1);
                $scope.rightNavCtrlbtn = $scope.ctrlLimt;
              
            }
			
				  if ($scope.carouselFlow < $scope.checkTweet) {				 
                				
				$scope.carouselincr = $scope.carouselincr + 1;				
            }
            else {				
				angular.element('.naviButtons #right').css('pointer-events' , 'none');				
            }
			
			}
			
			else{			
				if ($scope.promotedtweetID.length > ($scope.rightNavCtrlbtn + 1)) {
				console.log($scope.carouselFlow);
			console.log($scope.promotedtweetID.length);               
                $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn + 1);
				$scope.carouselFlow = $scope.carouselFlow + 1;
                $scope.rightNavCtrlbtn = $scope.ctrlLimt;                
            }
				
				  if ($scope.carouselFlow < $scope.totalItemsCount) {
                $scope.carouselFlow = $scope.carouselFlow + 1;
            }
            
				
			}
          
            $scope.expand();


        }

        $scope.leftNavCtrl = function (ctrlLimt) {
            $scope.trustedHtml = "";
            $scope.trustedHtmliphone = "";
            $scope.trustedHtmlandroid = "";
            $scope.carouselFlow = $scope.carouselFlow - 1;
			angular.element('.naviButtons #right').css('pointer-events' , 'auto');	
            if ($scope.rightNavCtrlbtn != 0) {
                // angular.element('.rightNavArrow').show();

                $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn - 1);

                $scope.rightNavCtrlbtn = $scope.ctrlLimt;

                $scope.isLeftBtnEnable = false;
                $scope.isrightBtnEnable = true;
            }

            if ($scope.carouselFlow > 1) {
                
            }
            else {
                // angular.element('.leftNavArrow').hide();
				angular.element('.naviButtons #left').css('pointer-events' , 'none');
            }
            $scope.expand();

        }

        $scope.selectCards = function (cards) {
            //alert('select card');
            $scope.selectCard = true;
            $scope.createCard = false;
            $scope.cardselectbutton=true;
            $scope.mediabutton=false;
            $scope.cardbutton=false;
            $scope.tweetContent="";
        }

        $scope.createCards = function () {
            // alert('create card');
            $scope.selectCard = false;
            $scope.createCard = true;
            $scope.mediabutton=false;
            $scope.cardbutton=true;
            $scope.cardselectbutton=false;
            $scope.tweetContent="";
        }
        
        
		$scope.webPreview = function () {
        //alert('edit');
		console.log($scope.multipleTweetIdedit);
            $scope.twitterPreviewLoader = "block";
            var _key = $scope.carouselFlow - 1;
			console.log(_key);
            //console.log(_key + " :: " + $scope.multipleTweetId[_key]);
            //console.log(_key + " :: " + $scope.promotedtweetID[_key]);
            $scope.iosexpand = false;
            $scope.androidexpand = false;
            $scope.desktopexpand = true;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            
            if($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")){			
            var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];
            twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                console.log("edit preview");
                if (response.data.appStatus == '0') {
                    $scope.twitterPreviewLoader = "none";
                   // console.log(response.data.successMessage);
                    $scope.webpreviewTweets = response.data.previewTweet[0].preview;
                    $scope.trustedHtml = $sce.trustAsHtml($scope.webpreviewTweets);
                }
                else {
                    $scope.twitterPreviewLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }
            })
            }
            else{			
			console.log("create preview");
             var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
               // console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.twitterPreviewLoader = "none";
                   // console.log(response.data.successMessage);
                    $scope.webpreviewTweets = response.data.previewTweet[0].preview;
                    $scope.trustedHtml = $sce.trustAsHtml($scope.webpreviewTweets);
                }
                else {
                    $scope.twitterPreviewLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }
            })
            }
            // });
			$scope.setLine();
        }

         $scope.androidPreview = function () {
            $scope.twitterPreviewLoader = "block";
            var _key = $scope.carouselFlow - 1;
			console.log(_key);
            $scope.androidexpand = true;
            $scope.iosexpand = false;
            $scope.desktopexpand = false;
 
          
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                
                if($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")){	
                var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];
                twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                    //console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";                        
                        $scope.androidpreviewTweets = response.data.previewTweet[1].preview;                       
                        $scope.trustedHtmlandroid = $sce.trustAsHtml($scope.androidpreviewTweets);
 
                    }
                    else {
                        $scope.twitterPreviewLoader = "none";
                        console.log(response.data);
                        console.log(response.data.errorMessage);
                        $scope.showErrorPopup(response);
                    }
                    
                    
                })
                }
                else{
                     var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
                    //console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";                       
                        $scope.androidpreviewTweets = response.data.previewTweet[1].preview;
                        $scope.trustedHtmlandroid = $sce.trustAsHtml($scope.androidpreviewTweets);
 
                    }
                    else {
                        $scope.twitterPreviewLoader = "none";
                        console.log(response.data);
                        console.log(response.data.errorMessage);
                        $scope.showErrorPopup(response);
                    }
                    
                })
            }
			$scope.setLine();
            }


       $scope.iphonePreview = function () {            
            $scope.twitterPreviewLoader = "block";
            var _key = $scope.carouselFlow - 1;
			console.log($scope.carouselincr);
            $scope.desktopexpand = false;
            $scope.androidexpand = false;
            $scope.iosexpand = true;
			console.log($scope.multipleTweetId);
           // angular.forEach($scope.multipleTweetId, function (value, key) {
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                
                if($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")){	
               // var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];
			var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];				
                
                twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                   // console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                       // console.log(response.data.successMessage);
                        $scope.iphonepreviewTweets = response.data.previewTweet[2].preview;
                        $scope.trustedHtmliphone = $sce.trustAsHtml($scope.iphonepreviewTweets);
 
                    }
                    else {
                        $scope.twitterPreviewLoader = "none";
                        console.log(response.data);
                        console.log(response.data.errorMessage);
                        $scope.showErrorPopup(response);
                    }
                })
                }
                
                else{
                     var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
                   // console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                       // console.log(response.data.successMessage);
                        $scope.iphonepreviewTweets = response.data.previewTweet[2].preview;
                        $scope.trustedHtmliphone = $sce.trustAsHtml($scope.iphonepreviewTweets);
 
                    }
                    else {
                        $scope.twitterPreviewLoader = "none";
                        $scope.showErrorPopup(response);
                    }
                })
                
                }
				$scope.setLine();
                }
				
        $scope.showErrorPopup = function (response) {
            $scope.popupTitle = "Error";
            $scope.popupMessage = response.data.errorMessage;
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }
        $scope.showSuccessPopup = function (response) {
            //console.log('success popup here123');
            $scope.popupTitle = "Twitter creative";
            $scope.popupMessage = response.data.successMessage;
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show(); 
        }
        $scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            $scope.networkErrorPopup = 'none';
            successReq.hide();  
        }
    }]);