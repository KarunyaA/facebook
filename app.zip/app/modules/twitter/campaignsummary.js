dashboard.controller("twittercampaignsummaryController", ['$rootScope', '$scope', '$http', '$state', '$location', 'loginService', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', 'twitterGetPost', '$sce', '$filter', '$q', 'parser',
    function ($rootScope, $scope, $http, $state, $location, loginService, Flash, apiService, $window, appSettings, globalData, twitterGetPost, $sce, $filter, $q, parser) {
        var vm = this;
        vm.getData = {};
        vm.setSet = {};

        $scope.fifthActiveDiv = 'yes';
        $scope.activeNetworks = $rootScope.networkActive;
        console.log($rootScope.networkActive);
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = true;
        $scope.fifthActiveDivImg = false;

        var apiTPBase = appSettings.apiTPBase;
        vm.showDetails = true;
        $scope.campaignplan = [];
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.objective = ''; //Test variable, Not needed remove this decularation
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};
        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        //$scope.placement = [];
        $scope.currencyCode = "\uf156";
        $scope.campaignAudienceLocationsArr = [];
        $scope.campaignAudienceLanguageArr = [];
        $scope.targetingDisplayArray = [];
        $scope.mobilenewfeed = [];
        $scope.devices = [];
        $scope.currencyList = [];
        $scope.currencyCodeFlg = false;
        $scope.mediaType = "";
        $scope.mediaURL = "";
        $scope.imageSources = [];
        $scope.urlSources = [];
        $scope.lineItems = "";
        $scope.campaign = "";
        $scope.locationArray = [];
        $scope.languageArray = [];
        $scope.interestArray = [];
        $scope.behaviorArray = [];
        $scope.tvTargetArray = [];
        $scope.eventTargetArray = [];
        $scope.thumbnailArray = [];
        $scope.eventsArray = [];
        $scope.behaviorsArray = [];
        $scope.limitbehaviorsArray = [];
        $scope.tvTargetArray = [];
        $scope.targetDevices = [];
        $scope.targetCarriers = [];

        $scope.DTBehaviourArray = [];
        $scope.DTBehaviourNameArray = [];
        $scope.DTlimitBehaviourArray = [];
        $scope.DTlimitBehaviourNameArray = [];
        $scope.twitterReplicatorData = [];

//        $scope.media = {
//            "possibly_sensitive": false,
//            "created_at": "Fri Mar 17 06:52:25 +0000 2017",
//            "truncated": false,
//            "source": "<a href=\"https://twitter.com/advtech_live\" rel=\"nofollow\">CogTwitterAdApp</a>",
//            "retweet_count": 0,
//            "retweeted": false,
//            "entities": {
//                "urls": [],
//                "hashtags": [],
//                "media": [
//                    {
//                        "display_url": "pic.twitter.com/5NyemPDYai",
//                        "indices": [
//                            14,
//                            37
//                        ],
//                        "sizes": {
//                            "small": {
//                                "w": 680,
//                                "h": 272,
//                                "resize": "fit"
//                            },
//                            "large": {
//                                "w": 800,
//                                "h": 320,
//                                "resize": "fit"
//                            },
//                            "thumb": {
//                                "w": 150,
//                                "h": 150,
//                                "resize": "crop"
//                            },
//                            "medium": {
//                                "w": 800,
//                                "h": 320,
//                                "resize": "fit"
//                            }
//                        },
//                        "id_str": "842629651969327105",
//                        "expanded_url": "https://twitter.com/advtech_live/status/842629679077113858/photo/1",
//                        "media_url_https": "https://pbs.twimg.com/media/C7GfNDrXwAEBYHt.jpg",
//                        "id": 842629651969327100,
//                        "type": "photo",
//                        "media_url": "http://pbs.twimg.com/media/C7GfNDrXwAEBYHt.jpg",
//                        "url": "https://t.co/5NyemPDYai"
//                    },
//                    {
//                        "display_url": "pic.twitter.com/5NyemPDYai",
//                        "indices": [
//                            14,
//                            37
//                        ],
//                        "sizes": {
//                            "small": {
//                                "w": 680,
//                                "h": 272,
//                                "resize": "fit"
//                            },
//                            "large": {
//                                "w": 800,
//                                "h": 320,
//                                "resize": "fit"
//                            },
//                            "thumb": {
//                                "w": 150,
//                                "h": 150,
//                                "resize": "crop"
//                            },
//                            "medium": {
//                                "w": 800,
//                                "h": 320,
//                                "resize": "fit"
//                            }
//                        },
//                        "id_str": "842629651969327105",
//                        "expanded_url": "https://twitter.com/advtech_live/status/842629679077113858/photo/1",
//                        "media_url_https": "https://pbs.twimg.com/media/C7GfNDrXwAEBYHt.jpg",
//                        "id": 842629651969327100,
//                        "type": "photo",
//                        "media_url": "http://pbs.twimg.com/media/C7GfNDrXwAEBYHt.jpg",
//                        "url": "https://t.co/5NyemPDYai"
//                    }
//                ],
//                "user_mentions": [],
//                "symbols": []
//            },
//            "id_str": "842629679077113858",
//            "favorite_count": 0,
//            "id": 842629679077113900,
//            "text": "tweets 123!!! https://t.co/5NyemPDYai",
//            "scopes": {
//                "followers": false
//            },
//            "lang": "en",
//            "user": {
//                "friends_count": 0,
//                "profile_image_url_https": "https://abs.twimg.com/sticky/default_profile_images/default_profile_2_normal.png",
//                "listed_count": 0,
//                "default_profile_image": true,
//                "favourites_count": 0,
//                "description": "Advtech",
//                "created_at": "Thu Jun 23 06:51:02 +0000 2016",
//                "is_translator": false,
//                "protected": false,
//                "screen_name": "advtech_live",
//                "id_str": "745871769618219008",
//                "profile_link_color": "1DA1F2",
//                "is_translation_enabled": false,
//                "translator_type": "none",
//                "id": 745871769618219000,
//                "geo_enabled": false,
//                "profile_background_color": "F5F8FA",
//                "lang": "en",
//                "has_extended_profile": true,
//                "profile_sidebar_border_color": "C0DEED",
//                "profile_text_color": "333333",
//                "verified": false,
//                "profile_image_url": "http://abs.twimg.com/sticky/default_profile_images/default_profile_2_normal.png",
//                "contributors_enabled": false,
//                "profile_background_tile": false,
//                "statuses_count": 0,
//                "followers_count": 0,
//                "profile_use_background_image": true,
//                "default_profile": true,
//                "name": "Advtech",
//                "location": "United States",
//                "profile_sidebar_fill_color": "DDEEF6"
//            },
//            "favorited": false
//        }

        $scope.loadCurrencyCode = function () {
            $http.get("localData/currencyData.json").success(function (data) {
                $scope.currencyList = data.currencyList;
            });
        }
        $scope.checkCurrencyCode = function (_code) {
            angular.forEach($scope.currencyList, function (value, key) {
                if ($scope.currencyList[key].currency == _code) {
                    $scope.currencyCodeVal = $scope.currencyList[key].currencyCode;
                    $scope.currencyCodeFlg = true;
                }
            });
            $scope.currencyCode = $scope.currencyCodeVal

        }

        $scope.init = function () {
            $rootScope.progressLoader = "block";

            $scope.loadCurrencyCode();
            $scope.campaignState = $window.localStorage.getItem("campaignState");
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            $scope.todayDate = new Date();
            $scope.minDate = new Date();
            //$scope.loadCurrencyCode();
            if ($scope.campaignState == "create" || $scope.campaignState == "edit") {



                var queryStr = "?campaignId=" + $window.localStorage.getItem('twCampaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId");
                twitterGetPost.readcampaign(queryStr, "").then(function (response) {
                    if (response.data.appStatus == 0) {
//                        $rootScope.progressLoader = "none";
                        $scope.campaign = response.data.campaign;
                        if(response.data.campaign[0][$window.localStorage.getItem('twCampaignId')].twCampaignDetails.end_time != "" && response.data.campaign[0][$window.localStorage.getItem('twCampaignId')].twCampaignDetails.end_time != null && response.data.campaign[0][$window.localStorage.getItem('twCampaignId')].twCampaignDetails.end_time != undefined){
                            $scope.endTimeResponse = response.data.campaign[0][$window.localStorage.getItem('twCampaignId')].twCampaignDetails.end_time;
                        }else{
                            $scope.endTimeResponse = "null";
;                        }
                            console.log(response.data.campaign[0][$window.localStorage.getItem('twCampaignId')].twCampaignDetails.end_time);
                        $scope.twitterReplicatorData.push(response.data.campaign[0]);
                        $scope.fetchCampaign();
                        queryStr = "?campaignId=" + $window.localStorage.getItem('twCampaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId");
                        twitterGetPost.readlineitems(queryStr, "").then(function (response) {
                            if (response.data.appStatus == 0) {
                                $scope.lineItems = response.data.lineItems;
                                $scope.twitterReplicatorData.push(response.data.lineItems[0]);
                                angular.forEach($scope.lineItems, function (value, key) {
                                    var lineObj = $scope.lineItems[key];
                                    for (var i in lineObj) {
                                        angular.forEach(lineObj[i].twLineItemDetails.placements, function (placementsVal) {
                                            if (placementsVal == "TWITTER_TIMELINE") {
                                                placementsVal = "User's Timeline";
                                            } else {
                                                placementsVal = "Profiles & Tweet Detail Pages"
                                            }
                                            $scope.mobilenewfeed.push(placementsVal);
                                        })
                                    }
                                })
                                $scope.fetchLineItems();

                                queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&lineItemId=" + $window.localStorage.getItem("lineItemid");
                                twitterGetPost.readtargetingcriteria(queryStr, "").then(function (response) {
                                    $scope.targetingCriteria = response.data.targetingCriteria;
                                    if (response.data.appStatus == 0) {
                                        //$scope.fetchTargetLocation();
                                        $scope.twitterReplicatorData.push(response.data.targetingCriteria);
                                        $window.localStorage.setItem("twitterReplicatorData", JSON.stringify($scope.twitterReplicatorData));
                                        $scope.fetchGender();
                                        $scope.fetchMedia();
                                    }
                                })
                            }
                        })
                    }
                })
            }

        }

        $scope.fetchAllValues = function () {
            //-----------------------------------
            $scope.fetchCampaign();
            $scope.fetchLineItems();
            $scope.fetchGender();
            $scope.fetchTargetLocation();
            $scope.fetchTargetLanguage();
            $scope.fetchDetailedTargeting();
            $scope.fetchMobileNewsFeed();
            $scope.fetchDevices();
            $scope.fetchMedia();
			
            //-----------------------------------
        }
		$scope.setLine = function () {
            var everythingLoaded = setInterval(function () {
                if (/loaded|complete/.test(document.readyState)) {
                    clearInterval(everythingLoaded);
                    $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                    $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                    var offsetHeight2 = document.getElementById('step2container').offsetHeight;
                    var fStep = $(".vr");
                    fStep.css('height', (($scope.lsValue - $scope.fsValue)));

                }
            }, 10);
        };
        $scope.fetchGender = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            //console.log(JSON.stringify($scope.targetingCriteria, null, 2));
            angular.forEach($scope.targetingCriteria, function (value, key) {
                var JsonObj = $scope.targetingCriteria[key];
                var array = [];
                for (var i in JsonObj) {
                    if (JsonObj.hasOwnProperty(i)) {
                        array[+i] = JsonObj[i];
                        var lineItemObj = array[+i];
                        console.log(JSON.stringify(lineItemObj, null, 2));
                        $scope.targetType = lineItemObj.twTargetingCriteriaDetails.targeting_type;
                        $scope.targetStatus = lineItemObj.twTargetingCriteriaStatus;
                        if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "GENDER") {
                            $scope.genderValue = lineItemObj.twTargetingCriteriaDetails.name;
                            $scope.twitterReplicatorData.push({"gender": lineItemObj.twTargetingCriteriaDetails});
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "LOCATION") {
                            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&targetingCriteria=locations" + "&q=" + lineItemObj.twTargetingCriteriaDetails.name.split(' ')[0];
                            twitterGetPost.gettargetingcriteria(queryStr, data).then(function (locres) {
                                var results = $filter('filter')(locres.data.targetingCriteria, {name: lineItemObj.twTargetingCriteriaDetails.name}, true);
                                $scope.getBehaviourChildDetails(results[0].country_code);
                            });
                            $scope.locationArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            $scope.twitterReplicatorData.push({"locations": lineItemObj.twTargetingCriteriaDetails});
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "LANGUAGE") {
                            $scope.languageArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            $scope.twitterReplicatorData.push({"language": lineItemObj.twTargetingCriteriaDetails});
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "INTEREST") {
                            $scope.interestArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            $scope.twitterReplicatorData.push({"interests": lineItemObj.twTargetingCriteriaDetails});

                            /*$scope.age = "AGE_13_TO_24";							
                             if ($scope.age.indexOf('OVER') > 0) {
                             $scope.age = $scope.age.substring($scope.age.length - 2, $scope.age.length);
                             $scope.twitterReplicatorData.push({"age":$scope.age});
                             } else {
                             $scope.ageFrom = $scope.age.substring($scope.age.indexOf('_') + 1, $scope.age.indexOf('_') + 3);
                             $scope.twitterReplicatorData.push({"age_min":$scope.ageFrom});
                             $scope.ageTo = $scope.age.substring($scope.age.length - 2, $scope.age.length);
                             $scope.twitterReplicatorData.push({"age_max":$scope.ageTo});
                             }*/

                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "EVENT") {
                            //$scope.eventsArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            var m_Obj = {"id": lineItemObj.twTargetingCriteriaDetails.targeting_value, "name": lineItemObj.twTargetingCriteriaDetails.name};
                            $scope.eventsArray.push(m_Obj);
                            //console.log($scope.eventsArray);
                            var data = {
                                'userId': $window.localStorage.getItem("userId"),
                                'accessToken': $window.localStorage.getItem("accessToken")
                            };
                            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=events';
                            twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                                $scope.DefaultEventsArray = response.data.targetingCriteria;
                                //console.log($scope.DefaultEventsArray);													
                                var results = $filter('filter')($scope.DefaultEventsArray, {id: $scope.eventsArray[0].id}, true);
                                var m_Obj = {"id": results[0].id, "name": results[0].name};
                                $scope.eventsArray = [];
                                $scope.eventsArray.push(m_Obj);
                                $scope.twitterReplicatorData.push({"events": m_Obj});
                            });


                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "BEHAVIOR") {
                            //$scope.behaviorsArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            var m_Obj = {"id": lineItemObj.twTargetingCriteriaDetails.targeting_value, "name": lineItemObj.twTargetingCriteriaDetails.name};
                            $scope.behaviorsArray.push(m_Obj);
                            $scope.twitterReplicatorData.push({"behaviours": lineItemObj.m_Obj});
                            //$scope.DTBehaviourArray.push(lineItemObj.twTargetingCriteriaDetails.targeting_value);
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "NEGATIVE_BEHAVIOR") {
                            //$scope.limitbehaviorsArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                            var m_Obj = {"id": lineItemObj.twTargetingCriteriaDetails.targeting_value, "name": lineItemObj.twTargetingCriteriaDetails.name};
                            $scope.limitbehaviorsArray.push(m_Obj);
                            $scope.twitterReplicatorData.push({"limit_behaviours": lineItemObj.m_Obj});
                            //$scope.DTlimitBehaviourArray.push(lineItemObj.twTargetingCriteriaDetails.targeting_value);
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "TV_SHOW") {
                            $scope.tvTargetArray.push(lineItemObj.twTargetingCriteriaDetails.name);
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "AGE") {
                            $scope.age = lineItemObj.twTargetingCriteriaDetails.name;

                            if ($scope.age.indexOf('OVER') > 0) {
                                $scope.age = $scope.age.substring($scope.age.length - 2, $scope.age.length);
                                $scope.twitterReplicatorData.push({"age": $scope.age});
                            } else {
                                $scope.ageFrom = $scope.age.substring($scope.age.indexOf('_') + 1, $scope.age.indexOf('_') + 3);
                                $scope.twitterReplicatorData.push({"age_min": $scope.ageFrom});
                                $scope.ageTo = $scope.age.substring($scope.age.length - 2, $scope.age.length);
                                $scope.twitterReplicatorData.push({"age_max": $scope.ageTo});
                            }
                        } else if ($scope.targetStatus == 'ACTIVE' && ($scope.targetType == "DEVICE" || $scope.targetType == "PLATFORM")) {
                            $scope.targetDevices.push(lineItemObj.twTargetingCriteriaDetails.name);
                            $scope.twitterReplicatorData.push({"device_platforms": lineItemObj.twTargetingCriteriaDetails});
                        } else if ($scope.targetStatus == 'ACTIVE' && $scope.targetType == "NETWORK_OPERATOR") {
                            $scope.targetCarriers.push(lineItemObj.twTargetingCriteriaDetails.name);
                        }
                        $window.localStorage.setItem("twitterReplicatorData", JSON.stringify($scope.twitterReplicatorData));
                    }
                }
            });

        }
        //alert('h')
        $scope.fetchMedia = function () {
            var promises = [];
            //if ($scope.campaignState != "create")
            //{
            $scope.promotedtweetID = [];
            $scope.deleteTweetId = [];
            $scope.deleteTweetIdLength = 0;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&lineItemId=" + $window.localStorage.getItem("lineItemid");

            twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                // console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.promotedArray = [];
                    $scope.promoteFetch = response.data.promotedTweets;
                    // $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    console.log(JSON.stringify(response.data, null, 2));

                    angular.forEach($scope.promoteFetch, function (value, key) {
                        var JsonObj = $scope.promoteFetch[key]
                        console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweetsFetch = array[+i];
                                console.log(JSON.stringify($scope.iteratedtweetsFetch, null, 2));
                                //$scope.deleteTweetId = $scope.iteratedtweetsFetch.promotedTweetId;
                                angular.forEach($scope.iteratedtweetsFetch, function (value, key) {

                                    $scope.promotedTweetStatus = value.promotedTweetStatus;
                                    if ($scope.promotedTweetStatus != "DELETED") {
                                        //$scope.promotedtweetID.push($scope.iteratedtweetsFetch.promotedTweetDetails.tweet_id);
                                        //$scope.deleteTweetId.push($scope.iteratedtweetsFetch.promotedTweetId);
                                        //console.log($scope.promotedTweetStatus);
                                        //console.log(key);			

                                        $scope.promotedtweetID.push(value.promotedTweetDetails.tweet_id);
                                    }
                                })
                                $scope.promotedTweetStatus = $scope.iteratedtweetsFetch.promotedTweetStatus;
                                if ($scope.promotedTweetStatus != "DELETED") {
                                    //$scope.promotedtweetID.push($scope.iteratedtweetsFetch.promotedTweetDetails.tweet_id);
                                    //$scope.deleteTweetId.push($scope.iteratedtweetsFetch.promotedTweetId);
                                    //console.log($scope.promotedTweetStatus);
                                    //console.log(key);			
                                }

                            }
                            console.log($scope.promotedtweetID);
                            console.log($scope.deleteTweetId);

                            //$window.localStorage.setItem("multipleTweetId", $scope.promotedtweetID);
                            //$scope.setTweetCheckforEdit();
                            $window.localStorage.setItem("deleteTweetId", $scope.promotedtweetID);
                        }
                        $scope.promotedtweetIDLength = $scope.promotedtweetID.length;
                        console.log($scope.promotedtweetID.length);
                        //console.log($scope.tweetedArray);
                        // $scope.setTweetCheck($scope.tweetedArray);
                    });
                    $scope.deleteTweetIdLength = $scope.deleteTweetId.length;
                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")

                    };
                    for (var i = 0; i < $scope.promotedtweetID.length; i++) {
                        var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "id=" + $scope.promotedtweetID[i];
                        promises.push(twitterGetPost.gettweetbyid(queryStr, data).then(function (response) {
                            if (response.data.appStatus == '0') {
                                $scope.mediaResponse = response.data.tweetDetails;
                                console.log($scope.mediaResponse);

                                angular.forEach($scope.mediaResponse, function (value, key) {
                                    var JsonObj = $scope.mediaResponse[key];
                                    if (JsonObj.extended_entities != undefined) {
                                        $scope.extended_entities = JsonObj.extended_entities;
                                        console.log($scope.extended_entities);
                                        var array = [];
                                        for (var i in $scope.extended_entities) {
                                            if ($scope.extended_entities.hasOwnProperty(i)) {
                                                array[+i] = $scope.extended_entities;
                                                //console.log(array[+i]);
                                                $scope.iteratedtweets = array[+i];

                                                console.log($scope.iteratedtweets);
                                                if ($scope.iteratedtweets.hasOwnProperty('media'))
                                                    $scope.imageSources.push($scope.iteratedtweets.media[0].media_url);
                                                console.log($scope.imageSources);
                                                //$scope.thumbnailArray.push(array[+i].tweet_id);

                                            }

                                        }
                                    } else {
                                        $scope.entities = JsonObj.entities;
                                        console.log($scope.entities);
                                        //console.log(array[+i]);
                                        $scope.iteratedtweetsCard = $scope.entities;

                                        console.log($scope.iteratedtweetsCard);
                                        $scope.urlSources.push($scope.iteratedtweetsCard.urls[0].url);
                                        console.log($scope.urlSources);

                                    }
                                })
                            }
                        }));
                    }

                }

            });
            $rootScope.progressLoader = "none";
			$scope.setLine();
        }
        //$scope.fetchMedia();

        $scope.fetchDevices = function () {
            angular.forEach($scope.targeting_criteria_devices, function (value, key) {
                $scope.devices.push($scope.targeting_criteria_devices[key].name);
            })

        }
        $scope.fetchMobileNewsFeed = function () {
            angular.forEach($scope.targeting_criteria_mobileNewsFeed, function (value, key) {
                $scope.mobilenewfeed.push($scope.targeting_criteria_mobileNewsFeed[key].name);
            })

        }
        $scope.fetchDetailedTargeting = function () {
            angular.forEach($scope.targeting_criteria_interests, function (value, key) {
                $scope.targetingDisplayArray.push($scope.targeting_criteria_interests[key].name);
            })

        }
        $scope.fetchTargetLanguage = function () {
            angular.forEach($scope.targeting_criteria_language, function (value, key) {
                $scope.campaignAudienceLanguageArr.push($scope.targeting_criteria_language[key].name);
            })
        }
        $scope.fetchTargetLocation = function () {
            angular.forEach($scope.targeting_criteria_location, function (value, key) {
                $scope.campaignAudienceLocationsArr.push($scope.targeting_criteria_location[key].name);
            })
        }
        $scope.fetchLineItems = function () {
            angular.forEach($scope.lineItems, function (value, key) {
                var JsonObj = $scope.lineItems[key];
                var array = [];
                for (var i in JsonObj) {
                    if (JsonObj.hasOwnProperty(i)) {
                        array[+i] = JsonObj[i];
                        var lineItemObj = array[+i];
                        $scope.objectiveValue = lineItemObj.twLineItemDetails.objective;
                        $scope.currency = lineItemObj.twLineItemDetails.currency;
                        $scope.checkCurrencyCode($scope.currency);
                    }
                }
            });
        }
        $scope.fetchCampaign = function () {
            angular.forEach($scope.campaign, function (value, key) {
                var JsonObj = $scope.campaign[key];
                var array = [];
                for (var i in JsonObj) {
                    if (JsonObj.hasOwnProperty(i)) {
                        array[+i] = JsonObj[i];
                        var campaignObj = array[+i];
                        $scope.campaignName = campaignObj.twCampaignDetails.name;
                        $scope.scheduleStartDate = campaignObj.twCampaignDetails.start_time;
                        $scope.scheduleEndDate = campaignObj.twCampaignDetails.end_time;
                        $scope.budget = campaignObj.twCampaignDetails.daily_budget_amount_local_micro;
                        $scope.campaignStatus = campaignObj.twCampaignStatus;
                    }
                }
            });
        }


        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }

        $scope.getBehaviourChildDetails = function (tvbehaviourMarket) {
            var promises = [];
//            $rootScope.progressLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behaviors&countryCode=' + tvbehaviourMarket;
            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
//                $rootScope.progressLoader = "none";
                $scope.DefaultBehaviourArray = response.data.targetingCriteria;
            }));

            $q.all(promises).finally(function () {
                $scope.newbehaviorsArray = [];
                for (var i = 0; i < $scope.behaviorsArray.length; i++) {
                    var results = $filter('filter')($scope.DefaultBehaviourArray, {id: $scope.behaviorsArray[i].id}, true);
                    var m_Obj = {"id": results[0].id, "name": results[0].name};
                    $scope.newbehaviorsArray.push(m_Obj);
                }
                $scope.newlimitbehaviorsArray = [];
                for (var i = 0; i < $scope.limitbehaviorsArray.length; i++) {
                    var results = $filter('filter')($scope.DefaultBehaviourArray, {id: $scope.limitbehaviorsArray[i].id}, true);
                    var m_Obj = {"id": results[0].id, "name": results[0].name};
                    $scope.newlimitbehaviorsArray.push(m_Obj);
                }
//                $rootScope.progressLoader = "none";
            });

        };

        $scope.init();

        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */

        $scope.getCampaign = function () {
            var promises = [];
            //$rootScope.progressLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "campaignIds=" + $window.localStorage.getItem("twCampaignId");
            promises.push(twitterGetPost.getcampaignforaccount(queryStr, data).then(function (response) {
                $scope.getCampaignFlag;
                if (response.data.appStatus == 0) {
                    $scope.getCampaignFlag = "0";
//                    $rootScope.progressLoader = "none";
                    $scope.getCampaignDetailsResponse = response;
                    $scope.saveCampaign($scope.getCampaignDetailsResponse.data.campaign);
                }
                else {
                    $scope.getCampaignFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            /*$q.all(promises).finally(function () {
                if ($scope.getCampaignFlag == "0") {
                    $scope.saveCampaign($scope.getCampaignDetailsResponse.data.campaign);
                }
            });*/

        }
        $scope.saveCampaign = function (getCampaignDetailsResponse) {
            var promises = [];
            $rootScope.freezeFlag = false;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'parentCampaignId': $window.localStorage.getItem("parentCampaignId"),
                'campaignId': $window.localStorage.getItem("twCampaignId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'campaignDetails': getCampaignDetailsResponse[0][$window.localStorage.getItem("twCampaignId")]
            };
            promises.push(twitterGetPost.savecampaign("", data).then(function (response) {
                $scope.saveCampaignFlag;
                if (response.data.appStatus == 0) {
                    $scope.saveCampaignFlag = "0";
//                    $rootScope.progressLoader = "none";
                    $scope.saveCampaignDetailsResponse = response;
                    $scope.updatelineitems();
                }
                else {
                    $scope.saveCampaignFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
           /* $q.all(promises).finally(function () {
                if ($scope.saveCampaignFlag == "0") {
                    $scope.updatelineitems();
                }
            });*/
        }

        $scope.getlineitems = function () {
            var promises = [];
//            $rootScope.progressLoader = "block";
            $rootScope.freezeFlag = false;
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "lineItemIds=" + $window.localStorage.getItem("lineItemid");
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            promises.push(twitterGetPost.getlineitems(queryStr, data).then(function (response) {
                $scope.getlineitemsFlag;
                if (response.data.appStatus == 0) {
                    $scope.getlineitemsFlag = "0";
//                    $rootScope.progressLoader = "none";
                    $scope.getlineitemsResponse = response;
                    $scope.savelineitem($scope.getlineitemsResponse);
                }
                else {
                    $scope.getlineitemsFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            /*$q.all(promises).finally(function () {
                if ($scope.getlineitemsFlag == "0") {
                    $scope.savelineitem($scope.getlineitemsResponse);
                }
            });*/
        }

        $scope.savelineitem = function (getlineitemsResponse) {
            var promises = [];
//            $rootScope.progressLoader = "block";
            $rootScope.freezeFlag = false;
            var data = {};
            angular.forEach(getlineitemsResponse.data.lineItems[0], function (value, key) {
                data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    'lineitemId': $window.localStorage.getItem("lineItemid"),
                    'lineitemDetails': value
                };
            });
            promises.push(twitterGetPost.savelineitem("", data).then(function (response) {
                $scope.savelineitemFlag;
                if (response.data.appStatus == 0) {
                    $scope.savelineitemFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.savelineitemResponse = response;
                    $scope.popupTitle = "Success";
                    $scope.popupMessage = response.data.successMessage;
                    $scope.successPopup();
                }
                else {
                    $scope.savelineitemFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.savelineitemFlag == "0") {
                    $scope.popupTitle = "Success";
                    $scope.popupMessage = response.data.successMessage;
                    $scope.successPopup();
                }
            });
        }

        vm.campSummaryAction = function (data1) {
           $rootScope.progressLoader = "block";           
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("twUserNetworkMapId"),
                "adAccountId": $window.localStorage.getItem("twNetworkAdAccountId"),
                "campaignId": $window.localStorage.getItem("twCampaignId"),
                "endTime" : $scope.endTimeResponse,
                "entityStatus": "ACTIVE"
            };
            twitterGetPost.updatecampaign("", data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.getCampaign();
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.data.errorMessage;
                    $scope.errorPopup();
                }
            });

        };

        $scope.updatelineitems = function (data) {
            var datalineItem = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("twUserNetworkMapId"),
                "adAccountId": $window.localStorage.getItem("twNetworkAdAccountId"),
                "lineItemId": $window.localStorage.getItem("lineItemid"),
                "entityStatus": "PAUSED"
            };
            twitterGetPost.updatelineitems("", datalineItem).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.getlineitems();
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.data.errorMessage;
                    $scope.errorPopup();
                }
            });
        }


        var modalSuccessPop = $(".success-popup");// Get the modal Success req
        var modalReplicatorPop = $(".replicator-popup"); //Get the replicator nodal
        var modalNetworkPop = $(".network-popup"); // Get the network nodal

        $scope.successPopup = function () {
            $rootScope.progressLoader = "none";
            modalSuccessPop.show();
            angular.element($('body').css("overflow-y", "hidden"));
        }
        $scope.closeSuccessPopup = function () {
            modalSuccessPop.hide();
            angular.element($('body').css("overflow-y", "scroll"));
            $state.go('app.parentcampaign');
        }
        var modalErrorPop = $(".error-popup");// Get the modal error req
        $scope.errorPopup = function () {
            $rootScope.progressLoader = "none";
            modalErrorPop.show();
            angular.element($('body').css("overflow-y", "hidden"));
        }
        $scope.closeErrorPopup = function () {
            modalErrorPop.hide();
            angular.element($('body').css("overflow-y", "scroll"));
        }
        $scope.openConfirmPopup = function () {
            var modalSuccessPop = $(".replicator-popup");
            modalSuccessPop.show();
        }
        $scope.openNetworkPopup = function () {
            modalReplicatorPop.hide();
            modalNetworkPop.show();

            // var modalSuccessPop = $(".network-popup");
            // modalSuccessPop.show();
        }
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
            var modalApproveerr = $(".error_popup_replicator");
            modalApproveerr.hide();
        }
        $scope.openReplicatorPopup1 = function() {
		if($rootScope.replicationCycle == true){
		    $state.go('app.parentcampaign');
		}
                else{
                    $scope.openReplicatorPopup();
                    }
		}
        $scope.openReplicatorPopup = function () {
            modalSuccessPop.hide();
            angular.element($('body').css("overflow-y", "scroll"));
            angular.element('.replicator-pop-up-ok').css('opacity', 0.8);
            angular.element('.replicator-pop-up-ok').css('pointer-events', 'none');
            $rootScope.campaignSteps[4] = true;
            $rootScope.campaignGoLive = false;
            console.log($rootScope.campaignGoLive);
            modalReplicatorPop.show();
        }
        $scope.checkReplicator = function () {
            $window.localStorage.setItem("campaignState", "replication");
            // var cNetwork = $rootScope.currentCampaignNetwork;  
            // var cNetwork = $rootScope.currentNetwork;			
            var cNetwork = "Twitter";
            $rootScope.campaignData = JSON.parse($window.localStorage.getItem("twitterReplicatorData"));
            $rootScope.replicatorNetwork = $scope.netName;
            $rootScope.campaignObjective = parser.getParsedObject($rootScope.campaignData, 'objective');
//            parser.getSetParser(cNetwork, $rootScope.campaignObjective, $rootScope.replicatorNetwork);
            if (cNetwork == "Twitter" && $rootScope.replicatorNetwork == "Facebook") {
                var campaignId = $window.localStorage.getItem("twCampaignId");
                var lineItemid = $window.localStorage.getItem("lineItemid");
                parser.getSetParser(cNetwork, $rootScope.campaignObjective, $rootScope.replicatorNetwork);
                var twData = parser.twitterParser(campaignId, lineItemid);
                var modalSuccessPop = $(".replicator-popup");
                modalSuccessPop.hide();
                var modalSuccessPop = $(".network-popup");
                modalSuccessPop.hide();
                $rootScope.campaignSteps = [false, false, false, false, false];
            } else if (cNetwork == "Twitter" && $rootScope.replicatorNetwork == "Twitter") {
                console.log('twitter to twitter replication');
                var campaignId = $window.localStorage.getItem("twCampaignId");
                var lineItemid = $window.localStorage.getItem("lineItemid");
                //parser.getSetParser(cNetwork, $rootScope.campaignObjective, $rootScope.replicatorNetwork);
                var twData = parser.facebookParser(cNetwork, $rootScope.replicatorNetwork);
                var modalSuccessPop = $(".replicator-popup");
                modalSuccessPop.hide();
                var modalSuccessPop = $(".network-popup");
                modalSuccessPop.hide();
                $rootScope.campaignSteps = [false, false, false, false, false];
            }
            else {
                var modalSuccessPop = $(".network-popup");
                modalSuccessPop.hide();
                var modalerrPop = $(".error_popup_replicator");
                modalerrPop.show();
            }
            $scope.networkNames = "";
        }
        $scope.selectNetwork = function (_name) {
            angular.element('.replicator-pop-up-ok').css('opacity', 1);
            angular.element('.replicator-pop-up-ok').css('pointer-events', 'auto');
            $scope.netName = _name;
        }
        $scope.menuItems = [{
                title: "All",
                img: "images/accountDashboard/all.svg",
                icon: "glyphicon glyphicon-search",
                state: false

            },
            {
                title: "Facebook",
                img: "images/accountDashboard/facebook.svg",
                icon: "\uf09a",
                state: false

            },
            {
                title: "Twitter",
                img: "images/accountDashboard/twitter.svg",
                icon: "\uf099",
                state: false

            },
            {
                title: "LinkedIn",
                img: "images/accountDashboard/linked_in.svg",
                icon: "\uf0e1",
                state: true


            },
            {
                title: "Google Adsense",
                img: "images/accountDashboard/google_adsense.svg",
                icon: "\uf1a0",
                state: true

            },
            {
                title: "Instagram",
                img: "images/accountDashboard/instagram.svg",
                icon: "\uf16d",
                state: true

            },
            {
                title: "Cognizant AdServer",
                img: "images/accountDashboard/cts-small.png",
                icon: "\uf0d5",
                state: true

            },
            {
                title: "Bing",
                img: "images/accountDashboard/bing.svg",
                icon: "\uf0e2",
                state: true

            }
        ];



    }]);

