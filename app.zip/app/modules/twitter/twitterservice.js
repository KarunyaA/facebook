dashboard.factory('twitterGetPost', ['$http', '$q','$timeout', 'catalyst', 'httpApi', '$rootScope','appSettings', function($http, $q, $timeout, catalyst, httpApi, $rootScope, appSettings) {
    var obj = {};
    var baseUrl = catalyst.serviceUrl1;
	var baseUrl2 = catalyst.serviceUrl2;
	var apiTPBase = appSettings.apiTPBase;
    var apiBase = appSettings.apiBase;
	var apiTwitterBase = appSettings.apiTwitterBase;
	
    obj.isLocal = false;
    var _config = {};
    _config.cache = 'false';
    _config.async = 'false';
	 
	 //----------------------------------------------get API----------------------------------------------------------------	 
	obj.readadfundinginstruments = function(_queryStr, _parameters){
	    var url = apiTwitterBase+"/readadfundinginstruments"+_queryStr;
        return httpApi.get(url, _parameters);
    }

	obj.readadaccounts = function(_queryStr, _parameters){
		var url = apiTwitterBase+"/readadaccounts"+_queryStr;
        return httpApi.get(url, _parameters);
    }
	
	obj.getcampaignforaccount = function(_queryStr, _parameters){
		var url = apiTwitterBase+"/getcampaignforaccount"+_queryStr;
        return httpApi.get(url, _parameters);
    }
		
	obj.readcampaign = function(_queryStr, _parameters){
		var url = apiTwitterBase+"/readcampaign"+_queryStr;
        return httpApi.get(url, _parameters);
    }
	obj.gettargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/gettargetingcriteria"+_queryStr; 
		return httpApi.get(url, _parameters);
	}
	obj.getaccounttargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getaccounttargetingcriteria"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.readtargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/readtargetingcriteria"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.getlineitems = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getlineitems"+_queryStr;
		return httpApi.get(url, _parameters);
	}	
	obj.readlineitems = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/readlineitems"+_queryStr;    
		return httpApi.get(url, _parameters);
	}		
	obj.getlineitemsplacements = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getlineitemsplacements"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.getadaccounts = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getadaccounts"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.gettweet = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/gettweet"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.getpromotedtweetsforaccount = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getpromotedtweetsforaccount"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.previewtweetbyid = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/previewtweetbyid"+_queryStr;    
		return httpApi.get(url, _parameters);
	}	
	obj.getaccountcardwebsite = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getaccountcardwebsite"+_queryStr;    
		return httpApi.get(url, _parameters);
	}

	obj.getmediacreatives = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getmediacreatives"+_queryStr;   
		return httpApi.get(url, _parameters);
	}	
		
	obj.getstats = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getstats"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.readtargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/readtargetingcriteria"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.gettweet = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/gettweet"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
	
	obj.readpromotedtweets = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/readpromotedtweets"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
	
        obj.getadvideos = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getadvideos"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
        
        obj.gettweetbyid = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/gettweetbyid"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
        
        obj.getimageappdownload = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getimageappdownload"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
        obj.getvideoappdownloadcardsforaccount = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/getvideoappdownloadcardsforaccount"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
		
	//----------------------------------------------post API----------------------------------------------------------------
	obj.createcampaign = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createcampaign";    
		return httpApi.post(url, _parameters);
	}
	obj.savecampaign = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/savecampaign";    
		return httpApi.post(url, _parameters);
	}	
	obj.createlineitems = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createlineitems";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.savelineitem = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/savelineitem";    
		return httpApi.post(url, _parameters);
	}
	
	obj.updatelineitems = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/updatelineitems";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.updatecampaign = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/updatecampaign";    
		return httpApi.post(url, _parameters);
	}	
	obj.createaccounttargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createaccounttargetingcriteria";    
		return httpApi.post(url, _parameters);
	}	
	obj.puttargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/puttargetingcriteria";    
		return httpApi.post(url, _parameters);
	}
	obj.savetargetingcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/savetargetingcriteria";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.mediaupload = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/mediaupload";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.createtweet = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createtweet";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.savepromotedtweets = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/savepromotedtweets";    
		return httpApi.post(url, _parameters);
	}	
	obj.createmediacreatives = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createmediacreatives";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.createaccountcardwebsite = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createaccountcardwebsite";    
		return httpApi.post(url, _parameters);
	}
	
	obj.createaccountmedia = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createaccountmedia";    
		return httpApi.post(url, _parameters);
	}		
	
	obj.createpromotedaccounts = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createpromotedaccounts";    
		return httpApi.post(url, _parameters);
	}		
	obj.createpromotedtweetsmap = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/createpromotedtweetsmap";    
		return httpApi.post(url, _parameters);
	}        
	obj.createimageappdownload = function(_queryStr, _parameters){
            var url = apiTwitterBase + "/createimageappdownload"+_queryStr;;    
		return httpApi.post(url, _parameters);
        }
        obj.createvideoappdownloadcard = function(_queryStr, _parameters){
            var url = apiTwitterBase + "/createvideoappdownload"+_queryStr;;    
		return httpApi.post(url, _parameters);
        }
        //----------------------------------------------Delete API----------------------------------------------------------------
        obj.deletetargetcriteria = function(_queryStr, _parameters){
		var url = apiTwitterBase + "/deletetargetingcriteria"+_queryStr;;    
		return httpApi.delete(url, _parameters);
	}
    return obj;
}]); 
