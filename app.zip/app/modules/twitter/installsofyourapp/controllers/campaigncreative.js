dashboard.controller("installsofyourappCampaigncreativeController", ['$rootScope', '$scope', '$http', '$state', '$location', 'dashboardService', 'Flash', '$window', 'appSettings', '$sce', '$timeout', 'twitterGetPost', '$q', 'globalData',
    function ($rootScope, $scope, $http, $state, $location, dashboardService, Flash, $window, appSettings, $sce, $timeout, twitterGetPost, $q, globalData) {
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        var apiTPBase = appSettings.apiTPBase;
        $scope.networkAdAccountId = appSettings.networkAdAccountId;       
        $scope.mainLoader = "none";
        $scope.fourthActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.mediabutton = true;
        $scope.values = [];
        $scope.mediaUpdate = false;
        $scope.cardUpdate = false;
        $scope.isHeadline = true;
        $scope.rightNavCtrlbtn = 0;
        $scope.ctrlLimt = 0;
        $scope.isLeftBtnEnable = false;
        $scope.isrightBtnEnable = true;
        $scope.createCard = true;
        $scope.selectCard = false;
        $scope.uploading = true;
        $scope.previewing = false;
        $scope.uploadingcard = true;
        $scope.previewingcard = false;
        $scope.mediaandcard = false;
        $scope.mediaonly = true;
        $scope.carouselFlow = 0;
        $scope.checkVal = [];
        $scope.mediaarrow = true;
        $scope.multipleTweetIdedit = [];
        $scope.iosexpand = false;
        $scope.androidexpand = false;
        $scope.desktopexpand = false;
        $scope.mediapresent = true;
        $scope.lengthmultipleTweetId = 1;
        $scope.chkImage = 1;
        $scope.card = {};
        $scope.tweetedArray1 = [];
        $scope.tweeterIDArray = [];
        $scope.upload = true;
        $scope.selectcard = false;
        var lengthkey = 0;
        $scope.tweetsArray = [];
        $scope.tweetsArray1 = [];
        $scope.promotedtweetID1 = [];
        angular.element('.creativePreviewBlock').css('pointer-events', 'none');
        var tweetObj = {};
        $scope.tweetsChecked = [];
        var apiTwitterBase = appSettings.apiTwitterBase;        
        $scope.deleteTweetId = [];
		
		$scope.combinedStatsimp = [];
		$scope.combinedStatseng = [];
		$scope.combinedStatsengrate = [];
		
        $scope.card.ctavalue = "";
        $scope.selectedType = 'Image App Card';
        $scope.previewTweet = function (val) {
            window.open(val, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
        }
        $scope.closePopupDetails = function () {
            $scope.editAdsetErrorMsg = "none";
        }

        $scope.fetchMediaforEdit = function () {
            $scope.mainLoader = "block";
            var promises = [];
            $scope.promotedtweetID = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");

            promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.mainLoader = "none";
                    $scope.promoteFetch = response.data.promotedTweets;
                    angular.forEach($scope.promoteFetch, function (value, key) {
                        var JsonObj = $scope.promoteFetch[key]
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweetsFetch = array[+i];
                                angular.forEach($scope.iteratedtweetsFetch, function (value, key) {
                                    $scope.promotedTweetStatus = value.promotedTweetStatus;
                                    if ($scope.promotedTweetStatus != "DELETED" && $scope.promotedtweetID.includes(value.promotedTweetDetails.tweet_id) == false) {
                                        $scope.promotedtweetID.push(value.promotedTweetDetails.tweet_id);
                                    }
                                })
                            }
                        }
                    });

                } else {
                    $scope.mainLoader = "none";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }

            }));
            $q.all(promises).finally(
                    function () {
                        console.log('read promoted tweets for account done');
                       // $scope.readtweetbyID();
						$scope.getCombinedStatsvalue();
					});
        }


		$scope.getCombinedStatsvalue = function(){
			
			var promises = [];
				var data = {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			};
								//Stats service
								var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.promotedtweetID + "&entity=ORGANIC_TWEET&startTime=" +$scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
								
								 promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
								//$scope.mainLoader = "block";
								
								if (response.data.appStatus == '0') {								
									$scope.statsData = response.data.stats;
									var JsonObj1 = $scope.statsData;
									
									angular.forEach(JsonObj1,function(value,key){
									var array1 = [];
									
									var impValue = globalData.getKeyValues(JsonObj1[key], 'impressions');
									
									
									if(typeof(impValue) == 'number'){
										$scope.combinedStatsimp[key] = impValue;
									} else {
										$scope.combinedStatsimp[key] = impValue[0];
									}
									
									var impValue1 = globalData.getKeyValues(JsonObj1[key], 'engagements');
									//tweetObj.engagements = impValue1;	
									if(typeof(impValue1) == 'number'){
										$scope.combinedStatseng[key] = impValue1;
									} else {
										$scope.combinedStatseng[key] = impValue1[0];
									}

									if($scope.combinedStatsimp[key] == 0 && $scope.combinedStatseng[key] == 0){
									$scope.combinedStatsengrate[key] = "0.0%";
									}
									else if($scope.combinedStatsimp[key] > 0 && $scope.combinedStatseng[key] == 0){
									$scope.combinedStatsengrate[key] = "0.0%";
									}
									else if($scope.combinedStatsimp[key] == $scope.combinedStatseng[key]){
										$scope.engratecheck = $scope.combinedStatseng[key] / $scope.combinedStatsimp[key];
										$scope.combinedStatsengrate[key] = $scope.engratecheck + '%';
									}
									else if($scope.combinedStatsimp[key] > 0 && $scope.combinedStatseng[key] > 0){
										$scope.engratecheck = $scope.combinedStatseng[key] / $scope.combinedStatsimp[key];
										
										if($scope.engratecheck < 1){
										$scope.combinedStatsengrate[key] = "0.0%";
										}
										else {
										
											$scope.combinedStatsengrate[key] = $scope.engratecheck + '%';
											
										}
									}
									   
										});
									}
									
									 else {										
										$scope.combinedStatsimp = 0;
                                        $scope.combinedStatseng = 0;
                                        $scope.combinedStatsengrate = 0;
										$scope.setLine();
										if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
											$window.localStorage.setItem("TokenExpired", true);
											$state.go('login');
										} else {
											$rootScope.progressLoader = "none"; 
											$scope.mainLoader="none";
											//$scope.editAdsetErrorMsg = 'block';						
											if (response.data.networkError != '' && response.data.networkError != undefined) {
												if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
														$scope.errorpopupHeading = 'Error';
														$scope.errorMsg = response.data.networkError.message;
												} else {
														$scope.errorpopupHeading = response.data.networkError.error_user_title;
														$scope.errorMsg = response.data.networkError.error_user_msg;
												}
											} else {
													$scope.errorpopupHeading = 'Error';
													$scope.errorMsg = response.data.errorMessage;
											}
										}
                                    }
									
                                }));
								
								
								$q.all(promises).finally(
                    function(){						
						console.log($scope.promotedtweetID);
						console.log($scope.combinedStatseng);
						console.log($scope.combinedStatsimp);
						console.log($scope.combinedStatsengrate);
						$scope.readtweetbyID();
						//$scope.getCombinedStatsvalue();
						
                    });
		}
		
		

        $scope.readtweetbyID = function () {
            tweetObj = {};
            $scope.mainLoader = "block";
            if (lengthkey <  $scope.promotedtweetID.length) {                
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "id=" + $scope.promotedtweetID[lengthkey];
                twitterGetPost.gettweetbyid(queryStr, data).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        $scope.mediaResponse = response.data.tweetDetails;
                        angular.forEach($scope.mediaResponse, function (value, key) {
                            var JsonObj = $scope.mediaResponse[key];
                            $scope.created_at = JsonObj.created_at.split(' ')[1] + ' ' + JsonObj.created_at.split(' ')[2];
                            var array = [];
                            $scope.extended_entities = JsonObj.extended_entities;
                            if (JsonObj.extended_entities != undefined) {
                                $scope.extended_entities = JsonObj.extended_entities;
                                for (var i in $scope.extended_entities) {
                                    if ($scope.extended_entities.hasOwnProperty(i)) {
                                        array[+i] = $scope.extended_entities;
                                        $scope.iteratedtweets = array[+i];
                                        tweetObj = {
                                            "profile_image": JsonObj.user.profile_image_url,
                                            "name": JsonObj.user.name,
                                            "screenName": JsonObj.user.screen_name,
                                            "created_at": $scope.created_at,
                                            "text": JsonObj.text,
                                            "media_url": $scope.iteratedtweets.media[0].media_url,
                                            "tweeterID": JsonObj.id_str,
											"impressions" : $scope.combinedStatsimp[lengthkey],
											"engagements": $scope.combinedStatseng[lengthkey],
											"engrate": $scope.combinedStatsengrate[lengthkey]

                                        }
                                    }

                                }
                                $scope.readstatsandpromoted();
                            } else {
                                
                               
                                    $scope.values = JsonObj.text.split(" ");
									console.log($scope.values)
                                    $scope.link = $scope.values[$scope.values.length - 1];
									console.log($scope.link)
                                    $scope.entitites = JsonObj.entities;
                                    tweetObj = {
                                        "profile_image": JsonObj.user.profile_image_url,
                                        "link": $scope.link,
                                        "text": JsonObj.text,
                                     //   "expandedUrl": $scope.entitites.urls[0].expanded_url,
                                        "name": JsonObj.user.description,
                                        "screenName": JsonObj.user.screen_name,
                                        "created_at": $scope.created_at,
                                        "tweeterID": JsonObj.id_str,
										"impressions" : $scope.combinedStatsimp[lengthkey],
										"engagements": $scope.combinedStatseng[lengthkey],
										"engrate": $scope.combinedStatsengrate[lengthkey]
                                    }
                               
                                $scope.readstatsandpromoted();
                            }

                        });

                    } else {
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $scope.mainLoader = "none";
                            $rootScope.progressLoader = "none";
                            if (response.data.networkError.code == '144') {
                                console.log('Error tweeet ID');
                                $scope.tweetsArray1.push(tweetObj);
                                lengthkey++;
                                $scope.readtweetbyID();
                            } else if (response.data.networkError != '' && response.data.networkError != undefined) {
                                if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.data.networkError.message;
                                } else {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }


                });
            } else {
                $scope.mainLoader = "none";
                $scope.tweetsArray = $scope.tweetsArray1;
                $scope.setLine();
				console.log($scope.tweetsArray);
                var a = 0;
                $timeout(function () {
                    angular.forEach($scope.tweetsArray, function (value, index) {

                        var h2 = $("#parenttd" + a).height();
                        var tableHeight = $("#tablever").height();
                        angular.element('.childtd' + a).css('height', h2);
                        a = a + 1;
                        angular.element('.vrtable1').css('height', tableHeight);
                        angular.element('.vrtable2').css('height', tableHeight);
                        angular.element('.vrtable3').css('height', tableHeight);
                    });
                }, 2000);                
                $scope.setLine();
                $scope.mainLoader = "none";
            }
        }


        $scope.readstatsandpromoted = function(){
			$scope.mainLoader = "block";
			var data = {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			};
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" +$scope.promotedtweetID[lengthkey];
                                //$scope.mainLoader = "block";
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {                                      
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        tweetObj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign"; 
										//$scope.getStats();   

									if($scope.campaignState == "edit"){
                                    if($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true){   
										$scope.checkVal[lengthkey] = true;
										$scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
										$scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
										$scope.checkTweet = $scope.promotedtweetID1.length; 
										
                                    }
                                    else{
                                    $scope.checkVal[lengthkey]=false;                                        
                                    }
                                    }
									
									   $scope.tweetsArray1.push(tweetObj);
										$scope.setTweetCheck($scope.promotedtweetID);                   
										lengthkey++;									
										$scope.readtweetbyID();
										
										
                                    }else{										
                                        tweetObj.promotedCount = "Promoted-only - " + "Currently Unpromoted";
										tweetObj.impressionspromoted = 0;
										tweetObj.engagementspromoted = 0;
										tweetObj.engratepromoted = "0.0%";
										//$scope.getStats();
										
										if($scope.campaignState == "edit"){
                                    if($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true){   
										$scope.checkVal[lengthkey] = true;
										$scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
										$scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
										$scope.checkTweet = $scope.promotedtweetID1.length; 
										
                                    }
                                    else{
                                    $scope.checkVal[lengthkey]=false;                                        
                                    }
                                    }
									
									   $scope.tweetsArray1.push(tweetObj);
										$scope.setTweetCheck($scope.promotedtweetID);                   
										lengthkey++;									
										$scope.readtweetbyID();
										
                                    }
                                })
								
		}

        $scope.getStats = function () {
            $scope.mainLoader = "block";
            var promises = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            //Stats service
            var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.promotedtweetID[lengthkey] + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";

            promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.mainLoader = "none";
                    $scope.statsData = response.data.stats;
                    var JsonObj1 = $scope.statsData;
                    var impValue = globalData.getKeyValues(JsonObj1, 'impressions');

                    if (typeof (impValue) == 'number') {
                        tweetObj.impressions = impValue;
                    } else {
                        tweetObj.impressions = impValue[0];
                    }

                    var impValue1 = globalData.getKeyValues(JsonObj1, 'engagements');
                    if (typeof (impValue1) == 'number') {
                        tweetObj.engagements = impValue1;
                    } else {
                        tweetObj.engagements = impValue1[0];
                    }

                    if (tweetObj.impressions == 0 && tweetObj.engagements == 0) {
                        tweetObj.engrate = "0.0%";
                    } else if (tweetObj.impressions > 0 && tweetObj.engagements == 0) {
                        tweetObj.engrate = "0.0%";
                    } else if (tweetObj.impressions == tweetObj.engagements) {
                        $scope.engratecheck = tweetObj.engagements / tweetObj.impressions;
                        tweetObj.engrate = $scope.engratecheck + '%';
                    } else if (tweetObj.impressions > 0 && tweetObj.engagements > 0) {
                        $scope.engratecheck = tweetObj.engagements / tweetObj.impressions;

                        if ($scope.engratecheck < 1) {
                            tweetObj.engrate = "0.0%";
                        } else {

                            tweetObj.engrate = $scope.engratecheck + '%';

                        }
                    }

                    if ($scope.campaignState == "edit") {
                        if ($scope.promotedtweetID1.includes($scope.promotedtweetID[lengthkey]) == true) { 
                            
                            $scope.checkVal[lengthkey] = true;
                            $scope.multipleTweetIdedit.push($scope.promotedtweetID[lengthkey]);
                            $scope.tweetsChecked.push($scope.promotedtweetID[lengthkey]);
                            $scope.checkTweet = $scope.promotedtweetID1.length;
                        } else {
                            $scope.checkVal[lengthkey] = false;
                        }
                    }
                    
                    $scope.getStatsForPromotedTweets();

                } else {
                    tweetObj.impressions = 0;
                    tweetObj.engagements = 0;
                    tweetObj.engrate = 0;
                    $scope.setLine();
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $scope.mainLoader = "none";
                        $rootScope.progressLoader = "none";						
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }

            }));
            
        }
        $scope.getStatsForPromotedTweets = function () {
            var promises = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            $scope.statIDsum = [];

            angular.forEach($scope.statID, function (value, key) {
                var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.statsDatapromote = response.data.stats;
                        var JsonObj3 = $scope.statsDatapromote;
                        var array3 = [];
                        for (var j in JsonObj3) {
                            if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                array3[+j] = JsonObj3[j];
                                $scope.statdata3 = array3[+j];

                                angular.forEach($scope.statdata3, function (value, key) {

                                    $scope.impressionsSum1 = value.id_data[0].metrics.engagements;
                                    $scope.impressionsSum.push($scope.impressionsSum1);

                                    if ($scope.impressionsSum1 != 0) {
                                        $scope.impressionsSum.push($scope.impressionsSum1[0]);

                                    }
                                    $scope.engagementsSum1 = value.id_data[0].metrics.engagements;
                                    $scope.engagementsSum.push($scope.engagementsSum1);
                                    if ($scope.engagementsSum1 != 0) {
                                        $scope.engagementsSum.push($scope.engagementsSum1[0]);
                                    }
                                    if ($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0) {
                                        $scope.engrateSum1 = 0;
                                        $scope.engrateSum.push($scope.engrateSum1);
                                    } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0) {
                                        $scope.engrateSum1 = 0;
                                        $scope.engrateSum.push($scope.engrateSum1);
                                    } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0) {
                                        $scope.engrateSum1 = $scope.impressionsSum1 / $scope.engagementsSum1;
                                        $scope.engrateSum.push($scope.engrateSum1);
                                    }

                                });


                            }
                        }
                    } else {
                        $scope.engagementsSum = 0;
                        $scope.impressionsSum = 0;
                        $scope.engrateSum = 0;
                    }

                }));
            })
            $scope.statIDsum1 = 0;
            angular.forEach($scope.impressionsSum, function (value, key) {
                $scope.statIDsum1 += $scope.impressionsSum[key];
            })
            tweetObj.impressionspromoted = $scope.statIDsum1;
            $scope.statIDsum2 = 0;
            angular.forEach($scope.engagementsSum, function (value, key) {
                $scope.statIDsum2 += $scope.engagementsSum[key];
            })
            tweetObj.engagementspromoted = $scope.statIDsum2;

            $scope.statIDsum3 = 0;
            angular.forEach($scope.engrateSum, function (value, key) {
                $scope.statIDsum3 += $scope.engrateSum[key];
            })
            tweetObj.engratepromoted = $scope.statIDsum3 + "%";
            
            $scope.tweetsArray1.push(tweetObj);
            $scope.setTweetCheck($scope.promotedtweetID);
            lengthkey++;
            $scope.readtweetbyID();

        }
        $scope.init = function () {
            $rootScope.twitterFormData = vm.getData;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            $scope.d = new Date();
            $scope.currentdate = $scope.d.getFullYear() + "-" + ('0' + ($scope.d.getMonth() + 1)).slice(-2) + "-" + ('0' + ($scope.d.getDate())).slice(-2);
            $scope.d.setDate($scope.d.getDate() - 7);
            $scope.curr_date = $scope.d.getDate();
            $scope.curr_month = $scope.d.getMonth() + 1;
            $scope.curr_year = $scope.d.getFullYear();
            $scope.weekdate = $scope.curr_year + "-" + ('0' + ($scope.curr_month)).slice(-2) + "-" +('0' + $scope.curr_date).slice(-2);
            

            $scope.campaignState = $window.localStorage.getItem("campaignState");
            $scope.fetchMediaforEdit();
            if ($scope.campaignState == "edit") {
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element($('#step1').css('background-color', 'rgb(149, 210, 177)'));
                angular.element($('#step2').css('background-color', 'rgb(149, 210, 177)'));
                $scope.mainLoader = "block";
               // $timeout(function () {
                $scope.readPromotedTweetsEdit();
            //},35000);
                angular.element('.naviButtons #right').css('pointer-events', 'auto');
                angular.element('.naviButtons #left').css('pointer-events', 'auto');
                angular.element('.creativePreviewBlock').css('pointer-events', ' auto');
            } else {
                $window.localStorage.setItem("multipleTweetId", "");

            }
            
        }

        //Get Promoted only Tweets
        $scope.getPromotedOnlyTweets = function () {
            var promises = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=none";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.tweetedArray = [];
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
                                $scope.tweeterIDArray.push($scope.iteratedtweets.id_str);
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                if ($scope.mediaurlcheck.hasOwnProperty('urls')) {
                                    if ($scope.mediaurlcheck.urls.length > 0) {
                                        $scope.expanded_url_length = $scope.mediaurlcheck.urls.length;
                                        $scope.expanded_url = $scope.mediaurlcheck.urls[0].expanded_url;
                                    }
                                } else {
                                    $scope.expanded_url = "";
                                }
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                $scope.values = $scope.iteratedtweets.text.split(" ");
                                $scope.link = $scope.values[$scope.values.length - 1];
                                $scope.impressions = 0;
                                $scope.engagements = 0;
                                $scope.engrate = 0;
                                $scope.impressionspromoted = 0;
                                $scope.engagementspromoted = 0;
                                $scope.engratepromoted = 0;
                                
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                } else {
                                    $scope.media_url = "";
                                }

                                if ($scope.campaignState == "edit") {
                                    if ($scope.promotedtweetID.includes($scope.tweeterID) == true) {
                                        $scope.checkVal[key] = true;
                                        $scope.checkTweet = $scope.promotedtweetID.length;
                                    }
                                }

                                var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
                                    "expanded_url": $scope.expanded_url,
                                    "IFrameURL": $scope.link,
                                    "impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
                                    "impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";

                                        //Stats service for promoted campaign
                                        $scope.promotedCampaign = response.data.promotedTweets;
                                        $scope.statID = [];
                                        angular.forEach($scope.promotedCampaign, function (value, key) {
                                            var JsonObj2 = $scope.promotedCampaign[key]
                                            var array2 = [];
                                            for (var i in JsonObj2) {
                                                if (JsonObj2.hasOwnProperty(i)) {
                                                    array2[+i] = JsonObj2[i];
                                                    $scope.statdata1 = array2[+i];
                                                    $scope.statID.push($scope.statdata1.promotedTweetId);
                                                }
                                            }
                                        })
                                        $scope.statIDsum = [];

                                        angular.forEach($scope.statID, function (value, key) {
                                            //Stats service
                                            var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                            promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {
                                                if (response.data.appStatus == '0') {
                                                    $scope.statsDatapromote = response.data.stats;
                                                    var JsonObj3 = $scope.statsDatapromote;
                                                    var array3 = [];
                                                    for (var j in JsonObj3) {
                                                        if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                                            array3[+j] = JsonObj3[j];
                                                            $scope.statdata3 = array3[+j];

                                                            angular.forEach($scope.statdata3, function (value, key) {

                                                                $scope.impressionsSum1 = value.id_data[0].metrics.engagements;
                                                                $scope.impressionsSum.push($scope.impressionsSum1);

                                                                if ($scope.impressionsSum1 != 0) {
                                                                    $scope.impressionsSum.push($scope.impressionsSum1[0]);

                                                                }
                                                                $scope.engagementsSum1 = value.id_data[0].metrics.engagements;
                                                                $scope.engagementsSum.push($scope.engagementsSum1);
                                                                if ($scope.engagementsSum1 != 0) {
                                                                    $scope.engagementsSum.push($scope.engagementsSum1[0]);
                                                                }
                                                                if ($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0) {
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0) {
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0) {
                                                                    $scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                }

                                                            });


                                                        }
                                                    }
                                                } else {
                                                    $scope.engagementsSum = 0;
                                                    $scope.impressionsSum = 0;
                                                    $scope.engrateSum = 0;
                                                }

                                            }));

                                        })
                                        $scope.statIDsum1 = 0;
                                        angular.forEach($scope.impressionsSum, function (value, key) {
                                            $scope.statIDsum1 += $scope.impressionsSum[key];
                                        })
                                        obj.impressionspromoted = $scope.statIDsum1;
                                        $scope.statIDsum2 = 0;
                                        angular.forEach($scope.engagementsSum, function (value, key) {
                                            $scope.statIDsum2 += $scope.engagementsSum[key];
                                        })
                                        obj.engagementspromoted = $scope.statIDsum2;

                                        $scope.statIDsum3 = 0;
                                        angular.forEach($scope.engrateSum, function (value, key) {
                                            $scope.statIDsum3 += $scope.engrateSum[key];
                                        })
                                        obj.engratepromoted = $scope.statIDsum3;
                                    } else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
                                        obj.impressionspromoted = 0;
                                        obj.engagementspromoted = 0;
                                        obj.engratepromoted = 0;
                                    }

                                }));

                                //Stats service
                                var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.statsData = response.data.stats;

                                        var JsonObj1 = $scope.statsData;
                                        var array1 = [];
                                        for (var j in JsonObj1) {
                                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                                array1[+j] = JsonObj1[j];
                                                $scope.statdata = array1[+j];

                                                angular.forEach($scope.statdata, function (value, key) {
                                                    obj.impressions = value.id_data[0].metrics.impressions;
                                                    if (obj.impressions != 0) {
                                                        obj.impressions = value.id_data[0].metrics.impressions[0];
                                                    }
                                                    obj.engagements = value.id_data[0].metrics.engagements;
                                                    if (obj.engagements != 0) {
                                                        obj.engagements = value.id_data[0].metrics.engagements[0];
                                                    }
                                                    if (obj.impressions == 0 && obj.engagements == 0) {
                                                        obj.engrate = 0;
                                                    } else if (obj.impressions > 0 && obj.engagements > 0) {
                                                        $scope.engratecheck = obj.engagements / obj.impressions;
                                                        if (obj.engrate < 1) {
                                                            obj.engrate = 0;
                                                        }
                                                    }
                                                });

                                            }
                                        }
                                    } else {
                                        obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }

                                }));

                                $scope.tweetedArray.push(obj);

                            }
                        }

                    });


                } else {
                    $scope.mainLoader = "none";
                    $scope.showErrorPopup(response);
                }

                $q.all(promises).finally(
                        function () {
                            $scope.mainLoader = "none";

                            var a = 0;
                            angular.forEach($scope.tweetedArraySample, function (value, index) {
                                var h2 = $("#parenttd" + a).height();
                                angular.element('#childtd' + a).css('height', h2);
                                angular.element('#childtd1' + a).css('height', h2);
                                angular.element('#childtd2' + a).css('height', h2);
                                a = a + 1;
                            })
                        });
            }));
        }

        //Get Organic Tweets
        $scope.getOrganicTweets = function () {
            var promises = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=followers";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.tweetedArray = [];
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
                                $scope.tweeterIDArray.push($scope.iteratedtweets.id_str);
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                if ($scope.mediaurlcheck.hasOwnProperty('urls')) {
                                    if ($scope.mediaurlcheck.urls.length > 0) {
                                        $scope.expanded_url_length = $scope.mediaurlcheck.urls.length;
                                        $scope.expanded_url = $scope.mediaurlcheck.urls[0].expanded_url;
                                    }
                                } else {
                                    $scope.expanded_url = "";
                                }
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                $scope.values = $scope.iteratedtweets.text.split(" ");
                                $scope.link = $scope.values[$scope.values.length - 1];
                                $scope.impressions = 0;
                                $scope.engagements = 0;
                                $scope.engrate = 0;
                                $scope.impressionspromoted = 0;
                                $scope.engagementspromoted = 0;
                                $scope.engratepromoted = 0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                } else {
                                    $scope.media_url = "";
                                }

                                if ($scope.campaignState == "edit") {
                                    if ($scope.promotedtweetID.includes($scope.tweeterID) == true) {
                                        $scope.checkVal[key] = true;
                                        $scope.checkTweet = $scope.promotedtweetID.length;
                                    }
                                }

                                var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
                                    "expanded_url": $scope.expanded_url,
                                    "IFrameURL": $scope.link,
                                    "impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
                                    "impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
                                        //Stats service for promoted campaign
                                        $scope.promotedCampaign = response.data.promotedTweets;
                                        $scope.statID = [];
                                        angular.forEach($scope.promotedCampaign, function (value, key) {
                                            var JsonObj2 = $scope.promotedCampaign[key]
                                            var array2 = [];
                                            for (var i in JsonObj2) {
                                                if (JsonObj2.hasOwnProperty(i)) {
                                                    array2[+i] = JsonObj2[i];
                                                    $scope.statdata1 = array2[+i];
                                                    $scope.statID.push($scope.statdata1.promotedTweetId);
                                                }
                                            }
                                        })
                                        $scope.statIDsum = [];

                                        angular.forEach($scope.statID, function (value, key) {

                                            //Stats service
                                            var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                            promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {
                                                if (response.data.appStatus == '0') {
                                                    $scope.statsDatapromote = response.data.stats;
                                                    var JsonObj3 = $scope.statsDatapromote;
                                                    var array3 = [];
                                                    for (var j in JsonObj3) {
                                                        if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                                            array3[+j] = JsonObj3[j];
                                                            $scope.statdata3 = array3[+j];

                                                            angular.forEach($scope.statdata3, function (value, key) {

                                                                $scope.impressionsSum1 = value.id_data[0].metrics.engagements;
                                                                $scope.impressionsSum.push($scope.impressionsSum1);

                                                                if ($scope.impressionsSum1 != 0) {
                                                                    $scope.impressionsSum.push($scope.impressionsSum1[0]);

                                                                }
                                                                $scope.engagementsSum1 = value.id_data[0].metrics.engagements;
                                                                $scope.engagementsSum.push($scope.engagementsSum1);
                                                                if ($scope.engagementsSum1 != 0) {
                                                                    $scope.engagementsSum.push($scope.engagementsSum1[0]);
                                                                }
                                                                if ($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0) {
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0) {
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0) {
                                                                    $scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                }

                                                            });


                                                        }
                                                    }
                                                } else {
                                                    $scope.engagementsSum = 0;
                                                    $scope.impressionsSum = 0;
                                                    $scope.engrateSum = 0;
                                                }

                                            }));

                                        })
                                        $scope.statIDsum1 = 0;
                                        angular.forEach($scope.impressionsSum, function (value, key) {
                                            $scope.statIDsum1 += $scope.impressionsSum[key];
                                        })
                                        obj.impressionspromoted = $scope.statIDsum1;

                                        $scope.statIDsum2 = 0;
                                        angular.forEach($scope.engagementsSum, function (value, key) {
                                            $scope.statIDsum2 += $scope.engagementsSum[key];
                                        })
                                        obj.engagementspromoted = $scope.statIDsum2;

                                        $scope.statIDsum3 = 0;
                                        angular.forEach($scope.engrateSum, function (value, key) {
                                            $scope.statIDsum3 += $scope.engrateSum[key];
                                        })
                                        obj.engratepromoted = $scope.statIDsum3;
                                    } else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
                                        obj.impressionspromoted = 0;
                                        obj.engagementspromoted = 0;
                                        obj.engratepromoted = 0;
                                    }

                                }));

                                //Stats service
                                var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.statsData = response.data.stats;

                                        var JsonObj1 = $scope.statsData;
                                        var array1 = [];
                                        for (var j in JsonObj1) {
                                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                                array1[+j] = JsonObj1[j];
                                                $scope.statdata = array1[+j];

                                                angular.forEach($scope.statdata, function (value, key) {
                                                    obj.impressions = value.id_data[0].metrics.impressions;
                                                    if (obj.impressions != 0) {
                                                        obj.impressions = value.id_data[0].metrics.impressions[0];
                                                    }
                                                    obj.engagements = value.id_data[0].metrics.engagements;
                                                    if (obj.engagements != 0) {
                                                        obj.engagements = value.id_data[0].metrics.engagements[0];
                                                    }
                                                    if (obj.impressions == 0 && obj.engagements == 0) {
                                                        obj.engrate = 0;
                                                    } else if (obj.impressions > 0 && obj.engagements > 0) {
                                                        $scope.engratecheck = obj.engagements / obj.impressions;
                                                        
                                                        if (obj.engrate < 1) {
                                                            obj.engrate = 0;
                                                        }
                                                    }
                                                });

                                            }
                                        }
                                    } else {
                                        obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }

                                }));

                                $scope.tweetedArray.push(obj);

                            }
                        }

                    });


                } else {
                    $scope.mainLoader = "none";
                    
                    $scope.showErrorPopup(response);
                }

                $q.all(promises).finally(
                        function () {
                            $scope.mainLoader = "none";
                        });

            }));

        }


        //Get All tweets in campaign
        $scope.getAllTweetsinCampaign = function () {
            var promises = [];
            $scope.tweetedArray = [];
            $scope.scopenone = [];
            $scope.scopefollowers = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=none" + "&" + "promotedTweetsOnly=true";
            var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "scopedTo=followers" + "&" + "promotedTweetsOnly=true";
            promises.push(twitterGetPost.gettweet(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.promotedtweets = response.data.tweet;
                    angular.forEach($scope.promotedtweets, function (value, key) {
                        var JsonObj = $scope.promotedtweets[key]
                        var array = [];
                        loopCnt = key;
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                $scope.name = $scope.iteratedtweets.user.name;
                                $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                $scope.tweetHeadline = $scope.iteratedtweets.text;
                                $scope.tweeterID = $scope.iteratedtweets.id_str;
                                $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                $scope.impressions = 0;
                                $scope.engagements = 0;
                                $scope.engrate = 0;
                                $scope.impressionspromoted = 0;
                                $scope.engagementspromoted = 0;
                                $scope.engratepromoted = 0;
                                if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                    $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                } else {
                                    $scope.media_url = "";
                                }

                                if ($scope.campaignState == "edit") {
                                    if ($scope.promotedtweetID.includes($scope.tweeterID) == true) {
                                        $scope.checkVal[key] = true;
                                        $scope.checkTweet = $scope.promotedtweetID.length;
                                    } 
                                }

                                var obj = {
                                    "text": $scope.tweetHeadline,
                                    "profile_image_url": $scope.profileimage,
                                    "name": $scope.name,
                                    "screen_name": $scope.screen_name,
                                    "created_at": $scope.created_at,
                                    "media_url": $scope.media_url,
                                    "tweeterID": $scope.tweeterID,
                                    "promotedCount": $scope.promotedCount,
                                    "impressions": $scope.impressions,
                                    "engagements": $scope.engagements,
                                    "engrate": $scope.engrate,
                                    "impressionspromoted": $scope.impressionspromoted,
                                    "engagementspromoted": $scope.engagementspromoted,
                                    "engratepromoted": $scope.engratepromoted
                                }

                                var data = {
                                    'userId': $window.localStorage.getItem("userId"),
                                    'accessToken': $window.localStorage.getItem("accessToken")
                                };
                                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
                                $scope.impressionsSum = [];
                                $scope.engagementsSum = [];
                                $scope.engrateSum = [];
                                promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.promotedTweetLength = response.data.promotedTweets.length;
                                        obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";


                                        //Stats service for promoted campaign
                                        $scope.promotedCampaign = response.data.promotedTweets;
                                        $scope.statID = [];
                                        angular.forEach($scope.promotedCampaign, function (value, key) {
                                            var JsonObj2 = $scope.promotedCampaign[key]
                                            var array2 = [];
                                            for (var i in JsonObj2) {
                                                if (JsonObj2.hasOwnProperty(i)) {
                                                    array2[+i] = JsonObj2[i];
                                                    $scope.statdata1 = array2[+i];
                                                    $scope.statID.push($scope.statdata1.promotedTweetId);
                                                }
                                            }
                                        })
                                        $scope.statIDsum = [];

                                        angular.forEach($scope.statID, function (value, key) {
                                            //Stats service
                                            var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                            promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {
                                                if (response.data.appStatus == '0') {
                                                    $scope.statsDatapromote = response.data.stats;
                                                    var JsonObj3 = $scope.statsDatapromote;
                                                    //console.log(JsonObj1);
                                                    var array3 = [];
                                                    for (var j in JsonObj3) {
                                                        if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                                            array3[+j] = JsonObj3[j];
                                                            $scope.statdata3 = array3[+j];

                                                            angular.forEach($scope.statdata3, function (value, key) {

                                                                $scope.impressionsSum1 = value.id_data[0].metrics.engagements;
                                                                //console.log($scope.impressionsSum1);
                                                                $scope.impressionsSum.push($scope.impressionsSum1);

                                                                if ($scope.impressionsSum1 != 0) {
                                                                    //obj.impressions = value.id_data[0].metrics.impressions[0];
                                                                    $scope.impressionsSum.push($scope.impressionsSum1[0]);

                                                                }
                                                                $scope.engagementsSum1 = value.id_data[0].metrics.engagements;
                                                                $scope.engagementsSum.push($scope.engagementsSum1);
                                                                //console.log($scope.engagementsSum1);
                                                                if ($scope.engagementsSum1 != 0) {
                                                                    $scope.engagementsSum.push($scope.engagementsSum1[0]);
                                                                }
                                                                //obj.engrate = obj.engagements / obj.impressions;

                                                                if ($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0) {
                                                                    //console.log(obj.engrate);
                                                                    //obj.engrate = 0;
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0) {
                                                                    //obj.engrate = 0;
                                                                    $scope.engrateSum1 = 0;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0) {
                                                                    //obj.engrate = $scope.impressionsSum1 / $scope.impressionsSum1;
                                                                    $scope.engrateSum1 = $scope.impressionsSum1 / $scope.impressionsSum1;
                                                                    $scope.engrateSum.push($scope.engrateSum1);
                                                                }

                                                            });


                                                        }
                                                    }
                                                } else {
                                                    $scope.engagementsSum = 0;
                                                    $scope.impressionsSum = 0;
                                                    $scope.engrateSum = 0;
                                                }

                                            }));

                                        })
                                        //console.log($scope.impressionsSum);
                                        $scope.statIDsum1 = 0;
                                        angular.forEach($scope.impressionsSum, function (value, key) {
                                            //$scope.statIDsum1 =[];
                                            $scope.statIDsum1 += $scope.impressionsSum[key];
                                            //nsole.log($scope.statIDsum1);
                                        })

                                        //console.log($scope.statIDsum1);

                                        obj.impressionspromoted = $scope.statIDsum1;
                                        //console.log(obj.impressionspromoted);

                                        $scope.statIDsum2 = 0;
                                        angular.forEach($scope.engagementsSum, function (value, key) {
                                            //$scope.statIDsum12 =[];
                                            $scope.statIDsum2 += $scope.engagementsSum[key];
                                        })
                                        obj.engagementspromoted = $scope.statIDsum2;
                                        //console.log(obj.engagementspromoted);

                                        $scope.statIDsum3 = 0;
                                        angular.forEach($scope.engrateSum, function (value, key) {
                                            //$scope.statIDsum3 =[];
                                            $scope.statIDsum3 += $scope.engrateSum[key];
                                        })
                                        obj.engratepromoted = $scope.statIDsum3;
                                        //console.log(obj.engratepromoted);

                                        //console.log($scope.statIDsum);

                                    } else {
                                        obj.promotedCount = "Promoted-only - Currently unpromoted";
                                        obj.impressionspromoted = 0;
                                        obj.engagementspromoted = 0;
                                        obj.engratepromoted = 0;
                                    }

                                }));

                                //Stats service
                                var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                                    if (response.data.appStatus == '0') {
                                        $scope.statsData = response.data.stats;

                                        var JsonObj1 = $scope.statsData;
                                        //console.log(JsonObj1);
                                        var array1 = [];
                                        for (var j in JsonObj1) {
                                            if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                                array1[+j] = JsonObj1[j];
                                                $scope.statdata = array1[+j];
                                                //console.log($scope.statdata);

                                                angular.forEach($scope.statdata, function (value, key) {
                                                    //console.log(key);
                                                    //console.log(value.id);
                                                    //console.log(value.id_data[0].metrics.impressions);
                                                    //console.log(value.id_data[0].metrics.engagements);
                                                    obj.impressions = value.id_data[0].metrics.impressions;
                                                    //console.log(obj.impressions);
                                                    if (obj.impressions != 0) {
                                                        obj.impressions = value.id_data[0].metrics.impressions[0];
                                                        //console.log(obj.impressions);
                                                    }
                                                    obj.engagements = value.id_data[0].metrics.engagements;
                                                    if (obj.engagements != 0) {
                                                        obj.engagements = value.id_data[0].metrics.engagements[0];
                                                        //console.log(obj.engagements);
                                                    }
                                                    //obj.engrate = obj.engagements / obj.impressions;

                                                    if (obj.impressions == 0 && obj.engagements == 0) {
                                                        //console.log(obj.engrate);
                                                        obj.engrate = 0;
                                                    } else if (obj.impressions > 0 && obj.engagements > 0) {
                                                        //obj.engrate = obj.engagements / obj.impressions;
                                                        $scope.engratecheck = obj.engagements / obj.impressions;
                                                        console.log($scope.engratecheck);
                                                        if (obj.engrate < 1) {
                                                            obj.engrate = 0;
                                                        }
                                                    }
                                                });

                                            }
                                        }
                                    } else {
                                        obj.impressions = 0;
                                        obj.engagements = 0;
                                        obj.engrate = 0;
                                    }

                                }));

                                $scope.scopenone.push(obj);
                                //$scope.tweetedArray.push([$scope.scopenone]);
                                //console.log($scope.scopenone);

                            }


                        }

                    });

                    promises.push(twitterGetPost.gettweet(queryStr1, data).then(function (response) {
                        console.log(response);
                        if (response.data.appStatus == '0') {
                            // $scope.tweetedArray = [];
                            //$scope.tweetedArray2 = [];
                            //$scope.mainLoader = "none";
                            console.log(response.data.successMessage);
                            $scope.promotedtweets = response.data.tweet;
                            angular.forEach($scope.promotedtweets, function (value, key) {
                                var JsonObj = $scope.promotedtweets[key]
                                var array = [];
                                loopCnt = key;
                                // console.log(JsonObj);
                                for (var i in JsonObj) {
                                    if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                        array[+i] = JsonObj[i];
                                        $scope.iteratedtweets = array[+i];
                                        $scope.profileimage = $scope.iteratedtweets.user.profile_image_url;
                                        $scope.name = $scope.iteratedtweets.user.name;
                                        $scope.screen_name = $scope.iteratedtweets.user.screen_name;
                                        $scope.created_at = $scope.iteratedtweets.created_at.split(' ')[1] + " " + $scope.iteratedtweets.created_at.split(' ')[2];
                                        $scope.tweetHeadline = $scope.iteratedtweets.text;
                                        $scope.tweeterID = $scope.iteratedtweets.id_str;
                                        $scope.mediaurlcheck = $scope.iteratedtweets.entities;
                                        $scope.promotedCount = "Promoted-only - Currently unpromoted";
                                        $scope.impressions = 0;
                                        $scope.engagements = 0;
                                        $scope.engrate = 0;
                                        if ($scope.mediaurlcheck.hasOwnProperty('media')) {
                                            $scope.media_url = $scope.mediaurlcheck.media[0].media_url;
                                            // $(".tableCell .setcolumnheight").css("height", "175px");
                                        } else {
                                            $scope.media_url = "";
                                            // $(".tableCell .setcolumnheight").css("height", "75px");
                                        }
                                        var obj = {
                                            "text": $scope.tweetHeadline,
                                            "profile_image_url": $scope.profileimage,
                                            "name": $scope.name,
                                            "screen_name": $scope.screen_name,
                                            "created_at": $scope.created_at,
                                            "media_url": $scope.media_url,
                                            "tweeterID": $scope.tweeterID,
                                            "promotedCount": $scope.promotedCount,
                                            "impressions": $scope.impressions,
                                            "engagements": $scope.engagements,
                                            "engrate": $scope.engrate,
                                            "impressionspromoted": $scope.impressionspromoted,
                                            "engagementspromoted": $scope.engagementspromoted,
                                            "engratepromoted": $scope.engratepromoted
                                        }

                                        var data = {
                                            'userId': $window.localStorage.getItem("userId"),
                                            'accessToken': $window.localStorage.getItem("accessToken")
                                        };
                                        var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.tweeterID;
                                        promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                                            if (response.data.appStatus == '0') {
                                                // console.log(response.data.promotedTweets.length);
                                                $scope.promotedTweetLength = response.data.promotedTweets.length;
                                                obj.promotedCount = "Promoted-only - Promoted in " + $scope.promotedTweetLength + " campaign";
                                            } else {
                                                obj.promotedCount = "Promoted-only - Currently unpromoted";
                                            }

                                        }));

                                        //Stats service
                                        var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.tweeterID + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                                        promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                                            if (response.data.appStatus == '0') {
                                                $scope.statsData = response.data.stats;

                                                var JsonObj1 = $scope.statsData;
                                                //console.log(JsonObj1);
                                                var array1 = [];
                                                for (var j in JsonObj1) {
                                                    if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                                        array1[+j] = JsonObj1[j];
                                                        $scope.statdata = array1[+j];
                                                        //console.log($scope.statdata);

                                                        angular.forEach($scope.statdata, function (value, key) {
                                                            //console.log(key);
                                                            //console.log(value.id);
                                                            //console.log(value.id_data[0].metrics.impressions);
                                                            //console.log(value.id_data[0].metrics.engagements);
                                                            obj.impressions = value.id_data[0].metrics.impressions;
                                                            //console.log(obj.impressions);
                                                            if (obj.impressions != 0) {
                                                                obj.impressions = value.id_data[0].metrics.impressions[0];
                                                                //console.log(obj.impressions);
                                                            }
                                                            obj.engagements = value.id_data[0].metrics.engagements;
                                                            if (obj.engagements != 0) {
                                                                obj.engagements = value.id_data[0].metrics.engagements[0];
                                                                //console.log(obj.engagements);
                                                            }
                                                            //obj.engrate = obj.engagements / obj.impressions;

                                                            if (obj.impressions == 0 && obj.engagements == 0) {
                                                                //console.log(obj.engrate);
                                                                obj.engrate = 0;
                                                            } else if (obj.impressions > 0 && obj.engagements == 0) {
                                                                obj.engrate = 0;
                                                            }
                                                        });

                                                    }
                                                }
                                            } else {
                                                obj.impressions = 0;
                                                obj.engagements = 0;
                                                obj.engrate = 0;
                                            }

                                        }));

                                        $scope.scopefollowers.push(obj);
                                        $scope.tweetedArray = $scope.scopefollowers.concat($scope.scopenone)
                                    }
                                }

                            });


                        } else {
                            $scope.mainLoader = "none";
                            console.log(response.data.errorMessage);
                            $scope.showErrorPopup(response);
                        }
                    }));


                } else {
                    $scope.mainLoader = "none";
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }

                $q.all(promises).finally(
                        function () {
                            //$scope.onloadchild();
                            $scope.mainLoader = "none";
                        });

            }));



        }

        //$scope.getPromotedOnlyTweets();

        //Get media only content
        $scope.tweetsArray = [];
        var tweetObj = {};
        $scope.fetchMedia = function () {
            var promises = [];
            $scope.promotedtweetID = [];            
            
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "id=" + $window.localStorage.getItem("twtweetID");
            promises.push(twitterGetPost.gettweetbyid(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.mediaResponse = response.data.tweetDetails;
                    angular.forEach($scope.mediaResponse, function (value, key) {
                        var JsonObj = $scope.mediaResponse[key];
                        $scope.created_at = JsonObj.created_at.split(' ')[1] + ' ' + JsonObj.created_at.split(' ')[2];
						console.log($scope.created_at);
                        var array = [];
                        $scope.extended_entities = JsonObj.extended_entities;
                        if ($scope.extended_entities != undefined) {
                            for (var i in $scope.extended_entities) {
                                if ($scope.extended_entities.hasOwnProperty(i)) {
                                    array[+i] = $scope.extended_entities;
                                    $scope.iteratedtweets = array[+i];
									$scope.values = JsonObj.text.split(" ");
									console.log($scope.values)
                                    $scope.link = $scope.values[$scope.values.length - 1];
                                    tweetObj = {
                                        "profile_image": JsonObj.user.profile_image_url,
                                        "name": JsonObj.user.name,
                                        "screenName": JsonObj.user.screen_name,
                                        "created_at": $scope.created_at,
                                        "text": JsonObj.text,
                                        "tweeterID": JsonObj.id_str,
										"link" : $scope.link,
                                        "media_url": $scope.iteratedtweets.media[0].media_url
                                    }
                                }

                            }
                            $scope.media_url = $scope.iteratedtweets.media[0].media_url;
                        } else {
						$scope.values = JsonObj.text.split(" ");
									console.log($scope.values)
                                    $scope.link = $scope.values[$scope.values.length - 1];
									console.log($scope.link);
                            tweetObj = {
                                "profile_image": JsonObj.user.profile_image_url,
                                "name": JsonObj.user.name,
                                "screenName": JsonObj.user.screen_name,
                                "created_at": $scope.created_at,
                                "tweeterID": JsonObj.id_str,
								"link" : $scope.link,
                                "text": JsonObj.text,
                                

                            }
                        }

                    })
                    var lengthTweet = 0;
                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    };
                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $window.localStorage.getItem("twtweetID");
                    //$scope.mainLoader = "block";
                    $scope.impressionsSum = [];
                    $scope.engagementsSum = [];
                    $scope.engrateSum = [];
                    promises.push(twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                        if (response.data.appStatus == '0') {
                            $scope.promotedTweetLength = response.data.promotedTweets;
                             $scope.statID = [];
                            angular.forEach($scope.promotedTweetLength, function (value, key) {
                                var JsonObj2 = $scope.promotedTweetLength[key]
                                var array2 = [];
                                for (var i in JsonObj2) {
                                    if (JsonObj2.hasOwnProperty(i)) {
                                        array2[+i] = JsonObj2[i];
                                        $scope.statdata1 = array2[+i];
                                        $scope.statID.push($scope.statdata1.promotedTweetId);
                                    }
                                }
                            })
                            angular.forEach($scope.promotedTweetLength, function (key, value) {
                                lengthTweet += key.length;
                            });
                            tweetObj.promotedCount = "Promoted-only - Promoted in " + lengthTweet + " campaign";
                        } else {
                            $scope.mainLoader = "none";
                            tweetObj.promotedCount = "Promoted-only -" + "Currently Unpromoted";
                            tweetObj.impressionspromoted = 0;
                            tweetObj.engagementspromoted = 0;
                            tweetObj.engratepromoted = "0.0%";
                        }
                    }))

                    //Stats service
                    var queryStrstat = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $window.localStorage.getItem("twtweetID") + "&entity=ORGANIC_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";

                    promises.push(twitterGetPost.getstats(queryStrstat, data).then(function (response) {
                        if (response.data.appStatus == '0') {
                            $scope.statsData = response.data.stats;
                            console.log($scope.statsData);
                            var JsonObj1 = $scope.statsData;
                            var array1 = [];
                            for (var j in JsonObj1) {
                                if (JsonObj1.hasOwnProperty(j) && !isNaN(+j)) {
                                    array1[+j] = JsonObj1[j];
                                    $scope.statdata = array1[+j];

                                    angular.forEach($scope.statdata, function (value, key) {
                                        tweetObj.impressions = value.id_data[0].metrics.impressions[0];
                                        console.log(tweetObj.impressions);
                                        if (tweetObj.impressions != 0) {
                                            tweetObj.impressions = value.id_data[0].metrics.impressions[0];
                                            console.log(tweetObj.impressions);
                                        }
                                        tweetObj.engagements = value.id_data[0].metrics.engagements[0];
                                        if (tweetObj.engagements != 0) {
                                            tweetObj.engagements = value.id_data[0].metrics.engagements[0];
                                            console.log(tweetObj.engagements);
                                        }
                                        if (tweetObj.impressions == 0 && tweetObj.engagements == 0) {
                                            console.log(tweetObj.engrate);
                                            tweetObj.engrate = "0.0%";
                                        } else if (tweetObj.impressions > 0 && tweetObj.engagements == 0) {
                                            tweetObj.engrate = "0.0%";
                                        } else if (tweetObj.impressions > 0 && tweetObj.engagements > 0) {
                                            $scope.engratecheck = tweetObj.engagements / tweetObj.impressions;
                                            console.log($scope.engratecheck);
                                            if (tweetObj.engrate < 1) {
                                                tweetObj.engrate = "0.0%";
                                            }
                                        }
                                    });

                                }
                            }
                            $scope.setLine();
                            var a = 0;
                            angular.forEach($scope.tweetsArray, function (value, index) {
                                var h2 = $("#parenttd" + a).height();
                                var tableHeight = $("#tablever").height();
                                console.log(tableHeight);
                                angular.element('#childtd' + a).css('height', h2);
                                angular.element('#childtd1' + a).css('height', h2);
                                angular.element('#childtd2' + a).css('height', h2);
                                a = a + 1;
                                angular.element('.vrtable1').css('height', tableHeight);
                                angular.element('.vrtable2').css('height', tableHeight);
                                angular.element('.vrtable3').css('height', tableHeight);
                            });
                            $scope.mainLoader = "none";
                        } else {
                            $scope.mainLoader = "none";
                            tweetObj.impressions = 0;
                            tweetObj.engagements = 0;
                            tweetObj.engrate = 0;
                            $scope.setLine();
                        }
                        $scope.setLine();
                        var a = 0;
                        angular.forEach($scope.tweetsArray, function (value, index) {
                            var h2 = $("#parenttd" + a).height();
                            var tableHeight = $("#tablever").height();
                            console.log(tableHeight);
                            angular.element('.childtd' + a).css('height', h2);

                            a = a + 1;
                            angular.element('.vrtable1').css('height', tableHeight);
                            angular.element('.vrtable2').css('height', tableHeight);
                            angular.element('.vrtable3').css('height', tableHeight);
                        });
                    }));
                     promises = [];
                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    };
                    $scope.statIDsum = [];

                    angular.forEach($scope.statID, function (value, key) {
                        var queryStrstatpromote = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "entityIds=" + $scope.statID[key] + "&entity=PROMOTED_TWEET&startTime=" + $scope.weekdate + "&endTime=" + $scope.currentdate + "&placement=ALL_ON_TWITTER&granularity=TOTAL&metricGroups=ENGAGEMENT";
                        promises.push(twitterGetPost.getstats(queryStrstatpromote, data).then(function (response) {
                            if (response.data.appStatus == '0') {
                                $scope.statsDatapromote = response.data.stats;
                                var JsonObj3 = $scope.statsDatapromote;
                                var array3 = [];
                                for (var j in JsonObj3) {
                                    if (JsonObj3.hasOwnProperty(j) && !isNaN(+j)) {
                                        array3[+j] = JsonObj3[j];
                                        $scope.statdata3 = array3[+j];

                                        angular.forEach($scope.statdata3, function (value, key) {

                                            $scope.impressionsSum1 = value.id_data[0].metrics.engagements;
                                            $scope.impressionsSum.push($scope.impressionsSum1);

                                            if ($scope.impressionsSum1 != 0) {
                                                $scope.impressionsSum.push($scope.impressionsSum1[0]);

                                            }
                                            $scope.engagementsSum1 = value.id_data[0].metrics.engagements;
                                            $scope.engagementsSum.push($scope.engagementsSum1);
                                            if ($scope.engagementsSum1 != 0) {
                                                $scope.engagementsSum.push($scope.engagementsSum1[0]);
                                            }
                                            if ($scope.impressionsSum1 == 0 && $scope.engagementsSum1 == 0) {
                                                $scope.engrateSum1 = 0;
                                                $scope.engrateSum.push($scope.engrateSum1);
                                            } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 == 0) {
                                                $scope.engrateSum1 = 0;
                                                $scope.engrateSum.push($scope.engrateSum1);
                                            } else if ($scope.impressionsSum1 > 0 && $scope.engagementsSum1 > 0) {
                                                $scope.engrateSum1 = $scope.impressionsSum1 / $scope.engagementsSum1;
                                                $scope.engrateSum.push($scope.engrateSum1);
                                            }

                                        });


                                    }
                                }
                            } else {
                                $scope.engagementsSum = 0;
                                $scope.impressionsSum = 0;
                                $scope.engrateSum = 0;
                            }

                        }));
                    })
                    $scope.statIDsum1 = 0;
                    angular.forEach($scope.impressionsSum, function (value, key) {
                        $scope.statIDsum1 += $scope.impressionsSum[key];
                    })
                    tweetObj.impressionspromoted = $scope.statIDsum1;
                    $scope.statIDsum2 = 0;
                    angular.forEach($scope.engagementsSum, function (value, key) {
                        $scope.statIDsum2 += $scope.engagementsSum[key];
                    })
                    tweetObj.engagementspromoted = $scope.statIDsum2;

                    $scope.statIDsum3 = 0;
                    angular.forEach($scope.engrateSum, function (value, key) {
                        $scope.statIDsum3 += $scope.engrateSum[key];
                    })
                    tweetObj.engratepromoted = $scope.statIDsum3 + "%";
                    $scope.tweetsArray.push(tweetObj);
					console.log(JSON.stringify($scope.tweetsArray , null , 2));
                }
            }));
        }

        $scope.readPromotedTweetsEdit = function () {
            
            $scope.promotedtweetID1 = [];
            $scope.deleteTweetId = []; 
          //  $scope.multipleTweetId = [];
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")

            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&lineItemId=" + $window.localStorage.getItem("lineItemid");
            twitterGetPost.readpromotedtweets(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {  
                   // $scope.mainLoader = "none";
                     var promoteFetch = response.data.promotedTweets;
                    angular.forEach(promoteFetch, function (value, key) {
                        var JsonObj = promoteFetch[key];
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweetsFetch = array[+i];
                                angular.forEach($scope.iteratedtweetsFetch, function (value, key) {
                                     var promotedTweetStatus = value.promotedTweetStatus;
                                    if (promotedTweetStatus != "DELETED") {
                                        $scope.promotedtweetID1.push(value.promotedTweetDetails.tweet_id);
                                        $scope.deleteTweetId.push(value.promotedTweetDetails.id);
                                    }
                                })
                                
                            }
                            $window.localStorage.setItem("deleteTweetId", $scope.deleteTweetId);
                            $scope.checkTweet = $scope.promotedtweetID1.length;
                            if($scope.checkTweet >= 1){
                                $scope.carouselFlow = 1;
                                angular.element('.naviButtons #left').css('pointer-events', 'none');
                                angular.element('.naviButtons #right').css('pointer-events', 'none');
                            }
                            $scope.tweetsChecked.push($scope.deleteTweetId);
                        }
                    });
                } else {
                    $scope.mainLoader = "none";
                    angular.element($('#step2').css('background-color', 'rgb(149, 210, 177)'));
                    $scope.showErrorPopup(response);
                }
            });
        };

        $scope.init();



        //Promoted Tweet Map
        $scope.createPromotedTweetMap = function () {
            //alert('hi');
            $scope.mainLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                'tweetIds': $window.localStorage.getItem("multipleTweetId")
            };
            var queryStr = "";
            twitterGetPost.createpromotedtweetsmap("", data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0' || response.appStatus == '0') {
                    //$scope.tweetedArray =[];
                    // 
                    //angular.element($('.btnCampaignCreative').prop('disabled', true));
                    console.log(response.data.successMessage);
                    //console.log('Response for createpromotedtweetsmap POST call++');
                    console.log(response.data);
                    $scope.getPromotedTweetsForAccount();

                } else {
                    $scope.mainLoader = "none";
                    angular.element($('.btnCampaignCreative').prop('disabled', true));                    
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }
            })
        }

        //Get Promoted tweet for Account
        $scope.getPromotedTweetsForAccount = function () {
            $scope.getTweetDetails = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "withDeleted=true";
            twitterGetPost.getpromotedtweetsforaccount(queryStr, data).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {

                    $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    //console.log(response.data);
                    $scope.getTweetDetails = response.data.promotedTweets;
					
                    console.log($scope.getTweetDetails);
                    if($scope.getTweetDetails.length == 0)
					{
						$scope.mainLoader = "none";            
						$rootScope.campaignSteps[3] = true;
						$rootScope.campaignSteps[4] = true;
						$state.go('app.twittercampaignsummary');
					}
					else{
						$scope.savePromotedTweets();
					}
                    // $scope.mainLoader = "none"; 
                    //$state.go('app.twittercampaignsummary');
                } else {
                    $scope.mainLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    $scope.showErrorPopup(response);
                }

            });



        }
        $scope.setLine = function () {
            var everythingLoaded = setInterval(function () {
                if (/loaded|complete/.test(document.readyState)) {
                    clearInterval(everythingLoaded);
                    $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;

                    $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;

                    var fStep = $(".vr");
                    fStep.css('height', (($scope.lsValue - $scope.fsValue)));

                }
            }, 10);
        };
        $scope.setLine();

        //Save promoted tweets local DB
        $scope.savePromotedTweets = function () {


            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                'tweetDetails': $scope.getTweetDetails
            };
            var queryStr = "";
            twitterGetPost.savepromotedtweets("", data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {

                    $scope.mainLoader = "none";
                    console.log(response.data.successMessage);
                    console.log(response.data);
                    $scope.mainLoader = "none";
                    $rootScope.campaignSteps[3] = true;
                    $rootScope.campaignSteps[4] = true;
                    $state.go('app.twittercampaignsummary');
                } else {
                    $scope.mainLoader = "none";
                    //console.log(response.data);
                    //console.log(response.data.errorMessage);
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    $scope.showErrorPopup(response);
                }

            });



        }

        //Tweets popup functionality
        $scope.uploadFile = function (files) {
            if($scope.selectedType == 'Image App Card'){
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').attr('src', e.target.result);
                $scope.dataURL = reader.result;
                
                $scope.splittedData = $scope.dataURL.split(',')[1];
               // alert($scope.splitted);
                $scope.mainLoader = "block";
            };

            $timeout(function () {
                //console.log($scope.dataURL); 
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'mediaData': $scope.splittedData
                };
                if (typeof (files[0]) == "object") {
                    twitterGetPost.mediaupload("", data).then(function (response) {
                        console.log(response);

                        if (response.data.appStatus == 0) {
                            $scope.mainLoader = "none";
                            $scope.mediaID = response.data.mediaDetails.media_id_string;
                            console.log(response.data.successMessage);
                            console.log($scope.mediaID);
                            $window.localStorage.setItem("twMediaID", $scope.mediaID);


                        } else {
                            console.log(response.data);
                            $scope.mainLoader = "none";
                            $scope.showErrorPopup(response);
                            //alert('failed');
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }
                    });

                }

            }, 1000);
            console.log(files[0]);
            reader.readAsDataURL(files[0]);
            $scope.uploading = false;
            $scope.previewing = true;
            }
        };

        //Update tweet content

        $scope.sendTweetContent = function (val) {
            $scope.tweetContent = val;
            $window.localStorage.setItem("tweetContents", $scope.tweetContent)

        };
        $scope.previewUrl = "";
        $scope.publishTweets = function () {
            angular.element($('html').css("overflow-y", "scroll"));
            $scope.gettweetmediaID = $window.localStorage.getItem("twMediaID");
            $scope.mainLoader = "block";
            var promises = [];
             var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken"),
                        'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                        'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                        'name':$scope.card.cardName,                        
                        'appCountryCode':$scope.card.country,
                        'googleplayAppId':'com.modernmedical.trumobile',
                        'appCta': $scope.card.ctavalue,
                        'googleplayDeepLink' : $scope.card.androidLink                        
                    }
            if($scope.selectedType == 'Image App Card'){
                if(!$scope.selectcard){
                   data['wideAppImageMediaId'] = $window.localStorage.getItem("twMediaID");
                    promises.push(twitterGetPost.createimageappdownload("" ,data).then(function (response){
                        if (response.data.appStatus == 0) {
                            $scope.previewUrl = response.data.imageAppDownload.preview_url;                            
                        }
                    }))
                    
                }else{
                    $scope.previewUrl = $scope.websiteUrl;
                    
                }
            }else{
                if(!$scope.selectcard){
                    data['videoId'] = $window.localStorage.getItem("twMediaID");
                    promises.push(twitterGetPost.createvideoappdownloadcard("" ,data).then(function (response){
                        if (response.data.appStatus == 0) {
                            $scope.previewUrl = response.data.imageAppDownload.preview_url;                            
                        }
                    }))
                    
                }else{
                    $scope.previewUrl = $scope.websiteUrl;
                }
            }
            $q.all(promises).finally(
                    function(){
                        
                    

            if ($scope.gettweetmediaID == "" || $scope.gettweetmediaID == null || $scope.gettweetmediaID == undefined) {
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $scope.tweetContent +" "+$scope.preview_url
                };

                twitterGetPost.createtweet("", data).then(function (response) {
                    console.log(response);

                    if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;	
                        $scope.fetchMedia();
                        $scope.closePopup();
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                    } else {
                        console.log(response.data.errorMessage);
                        $scope.mainLoader = "none";
                        $scope.showErrorPopup(response);
                    }
                });
            } else {

                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'text': $scope.tweetContent+" "+$scope.preview_url
                    
                };

                twitterGetPost.createtweet("", data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.mainLoader = "none";
                        $scope.tweetID = response.data.tweet.id_str;
                        $window.localStorage.setItem("twtweetID", $scope.tweetID);
                        $scope.tweetContent = "";
                        $scope.uploading = true;
                        $scope.previewing = false;
                        $scope.fetchMedia();
                        $scope.closePopup();

                    } else {
                        $scope.mainLoader = "none";
                        $scope.showErrorPopup(response);
                    }
                });
            }
            });
        };
        //Select Tweet Types
        $scope.sendTweetTpe = function (val) {
            $scope.tweetselectedItem = val;
            if ($scope.tweetselectedItem == "Promoted only tweets") {
                $scope.getPromotedOnlyTweets();
            } else if ($scope.tweetselectedItem == "Organic Tweets") {                
                $scope.getOrganicTweets();
            } else if ($scope.tweetselectedItem == "All Tweets in Campaign") {
                $scope.getAllTweetsinCampaign();
            }
        }


        $scope.saveAndProceedNextStep = function () {
            if ($scope.campaignState == "edit") {
                $scope.deleteTweetIdLengthcheck = $window.localStorage.getItem("deleteTweetId");
                if ($scope.deleteTweetIdLengthcheck == null || $scope.deleteTweetIdLengthcheck == "undefined" || $scope.deleteTweetIdLengthcheck == " ") {
                    $scope.createPromotedTweetMap();
                } else {
                    $scope.deletepromotedtweet();
                }
            } else {
                $scope.createPromotedTweetMap();
            }
        }

        $scope.deletepromotedtweet = function(){
        
        console.log($scope.deleteTweetId);
            angular.forEach($scope.deleteTweetId, function (value, key) {
             var queryStr = "userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&promotedTweetId=" + $scope.deleteTweetId[key];
            $http({
                method: 'DELETE',
                url: apiTwitterBase + '/deletepromotedtweet?' + queryStr,
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                   
                }
            }).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.createPromotedTweetMap();
                } else {
                    $scope.mainLoader = "none";
                    $scope.showErrorPopup(response);
                }
            });
            });
        }


        $scope.changeSelection = function (image_hash) {
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }


        $scope.twitterAccounts = [
            {
                accountName: "@adtech_live",
            }
        ]

        $scope.tweetsPromote = [
            {
                promoted: "Promoted only tweets",
            },
            {
                promoted: "Scheduled Tweets",
            },
            {
                promoted: "Organic Tweets",
            },
            {
                promoted: "All Tweets in Campaign",
            }
        ]

        $scope.tweetPopup = function () {            
            $scope.tweetContent = "";
            $scope.card.cardHeadline = "";
            $scope.card.cardWebisteURL = "";
            $scope.selectcard = false;
            $scope.upload = true;
            $scope.createCard = true;
            $scope.cardbutton = true;
            $scope.cardselectbutton = false;
            $scope.selectedType = 'Image App Card';
            $scope.mediaText = 'Upload Images';
            $scope.selectMediaType($scope.selectedType);
            angular.element($('html').css("overflow-y", "hidden"));
            angular.element($('#tweetPopups .modal-content').css("overflow-y", "auto"));
            var createPopup = $(".tweetCreatePopup");
            $('#tweetPopups .modal-content').scrollTop(0);
            
            createPopup.show();
            $scope.maxLength = 140;
            angular.element($('.input-tweets textarea').keyup(function () {
                $scope.length = angular.element($('.input-tweets textarea')).val().length;
                $scope.charlength = $scope.maxLength - $scope.length;
                angular.element($('.input-tweets #chars')).text($scope.charlength);
            }));

            $scope.createBlock = true;
            $scope.mediaUpdate = true;
            $scope.cardUpdate = true;
            $scope.media = true;
            $scope.twitterFormat = "twittermediaUpdate";
            $scope.inputTypeFile = false;

            if ($window.localStorage.getItem("twMediaID") != '' || $window.localStorage.getItem("twMediaID") != 'undefined' || $window.localStorage.getItem("twMediaID") != undefined || $window.localStorage.getItem("twMediaID") != null) {
                $window.localStorage.setItem("twMediaID", "");
            }

        }

        $scope.closePopup = function () {
            $scope.createBlock = false;
            $scope.card.cardHeadline = "";
            $scope.card.cardWebisteURL = "";
            $scope.card.cardName = "";
            $scope.headline = "";
            $scope.websiteUrl = "";
            $scope.cardname = "";
            $scope.previewingcard = false;
            $scope.previewing = false;
            $scope.uploadingcard = true;
            $scope.uploading = true;
            angular.element($('html').css("overflow-y", "scroll"));
            angular.element($('#tweetPopups .modal-content').css("overflow-y", "hidden"));
        }        

        
        $scope.getImageCardApp = function(){
            $scope.mainLoader = "block";
            var promises = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");
            promises.push(twitterGetPost.getimageappdownload(queryStr,data).then(function(response){
                if (response.data.appStatus == '0') {
                    $scope.mainLoader = "none";
                    $scope.websitecards = response.data.imageAppDownload;
                     angular.forEach($scope.websitecards, function (value, key) {
                        var JsonObj = $scope.websitecards[key]
                        var array = [];
                        loopCnt = key;
                        for (var i in JsonObj) {

                            if (JsonObj.hasOwnProperty(i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.name = $scope.iteratedtweets.name;
                                $scope.image = $scope.iteratedtweets.wide_app_image;                                
                                $scope.cardId = $scope.iteratedtweets.id;
                                $scope.preview_url = $scope.iteratedtweets.preview_url;
                                var obj = {
                                    "image": $scope.image,
                                    "cardname": $scope.name,
                                    "cardId": $scope.cardId,
                                    "preview_url": $scope.preview_url,
                                    "appCta": $scope.iteratedtweets.app_cta,
                                    "countryCode":$scope.iteratedtweets.app_country_code
                                }
                                $scope.tweetedArray1.push(obj);

                            }
                        }
                    })
                    
                }
            }));
            
             $q.all(promises).finally(
                    function(){
                        $scope.tweetedArray2 = angular.copy($scope.tweetedArray1);
                        $scope.getvideoAppCard();
                       // $scope.gettargetingcriteria();
                    });
        }

        $scope.getImageCardApp();
        $scope.getAccountCardWebsite = function () {
            $scope.mainLoader = "block";
            var promises = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");
            promises.push(twitterGetPost.getaccountcardwebsite(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {

                    $scope.mainLoader = "none";
                    //console.log(response.data.successMessage);
                    $scope.websitecards = response.data.accountCardWebSiteDetails;
                    angular.forEach($scope.websitecards, function (value, key) {
                        var JsonObj = $scope.websitecards[key]
                        var array = [];
                        loopCnt = key;
                        // console.log(JsonObj);
                        for (var i in JsonObj) {

                            if (JsonObj.hasOwnProperty(i)) {
                                array[+i] = JsonObj[i];
                                $scope.iteratedtweets = array[+i];
                                $scope.name = $scope.iteratedtweets.name;
                                $scope.image = $scope.iteratedtweets.image;
                                $scope.website_url = $scope.iteratedtweets.website_url;
                                $scope.headline = $scope.iteratedtweets.website_title;
                                $scope.cardId = $scope.iteratedtweets.id;
                                $scope.preview_url = $scope.iteratedtweets.preview_url;
                                var obj = {
                                    "headline": $scope.headline,
                                    "image": $scope.image,
                                    "cardname": $scope.name,
                                    "website_url": $scope.website_url,
                                    "cardId": $scope.cardId,
                                    "preview_url": $scope.preview_url
                                }
                                $scope.tweetedArray1.push(obj);

                            }
                        }
                    })
                }

            }));
             $q.all(promises).finally(
                    function(){
                        $scope.tweetedArray2 = angular.copy($scope.tweetedArray1);
                        $scope.gettargetingcriteria();
                    });

        }
        $scope.countries = [];
        $scope.gettargetingcriteria = function(){
            var targettingcriteria;
            var object;
             $scope.countries = [];
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=locations&locationType=COUNTRIES';
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            twitterGetPost.gettargetingcriteria(queryStr , data).then(function (response){
                 if (response.data.appStatus == 0) {
                     targettingcriteria = response.data.targetingCriteria;
                     angular.forEach(targettingcriteria, function(key,value){
                         object = {
                             'name':key.name,
                             'countryCode' : key.country_code
                         }
                         $scope.countries.push(object);
                     }) 
                 }
             })
               
            }
        
        $scope.countryChange = function(val){
            angular.forEach($scope.countries ,function(key,value){
                if(key.name == val){
                    $scope.card.country = key.countryCode;
                }
            })
        }

        $scope.createTweetCard = function () {
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'text': $scope.tweetContent + " " + $scope.preview_url
            };
            twitterGetPost.createtweet("", data).then(function (response) {
                if (response.data.appStatus == 0) {
                    $scope.mainLoader = "none";
                    $scope.tweetID = response.data.tweet.id_str;
                    console.log(response.data.successMessage);
                    $window.localStorage.setItem("twtweetID", $scope.tweetID);
                    $scope.tweetContent = " ";
                    $scope.uploading = true;
                    $scope.previewing = false;
                    $scope.fetchMedia();
                    $scope.closePopup();

                } else {
                    console.log(response.data.errorMessage);
                    $scope.mainLoader = "none";
                    $scope.showErrorPopup(response);
                }
            })
        }
        $scope.mediaText = "Upload Images";
        $scope.selectMediaType = function(val){
             $scope.card.cardName = "";
            $scope.headline = "";
            $scope.card.country = "";
            $scope.card.ctavalue = "";
            $scope.uploading = true;
             $scope.previewing = false;
            if(val == 'Image App Card'){
                $scope.mediaText = 'Upload Images';
                angular.element('#uploadmedia').css('pointer-events', 'auto');
                $scope.tweetedArray1 = angular.copy($scope.tweetedArray2);
            }else{
                $scope.mediaText = 'Upload Videos';
                angular.element('#uploadmedia').css('pointer-events', 'none');
               $scope.tweetedArray1 = angular.copy($scope.tweetedArrayVideo);
            }
        }
        $scope.tweetedArrayVideo = [];
        $scope.getvideoAppCard = function(){
            var obj;
            var promises = [];
            $scope.tweetedArrayVideo = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
            }
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId");
            promises.push(twitterGetPost.getvideoappdownloadcardsforaccount(queryStr,data).then(function(response){
                if(response.data.appStatus == 0){
                    var videoResponse = response.data.videoAppDownloadCards;
                    angular.forEach(videoResponse,function(value,key){
                        angular.forEach(value,function(val,k){
                            obj = {
                                'cardId' : val.id,
                                'preview_url':val.preview_url,                               
                                'created_at':val.created_at,
                                'image':val.video_poster_url,
                                'countryCode':val.app_country_code,
                                'appCta':val.app_cta,
                                'cardname':val.name
                                
                            }
                           $scope.tweetedArrayVideo.push(obj); 
                        })
                    })
                }else{
                     $scope.mainLoader = "none";
                    $scope.showErrorPopup(response);
                }
            }))
            $q.all(promises).finally(
                    function(){                        
                        $scope.gettargetingcriteria();
                    });
        }
        $scope.countrycode = "";
        $scope.showpreview = function (id, val) {
            angular.element("#galleryArray" + val).css("border", "1px solid #169f92");
            var i = 0;
            angular.forEach($scope.tweetedArray1, function (value, key) {

                if (id != value.cardId) {
                    angular.element("#galleryArray" + i).css("border", "1px solid #e1e1e1");
                }
                i++;
            });
            
            for (var i = 0; i < $scope.tweetedArray1.length; i++)
            {
                if ($scope.tweetedArray1[i].cardId == id) {

                    $scope.headline = $scope.tweetedArray1[i].headline;
                    $scope.websiteUrl = $scope.tweetedArray1[i].preview_url;
                    $scope.card.cardName = $scope.tweetedArray1[i].cardname;
                    $scope.card.country = $scope.tweetedArray1[i].countryCode;
                    $scope.card.ctavalue = $scope.tweetedArray1[i].appCta;
                    
                }
            }
        }


        $scope.selectcountry = function (value)
        {
            console.log(value);
            if (value == '' || value == null || value == undefined)
            {
                console.log("if");
            } else
            {
                console.log("else");
            }
        }

        //Sandbox VERSION
        $scope.checkedTweet = [];
        $scope.checkTweet = 0;
        $scope.setTweetCheck = function (item) {
            $scope.tweetObj = {};
            $scope.tweetObj.tweetsChecked = [];
            $scope.tweetObj.tweetsUnChecked = [];
            $scope.multipleTweetId = [];
            $scope.multipleTweetMediaURL = [];
            $scope.webpreviewTweets1 = [];
            $scope.multipleTweetIFrameURL = [];
            var index = $scope.checkedTweet.indexOf(item);
            if (index > -1) {
                $scope.checkedTweet.splice(index, 1);
            } else {
                $scope.checkedTweet.push(item);
            }
            $(".tableRowContent input:checkbox").each(function () {
                var $this = $(this);
                $scope.totalItems = angular.element($('.tweetcount')).html();
                $scope.totalItemsCount = parseInt($scope.totalItems);
                if ($this.is(":checked")) {                   
                    $scope.tweetObj.tweetsChecked.push($this.attr("id"));
                    $scope.checkTweet = $scope.tweetObj.tweetsChecked.length;
                    if($scope.checkTweet == 1){
                       $scope.carouselFlow = 1; 
                    }
                    if($scope.checkTweet > $scope.carouselFlow){
                        angular.element('.naviButtons #right').css('pointer-events', 'auto');
                    }
//                    if ($scope.checkedTweet.length > 1) {
//                        if($scope.carouselFlow == 1){
//                            angular.element('.naviButtons #left').css('pointer-events', 'none');
//                            angular.element('.naviButtons #right').css('pointer-events', 'auto');
//                        }else {
//                            angular.element('.naviButtons #right').css('pointer-events', 'auto');
//                            angular.element('.naviButtons #left').css('pointer-events', 'auto');
//                        }
//                        
//                    } else {
//                        angular.element('.naviButtons #right').css('pointer-events', 'none');
//                        angular.element('.naviButtons #left').css('pointer-events', 'none');
//                    }
                    angular.element($('#step1').css('background-color', 'rgb(149, 210, 177)'));
                    angular.element($('#step2').css('background-color', 'rgb(149, 210, 177)'));
                    angular.element('.creativePreviewBlock').css('pointer-events', ' auto');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));

                } else {
                    if ($scope.carouselFlow > $scope.checkTweet) {
                        $scope.carouselFlow = $scope.checkTweet;
                        angular.element('.naviButtons #left').css('pointer-events', 'auto');
                        $('#collapseOne1').removeClass('in');
                        $('#collapseTwo1').removeClass('in');
                        $('#collapseThree1').removeClass('in');
                    }
                    //$scope.carouselFlow = 1;
                    $scope.tweetObj.tweetsUnChecked.push($this.attr("id"));
                    $scope.checkTweet = $scope.tweetObj.tweetsChecked.length;
                    if ($scope.checkTweet >= 1) {
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                    } else {
                        angular.element($('.btnCampaignCreative').prop('disabled', true));
                        $window.localStorage.setItem("multipleTweetId", " ");
                        angular.element($('#step1').css('background-color', '#C2C2C2'));
                        angular.element('.creativePreviewBlock').css('pointer-events', ' none');
                        angular.element($('#step2').css('background-color', '#C2C2C2'));

                    }
                }
            });

            for (var i = 0; i < $scope.tweetObj.tweetsChecked.length; i++) {
                var twChk = $scope.tweetObj.tweetsChecked[i]; 
                $scope.multipleTweetId.push($scope.tweetsArray[twChk].tweeterID);
                if ($scope.multipleTweetIdedit.includes($scope.tweetsArray[twChk].tweeterID) == false) {
                    $scope.multipleTweetIdedit.push($scope.tweetsArray[twChk].tweeterID);
                }
                $window.localStorage.setItem("multipleTweetId", $scope.multipleTweetId);
                $scope.multipleTweetIFrameURL.push($scope.tweetsArray[twChk].IFrameURL);
                $window.localStorage.setItem("multipleTweetIFrameURL", $scope.multipleTweetIFrameURL);
            }

        }

        $scope.deleteImg = function () {
            $scope.uploading = true;
            $scope.previewing = false;
        }

        $scope.deleteImgCard = function () {
            $scope.uploadingcard = true;
            $scope.previewingcard = false;
        }


        //Carousel navigation
        $scope.expand = function () {
            if ($scope.iosexpand == true) {
                $('#accr1').removeClass('collapsed');
                $('#collapseOne1').addClass('in');

                $scope.iphonePreview();
            }

            if ($scope.androidexpand == true) {
                $('#accr2').removeClass('collapsed');
                $('#collapseTwo1').addClass('in');
                $scope.androidPreview();
            }
            if ($scope.desktopexpand == true) {
                $('#accr3').removeClass('collapsed');
                $('#collapseThree1').addClass('in');
                $scope.webPreview();
            }
        }
        $scope.carouselincr = 0;
        $scope.rightNavCtrl = function (obj) {
            $scope.trustedHtml = "";
            $scope.trustedHtmliphone = "";
            $scope.trustedHtmlandroid = "";
            
//            if ($scope.campaignState != "edit") {
//                angular.element('.naviButtons #left').css('pointer-events', 'auto');
//                if ($scope.multipleTweetId.length > $scope.rightNavCtrlbtn) {
//                    $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn + 1);
//                    $scope.rightNavCtrlbtn = $scope.ctrlLimt;
//                }
//
//                if ($scope.carouselFlow < $scope.checkTweet) {
//                    $scope.carouselincr = $scope.carouselincr + 1;
//                } else {
//                    angular.element('.naviButtons #right').css('pointer-events', 'none');
//                }
//
//            } else {
//                if ($scope.promotedtweetID.length > ($scope.rightNavCtrlbtn + 1)) {
//                    console.log($scope.promotedtweetID.length);
//                    $scope.ctrlLimt = parseInt($scope.rightNavCtrlbtn + 1);
//                    $scope.carouselFlow = $scope.carouselFlow + 1;
//                    $scope.rightNavCtrlbtn = $scope.ctrlLimt;
//                }
//
//                if ($scope.carouselFlow < $scope.checkTweet) {
//                    $scope.carouselFlow = $scope.carouselFlow + 1;
//                }
//            }
//            
//            if($scope.carouselFlow <= $scope.checkTweet){
//                 angular.element('.naviButtons #right').css('pointer-events', 'auto');
//                 
//            }else{
//                angular.element('.naviButtons #right').css('pointer-events', 'none');
//            }

              if ($scope.carouselFlow == 1) {
                angular.element('.naviButtons #left').css('pointer-events', 'none');
            }else{
                angular.element('.naviButtons #left').css('pointer-events', 'auto');
            }
            if ($scope.carouselFlow < $scope.checkTweet) {
                angular.element('.naviButtons #right').css('pointer-events', 'auto');
                $scope.carouselFlow = $scope.carouselFlow + 1;
            } else{
                angular.element('.naviButtons #right').css('pointer-events', 'none');
            }
            $scope.expand();
            if ($scope.carouselFlow <= $scope.checkTweet) {
                angular.element('.naviButtons #right').css('pointer-events', 'auto');
                angular.element('.naviButtons #left').css('pointer-events', 'auto');
            }if($scope.carouselFlow == $scope.checkTweet){
                angular.element('.naviButtons #right').css('pointer-events', 'none');
                angular.element('.naviButtons #left').css('pointer-events', 'auto');
            }
        }

        $scope.leftNavCtrl = function (ctrlLimt) {
            $scope.trustedHtml = "";
            $scope.trustedHtmliphone = "";
            $scope.trustedHtmlandroid = "";
           
            if($scope.carouselFlow > 1){
                $scope.carouselFlow = $scope.carouselFlow - 1;
            }
             $scope.expand();
             if($scope.carouselFlow >1){
                 angular.element('.naviButtons #left').css('pointer-events', 'auto');
             }else{
                 angular.element('.naviButtons #left').css('pointer-events', 'none');
             }
             if ($scope.carouselFlow <= $scope.checkTweet) {
                angular.element('.naviButtons #right').css('pointer-events', 'auto');                
            }if($scope.carouselFlow == $scope.checkTweet){
                angular.element('.naviButtons #right').css('pointer-events', 'none');
                angular.element('.naviButtons #left').css('pointer-events', 'auto');
            }

        }
        $scope.selectedCardNew = true;        

        $scope.selectCards = function (cards) {
            $scope.selectedCardNew = false;
            $scope.card.ctavalue = "";
            $scope.card.country = "";
            $scope.card.cardName = "";
            $scope.selectcard = true;
            $scope.upload = false;
            $scope.cardselectbutton = true;
            $scope.cardbutton = false;            
        }
        $scope.createCards = function () {
            $scope.card.ctavalue = "";
            $scope.card.country = "";
            $scope.selectcard = false;
            $scope.upload = true;
            $scope.cardbutton = true;
            $scope.cardselectbutton = false;            
            $scope.card.cardName = "";
            $scope.ctavalue = "";
            $scope.country = "";
        }
        $scope.sendPrevTweet = function (_id) {
            $scope.webpreviewTweets1 = [];
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_id];
            twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
                if (response.data.appStatus == '0') {
                    $scope.webpreviewTweets1.push(response.data.previewTweet[0].preview);
                    $scope.trustedHtml = $sce.trustAsHtml($scope.webpreviewTweets1);
                } else {
                    $scope.mainLoader = "none";
                }
            })

        }

        $scope.webPreview = function () {
            $scope.twitterPreviewLoader = "block";
            var _key = $scope.carouselFlow - 1;
            $scope.iosexpand = false;
            $scope.androidexpand = false;
            $scope.desktopexpand = true;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            
            if($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")){			
            var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];
            twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                console.log("edit preview");
                if (response.data.appStatus == '0') {
                    $scope.twitterPreviewLoader = "none";
                    $scope.webpreviewTweets = response.data.previewTweet[0].preview;
                    $scope.trustedHtml = $sce.trustAsHtml($scope.webpreviewTweets);
                }
                else {
                    $scope.twitterPreviewLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }
            })
            }
            else{			
			console.log("create preview");
             var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
               // console.log(response);
                if (response.data.appStatus == '0') {
                    $scope.twitterPreviewLoader = "none";
                   // console.log(response.data.successMessage);
                    $scope.webpreviewTweets = response.data.previewTweet[0].preview;
                    $scope.trustedHtml = $sce.trustAsHtml($scope.webpreviewTweets);
                }
                else {
                    $scope.twitterPreviewLoader = "none";
                    console.log(response.data);
                    console.log(response.data.errorMessage);
                    $scope.showErrorPopup(response);
                }
            })
            }
            // });
			$scope.setLine();
        }

        $scope.androidPreview = function () {
            $scope.twitterPreviewLoader = "block";
            var _key = $scope.carouselFlow - 1;
            $scope.androidexpand = true;
            $scope.iosexpand = false;
            $scope.desktopexpand = false;


            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            if ($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")) {
                var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];
                twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                        $scope.androidpreviewTweets = response.data.previewTweet[1].preview;
                        $scope.trustedHtmlandroid = $sce.trustAsHtml($scope.androidpreviewTweets);


                    } else {
                        $scope.twitterPreviewLoader = "none";
                        console.log(response.data);
                        console.log(response.data.errorMessage);
                        $scope.showErrorPopup(response);
                    }


                })
            } else {
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {
                    //console.log(response);
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                        $scope.androidpreviewTweets = response.data.previewTweet[1].preview;
                        $scope.trustedHtmlandroid = $sce.trustAsHtml($scope.androidpreviewTweets);


                    } else {
                        $scope.twitterPreviewLoader = "none";
                        console.log(response.data);
                        console.log(response.data.errorMessage);
                        $scope.showErrorPopup(response);
                    }

                })
            }
            $scope.setLine();
        }


        $scope.iphonePreview = function () {
            $scope.twitterPreviewLoader = "block";
            console.log($scope.carouselFlow);
            var _key = $scope.carouselFlow - 1 ;
            $scope.desktopexpand = false;
            $scope.androidexpand = false;
            $scope.iosexpand = true;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            console.log(JSON.stringify($scope.multipleTweetIdedit,null,2));
            if ($scope.campaignState == "edit" && ($scope.multipleTweetIdedit != "undefined" || $scope.multipleTweetIdedit != "")) {
                console.log($scope.multipleTweetIdedit[_key]);
                var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetIdedit[_key];

                twitterGetPost.previewtweetbyid(queryStr1, data).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                        $scope.iphonepreviewTweets = response.data.previewTweet[2].preview;
                        $scope.trustedHtmliphone = $sce.trustAsHtml($scope.iphonepreviewTweets);

                    } else {
                        $scope.twitterPreviewLoader = "none";
                        $scope.showErrorPopup(response);
                    }
                })
            } else {
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "tweetId=" + $scope.multipleTweetId[_key];
                twitterGetPost.previewtweetbyid(queryStr, data).then(function (response) {                    
                    if (response.data.appStatus == '0') {
                        $scope.twitterPreviewLoader = "none";
                        $scope.iphonepreviewTweets = response.data.previewTweet[2].preview;
                        $scope.trustedHtmliphone = $sce.trustAsHtml($scope.iphonepreviewTweets);

                    } else {
                        $scope.twitterPreviewLoader = "none";
                        $scope.showErrorPopup(response);
                    }
                })

            }
            $scope.setLine();
        }

        $scope.showErrorPopup = function (response) {
            $scope.popupTitle = "Error";
            $scope.popupMessage = response.data.errorMessage;
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }
        $scope.showSuccessPopup = function (response) {
            //console.log('success popup here123');
            $scope.popupTitle = "Twitter creative";
            $scope.popupMessage = response.data.successMessage;
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show();
        }
        $scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            $scope.networkErrorPopup = 'none';
            successReq.hide();
        }

        $scope.callToAction = [
            {
                "id": 1,
                "ctavalue": "INSTALL",
                "ctavaluedesc": "Install",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "ctavalue": "PLAY",
                "ctavaluedesc": "Play",
                "description": null,
                "code": null
            }, {
                "id": 3,
                "ctavalue": "SHOP",
                "ctavaluedesc": "Shop",
                "description": null,
                "code": null
            }, {
                "id": 4,
                "ctavalue": "BOOK",
                "ctavaluedesc": "Book",
                "description": null,
                "code": null
            }, {
                "id": 5,
                "ctavalue": "CONNECT",
                "ctavaluedesc": "Connect",
                "description": null,
                "code": null
            }, {
                "id": 6,
                "ctavalue": "ORDER",
                "ctavaluedesc": "order",
                "description": null,
                "code": null
            },
            {
                "id": 7,
                "ctavalue": "INSTALL_OPEN",
                "ctavaluedesc": "Install Open",
                "description": null,
                "code": null
            }

        ];
    }]);
