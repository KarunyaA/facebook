dashboard.controller("twitterCampaigntemplateController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window','appSettings','globalData','netWorkData',
function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData) {
    var vm = this;
    var apiTPBase = appSettings.apiTPBase;
    var apiBase = appSettings.apiBase;
    vm.showDetails = true;
    vm.home = {}; 
    $scope.predicate = 'name';  
    $scope.reverse = true;  
    $scope.currentPage = 1; 
	$scope.formChangeCount0;
	$scope.overLay = false;
        var stateArray =[];
         $scope.gotoMyCampaign=function(){
            $state.go('app.parentcampaign');
        }
        if($window.localStorage.getItem("marketingObjective") == "TWEET_ENGAGEMENTS"){
            stateArray=["app.twittercampaigndetails","app.twEngCampaignaudience","app.twEngCampaignplan","app.twEngCampaigncreative","app.twittercampaignsummary"];
        }else if($window.localStorage.getItem("marketingObjective") == "WEBSITE_CLICKS"){
            stateArray=["app.twittercampaigndetails","app.webVisitsCampaignaudience","app.webVisitsCampaignplan","app.webVisitsCampaigncreative","app.twittercampaignsummary"];
        }else if($window.localStorage.getItem("marketingObjective") == "VIDEO_VIEWS"){
            stateArray=["app.twittercampaigndetails","app.videoViewsCampaignaudience","app.videoViewsCampaignplan","app.videoViewsCampaigncreative","app.twittercampaignsummary"];
        }else if($window.localStorage.getItem("marketingObjective") == "FOLLOWERS"){
            stateArray=["app.twittercampaigndetails","app.followersCampaignaudience","app.followersCampaignplan","app.followersCampaigncreative","app.twittercampaignsummary"];
        }else if($window.localStorage.getItem("marketingObjective") == "AWARENESS"){
            stateArray=["app.twittercampaigndetails","app.awarenessCampaignaudience","app.awarenessCampaignplan","app.awarenessCampaigncreative","app.twittercampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "APP_INSTALLS"){
            stateArray=["app.twittercampaigndetails","app.installsofyourappCampaignaudience","app.installsofyourappCampaignplan","app.installsofyourappCampaigncreative","app.twittercampaignsummary"];
        }
        
        else{
            stateArray=["app.twittercampaigndetails","app.twEngCampaignaudience","app.twEngCampaignplan","app.twEngCampaigncreative","app.twittercampaignsummary"];
        }
        
       
        
    
	
	$scope.global = $rootScope;
	$scope.init = function(){
		$scope.overLay = false;
		$rootScope.freezeFlag = false;
		angular.element($('body').css("overflow-y", "scroll"))
		var campaignState = $window.localStorage.getItem("campaignState");
		$rootScope.formChangeCount=0;
		/* $scope.$watch('faceBookFormData',function(newValue, oldValue) {
			if(newValue != oldValue) {
				$rootScope.formChangeCount++;
				console.log('$rootScope.formChangeCount >> '+$rootScope.formChangeCount);
				if($rootScope.formChangeCount>1 && $window.localStorage.getItem("role") != 'Account'){
					//$scope.overLay = true;
					//$rootScope.freezeFlag=true;
				}				
			} else {
				console.log('form not changed ::' + $rootScope.freezeFlag + " Count::" +$rootScope.formChangeCount);
				
			}
		},true); */
		
		function checkNav(){
			angular.forEach($rootScope.campaignSteps, function(value, key){
				//console.log($rootScope.campaignSteps);
				if($rootScope.campaignSteps[key] == true){
					angular.element($('menu'+(key+1)).addClass('addCursor'));
				} else {
					angular.element($('menu'+(key+1)).removeClass('removeCursor'));
					//console.log('remove');
				}					
			});
		}
	
		var timer = setInterval(checkNav(), 500)
	
		$scope.navigateSteps = function(_this){
			/* var flag = $window.localStorage.getItem("isChildCampaignEdit")
			if(flag == "true"){
				console.log($window.localStorage.getItem("isChildCampaignEdit"))
				var keyVal = stateArray[_this-1].split('.')[1]
				console.log(stateArray[_this-1])
				$state.go(stateArray[_this-1]);
			} else {
				console.log($rootScope.campaignSteps[_this-1])
				if($rootScope.campaignSteps[_this-1]){
					$state.go(stateArray[_this-1]);
				}
			} */
			console.log($rootScope.campaignSteps[_this-1]);
			if($rootScope.campaignSteps[_this-1]){
				$window.localStorage.setItem("campaignState", 'edit');  
				$state.go(stateArray[_this-1]);
			}
			
			 
			//console.log(stateArray[_this-1])
			//$state.go(stateArray[_this-1]);
		}
		
	}
	
    $scope.init();
}]);