dashboard.controller("campaignController", ['$rootScope', '$scope', '$http', '$state', '$location', 'loginService', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', '$filter', '$timeout', 'netWorkData', 'facebookGetPost',
    function ($rootScope, $scope, $http, $state, $location, loginService, Flash, apiService, $window, appSettings, globalData, $filter, $timeout, netWorkData, facebookGetPost) {

        var vm = this;
        vm.getData = {};
        vm.setSet = {};

        $scope.editAdsetErrorMsg = 'none';
        $scope.firstActiveDiv = 'yes';

        $scope.firstActiveDivImg = false;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        //$scope.progressLoader = "none";
        var apiTPBase = appSettings.apiTPBase;
        vm.showDetails = true;
        $scope.campaignplan = [];
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.objective = ''; //Test variable, Not needed remove this decularation
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};
        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        $scope.tempObjective = ""
        $scope.name = ""
        $scope.failure_update_popup = false;
        $scope.campaignDetails;
        $scope.popFlag = false;
        $scope.adminUserRole = false;
        $scope.abc = 0;
        $scope.objectiveFlag = false;
        $scope.nameFlag = false;
        $scope.formChangeCount = 0;
        $scope.isDirty;
        $scope.duplicateCampaignStep = [false, false, false, false, false];
        var adsetId;

        $scope.init = function () {
            //------------------------------------------
            $rootScope.faceBookFormData = vm.getData;
            //------------------------------------------
            $rootScope.step = 1;
            if ($rootScope.campaignSteps[0] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }

            angular.element($('body').css("overflow-y", "scroll"));
            var campaignState = $window.localStorage.getItem("campaignState")
            if (campaignState == "create") {
                var campaignId = $window.localStorage.getItem("campaignId");
                if (campaignId != null && campaignId != undefined && campaignId != " ") {
                    var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                    if (campaignDetails) {
                        //$rootScope.campaignState = "update"
                        $window.localStorage.setItem("campaignState", $rootScope.campaignState)
                        $scope.prePopulateFromLocalStorage(campaignDetails)
                    } else {
                        $scope.getEditCampaignDetails();
                    }
                } else {
                    $scope.todayDate = new Date();
                    $scope.minDate = new Date();
                    $scope.campaignplan.accountCountryName = "India"
                    $scope.campaignplan.currency = "Indian Rupee"
                    $scope.campaignplan.description = "Asia/Kolkata"
                    $scope.campaignplan.adAccName = "Digi Live"
                    $scope.campaignplan.advertSetName = "createAdsetTest1"
                }
            }
            if (campaignState == "update") {
                var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.prePopulateFromLocalStorage(campaignDetails)
                //$scope.getEditCampaignDetails();
            }
            if (campaignState == "edit") {
                if ($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;
                } else {
                    $scope.adminUserRole = false;
                }
                var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.getEditCampaignDetails();
            }


        }
        $scope.prePopulateFromLocalStorage = function (cDetails) {
            vm.getData.objective = cDetails.data.campaignDetails.objective;
            vm.getData.campaignName = cDetails.data.campaignDetails.name;
            $scope.tempObjective = cDetails.data.campaignDetails.objective;
            $scope.name = cDetails.data.campaignDetails.name;

        }


        $scope.getEditCampaignDetails = function () {
            var campaignStatus = $rootScope.campaignStatus;
            var campaignId = $rootScope.campaignId;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&adCampaignId=" + campaignId;

            facebookGetPost.readadcampaign(queryStr, headers).then(function (response) {
                console.log(response);
                $rootScope.progressLoader = "none";
                if (response.data.appStatus == '0') {
                    $scope.campaignDetails = globalData.getKeyValues(response, campaignId)
                    //console.log($scope.campaignDetails)
                    if (campaignStatus == 'draft') {
                        //globalData.setDraftLocal("campaign", campaignId, $scope.campaignDetails)
                        //$scope.prePopulateValues($scope.campaignDetails)
                    } else {
                        //console.log($scope.campaignDetails)
                        globalData.setLocal("campaign", campaignId, $scope.campaignDetails)
                        $scope.prePopulateFromDBStorage($scope.campaignDetails)
                    }

                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
            adsetId = $window.localStorage.getItem("adsetId");
            if (adsetId != 'undefined' && adsetId != '' && adsetId != null && adsetId != 'null') {
                angular.element('#campaignObjectiveSection').css("pointer-events", "none");
            }

        }
        $scope.prePopulateFromDBStorage = function (cDetails) {
            vm.getData.objective = cDetails.campaignDetails.objective;
            vm.getData.campaignName = cDetails.campaignDetails.name;
            $scope.tempObjective = cDetails.campaignDetails.objective;
            $scope.name = cDetails.campaignDetails.name;

        }
        $scope.$watch('vm.getData.objective', function (newVal, oldVal) {

            if (newVal) {
                $window.localStorage.setItem("marketingObjective", newVal);
                $scope.objectiveFlag = true;
                var SObj = $filter('filter')($scope.objectiveArray, function (d) {
                    return d.Key === newVal;
                }, true)[0];
                //console.log(SObj)
                $window.localStorage.setItem("marketingObjectiveName", SObj.Value);

                angular.element('#step1').css('background-color', '#95D2B1');
                //angular.element('.is-div-disabled').css('opacity', 1);
                angular.element('.is-div-disabled').css('pointer-events', 'auto');
            }
        }, true)

        $scope.$watch('vm.getData.campaignName', function (newVal, oldVal) {
            if (newVal) {
                $scope.nameFlag = true;
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#mandatory').removeClass("required");
            } else {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element('#mandatory').addClass("required");
            }
        }, true)


        /*Added for Summary page show Need to be removed*/
        /*$window.localStorage.setItem("campaignAudienceTargetType", $scope.campaignAudienceTargetType);
         $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceTarget);
         
         $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);
         $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
         $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
         $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
         $window.localStorage.setItem("campaignAudienceLanguage", $scope.campaignAudienceLanguage);
         $window.localStorage.setItem("campaignaudienceDetailedTargeting", $scope.campaignaudienceDetailedTargeting);
         $window.localStorage.setItem("campaignAudienceConnection", $scope.campaignAudienceConnection);
         $window.localStorage.setItem("campaignAudiencePlacements", $scope.campaignAudiencePlacements);
         $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);*/



        $scope.objectiveValue = $window.localStorage.getItem("objective");
        $scope.campaignNamevalue = $window.localStorage.getItem("tempCampaignName");
        $scope.LocationValue = $window.localStorage.getItem("campaignAudienceLocations");
        $scope.agefromValue = $window.localStorage.getItem("campaignAudienceAgeFrom");
        $scope.agetoValue = $window.localStorage.getItem("campaignAudienceAgeTo");
        $scope.genderValue = $window.localStorage.getItem("campaignAudienceGender");
        $scope.languagesValue = $window.localStorage.getItem("campaignAudienceLanguage");
        //$scope.detailTargetingValue = $window.localStorage.getItem("campaignaudienceDetailedTargeting");
        $scope.mobileDeviceValue = $window.localStorage.getItem("campaignAudienceMobileDevice");

        $scope.mobileDeviceValue_1 = $window.localStorage.getItem("MFeedcampaignAudiencePlacements");
        $scope.mobileDeviceValue_2 = $window.localStorage.getItem("DFeedcampaignAudiencePlacements");
        $scope.mobileDeviceValue_3 = $window.localStorage.getItem("DRColumncampaignAudiencePlacements");

        $scope.mobilenewfeed = $scope.mobileDeviceValue_1 + " " + $scope.mobileDeviceValue_2 + " " + $scope.mobileDeviceValue_3;


        /*End of summary Page Temp Variables*/
        $scope.selectBudget = function (_obj) {

            if (_obj.name == "Daily Budget") {
                $scope.campaignplan.budgetValue = "20"
            } else {
                $scope.campaignplan.budgetValue = "50"
            }
        }
        $scope.selectAdvertDelivery = function (_obj) {
            $scope.campaignplan.advertDelivery = _obj.name

        }
        $scope.selectSchedule = function (value) {
            if (value == 1) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:ss');
            }
        }
        $scope.onDateChange1 = function (selectedDate) {
            $scope.startDate = selectedDate

            var _date = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');

            if ($scope.startDate > $scope.todayDate) {
                $scope.campaignplan.scheduleStartDate = $filter('date')(new Date($scope.startDate), 'yyyy-mm-dd HH:mm:ss');
            } else {
                //console.log('less than')
            }
        }
        $scope.onDateChange2 = function (selectedDate) {
            $scope.endDate = selectedDate
            //console.log($scope.endDate)
            if ($scope.endDate > $scope.startDate) {
                $scope.campaignplan.scheduleEndDate = $filter('date')(new Date($scope.endDate), 'yyyy-mm-dd HH:mm:ss');
                //console.log($scope.campaignplan.scheduleEndDate)
            } else {
                //console.log('less than')
            }
        }
        $scope.selectBidAmount = function (value) {
            if (value == 1) {
                $scope.showText = false;
                $scope.campaignplan.bidAmount = "1000"
            } else {
                $scope.showText = true;
            }
        }
        $scope.saveBidAmount = function (value) {
            $scope.campaignplan.bidAmount = value;

        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
            $rootScope.freezeFlag = false;
        }
        $scope.init();
        var everythingLoaded = setInterval(function () {
            if (/loaded|complete/.test(document.readyState)) {
                clearInterval(everythingLoaded);
                $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                var offsetHeight2 = document.getElementById('step2container').offsetHeight;
                var fStep = $(".vr");
                fStep.css('height', (($scope.lsValue - $scope.fsValue) - (offsetHeight2 + 22)));
            }
        }, 10);
        /*  $scope.postCampaignPlan = function (data) {
         console.log($scope.campaignplan)
         
         var headers = {
         "Content-Type": "application/json"
         }
         
         var parameters = {
         "userId": $window.localStorage.getItem("userId"),
         "accessToken": $window.localStorage.getItem("accessToken"),
         "networkAdAccountId": "114680145658525",
         "dailyBudget": $scope.campaignplan.budgetValue,
         "isAutobid": "true",
         "adlabels": [
         {"name": "adLabelN1"}
         ],
         "name": $scope.campaignplan.advertSetName,
         "billingEvent": "IMPRESSIONS",
         "campaignId": "23842529546860715",
         "targeting": {
         "geo_locations": {
         "countries": ["US"]}
         },
         "status": "PAUSED",
         //"networkAccessToken": "EAAFMB7HwTnoBAE5hdTzFbPQgcKsGOaOX9RUWpZAshWv7dMxqTHx7TbofgdUpWClS5qlz0IhskZCWK7Rkd1Voo8YgcgIlvsGsH5ijA4FX7AqiFgQuIzOdYFgKr1bfAmEOGEKuGbq9afcssTBDj3u52YVOOKuTMwIXPcXVO8uQZDZD",
         "networkAccessToken" : $window.localStorage.getItem("networkAccessToken"),
         "userNetworkMapId": "300013"
         }
         }*/
        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */
        $scope.result = 'pass';

        function getCampaignDetailsFromFB(campaignId) {

            var headers = {
                "userId": $scope.userId,
                "accessToken": $scope.accessToken
            }
            var queryStr = "?campaignId=" + $window.localStorage.getItem('campaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            facebookGetPost.getcampaignbycampaignid(queryStr, headers).then(function (response) {

                if (response.data.appStatus == '0') { // success
                    //console.log(response.data.campaign);
                    getNetWorkMapId(response.data.campaign, campaignId)

                } else { // failed

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.popupTitle = "Error";
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.popupMessage = response.errorMessage + '. ' + response.networkError.error_user_msg;
                        } else {
                            $scope.popupMessage = response.errorMessage;
                        }
                        $scope.showPopup();
                    }
                }
            })

        }
        //
        function getNetWorkMapId(response, campaignId) {

            /*$http({
             method: 'GET',
             url: apiTPBase+"/getfbuserid?networkMapId=300002",
             headers: {
             'userId': $window.localStorage.getItem("userId"),
             'accessToken': $window.localStorage.getItem("accessToken")
             }
             }).then(function(response) {
             
             if (response.data.appStatus == '0') {// success
             console.log(response.data.fbUserId);
             saveCampaignDataToLocalDB(response, campaignId,response.data.fbUserId);
             } else {// failed
             
             
             }
             });*/
            saveCampaignDataToLocalDB(response, campaignId);
        }

        function saveCampaignDataToLocalDB(response, campaignId) {

            //console.log($window.localStorage.getItem("parentCampaignId"))
            var networkMapId = $window.localStorage.getItem("userNetworkMapId");
            var sTime = response.start_time;
            if (response.start_time.indexOf('1970') == 0) {
                sTime = response.updated_time;
            }
            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": networkMapId,
                "parentCampaignId": $window.localStorage.getItem("parentCampaignId"),
                "adAccountId": response.account_id,
                "campaignId": campaignId,
                "campaignDetails": {
                    "id": campaignId,
                    "account_id": response.account_id,
                    "buying_type": "AUCTION",
                    "can_use_spend_cap": true,
                    "configured_status": "PAUSED",
                    "created_time": response.created_time,
                    "effective_status": "PAUSED",
                    "name": response.name,
                    "objective": response.objective,
                    "spend_cap": "5000000",
                    "start_time": sTime,
                    "status": "PAUSED",
                    "updated_time": response.updated_time
                }
            }
            //console.log($window.localStorage.getItem("campaignState"))
            //console.log(parameters)
            if ($window.localStorage.getItem("campaignState") == "create") {

                globalData.setLocal("campaign", campaignId, parameters);
                //globalData.setDraftLocal("campaign", campaignId, parameters);
                $window.localStorage.setItem("lastStep", 2);
            }
            if ($window.localStorage.getItem("campaignState") == "update") {
                globalData.setLocal("campaign", campaignId, parameters);
            }
            if ($window.localStorage.getItem("campaignState") == "edit") {
                globalData.setLocal("campaign", campaignId, parameters);
            }
            if ($window.localStorage.getItem("campaignState") == "draftEdit") {
                globalData.setDraftLocal("campaign", campaignId, parameters);
                $window.localStorage.setItem("lastStep", 2);
            }

            facebookGetPost.savecampaigndata("", parameters).then(function (response) {

                //console.log(response);
                $rootScope.progressLoader = "none";
                angular.element($('body').css("overflow-y", "scroll"))
                if (response.data.appStatus == '0') { // success
                    //console.log('campaign details saved successfully')
                    //globalData.setLocal("campaign", campaignId, parameters)
                    $rootScope.flg = true;
                    $scope.moveNextStep()

                } else { // failed
                    //console.log('save campaign failed');
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    ;
                    $scope.popupTitle = "Save Failed";
                    $scope.popupMessage = "Save campaign failed";
                    $scope.showPopup();
                }

            });

        }
        $scope.moveNextStep = function () {
            $rootScope.campaignSteps[0] = true;
            //$state.go('app.bypcampaignaudience');
            if ($window.localStorage.getItem("marketingObjective") == "POST_ENGAGEMENT") {
                $state.go('app.bypcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                $state.go('app.pypcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "REACH") {
                $state.go('app.rpcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "BRAND_AWARENESS") {
                $state.go('app.ibacampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "LINK_CLICKS") {
                $state.go('app.spcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "APP_INSTALLS") {
                $state.go('app.apinstcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "EVENT_RESPONSES") {
                $state.go('app.eventscampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "VIDEO_VIEWS") {
                $state.go('app.videocampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "LEAD_GENERATION") {
                $state.go('app.leadscampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "CONVERSIONS") {
                $state.go('app.convcampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "OFFER_CLAIMS") {
                $state.go('app.offerscampaignaudience');
            }

        }
        //

        vm.createCampaignObjective = function (data) {

            $scope.isDirty = $scope.createCampaignForm.$dirty;
            if ($scope.isDirty) {
                //---------------------------
                $rootScope.freezeFlag = false;
                //---------------------------
                $rootScope.progressLoader = "block";
                if (data.objective == undefined) {
                    alert('Please Select Marketing Objective');
                    return true;
                }
                if ($window.localStorage.getItem("campaignState") != "create") {
                    $scope.editAndUpdateCampaignDetails();
                } else {
                    //            console.log($scope.objectiveFlag);
                    //console.log($scope.nameFlag);                                                             
                    loginService.campService(data).then(function (response) {
                        //console.log(response);
                        if (response.appStatus == 0) {
                            //console.log(response.campaignId);
                            $window.localStorage.setItem("campaignId", response.campaignId);
                            $window.localStorage.setItem("objective", data.objective);
                            getCampaignDetailsFromFB(response.campaignId);

                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.popupTitle = "Error";
                            if (response.networkError != '' && response.networkError != undefined) {
                                $scope.popupMessage = response.errorMessage + '. ' + response.networkError.error_user_msg;
                            } else {
                                $scope.popupMessage = response.errorMessage;
                            }
                            $scope.showPopup();
                            //Flash.create('danger', response.errorMessage, 'large-text');
                        }

                    });
                }
            } else {
                $scope.moveNextStep();
            }




        };
        $scope.showPopup = function () {
            $scope.popFlag = true;
            $rootScope.progressLoader = "none";
            angular.element($('body').css("overflow-y", "scroll"))

            var modalApproveReq = $(".update_modalApprove");// Get the modal Approve req
            modalApproveReq.show();
        }
        $scope.resetSelection = function () {

            $rootScope.progressLoader = "none";
            angular.element($('body').css("overflow-y", "scroll"));
            $scope.failure_update_popup = false;
            var modalApproveReq = $(".update_modalApprove");// Get the modal Approve req
            //console.log(modalApproveReq)
            modalApproveReq.hide();
            //$scope.moveNextStep();         
        }
        $scope.editAndUpdateCampaignDetails = function () {



            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "campaignId": $window.localStorage.getItem('campaignId'),
                "name": vm.getData.campaignName
            }
            if (adsetId == '' || adsetId == null || adsetId == 'null' || adsetId == undefined) {
                parameters["objective"] = vm.getData.objective;
            }
            facebookGetPost.updatecampaign("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {
                    //$scope.moveNextStep();                                                         
                    getCampaignDetailsFromFB($window.localStorage.getItem('campaignId'));
                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    $rootScope.progressLoader = "none";
                    angular.element($('body').css("overflow-y", "scroll"))
                    //if(!$scope.popFlag) {
                    $scope.popupTitle = "Update Failed";
                    $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.error_user_msg;
                    $scope.showPopup();
                    //}

                }

            })
        }
        vm.campSummaryAction = function (data) {
            loginService.campSummaryService(data).then(function (response) {
                //alert(":: "+response.success);
                if (response.success == true) {
                    $scope.successPopup();
                } else {
                    $scope.successPopup();
                    //Flash.create('danger', "Connection Issue with Facebook", 'large-text');
                }
            });
        };

        //-------------------------------
        /*$scope.campaignplan =[
         {
         "accountCountryName": "India",
         "currency": "Indian Rupee",
         "description": "Asia/Kolkata",
         "adAccName": "Digi Live",
         "advertSetName":"createAdsetTest1"
         }
         ];*/
        /*   $scope.campaignplan =[
         {
         "accountCountryName": "India",
         "currency": "Indian Rupee",
         "description": "Asia/Kolkata",
         "adAccName": "Digi Live",
         "budgetValue":"",
         "scheduleStartDate":"",
         "scheduleEndDate":"",
         "advertSetName":"createAdsetTest1",
         "advertDelivery":"",
         "bidAmount":""
         }
         ];
         */

        //----------------------------

        $scope.accountItems = [{
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }]
        $scope.currencyItems = [{
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }]
        $scope.timeZoneItems = [{
                "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
            }]
        $scope.budgetItems = [{
                "id": 1,
                "name": "Daily Budget",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Lifetime Budget",
                "description": null,
                "code": null
            }]
        $scope.advertItems = [{
                "id": 1,
                "name": "NONE",
                "description": null,
                "code": null
            },
            {
                "id": 2,
                "name": "APP_INSTALLS",
                "description": null,
                "code": null
            },
            {
                "id": 3,
                "name": "BRAND_AWARENESS",
                "description": null,
                "code": null
            },
            {
                "id": 4,
                "name": "CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 5,
                "name": "ENGAGED_USERS",
                "description": null,
                "code": null
            },
            {
                "id": 6,
                "name": "EXTERNAL",
                "description": null,
                "code": null
            },
            {
                "id": 7,
                "name": "EVENT_RESPONSES",
                "description": null,
                "code": null
            },
            {
                "id": 8,
                "name": "IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 9,
                "name": "LEAD_GENERATION",
                "description": null,
                "code": null
            },
            {
                "id": 10,
                "name": "LINK_CLICKS",
                "description": null,
                "code": null
            },
            {
                "id": 11,
                "name": "OFFER_CLAIMS",
                "description": null,
                "code": null
            },
            {
                "id": 12,
                "name": "OFFSITE_CONVERSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 13,
                "name": "PAGE_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 14,
                "name": "PAGE_LIKES",
                "description": null,
                "code": null
            },
            {
                "id": 15,
                "name": "POST_ENGAGEMENT",
                "description": null,
                "code": null
            },
            {
                "id": 16,
                "name": "REACH",
                "description": null,
                "code": null
            },
            {
                "id": 17,
                "name": "SOCIAL_IMPRESSIONS",
                "description": null,
                "code": null
            },
            {
                "id": 18,
                "name": "VIDEO_VIEWS",
                "description": null,
                "code": null
            },
            {
                "id": 19,
                "name": "APP_DOWNLOADS",
                "description": null,
                "code": null
            }
        ];
        var modalSuccessPop = $(".success-popup"); // Get the modal Success req
        $scope.successPopup = function () {
            modalSuccessPop.show();
        }
        $scope.closeSuccessPopup = function () {
            modalSuccessPop.hide();
        }


        $scope.objectiveArray = [
            {Key: "APP_INSTALLS", Value: "Get installs of your app"},
            {Key: "BRAND_AWARENESS", Value: "Increase brand awareness"},
            {Key: "EVENT_RESPONSES", Value: "Raise attendance at your events"},
            {Key: "CANVAS_APP_ENGAGEMENT", Value: "Increase engagements on your app"},
            {Key: "LEAD_GENERATION", Value: "Collect leads for your business"},
            {Key: "LINK_CLICKS", Value: "Send people to your website"},
            {Key: "OFFER_CLAIMS", Value: "Get people to claim your offer"},
            {Key: "CONVERSIONS", Value: "Increase conversions on website"},
            {Key: "PAGE_LIKES", Value: "Promote your page"},
            {Key: "POST_ENGAGEMENT", Value: "Boost your posts"},
            {Key: "REACH", Value: "Reach people near your business"},
            {Key: "VIDEO_VIEWS", Value: "Get video views"}

        ];

    }
]);
