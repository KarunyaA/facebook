dashboard.controller("offerscampaigncreativeController", ['$rootScope', '$scope', '$http', '$q', '$state', '$location', 'dashboardService', 'apiService', 'Flash', '$window', 'appSettings', '$sce', '$timeout', 'globalData','$animate','$filter','facebookGetPost',
function ($rootScope, $scope, $http, $q, $state, $location, dashboardService, apiService, Flash, $window, appSettings, $sce, $timeout, globalData,$animate, $filter, facebookGetPost) {
	
	$scope.myInterval = 500;
        $scope.imgthumbnaildiv = false;
        $scope.vidthumbnaildiv = false;
	$scope.previewing = false;
        var vm = this;
        vm.getData = {};
        vm.setSet = {};
        var apiTPBase = appSettings.apiTPBase;
        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken"); 
        $scope.fourthActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = true;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.browseImgSuccessMsg = "none";
        $scope.browselibrary = "none";
        $scope.browselibraryvideos = "none";
        $scope.mainLoader = "none";
        $scope.errTextMsg = "none";
        $scope.errHeadlineTextMsg = "none";
        $scope.errLandingviewTextMsg = "none";
        $scope.uniqueArray = [];
        $scope.cardHeadline = [];
		$scope.uniqueImageSelectionArray = [];
		$scope.campaignAudienceCampaignOfferArr = [];		
        $scope.textBodyContent = "";
        $scope.campaignHeadline = "";
		$scope.cardHeadline = "";
		$scope.cardDescription = "";
		$scope.cardwebURL = "";
        $scope.campaignLandingView = "Timeline";
        $scope.hashVal = "";
        $scope.formatSelected = "";
        $scope.imagesSource = "";
        $scope.objectType = 'PHOTO';
        $scope.networkErrorPopup = "none";
	   $scope.slideShowCreate=true;
        $scope.advertCarousel = false;
        $scope.advertSingleImg = false;
        $scope.advertSingleVideo = false;
        $scope.advertSlideshow = false;
        $scope.step2_green=false;
        $scope.valAddWebsiteUrl = false;
        $scope.isHeadline = false;
        $scope.isCreateShowAdvOption = false;
        $scope.editAdsetErrorMsg = 'none';
        $scope.isCarousaltrafficText = false;
		$scope.campaignAudienceCampaignTargetLoader = true;
                $scope.campaignAudienceLandingViewLoader = false;
		/*Carousel advent*/	
		$scope.carouseladvent1 = true;
		$scope.showImgPrev = [];
		$scope.showVideoPrev = [];
		$scope.carouseladventEdit2 = false;
		$scope.carouseladventEdit3 = false;
		$scope.carouseladventEdit4 = false;
		$scope.carouseladventEdit5 = false;
		$scope.carouseladventEdit6 = false;
		$scope.carouseladventEdit7 = false;
		$scope.carouseladventEdit8 = false;
		$scope.carouseladventEdit9 = false;
				
		$scope.selectedImagegalleryArray = []; 
		$scope.selectedImagegalleryArrayVideo = []; 
		$scope.headlinecontents = [];
		 $scope.descriptioncontents = [];
		 $scope.weburlcontents = [];
		$scope.mediaImage = true;
        $scope.mediaVideo = true;
		$scope.carouseladvent = false;
		$scope.imageFormat = "imagemediaUpdate";
		$scope.imagePreviewSrc = "";
		$scope.imagePreviewVideoSrc = "";
		//$scope.showVideoPrev = false;
		//$scope.showImgPrev = false;
		//$scope.imageFormat1 = "videomediaUpdate";
		$scope.mediaarrow=true;
		$scope.previewing = false;
		$scope.counter = 1;
		$scope.isPixelTracking=false;
		$scope.isOfflineTracking=false;
        /*use Exist Post - start */
        $scope.existURLParam = false;
        $scope.exitShowAdvOption = true;
        $scope.exitHideAdvOption = false;
        $scope.selectedTarget = "";
        /*use Exist Post - end*/

        $scope.fbAccessToken = "";
        $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
        // $scope.marketingObjective = "LEAD_GENERATION";

        $scope.desktop = false;
        $scope.mobile = false;
        $scope.rightColumn = false;
        $scope.isLeadGen = false;
        
       // $scope.callToDirectionValue = 0;
        $scope.adminUserRole = false;
		$scope.accordianRole = false;
        $scope.webURL = "";
        $scope.adData = "";
        $scope.campaignEventLoader = false;
        $scope.uploadstep = '2';
        $scope.previewstep = '3';
        $scope.pageTabs = [];
        
        $scope.detectChange = function () {
            if ($rootScope.uploadedfilename == undefined) {
                console.log('no image');
                console.log('yes image');
                $rootScope.progressLoader = 'none';
                if ($scope.thumbnail != '' && $scope.formatSelected == $scope.fbadvertFormat) {
                    if ($scope.fbadvertFormat == "fbsingleimage") {
                        $scope.imgthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if ($scope.fbadvertFormat == "fbsinglevideo") {
                        $scope.vidthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if ($scope.fbadvertFormat == "fbslideshow") {
                        $scope.slideShowCreate = false;
                        $scope.slideShowSuccess = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    }
                }
            }
            else {
                console.log('yes image');
                $rootScope.progressLoader = 'none';
                if ($scope.thumbnail != '' && $scope.formatSelected == $scope.fbadvertFormat) {
                    if ($scope.fbadvertFormat == "fbsingleimage") {
                        $scope.imgthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if ($scope.fbadvertFormat == "fbsinglevideo") {
                        $scope.vidthumbnaildiv = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    } else if ($scope.fbadvertFormat == "fbslideshow") {
                        $scope.slideShowCreate = false;
                        $scope.slideShowSuccess = true;
                        angular.element($('.btnCampaignCreative').prop('disabled', false));
                        angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                        angular.element('.btnCampaignCreative').css('opacity', '1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element('#step3').css('background-color', '#95D2B1');
                        angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                        angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                        angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    }
                }
            }
            document.body.onfocus = null;
        }
        $scope.getFocus = function () {
            $scope.imgthumbnaildiv = false;
            $timeout(function () {
                document.body.onfocus = $scope.detectChange();
            }, 1500);
        }
        
        $scope.checkMandatoryVal = function(){
            if($scope.fbadvertFormat == 'fbsingleimage' || $scope.fbadvertFormat == 'fbsinglevideo' || $scope.fbadvertFormat == 'fbslideshow' || $scope.fbadvertFormat == 'fbcarosel'){
                if($scope.textBodyContent!="" && $scope.textBodyContent!= null && $scope.textBodyContent!= undefined ){
                   angular.element('#step1').css('background-color', '#95D2B1');
                   if($scope.fbadvertFormat == 'fbcarosel'){
                                               $timeout(function () {
                        angular.element('.sectionBrowseCarosel').css('pointer-events', 'auto');
                    }, 1000);

                   }
                }
                else{
                    angular.element('#step1').css('background-color', '#c2c2c2');
                    if($scope.fbadvertFormat == 'fbcarosel'){
                        $timeout( function(){
                            angular.element('.sectionBrowseCarosel').css('pointer-events' , 'none');
                        }, 1000 );
                    }
                    
                }
            }
        };
        $scope.deleteImgThumbnail = function(){
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            $scope.imgthumbnaildiv = false;
           //$scope.deleteAdCreative();
           $scope.removeThumbnail();
        };
        
        $scope.deleteVidThumbnail = function(){
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            $scope.vidthumbnaildiv = false;
           //$scope.deleteAdCreative();
           $scope.removeThumbnail();
           
        };
        
        $scope.removeThumbnail = function (){
            $scope.vidthumbnaildiv = false;
            angular.element('#step2').css('background-color', '#c2c2c2');
            angular.element('#step3').css('background-color', '#c2c2c2');
            angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            angular.element('#collapseOne1').removeClass('in');
            angular.element('#collapseTwo1').removeClass('in');
            angular.element('#collapseThree1').removeClass('in');
            angular.element('.btnCampaignCreative').css('pointer-events', 'none');
            angular.element('.btnCampaignCreative').css('opacity', '0.6');
            $scope.imgthumbnaildiv = false;
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");

            if ($scope.fbadvertFormat == "fbcarosel") {
                $scope.carouseladvent1 = true;
                $scope.carouseladventEdit2 = false;
                $scope.carouseladventEdit3 = false;
                $scope.carouseladventEdit4 = false;
                $scope.carouseladventEdit5 = false;
                $scope.carouseladventEdit6 = false;
                $scope.carouseladventEdit7 = false;
                $scope.carouseladventEdit8 = false;
                $scope.carouseladventEdit9 = false;
                for (var i = 0; i < 10; i++) {
                    //$scope.removeTab(i);
                    $scope.cardHeadline[i] = "";
                    $scope.showImgPrev[i] = false;
                    $scope.showVideoPrev[i] = false;
                    angular.element('.carouseladventEdit2 ').css('left', '140px');
                    if (i >= 2) {
                        //$scope.tabs.splice(i, 1);
                        $scope.tabs = [{
                                title: '1'
                            },
                            {
                                title: '2'
                            }];
                    }

                }

            }

        };
        
        $scope.getPageTabs = function(pageId) {
            var accessToken = "";
            var name = "";
            for(i=0;i<$scope.connectFBVal.length;i++)
            {
                if(pageId == $scope.connectFBVal[i].id)
                {
//                    console.log("page matched");
//                    console.log($scope.connectFBVal[i].access_token);
                    accessToken = $scope.connectFBVal[i].access_token;
                    name = $scope.connectFBVal[i].name;
                }
            }
            if(accessToken != "")
            {
                $scope.pageTabs = [];
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
				}
			   var queryStr = "?pageAccessToken=" + accessToken + "&pageId=" + pageId + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
               
				facebookGetPost.fetchpagetabs(queryStr, headers).then(function(response)
                {
                    if(response.data.appStatus == 0)
                    {
                        var obj = {
                            "name":"Timeline",
                            "urlPart":name.split(" ").join("-") + "-" + pageId + "/"
                        };
                        $scope.pageTabs.push(obj);
                        if($window.localStorage.getItem("campaignState") == "create") {
                            $scope.campaignLandingView = "Timeline";
                        }
                        angular.forEach(response.data.pageTabs,function(value,key)
                        {
                            angular.forEach(value,function(value2,key2)
                            {
                                var obj = {
                                    "name":value2.name,
                                    "urlPart":value2.link
                                }
                                $scope.pageTabs.push(obj);
                            });
                        });
                        $scope.campaignAudienceLandingViewLoader = false;
//                        console.log($scope.pageTabs);
                    }
                    else
                    {
                        $scope.campaignAudienceLandingViewLoader = false;
//                        console.log("fetch page tabs failed");
//                        console.log(response);
                    }
                });
            }
            else
            {
                $scope.campaignAudienceLandingViewLoader = false;
                $scope.pageTabs = [];
                var obj = {
                  "name":"Timeline",
                  "urlPart":name.split(" ").join("-") + "-" + pageId + "/"
                };
                $scope.pageTabs.push(obj);
//                console.log("Page accessToken not found");
            }
        };

        $scope.selectMessenger = function (radioDestination) {
            $scope.radioDestination = radioDestination;
            if (radioDestination == 'MESSENGER') {
                
                $scope.isDisplayLink = false;
                $scope.isWebURL = false;
            } 
		
            $window.localStorage.setItem("radioDestination", $scope.radioDestination);
        }
			$scope.getAdCreativeIdFromFaceBook = function () {
            var adId = $window.localStorage.getItem("adId");
            //var queryStr = adId + "?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&fields=creative";
            var queryStr = "?adId=" + adId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
            facebookGetPost.getcreativeid(queryStr).then(function (response) {
                                                                var resp =response.data.ads;
                                                                angular.forEach(resp, function(val,key)
                                                                {
                                                                                angular.forEach(val, function(val1,key1)
                                                                                {
                                                                                console.log(val[key1]);
                                                                                console.log(val1);
                                                                                $window.localStorage.setItem("adCreativeId", val1.creative.id);
                                                                                });
                                                                });
              
            $scope.getAdCreativeForEdit();
			})

        }
        $scope.getAdCreativeForEdit = function () {
            var adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $rootScope.progressLoader = "block";
           
			facebookGetPost.getadcreative(queryStr, headers).then(function (response) {
                if (response.data.fbAdCreativeResponse.id) {
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green = true;
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#step3').css('background-color', '#95D2B1');
					$scope.setLine();
                } else {
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                }
                if (response.data.appStatus == 0) {// success
                    if (response.data.fbAdCreativeResponse.object_type == 'VIDEO') {		
                        $scope.formatSelected = 'fbsinglevideo';		
                    } else if (response.data.fbAdCreativeResponse.object_type == 'SHARE') {		
                        if(response.data.fbAdCreativeResponse.object_story_spec.link_data.hasOwnProperty("child_attachments")){		
                            $scope.formatSelected = 'fbcarosel' ;		
                        }		
                        else{		
                            $scope.formatSelected = 'fbsingleimage';		
                        }		
                    } else if (response.data.fbAdCreativeResponse.object_type == 'PHOTO') {		
                        $scope.formatSelected = 'fbsingleimage';		
                    }
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();
                    $scope.adCreativeDetails = response.data.fbAdCreativeResponse;
                    $scope.advertypeforEdit = response.data.fbAdCreativeResponse.object_type;
                    if ($scope.adCreativeDetails.url_tags) {
                        $scope.campaignURLParameter = $scope.adCreativeDetails.url_tags;
                    }
                    if($window.localStorage.getItem("marketingObjective") == 'PAGE_LIKES'){
                        $scope.campaignAudienceLandingViewLoader = true;
                        $scope.getPageTabs(response.data.fbAdCreativeResponse.object_id);
                    }
                    if(typeof(response.data.fbAdCreativeResponse.object_story_spec) != "undefined") {
                        if(typeof(response.data.fbAdCreativeResponse.object_story_spec.video_data) != "undefined"){
                            $scope.advertypeforEdit = 'VIDEO';
                        }
                    }
                    

					$rootScope.progressLoader = "none";
					$scope.mainLoader = "none";
                                    if(typeof($scope.adCreativeDetails.object_story_spec) != "undefined") {
					if(typeof($scope.adCreativeDetails.object_story_spec.link_data) != "undefined"){
						if(typeof($scope.adCreativeDetails.object_story_spec.link_data.child_attachments) != "undefined"){
						$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","435px");
						$scope.fbadvertFormat = "fbcarosel";
                        $rootScope.progressLoader = "none";
						console.log('fbcarousel adven');
						$scope.carouseladvent = true;
						/*$scope.isHeadline = false;
						$scope.isDestination = false;
						$scope.isWebURL = false;						
						$scope.isSeeMoreURL = true;
						$scope.isAddWebsiteUrl = false;*/
						
						$scope.cardHeadline = [];
						$scope.cardwebURL = [];
						$scope.cardDescription = [];
						
						$scope.headlinecontents = [];
						$scope.weburlcontents = [];
						$scope.descriptioncontents = [];
						$scope.selectedImagegalleryArray = [];
						$scope.imagePreviewSrc = [];
						$scope.imagePreviewVideoSrc = [];
						$scope.child_attachments = $scope.adCreativeDetails.object_story_spec.link_data.child_attachments;
						$scope.child_attachmentslength = $scope.adCreativeDetails.object_story_spec.link_data.child_attachments.length;
						console.log($scope.child_attachmentslength);	

						if($scope.child_attachmentslength > 2){
							for(var i = 3;i <= $scope.child_attachmentslength; i++){
							var len = $scope.tabs.length + 1;
							console.log(len);
							var numLbl =  len;
							$scope.tabs.push({
							  title: numLbl     
							  
							});
									
							}
							
							if($scope.child_attachmentslength == 3){$scope.carouseladventEdit3 = true;}
							else if($scope.child_attachmentslength == 4){$scope.carouseladventEdit4 = true;}
							else if($scope.child_attachmentslength == 5){$scope.carouseladventEdit5 = true;}
							else if($scope.child_attachmentslength == 6){$scope.carouseladventEdit6 = true;}
							else if($scope.child_attachmentslength == 7){$scope.carouseladventEdit7 = true;}
							else if($scope.child_attachmentslength == 8){$scope.carouseladventEdit8 = true;}
							else if($scope.child_attachmentslength == 9){$scope.carouseladventEdit9 = true;}
							
						}
						else{
							$scope.carouseladventEdit2 = true;
						}
					
						for(var i = 0;i<$scope.child_attachmentslength; i++){
							if ($scope.child_attachments[i].name != undefined) {
							console.log($scope.child_attachments[i].link);
							$scope.cardHeadline[i] =  $scope.child_attachments[i].name;
							$scope.headlinecontents[i] = $scope.cardHeadline[i];
							$scope.cardwebURL[i] =  $scope.child_attachments[i].link;
							$scope.weburlcontents[i] = $scope.cardwebURL[i];
							$scope.cardDescription[i] =  $scope.child_attachments[i].description;
							$scope.descriptioncontents[i] = $scope.cardDescription[i];
							}
						}	
							
							for(var i = 0;i<$scope.child_attachmentslength; i++){
								(function(i)
								{
										if(typeof($scope.child_attachments[i].image_hash) != "undefined"){
											//$scope.mainLoader = "block";
											console.log(i);
											
										//Get add image service using Hash value
										
												var queryStr1 = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + $scope.child_attachments[i].image_hash;
												
												var headers1 = {
																"userId": $window.localStorage.getItem("userId"),
																"accessToken": $window.localStorage.getItem("accessToken")
															   }
												
												facebookGetPost.getadimages(queryStr1, headers1).then(function (response) {
													console.log(response);
													if (response.status == "200" && response.data.appStatus == '0') {
													console.log(i);
													
														$scope.mainLoader = "none";
														console.log('image hash servic success');
														//$scope.getimageURL = response.data.adImages[0].url;
														//console.log($scope.getimageURL);
														//console.log(response.data.adImages[0]);
														var JsonObj = response.data.adImages[0];
														 var array = [];
														for (var j in JsonObj) {
															if (JsonObj.hasOwnProperty(j)) {
																array[+j] = JsonObj[j];
																console.log(JsonObj[j].url);
																$scope.imagePreviewSrc[i] = JsonObj[j].url;
																console.log(i);														
																$scope.selectedImagegalleryArray[i] = $scope.imagePreviewSrc[i];
																console.log($scope.selectedImagegalleryArray[i]);
																$scope.uniqueImageSelectionArray[i] = JsonObj[j].hash;
																console.log($scope.uniqueImageSelectionArray);
																$scope.showImgPrev[i] = true;														
																//$scope.adCreativeDetails(array[+i]);
															}
														}
														
													}else{
															if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
																$window.localStorage.setItem("TokenExpired",true);
																$state.go('login');
															}else{
																$rootScope.progressLoader = "none";
																$scope.editAdsetErrorMsg = 'block';
																if(response.networkError!='' && response.networkError!=undefined){
																	$scope.errorpopupHeading = response.networkError.error_user_title;
																	$scope.errorMsg = response.networkError.error_user_msg;

																	$scope.errorpopupHeading = 'Error';
																	$scope.errorMsg = response.networkError.message;
																}else{
																	$scope.errorpopupHeading = 'Error';
																	$scope.errorMsg = response.errorMessage;
																}
															}
														}
													});
												
										}
										else{
											console.log(i);
											console.log($scope.child_attachments[i].picture);
											console.log($('#imagePreviewVideo'+i).attr('id'));
											$scope.imagePreviewVideoSrc[i] = $scope.child_attachments[i].picture;
											$scope.selectedImagegalleryArray[i] = $scope.imagePreviewVideoSrc[i];
											//$scope.selectedImagegalleryArray[i] = $scope.child_attachments[i].video_id;
											console.log($scope.imagePreviewSrc[i]);
											$scope.showVideoPrev[i] = true;
											
										}
								})(i);
									
							}
							
						}
						else{
					
						if ($scope.advertypeforEdit == "VIDEO") {
							$scope.fbadvertFormat = "fbsinglevideo";
							$rootScope.progressLoader = "none";
                                                        $scope.formatSelected = 'fbsinglevideo';
						}
						else if ($scope.advertypeforEdit == "PHOTO" || $scope.advertypeforEdit == "PAGE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							 
						}
						else if ($scope.advertypeforEdit == "SHARE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							
						}
						else if($scope.advertypeforEdit == "SLIDESHOW") {
                        $scope.fbadvertFormat = "fbslideshow";
                        $rootScope.progressLoader = "none";
                        
						}
					}
					}
					else{
					
						if ($scope.advertypeforEdit == "VIDEO") {
							$scope.fbadvertFormat = "fbsinglevideo";
							$rootScope.progressLoader = "none";
						}
						else if ($scope.advertypeforEdit == "PHOTO" || $scope.advertypeforEdit == "PAGE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							 
						}
						else if ($scope.advertypeforEdit == "SHARE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							
						}
						else if($scope.advertypeforEdit == "SLIDESHOW") {
                        $scope.fbadvertFormat = "fbslideshow";
                        $rootScope.progressLoader = "none";
                        
						}
					}
                                    }
					else{
					
						if ($scope.advertypeforEdit == "VIDEO") {
							$scope.fbadvertFormat = "fbsinglevideo";
							$rootScope.progressLoader = "none";
						}
						else if ($scope.advertypeforEdit == "PHOTO" || $scope.advertypeforEdit == "PAGE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							 
						}
						else if ($scope.advertypeforEdit == "SHARE") {
							$scope.fbadvertFormat = "fbsingleimage";
							$rootScope.progressLoader = "none";
							
						}
						else if($scope.advertypeforEdit == "SLIDESHOW") {
                        $scope.fbadvertFormat = "fbslideshow";
                        $rootScope.progressLoader = "none";
                        
						}
					}
                    if($scope.fbadvertFormat == "fbsingleimage"){                        
                        $scope.thumbnail = response.data.fbAdCreativeResponse.thumbnail_url;
						$scope.thumbnailVideo="images/campaign/single-video.png";
						$scope.thumbnailCarousel="images/campaign/carousel.svg";
						 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.imgthumbnaildiv = true;
                        
                    }else if($scope.fbadvertFormat == "fbsinglevideo"){
                        $scope.thumbnailVideo = response.data.fbAdCreativeResponse.thumbnail_url;
                        $scope.thumbnail="images/campaign/single-image.png";
						  $scope.thumbnailCarousel="images/campaign/carousel.svg";
						   $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                        $scope.vidthumbnaildiv = true;
                    }
					else if($scope.fbadvertFormat == "fbslideshow"){
                         $scope.thumbnailVideo = "images/campaign/single-video.png";
                         $scope.thumbnail="images/campaign/single-image.png";
					     $scope.thumbnailSlideshow = response.data.fbAdCreativeResponse.thumbnail_url;
						 $scope.thumbnailCarousel="images/campaign/carousel.svg";
                      
                    }
					else if($scope.fbadvertFormat == "fbcarosel"){
						  $scope.thumbnailCarousel = response.data.fbAdCreativeResponse.thumbnail_url;
                          $scope.thumbnailVideo="images/campaign/single-video.png";
                          $scope.thumbnail="images/campaign/single-image.png";
						  $scope.thumbnailSlideshow = "images/campaign/slide-show.png";

                    }
					
                    if ($scope.marketingObjective == "OFFER_CLAIMS") {
                        //alert($scope.advertypeforEdit);
                        if($scope.advertypeforEdit == "VIDEO"){
                            $scope.textBodyContent = $scope.adCreativeDetails.body;
                            $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                            $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            //alert($scope.selectedTarget);
							 $scope.rightColumn = false;
                        }
						
						else if($scope.adCreativeDetails.object_type == "SHARE" && $scope.carouseladvent == true){
							$scope.textBodyContent = $scope.adCreativeDetails.body;
							$scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
							$window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
							$scope.isAddWebsiteUrl = false;
								$scope.isText = true;
								$scope.isWebsiteurl = false;
								$scope.isDisplayLinkOptional = false;
								$scope.isHeadline1 = false;
								$scope.isHeadline = false;								
								$scope.isDestination = false;
								$scope.isSeeMoreURL = false;
								$scope.isNewsFeedLinkDesc = false;
								$scope.isMoreDisplayURLOptional = false;
								$scope.isCallToActionOptional = false;
								$scope.isDisplayLink = false;
								$scope.isCallToAction = false;
								$scope.isCreateShowandHideOptionWrap1 = false;
								
								$scope.mediaImage = false;
								$scope.mediaVideo = false;
								$scope.offersmediaUpdate = true;
								$scope.mediaarrow = true;
								$scope.cardarrow = false;								
								$scope.imageFormat = "offersmediaUpdate"; 
						}
						
						else{
                            $scope.textBodyContent = $scope.adCreativeDetails.body;
                            if ($scope.adCreativeDetails.object_story_spec) {
                                $scope.newsfeedlinkdesc = $scope.adCreativeDetails.object_story_spec.link_data.description;
                                $scope.selectedTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                $window.localStorage.setItem("campaignAudienceTarget",$scope.selectedTarget);
                            }
                        }
                    }
                     $scope.checkMandatoryVal();
                     $scope.selectAdvertFormat();
                     
                
                }else{
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
               
            });
       }
        $scope.getAdForEdit = function () {
            var queryStr = "?adsetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }

			facebookGetPost.readaddata(queryStr, headers).then(function (response) {
                //console.log(response.data.ads);
                if (response.data.appStatus == '0') {// success
                    angular.forEach(response.data.ads, function (value, key) {
                        var JsonObj = response.data.ads[key];
                        //console.log(JsonObj);
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                array[+i] = JsonObj[i];
                                //$scope.adCreativeDetails(array[+i]);
                            }
                        }
                    });
                } else {// failed
                    console.log("failed for getadforedit service");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    // Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
        }
        
        $scope.getPageOffers = function(){
            //console.log($scope.connectFBVal);
            //console.log($scope.selectedTarget);
            var pageObj = $filter('filter')($scope.connectFBVal, function(d){return d.id == $scope.selectedTarget;})[0];
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
			var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&pageId=" + $scope.selectedTarget + "&pageAccessToken=" + pageObj.access_token;
            
			facebookGetPost.getoffersinpage(queryStr, headers).then(function(response){
                angular.forEach(response.data.offersInPage, function(value, key){
                    var JsonObj = response.data.offersInPage[key];  				
                    var array = [];
                    for(var i in JsonObj) {
                        if(JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                            var OfferDetails = array[+i] = JsonObj[i];							
                            var newOfferArr = {
                                "id" : OfferDetails.id,
                                "name" : OfferDetails.title,
                                "redemptionlink" : OfferDetails.redemption_link
                            }
                            $scope.campaignAudienceCampaignOfferArr.push(newOfferArr);
                        }
                    }
                });
				console.log($scope.campaignAudienceCampaignOfferArr);
				console.log($scope.campaignAudienceCampaignOffer);
				
                var OfferObj = $filter('filter')($scope.campaignAudienceCampaignOfferArr, function(d){return d.id==$scope.campaignAudienceCampaignOffer;})[0];
                $window.localStorage.setItem("OfferRedemptionLink",OfferObj.redemptionlink);
                $window.localStorage.setItem("OfferName",OfferObj.name);
            })
        }
        
        $scope.init = function () {
            $scope.textBodyContent =="";
            $scope.cardHeadline = []; 
            angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
            console.log(angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle"));
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
            $rootScope.freezeFlag = false;
            $rootScope.overLayAudience = false;

            //alert("1"+$scope.overLay);

            $rootScope.step = 4;
            if ($rootScope.campaignSteps[3] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }
            //$window.localStorage.setItem("campaignState", "edit");
           // angular.element('#step1').css('background-color', '#95D2B1');

            $scope.connectFBVal1 = $window.localStorage.getItem("pageCampaignTargetArr");
            $scope.connectFBVal = ""//JSON.parse($scope.connectFBVal1);
            $scope.campaignAudienceTargetType = $window.localStorage.getItem("campaignAudienceTargetType");
            //console.log($window.localStorage.getItem("campaignAudienceTarget"));
            $scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            
            if ($scope.selectedTarget == "undefined") {
                $scope.selectedTarget = "";
            }
            if ($scope.campaignPromateURL != "" && $scope.campaignPromateURL!="undefined" && $scope.campaignPromateURL!=null) {
                $scope.selectedTarget = "";
            }
            //alert($scope.selectedTarget);
//            if ($scope.callToDirectionValue == undefined) {
//                $scope.callToDirectionValue = "0";
//            }
            $scope.campaignPromateURL = $window.localStorage.getItem("hdcampaignAudienceCampaignTargetName");
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            $scope.previewSection();
            //$scope.adsetIdDetails = globalData.getLocal($window.localStorage.getItem("campaignId"));        		
            //$scope.useExistingPostLink = false;
            $scope.checkPreview();            
            $scope.getPromotablePage();
            var campaignState = $window.localStorage.getItem("campaignState");
            $scope.campState = $window.localStorage.getItem("campaignState");
            //console.log(campaignState);
             if (campaignState == "create") {
              $scope.thumbnail="images/campaign/single-image.png";
              $scope.thumbnailVideo = "images/campaign/single-video.png";

                $scope.thumbnailCarousel = "images/campaign/carousel.svg";

               $scope.thumbnailSlideshow = "images/campaign/slide-show.png";

             }
            if (campaignState == "edit") {
			$scope.carouseladvent1 = false;
                if ($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;					
                } else {
                    $scope.adminUserRole = false;					
                }
                //var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.textBodyContent = $window.localStorage.getItem("textBodyContent");

                //$scope.selectedTarget = $window.localStorage.getItem("campaignAudienceTarget");
                $scope.newsfeedlinkdesc = $window.localStorage.getItem("newsfeedlinkdesc");
                $scope.displayLink = $window.localStorage.getItem("displayLink");
                $scope.campaignHeadline = $window.localStorage.getItem("campaignHeadline");
                $scope.campaignHeadline1 = $window.localStorage.getItem("campaignHeadline1");
                $scope.callToDirectionValue = $window.localStorage.getItem("callToDirectionValue");
                $scope.selectLeadForm = $window.localStorage.getItem("selectLeadForm");
                
                $scope.webURL = $window.localStorage.getItem("webURL");
                $scope.selectedTarget = $window.localStorage.getItem("selectedTarget");
                $scope.valAddWebsiteUrl = JSON.parse($window.localStorage.getItem("valAddWebsiteUrl"));
                //$scope.campaignHeadline = $window.localStorage.getItem("hdcampaignAudienceCampaignTargetName");
                $scope.getAdCreativeIdFromFaceBook();
                //$scope.getAdCreativeForEdit();
                //$scope.getAdForEdit();
            }
            
            // alert($scope.objectType);
			$scope.setLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.fsValue = angular.element(document.getElementById('step1')).offset().top;					
						$scope.ssValue = angular.element(document.getElementById('step2')).offset().top;		
						$scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                                                var offsetHeight3 = document.getElementById('step3container').offsetHeight;
                                                var fStep = $(".vr");						
                                                fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
                                                
					}
					}, 10);
			};
			$scope.setLine();
			$scope.setFixLine = function(){
				var everythingLoaded = setInterval(function() {
					if (/loaded|complete/.test(document.readyState)) {
						clearInterval(everythingLoaded);
						$scope.exfsValue = angular.element(document.getElementById('existingStep1')).offset().top;					
						$scope.exssValue = angular.element(document.getElementById('existingStep2')).offset().top;											
						var exStep = $(".vline");						
						exStep.css('height', (($scope.exssValue - $scope.exfsValue)));						
					}
					}, 10);
			};
			
			$scope.imagePreviewSrc = [];
			$scope.imagePreviewVideoSrc = [];
			
		}
        
        $scope.sendcampaignAudienceCampaignTarget = function(campaignAudienceCampaignTarget){
            $scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $rootScope.freezeFlag = true;
        }
        
        $scope.localAwareness = [
            {
                "id": "CALL_NOW",
                "name": "Call Now"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "GET DIRECTIONS"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }
        ]

        $scope.canvas_app_installs1 = [
            {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "USE_APP",
                "name": "Use App"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }
        ]
        $scope.canvas_app_installs = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "INSTALL_NOW",
                "name": "Install Now"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "LISTEN_NOW",
                "name": "Listen Now"
            }, {
                "id": "PLAY_GAME",
                "name": "Play Game"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            },{
                "id": "SIGN_UP",
                "name": "Sign Up"
            },{
                "id": "USE_APP",
                "name": "Use App"
            },{
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]
        $scope.reachPeople = [
			{
                "id": "LEARN_MORE",
                "name": "Learn More"
            },
            {
                "id": "CALL_NOW",
                "name": "Call Now"
            }, {
                "id": "GET_DIRECTIONS",
                "name": "Get Directions"
            }, {
                "id": "SEND_MESSAGE",
                "name": "Send Message"
            }
        ]

        $scope.brandAwareness = [
            {
                "id": "NO_BUTTON",
                "name": "No Button"
            }, {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]
        
        $scope.leadgeneration = [
            {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "GET_QUOTE",
                "name": "Get Quote"
            },{
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            },{
                "id": "SUBSCRIBE",
                "name": "Subscribe"
            }

        ]


        $scope.videoBrandAwareness = [
            {
                "id": "APPLY_NOW",
                "name": "Apply Now"
            }, {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "CONTACT_US",
                "name": "Contact Us"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "REQUEST_TIME",
                "name": "Request Time"
            }, {
                "id": "SEE_MENU",
                "name": "See Menu"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]

        $scope.video_views = [
            {
                "id": "BOOK_NOW",
                "name": "Book Now"
            }, {
                "id": "DOWNLOAD",
                "name": "Download"
            }, {
                "id": "LEARN_MORE",
                "name": "Learn More"
            }, {
                "id": "SHOP_NOW",
                "name": "Shop Now"
            }, {
                "id": "SIGN_UP",
                "name": "Sign Up"
            }, {
                "id": "WATCH_MORE",
                "name": "Watch More"
            }

        ]

		$scope.pixelTrackingOptions = [
		{
			"id":"allpixel",
			"name":"Track all conversions from my Facebook pixel"			
		},
		{	
			"id":"nopixel",
			"name":"Do not track conversions"		
		}]
        
 
        
        $scope.getPromotablePage = function () {
			var headers = {
					"userId": $window.localStorage.getItem("userId"),
					"accessToken": $window.localStorage.getItem("accessToken")
				}
			var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
           
			facebookGetPost.fetchuserpromotablepages(queryStr, headers).then(function (response) {
				console.log(response);
				$scope.campaignAudienceCampaignTargetLoader = false;
                //console.log(response);
                $scope.connectFBVal = response.data.fbUserPromotablePagesResponse;				
                if($window.localStorage.getItem("marketingObjective") == 'OFFER_CLAIMS'){
                    $scope.getPageOffers();
                }
                if($window.localStorage.getItem("campaignState") == "create") {
                    if($window.localStorage.getItem("campaignAudienceTarget") != "undefined" && $window.localStorage.getItem("campaignAudienceTarget") != undefined && $window.localStorage.getItem("campaignAudienceTarget") != "") {
                        if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                            $scope.campaignAudienceLandingViewLoader = true;
                            $scope.getPageTabs($window.localStorage.getItem("campaignAudienceTarget"));
                        }
                    }
                }
            })
        }
    
        $scope.checkPreview = function () {
            
            var preview = $window.localStorage.getItem("campaignAudiencePlacementsValues");
            preview = "mobilenewsfeed,desktoprightcolumn,desktopnewsfeed";
            var arr = preview.split(',');
            angular.forEach(arr, function (value, key) {
                //console.log(arr[key])
                if (arr[key] == 'mobilenewsfeed') {
                    $scope.mobile = true;
                }
                if (arr[key] == 'desktoprightcolumn') {
                    $scope.rightColumn = true;
                }
                if (arr[key] == 'desktopnewsfeed') {
                    $scope.desktop = true;
                }
                if (arr[key] == 'instagram') {
                    $scope.instagramfeed = true;
                }
            });
        

            //mobilenewsfeed,desktoprightcolumn,desktopnewsfeed
        }
       
     
        $scope.fetChPreview = function () {
            var queryStr = "act_" + $scope.networkAdAccountId + "/generatepreviews?access_token=" + $rootScope.networkAccessToken;
           
			facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                //console.log(response);
            });
        }
        
        
        $scope.selectAdvertFormat = function (mode) {
            
            if (mode == 'insert') {
                $rootScope.freezeFlag = true;
                angular.element($('.btnCampaignCreative').prop('disabled', true));
                //angular.element($('.accordianRole').prop('disabled', true));
                angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            } else {				
                $rootScope.freezeFlag = false;
            }
            $window.localStorage.setItem("fbadvertFormat", $scope.fbadvertFormat);
            //$scope.fbadvertFormat = "fbcarosel";
            $scope.isCreateShowandHideOptionWrap1 = false;
            $scope.isPixelTracking = false;
            $scope.isOfflineTracking = false;
            $scope.isDeepLink = false;
            if ($scope.formatSelected == $scope.fbadvertFormat) {
                $scope.imgthumbnaildiv = true;
                $scope.vidthumbnaildiv = true;
                $scope.slideShowSuccess = true;
                $scope.slideShowCreate = false;
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                //angular.element($('.accordianRole').prop('disabled', false));
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                $scope.step2_green = true;
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
            }
            else {
                $scope.imgthumbnaildiv = false;
                $scope.vidthumbnaildiv = false;
                $scope.slideShowCreate = true;
                $scope.slideShowSuccess = false;
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element('#step3').css('background-color', '#C2C2C2');
                angular.element('#collapseOne1').removeClass('in');
                angular.element('#collapseTwo1').removeClass('in');
                angular.element('#collapseThree1').removeClass('in');
                 angular.element('.btnCampaignCreative').css('pointer-events', 'none');
                angular.element('.btnCampaignCreative').css('opacity', '0.6');
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
                angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            }

            switch ($scope.fbadvertFormat) {
                case "fbsingleimage": // Single image
                    
                    $scope.isCreateShowandHideOptionWrap = true;
                    $scope.isNewsFeedLinkDesc = true;
                    //$scope.isHeadline = true;

                 
                    if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = false;

                    }
                    break;
                case "fbsinglevideo": // Single Video
                    $scope.isCreateShowandHideOptionWrap = false;
                    $scope.isNewsFeedLinkDesc = false;
                    //$scope.isHeadline = true;
                    //$scope.isDestination = false;
                  
                    if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
			$scope.rightColumn = false;
                    }
                    break;
                case "fbslideshow":  // Slide show
                    $scope.isCreateShowandHideOptionWrap = false;
                    $scope.isNewsFeedLinkDesc = false;
                    //$scope.isHeadline = true;
                    //$scope.isDestination = false;
                    
                    if ($scope.marketingObjective == "OFFER_CLAIMS") {  ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.useExistingPostLink = false;
						 $scope.rightColumn = false;
                    }
                    break;
                case "fbcarosel": //Carosel				
                    $scope.isNewsFeedLinkDesc = true;
                    $scope.isEvent = false;
				  $scope.isCreateHideAdvOption = false;
				  $scope.isUrlParam=false;
                    
                    if ($scope.marketingObjective == "OFFER_CLAIMS") { ////Get people to claim your offer
                        $scope.advertPreviewHeading = "Creative";
                        $scope.isEvent = false;
                        $scope.isConnectFBPage = false;
                        $scope.isInstagram = false;
                        $scope.isDestination = false;
                        $scope.isHeadline = false;
                        $scope.isText = true;
                        $scope.isCallToAction = false;
                        $scope.isCards = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.useExistingPostLink = false;												
                            $scope.iscardDescription = true;
                            $scope.iscardwebURL = true;
                            $scope.iscarddisplayLink = true;

                            $scope.mediaImage = false;
                        $scope.mediaVideo = false;
                        $scope.offersmediaUpdate = true;
                        $scope.mediaarrow = true;
                        $scope.cardarrow = false;
                        $scope.isWebsiteurl = false;
                        $scope.isDisplayLink = false;
                        $scope.isHeadline1 = false;
                        $scope.isNewsFeedLinkDesc = false;
                        $scope.isAddWebsiteUrl = false;
                        $scope.imageFormat = "offersmediaUpdate";
                    }
                    break;
            }
            $scope.checkMandatoryVal();
        };
        
        $scope.exitPostShowAdvanceOption = function () {
            $scope.existURLParam = true;
            $scope.exitShowAdvOption = false;
            $scope.exitHideAdvOption = true;
        }
        $scope.exitPostHideAdvanceOption = function () {
            $scope.existURLParam = false;
            $scope.exitShowAdvOption = true;
            $scope.exitHideAdvOption = false;
        }
        $scope.previewSection = function () {
            switch ($scope.marketingObjective) {
              
                case "OFFER_CLAIMS": //Get people to claim your offer
                    $scope.fbadvertFormat = "fbsingleimage";
                    $scope.advertCarousel = true;
                    $scope.advertSingleImg = true;
                    $scope.advertSingleVideo = true;
                    $scope.advertSlideshow = true;
                    $scope.selectAdvertFormat('defaultLoad');
                    break;

            }
        }



        $scope.changeAdvertFormat = function () {
            // alert($scope.fbadvertFormat);
            //console.log($scope.fbadvertFormat);
        }
        $scope.init();		
        $scope.getBrowseLibraryImagekey = function (data) {
            $scope.imagesSource = data.imageSources;
            console.log($scope.imagesSource);
            if ($scope.imagesSource === undefined) {
                console.log('Choose one from library');
                return true;
            }
            /*var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
             if (isCreativeAdCreativeId) {
             $scope.deleteAdCreative();
             }else{*/
            $scope.creativeAdCreative($scope.imagesSource);
            //}

            angular.element($('body').css("overflow-y", "scroll"));
            $scope.browselibrary = "none";
        }


		
	$scope.$watchCollection(function () {
        if ($scope.frmCreateNewAdvert)
            return $scope.frmCreateNewAdvert;
    }, function () {
       if ($scope.frmCreateNewAdvert)
       if (($scope.frmCreateNewAdvert.$invalid == true))
             $scope.inputTypeFile = false;	
        else
             $scope.inputTypeFile = true;	
    }, true);

	
	    $scope.inputTypeFile = false;
		/*$scope.getInputType = function (){
	
		if (!$scope.frmCreateNewAdvert.$valid) { 
                  $scope.inputTypeFile = false;		
                  return;
            }
			    $scope.inputTypeFile = true;
			
    
			
        
        } */
		
        $scope.getCampaignfiles = function (element) {
		
	if(element.files[0] != undefined){
            $scope.removeThumbnail();	  
            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
                window.scrollTo(0, document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));
				//angular.element($('.accordianRole').prop('disabled', true));
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            }
            else {
			      $rootScope.progressLoader = 'block';
                document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
                $scope.errTextMsg = "none";
                angular.element($('.btnCampaignCreative').prop('disabled', false));
				//angular.element($('.accordianRole').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                                $scope.step2_green=true;
                $scope.$apply(function ($scope) {
                    $scope.uploadedfilename = element.files[0];
                });
                //console.log(element.files[0]);
                var reader = new FileReader();
                reader.onload = function () {
                    $scope.dataURL = reader.result;
                };
                $timeout(function () {
                    //console.log($scope.dataURL);				
				
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
			parameters.append('type','IMAGE');
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('imageFile',element.files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadimage";

			if (typeof (element.files[0]) == "object") {
                         
							facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                                console.log(response);
                                                        $rootScope.progressLoader = 'none';
                                if (response.status == "200" && response.data.appStatus == 0) {
                                    $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                                    $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
                                    var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
                                    //if (isCreativeAdCreativeId) {
                                      //  $scope.deleteAdCreative($scope.hashVal);

                                   // }
                                    $scope.creativeAdCreative($scope.hashVal);
                                }
                                else {
                                    console.log('failed $scope.getCampaignfiles');
                                                                $scope.showErrorPopup(response.data);
                                    // Flash.create('danger', response.errorMessage, 'large-text');
                                }															
                            });
					    
			}
																			
                }, 1000);
                
                
                reader.readAsDataURL(element.files[0]);
            }//else
        }
				
        };
		
        $scope.browseExistingVideos = function (element) {

            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
                        
			facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                console.log(response);
                
                
                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    $scope.mainLoader = "none";	
                    $scope.existVideosList = response.data.data;
				
                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
                    $scope.existVideosList = arrAdAccountCreativeallDataVideo;
					
		}else {// failed							
                    console.log("failed $scope.getAd");				       
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);		
                        $state.go('login');		
                    }else{		
                        $rootScope.progressLoader = "none";		
                        $scope.editAdsetErrorMsg = 'block';		
                        $scope.showErrorPopup(response);		
                        //Flash.create('danger', response.errorMessage, 'large-text');		
                    }		
                }       
                        
                $rootScope.progressLoader = "none";
                $scope.browselibraryvideos = "block";
                //$scope.existVideosList = response.data.adVideos;
            });
        };
        $scope.getBrowseLibraryVideoID = function (data) {
            $scope.videoID = data.videoSources;
            $scope.hashVal = data.videoSources;
            if ($scope.videoID === undefined) {
                console.log('Choose one from library');
                return true;
            }
            
            $scope.creativeAdCreative($scope.videoID);
            $scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
        }
        $scope.getCampaignVideoFiles = function (element) {
            if(element.files[0] != undefined){
                
            $rootScope.progressLoader = 'block';
            $scope.removeThumbnail();
            /*$scope.$apply(function ($scope) {
                $scope.uploadedfilename = element.files[0];
            });*/
            var parameters = new FormData();
            parameters.append('userId',$window.localStorage.getItem("userId"));
            parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
            parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
            parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
            parameters.append('source',element.files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadvideo";

            if (typeof (element.files[0]) == "object") {                
				facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {
                    //console.log(response);					
                    if (response.data.appStatus == '0') {
                        $scope.newvideoID = response.data.adVideoId;
                        $scope.callGetadvideos($scope.newvideoID);
                    } else {
                        $rootScope.progressLoader = 'none';
                        console.log("failed $scope.getCampaignVideoFiles");
			$scope.showErrorPopup(response.data);
                    }
                });



            }
        }
        };
        
        $scope.callGetadvideos = function(newvideoID){
            
            var modalErr = $(".video_error_popup");
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "?adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID;
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
				}
                $scope.mainLoader = "block";
               
				facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
                                    $scope.pictureFormat = adVideoID.format;
                                    $scope.videoStatus = adVideoID.status;
                                    angular.forEach( $scope.pictureFormat,function(ulrVal){
                                        if(ulrVal.filter == "native"){
                                            $scope.imageURLValue = ulrVal.picture;
                                            //$scope.videoSource = adVideoID.source;
                                        }
                                    });
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';
                        $scope.checkCreatedVideoStatus(newvideoID);
                    } else {// failed		
                        console.log("failed $scope.getAd");		
                        if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){		
                            $window.localStorage.setItem("TokenExpired",true);		
                            $state.go('login');		
                        }else{		
                            $rootScope.progressLoader = "none";		
                            $scope.editAdsetErrorMsg = 'block';		
                            $scope.showErrorPopup(response);		
                            //Flash.create('danger', response.errorMessage, 'large-text');		
                        }		
                    }
                });
            
            },0);

        }
        
        $scope.checkCreatedVideoStatus = function(newvideoID){
            $scope.newvideoID = newvideoID;
            if($scope.videoStatus){
                if($scope.videoStatus.video_status == "ready"){
                    console.log($scope.newvideoID+"|"+$scope.imageURLValue);
                    $scope.creativeAdCreative($scope.newvideoID+"|"+$scope.imageURLValue);
                }else if($scope.videoStatus.video_status == "error"){
                    $scope.popupTitle = 'Error';
                    $scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup");
                    modalErr.show();
                }else{
                    $scope.popupTitle = 'Video Status Error';
                    $scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup");
                    modalErr.show();
                    //$scope.callGetadvideos(newvideoID);
                }			
            }			
        }

        $scope.selectPromotable = function (pageId, _name) {
            $scope.campaignAudienceCampaignTargetLoader = false;
            $scope.selectedTarget = pageId;
            $scope.selectedTargetName = _name;
            if($scope.selectedTarget!=null && $scope.selectedTarget!="" && $scope.selectedTarget!=undefined)
            {
                angular.element('#selectTargetObjective').removeClass("mandatory");
            }else
            {
                angular.element('#selectTargetObjective').addClass("mandatory");
            }
            $window.localStorage.setItem("selectedTarget", $scope.selectedTarget);

            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please re-select image/video");
            if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES")
            {
                $scope.campaignAudienceLandingViewLoader = true;
//                console.log($scope.selectedTarget);
//                console.log($scope.connectFBVal);
                $scope.getPageTabs(pageId);
            }
         //   $scope.getExistingPost(pageId);
        }
        $scope.getDisplayLink = function (displayLink) {
            $scope.displayLink = displayLink;
            if($scope.displayLink!=null && $scope.displayLink!="" && $scope.displayLink!=undefined)
            {
                angular.element('#errdisplayLink').removeClass("mandatory");
            }else
            {
                angular.element('#errdisplayLink').addClass("mandatory");
            }
            $window.localStorage.setItem("displayLink", $scope.displayLink);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
		$scope.getDisplayURLoptional = function (displayURLoptional) {
            $scope.displayURLoptional = displayURLoptional;
            $window.localStorage.setItem("displayURLoptional", $scope.displayURLoptional);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
		$scope.getMoreURL = function (seeMoreUrl) {
            $scope.seeMoreUrl = seeMoreUrl;
            if($scope.seeMoreUrl!=null && $scope.seeMoreUrl!="" && $scope.seeMoreUrl!=undefined)
            {
                angular.element('#seeMoreUrl').removeClass("required");
            }else
            {
                angular.element('#seeMoreUrl').addClass("required");
            }
            $window.localStorage.setItem("seeMoreUrl", $scope.seeMoreUrl);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");

        }
		
        $scope.getwebURL = function (webURL) {
            $scope.webURL = webURL;
            if($scope.webURL!=null && $scope.webURL!="" && $scope.webURL!=undefined)
            {
                angular.element('#websiteURL').removeClass("mandatory");
            }else
            {
                angular.element('#websiteURL').addClass("mandatory");
            }
            $window.localStorage.setItem("webURL", $scope.webURL);

            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /* if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
			$scope.setLine();
        }
		
		$scope.getWebURLVal = function(){
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
                        if($window.localStorage.getItem("campaignState") != "edit")
                        {
                            $scope.newsfeedlinkdesc = "";
                            $scope.webURL = "";
                            $scope.displayLink = "";
                            $scope.campaignHeadline = "";
                        }
			//$scope.callToDirectionValue = 0;
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
		}
                $scope.sendcampaignURLParameter = function(campaignURLParameter){
                    $scope.campaignURLParameter = campaignURLParameter;
                }
        $scope.creativeAdCreative = function (imageHashVal) {
            $rootScope.progressLoader = "block";
            //console.log(imageHashVal);
            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
            if (isCreativeAdCreativeId) {
               $scope.deleteAdCreative(imageHashVal);
                $window.localStorage.removeItem("adCreativeId");
                if ($window.localStorage.removeItem("deleteAdCreativeStatus")) { //alert("dfdsf")
                    $scope.networkErrorPopup = 'block';
                    return;
                }
            }
                        else {
                $scope.proceedToCreateAdCreative(imageHashVal);
            }
  
        };
		
	$scope.proceedToCreateAdCreative=function(imageHashVal){
			                   
            $scope.objid = imageHashVal.split('|')[0];
            $scope.objurl = imageHashVal.split('|')[1];
            //console.log($scope.objurl);
            $window.localStorage.setItem("campaignMediaURL", $scope.objurl);

			
            //$scope.campaignHeadline1 = "";
            $window.localStorage.setItem("newsfeedlinkdesc", $scope.newsfeedlinkdesc);
            $window.localStorage.setItem("valAddWebsiteUrl", $scope.valAddWebsiteUrl);
            $window.localStorage.setItem("displayLink", $scope.displayLink);
            $window.localStorage.setItem("selectLeadForm", $scope.selectLeadForm);
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            
            $scope.pageIdVal = $scope.selectedTarget;
            //console.log($scope.marketingObjective);
            console.log($scope.fbadvertFormat);
            if ($scope.fbadvertFormat == 'fbcarosel') {
                $scope.objectType = 'PHOTO';
                $window.localStorage.setItem("campaignMediaFormat", "Carosel");
		$scope.objectType = "SHARE";
                   	
            } else if ($scope.fbadvertFormat == 'fbsingleimage') {

                if ($scope.marketingObjective == "OFFER_CLAIMS") {
                    $scope.objectType = 'SHARE';
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "link_data": {
                            "link" : $window.localStorage.getItem("OfferRedemptionLink"),
                            "message": $scope.textBodyContent,
                            "image_hash": $scope.objid,
                            "offer_id": $scope.campaignAudienceCampaignOffer,
                            "call_to_action":
                            {
                                "type": "GET_OFFER_VIEW"
                            }
                        }
                    }
                }

                $window.localStorage.setItem("campaignMediaFormat", "Single Image");
            } 
            else if ($scope.fbadvertFormat == 'fbsinglevideo') {
                if ($scope.marketingObjective == "OFFER_CLAIMS") {
                    $scope.objectType = "VIDEO";
                    $scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "message": $scope.textBodyContent,
                            "title" : $window.localStorage.getItem("OfferName"),
                            "call_to_action":
                            {
                                "type": "GET_OFFER_VIEW",
                                "value" : {
                                    "link" : $window.localStorage.getItem("OfferRedemptionLink"),
//                                    "link_title": $window.localStorage.getItem("OfferName")
                                }
                            },
                            "image_url": $scope.objurl,
                            "offer_id": $scope.campaignAudienceCampaignOffer 
                        }
                    }   
                }

                $window.localStorage.setItem("campaignMediaFormat", "Single Video");
            } 
            else if ($scope.fbadvertFormat == 'fbslideshow') {
                $scope.objectType = "VIDEO";
                if($scope.objurl){
                        $scope.imageURLValue = $scope.objurl;
                }
                 $window.localStorage.setItem("campaignMediaFormat", "Slideshow");	
		$scope.object_type = "VIDEO";
		$scope.objectStorySpec = {
                        "page_id": $scope.pageIdVal,
                        "video_data": {
                            "video_id": $scope.objid,
                            "message": $scope.textBodyContent,
                            "title" : $window.localStorage.getItem("OfferName"),
                            "call_to_action":
                            {
                                "type": "GET_OFFER_VIEW",
                                "value" : {
                                    "link" : $window.localStorage.getItem("OfferRedemptionLink"),
                                }
                            },
                            "image_url": $scope.imageURLValue,
                            "offer_id": $scope.campaignAudienceCampaignOffer 
                        }
                    }		
	
            }
            //console.log("objectStorySpec : "+JSON.stringify($scope.objectStorySpec));
            if ($scope.campaignHeadline != '' && $scope.campaignHeadline != undefined && $scope.campaignHeadline != 'null') {
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,
                    //"objectId" : $scope.selectedTarget,//Note : remove this for video
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields",
                    //"imageHash" : imageHashVal, // Note : its for image 
                    //"videoId" : imageHashVal, // Note : its for video
                    "title": $scope.campaignHeadline
                };
            } else {
                var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,
                    //"objectId" : $scope.selectedTarget,//Note : remove this for video
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields"
                            //"imageHash" : imageHashVal, // Note : its for image 
                            //"videoId" : imageHashVal, // Note : its for video
                };
            }
            if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
            if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES") {
                if($scope.isCreateHideAdvOption) {
                    var url = "";
                    for(var i=0;i<$scope.pageTabs.length;i++) {
                        if($scope.pageTabs[i].name == $scope.campaignLandingView) {
                            url = "https://www.facebook.com/" + $scope.pageTabs[i].urlPart;
                        }
                    }
                    var link_url = {
                        "linkUrl":url
                    };
                    parameters = angular.extend({},parameters,link_url);
                }
                var image_hash = {
                    "imageHash":$scope.objid
                };
                parameters = angular.extend({},parameters,image_hash);
                var object_id = {
                    "objectId":$scope.pageIdVal
                };
                parameters = angular.extend({},parameters,object_id);
                
            }
            console.log(parameters);
            $rootScope.progressLoader = 'block';
         
			facebookGetPost.createadcreative("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {
                    //console.log(response.data.adCreativeId);
                    $scope.adCreativeId = response.data.adCreativeId;
                      $scope.showSlideShowBrowser=false;
                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.browselibraryPopupHeading = "Browse Library";
                    $scope.browselibrarySuccessMsg = "successfully uploaded";
                    $scope.createAd();
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();
                    // $scope.browseImgSuccessMsg = "block";
                    $scope.browselibrary = "none";
					$scope.objurl = "";
                    angular.element('#step2').css('background-color', '#95D2B1');

                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    //angular.element($('.accordianRole').prop('disabled', false));
                    //globalData.setLocal("adCreativeId", $scope.adCreativeId, response.data);
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                }
                else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                    vm.getData = {}; 
                    $scope.slideShowSuccess=false;
                    $scope.slideShowCreate=true;
                    $scope.showMediaErrorPopup(response);
                    $scope.showSlideShowBrowser=false;
                    angular.element($('.btnCampaignCreative').prop('disabled', true));
                    //angular.element($('.accordianRole').prop('disabled', true));
                    angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                    //  Flash.create('danger', response.errorMessage, 'large-text');
                }
            });
       
		}
        //=-------------------------------------------------------------------------------------------------
        
        $scope.desktopCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "DESKTOP_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "networkMapID=" + $window.localStorage.getItem("userNetworkMapId") + "&adCreativeId=" + $scope.adCreativeId+ "&adFormat=" + $scope.previewCategory;
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
				}
				var queryStr = "?" + $scope.facebookGraphCall;
				
				facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.progressLoaderPreveiw = "none";
                        $scope.RetryDesktopPreview = "none";
                        $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.desktopPreview1 = {src: $scope.embedSrcDesktop, title: "Desktop Preview"};
                    }
                    else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }

        $scope.mobileCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "MOBILE_FEED_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
				var queryStr = $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
               
				facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                    $scope.progressLoaderPreveiw = "none";
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                        $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.mobilePreview1 = {src: $scope.embedSrcDesktop, title: "Mobile Preview"};
                    }
                    else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }
        
        $scope.rightColumnCreativePreview_1 = function () {
            
            if($scope.selectedPostPage!='' && $scope.selectedPostPage!=undefined && $scope.selectedPostPage!=null){
                $scope.progressLoaderPreveiw = "block";
                $scope.previewCategory = "RIGHT_COLUMN_STANDARD";
                $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
                $scope.facebookGraphCall = "https://graph.facebook.com/v2.8/" + $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
				var queryStr = $scope.adCreativeId + "/previews?access_token=" + $window.localStorage.getItem("networkAccessToken") + "&ad_format=" + $scope.previewCategory;
                
				facebookGetPost.getfacebookgraph(queryStr).then(function (response) {
                    $scope.progressLoaderPreveiw = "none"
                    if (response.data['data'][0].body) {
                        $scope.RetryDesktopPreview = "none";
                         $scope.progressLoaderPreveiw = "none";
                        $scope.facebookResponseIframe = response.data['data'][0].body;
                        $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                        var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                                iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                        $scope.embedSrcDesktop = iframeSrcbody;
                        //console.log("src : "+$scope.embedSrcDesktop);
                        $scope.trustSrc = function (src) {
                            return $sce.trustAsResourceUrl(src);
                        }
                        $scope.rightColumnPreview1 = {src: $scope.embedSrcDesktop, title: "Right Column Preview"};
                    } else {
                        $scope.RetryDesktopPreview = "block";
                        $scope.progressLoaderPreveiw = "none";
                    }
                });
            }
            
        }
        //----------------------------------------------------------------------------------------------------
        $scope.desktopCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "DESKTOP_FEED_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");

            var queryStr = "?networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
         
			facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                console.log(response);
                $scope.progressLoaderPreveiw = "none";

                if (response.data.previewFb[0].preview) {
                    $scope.progressLoaderPreveiw = "none";
                    $scope.RetryDesktopPreview = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.desktopPreview = {src: $scope.embedSrcDesktop, title: "Desktop Preview"};
                }
                else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }

        $scope.mobileCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "MOBILE_FEED_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           
			facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                $scope.progressLoaderPreveiw = "none";
                if (response.data.previewFb[0].preview) {
                    $scope.RetryDesktopPreview = "none";
                    $scope.progressLoaderPreveiw = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.mobilePreview = {src: $scope.embedSrcDesktop, title: "Mobile Preview"};
                }
                else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }
        
        $scope.rightColumnCreativePreview = function () {
            $scope.progressLoaderPreveiw = "block";
            $scope.previewCategory = "RIGHT_COLUMN_STANDARD";
            $scope.adCreativeId = $window.localStorage.getItem("adCreativeId");
            var queryStr = "?networkMapID="+$window.localStorage.getItem("userNetworkMapId")+"&adCreativeId="+$scope.adCreativeId+"&adFormat="+$scope.previewCategory;
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
          
			facebookGetPost.getfbpreview(queryStr, headers).then(function (response) {
                $scope.progressLoaderPreveiw = "none"
                if (response.data.previewFb[0].preview) {
                    $scope.RetryDesktopPreview = "none";
                     $scope.progressLoaderPreveiw = "none";
                    $scope.facebookResponseIframe = response.data.previewFb[0].preview;
                    $scope.iframeSourcebody = $scope.facebookResponseIframe.replace(/&amp;/g, '&');
                    var srcWithQuotesbody = $scope.iframeSourcebody.match(/src\=([^\s]*)\s/)[1],
                            iframeSrcbody = srcWithQuotesbody.substring(1, srcWithQuotesbody.length - 1);
                    $scope.embedSrcDesktop = iframeSrcbody;
                    //console.log("src : "+$scope.embedSrcDesktop);
                    $scope.trustSrc = function (src) {
                        return $sce.trustAsResourceUrl(src);
                    }
                    $scope.rightColumnPreview = {src: $scope.embedSrcDesktop, title: "Right Column Preview"};
                } else {
                    $scope.RetryDesktopPreview = "block";
                    $scope.progressLoaderPreveiw = "none";
                }


            });
        }
        
        $scope.createAd = function () {
			$rootScope.progressLoader = "block";		
			$scope.mainLoader = "block";
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "accountId": $scope.networkAdAccountId,
                "adsetId": $window.localStorage.getItem("adsetId"),
                "creativeId": $window.localStorage.getItem("adCreativeId"),
                "name": "Demo Ad",
                "status": "PAUSED"
            };
            
			facebookGetPost.createad("", parameters).then(function (response) {
                $scope.mainLoader = "none";
                if (response.data.appStatus == 0) {
                    $scope.adId = response.data.adId;
                    $window.localStorage.setItem("adId", $scope.adId);
                    //$scope.desktopCreativePreview();
                    //$scope.mobileCreativePreview();
                    //$scope.rightColumnCreativePreview();
                    $scope.getAd();
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
                    //angular.element($('.accordianRole').prop('disabled', false));
                    angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                    angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                }
                else {
                    $rootScope.progressLoader = "none"
                    $scope.showErrorPopup(response.data);
                    vm.getData = {};
					angular.element($('.btnCampaignCreative').prop('disabled', true));
					//angular.element($('.accordianRole').prop('disabled', true));
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
                    angular.element('#step2').css('background-color', '#c2c2c2');
                    angular.element('#step3').css('background-color', '#c2c2c2');
                    angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
                }
            });
        }

        $scope.showErrorPopup = function (response) {
        console.log(response);
        if(response.hasOwnProperty("data")){
                                                if (response.data.networkError) {
                                                                if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined) {
                                                                                $scope.popupTitle = response.data.networkError.error_user_title;
                                                                                $scope.popupMessage = response.data.networkError.error_user_msg;
                                                } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {

                $scope.popupTitle = "Error";
                $scope.popupMessage = response.data.networkError.message;
                                                                }
                                                }else{
                                                                $scope.popupTitle = "Error";
                $scope.popupMessage = response.data.errorMessage;
                                                }
                                }else {
                                                if (response.networkError) {
                                                                if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                                                                                $scope.popupTitle = response.networkError.error_user_title;
                                                                                $scope.popupMessage = response.networkError.error_user_msg;
                                                                } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                                                                                $scope.popupTitle = "Error";
                                                                                $scope.popupMessage = response.networkError.message;
                                                                                }
                                                }else{
                                                                $scope.popupTitle = "Error";
                $scope.popupMessage = response.errorMessage;
                                                                }
               
                                                }

        var modalApproveReq = $(".error_popup"); // Get the modal Approve req
                modalApproveReq.show();
        }
        $scope.resetError = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.hide();
        }
        $scope.showSuccessPopup = function () {
            //console.log('success popup here123');
            $scope.popupTitle = "Assigning creative";
            $scope.popupMessage = "Ad created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup");
            successReq.show();

        }
        $scope.closeSuccessPopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup");
            $scope.networkErrorPopup = 'none';
            successReq.hide();


        }
        $scope.showMediaErrorPopup = function (response) {
            
            if(response.data.networkError!='' && response.data.networkError!=undefined){
				if(response.data.networkError.error_user_title){
					$scope.popupTitle = response.data.networkError.error_user_title;
					$scope.popupMessage = response.data.networkError.error_user_msg;
				}
				else{
					$scope.popupTitle = 'Invalid Parameter';
					$scope.popupMessage = response.data.errorMessage;
				}
                
            }else{
                $scope.popupTitle = 'Invalid Parameter';
                $scope.popupMessage = response.data.errorMessage;
            }
            angular.element($('body').css("overflow-y", "hidden"))
            var modalApproveReq = $(".error_popup");
            modalApproveReq.show();
        }

        $scope.hidePopup = function () {
            angular.element($('body').css("overflow-y", "scroll"))
            var modalApproveReq = $(".success_popup");
            modalApproveReq.hide();
        }
		
		$scope.getAdForDelete = function () {		
            console.log('get ad');		
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");		
			var headers = {		
                "userId": $window.localStorage.getItem("userId"),		
                "accessToken": $window.localStorage.getItem("accessToken")		
            }		
           		
			facebookGetPost.getad(queryStr, headers).then(function (response) {		
                if (response.data.appStatus == '0') {// success		
                    $scope.adData = response.data.adData;// need to change adsets instead of adData when backend change		
                    $window.localStorage.setItem("adData", JSON.stringify($scope.adData));		
                    		
                    console.log($scope.adData);		
					$scope.saveAdforDelete($scope.adData);		
                    //$scope.saveAd($scope.adData);		
                    console.log("success $scope.getAd");		
                } else {// failed		
                    console.log("failed getad");		
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){		
                        $window.localStorage.setItem("TokenExpired",true);		
                        $state.go('login');		
                    }else{		
                        $rootScope.progressLoader = "none";		
                        $scope.editAdsetErrorMsg = 'block';
                        vm.getData = {};
                        if(response.data.networkError!='' && response.data.networkError!=undefined){		
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;		
                            $scope.errorMsg = response.data.networkError.error_user_msg;		
                        }else{		
                            $scope.errorpopupHeading = 'Error';		
                            $scope.errorMsg = response.data.errorMessage;		
                        }		
                        //Flash.create('danger', response.errorMessage, 'large-text');		
                    }		
                }		
            });		
        }		


        $scope.getAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&" + "adId=" + $window.localStorage.getItem("adId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           
			facebookGetPost.getad(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                     $scope.formatSelected = $scope.fbadvertFormat;
                    $rootScope.progressLoader = "block";
                    $scope.adData = response.data.adData;// need to change adsets instead of adData when backend change
                    $window.localStorage.setItem("adData", JSON.stringify($scope.adData));
                    $scope.saveAd($scope.adData);
                    console.log("success $scope.getAd");
                } else {// failed
                    console.log("failed $scope.getAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        vm.getData = {};
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
        }

        $scope.saveAdforDelete = function () {

            //console.log($scope.adData)
            $scope.adDataFromLocal = JSON.parse($window.localStorage.getItem("adData"));

            $scope.adDataTemp = {
                "status": "DELETED"
            };

            var camR = {};
            for (var key in $scope.adDataFromLocal) {
                camR[key] = $scope.adDataFromLocal[key];
            }
            for (var key in $scope.adDataTemp) {
                camR[key] = $scope.adDataTemp[key];
            }
            $scope.adDataFromLocal = camR;
            console.log($scope.adData);

            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": $scope.adDataFromLocal
            };
            
			facebookGetPost.saveaddata("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    $rootScope.progressLoader = "none";
					angular.element('#step3').css('background-color', '#95D2B1');
                    //$scope.showSuccessPopup(response.data.successMessage);
                }
                else {
                    console.log('failed $scope.saveAdforDelete');
					$rootScope.progressLoader = "none";
                                        vm.getData = {};
                    $scope.showErrorPopup(response.data);
                    $scope.networkErrorPopup = "block";
                    $scope.popupTitleError = "Error";
                    $scope.popupTitleError = response.data.errorMessage;
                    return false;

                }
            });
        }


        $scope.saveAd = function (adData) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adId": $window.localStorage.getItem("adId"),
                "adDetails": adData
            };
           
			facebookGetPost.saveaddatapost("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    console.log(response.data.successMessage);
                    $rootScope.progressLoader = "block";
                    $scope.showSuccessPopup(response.data.successMessage);
                    // $scope.getAdCreative();
                    $scope.getAdSetAdCreative();
                    $scope.networkErrorPopup = "none";
                    $scope.popupTitleError = "";
                    $scope.popupTitleError = "";
                }
                else {
					$rootScope.progressLoader = "none";
                    console.log('failed $scope.saveAd');
                    $scope.showErrorPopup(response.data);
                    $scope.networkErrorPopup = "block";
                    $scope.popupTitleError = "Error";
                    $scope.popupTitleError = response.data.errorMessage;
                    return false;
                }
            });
        }
        $scope.getAdSetAdCreative = function () {

            var queryStr = "?adSetId=" + $window.localStorage.getItem("adsetId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           
			facebookGetPost.getadsetadcreative(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
					$rootScope.progressLoader = "none";
					$scope.mainLoader = "none";
                    $scope.adCreativeDatailsResponse = response.data.fbAdSetCreativeResponse.data[0];                   
                    $scope.saveAdAccountAdCreative($scope.adCreativeDatailsResponse)
					//$scope.fbadvertFormat = "fbslideshow";
                    if($scope.fbadvertFormat == "fbsingleimage"){
                        $scope.thumbnail = $scope.adCreativeDatailsResponse.thumbnail_url;
                         $scope.thumbnailVideo = "images/campaign/single-video.png";
				          $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
						 $scope.thumbnailCarousel = "images/campaign/carousel.svg";
						   $scope.imgthumbnaildiv = true;
                         
                    }else if($scope.fbadvertFormat == "fbsinglevideo"){
                        $scope.thumbnail="images/campaign/single-image.png";
                         $scope.thumbnailVideo = $scope.adCreativeDatailsResponse.thumbnail_url;
						 $scope.thumbnailCarousel = "images/campaign/carousel.svg";
						  $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
						  $scope.vidthumbnaildiv = true;
                    }
					else if($scope.fbadvertFormat == "fbcarosel"){
						  $scope.thumbnailCarousel = $scope.adCreativeDatailsResponse.thumbnail_url;
                          $scope.thumbnailVideo="images/campaign/single-video.png";
                          $scope.thumbnail="images/campaign/single-image.png";

						 $scope.thumbnailSlideshow = "images/campaign/slide-show.png";
                    }else if($scope.fbadvertFormat == "fbslideshow"){
                        $scope.thumbnail="images/campaign/single-image.png";
                         $scope.thumbnailVideo =  "images/campaign/single-video.png";
						  $scope.thumbnailSlideshow = $scope.adCreativeDatailsResponse.thumbnail_url;
						  $scope.thumbnailCarousel = "images/campaign/carousel.svg";
						  $scope.slideShowCreate = false;			
	                     $scope.slideShowSuccess = true;			
	                    $scope.slideShowPreview = $scope.adCreativeDatailsResponse.thumbnail_url;
                    }
					
					
                    //$scope.saveAdAccountAdCreative($scope.adCreativeDetails);
                    //console.log(response.data.successMessage);
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        vm.getData = {};
                        if(response.data.networkError){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });

        }
        $scope.getAdCreative = function () { 
            //   var queryStr = "adAccountId="+$scope.networkAdAccountId+"&networkMapId="+$window.localStorage.getItem("userNetworkMapId")+"&limit=10";
            var queryStr = "?adsetid=" + $window.localStorage.getItem("adsetId") + "&networkmapid=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            
			facebookGetPost.getadcreative(queryStr, headers).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {// success
					$rootScope.progressLoader = "none";
                    $scope.fbAdCreativeResp = response.data.fbAdCreativeResponse;
                    console.log($scope.fbAdCreativeResp);
                    for (var i = 0; i < response.data.fbAdCreativeResponse.data.length; i++) {
                        if ($window.localStorage.getItem("adCreativeId") == response.data.fbAdCreativeResponse.data[i].id) {
                            $scope.respAdCreativeObj = response.data.fbAdCreativeResponse.data[i];
                        }
                    }
                    console.log($scope.respAdCreativeObj);

                    $scope.saveAdAccountAdCreative($scope.respAdCreativeObj);
                    console.log(response.data.successMessage);
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
        }

        $scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }


        $scope.sendBodyContent = function (val) {
            $scope.textBodyContent = val;
            angular.element('#step2').css('background-color', '#C2C2C2');
            if($scope.textBodyContent!=null && $scope.textBodyContent!="" && $scope.textBodyContent!=undefined)
            {
                angular.element('#textBodyContent').removeClass("mandatory");
            }else
            {
                angular.element('#textBodyContent').addClass("mandatory");
            }
            $window.localStorage.setItem("textBodyContent", $scope.textBodyContent);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));			
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            $scope.removeThumbnail();
            $scope.checkMandatoryVal();
        };

        $scope.sendHeadline = function (val) {
		
            $scope.campaignHeadline = val;
            if($scope.campaignHeadline!=null && $scope.campaignHeadline!="" && $scope.campaignHeadline!=undefined)
            {
                angular.element('#campaignHeadline1').removeClass("required");
            }else
            {
                angular.element('#campaignHeadline1').addClass("required");
            }
            $window.localStorage.setItem("campaignHeadline", $scope.campaignHeadline)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; } */
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             
        };
		
	$scope.sendLeadForm = function (val) {
            $scope.selectLeadForm = val;
            $window.localStorage.setItem("selectLeadForm", $scope.selectLeadForm)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
        };
		
		$scope.sendmessengertext = function (val) {
            $scope.messengertextBodyContent = val;
            $window.localStorage.setItem("sendmessengertext", $scope.messengertextBodyContent)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
        };
		
        
            $scope.sendHeadline1 = function (val) {
            $scope.campaignHeadline1 = val;
            if($scope.campaignHeadline1!=null && $scope.campaignHeadline1!="" && $scope.campaignHeadline1!=undefined)
            {
                angular.element('#idcampaignHeadline').removeClass("required");
            }else
            {
                angular.element('#idcampaignHeadline').addClass("required");
            }
            $window.localStorage.setItem("campaignHeadline1", $scope.campaignHeadline1)
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; } */
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
             
             
        };
        $scope.sendnewsfeedlinkdesc = function (val) {
            $scope.newsfeedlinkdesc = val;
            if($scope.newsfeedlinkdesc!=null && $scope.newsfeedlinkdesc!="" && $scope.newsfeedlinkdesc!=undefined)
            {
                angular.element('#txtnewsfeedlinkdesc').removeClass("mandatory");
            }else
            {
                angular.element('#txtnewsfeedlinkdesc').addClass("mandatory");
            }
            $window.localStorage.setItem("newsfeedlinkdesc", $scope.newsfeedlinkdesc)
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
			//angular.element($('.accordianRole').prop('disabled', true));
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true; }*/
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
             
             

        };
		
		//Carousel card textbox model
		 
		$scope.sendCardHeadline = function (val,index) {
		console.log(index);
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardHeadline = val;			
			// $scope.headlinecontents = [];
			 $scope.headlinecontents[index] = $scope.cardHeadline[index];
                         if($scope.cardHeadline[index]!=null && $scope.cardHeadline[index]!="" && $scope.cardHeadline[index]!=undefined)
                        {
                            angular.element("#cardHeadline"+index).removeClass("required");
                        }else
                        {
                            angular.element("#cardHeadline"+index).addClass("required");
                        } 
			 console.log($scope.headlinecontents);					
			$window.localStorage.setItem("cardHeadline", JSON.stringify($scope.headlinecontents));
		}
		     
        };
		
		$scope.sendCardDescription = function (val,index) {
		
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardDescription = val;			
			// $scope.descriptioncontents = [];
			 $scope.descriptioncontents[index] = $scope.cardDescription[index];	
			console.log($scope.descriptioncontents);			 
			$window.localStorage.setItem("cardDescription", JSON.stringify($scope.descriptioncontents));
		}
		 
             
        };
		
		$scope.sendcardwebURL = function (val,index) {			
		if($scope.fbadvertFormat == 'fbcarosel'){			
			$scope.cardwebURL = val;			
			// $scope.weburlcontents = [];
			$scope.weburlcontents[index] = $scope.cardwebURL[index];
                        if($scope.cardwebURL[index]!=null && $scope.cardwebURL[index]!="" && $scope.cardwebURL[index]!=undefined)
                        {
                            angular.element("#cardwebURL"+index).removeClass("mandatory");
                        }else
                        {
                            angular.element("#cardwebURL"+index).addClass("mandatory");
                        } 
			$window.localStorage.setItem("cardwebURL", JSON.stringify($scope.weburlcontents));
			console.log($scope.weburlcontents);	
		}
		 
             
        };

        $scope.sendLandingView = function (val) {
            $scope.campaignLandingView = val;
            $rootScope.freezeFlag = true;
            angular.element($('.btnCampaignCreative').prop('disabled', true));
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
        };

        $scope.getAdAccountAdCreative = function () {
		

            $scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));

            //angular.element($('.btnCampaignCreative').prop('disabled', false));
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
			//angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
           // angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
			//angular.element($('.accordianRole').prop('disabled', false));
            var queryStr = "?adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
            
			facebookGetPost.getadimages(queryStr, headers).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    $scope.mainLoader = "none";
                    $scope.browselibrary = "block";
                    var arrAdAccountCreativeallData = [];
                    
                    angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
                    $scope.uniqueArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
//                    for (var i = 0; i < response.data.adAccountAdCreative.length; i++) {
//                        if (response.data.adAccountAdCreative[i].image_hash != undefined) {
//                            arrAdAccountCreativeallData.push(response.data.adAccountAdCreative[i]);
//                        }
//                    }
//                    $scope.uniqueArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "image_hash");
//                    for (var i = 0; i < response.data.adAccountAdCreative.length; i++) {
//                        if ($window.localStorage.getItem("adCreativeId") == response.data.adAccountAdCreative[i].id) {
//                            $scope.respGetAdCreativeObj = response.data.adAccountAdCreative[i];
//                        }
//                    }
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;

                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
            // }
        }


        $scope.saveAdAccountAdCreative = function (respGetAdCreativeObj) {
            var parameters = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                "adSetID": $window.localStorage.getItem("adsetId"),
                "adCreativeID": $window.localStorage.getItem("adCreativeId"),
                "adCreativeDetails": respGetAdCreativeObj,
            };
           
            facebookGetPost.saveadsetadcreative("", parameters).then(function (response) {
                if (response.data.appStatus == 0) {
                    $rootScope.campaignSteps[3] = true;
                    $rootScope.progressLoader = "none";		
                    $scope.mainLoader = "none";
                    angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                    angular.element('.btnCampaignCreative').css('opacity', '1');
                    //$rootScope.step = 4;
                }
                else {
                    console.log('failed');
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        vm.getData = {};
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
        }
        $scope.deleteAdCreative = function (imageHashVal) {
		  $rootScope.progressLoader = 'block';
            var isCreateAd = $window.localStorage.getItem("adId");
            var isAdDetails = $window.localStorage.getItem("adData");
            var queryStr = "?adCreativeId=" + $window.localStorage.getItem("adCreativeId") + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
           
			facebookGetPost.deleteadcreative(queryStr, headers).then(function (response) {
                //alert(response.data.appStatus)
                if (response.data.appStatus == '0') {// success
                    //$scope.creativeAdCreative(hashVal);
                    $scope.networkErrorPopup = 'none';
                    $scope.popupTitleError = '';
                    $scope.popupMessageError = '';
                    $window.localStorage.setItem("deleteAdCreativeStatus", "true");
				
					if (isCreateAd) {
                        $scope.deleteAd();
                    }
                    $scope.proceedToCreateAdCreative(imageHashVal);

                } else {// failed
                    if(response.data.appStatus > 0 && (response.data.errorId == 10006)) {
                        $window.localStorage.setItem("deleteAdCreativeStatus", "true");

                        if (isCreateAd) {
                            $scope.deleteAd();
                        }
                        $scope.proceedToCreateAdCreative(imageHashVal);  
                    } else if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }                       

                    }
                    $window.localStorage.setItem("deleteAdCreativeStatus", "false");


                }
            });
        }

        $scope.deleteAd = function () {
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adId=" + $window.localStorage.getItem("adId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            
			facebookGetPost.deletead(queryStr, headers).then(function (response) {
                if (response.data.appStatus == '0') {// success
                    console.log("success delete ad");
                    $scope.networkErrorPopup = 'none';
                    $scope.popupTitleError = "";
                    $scope.popupMessageError = '';
                    //var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
                   // if (isCreativeAdCreativeId) {
                  //  $scope.deleteAdCreative();
                 //   }
					$scope.getAdForDelete();
                } else {// failed
                    console.log("failed $scope.deleteAd");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    return false;
                }
            });
        }
        $scope.saveAndProceedNextStep = function () {
            console.log("textBodyContent : " + $scope.textBodyContent);
            console.log("imagesSource : " + $scope.imagesSource);
            console.log("hashVal : " + $scope.hashVal);
            //  if(($scope.textBodyContent != "") && ($scope.imagesSource != "" || $scope.hashVal != "")){
            //angular.element($('.btnCampaignCreative').prop('disabled', false));
            $rootScope.freezeFlag = false;
            $rootScope.campaignSteps[3] = true;
			 $rootScope.campaignSteps[4] = true;
            $state.go('app.fbcampaignsummary');
            /* }
             else{
             angular.element($('.btnCampaignCreative').prop('disabled', true));
             console.log("Please upload/browse image");
             }*/

        }
        $scope.closePopup = function () {
            $scope.editAdsetErrorMsg = "none";
            $scope.mainLoader = "none";
            $scope.browseImgSuccessMsg = "none";
            $scope.browselibrary = "none";
            $scope.browselibraryvideos = "none";
            angular.element($('body').css("overflow-y", "scroll"));
            vm.getData = {};
            if($scope.thumbnail != '' && $scope.thumbnail != "images/campaign/single-image.png"
                && $scope.fbadvertFormat == "fbsingleimage") {
                $scope.imgthumbnaildiv = true;
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
            } else if ($scope.thumbnailVideo != '' && $scope.thumbnailVideo != "images/campaign/single-video.png"
                && $scope.fbadvertFormat == "fbsinglevideo") {
                $scope.vidthumbnaildiv = true;
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
            } else if ($scope.thumbnailSlideshow != '' && $scope.thumbnailSlideshow != "images/campaign/slide-show.png"
                && $scope.fbadvertFormat == "fbslideshow") {
                $scope.slideShowCreate = false;
                $scope.slideShowSuccess = true;
                angular.element($('.btnCampaignCreative').prop('disabled', false));
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step3').css('background-color', '#95D2B1');
                angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'pointer');
                angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
                angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                angular.element('.btnCampaignCreative').css('pointer-events', 'auto');
                angular.element('.btnCampaignCreative').css('opacity', '1');
            }

        };


        $scope.changeSelection = function (image_hash) {
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.getExistingVideosID = function (videoID) {
            if (angular.element($("#" + videoID).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + videoID).parent(".galleryImages").addClass('sel_bk_color'));
            }

        }
        $scope.sendcampaignWebURL = function (campaignWebURL) {
            console.log(campaignWebURL);
            $scope.campaignWebURL = campaignWebURL;
            if($scope.campaignWebURL!=null && $scope.campaignWebURL!="" && $scope.campaignWebURL!=undefined)
            {
                angular.element('#campaignWebURL').removeClass("mandatory");
            }else
            {
                angular.element('#campaignWebURL').addClass("mandatory");
            }
            $window.localStorage.setItem("campaignWebURL", $scope.campaignWebURL);
            var campaignStateForEdit = $window.localStorage.getItem("campaignState");
            /*if(campaignStateForEdit == 'edit'){ 
             $rootScope.freezeFlag  = true;
             angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
             angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
             
             }*/
        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }

        
        $scope.selectlearnMoreUrl = function(_learnMoreUrl)
        {
           $scope.learnMoreUrl = _learnMoreUrl;
            if($scope.learnMoreUrl!=null && $scope.learnMoreUrl!="" && $scope.learnMoreUrl!=undefined)
            {
                angular.element('#learnMoreUrl').removeClass("required");
            }else
            {
                angular.element('#learnMoreUrl').addClass("required");
            } 
        };
         $scope.selectcampaignURLParameter = function(_campaignURLParameter)
        {
            $scope.campaignURLParameter = _campaignURLParameter;
            if($scope.campaignURLParameter!=null && $scope.campaignURLParameter!="" && $scope.campaignURLParameter!=undefined)
            {
                angular.element('#campaignURLParameter').removeClass("required");
            }else
            {
                angular.element('#campaignURLParameter').addClass("required");
            }
        };
        $scope.selectPixelTracking = function(pixelTracking)
        {
            if(pixelTracking!=null && pixelTracking!="" && pixelTracking!=undefined)
            {
                angular.element('#pixelTracking').removeClass("mandatory");
            }else
            {
                angular.element('#pixelTracking').addClass("mandatory");
            }
        };
        

        // Use Exist Post Services integration
        //$scope.fetchuserpromotablepages();
        $scope.promotableposts = function () {
            $http({
                method: 'GET',
                url: 'https://graph.facebook.com/585993311604680/promotable_posts?access_token=EAAJ4OaibPkYBAJVkRNZCKm1ZCuJZATHOaXJNz2TEvZAboSqlBjnsLdv0tZCTKON5ZBXe56y4hIDyOIxi8ulk4kIW5PypmTS1h06Imp3vj1gG3EPBu5LwAgzRGuJZBn87wS4Wf6ZCGIl2F8ZCbzxRlvDGOZAYJhYOUb32mJFUFFZC5mqSKQIJdcWZCnQe&limit=100&fields=name,description,link',
                /*headers: {
                 "userId": $window.localStorage.getItem("userId"),
                 "accessToken": $window.localStorage.getItem("accessToken")
                 }*/
            }).success(function (response) {
                console.log(response);

            }).error(function (error) {
                //alert(error);
            });
        }
		
		
		
		//Carousel advent code start
		
		$scope.selectMedia = function (val,index) {
            $scope.imageFormat = "imagemediaUpdate";            
            $scope.media=true;
			$scope.mediaarrow=true;
			$scope.cardarrow=false;
			
			if($scope.campaignState == 'create'){
					$scope.showVideoPrev[index] = false;
					console.log(index);
				}
			
			
        }

        $scope.selectMedia1 = function (val,index) {
            $scope.imageFormat = "videomediaUpdate";            
            $scope.media=true;
            //$scope.createCards();  
			$scope.mediaarrow=false;
			$scope.cardarrow=true;	
				if($scope.campaignState == 'create'){
					$scope.showImgPrev[index] = false;
					console.log(index);
				} 
			
        }
		
		 $scope.selectMedia2 = function (val) {
            $scope.imageFormat = "videoviewsmediaUpdate";            
            $scope.media=false;
            //$scope.createCards();  
			$scope.mediaarrow=false;
			$scope.cardarrow=false;		
			
        }
		
		 $scope.selectImagePopup = function (index) {
		 
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
				else{
					
				//$rootScope.progressLoader = 'block';
                document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";
				 //	document.getElementById("seeMoreUrl").style.borderColor = "#A9A9A9";
                $scope.errTextMsg = "none";
				angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
               /* angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); */
                $scope.step2_green=true;
				$scope.uploadimgcount = index;
				angular.element($('body').css("overflow", "hidden"));
				var createPopup = $(".selectImagePopup");// Get the modal Reject req
				
				$scope.mainLoader = "block";
			
			
			var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId");  
			var headers = {
							"userId": $window.localStorage.getItem("userId"),
							"accessToken": $window.localStorage.getItem("accessToken")
						}			//$scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray1 = "";
           
			facebookGetPost.getadimages(queryStr, headers).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
                    $scope.mainLoader = "none";					
                    //$scope.browselibrary = "block";
                    createPopup.show();
                    var arrAdAccountCreativeallData = [];
					console.log(response.data.adImages.length);
                    angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    }); 
					$scope.uniqueArray1 = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");
					//console.log(uniqueArray1);
					console.log(arrAdAccountCreativeallData);
                    console.log($scope.respGetAdCreativeObj);
					
                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                       // $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                }
            });
			
			}
			
		 }
		 
		 
		  $scope.selectVideoPopup = function (index) {
		  
		  
				angular.element($('.panel-collapse.collapse.in').removeClass("in"));
				if ($scope.textBodyContent == "") {
                document.getElementById("textBodyContent").style.borderColor = "#ff0000";
				//document.getElementById("seeMoreUrl").style.borderColor = "#ff0000";
                window.scrollTo(0, 0);
				//console.log(document.body.scrollHeight);
                $scope.errTextMsg = "block";
                angular.element($('.btnCampaignCreative').prop('disabled', true));				
				angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
				}
				
			else {	
			
			 document.getElementById("textBodyContent").style.borderColor = "#A9A9A9";				
             $scope.errTextMsg = "none";
             angular.element($('.btnCampaignCreative').prop('disabled', false));
			 angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			 angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1,  Note : Please select image/video");
			$scope.uploadimgcount = index;
			angular.element($('body').css("overflow", "hidden"));
            var createPopup = $(".selectVideoPopup");// Get the modal Reject req
            createPopup.show();
			$scope.mainLoader = "block";
			
			 var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
			 angular.element($('body').css("overflow-y", "hidden"));
			 var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
			 $scope.uniqueArrayVideo = "";
            
			facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
			
			 if (response.data.appStatus == '0') {// success
				console.log(response.data);
                 $scope.mainLoader = "none";		
               // $scope.browselibraryvideos = "block";
                //console.log(response.data.data);
                $scope.existVideosList = response.data.data;
				
				var arrAdAccountCreativeallDataVideo = [];
                     angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
					// $scope.uniqueArrayVideo = $scope.removeDuplicates(arrAdAccountCreativeallDataVideo, "id");                  
					$scope.uniqueArrayVideo = arrAdAccountCreativeallDataVideo;                  
                    console.log($scope.uniqueArrayVideo);
					
			}
		 else {
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                        //Flash.create('danger', response.errorMessage, 'large-text');
                    }
                } 
			
            });
			
			} 
			
		 }
		 
		 
		 
		 
		 $scope.selectImage = function(){
			$scope.imagePreviewSrc[$scope.uploadimgcount] = $scope.selectedImagegallery;	
			$('#imagePreview'+$scope.uploadimgcount).attr('src', $scope.selectedImagegallery);	
			$('#imagePreview'+$scope.uploadimgcount).attr('class', $scope.selectedImagegalleryHash);	
			$scope.showImgPrev[$scope.uploadimgcount] = true;
			//$scope.closePopup();
			angular.element($('body').css("overflow-y", "scroll"));
			angular.element($('#fbImagepopup').css("display","none"));
			$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('src'));			
			$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('class'));			
			$scope.setLine();
                        vm.getData = {};
		 };
		 
		 
		  $scope.selectVideo = function(){
			$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.selectedImagegallery;	
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.selectedImagegallery);
			$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.selectedImagegalleryVideo);				
			$scope.showVideoPrev[$scope.uploadimgcount] = true;
			angular.element($('body').css("overflow-y", "scroll"));
			angular.element($('#fbVideopopup').css("display","none"));
			$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
			$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));			
			$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
			console.log($scope.uniqueImageSelectionArray);
			$scope.setLine();
			vm.getData = {};
		 };
		 
		
			$scope.selectedImagePush = [];
		$scope.changeSelectionImage = function (image_hash) {
			
            if (angular.element($("#" + image_hash).is(':checked'))) {
                angular.element($('.galleryImages').removeClass('sel_bk_color'));
                angular.element($("#" + image_hash).parent(".galleryImages").addClass('sel_bk_color'));
				
				
				// console.log($('.galleryImages label img').attr('src'));
				console.log($('.sel_bk_color label img').attr('src'));
				$scope.selectedImagegallery = $('.sel_bk_color label img').attr('src');
				$scope.selectedImagegalleryHash = image_hash;
				console.log($scope.selectedImagegalleryHash);
				$scope.selectedImagePush.push(image_hash);
				
            }
			// $scope.selectedImagePush.push(image_hash);
			

        }
		 
		
		 $scope.changeSelectionVideo = function (videoID1) {
			console.log(videoID1);
           
				 if (angular.element($(".galleryVideos #" + videoID1).is(':checked'))) {				 
					angular.element($('.galleryVideos').removeClass('sel_bk_color1'));
                angular.element($(".galleryVideos #" + videoID1).parent(".galleryVideos").addClass('sel_bk_color1'));	

						console.log($('.sel_bk_color1 label img').attr('src'));
				$scope.selectedImagegallery = $('.sel_bk_color1 label img').attr('src');
				$scope.selectedImagegalleryVideo = $('.sel_bk_color1 label img').attr('class');
				$scope.selectedImagegalleryHash = videoID1;
				console.log($scope.selectedImagegalleryHash);
				$scope.selectedImagePush.push(videoID1);
				
				//Code to remove duplicate hash value from array
				/* $scope.uniqueImageSelectionArray = $scope.selectedImagePush.filter(function( item, index, inputArray)
					{
						return inputArray.indexOf(item) == index;
					});
			
			console.log($scope.uniqueImageSelectionArray); */
				
            }

        }
		 
		  $scope.deleteImg = function (index) {
			//console.log(index);
                        $scope.selectedImagegalleryArray[index]="";
            $scope.uploading = true;
            $scope.previewing = false;
			console.log($('#imagePreview'+index).attr('src'));
			$('#imagePreview'+index).attr('src', '#');
			//angular.element($('.cards-content .imgprv #imagePreview'+index).css("visibility", "hidden"));
			//angular.element($('.cards-content .imgprv #imagePreview'+index+ '+span').css("visibility", "hidden"));
			$scope.showImgPrev[index] = false;
        }
		
		 $scope.deleteImgVideo = function (index) {
                     $scope.selectedImagegalleryArray[index]="";
			//console.log(index);
            $scope.uploading = true;
            $scope.previewing = false;
			console.log($('#imagePreviewVideo'+index).attr('src'));
			$('#imagePreviewVideo'+index).attr('src', '#');			
			$scope.showVideoPrev[index] = false;
        }
		 
		 //Image Upload section carousel
		 
		   $scope.uploadFile = function (files) {
		   
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = files[0];
            });
            var reader = new FileReader();
            reader.onload = function (e) {			
                $('#imagePreview'+$scope.uploadimgcount).attr('src', e.target.result);				
				$scope.showImgPrev[$scope.uploadimgcount] = true;
                $scope.dataURL = reader.result;                
                $scope.splittedData = $scope.dataURL.split(',')[1]; 
				$scope.mainLoader = "block";
            };
            
			 $timeout(function () {                    				
			$scope.mainLoader = "block";
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
			parameters.append('type','IMAGE');
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('imageFile',files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadimage";

					 if (typeof (files[0]) == "object") {                   
					facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                        console.log(response);
						$rootScope.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
							$scope.mainLoader = "none";
							angular.element($('body').css("overflow-y", "scroll"));
							angular.element($('#fbImagepopup').css("display","none"));	
                            $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
							console.log($scope.hashVal);
                            $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
							console.log($scope.hashUrl);
                            var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
							
                          $scope.imagePreviewSrc[$scope.uploadimgcount] = $scope.hashUrl;	
						  $('#imagePreview'+$scope.uploadimgcount).attr('src', $scope.hashUrl);
						  $('#imagePreview'+$scope.uploadimgcount).attr('class', $scope.hashVal);						
							$scope.showImgPrev[$scope.uploadimgcount] = true;
							$scope.selectedImagePush.push($scope.hashVal);
							$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('class'));
							console.log($scope.uniqueImageSelectionArray);
							$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreview'+$scope.uploadimgcount).attr('src'));
							console.log($scope.selectedImagegalleryArray);
                        }
                        else {
                            console.log('failed $scope.getCampaignfiles');
							$scope.showErrorPopup(response.data);
							$scope.mainLoader = "none";
                            // Flash.create('danger', response.errorMessage, 'large-text');
                        }															
                    });
					
					}
																			
                }, 1000);
			
			
			
            reader.readAsDataURL(files[0]);
          
        };
		
		
	   $scope.closeImagePopup = function () {
            $scope.mainLoader = "none";            
            angular.element($('body').css("overflow-y", "scroll"));			
			angular.element($('#fbImagepopup').css("display","none"));
			
			console.log($('#imagePreview'+$scope.uploadimgcount).attr('src'));
			if($('#imagePreview'+$scope.uploadimgcount).attr('src') == "#"){
			$('#imagePreview'+$scope.uploadimgcount).attr('src', ' ');
			$('#imagePreview'+$scope.uploadimgcount).attr('class', ' ');				
				$scope.showImgPrev[$scope.uploadimgcount] = false;
				}
        }	
		

        $scope.closeVideoPopup = function () {
            $scope.mainLoader = "none";            
            angular.element($('body').css("overflow-y", "scroll"));						
            angular.element($('#fbVideopopup').css("display","none"));

            console.log($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
            if($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src') == "#"){
            $('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', ' ');
            $('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', ' ');				
            $scope.showVideoPrev[$scope.uploadimgcount] = false;
            }
            vm.getData = {};
        };

		$scope.validateCarousel = function()
                {
                    console.log("validated");
                    console.log($scope.selectedImagegalleryArray);
                    $scope.index = [];
					
				if($scope.marketingObjective == "VIDEO_VIEWS" || $scope.marketingObjective == "OFFER_CLAIMS"){
					
                    for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }                       
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
				}
				
				else if($scope.marketingObjective == "LEAD_GENERATION"){
					
                    for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }                       
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
						
						  if($scope.selectLeadForm=="" || $scope.selectLeadForm==undefined || $scope.selectLeadForm==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
				}
				
				
				else{
					 for(var i=0;i<$scope.tabs.length;i++)
                    {
                        if($scope.headlinecontents[i]=="" || $scope.headlinecontents[i]==undefined || $scope.headlinecontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                        if($scope.weburlcontents[i]=="" || $scope.weburlcontents[i]==undefined || $scope.weburlcontents[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                        if($scope.selectedImagegalleryArray[i]=="" || $scope.selectedImagegalleryArray[i]==undefined || $scope.selectedImagegalleryArray[i]==null)
                        {
                            if($scope.index.indexOf(i)==-1)
                            {
                                $scope.index.push(i);
                            }
                        }
                    }
					
				
				}
                    if($scope.index.length==0)
                    {
                        for(i=0;i<$scope.tabs.length;i++)
                        {
                            console.log($scope.tabs[i].title-1);
                            angular.element('#mainCntr #'+($scope.tabs[i].title-1)).removeClass("mandatory_red");
                        }
                        angular.element('#step2').css('background-color', '#95D2B1');
                        console.log("if")
                        $scope.createCarousel();
                    }
                    else
                    {
                        for(i=0;i<$scope.tabs.length;i++)
                        {
                            for(j=0;j<$scope.index.length;j++)
                            {
                                angular.element('#mainCntr #'+$scope.index[j]).addClass("mandatory_red");
                                if($scope.index[j]!= ($scope.tabs[i].title - 1))
                                {
                                    angular.element('#mainCntr #'+($scope.tabs[i].title-1)).removeClass("mandatory_red");
                                }
                            }
                            
                        }
                        angular.element('#step2').css('background-color', '#c2c2c2');
                    }
                };

	
		$scope.createCarousel = function(){
			
			angular.element($('.btnCampaignCreative').prop('disabled', false));
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1"); 			
			if($scope.selectedImagegalleryArray.length >= 2){
			$scope.mainLoader = "block";
					 var isCreativeAdCreativeId = $window.localStorage.getItem("adCreativeId");
						if (isCreativeAdCreativeId) {
							$scope.deleteAdCreative();
							$window.localStorage.removeItem("adCreativeId");
							if ($window.localStorage.removeItem("deleteAdCreativeStatus")) { //alert("dfdsf")
								$scope.networkErrorPopup = 'block';
								return;
							}
						}
					console.log($scope.selectedImagegalleryArray);
					 $scope.pageIdVal = $scope.selectedTarget;
					 $scope.objectType = "SHARE";
					 
			
			
				
			if($scope.marketingObjective == "OFFER_CLAIMS"){
				console.log('offer claims obj');
				var parameterAdd  = {};
					var parameterCheck = {};
					parameterCheck = {
						"page_id": $scope.pageIdVal							
					};
					
					var child_attachments = [];
					for(var i=0; i<$scope.selectedImagegalleryArray.length; i++)  {
					console.log('Image selected');
					child_attachments.push(
					{link: $window.localStorage.getItem("OfferRedemptionLink"), image_hash: $scope.uniqueImageSelectionArray[i], name: $scope.cardHeadline[i], call_to_action: {type: "GET_OFFER_VIEW"} });
					
					}
					
					var link_data1 = {	
								"link" : $window.localStorage.getItem("OfferRedemptionLink"),
                                "message": $scope.textBodyContent, 
								"call_to_action": {
								   "type": "GET_OFFER_VIEW"
								},
								"offer_id": $scope.campaignAudienceCampaignOffer
									
					}
					var ck = {
						"child_attachments" : 	child_attachments
					}
					
					var link_data = angular.extend({},link_data1,ck);
					var lk = {
						"link_data": link_data
					}
					parameterCheck = angular.extend({},parameterCheck,lk);
					
					parameterCheck = angular.extend({},parameterCheck,parameterAdd);
					$scope.objectStorySpec = angular.extend({},parameterCheck);
					
					console.log($scope.objectStorySpec);
			}
				
				
				
				var parameters = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    "userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
                    "accountId": $scope.networkAdAccountId, //101870703634673,                    
                    "objectType": $scope.objectType,
                    "objectStorySpec": JSON.stringify($scope.objectStorySpec),
                    "body": $scope.textBodyContent,
                    "name": "optional fields"
                            
                };
				
				 if ($scope.campaignURLParameter != '' && $scope.campaignURLParameter != 'undefined' && $scope.campaignURLParameter != null){
                var urlparams = {
                        "urlTags": $scope.campaignURLParameter
                }
                parameters = angular.extend({},parameters,urlparams);
            }
					
			
			facebookGetPost.createadcreative("", parameters).then(function (response) {

                if (response.data.appStatus == 0) {
					$scope.mainLoader = "none";                   
                    $scope.adCreativeId = response.data.adCreativeId;                  
                    $window.localStorage.setItem("adCreativeId", $scope.adCreativeId);
                    $scope.browselibraryPopupHeading = "Browse Library";
                    $scope.browselibrarySuccessMsg = "successfully uploaded";
                    $scope.createAd();
                    $scope.desktopCreativePreview();
                    $scope.mobileCreativePreview();
                    $scope.rightColumnCreativePreview();                    
                    $scope.browselibrary = "none";
					angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element('#step2').css('background-color', '#95D2B1');
					angular.element('#step3').css('background-color', '#95D2B1');
                    angular.element($('.btnCampaignCreative').prop('disabled', false));
					angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                    $scope.step2_green=true;
                }
                else {
                    $scope.mainLoader = "none";
                    $rootScope.progressLoader = "none";
                     vm.getData = {}; 
                    $scope.showMediaErrorPopup(response);
					angular.element($('.btnCampaignCreative').prop('disabled', true));					
					angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
					angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");                    
                }
            });  
					
			}
			
		}
		
	
//Carousel video file upload

$scope.getCampaignVideoFilesCarousel = function (element) {
			$rootScope.progressLoader = 'block';            
            $scope.$apply(function ($scope) {
                $scope.uploadedfilename = element.files[0];
            });
			var parameters = new FormData();
			parameters.append('userId',$window.localStorage.getItem("userId"));
			parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
			parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
			parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
			parameters.append('source',element.files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadvideo";		
			
            if (typeof (element.files[0]) == "object") {             
				facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {
                    //console.log(response);
					$scope.mainLoader = "none";
                    if (response.data.appStatus == '0') {
                        $scope.newvideoID = response.data.adVideoId;
                        console.log($scope.newvideoID);
						$scope.callGetadvideosCarousel($scope.newvideoID);
						angular.element($('body').css("overflow-y", "scroll"));
						angular.element($('#fbVideopopup').css("display","none"));
                       
                    } else {
                        console.log("failed $scope.getCampaignVideoFiles");
						$scope.showErrorPopup(response.data);
						$scope.mainLoader = "none";
                    }
                });



            }
        };	
		
		
		$scope.callGetadvideosCarousel = function(newvideoID){
            console.log('getvideocarousel');
            var modalErr = $(".video_error_popup_carousel");
			angular.element($('body').css("overflow-y", "scroll"));
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "?adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID;
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
				}
                $scope.mainLoader = "block";
               
				facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
                                    $scope.pictureFormat = adVideoID.format;
                                    $scope.videoStatus = adVideoID.status;
                                    angular.forEach( $scope.pictureFormat,function(ulrVal){
                                        if(ulrVal.filter == "native"){
                                            $scope.imageURLValue = ulrVal.picture;
                                            $scope.slideShowSource = adVideoID.source;
											
											$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.imageURLValue;	
											$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.imageURLValue);
											$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.slideShowSource);
											$scope.showVideoPrev[$scope.uploadimgcount] = true;
											$scope.selectedImagePush.push($scope.hashVal);
											$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
											console.log($scope.uniqueImageSelectionArray);
											
											$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
											$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
											console.log($scope.selectedImagegalleryArray);	
                                        }
                                    });
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';
                        $scope.checkCreatedVideoStatusCarousel(newvideoID);
                    } 
                });
            
            },0);

        }
		
		
		$scope.checkCreatedVideoStatusCarousel = function(newvideoID){
            $scope.newvideoID = newvideoID;
            if($scope.videoStatus){
                if($scope.videoStatus.video_status == "ready"){
					console.log('video upload success');
                    console.log($scope.newvideoID+"|"+$scope.imageURLValue);
					$scope.imagePreviewVideoSrc[$scope.uploadimgcount] = $scope.imageURLValue;	
					$('#imagePreviewVideo'+$scope.uploadimgcount).attr('src', $scope.imageURLValue);
					$('#imagePreviewVideo'+$scope.uploadimgcount).attr('class', $scope.newvideoID);
					$scope.showVideoPrev[$scope.uploadimgcount] = true;
					$scope.selectedImagePush.push($scope.hashVal);
					$scope.uniqueImageSelectionArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
					console.log($scope.uniqueImageSelectionArray);
					
					$scope.selectedImagegalleryArray[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('src'));
					$scope.selectedImagegalleryArrayVideo[$scope.uploadimgcount]=($('#imagePreviewVideo'+$scope.uploadimgcount).attr('class'));
					console.log($scope.selectedImagegalleryArray);	
                    //$scope.creativeAdCreative($scope.newvideoID+"|"+$scope.slideShowSource);
                }else if($scope.videoStatus.video_status == "error"){
                    $scope.popupTitle = 'Error';
                    $scope.popupMessage = "";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                }else{
                    $scope.popupTitle = 'Video Status Error';
                    $scope.popupMessage = "processing error, would you like to continue...";
                    angular.element($('body').css("overflow-y", "hidden"))
                    var modalErr = $(".video_error_popup_carousel");
                    modalErr.show();
                    //$scope.callGetadvideos(newvideoID);
                }			
            }			
        }
		 
$scope.tabs = [{
    title: '1'
},
{
title: '2'
}];


 $timeout(function () {		
		if($scope.tabs.length == 2){
		console.log($scope.tabs.length);
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
		}
	},1000);
		


$scope.removeTab = function($index) {

	if($scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
	}
	else{

    console.log("Removing tab: " + $index);
//	$scope.cardHeadline[$index] = "";
//	$scope.cardDescription[$index] = "";
//	$scope.cardwebURL[$index] = "";	
	$scope.selectedImagegalleryArray.splice($index, 1); 
        $scope.imagePreviewVideoSrc.splice($index, 1);
        $scope.showVideoPrev.splice($index, 1);
        $scope.cardHeadline.splice($index,1);

   $scope.tabs.splice($index, 1);	
	$scope.leftStyle1 = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) - 42;
	console.log($scope.leftStyle1);
	$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",$scope.leftStyle1);	
	for(i=0;i<$scope.tabs.length;i++){
			$scope.tabs[i].title = (i+1);
	}
	if($scope.tabs.length == 2){
		angular.element($('.cards-content #contentBlock0 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock1 .removeCard').css("display", "none"));
		angular.element($('.cards-content #contentBlock2 .removeCard').css("display", "none"));
	}
	}
     
  };

  $scope.addTab = function($index) {
    var len = $scope.tabs.length + 1;
    var numLbl =  len;

    if(numLbl <=10){
	$scope.cardHeadline[numLbl-1] = "";
	$scope.cardDescription[numLbl-1] = "";
	$scope.cardwebURL[numLbl-1] = "";
	$scope.showImgPrev[numLbl-1] = false;
	$scope.showVideoPrev[numLbl-1] = false;
	
	$scope.leftStyle = parseInt($(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left").replace('px','')) + 42;
	//console.log($scope.leftStyle);
	$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left",$scope.leftStyle);
	
	 $scope.tabs.push({
      title: numLbl     
	  
    });
       
	for(i=0;i<$scope.tabs.length;i++){
			$scope.tabs[i].title = (i+1);		
			angular.element($('.cards-content '+'#contentBlock'+i+' .removeCard').css("display", "block"));
				
	}
    
    }
  };
  
  
  $scope.cardSelection = function(index){	
  
	var len = $scope.tabs.length + 1;
	var len1 = $scope.tabs.length - 1;
    var numLbl =  len;
	
	if(index == numLbl - 2 && index !=2){	
		
		//$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","420px");
		if(index == 3){
			$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","185px");
		}
		else if(index == 4){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","230px");}
		else if(index == 5){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","265px");}
		else if(index == 6){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","312px");}
		else if(index == 7){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","355px");}
		else if(index == 8){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","392px");}
		else if(index == 9){$(".sectionBrowse .sectionBrowseCarosel .cards-content .addBtn").css("left","436px");}
		
	}
  
		 $timeout(function () {
		//console.log($('#contentBlock'+index+' .cardContainer .mediaBlock').height());
		var imgSelector = $('#contentBlock'+index+' .cardContainer .mediaBlock').height();
		if(imgSelector > 500){
			$scope.mediaarrow = false;
			$scope.cardarrow = true;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		else{
			$scope.mediaarrow = true;
			$scope.cardarrow = false;
			//$('#contentBlock'+index+' .cardContainer .mediaSelection .customRadioButton input').trigger("click");
		}
		},300);
		
  	}

	//Carousel advent code end
		//ENABLE SLIDESHOW POPUP
	    $scope.onSlideshowSuccess = false;
		$scope.onCreateSlideShow=false;
		$scope.addSlideshow=true;
		$scope.previewSlideShowImage = false;
		$scope.previewSlideShowVideo = false;
		$scope.displaySelectedImages=false;
		$scope.displaySelectedVideos=false;
		$scope.displaySelectedImagesBtn = true;
		$scope.displaySelectedVideosBtn=false;
		$scope.aspectRatioOptions = [
		
			{	
				"id":"Original",
				"name":"Original "	
			},
			{	
				"id":"Square",
				"name":"Square (1:1)"	
			},
			{	
				"id":"Rectangle",
				"name":"Rectangle (16:9)"	
			},
			{	
				"id":"Vertical",
				"name":"Vertical (2:3)"	
			}
		]
		
		$scope.imageDurationOptions = [
		
			{	
				"id":"0.5 seconds",
				"value":"500",
                "key":"0.5"				
			},
			{	
				"id":"1 seconds",
				"value":"1000",
                "key":"01"				
			},
			{	
				"id":"2 seconds",
				"value":"2000"	,
				"key":"02"				
			},
			{	
				"id":"3 seconds",
				"value":"3000",
				"key":"03"								
			},
			{	
				"id":"4 seconds",
				"value":"4000",
				"key":"04"				
			},
			{	
				"id":"5 seconds",
				"value":"5000",
                "key":"05"				
			}
		]
		
	
	$scope.musicOptions = [
		
			{	
				"id":"None",
				"name":"None"	
			},
			{	
				"id":"Chillwave",
				"name":"Chillwave"	
			},
			{	
				"id":"Dreamy",
				"name":"Dreamy"	
			},
			{	
				"id":"Timelapse",
				"name":"Timelapse"	
			},
			{	
				"id":"Space Trip",
				"name":"Space Trip"	
			},
			{	
				"id":"Dance",
				"name":"Dance"	
			},
			{	
				"id":"Workday",
				"name":"Workday"	
			},
			{	
				"id":"Longboard",
				"name":"Longboard"	
			},
			{	
				"id":"Jazzy Samba",
				"name":"Jazzy Samba"	
			},
			{	
				"id":"Electric Coconut",
				"name":"Electric Coconut"	
			},
			{	
				"id":"Action",
				"name":"Action"	
			},
			{	
				"id":"Happy Zone",
				"name":"Happy Zone"	
			},
			{	
				"id":"Garage Groove",
				"name":"Garage Groove"	
			},
			{	
				"id":"Blues Country",
				"name":"Blues Country"	
			},
			{	
				"id":"Wonder",
				"name":"Wonder"	
			},
			{	
				"id":"Wonder",
				"name":"Wonder"	
			},
			{	
				"id":"Homecoming",
				"name":"Homecoming"	
			},
			{	
				"id":"Good Memories",
				"name":"Good Memories"	
			},
			{	
				"id":"Swamp",
				"name":"Swamp"	
			}
			
		]
		$scope.enableSlideShow = function(){
			  if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }
			$scope.showSlideShowBrowser =true;
			$scope.aspectRatio = "Original";
			$scope.imageDuration = "1000";
			$scope.slideShowTransition="none";
			$scope.musicValue = "None";
			$scope.onCreateSlideShow=true;
            $scope.createSlideShowBrowser = true;
			var slideshowpopup = $(".creativeSlideShow");
		    slideshowpopup.show();
			angular.element($('body').css("overflow-y", "hidden"));
			
		}
		
		$scope.selectAspectRatio = function(selectedRatio){
			
				console.log(selectedRatio);
				
		}
		$scope.durationToBeDisplayed = [];
		$scope.selectImageDuration = function(selectedDuration){
			
			angular.forEach($scope.imageDurationOptions,function(getID){
				if(selectedDuration == getID.value){		
					$scope.displayTime = getID.key;
				}				
			})

			console.log($scope.displayTime );			
            var display = 0;
	if($scope.displaySelectedImages){
			
			if($scope.selectedSlideShowImages.length != 0){
			$scope.durationToBeDisplayed = [];
			
			for(i=0;i<$scope.selectedSlideShowImages.length;i++){
			
				display = parseFloat(display) + parseFloat($scope.displayTime);
				var sampleVal = parseFloat(display.toFixed(2));
				console.log(sampleVal);
				if(sampleVal <= 9) {
				 sampleVal = "0:0"+sampleVal;	
				}else{
					sampleVal = "0:"+sampleVal;	
				}
				console.log(sampleVal);
				$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
				 console.log($scope.durationToBeDisplayed);
			  } 			
			}else{
				$scope.durationToBeDisplayed = [];
                 $scope.displayTime = 1;				
				for(i=0;i<$scope.selectedSlideShowImages.length;i++){
				
					display = parseFloat(display) + parseFloat($scope.displayTime);
					var sampleVal = parseFloat(display.toFixed(2));
					console.log(sampleVal);
					if(sampleVal <= 9) {
					 sampleVal = "0:0"+sampleVal;	
					}else{
						sampleVal = "0:"+sampleVal;	
					}
					console.log(sampleVal);
					$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
					 console.log($scope.durationToBeDisplayed);
				  }				
			}
	}
	else if($scope.displaySelectedVideos){
			
			if($scope.selectedSlideShowVideos.length != 0){
			$scope.durationToBeDisplayed = [];
			
			for(i=0;i<$scope.selectedSlideShowVideos.length;i++){
			
				display = parseFloat(display) + parseFloat($scope.displayTime);
				var sampleVal = parseFloat(display.toFixed(2));
				console.log(sampleVal);
				if(sampleVal <= 9) {
				 sampleVal = "0:0"+sampleVal;	
				}else{
					sampleVal = "0:"+sampleVal;	
				}
				console.log(sampleVal);
				$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
				 console.log($scope.durationToBeDisplayed);
			  } 			
			}else{
				$scope.durationToBeDisplayed = [];
                 $scope.displayTime = 1;				
				for(i=0;i<$scope.selectedSlideShowVideos.length;i++){
				
					display = parseFloat(display) + parseFloat($scope.displayTime);
					var sampleVal = parseFloat(display.toFixed(2));
					console.log(sampleVal);
					if(sampleVal <= 9) {
					 sampleVal = "0:0"+sampleVal;	
					}else{
						sampleVal = "0:"+sampleVal;	
					}
					console.log(sampleVal);
					$scope.durationToBeDisplayed.push({"timeSlot":sampleVal});
					 console.log($scope.durationToBeDisplayed);
				  }				
			}
 }
		//	$scope.createSlideshow(); 
			
				
		}
		
		$scope.selectMusic=function(selectedMusic){
			
			console.log(selectedMusic);
		}
	
	
		$scope.cancelSlideShow = function(){
			 $scope.showSlideShowBrowser =false;
			 $scope.addSlideshow=true;
			 $scope.createSlideShowBrowser = false;
			 $scope.showSelectImages = false;
			 $scope.showSelectVideos = false;
			 $scope.selectedSlideShowImages=[];
			 $scope.durationToBeDisplayed=[];
			 $scope.selectedImages=[];
			 $scope.selectedVideos=[];
			 $scope.selectedSlideShowVideos=[];
			 $scope.onCreateSlideShow=false;
			 $scope.previewSlideShowVideo=false;
			 $scope.previewSlideShowImage=false;
			 $scope.displaySelectedImagesBtn = true;
		      $scope.displaySelectedVideosBtn=false;
			 angular.element($('body').css("overflow-y", "scroll"));
		};
		$scope.slideShowBrowserImage=[];
		$scope.getSlideShowImageBrowser = function(){

		console.log($scope.slideShowBrowser);
		$scope.displaySelectedImages=true;
		$scope.displaySelectedVideos=false;
		$scope.displaySelectedImagesBtn = true;
		$scope.displaySelectedVideosBtn=false;
		$scope.selectedSlideShowVideos=[];
		$scope.selectedVideos=[];
		$scope.durationToBeDisplayed =[];
		 $rootScope.progressLoader = "block";              
			
            $scope.websiteurlPattern = '/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;';
            if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));    
			angular.element($('.btnCampaignCreative').prop('disabled', true));
			angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
			angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select image/video");
			
			
			var queryStr = "?adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId");
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $scope.browselibrary = "none";
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
           
			facebookGetPost.getadimages(queryStr, headers).then(function (response) {
                //console.log(response);
                if (response.data.appStatus == '0') {// success
						$scope.showSelectImages = true;
						$scope.showSelectVideos = false;
						var addImagesPopup = $(".selectImagesSlideshow");
						addImagesPopup.show();
						angular.element($('body').css("overflow-y", "scroll"));
						$rootScope.progressLoader = "none"; 
					
						$scope.mainLoader = "none";
						var arrAdAccountCreativeallData = [];
						
					 angular.forEach(response.data.adImages, function(v, k){
                        var JsonObj = response.data.adImages[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.hash != undefined) {
                                    arrAdAccountCreativeallData.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.account_id) {
                                        $scope.slideShowBrowserImage = s_images;
                                    }

                                }

                            }
                        }
                    });
                    $scope.slideShowImageArray = $scope.removeDuplicates(arrAdAccountCreativeallData, "hash");


                } else {// failed
                    console.log("failed");
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;

                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });
		     
		}
		
		$scope.cancelAddImages = function(){
			
			$scope.showSelectImages = false;
			$scope.selectImageDuration($scope.imageDuration);
			angular.element($('body').css("overflow-y", "scroll"));
			
		}
		$scope.selectedImages = [];
		$scope.selectedSlideShowImages =[];
		
		$scope.getSelectedImages=function(image){
			console.log(image);
			if(image.Selected){
				if($scope.selectedImages.indexOf(image) == -1){
				      $scope.selectedImages.push(image);						
				}
				
			}else{				
				$scope.selectedImages.splice($scope.selectedImages.indexOf(image),1);
			}
			
		}
			
		$scope.addSlideShowImages = function(){
			
			console.log("Add Images");
			console.log($scope.selectedSlideShowImages);
			$scope.selectedSlideShowImages=angular.extend($scope.selectedSlideShowImages,$scope.selectedImages);
			//$scope.selectedSlideShowImages= $scope.selectedImages;
			$scope.showSelectImages = false;
			$scope.selectImageDuration($scope.imageDuration);
	
			
			angular.element($('body').css("overflow-y", "scroll"));
		}
		
		
		$scope.addMoreSlideShowImages=function(){
			if($scope.selectedSlideShowImages.length > 0){
				$scope.showSelectImages = true;	
				$scope.showSelectVideos =false;
			}else if($scope.selectedSlideShowVideos.length > 0){
				$scope.showSelectVideos =true;
				$scope.showSelectImages = false;	
			}
			
			$timeout(function() {			
				return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
			});
			
		}
		
		$scope.deleteSelectedImg = function(image){
			if($scope.selectedSlideShowImages){
					$scope.selectedSlideShowImages.splice($scope.selectedSlideShowImages.indexOf(image),1);
					$timeout(function() {			
						return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
					});			
					$scope.selectImageDuration($scope.imageDuration);		
			}
			if($scope.selectedSlideShowVideos){
					$scope.selectedSlideShowVideos.splice($scope.selectedSlideShowVideos.indexOf(image),1);
					$timeout(function() {			
						return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
					});			
					$scope.selectImageDuration($scope.imageDuration);		
				
			}
		
		}
		
		 $scope.uploadSlideShowImage = function (uploadedFiles) {
             console.log(uploadedFiles);
		
		      $rootScope.progressLoader = 'block';
               
                angular.element($('.btnCampaignCreative').prop('disabled', false));			
				angular.element("#accordion1").find(".panel .panel-heading").attr("data-toggle", "collapse");
				angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("1 of 1");
                $scope.$apply(function ($scope) {
                    $scope.uploadedfilename = uploadedFiles.files[0];
                });             
                var reader = new FileReader();
                reader.onload = function () {
                    $scope.dataURL = reader.result;
                };
                $timeout(function () {
             
						var parameters = new FormData();
						parameters.append('userId',$window.localStorage.getItem("userId"));
						parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
						parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));
						parameters.append('type','IMAGE');
						parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
						parameters.append('imageFile',uploadedFiles.files[0]);
						var headers = {
							'Content-Type': undefined,
							'dataType': 'jsonp',
							'async': 'false'
						}
						var url = apiTPBase+ "/createadimage";

					 if (typeof (uploadedFiles.files[0]) == "object") {                  
					facebookGetPost.createadimage(url, parameters, headers).then(function (response) {
                        console.log(response);
						$rootScope.progressLoader = 'none';
                        if (response.status == "200" && response.data.appStatus == 0) {
                            $scope.hashVal = response.data.adImageDetails.images.bytes.hash;
                            $scope.hashUrl = response.data.adImageDetails.images.bytes.url;
                            
                                 $scope.getUploadedImage(response.data.adImageDetails.images.bytes.hash, $scope.uploadedfilename);
							  /* var imageObj=
								 {
										"thumbnail_url": $scope.hashVal,
										"url":$scope.hashUrl,
										"id":$scope.uploadedfilename.name,
										Selected:false
								 }
								$scope.slideShowImageArray.push(imageObj);*/
                             
                        }
                        else {
                            console.log('failed $scope.getCampaignfiles');
							$scope.showErrorPopup(response.data);
                           
                        }															
                    });
					
					}
																			
                }, 1000);
                reader.readAsDataURL(uploadedFiles.files[0]);			
              
		 }
		 $scope.getUploadedImage = function(hashVal,uploadedfilename){
			 console.log(hashVal);
			var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId") + "&hashes=" + hashVal;
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
		
		facebookGetPost.getadimages(queryStr, headers).then(function (response) {
			console.log(response);
			if (response.status == "200" && response.data.appStatus == '0') {
	
				$scope.mainLoader = "none";
				console.log('image hash servic success');
				
				var JsonObj = response.data.adImages[0];
				 var array = [];
				for (var j in JsonObj) {
					if (JsonObj.hasOwnProperty(j)) {
						array[+j] = JsonObj[j];
						console.log(JsonObj[j].url);
						$scope.imagePreviewSrc[i] = JsonObj[j].url;
						console.log(i);	
	                var imageObj=
					 {
							"thumbnail_url": $scope.imagePreviewSrc[i],
							"url":$scope.imagePreviewSrc[i],
							"id":uploadedfilename.name,
							Selected:false
					 }
					$scope.slideShowImageArray.push(imageObj);

					}
				}
				
			}else{
						if(response.appStatus > 0 && (response.errorMessage=='Access token is invalid or expired' || response.errorMessage=='Access Token is invalid or expired.')){
							$window.localStorage.setItem("TokenExpired",true);
							$state.go('login');
						}else{
							$rootScope.progressLoader = "none";
							$scope.editAdsetErrorMsg = 'block';
							if(response.networkError!='' && response.networkError!=undefined){
								$scope.errorpopupHeading = response.networkError.error_user_title;
								$scope.errorMsg = response.networkError.error_user_msg;

								$scope.errorpopupHeading = 'Error';
								$scope.errorMsg = response.networkError.message;
							}else{
								$scope.errorpopupHeading = 'Error';
								$scope.errorMsg = response.errorMessage;
							}
						}
					}
			});
													
			 
		 }
		  $scope.pictureFormat = [];
		  $scope.getSlideshowVideos = function(){
			  
	   	 // var queryStr = "adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") +"&adVideoId="+$scope.slideshowID;
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
		    $rootScope.progressLoader = 'block';
		$timeout(function(){

		var promises = [];		  
        var queryStr = '/getadvideos?userNetworkMapId=' +  $window.localStorage.getItem("userNetworkMapId")  + "&adAccountId="+ $scope.networkAdAccountId +"&videoId="+$scope.slideshowID ;
		var headerVal = {
			headers: {
				'userId': $window.localStorage.getItem("userId"),
				'accessToken': $window.localStorage.getItem("accessToken")
			}
		};
		promises.push(apiService.getTp(queryStr,headerVal).then(function(resp){  		
			 if (resp.appStatus == 0) {
					   $scope.mainLoader = "none";
                      console.log(resp);		                				  
					 angular.forEach(resp.adVideos,function(key,value){
					  	angular.forEach(key,function(adVideoID){
							if($scope.slideshowID == adVideoID.id){	
							     $scope.pictureFormat = adVideoID.format;	
								 $scope.videoStatus = adVideoID.status;
                                 angular.forEach( $scope.pictureFormat,function(ulrVal){
                                 	if(ulrVal.filter == "native"){
                                 		$scope.imageURLValue = ulrVal.picture;
								        $scope.slideShowSource = adVideoID.source;
                                 	}
                                 })
							}
					  	})
					})
					
				    $scope.generateSlideshowPreview(resp);								
                }
                else {
                    console.log('failed');
                    if(resp.appStatus > 0 && (resp.errorMessage=='Access token is invalid or expired' || resp.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(resp.networkError!='' && resp.networkError!=undefined){
                            $scope.errorpopupHeading = resp.networkError.error_user_title;
                            $scope.errorMsg = resp.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = resp.errorMessage;
                        }
                    }
                } 
		}));		 
		  	  $q.all(promises).finally(function(){   
				  console.log("PROMISE");
				  console.log(promises);
			      $rootScope.progressLoader = 'none';	
				 $scope.checkCreatedSlideStatus();
             });
	  },0);

		  }
		   $scope.checkCreatedSlideStatus = function(){			
	                			
					 if($scope.videoStatus){			
                    if($scope.videoStatus.video_status == "ready"){	
                                    $scope.slideShowCreate = false ;
                                    $scope.slideShowSuccess = true;									
                                    $scope.creativeAdCreative($scope.slideshowID);                			
                    }else if($scope.videoStatus.video_status == "error"){
                                        $scope.slideShowCreate=true;
                                        $scope.slideShowSuccess=false;	
                                        $scope.selectedSlideShowImages = [];
                                        $scope.cancelSlideShow();	
                                        $scope.popupTitle = 'Video Status Error';
                                        $scope.popupMessage = "Error while fetching created slideshow ";
                                        angular.element($('body').css("overflow-y", "hidden"))
                                        var modalErr = $(".error_popup");
                                        modalErr.show();											
                        }else if($scope.videoStatus.video_status == "processing"){	
                                        $scope.slideShowCreate = false ;
                                        $scope.slideShowSuccess = true;											
                                         $scope.getSlideshowVideos();                                                			
                        }				
                    }			
	        }
		  $scope.generateSlideshowPreview = function(response){
				 angular.forEach(response.adVideos,function(key,value){
					  	angular.forEach(key,function(adVideoID){			
							if($scope.slideshowID == adVideoID.id){	
							     $scope.iFrameValue = adVideoID.format;								   
                                 angular.forEach( $scope.iFrameValue ,function(ulrVal){
                                 	if(ulrVal.filter == "native"){                                 		
											$scope.video_Source = ulrVal.picture;

                                 	}
                                 })					
							}						  		
					  	})									
					})			
				
				 $scope.slideShowPreview =  $scope.video_Source; 
				 $scope.slideshowGIF =  $scope.video_GIF;
                  //  $scope.slideShowPreview = {src: $scope.video_Source, title: "Desktop Preview"};
					
		  }
		  $scope.imageURL = [];
		 $scope.createImageSlideShow = function(){
			 
			 console.log($scope.selectedSlideShowImages);
			 console.log($scope.imageDuration);
			 console.log($scope.slideShowTransition);
			  $scope.imageURL =[];
			 if($scope.selectedSlideShowImages.length > 0){
				 	angular.forEach($scope.selectedSlideShowImages,function(images){
						if(images.url.includes("?")){							
						   	$scope.splicedVal = images.url.slice(0,images.url.indexOf("?"));
							if($scope.imageURL.indexOf($scope.splicedVal) == -1){							
							       $scope.imageURL.push($scope.splicedVal);
						   }
						}else{						
						   if($scope.imageURL.indexOf(images.url) == -1){							
							       $scope.imageURL.push(images.url);
						   }					   
						}							  
			     }) 
			 }
			 if($scope.selectedSlideShowVideos.length > 0){
				 $scope.imageURL =[];
				 	angular.forEach($scope.selectedSlideShowVideos,function(images){
						$scope.videoURL = images.picture.slice(0,images.picture.indexOf("?"));
						if($scope.imageURL.indexOf($scope.videoURL) == -1){
							$scope.imageURL.push($scope.videoURL);
						}						
			     })					 
			 }
		   
			     var parameters = {
					"userId": $window.localStorage.getItem("userId"),
					"accessToken": $window.localStorage.getItem("accessToken"),
					"userNetworkMapId": $window.localStorage.getItem("userNetworkMapId"),
					"adAccountId":$window.localStorage.getItem("networkAdAccountId"),
					"slideShowSpec":{
							"images_urls":$scope.imageURL,
							"duration_ms": $scope.imageDuration,
							"transition_ms": 200
						
					    }
                };
			  
		
		  var promises = [];
		 /* promises.push($http({
              method: 'POST',
                url: apiTPBase + '/createadslideshow',
                data: parameters,
                headers: {
                    'Content-Type': "application/json"
                }
            }) */
			 promises.push(facebookGetPost.createadslideshow("", parameters).then(function(response){            
					 if (response.data.appStatus == 0) {
					console.log(response);
					$scope.slideshowID = response.data.adVideoId;
					//$scope.creativeAdCreative(response.data.adVideoId); 
					$scope.showSlideshowSuccessPopup();					
                }
                else {
                    console.log('failed');
                    if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }else{
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if(response.data.networkError!='' && response.data.networkError!=undefined){
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        }else{
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                } 
          }));
		  $q.all(promises).finally(function(){   
				  console.log("PROMISE");
				  console.log(promises);
				
			     // $scope.getSlideshowVideos();
             });

		 }
	  $scope.showSlideshowSuccessPopup = function () {
            //console.log('success popup here123');
			$scope.onSlideshowSuccess = true;
			$scope.showSlideShowBrowser=false;
            $scope.popupTitle = "Slideshow Creation";
            $scope.popupMessage = "Slideshow created successfully";
            angular.element($('body').css("overflow-y", "hidden"))
            var successReq = $(".success_popup1");
            successReq.show();

        }
        $scope.closeSlideshowSuccessPopup = function () {
			$scope.onSlideshowSuccess = false;
            angular.element($('body').css("overflow-y", "scroll"))
            var successReq = $(".success_popup1");
            $scope.networkErrorPopup = 'none';
            successReq.hide();
			$scope.getSlideshowVideos();
			
		    
			$scope.showSlideShowBrowser=false;
		
        }

		
		$scope.createSlideshow = function(){

			$scope.myInterval = parseInt($scope.imageDuration);
		    $scope.activeSlide=0;
			$timeout(function() {
			
				return $animate.enabled(false, angular.element('#slides_control').carousel({interval:$scope.myInterval,cycle: true}));
			});
				$scope.addSlideshow=false;
			if($scope.selectedSlideShowImages.length != 0){
				
			$scope.previewSlideShowImage = true;	
			$scope.previewSlideShowVideo = false;
			$scope.createImageSlideShow();
			}
			if($scope.selectedSlideShowVideos.length != 0){
				$scope.previewSlideShowImage = false;	
				$scope.previewSlideShowVideo = true;
				$scope.createImageSlideShow();
			}
			
		   
			console.log($scope.selectedSlideShowImages);
			angular.element($('body').css("overflow-y", "scroll"));
		};
		
	 $scope.deleteSelectedSlide = function(){		 
			$scope.slideShowSuccess = false;
			$scope.slideShowCreate = true;	
            angular.element('#step2').css('background-color', '#c2c2c2');
            angular.element('#step3').css('background-color', '#c2c2c2');
            angular.element(".fbCampaignCreativeWrapper .accrodian-section .accordion-toggle").css('cursor', 'default');
            angular.element(".sectionPreviewAdvert .row").eq(0).find("p").text("Note : Please select a creative type");
            angular.element('#collapseOne1').removeClass('in');
            angular.element('#collapseTwo1').removeClass('in');
            angular.element('.btnCampaignCreative').css('pointer-events', 'none');
            angular.element('.btnCampaignCreative').css('opacity', '0.6');
            angular.element("#accordion1").find(".panel .panel-heading").removeAttr("data-toggle");
	}
                $scope.onDropComplete = function (index, obj, evt) {
                  
					if($scope.selectedSlideShowImages.length > 0){
						var otherObj = $scope.selectedSlideShowImages[index];
						var otherIndex = $scope.selectedSlideShowImages.indexOf(obj);
						$scope.selectedSlideShowImages[index] = obj;
						$scope.selectedSlideShowImages[otherIndex] = otherObj;
						console.log($scope.selectedSlideShowImages);
					}
					if($scope.selectedSlideShowVideos.length > 0){
						   var otherObj = $scope.selectedSlideShowVideos[index];
							var otherIndex = $scope.selectedSlideShowVideos.indexOf(obj);
							$scope.selectedSlideShowVideos[index] = obj;
							$scope.selectedSlideShowVideos[otherIndex] = otherObj;
							console.log($scope.selectedSlideShowVideos);	
					}
                }   
				
				
		$scope.slideShowVideoArray=[]
		$scope.getSlideShowVideoBrowser = function(){

		$scope.displaySelectedImages=false;
		$scope.displaySelectedVideos=true;
		$scope.displaySelectedImagesBtn = false;
		$scope.displaySelectedVideosBtn=true;
        $scope.selectedSlideShowImages=[];
		$scope.selectedImages=[];	
		$scope.durationToBeDisplayed =[];		
		   if (!$scope.frmCreateNewAdvert.$valid) {
                window.scrollTo(0, document.body.scrollHeight);
                return;
            }

            angular.element($('.panel-collapse.collapse.in').removeClass("in"));
			$rootScope.progressLoader = "block";
	       
		   var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem("networkAdAccountId"); 
            $scope.browselibrary = "none";
			var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            $scope.mainLoader = "block";
            angular.element($('body').css("overflow-y", "hidden"))
            $scope.uniqueArray = "";
          
			facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                console.log(response);
                
                 $scope.browseVideoArray = [];
                if (response.data.appStatus == '0') {// success
                    console.log(response.data);
                    $scope.mainLoader = "none";	
                    $scope.browseVideoArray = response.data.data;
				
                    var arrAdAccountCreativeallDataVideo = [];
                    angular.forEach(response.data.adVideos, function(v, k){
                        var JsonObj = response.data.adVideos[k];
                        for (var i in JsonObj) {
                            if(JsonObj[i]) {
                                var s_images  = JsonObj[i];
                                if (s_images.id != undefined) {
                                    arrAdAccountCreativeallDataVideo.push(s_images);
                                    if ($window.localStorage.getItem("adCreativeId") == s_images.id) {
                                        $scope.respGetAdCreativeObj = s_images;
                                    }

                                }

                            }
                        }
                    });
					
                 $scope.slideShowVideoArray = arrAdAccountCreativeallDataVideo;
				$scope.showSelectImages = false;
				$scope.showSelectVideos = true;
				var addVideosPopup = $(".selectVideosSlideshow");
				addVideosPopup.show();
				angular.element($('body').css("overflow-y", "hidden"));
				
					
		}  
		else {
							console.log('failed');
							if(response.data.appStatus > 0 && (response.data.errorMessage=='Access token is invalid or expired' || response.data.errorMessage=='Access Token is invalid or expired.')){
								$window.localStorage.setItem("TokenExpired",true);
								$state.go('login');
							}else{
								$rootScope.progressLoader = "none";
								$scope.editAdsetErrorMsg = 'block';
								if(response.data.networkError!='' && response.data.networkError!=undefined){
									$scope.errorpopupHeading = response.data.networkError.error_user_title;
									$scope.errorMsg = response.data.networkError.error_user_msg;
								}else{
									$scope.errorpopupHeading = 'Error';
									$scope.errorMsg = response.data.errorMessage;
								}
							}
						}		
                        
                $rootScope.progressLoader = "none";
               
                //$scope.existVideosList = response.data.adVideos;
            });
		}
		
		
			$scope.selectedSlideShowVideos= [];
			$scope.selectedVideos = [];
			
			
			$scope.getSelectedVideos=function(video){
				console.log(video);
				if(video.Selected){
					$scope.selectedVideos.push(video);					
				}else{				
					$scope.selectedVideos.splice($scope.selectedVideos.indexOf(video),1);
				}
		
		 }
			$scope.addSlideShowVideos = function(){
			
				console.log("Add Videos");
				console.log($scope.selectedSlideShowVideos);
			//	$scope.selectedSlideShowVideos= $scope.selectedVideos;		
				$scope.selectedSlideShowVideos= angular.extend($scope.selectedSlideShowVideos,$scope.selectedVideos);				
				$scope.showSelectVideos = false;
				$scope.selectImageDuration($scope.imageDuration);
				angular.element($('body').css("overflow-y", "scroll"));
		  }
	
		$scope.cancelAddVideos= function(){
			
			$scope.showSelectVideos = false;
			$scope.selectImageDuration($scope.imageDuration);
			angular.element($('body').css("overflow-y", "scroll"));
			
		}
		
		
			
		 $scope.uploadSlideShowVideo = function (element) {
		   $rootScope.progressLoader = 'block';
            var parameters = new FormData();
            parameters.append('userId',$window.localStorage.getItem("userId"));
            parameters.append('accessToken',$window.localStorage.getItem("accessToken"));
            parameters.append('userNetworkMapId',$window.localStorage.getItem("userNetworkMapId"));			
            parameters.append('adAccountId',$window.localStorage.getItem("networkAdAccountId"));
            parameters.append('source',element.files[0]);
			var headers = {
			'Content-Type': undefined,
			'dataType': 'jsonp',
			'async': 'false'
			}
			var url = apiTPBase+ "/createadvideo";

            if (typeof (element.files[0]) == "object") {                
				facebookGetPost.createadvideo(url, parameters, headers).then(function (response) {

                    if (response.status == "200") {
                        $scope.newvideoID = response.data.id;
                        $scope.getUploadedvideos(response.data.id);                      
                    } else {
                        console.log("failed $scope.getCampaignVideoFiles");
						$scope.showErrorPopup(response.data);
                    }

                });
				
            }
		
		 }
		 $scope.getUploadedvideos = function(newvideoID){
			 console.log(newvideoID);
			 var modalErr = $(".video_error_popup");
            modalErr.hide();
            
            $timeout(function(){
                var queryStr = "?adAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem("userNetworkMapId")+"&videoId="+newvideoID ;
                $scope.mainLoader = "block";
				var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
                }
                
				facebookGetPost.getadvideos(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        $scope.mainLoader = "none";
                        angular.forEach(response.data.adVideos,function(key,value){
                            angular.forEach(key,function(adVideoID){
                                if(newvideoID == adVideoID.id){
								    $scope.pictureFormat = adVideoID.format;										
                                    $scope.videoStatus = adVideoID.status;									
								     if($scope.videoStatus){
										if($scope.videoStatus.video_status == "ready"){
											
												angular.forEach($scope.pictureFormat,function(ulrVal){
												if(ulrVal.filter == "native"){
													var videoObj=
																 {
																		"picture":ulrVal.picture,
																		"id":adVideoID.id,
																		Selected:false
																 }
																 $scope.slideShowVideoArray.push(videoObj);
																 console.log($scope.slideShowVideoArray);
											
												}
											});
										}else if($scope.videoStatus.video_status == "error"){
											$scope.popupTitle = 'Error';
											$scope.popupMessage = "Video Status Error";
											angular.element($('body').css("overflow-y", "hidden"))
											var modalErr = $(".error_popup");
											modalErr.show();
										}else{
											$scope.popupTitle = 'Video Status Error';
											$scope.popupMessage = "processing error, would you like to continue...";
											angular.element($('body').css("overflow-y", "hidden"))
											var modalErr = $(".video_error_popup");
											modalErr.show();
											
										}			
									}
                                
                                }
                            })									
                        });
                        $rootScope.progressLoader = 'none';                     
                    } 
					
                });
            
            },0);
		 }
		
		 $scope.$on('details-loaded', function() {
		 					$scope.setLine();	
		});
		 
	
    }]); 
	

	//Directive code


 dashboard.directive('compileoffersHtml',
  function() {
    return {
      restrict: 'A',
      templateUrl: '../CNAP_UI_Repo/app/modules/facebook/fbcreativecarousel-directive.html'
    };
  }
);  

dashboard.directive('setConnector',function () {
	return {
	   restrict: 'A',
	   replace:false,
	   template: '',
	   link: function ($scope) {               
			  $scope.$emit('details-loaded');
	   }
	}
});

