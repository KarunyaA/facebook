dashboard.controller("bypcreateCampaignPlanController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'globalData', 'sharedService1', 'netWorkData', 'facebookGetPost',
        function ($rootScope, $scope, $state, catalyst, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile, appSettings, globalData, sharedService1, netWorkData, facebookGetPost) {
        var baseUrl = catalyst.serviceUrl1;
                var baseUrl2 = catalyst.serviceUrl2;
                var apiTPBase = appSettings.apiTPBase;
                var apiBase = appSettings.apiBase;
                $scope.editAdsetErrorMsg = 'none';
                $scope.thirdActiveDiv = 'yes';
                $scope.manualbidtxt = "per post engagement";
                $scope.disableadvertDelivery = false;
                $scope.disableofferConversion = false;
                $scope.firstActiveDivImg = true;
                $scope.secondActiveDivImg = true;
                $scope.thirdActiveDivImg = false;
                $scope.fourthActiveDivImg = false;
                $scope.fifthActiveDivImg = false;
                $scope.submitted = false;
                var vm = this;
                vm.showDetails = true;
                $scope.popupShow = false;
                $scope.campaignPlanForm = {}
        $scope.campaignplan = [];
                $scope.campaignplanObj = {}
        $scope.campaignPlanCurrency = {};
                $scope.campaignPlanBudget = {};
                $scope.campaignPlanSchedule = {};
                $scope.budgetValue = "";
                vm.home = {};
                $scope.disabled = true;
                $scope.isDisable = true;
                $scope.showText = false;
                $scope.advancedOption = false;
                $scope.impressions = false;
                $scope.radioimpressions = false;
                $scope.moreimpressions = false;
                $scope.runAdverts = false;
                $scope.deliveryType = false;
                $scope.autoBid = true;
                $scope.setDate = false;
                $scope.localAwareness = false;
                $scope.showAdvanced = true;
                $scope.disableDIV = false;
                $scope.showChart = false;
                $scope.checked = false;
                $scope.advertItemsList;
                $scope.adsetDetails;
                $scope.campaignDetails;
                $scope.adminUserRole = false;
                $scope.disableStartDate = false;
                $scope.startDateToday = false;
                $scope.manualBidAmount = false;
                $scope.currentSdate;
                $scope.currentEdate;
                $scope.chartPath = "";
                $scope.promotionObjective = 'no';
                $scope.dateChanged = false;
                $scope.currencyList = {};
                $scope.currencyCode = "\uf156";
                $scope.checkValid = true;
                $scope.frequencyHide = false;
                $scope.frequency = false;
                $scope.offerconversiondiv = false;
                $scope.campaignPlanForm.budget = "dailyBudget"
                $scope.enddateselected=false;

                $scope.checkMandatoryField = function(){
                $scope.step2Check = [];
                        var countStep2 = 0;
                        var step1Check = false;
                        if ($scope.campaignPlanForm.budgetValue != '' && $scope.campaignPlanForm.budgetValue != undefined && $scope.campaignPlanForm.budgetValue != null) {
                angular.element('#budget-input').removeClass("mandatory");
                        angular.element('#step1').css('background-color', '#95D2B1');
                        angular.element('.is-div-disabled').css('pointer-events', 'auto');
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        step1Check = true;
                } else {
                angular.element('#budget-input').addClass("mandatory");
                        angular.element('#step1').css('background-color', '#c2c2c2');
                        angular.element('.is-div-disabled').css('pointer-events', 'none');
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        step1Check = false;
                }

                if ($scope.campaignPlanForm.advertSetName != '' && $scope.campaignPlanForm.advertSetName != undefined && $scope.campaignPlanForm.advertSetName != null) {
                angular.element('#advertsetName').removeClass("mandatory");
                        $scope.step2Check.push(true);
                } else {
                angular.element('#advertsetName').addClass("mandatory");
                        $scope.step2Check.push(false);
                }

                if ($scope.campaignPlanForm.schedule == '2') {
                if ($scope.campaignPlanForm.scheduleEndDate != "" && $scope.campaignPlanForm.scheduleEndDate != null && $scope.campaignPlanForm.scheduleEndDate != undefined) {
                if (Date.parse($scope.campaignPlanForm.scheduleEndDate) <= Date.parse($scope.campaignPlanForm.scheduleStartDate)) {
                angular.element('#endate').addClass("mandatory");
                        angular.element('#endtime').addClass("mandatory");
                        $scope.step2Check.push(false);
                } else {
                angular.element('#endate').removeClass("mandatory");
                        angular.element('#endtime').removeClass("mandatory");
                        $scope.step2Check.push(true);
                }
                } else {
                angular.element('#endate').addClass("mandatory");
                        angular.element('#endtime').addClass("mandatory");
                        $scope.step2Check.push(false);
                }
                if ($scope.campaignPlanForm.scheduleStartDate == "" || $scope.campaignPlanForm.scheduleStartDate == null || $scope.campaignPlanForm.scheduleStartDate == undefined) {
                angular.element('#endate').addClass("mandatory");
                        angular.element('#endtime').addClass("mandatory");
                        $scope.step2Check.push(false);
                }
                }
                if ($scope.advancedOption) {
                if ($scope.campaignPlanForm.bidAmountVal == "2") {
                if ($scope.campaignPlanForm.bidAmount != "" && $scope.campaignPlanForm.bidAmount != null && $scope.campaignPlanForm.bidAmount != undefined) {
                angular.element('#bidAmount').removeClass("mandatory");
                        $scope.step2Check.push(true);
                } else {
                angular.element('#bidAmount').addClass("mandatory");
                        $scope.step2Check.push(false);
                }
                }
                
                }

                for (var ind = 0; ind < $scope.step2Check.length; ind++) {
                if ($scope.step2Check[ind] == true) {
                countStep2++;
                }
                }

                if (countStep2 == $scope.step2Check.length) {
                angular.element('#step2').css('background-color', '#95D2B1');
                } else {
                angular.element('#step2').css('background-color', '#c2c2c2');
                }

                if (countStep2 == $scope.step2Check.length && step1Check) {
                angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                } else {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                }

                };
                $scope.conversionwindowArr = [
                {Key1: "1", Key2: "0", Value: "1 day after clicking"},
                {Key1: "7", Key2: "0", Value: "7 days after clicking"}
                /*{Key1 : "1", Key2 : "1", Value : "1 day after clicking or viewing"},
                 {Key1 : "7", Key2 : "1", Value : "7 days after clicking or 1 day after viewing"}*/
                ];
                var timeArray = ["12AM", "1AM", "2AM", "3AM", "4AM", "5AM", "6AM", "7AM", "8AM", "9AM", "10AM", "11AM", "12PM", "1PM", "2PM", "3PM", "4PM", "5PM", "6PM", "7PM", "8PM", "9PM", "10PM", "11PM", "12PM"]

                //------------------------------------
                $scope.marketingObjectEnableList = [{
                "id": "POST_ENGAGEMENT",
                        "assets": [
                        {
                        "name": "POST_ENGAGEMENT",
                                "marketingName": "POST ENGAGEMENT",
                                "marketingDesc": "Post Engagement",
								"marketingDescText": "We'll deliver your adverts to the right people to help you get the most likes, shares or comments on your post at the lowest cost"
                        },
                        {
                        "name": "IMPRESSIONS",
                                "marketingName": "IMPRESSIONS",
                                "marketingDesc": "Impressions",
								"marketingDescText": "We'll deliver your adverts to people as many times as possible."
                        },
                        {
                        "name": "REACH",
                                "marketingName": "DAILY UNIQUE REACH",
                                "marketingDesc": "Daily Unique Reach",
								"marketingDescText": "We'll deliver your adverts to people up to once a day."
                        }
                        ]
                }
                ] 


                //----------------------------

                $scope.emptycheckformandatoryfields = function ()
                {
                console.log("emptycheck");
                        angular.element('#step1').css('background-color', '#95D2B1');
                        //angular.element('#step2').css('background-color', '#95D2B1');
                        if ($scope.campaignPlanForm.advertSetName != "" && $scope.campaignPlanForm.advertSetName != null && $scope.campaignPlanForm.advertSetName != undefined)
                {
                angular.element('#advertsetName').removeClass("required");
                } else
                {
                angular.element('#advertsetName').addClass("required");
                }
                console.log($scope.campaignPlanForm.bidAmount);
                        if ($scope.campaignPlanForm.bidAmount != "" && $scope.campaignPlanForm.bidAmount != null && $scope.campaignPlanForm.bidAmount != undefined)
                {
                console.log("h");
                        angular.element('#bidAmount').removeClass("required");
                } else
                {
                angular.element('#bidAmount').addClass("required");
                }
                };
                $scope.prePopulateCampaignDetails = function (cDetails) {
                console.log(cDetails);
                        $scope.populateAdvertDelivery(cDetails.campaignDetails.objective);
                }
        $scope.prePopulateAdsetDetails = function (aDetails) {
        if (aDetails) {
        var budget = aDetails.adsetDetails.lifetime_budget;
        }

        $scope.campaignPlanForm.advertDelivery = aDetails.adsetDetails.optimization_goal;
                if (aDetails.adsetDetails.attribution_window_days != '' && aDetails.adsetDetails.attribution_window_days != undefined && aDetails.adsetDetails.attribution_window_days != null) {
        var conversionObj = $filter('filter')($scope.conversionwindowArr, function (d) {
        return d.Key1 == aDetails.adsetDetails.attribution_window_days;
        })[0];
                console.log(conversionObj);
                $scope.campaignPlanForm.offerConversion = conversionObj.Value;
        }

        // Post Engagement Start
        if ($scope.marketingObjective == "POST_ENGAGEMENT") {
        if ($scope.campaignPlanForm.advertDelivery == "POST_ENGAGEMENT") {
        $scope.chargedOption = [
        {
        "id": "POST_ENGAGEMENT",
                "name": "Post engagement",
                "disabled": "false"
        },
        {
        "id": "IMPRESSIONS",
                "name": "Impressions",
                "disabled": "false"
        }
        ]
        }
        if ($scope.campaignPlanForm.advertDelivery == "IMPRESSIONS" || $scope.campaignPlanForm.advertDelivery == "REACH") {
        $scope.chargedOption = [
        {
        "id": "IMPRESSIONS",
                "name": "Impressions",
                "disabled": "false"
        }
        ]
        }

        }
        // Post Engagement End


        if (budget != 0) {
        $scope.campaignPlanForm.budget = "lifetimeBudget"
                $scope.campaignPlanForm.budgetValue = aDetails.adsetDetails.lifetime_budget;
                var adserArr = aDetails.adsetDetails.adset_schedule;
                $scope.prePopulateChart(adserArr);
        } else {
        $scope.campaignPlanForm.budget = "dailyBudget"
                $scope.campaignPlanForm.budgetValue = aDetails.adsetDetails.daily_budget
        }


        if (aDetails.adsetDetails.end_time != null) {
        $scope.campaignPlanForm.schedule = 2;
                $scope.setDate = true;
                $scope.startDateToday = true;
                $scope.disableDate = true;
                var startDateValue = new Date(aDetails.adsetDetails.start_time);
                var endDateValue = new Date(aDetails.adsetDetails.end_time);
                var currentDate = $filter('date')(startDateValue, 'yyyy-M-d hh:mm a');
                var endDate = $filter('date')(endDateValue, 'yyyy-M-d hh:mm a');
                $scope.currentSdate = currentDate;
                $scope.currentEdate = endDate;
                $scope.campaignPlanForm.scheduleStartDate = new Date(currentDate);
                $scope.campaignPlanForm.scheduleEndDate = new Date(endDate);
                $scope.diffDate($scope.campaignPlanForm.scheduleStartDate , $scope.campaignPlanForm.scheduleEndDate );
        } else {
        $scope.campaignPlanForm.schedule = 1;
                $scope.setDate = false;
                $scope.disableStartDate = true;
                $scope.startDateToday = false;
                $scope.disableDate = true;
                $scope.enddateselected=false;
        }
        $scope.campaignPlanForm.advertSetName = aDetails.adsetDetails.name;
                if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.runAdvert1 = 1;
                $scope.budget = true
                $scope.checked = false;
                $scope.disableBudget = true;
        } else {
        $scope.campaignPlanForm.runAdvert1 = 2;
                $scope.budget = false
                $scope.checked = true;
                $scope.disableStartDate = false;
                $scope.disableBudget = true;
        }


        if (aDetails.adsetDetails.is_autobid == true) {
        $scope.campaignPlanForm.bidAmountVal = 1
        } else {
        $scope.campaignPlanForm.bidAmountVal = 2
                $scope.campaignPlanForm.bidAmount = aDetails.adsetDetails.bid_amount;
                $scope.showText = true;
                $scope.autoBid = false;
        }


        $scope.campaignPlanForm.impression = aDetails.adsetDetails.billing_event;
                if ($scope.campaignPlanForm.advertDelivery == "POST_ENGAGEMENT")
        {
        if (aDetails.adsetDetails.billing_event == "POST_ENGAGEMENT")
        {
        $scope.chargedOption = [
        {
        "id": "POST_ENGAGEMENT",
                "name": "Post engagement",
                "disabled": "false"
        },
        {
        "id": "IMPRESSIONS",
                "name": "Impressions",
                "disabled": "false"
        }
        ]
        } else {
        $scope.chargedOption = [
        {
        "id": "IMPRESSIONS",
                "name": "Impressions",
                "disabled": "false"
        },
        {
        "id": "POST_ENGAGEMENT",
                "name": "Post engagement",
                "disabled": "false"
        }
        ]
        }
        }

        if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
                $scope.showChart = false;
        } else {
        $scope.campaignPlanForm.runAdvert = 2;
                $scope.AdvertText = "Run adverts on a schedule";
                if (aDetails.adsetDetails.adset_schedule != undefined) {
        $scope.showChart = true;
                $scope.campaignPlanForm.runAdvert = 2;
                $scope.AdvertText = "Run adverts on a schedule";
        } else {
        $scope.showChart = false;
                $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
        }
        }

        if (aDetails.adsetDetails.pacing_type.indexOf("no_pacing") > - 1){
        console.log("In here")
                $scope.campaignPlanForm.deliverType = 2;
                $scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";
        } else {
        $scope.campaignPlanForm.deliverType = 1;
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
        }

        //$scope.emptycheckformandatoryfields();           
        }

        $scope.setCampaignPlanMapping = function () {
        var mObj = $window.localStorage.getItem("marketingObjective");
                if (mObj == "POST_ENGAGEMENT") {
        $scope.manualBidAmount = true;
                $scope.selectBidAmount($scope.campaignPlanForm.bidAmountVal);
                if ($scope.campaignPlanForm.schedule == 2){
        $scope.campaignPlanForm.schedule = 2;
        } else{
        $scope.campaignPlanForm.schedule = 1;
        }
        //$scope.campaignPlanForm.bidAmountVal = 1;
        //$scope.campaignPlanForm.advertDelivery = "POST_ENGAGEMENT";
        $scope.campaignPlanForm.impression = "POST_ENGAGEMENT";
                $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
                $scope.campaignPlanForm.deliverType = 1;
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                $scope.chargedOption = [
                {
                "id": "POST_ENGAGEMENT",
                        "name": "Post engagement",
                        "disabled": "false"
                },
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
                ]
        }
        }
        $scope.loadCurrencyCode = function () {
        $http.get("localData/currencyData.json").success(function (data) {
        $scope.currencyList = data.currencyList;
                console.log($scope.currencyList);
        });
        };
                $scope.showErrorPopup = function (response) {
                if (response.hasOwnProperty("data")) {
                if (response.data.networkError) {
                if (response.data.networkError.error_user_title != '' && response.data.networkError.error_user_title != undefined) {
                $scope.popupTitle = response.data.networkError.error_user_title;
                        $scope.popupMessage = response.data.networkError.error_user_msg;
                } else if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {

                $scope.popupTitle = "Error";
                        $scope.popupMessage = response.data.networkError.message;
                }
                } else {
                $scope.popupTitle = "Error";
                        $scope.popupMessage = response.data.errorMessage;
                }
                } else {
                if (response.networkError) {
                if (response.networkError.error_user_title != '' && response.networkError.error_user_title != undefined) {
                $scope.popupTitle = response.networkError.error_user_title;
                        $scope.popupMessage = response.networkError.error_user_msg;
                } else if (response.networkError.message != '' && response.networkError.message != undefined) {

                $scope.popupTitle = "Error";
                        $scope.popupMessage = response.networkError.message;
                }
                } else {
                $scope.popupTitle = "Error";
                        $scope.popupMessage = response.errorMessage;
                }

                }

                var modalApproveReq = $(".error_popup"); // Get the modal Approve req
                        modalApproveReq.show();
                }
        $scope.resetError = function () {
        angular.element($('body').css("overflow-y", "scroll"))
                var modalApproveReq = $(".error_popup");
                modalApproveReq.hide();
        }

        $scope.init = function () {

        $scope.linkclicks = true;
                $rootScope.faceBookFormData = $scope.campaignPlanForm;
                $rootScope.chartChange = false;
                $rootScope.step = 3;
                if ($rootScope.campaignSteps[2] == false) {
        $window.localStorage.setItem("campaignState", "create");
                $rootScope.chartArray = [];
        }
        var campaignState = $window.localStorage.getItem("campaignState");
                $scope.campstate = $window.localStorage.getItem("campaignState");
                console.log(campaignState)
                if (campaignState == "create") {
        $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
                console.log("In create");
                $scope.campaignPlanForm.bidAmountVal = 1;
                $scope.selectBudget("dailyBudget");
        }
        var mObj = $window.localStorage.getItem("marketingObjective");
                $scope.populateAdvertDelivery(mObj);
                $scope.loadCurrencyCode();
                if (campaignState == "edit") {

        angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#step1').css('background-color', '#95D2B1');
                $scope.impressions = false;
                $scope.radioimpressions = false;
                if ($window.localStorage.getItem("role") == "Account") {
        $scope.adminUserRole = true;
        } else {
        $scope.adminUserRole = false;
        }
        var campaignId = $window.localStorage.getItem("campaignId")
                console.log("$rootScope.overLayAudience :: " + $rootScope.overLayAudience)
                if ($rootScope.overLayAudience == true) {
        $rootScope.freezeFlag = true;
        }
        var headers = {
        "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
        }

        var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&" + "adCampaignId=" + campaignId

                facebookGetPost.readadcampaign(queryStr, headers).then(function (response) {
        console.log(response);
                if (response.data.appStatus == '0') {
        angular.forEach(response.data.adcampaigns, function (value, key) {
        var JsonObj = response.data.adcampaigns[key]
                var array = [];
                for (var i in JsonObj) {
        if (JsonObj.hasOwnProperty(i) && !isNaN( + i)) {
        array[ + i] = JsonObj[i];
                $window.localStorage.setItem("campaignId", i)
                $scope.campaignDetails = array[ + i];
                $scope.prePopulateCampaignDetails($scope.campaignDetails)
        }
        }
        });
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }

        }
        });
                //---------------------------------------------------------------------------
                var campaignId = $window.localStorage.getItem("campaignId");
                var headers = {
                "userId": $window.localStorage.getItem("userId"),
                        "accessToken": $window.localStorage.getItem("accessToken")
                }
        var queryStr = "?adCampaignId=" + campaignId + "&" + "userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.readadset(queryStr, headers).then(function (response) {
        console.log(response)
                if (response.data.appStatus == 0) {
        console.log('======');
                console.log(response.data.adsets.length);
                if (response.data.adsets.length > 1) {
        $scope.editAdsetErrorMsg = 'block';
                $scope.errorpopupHeading = 'Adset Error';
                $scope.errorMsg = 'Please try again as there has been an error in AdSet Creation. If the error persists, please contact CAdConciergeSupport@cognizant.com';
        } else {
        angular.forEach(response.data.adsets, function (value, key) {
        var JsonObj = response.data.adsets[key]
                var array = [];
                for (var i in JsonObj) {
        if (JsonObj.hasOwnProperty(i) && !isNaN( + i)) {
        array[ + i] = JsonObj[i];
                $window.localStorage.setItem("adsetId", i)
                $scope.adsetDetails = array[ + i];
                console.log($scope.adsetDetails);
                $scope.prePopulateAdsetDetails($scope.adsetDetails);
        }
        }
        });
        }
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }
        }
        })

                if ($window.localStorage.getItem("marketingObjective") == 'POST_ENGAGEMENT') {
        $scope.promotionObjective = 'no';
        }

        if ($scope.promotionObjective != 'no') {
        try {
        $scope.getAdCreativeForEdit();
        } catch (err) {
        console.log('error on promotive objective' + err);
        }
        };
        }
        $scope.campaignplan.accountCountryName = "India"
                $scope.campaignplan.currency = "Indian Rupee"
                $scope.campaignplan.description = "Asia/Kolkata"
                $scope.campaignplan.adAccName = "Digi Live"
                $scope.campaignplan.advertSetName = "createAdsetTest1"
                $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
                $scope.readadAccountId();
                $("[type='number']").keypress(function (evt) {
        evt.preventDefault();
        });
                $scope.checkMandatoryField();
        }

        function isString(value) {
        return typeof value == 'string';
        }
        ;
                function trim(value) {
                return isString(value) ? value.replace(/^\s*/, '').replace(/\s*$/, '') : value;
                }
        ;
                $scope.checkCurrencyCode = function (_code) {
                console.log($scope.currencyList);
                        angular.forEach($scope.currencyList, function (value, key) {
                        if ($scope.currencyList[key].currency == _code) {
                        console.log($scope.currencyList[key].currencyCode + " --- " + _code);
                                $scope.currencyValue = $scope.currencyList[key].currencyCode;
                                console.log($scope.currencyValue);
                                return $scope.currencyList[key].currencyCode;
                        }
                        });
                        $scope.currencyCode = $scope.currencyValue;
                }
        $scope.readadAccountId = function () {
        $rootScope.progressLoader = "block";
                var headers = {
                "userId": $window.localStorage.getItem("userId"),
                        "accessToken": $window.localStorage.getItem("accessToken")
                }
        var queryStr = "?networkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.readadaccounts(queryStr, headers).then(function (response) {
        console.log(response);
                if (response.data.appStatus == '0') { // success
        $rootScope.progressLoader = "none";
                //console.log(response.data.fbReadAdAccountResponse);
                angular.forEach(response.data.fbReadAdAccountResponse, function (value, key) {
                $scope.currency = response.data.fbReadAdAccountResponse[key].fbAdAccountDetails.currency;
                });
                $scope.currencyCode1 = $scope.checkCurrencyCode($scope.currency);
                console.log("currency = " + $scope.currency);
                console.log("currency = " + $scope.currencyCode);
        } else { // failed
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }

        }
        });
        };
                $scope.prePopulateValues = function (aDetails, cDetails) {
                console.log(aDetails.data.fbAdsetDetails);
                        if (aDetails.data.fbAdsetDetails != undefined) {
                $scope.populateAdvertDelivery(cDetails.data.campaignDetails.objective);
                        $scope.campaignPlanForm.advertDelivery = cDetails.data.campaignDetails.objective;
                        if (aDetails) {
                var budget = aDetails.data.fbAdsetDetails.daily_budget;
                }

                if (budget == 0) {
                $scope.campaignPlanForm.budget = "lifetimeBudget"
                        $scope.campaignPlanForm.budgetValue = aDetails.data.fbAdsetDetails.lifetime_budget;
                        var adserArr = aDetails.data.fbAdsetDetails.adset_schedule;
                        console.log(adserArr);
                        $scope.prePopulateChart(adserArr);
                } else {
                $scope.campaignPlanForm.budget = "dailyBudget"
                        $scope.campaignPlanForm.budgetValue = aDetails.data.fbAdsetDetails.daily_budget
                }



                $scope.campaignPlanForm.advertSetName = aDetails.data.fbAdsetDetails.name;
                        if (aDetails.data.fbAdsetDetails.end_time == null || aDetails.data.fbAdsetDetails.end_time == undefined || aDetails.data.fbAdsetDetails.end_time == " ") {
                $scope.campaignPlanForm.schedule = 1;
                } else {
                $scope.campaignPlanForm.schedule = 2;
                        var startDateValue = new Date(aDetails.data.fbAdsetDetails.start_time);
                        var endDateValue = new Date(aDetails.data.fbAdsetDetails.end_time);
                        var currentDate = $filter('date')(startDateValue, 'yyyy-M-d hh:mm a');
                        $scope.campaignPlanForm.scheduleStartDate = new Date(currentDate);
                        $scope.campaignPlanForm.scheduleEndDate = new Date(endDateValue);
                }

                if (aDetails.data.fbAdsetDetails.is_autobid == true) {
                $scope.campaignPlanForm.bidAmountVal = 1
                } else {
                $scope.campaignPlanForm.bidAmountVal = 2
                }


                $scope.campaignPlanForm.impression = aDetails.data.fbAdsetDetails.billing_event;
                        if ($scope.campaignPlanForm.budget == "dailyBudget") {
                $scope.campaignPlanForm.runAdvert = 1;
                        $scope.AdvertText = "Run adverts all the time";
                        $scope.showChart = false;
                } else {
                $scope.campaignPlanForm.runAdvert = 2;
                        $scope.AdvertText = "Run adverts on a schedule";
                        $scope.showChart = true;
                }

                if ($scope.campaignPlanForm.budget == "dailyBudget") {
                $scope.campaignPlanForm.deliverType = 1;
                        $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                } else {
                $scope.campaignPlanForm.deliverType = 2;
                        $scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";
                }

                } else {
                $scope.populateAdvertDelivery(cDetails.data.campaignDetails.objective);
                        $scope.campaignPlanForm.advertDelivery = cDetails.data.campaignDetails.objective;
                        if (aDetails) {
                var budget = aDetails.data.adsetDetails.daily_budget;
                }

                if (budget == 0) {
                $scope.campaignPlanForm.budget = "lifetimeBudget"
                        $scope.campaignPlanForm.budgetValue = aDetails.data.adsetDetails.lifetime_budget;
                        var adserArr = aDetails.data.adsetDetails.adset_schedule;
                        $scope.prePopulateChart(adserArr);
                } else {
                $scope.campaignPlanForm.budget = "dailyBudget"
                        $scope.campaignPlanForm.budgetValue = aDetails.data.adsetDetails.daily_budget
                }



                $scope.campaignPlanForm.advertSetName = aDetails.data.adsetDetails.name;
                        if (aDetails.data.adsetDetails.end_time == null || aDetails.data.adsetDetails.end_time == undefined || aDetails.data.adsetDetails.end_time == " ") {
                $scope.campaignPlanForm.schedule = 1;
                } else {
                $scope.campaignPlanForm.schedule = 2;
                }

                if (aDetails.data.adsetDetails.is_autobid == true) {
                $scope.campaignPlanForm.bidAmountVal = 1
                } else {
                $scope.campaignPlanForm.bidAmountVal = 2
                }


                $scope.campaignPlanForm.impression = aDetails.data.fbAdsetDetails.billing_event;
                        if ($scope.campaignPlanForm.budget == "dailyBudget") {
                $scope.campaignPlanForm.runAdvert = 1;
                        $scope.AdvertText = "Run adverts all the time";
                        $scope.showChart = false;
                } else {
                $scope.campaignPlanForm.runAdvert = 2;
                        $scope.AdvertText = "Run adverts on a schedule";
                        $scope.showChart = true;
                }

                if ($scope.campaignPlanForm.budget == "dailyBudget") {
                $scope.campaignPlanForm.deliverType = 1;
                        $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                } else {
                $scope.campaignPlanForm.deliverType = 2;
                        $scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";
                }


                }



                }
        $scope.fetchAdsetDetails = function (cDetails) {
        console.log(cDetails)
                var campaignId = cDetails.data.campaignId;
                var headers = {
                "userId": $window.localStorage.getItem("userId"),
                        "accessToken": $window.localStorage.getItem("accessToken")
                }
        var queryStr = "?adCampaignId=" + campaignId + "&" + "userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.readadset(queryStr, headers).then(function (response) {
        console.log(response)
                if (response.data.appStatus == 0) {
        angular.forEach(response.data.adsets, function (value, key) {
        var JsonObj = response.data.adsets[key]
                var array = [];
                for (var i in JsonObj) {
        if (JsonObj.hasOwnProperty(i) && !isNaN( + i)) {
        array[ + i] = JsonObj[i];
                $window.localStorage.setItem("adsetId", i)
                globalData.setLocal("adset", i, array[ + i]);
                $scope.getAndPrePopuplateValues(i, cDetails)

        }
        }
        });
                //$scope.prePopulateValuesForEdit(cDetails, response)
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }
        }
        })
        };
                $scope.getAndPrePopuplateValues = function (adsetId, cDetails) {
                var aDetails = globalData.getLocal(adsetId);
                        console.log(aDetails);
                        $scope.prePopulateValues(aDetails, cDetails)
                }
        $scope.getEditAdSetDetails = function () {
        var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"));
                var adsetDetails = globalData.getLocal($window.localStorage.getItem("adsetId"));
                $scope.prePopulateFromLocalStorage(adsetDetails, campaignDetails);
                console.log(campaignDetails)
                console.log(adsetDetails)
        }

        $scope.prePopulateChart = function (_arr) {
        console.log(_arr)
                var adsetSchedule = ['0-60', '60-120', '120-180', '180-240', '240-300', '300-360', '360-420', '420-480', '480-540', '540-600', '600-660', '660-720', '720-780', '780-840', '840-900', '900-960', '960-1020', '1020-1080', '1080-1140', '1140-1200', '1200-1260', '1260-1320', '1320-1380', '1380-1440']
                var getSchedule = [];
                angular.forEach(_arr, function (value, key) {
                var jsonObj = _arr[key];
                        console.log(jsonObj.start_minute + " : " + jsonObj.end_minute + " : " + jsonObj.days);
                        var conStr = jsonObj.start_minute + "-" + jsonObj.end_minute
                        console.log(conStr)
                        for (var i = 0; i < adsetSchedule.length; i++) {
                if (adsetSchedule[i] == conStr) {
                var sch = 0;
                        if (jsonObj.days[0] == 0) {
                var sch = i * 7 + 7;
                } else {
                var sch = i * 7 + jsonObj.days[0];
                }
                getSchedule.push(sch);
                }
                }
                });
                $rootScope.chartArray = getSchedule;
        }
        $scope.getValuesFromLocal = function (cDetails) {
        $scope.populateAdvertDelivery(cDetails.data.campaignDetails.objective);
                $scope.campaignPlanForm.advertDelivery = cDetails.data.campaignDetails.objective;
                var aDetails = globalData.getLocal($window.localStorage.getItem("adsetId"));
                if (aDetails) {
        var budget = aDetails.data.fbAdsetDetails.lifetime_budget;
                console.log(aDetails.data.fbAdsetDetails.adset_schedule);
        }
        if (budget != 0) {
        $scope.campaignPlanForm.budget = "lifetimeBudget";
                $scope.campaignPlanForm.budgetValue = aDetails.data.fbAdsetDetails.lifetime_budget;
                var adserArr = aDetails.data.fbAdsetDetails.adset_schedule;
                console.log(adserArr);
                $scope.prePopulateChart(adserArr);
        } else {
        $scope.campaignPlanForm.budget = "dailyBudget"
                $scope.campaignPlanForm.budgetValue = aDetails.data.fbAdsetDetails.daily_budget
        }



        $scope.campaignPlanForm.advertSetName = aDetails.data.fbAdsetDetails.name;
                if (aDetails.data.fbAdsetDetails.end_time == null || aDetails.data.fbAdsetDetails.end_time == undefined || aDetails.data.fbAdsetDetails.end_time == " ") {
        $scope.campaignPlanForm.schedule = 1;
        } else {
        $scope.campaignPlanForm.schedule = 2;
        }

        if (aDetails.data.fbAdsetDetails.is_autobid == true) {
        $scope.campaignPlanForm.bidAmountVal = 1
        } else {
        $scope.campaignPlanForm.bidAmountVal = 2
        }
        $scope.campaignPlanForm.impression = aDetails.data.fbAdsetDetails.billing_event;
                if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
                $scope.showChart = false;
        } else {
        $scope.campaignPlanForm.runAdvert = 2;
                $scope.AdvertText = "Run adverts on a schedule";
                $scope.showChart = true;
        }

        if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.deliverType = 1;
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
        } else {
        $scope.campaignPlanForm.deliverType = 2;
                $scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";
        }

        }

        $scope.prePopulateFromLocalStorage = function (adsetDetails, cDetails) {

        console.log(cDetails)
                if (cDetails.data.campaignId != undefined) {
        $scope.populateAdvertDelivery(cDetails.data.campaignDetails.objective);
                $scope.campaignPlanForm.advertDelivery = cDetails.data.campaignDetails.objective;
        }

        console.log(adsetDetails.data.fbAdsetId)
                if (adsetDetails.data.fbAdsetId != "undefined") {
        var budget = adsetDetails.data.fbAdsetDetails.lifetime_budget
                if (budget != 0) {
        $scope.campaignPlanForm.budget = "lifetimeBudget";
                $scope.showChart = true;
                $scope.campaignPlanForm.budgetValue = adsetDetails.data.fbAdsetDetails.lifetime_budget;
                var adsetArr = adsetDetails.data.fbAdsetDetails.adset_schedule;
                $scope.prePopulateChart(adsetArr);
        } else {
        $scope.campaignPlanForm.budget = "dailyBudget";
                $scope.showChart = false;
                $scope.campaignPlanForm.budgetValue = adsetDetails.data.fbAdsetDetails.daily_budget;
        }


        $scope.campaignPlanForm.advertSetName = adsetDetails.data.fbAdsetDetails.name
                if (adsetDetails.data.fbAdsetDetails.end_time == null || adsetDetails.data.fbAdsetDetails.end_time == undefined || adsetDetails.data.fbAdsetDetails.end_time == " ") {
        $scope.campaignPlanForm.schedule = 1;
        } else {
        $scope.campaignPlanForm.schedule = 2;
        }

        if (adsetDetails.data.fbAdsetDetails.is_autobid == true) {
        $scope.campaignPlanForm.bidAmountVal = 1
        } else {
        $scope.campaignPlanForm.bidAmountVal = 2
        }


        $scope.campaignPlanForm.impression = adsetDetails.data.fbAdsetDetails.billing_event

                if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
        } else {
        $scope.campaignPlanForm.runAdvert = 2;
                $scope.AdvertText = "Run adverts on a schedule";
        }

        if ($scope.campaignPlanForm.budget == "dailyBudget") {
        $scope.campaignPlanForm.deliverType = 1;
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
        } else {
        $scope.campaignPlanForm.deliverType = 2;
                $scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";
        }



        }



        }


        $scope.prePopulateCampaignDetailsFromLocalStorage = function (cDetails) {
        $scope.populateAdvertDelivery(cDetails.data.campaignDetails.objective);
                $scope.campaignPlanForm.advertDelivery = cDetails.data.campaignDetails.objective

                console.log(cDetails.data.campaignDetails.objective)
        }
        $scope.$watch('campaignPlanForm.budgetValue', function (newVal, oldVal) {
        $scope.checkMandatoryField();
                if (newVal) {
        angular.element('#step1').css('background-color', '#95D2B1');
        } else
        {
        angular.element('#step1').css('background-color', '#c2c2c2');
        }

        }, true)
                $scope.populateAdvertDelivery = function (marketingObjective) {
                angular.forEach($scope.marketingObjectEnableList, function (value, key) {
                if (marketingObjective == $scope.marketingObjectEnableList[key].id) {
                $scope.advertItemsList = $scope.marketingObjectEnableList[key].assets;
                }
                })
                        $scope.campaignPlanForm.advertDelivery = marketingObjective;
                };
                $scope.openAdvancedOption = function () {
                $scope.advancedOption = true;
                        $scope.advertSchedule = true;
                }
        $scope.openImpression = function () {
        $scope.impressions = true;
                $scope.radioimpressions = true;
                $scope.moreimpressions = true;
        }
        $scope.openRunAdverts = function () {
        $scope.runAdverts = true;
        }
        $scope.opendeliveryType = function () {
        $scope.deliveryType = true;
        }
        $scope.closeAdvancedOption = function () {
        $scope.advancedOption = false;
        }
        $scope.setPadding = function (_index) {

        if (_index.id != 1) {
        angular.element('#radio' + _index.id).addClass('radio-padding-left');
        }

        if (_index.id == 1) {
        angular.element('#radio' + _index.id).css('padding-bottom', '10px');
        }

        }
        $scope.setBudgetValue = function (value) {
        $scope.campaignPlanForm.budgetValue = value;
        }
        $scope.selectBudget = function (_obj) {
        $scope.setCampaignPlanMapping();
                if (_obj != null) {
        if (_obj == "dailyBudget") {
        $scope.checked = false
                $scope.budget = true;
                $scope.showChart = false;
                $scope.runAdverts = false;
                $scope.startDateToday = false;
                $scope.campaignPlanForm.runAdvert1 = 1;
        } else {
        $scope.todayDate = new Date();
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.campaignPlanForm.scheduleStartDate = new Date(currentDate);
                $scope.checked = true;
                $scope.budget = false;
                $scope.campaignPlanForm.runAdvert = 1;
                $scope.AdvertText = "Run adverts all the time";
                $scope.campaignPlanForm.deliverType = 1;
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                $scope.showChart = false;
                $scope.runAdverts = true;
                $scope.startDateToday = true;
                $scope.campaignPlanForm.schedule = 2;
                $scope.setDate = true;
                $scope.campaignPlanForm.runAdvert1 = 2;
        }


        } else {
        $scope.campaignPlanForm.budgetValue = ""
                angular.element('#step1').css('background-color', '#C2C2C2');
        }
        $scope.checkMandatoryField();
                $window.localStorage.setItem("dailybudget", $scope.campaignPlanForm.budgetValue)
        }

        $scope.selectChargedOption = function (_obj) {
        console.log($scope.campaignPlanForm.advertDelivery);
                // Post Engagement Start
                if ($scope.marketingObjective == "POST_ENGAGEMENT") {
        if ($scope.campaignPlanForm.advertDelivery.name == "POST_ENGAGEMENT") {
        $scope.campaignPlanForm.impression = "POST_ENGAGEMENT";
                $scope.chargedOption = [
                {
                "id": "POST_ENGAGEMENT",
                        "name": "Post engagement",
                        "disabled": "false"
                },
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
                ]
        }
        if ($scope.campaignPlanForm.advertDelivery.name == "IMPRESSIONS" || $scope.campaignPlanForm.advertDelivery.name == "REACH") {
        $scope.campaignPlanForm.impression = "IMPRESSIONS";
                $scope.chargedOption = [
                {
                "id": "IMPRESSIONS",
                        "name": "Impressions",
                        "disabled": "false"
                }
                ]
        }

        }
        // Post Engagement End



        }


//        $scope.senddisableofferConversion = function (offerConversion) {
//        if (offerConversion == '' || offerConversion == undefined || offerConversion == null) {
//        angular.element('#offerConversion').addClass("mandatory");
//        } else {
//        angular.element('#offerConversion').removeClass("mandatory");
//        }
//        $scope.campaignPlanForm.offerConversion = offerConversion;
//                $window.localStorage.setItem("offerConversion", $scope.offerConversion);
//                $rootScope.freezeFlag = true;
//                $scope.checkMandatoryField();
//        }

//        $scope.getFrequencyCap = function (frequencyCap) {
//        $scope.campaignPlanForm.frequencyCap = frequencyCap;
//                $window.localStorage.setItem("frequencyCap", $scope.frequencyCap);
//                $rootScope.freezeFlag = true;
//                $scope.checkMandatoryField();
//        }

        $scope.selectAdvertDelivery = function (_obj) {
        $scope.selectChargedOption(_obj);
                console.log(_obj);
                //console.log($scope.marketingObjective);
                $scope.offerconversiondiv = false;
                $scope.campaignPlanForm.advertDelivery = _obj.name;
                $scope.campaignPlanForm.offerConversion = '';
                if (_obj.name == 'POST_ENGAGEMENT') {
        $scope.manualbidtxt = 'per post engagement';
        } else {
        $scope.manualbidtxt = "per 1,000 impressions";
        }
        $scope.checkMandatoryField();
        }

        $scope.selectSchedule = function (value) {

        if (value == "1") {
        $scope.setDate = false;
        $scope.enddateselected=false;
                $scope.todayDate = new Date();
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.campaignPlanForm.scheduleStartDate = new Date(currentDate);
                $scope.campaignPlanForm.scheduleEndDate = 0; //$filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:');
                


        } else {
        $scope.enddateselected=false;
        $scope.setDate = true;
                $scope.todayDate = new Date();
                $scope.campaignPlanForm.scheduleEndDate = $scope.endDate;
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.campaignPlanForm.scheduleStartDate = new Date(currentDate);
                $scope.campaignPlanForm.scheduleEndDate = 0;
//                if ($scope.campaignPlanForm.scheduleEndDate != "" && $scope.campaignPlanForm.scheduleEndDate != null && $scope.campaignPlanForm.scheduleEndDate != undefined)
//        {
//        angular.element('#step2').css('background-color', '#95D2B1');
//        } else
//        {
//        angular.element('#step2').css('background-color', '#c2c2c2');
//                angular.element('.is-btn-disabled').css('opacity', 0.9);
//                angular.element('.is-btn-disabled').css('pointer-events', 'none');
//        }
//        angular.element('#endate').addClass("mandatory");
//                angular.element('#endtime').addClass("mandatory");
        }

        $window.localStorage.setItem("scheduleStartDate", $scope.campaignPlanForm.scheduleStartDate);
                $window.localStorage.setItem("scheduleEndDate", $scope.campaignPlanForm.scheduleEndDate);
                $scope.checkMandatoryField();
        }
        $scope.onDateChange1 = function (selectedDate) {
        console.log(selectedDate);
                $scope.campaignPlanForm.scheduleStartDate = selectedDate;
                console.log($scope.campaignPlanForm.scheduleStartDate)
                $window.localStorage.setItem("scheduleStartDate", $scope.campaignPlanForm.scheduleStartDate)
        }
        $scope.onDateChange2 = function (selectedDate) {
        console.log(selectedDate);
                $scope.campaignPlanForm.scheduleEndDate = selectedDate;
                console.log($scope.campaignPlanForm.scheduleEndDate)
                $window.localStorage.setItem("scheduleEndDate", $scope.campaignPlanForm.scheduleEndDate);
                $scope.diffDate($scope.campaignPlanForm.scheduleStartDate , $scope.campaignPlanForm.scheduleEndDate );
                $scope.checkMandatoryField();
        }
        
        $scope.diffDate = function(date1, date2){
            var dateOut1 = new Date(date1); // it will work if date1 is in ISO format
            var dateOut2 = new Date(date2);
            var timeDiff = Math.abs(date2.getTime() - date1.getTime());
            $scope.diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
            if (Date.parse($scope.campaignPlanForm.scheduleEndDate) >= Date.parse($scope.campaignPlanForm.scheduleStartDate)) {
                $scope.enddateselected=true;
            }else
            {
                $scope.enddateselected=false;
            }
        };
        
        $scope.onTimeChange1 = function (selectedTime) {
        console.log(selectedTime);
                $scope.campaignPlanForm.scheduleStartDate = selectedTime;
                console.log($scope.campaignPlanForm.scheduleStartDate)
                $window.localStorage.setItem("scheduleStartDate", $scope.campaignPlanForm.scheduleStartDate)
        }
        $scope.onTimeChange2 = function (selectedTime) {
        console.log(selectedTime);
                $scope.checkMandatoryField();
                $scope.campaignPlanForm.scheduleEndDate = selectedTime;
                console.log($scope.campaignPlanForm.scheduleEndDate);
                $window.localStorage.setItem("scheduleEndDate", $scope.campaignPlanForm.scheduleEndDate)

        }
        $scope.selectBidAmount = function (value) {
        $scope.bidamount = value;
                if (value == 1) {
        $scope.campaignPlanForm.bidAmount = '';
                $scope.autoBid = true;
                $scope.showText = false;
                $scope.campaignPlanForm.deliverType = 1;
                $scope.campaignPlanForm.deliveryType = "standard";
                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
        } else {
        $scope.showText = true;
//                $scope.campaignPlanForm.deliverType = 1;
//                $scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                $scope.autoBid = false;
        }

        $scope.campaignPlanForm.bidAmountVal = value;
                $scope.checkMandatoryField();
        }
        $scope.saveBidAmount = function (value) {
        $scope.campaignPlanForm.bidAmount = value;
                $scope.checkMandatoryField();
        }
        $scope.selectImpression = function (value) {
        $scope.campaignPlanForm.impression = value;
        }
        $scope.AdvertText = "Run adverts all the time";
                $scope.selectRunAdvert = function (value) {
                console.log(value);
                        if (value == 1) {
                $scope.AdvertText = "Run adverts all the time";
                        $scope.showChart = false;
                } else {
                $scope.AdvertText = "Run adverts on a schedule";
                        $scope.showChart = true;
                }

                }
        $scope.selectDeliveryType = function(value) {
            console.log(value);
            if (value == 1) {
//                $scope.campaignPlanForm.deliveryType = "standard";
               $scope.campaignPlanForm.deliverType = 1;
            }else{
//                $scope.campaignPlanForm.deliveryType = "no_pacing";
               $scope.campaignPlanForm.deliverType = 2;
            } 
        };

        $scope.init();
                $scope.gotoParentCampaign = function () {
                $state.go('app.parentcampaign');
                        $rootScope.freezeFlag = false;
                }
        var everythingLoaded = setInterval(function () {
        if (/loaded|complete/.test(document.readyState)) {
        clearInterval(everythingLoaded);
                $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                var offsetHeight2 = document.getElementById('step2container').offsetHeight;
                var fStep = $(".vr");
                fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
        }
        }, 10);
                $scope.getAdvertSetName = function (_value) {

                $scope.campaignPlanForm.advertSetNme = _value;
                        $scope.checkMandatoryField();
                }
        $scope.moveNextStep = function () {
        $rootScope.campaignSteps[2] = true;
                $state.go('app.bypcampaigncreative');
        }

        $scope.updateCampaignPlan = function () {
        $scope.isDirty = $scope.campaignPlanCreateForm.$dirty;
                console.log($scope.adsetDetails);
                if ($scope.adsetDetails != undefined && $scope.adsetDetails != "") {
        var promotableObject = $window.localStorage.getItem("campaignAudienceTargetType");
                $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
                $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
                if ($window.localStorage.getItem("campaignAudienceTargetType")) {
        $scope.pageIdVal = $window.localStorage.getItem("campaignAudienceTarget");
        } else {
        $scope.pageIdVal = $scope.adsetDetails.adsetDetails.adlabels.id;
        }
        if ($window.localStorage.getItem("campaignAudienceLocationsJSON")) {
        $scope.selectedTarget = $window.localStorage.getItem("campaignAudienceLocationsJSON");
                $scope.connectFBLocation = JSON.parse($scope.selectedTarget);
                console.log($scope.connectFBLocation);
        } else {
        $scope.connectFBLocation = $scope.adsetDetails.adsetDetails.targeting;
        }
        } else {
        if ($window.localStorage.getItem("campaignAudienceTargetType")) {
        $scope.pageIdVal = $window.localStorage.getItem("campaignAudienceTargetType");
        }
        if ($window.localStorage.getItem("campaignAudienceLocationsJSON")) {
        $scope.selectedTarget = $window.localStorage.getItem("campaignAudienceLocationsJSON");
                $scope.connectFBLocation = JSON.parse($scope.selectedTarget);
                console.log($scope.connectFBLocation);
        }
        }
        $scope.todayDate = new Date();
                console.log($scope.currentSdate + " :: " + $scope.campaignPlanForm.scheduleStartDate);
                if ($scope.todayDate == $scope.campaignPlanForm.scheduleStartDate) {
        console.log('start Date equeal');
        } else {
        $scope.dateChanged = true;
        }
        if ($scope.currentEdate == $scope.campaignPlanForm.scheduleEndDate) {
        console.log('end Date equeal');
        } else {
        $scope.dateChanged = true;
        }
        console.log($rootScope.chartChange);
                if ($scope.isDirty || $rootScope.overLayAudience || $rootScope.chartChange) {
        $rootScope.freezeFlag = false;
                $rootScope.overLayAudience = false;
                $scope.submitted = false;
                var parameters1 = {};
                var budgetParameter = $scope.campaignPlanForm.budget;
                var bidAmountParameter;
                var bidAmountValue;
                console.log(budgetParameter);
               if ($scope.campaignPlanForm.deliverType == 2) {
                    $scope.pacing = ["no_pacing"]
                    if (budgetParameter != "dailyBudget") {
                        budgetParameter = "lifeTimeBudget";
                        if($scope.showChart){
                                $scope.pacing.push("day_parting");
                                var adsetScheduleValue = $rootScope.adsetSchedule;
                       }
                    }
                } else {
                    $scope.pacing = ["standard"]
                    if (budgetParameter != "dailyBudget") {
                        budgetParameter = "lifeTimeBudget";
                       if($scope.showChart){
                            $scope.pacing = ["day_parting"]
//                                    $scope.pacing.push("day_parting");
                                var adsetScheduleValue = $rootScope.adsetSchedule;
                        }
                    }
                }


        console.log($rootScope.adsetSchedule);
                if ($scope.campaignPlanForm.schedule == 1) {
        $scope.campaignPlanForm.scheduleStartDate = new Date();
                $scope.campaignPlanForm.scheduleEndDate = 0;
        }


        if ($scope.campaignPlanForm.bidAmountVal == 1) {
        bidAmountParameter = 'isAutoBid';
                bidAmountValue = $scope.autoBid;
        } else {
        bidAmountParameter = 'bidAmount';
                bidAmountValue = $scope.campaignPlanForm.bidAmount;
        }


        $rootScope.progressLoader = "block";
                $scope.popupShow = false;
                var headers = {
                "Content-Type": "application/json"
                }
        console.log($window.localStorage.getItem('adsetId'));
                var parameterAdd = {};
                var parameterCheck = {
                "userId": $window.localStorage.getItem('userId'),
                        "accessToken": $window.localStorage.getItem('accessToken'),
                        "adSetId": $window.localStorage.getItem('adsetId'),
                        "adSetName": $scope.campaignPlanForm.advertSetName,
                        "billingEvent": $scope.campaignPlanForm.impression,
                        "adLabels": [{
                        "name": $scope.campaignPlanForm.advertSetName
                        }],
                        "status": "PAUSED",
                        "targeting": $scope.connectFBLocation,
                        "pacingType": $scope.pacing,
                        "userNetworkMapId": $window.localStorage.getItem('userNetworkMapId'),
                        "optimizationGoal": $scope.campaignPlanForm.advertDelivery
                };
                parameterCheck[bidAmountParameter] = bidAmountValue;
                                parameterCheck[budgetParameter] = $scope.campaignPlanForm.budgetValue;
                var conversionObj = $filter('filter')($scope.conversionwindowArr, function (d) {
        return d.Value == $scope.campaignPlanForm.offerConversion;
        })[0];
                if ($scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery == "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        conversionparameterAdd = {
        "attributionWindowDays": conversionObj.Key1
        };
                parameterCheck = angular.extend({}, parameterCheck, conversionparameterAdd);
        }
        if (budgetParameter != "dailyBudget") {
        parameterAdd = {
        "adSetSchedule": adsetScheduleValue
        }
        parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        }
        if ($scope.campaignAudienceCampaignOffer != '' && $scope.campaignAudienceCampaignOffer != 'undefined' && $scope.campaignAudienceCampaignOffer != null && promotableObject == 'page' && $scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery == "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal,
                "offer_id": $scope.campaignAudienceCampaignOffer,
                "pixel_id": $scope.campaignAudienceCampaignConversionPixel,
                "custom_event_type": "CONTENT_VIEW"
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.campaignAudienceCampaignOffer != '' && $scope.campaignAudienceCampaignOffer != 'undefined' && $scope.campaignAudienceCampaignOffer != null && promotableObject == 'page' && $scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery != "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal,
                "offer_id": $scope.campaignAudienceCampaignOffer
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.campaignAudienceCampaignConversionPixel != '' && $scope.campaignAudienceCampaignConversionPixel != 'undefined' && $scope.campaignAudienceCampaignConversionPixel != null && $scope.marketingObjective == "CONVERSIONS") {
        parameterAdd = {
        "promotedObject": {
        "pixel_id": $scope.campaignAudienceCampaignConversionPixel,
                "custom_event_type": "CONTENT_VIEW"
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        }
		
		
        var finalDate = new Date($scope.campaignPlanForm.scheduleEndDate);
        var dateObj = {
        "endTime": finalDate
        }
	
        var parameters = angular.extend({}, parameterCheck, dateObj);	
        
                console.log(parameters)

                facebookGetPost.updateadset("", parameters).then(function (response) {
        console.log(response)
                if (!$scope.popupShow) {
        $scope.popupShow = true;
                if (response.data.appStatus == 0) {
        $scope.getAdSetDetails();
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }

        }
        }

        })

        } else {
        $scope.moveNextStep();
        }



        }

        $scope.merge_options = function (obj1, obj2) {
        var obj3 = {};
                for (var attrname in obj1) {
        obj3[attrname] = obj1[attrname];
        }
        for (var attrname in obj2) {
        obj3[attrname] = obj2[attrname];
        }
        console.log(obj3);
                return obj3;
        }


        $scope.successPopup = function () {
        var modalSuccessPop = $(".success-popup"); // Get the modal Success req
                modalSuccessPop.show();
                angular.element($('body').css("overflow-y", "hidden"))
        }
        $scope.postCampaignPlan = function (data) {

        if (!$scope.campaignPlanCreateForm.$valid) {
        return;
        }

        if ($window.localStorage.getItem("campaignState") != "create") {
        $scope.updateCampaignPlan();
        } else {
        $scope.isDirty = $scope.campaignPlanCreateForm.$dirty;
                console.log($scope.isDirty);
                if ($scope.isDirty) {

        console.log($rootScope.adsetSchedule);
                $scope.submitted = false;
                var parameters1 = {};
                var budgetParameter = $scope.campaignPlanForm.budget;
                var promotableObject = $window.localStorage.getItem("campaignAudienceTargetType")
                var bidAmountParameter;
                var bidAmountValue;
                if ($scope.campaignPlanForm.deliverType == 2) {
                        $scope.pacing = ["no_pacing"]
                        if (budgetParameter != "dailyBudget") {
                            budgetParameter = "lifetimeBudget";
                            if($scope.showChart){
                                $scope.pacing.push("day_parting");
                                var adsetScheduleValue = $rootScope.adsetSchedule;
                           }
                        }
                    } else {
                        $scope.pacing = ["standard"]
                        if (budgetParameter != "dailyBudget") {
                            budgetParameter = "lifetimeBudget";
                           if($scope.showChart){
                                $scope.pacing = ["day_parting"]
//                                    $scope.pacing.push("day_parting");
                                    var adsetScheduleValue = $rootScope.adsetSchedule;
                            }
                        }
                    }


        if ($scope.campaignPlanForm.bidAmountVal == 1) {
        bidAmountParameter = 'isAutobid';
                bidAmountValue = $scope.autoBid;
        } else {
        bidAmountParameter = 'bidAmount';
                bidAmountValue = $scope.campaignPlanForm.bidAmount;
        }

        if ($scope.campaignPlanForm.schedule == 1) {
        $scope.campaignPlanForm.scheduleStartDate = new Date();
                $scope.campaignPlanForm.scheduleEndDate = 0;
        }
        console.log($scope.campaignPlanForm.scheduleStartDate + " :: " + $scope.campaignPlanForm.scheduleEndDate)
                if ($scope.campaignPlanForm.scheduleStartDate == undefined || $scope.campaignPlanForm.scheduleStartDate == "") {
        //$scope.campaignPlanForm.scheduleStartDate=$scope.todayDate;
        }

        if ($scope.campaignPlanForm.scheduleEndDate == undefined || $scope.campaignPlanForm.scheduleEndDate == "") {
        //$scope.campaignPlanForm.scheduleEndDate=$scope.todayDate;
        }

        $rootScope.progressLoader = "block";
                $scope.popupShow = false;
                $scope.pageIdVal = $window.localStorage.getItem("campaignAudienceTarget");				
			    $scope.pageIdVal = 726949550817444;
                $scope.selectedTarget = $window.localStorage.getItem("campaignAudienceLocationsJSON");
                $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
                $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
                $scope.connectFBLocation = JSON.parse($scope.selectedTarget);
                var headers = {
                "Content-Type": "application/json"
                }


        var parameterAdd = {};
                var conversionparameterAdd = {};
                var parameterCheck = {
						"userId": $window.localStorage.getItem('userId'),
                        "accessToken": $window.localStorage.getItem('accessToken'),
                        "networkAdAccountId": $window.localStorage.getItem('networkAdAccountId'),
                        "userNetworkMapId": $window.localStorage.getItem('userNetworkMapId'),
                        "optimizationGoal": $scope.campaignPlanForm.advertDelivery,
                        "billingEvent": $scope.campaignPlanForm.impression,
                        "campaignId": $window.localStorage.getItem("campaignId"),
                        "name": $scope.campaignPlanForm.advertSetName,
                        "targeting": $scope.connectFBLocation,
                        "startTime": $scope.campaignPlanForm.scheduleStartDate,                        
                        "pacingType": $scope.pacing,
                        "status": "PAUSED",
                        "adlabels": [{
                        "name": $scope.campaignPlanForm.advertSetName
                        }],
                };
                parameterCheck[bidAmountParameter] = bidAmountValue;
                                parameterCheck[budgetParameter] = $scope.campaignPlanForm.budgetValue;
                if ($scope.showChart) {
        parameterAdd = {
        "adsetSchedule": adsetScheduleValue
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        }

				if($scope.campaignPlanForm.scheduleEndDate){
						var finalDate = new Date($scope.campaignPlanForm.scheduleEndDate);
						parameterAdd = {
						     "endTime": finalDate
						}
						 parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
				}
		
        var conversionObj = $filter('filter')($scope.conversionwindowArr, function (d) {
        return d.Value == $scope.campaignPlanForm.offerConversion;
        })[0];
                if ($scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery == "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        conversionparameterAdd = {
        "attributionWindowDays": conversionObj.Key1
        };
                parameterCheck = angular.extend({}, parameterCheck, conversionparameterAdd);
        }

        if ($scope.pageIdVal != '' && $scope.pageIdVal != 'undefined' && $scope.pageIdVal != null && promotableObject == 'app') {
        parameterAdd = {
        "promotedObject": {
        "application_id": $scope.pageIdVal,
                "object_store_url": "https://apps.facebook.com/" + $scope.pageIdVal //https://apps.facebook.com/695138990636614/
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.pageIdVal != '' && $scope.pageIdVal != 'undefined' && $scope.pageIdVal != null && promotableObject == 'page') {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.pageIdVal != '' && $scope.pageIdVal != 'undefined' && $scope.pageIdVal != null && promotableObject == 'event') {
        parameterAdd = {
        "promotedObject": {
        "event_id": $scope.pageIdVal
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        }
        //console.log($scope.campaignAudienceCampaignOffer+"=="+promotableObject+"=="+$scope.campaignPlanForm.offerConversion+"=="+$scope.campaignPlanForm.advertDelivery+"=="+$scope.marketingObjective);
        if ($scope.campaignAudienceCampaignOffer != '' && $scope.campaignAudienceCampaignOffer != 'undefined' && $scope.campaignAudienceCampaignOffer != null && promotableObject == 'page' && $scope.campaignPlanForm.offerConversion == '' && $scope.campaignPlanForm.advertDelivery != "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal,
                "offer_id": $scope.campaignAudienceCampaignOffer
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.campaignAudienceCampaignOffer != '' && $scope.campaignAudienceCampaignOffer != 'undefined' && $scope.campaignAudienceCampaignOffer != null && promotableObject == 'page' && $scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery == "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal,
                "offer_id": $scope.campaignAudienceCampaignOffer,
                "pixel_id": $scope.campaignAudienceCampaignConversionPixel,
                "custom_event_type": "CONTENT_VIEW"
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.campaignAudienceCampaignOffer != '' && $scope.campaignAudienceCampaignOffer != 'undefined' && $scope.campaignAudienceCampaignOffer != null && promotableObject == 'page' && $scope.campaignPlanForm.offerConversion != '' && $scope.campaignPlanForm.offerConversion != 'undefined' && $scope.campaignPlanForm.offerConversion != null && $scope.campaignPlanForm.advertDelivery != "OFFSITE_CONVERSIONS" && $scope.marketingObjective == "OFFER_CLAIMS") {
        parameterAdd = {
        "promotedObject": {
        "page_id": $scope.pageIdVal,
                "offer_id": $scope.campaignAudienceCampaignOffer
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        } else if ($scope.campaignAudienceCampaignConversionPixel != '' && $scope.campaignAudienceCampaignConversionPixel != 'undefined' && $scope.campaignAudienceCampaignConversionPixel != null && $scope.marketingObjective == "CONVERSIONS") {
        parameterAdd = {
        "promotedObject": {
        "pixel_id": $scope.campaignAudienceCampaignConversionPixel,
                "custom_event_type": "CONTENT_VIEW"
        }
        };
                parameterCheck = angular.extend({}, parameterCheck, parameterAdd);
        }

        if (($scope.marketingObjective == "BRAND_AWARENESS" || $scope.marketingObjective == "REACH") && $scope.campaignPlanForm.advertDelivery == "REACH")
        {
        parameterAdd = {
        "frequencyControlSpecs": [{"event": "IMPRESSIONS", "interval_days": $scope.campaignPlanForm.frequencyCap, "max_frequency": 1}]
        }

        }
        var parameters = angular.extend({}, parameterCheck, parameterAdd);
                console.log(parameters);
                facebookGetPost.createadset("", parameters).then(function (response) {
        console.log(response);
                if (!$scope.popupShow) {
        $scope.popupShow = true;
                if (response.data.appStatus == 0) {
        $window.localStorage.setItem("adsetId", response.data.adsetId);
                $scope.getAdSetDetails();
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }

        }
        }
        })
        }
        }
        };
                $scope.showSuccessPopup = function (response) {
                $scope.popupTitle = "Success"
                        $scope.popupMessage = response.successMessage
                        var modalApproveReq = $(".update_modalApprove1"); // Get the modal Approve req
                        modalApproveReq.show();
                }
        $scope.gotoSuccess = function () {
        var modalApproveReq = $(".update_modalApprove1"); // Get the modal Approve req
                modalApproveReq.hide();
                $scope.moveNextStep();
        }
        $scope.resetSelection = function () {
        $rootScope.freezeFlag = false;
                $scope.failure_update_popup = false;
                var modalApproveReq = $(".update_modalApprove"); // Get the modal Approve req
                modalApproveReq.hide();
                angular.element("#budget-input").focus();
                $rootScope.chartArray = [];
                $rootScope.chartChange = false;
                $scope.dateChanged = false;
        }

        $scope.goToSecondStep = function () {
        $rootScope.freezeFlag = false;
                var modalReq = $(".error_modalEvent");
                modalReq.hide();
                $state.go('app.bypcampaignaudience');
        }

        $scope.getAdSetDetails = function () {
        var netWorkMapId = $window.localStorage.getItem('userNetworkMapId');
                var adsetId = $window.localStorage.getItem('adsetId');
                var headers = {
                "userId": $window.localStorage.getItem("userId"),
                        "accessToken": $window.localStorage.getItem("accessToken")
                }
        var queryStr = "?userNetworkMapId=" + netWorkMapId + "&adSetId=" + adsetId;
                facebookGetPost.getadset(queryStr, headers).then(function (response) {
        console.log(response);
                if (response.data.appStatus == '0') {
        $scope.getnetworkUserIdDetails(response.data);
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }
        }
        })
        }
        $scope.getnetworkUserIdDetails = function (adsetDetails) {
        var netWorkMapId = $window.localStorage.getItem('userNetworkMapId')
                var headers = {
                "userId": $window.localStorage.getItem("userId"),
                        "accessToken": $window.localStorage.getItem("accessToken")
                }
        var queryStr = "?networkMapId=" + netWorkMapId;
                facebookGetPost.getfbuserid(queryStr, headers).then(function (response) {
        console.log(response)

                if (response.data.appStatus == '0') {
        $window.localStorage.setItem("fbUserId", response.data.fbUserId);
                $scope.saveAdSetId(response.data.fbUserId, adsetDetails);
                globalData.setLocal("adset", $window.localStorage.getItem("adsetId"), adsetDetails);
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }
        }
        })
        }


        $scope.saveAdSetId = function (fbUserId, adsetDetails) {

        $rootScope.progressLoader = "block";
                var parameters = {
                "userId": $window.localStorage.getItem('userId'),
                        "accessToken": $window.localStorage.getItem('accessToken'),
                        "fbAdsetId": $window.localStorage.getItem("adsetId"),
                        "fbAdsetDetails": adsetDetails.adsets,
                        "userNetworkMapId": $window.localStorage.getItem('userNetworkMapId')
                }



        facebookGetPost.saveadsetdata("", parameters).then(function (response) {
        console.log(response);
                if (response.data.appStatus == 0) {
        $rootScope.progressLoader = "none";
                $scope.moveNextStep();
        } else {
        $rootScope.progressLoader = "none";
                if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
        $window.localStorage.setItem("TokenExpired", true);
                $state.go('login');
        } else {
        $scope.showErrorPopup(response);
        }
        }
        })
                if ($window.localStorage.getItem("campaignState") == "create") {
        $rootScope.progressLoader = "none";
                $window.localStorage.setItem("lastStep", 4);
        }
        if ($window.localStorage.getItem("campaignState") == "draftEdit") {
        $window.localStorage.setItem("lastStep", 4);
        }
        }
        $scope.accountItems = [{
        "id": 1,
                "name": "Linux",
                "description": null,
                "code": null
        }, {
        "id": 2,
                "name": "Windows",
                "description": null,
                "code": null
        }]
                $scope.currencyItems = [{
                "id": 1,
                        "name": "Linux",
                        "description": null,
                        "code": null
                }, {
                "id": 2,
                        "name": "Windows",
                        "description": null,
                        "code": null
                }]


                $scope.timeZoneItems = [{
                "id": 1,
                        "name": "Linux",
                        "description": null,
                        "code": null
                }, {
                "id": 2,
                        "name": "Windows",
                        "description": null,
                        "code": null
                }]


                $scope.budgetItems = [{
                "id": 1,
                        "name": "dailyBudget",
                        "description": "Daily Budget",
                        "code": null
                }, {
                "id": 2,
                        "name": "lifetimeBudget",
                        "description": "Lifetime Budget",
                        "code": null
                }]
        }

]);
        dashboard.controller("dayPartChartController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'globalData', 'sharedService1',
                function ($rootScope, $scope, $state, catalyst, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile, appSettings, globalData, sharedService1) {
                var apiTPBase = appSettings.apiTPBase;
                        var apiBase = appSettings.apiBase;
                        $rootScope.adsetSchedule = [];
                        //sharedService1.store = $scope;
                        var data = [{
                        "day": "Monday",
                                "time": "12"
                        },
                        {
                        "day": "Tuesday",
                                "time": "3"
                        },
                        {

                        "day": "Wednesday",
                                "time": "6"
                        },
                        {

                        "day": "Thursday",
                                "time": "9"
                        },
                        {
                        "day": "Friday",
                                "time": "12"
                        },
                        {

                        "day": "Saturday",
                                "time": "3"
                        },
                        {
                        "day": "Sunday",
                                "time": "6"
                        }




                        ]

                        var svgns = "http://www.w3.org/2000/svg";
                        var _x = 130;
                        var _y = 85;
                        var day = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                        var time = ["12", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"]
                        var everyDay = [8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128, 136, 144, 152, 160, 168, 176, 184, 192];
                        var timeArray = ["12AM", "1AM", "2AM", "3AM", "4AM", "5AM", "6AM", "7AM", "8AM", "9AM", "10AM", "11AM", "12PM", "1PM", "2PM", "3PM", "4PM", "5PM", "6PM", "7PM", "8PM", "9PM", "10PM", "11PM", "12PM"]
                        var getSchedule = [2, 78, 94, 45, 56, 148, 149, 150, 151, 152, 153, 154];
                        var everyDayPart = [];
                        var totalWeekDays = 7;
                        var selectedTime = 0;
                        var selectedDay = 0;
                        var selectedTime = "";
                        var dragging = 0;
                        var startTime = 0;
                        var endTime = 60;
                        var dayFlag = false;
                        var timeFlag = false;
                        var canvas;
                        $scope.chartInit = function (obj) {


                        function reSchdeule1(flag) {
                        //	console.log('reSchdeule1')
                        var tmp2 = 1

                                for (var x = 116; x < 820; x += 30) {
                        for (var y = 75; y < 76; y += 35) {
                        //console.log(x+" "+y)
                        var xmlns = "http://www.w3.org/2000/svg"
                                var elem = document.createElementNS(xmlns, 'text');
                                //elem.setAttributeNS(null,"id","myText_"+tmp2);
                                elem.setAttributeNS(null, 'x', x);
                                elem.setAttributeNS(null, 'y', y);
                                elem.setAttributeNS(null, 'dx', '0,0,0,0,0');
                                elem.setAttributeNS(null, 'dy', '0,0,0,0,0');
                                elem.setAttributeNS(null, 'font-size', '12');
                                elem.setAttributeNS(null, 'color', '#484848');
                                elem.setAttributeNS(null, 'text-anchor', 'middle');
                                elem.setAttributeNS(null, 'cursor', 'pointer');
                                var lblText = document.createTextNode(time[tmp2 - 1]);
                                elem.append(lblText);
                                //console.log(elem);
                                //	console.log(document.getElementById('canvasElement'));
                                document.getElementById('canvasElement').appendChild(elem);
                                tmp2++;
                        }
                        }




                        var tmp1 = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 50; y < 56; y += 35) {
                        //var xmlns = "http://www.w3.org/2000/svg"
                        var txtRect = document.createElementNS(svgns, 'rect');
                                txtRect.setAttributeNS(null, "id", "myText_" + tmp1);
                                txtRect.setAttributeNS(null, 'x', x);
                                txtRect.setAttributeNS(null, 'y', y);
                                txtRect.setAttributeNS(null, 'height', '22');
                                txtRect.setAttributeNS(null, 'width', '28');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                txtRect.setAttributeNS(null, 'fill', '#7EC291');
                                txtRect.setAttributeNS(null, 'border', '1px solid red');
                                txtRect.setAttributeNS(null, 'cursor', 'pointer');
                                txtRect.setAttributeNS(null, 'timeFlag', 'false');
                                txtRect.setAttributeNS(null, 'opacity', 0);
                                document.getElementById('canvasElement').appendChild(txtRect);
                                tmp1++;
                        }
                        }




                        var tmp = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        var rect = document.createElementNS(svgns, 'rect');
                                //rect.setAttributeNS(null,"id","myRect_"+tmp);
                                rect.setAttributeNS(null, 'x', x);
                                rect.setAttributeNS(null, 'y', y);
                                rect.setAttributeNS(null, 'height', '22');
                                rect.setAttributeNS(null, 'width', '28');
                                //rect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                //rect.setAttributeNS(null, 'fill', '#7EC291');
                                rect.setAttributeNS(null, 'fill', '#ececec');
                                rect.setAttributeNS(null, 'border', '1px solid red');
                                rect.setAttributeNS(null, 'cursor', 'pointer');
                                rect.setAttributeNS(null, 'opacity', 1);
                                rect.setAttributeNS(null, 'flag', 0);
                                document.getElementById('canvasElement').appendChild(rect);
                                tmp++;
                        }
                        }




                        var tmp3 = 1

                                for (var x = 100; x < 800; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        var rect = document.createElementNS(svgns, 'rect');
                                rect.setAttributeNS(null, "id", "myRect_" + tmp3);
                                rect.setAttributeNS(null, 'x', x);
                                rect.setAttributeNS(null, 'y', y);
                                rect.setAttributeNS(null, 'height', '22');
                                rect.setAttributeNS(null, 'width', '28');
                                //rect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                rect.setAttributeNS(null, 'fill', '#FF8F00');
                                rect.setAttributeNS(null, 'border', '1px solid red');
                                rect.setAttributeNS(null, 'cursor', 'pointer');
                                rect.setAttributeNS(null, 'opacity', 0);
                                rect.setAttributeNS(null, 'flag', 0);
                                rect.setAttributeNS(null, 'sflag', '0');
                                rect.setAttributeNS(null, 'mflag', 'false');
                                document.getElementById('canvasElement').appendChild(rect);
                                tmp3++;
                        }
                        }




                        var tmp5 = 1

                                for (var x = 5; x < 30; x += 30) {
                        for (var y = 105; y < 260; y += 25) {
                        var xmlns = "http://www.w3.org/2000/svg"
                                var elem = document.createElementNS(xmlns, 'text');
                                elem.setAttributeNS(null, "id", "myDay_" + tmp4);
                                elem.setAttributeNS(null, 'x', x);
                                elem.setAttributeNS(null, 'y', y);
                                elem.setAttributeNS(null, 'height', '22');
                                elem.setAttributeNS(null, 'width', '80');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                elem.setAttributeNS(null, 'fill', '#000000');
                                elem.setAttributeNS(null, 'border', '1px solid red');
                                elem.setAttributeNS(null, 'cursor', 'pointer');
                                elem.setAttributeNS(null, 'dayFlag', 'false');
                                elem.setAttributeNS(null, 'opacity', 1);
                                var lblText = document.createTextNode(day[tmp5 - 1]);
                                elem.append(lblText);
                                document.getElementById('canvasElement').appendChild(elem);
                                tmp5++;
                        }
                        }




                        var tmp4 = 1

                                for (var x = 5; x < 30; x += 30) {
                        for (var y = 85; y < 240; y += 25) {
                        //var xmlns = "http://www.w3.org/2000/svg"
                        var txtRect = document.createElementNS(svgns, 'rect');
                                txtRect.setAttributeNS(null, "id", "myDay_" + tmp4);
                                txtRect.setAttributeNS(null, 'x', x);
                                txtRect.setAttributeNS(null, 'y', y);
                                txtRect.setAttributeNS(null, 'height', '22');
                                txtRect.setAttributeNS(null, 'width', '80');
                                //txtRect.setAttributeNS(null, 'fill', '#'+Math.round(0xffffff * Math.random()).toString(16));
                                txtRect.setAttributeNS(null, 'fill', '#7EC291');
                                txtRect.setAttributeNS(null, 'border', '1px solid red');
                                txtRect.setAttributeNS(null, 'cursor', 'pointer');
                                txtRect.setAttributeNS(null, 'dayFlag', 'false');
                                txtRect.setAttributeNS(null, 'opacity', 0);
                                document.getElementById('canvasElement').appendChild(txtRect);
                                tmp4++;
                        }
                        }



                        showEvtData(null, null);
                                //$scope.populateChart();
                                //prepopulateData();

                        }

                        setTimeout(reSchdeule1, 0, false)
                        }

                $scope.chartInit();
                        function checkIfEveryDay(id) {
                        var rectNo = id.split('_')[1]
                                for (var i = 0; i < everyDay.length; i++) {
                        if (everyDay[i] == rectNo) {
                        //return i;
                        }
                        }
                        return null;
                        }

                function createSchedule(selected, schedule) {
                $scope.populateChart();
                }




                var resetFlag = 0

                        function showEvtData(evt, _this) {
                        for (var i = 1; i < 500; i++) {

                        var rectElement = document.getElementById('myRect_' + i);
                                if (rectElement) {

                        if (!rectElement.hasAttribute('sFlag')) {
                        rectElement.sFlag = '0'
                        }

                        console.log(rectElement.sFlag)
                                if (!rectElement.hasAttribute('mFlag')) {
                        rectElement.mFlag = '0'
                        }

                        rectElement.onmouseup = function (evt) {
                        var rectObj = evt.target;
                                var day = checkIfEveryDay(evt.target.id);
                                if (day == null) {

                        if (rectObj.style.opacity == 1) {
                        rectObj.style.opacity = 0;
                                rectObj.sflag = '0';
                        } else {

                        rectObj.style.opacity = 1;
                                rectObj.sflag = '1';
                        }

                        console.log(rectObj.id + " : " + rectObj.sflag)
                                createSchedule(evt.target.id);
                        } else {
                        var startLen = day * totalWeekDays;
                                var endLen = startLen + totalWeekDays;
                                for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1))
                                //console.log(dayElement.id)                                                                                                    
                                if (dayElement) {
                        if (dayElement.flag == 1) {
                        reset(dayElement)
                        } else {
                        reset1(dayElement)
                        }
                        if (dayElement.style.opacity == 1) {
                        dayElement.style.opacity = 0;
                        } else {
                        dayElement.style.opacity = 1;
                        }
                        }
                        }




                        createSchedule(evt.target.id, 'All');
                        }
                        }



                        }
                        }



                        for (var i = 1; i <= 7; i++) {

                        var weekElement = document.getElementById('myDay_' + i);
                                if (weekElement) {

                        if (weekElement.hasAttribute('dayFlag') == true) {
                        weekElement.dayFlag = 'false';
                        }

                        weekElement.onmouseup = function (evt) {
                        var _obj = evt.target;
                                var day = Number(evt.target.id.split('_')[1]);
                                var startLen = (day - 1) * totalWeekDays;
                                var endLen = day + totalWeekDays;
                                for (var i = 1; i <= 240; i++) {

                        var elmNo = day + ((i - 1) * totalWeekDays);
                                var dayElement = document.getElementById('myRect_' + elmNo);
                                if (dayElement) {

                        if (_obj.dayFlag == "false") {
                        dayElement.sflag = '2';
                        } else {

                        dayElement.sflag = '0';
                        }
                        }
                        }
                        for (var i = 1; i <= 240; i++) {
                        var elmNo = day + ((i - 1) * totalWeekDays);
                                var dayElement = document.getElementById('myRect_' + elmNo);
                                if (dayElement) {
                        if (dayElement.sflag == "2") {
                        dayElement.style.opacity = 1;
                        } else {
                        dayElement.style.opacity = 0;
                        }


                        }




                        }
                        if (_obj.dayFlag == "true") {
                        _obj.dayFlag = 'false';
                        } else {
                        _obj.dayFlag = 'true';
                        }
                        createSchedule(evt.target.id);
                        }
                        }
                        }
                        for (var i = 1; i <= 24; i++) {




                        var textElement = document.getElementById('myText_' + i);
                                if (textElement) {

                        if (textElement.hasAttribute('timeFlag') == true) {
                        textElement.timeFlag = 'false';
                        }

                        textElement.onmouseup = function (evt) {
                        var _obj = evt.target;
                                var day = evt.target.id.split('_')[1];
                                var startLen = (day - 1) * totalWeekDays;
                                var endLen = startLen + totalWeekDays;
                                for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1));
                                console.log(dayElement.id + " : " + dayElement.sflag + " : " + _obj.timeFlag)
                                if (_obj.timeFlag == "false") {
                        dayElement.sflag = '2';
                        } else {

                        dayElement.sflag = '0';
                        }
                        }
                        for (var i = startLen; i < endLen; i++) {
                        var dayElement = document.getElementById('myRect_' + (i + 1));
                                if (dayElement.sflag == "2") {
                        dayElement.style.opacity = 1;
                        } else {
                        dayElement.style.opacity = 0;
                        }




                        }
                        if (_obj.timeFlag == "true") {
                        _obj.timeFlag = 'false';
                        } else {
                        _obj.timeFlag = 'true';
                        }
                        createSchedule(evt.target.id);
                        }
                        }
                        }
                        }

                $scope.getTimePosition = function (_time) {
                for (var i = 0; i < timeArray.length; i++) {
                if (timeArray[i] == _time) {
                return i;
                }

                }




                }



                $scope.myTimer = function () {
                console.log($rootScope.chartArray)
                        for (var i = 0; i < $rootScope.chartArray.length; i++) {
                var rectElement = document.getElementById('myRect_' + $rootScope.chartArray[i]);
                        if (rectElement) {
                console.log(rectElement);
                        rectElement.style.opacity = 1;
                }
                }
                clearInterval(idInter);
                }
                var idInter = setInterval($scope.myTimer, 2000);
                        $scope.populateChart = function () {
                        $rootScope.adsetSchedule = [];
                                var scheduleArray = [];
                                for (var i = 1; i < 200; i++) {
                        var rectElement = document.getElementById('myRect_' + i);
                                if (rectElement) {
                        var obj = rectElement.id;
                                if (rectElement.style.opacity == 1) {
                        scheduleArray.push(obj);
                        }
                        }
                        }
                        var sTime = 0;
                                var eTime = 0;
                                angular.forEach(scheduleArray, function (value, key) {
                                var selectedNo = scheduleArray[key].split('_')[1];
                                        var selectedPosition = selectedNo / totalWeekDays;
                                        console.log('selected position ' + parseInt(selectedPosition));
                                        if (selectedNo % 7 == 0) {
                                selectedTime = timeArray[parseInt(selectedPosition) - 1];
                                } else {
                                selectedTime = timeArray[parseInt(selectedPosition)];
                                }
                                selectedDay = (parseInt(selectedPosition) * 7) - selectedNo;
                                        selectedDay = selectedDay * ( - 1);
                                        console.log('selected time ' + selectedTime);
                                        console.log('selected no ' + selectedNo);
                                        console.log('selected day ' + selectedDay);
                                        var tPosition = $scope.getTimePosition(selectedTime);
                                        tPosition = tPosition + 1;
                                        if (tPosition == 1) {
                                sTime = startTime;
                                        eTime = endTime;
                                } else {
                                sTime = endTime * (tPosition - 1);
                                        eTime = (endTime * tPosition);
                                }
                                console.log('start Time ' + sTime);
                                        console.log('end time ' + eTime);
                                        var arr = [];
                                        arr.push(selectedDay);
                                        var obj = {

                                        "start_minute": sTime,
                                                "end_minute": eTime,
                                                "days": arr
                                        }



                                $rootScope.adsetSchedule.push(obj);
                                });
                                console.log($rootScope.adsetSchedule);
                                day.push(day);
                                var obj = {

                                "start_minute": 0,
                                        "end_minute": 60,
                                        "days": day
                                };
                                $rootScope.chartChange = true;
                        }



                }
        ]);