dashboard.controller("campaigntemplateController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window','appSettings','globalData','netWorkData',
function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData) {
    var vm = this;
    var apiTPBase = appSettings.apiTPBase;
    var apiBase = appSettings.apiBase;
    vm.showDetails = true;
    vm.home = {}; 
    $scope.predicate = 'name';  
    $scope.reverse = true;  
    $scope.currentPage = 1; 
	$scope.formChangeCount0;
	$scope.overLay = false;
        $scope.gotoMyCampaign=function(){
            $state.go('app.parentcampaign');
        }
		var stateArray = [];
	    if($window.localStorage.getItem("marketingObjective") == "POST_ENGAGEMENT"){
            stateArray=["app.fbcampaigndetails","app.bypcampaignaudience","app.bypcampaignplan","app.bypcampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "PAGE_LIKES"){
            stateArray=["app.fbcampaigndetails","app.pypcampaignaudience","app.pypcampaignplan","app.pypcampaigncreative","app.fbcampaignsummary"];
        }
	   else if($window.localStorage.getItem("marketingObjective") == "REACH"){
            stateArray=["app.fbcampaigndetails","app.rpcampaignaudience","app.rpcampaignplan","app.rpcampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "BRAND_AWARENESS"){
            stateArray=["app.fbcampaigndetails","app.ibacampaignaudience","app.ibacampaignplan","app.ibacampaigncreative","app.fbcampaignsummary"];
        }
		
		else if($window.localStorage.getItem("marketingObjective") == "LINK_CLICKS"){
            stateArray=["app.fbcampaigndetails","app.spcampaignaudience","app.spcampaignplan","app.spcampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "APP_INSTALLS"){
            stateArray=["app.fbcampaigndetails","app.apinstcampaignaudience","app.apinstcampaignplan","app.apinstcampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "EVENT_RESPONSES"){
            stateArray=["app.fbcampaigndetails","app.eventscampaignaudience","app.eventscampaignplan","app.eventscampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "VIDEO_VIEWS"){
            stateArray=["app.fbcampaigndetails","app.videocampaignaudience","app.videocampaignplan","app.videocampaigncreative","app.fbcampaignsummary"];
        }		
		else if($window.localStorage.getItem("marketingObjective") == "LEAD_GENERATION"){
            stateArray=["app.fbcampaigndetails","app.leadscampaignaudience","app.leadscampaignplan","app.leadscampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "CONVERSIONS"){
            stateArray=["app.fbcampaigndetails","app.convcampaignaudience","app.convcampaignplan","app.convcampaigncreative","app.fbcampaignsummary"];
        }
		else if($window.localStorage.getItem("marketingObjective") == "OFFER_CLAIMS"){
            stateArray=["app.fbcampaigndetails","app.offerscampaignaudience","app.offerscampaignplan","app.offerscampaigncreative","app.fbcampaignsummary"];
        }
	
		
		
		
    //var stateArray=["app.campaigndetails","app.campaignaudience","app.campaignplan","app.campaigncreative","app.campaignsummary"]
	
	$scope.global = $rootScope;
	$scope.init = function(){		
		var today1 = new Date();
		var dd = today1.getDate();
		var mm = today1.getMonth()+1; //January is 0! 
		var yyyy = today1.getFullYear();
		if(dd<10){dd='0'+dd} 
		if(mm<10){mm='0'+mm} 
		today1 = yyyy+'-'+mm+'-'+dd; 
		var currentDate = new Date(today1);
		$scope.overLay = false;
		angular.element($('body').css("overflow-y", "scroll"))
		var campaignState = $window.localStorage.getItem("campaignState");
		$rootScope.formChangeCount=0;
		$scope.$watch('faceBookFormData',function(newValue, oldValue) {
			if(newValue != oldValue) {
				$rootScope.formChangeCount++;
				console.log('$rootScope.formChangeCount >> '+$rootScope.formChangeCount)
				if($rootScope.formChangeCount>1 && $window.localStorage.getItem("role") != 'Account'){
					$scope.overLay = true;
					$rootScope.freezeFlag=true;
				}				
			} else {
				console.log('form not changed');
			}
		},true);

		
		function checkNav(){
			angular.forEach($rootScope.campaignSteps, function(value, key){
				window.scrollTo(0, 0);
				//console.log($rootScope.campaignSteps);
				if($rootScope.campaignSteps[key] == true){
					angular.element($('menu'+(key+1)).addClass('addCursor'));
				} else {
					angular.element($('menu'+(key+1)).removeClass('removeCursor'));
					console.log('remove');
				}					
			});
		}
	
		var timer = setInterval(checkNav(), 500)
	
		$scope.navigateSteps = function(_this){
			/* var flag = $window.localStorage.getItem("isChildCampaignEdit")
			if(flag == "true"){
				console.log($window.localStorage.getItem("isChildCampaignEdit"))
				var keyVal = stateArray[_this-1].split('.')[1]
				console.log(stateArray[_this-1])
				$state.go(stateArray[_this-1]);
			} else {
				console.log($rootScope.campaignSteps[_this-1])
				if($rootScope.campaignSteps[_this-1]){
					$state.go(stateArray[_this-1]);
				}
			} */
			console.log($rootScope.campaignSteps[_this-1]);
			if($rootScope.campaignSteps[_this-1]){
				$window.localStorage.setItem("campaignState", 'edit');  
				$state.go(stateArray[_this-1]);
			}
			
			 
			//console.log(stateArray[_this-1])
			//$state.go(stateArray[_this-1]);
		}
		/*var planEndDate = $window.localStorage.getItem("planEndDate");
		if(planEndDate == "" || planEndDate == undefined || planEndDate == null){
			$rootScope.noEdit = true;
		}else if (($window.localStorage.getItem("role") == 'Account') || ($filter('date')(planEndDate,'yyyy-MM-dd') <= $filter('date')(today1,'yyyy-MM-dd'))){
			$rootScope.noEdit = true;
		}else if (($window.localStorage.getItem("role") != 'Account') && ($filter('date')(planEndDate,'yyyy-MM-dd') > $filter('date')(today1,'yyyy-MM-dd'))){
			$rootScope.noEdit = false;
		}*/
		
	}
	
    $scope.init();
}]);