dashboard.directive('fbdetailedTargeting',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
	return{
		restrict:'E',		
		transclude:true,			
		scope:{
			 campaignAudienceDTJSON:'=dtjson',
			 DetailedTargetingArr:'=targeting',
             DTselectionkey:'=selectionkey',
			 DTselection:'=selection',
			 demographicsArray:'=demographics',
			 interestsArray:'=interests',
			 behaviorsArray:'=behaviours'					 
		},	
		template:
		'<div class="detailed-right" >'+
				'<div class="detailed-input"> '+
	               '<input type="text" autocomplete="off" id="campaignAudienceDetailedTargeting" placeholder="Add demographics, interests or behaviours..." class="autosearch-txt-box unstyled dropdown-toggle" readonly />'+                    
                                    '<div class="browsebutton"><button ng-click="showDetailTargetingListing()" data-toggle="dropdown" list="DetailedTargetingList" ng-model="campaignAudienceDetailedTargeting" class="autosearch-txt-box unstyled dropdown-toggle btnBrowseTargeting" type="button">Browse</button>'
                                      + ' <div class="dropdown-menu" ng-hide="detailtargetinglisting" ng-click="$event.stopPropagation()">'                        
                                         + ' <ul ng-repeat="val in DetailedTargetingArr| filter : campaignAudienceDetailedTargeting" >'
                                                +'<li ng-click="sendDetailTargetingKey(val.Key)"> {{val.Value}}'
												+'<i class="fa fa-search" aria-hidden="true"></i> </li>'
                                           +'</ul>'
                                       +' </div> '
                                    +'</div>'
                                    +'<div id="collapseTargeting" class="dropdown-search" ng-if="detailtargetingsearch" ng-click="$event.stopPropagation()">'
                                        +'<div class="drop-list">'
                                            +'<i ng-click="showDetailTargeting()" class="fa">&#xf0d9;</i>'
                                           +' <input type="text" ng-model="campaignAudienceDetailedTargetingSearch" ng-if="showSearchKeyword" placeholder="{{SearchPlaceholder}}" autocomplete="off" class="autosearch-txt-box unstyled" ng-change="searchDetailTargeting(campaignAudienceDetailedTargetingSearch)">'
                                        +'</div>'
                                        +'<div class="drop-search" id="scroll">'
                                            +'<div ng-show="!DemographicChildLeafDetails.length">'
                                                +'<img alt="" src="images/Spinning-Loader.gif" class="ajax-loader"/>'
                                            +'</div>'
                                            +'<div ng-repeat="val in DemographicChildLeafDetails| filter: searchBy track by $index">'
                                                +'<div class="hd-detail" ng-click="DTtoggleSearchSelection(val.id, val.path, val.name, hdDetailedTargeting)">'
                                                    +'<div class="hd-detail1">'
                                                        +'<span ng-repeat="cval in val.path"><span ng-if="$index > 0"> / </span>{{cval}}'
														+'<span ng-if="hdDetailedTargeting == \'more\'"> / {{val.name}}'
														+'</span>'
														+'</span>'
                                                    +'</div>'
                                                    +'<div class="hd-detail2">'
                                                        +'<input type="checkbox" name="selectedDT[]" ng-checked="DTselectionkey.indexOf(val.id) > - 1" />'
                                                    +'</div>'
                                                +'</div>'
                                            +'</div>'
                                        +'</div>'
                                    +'</div>'
									+'</div>'
									+'</div>'	
							 +'<div>'                           
                            +'<div class="detail-prev">'
                               +'<span ng-hide="!DTselection.length">'
                                    +'<div class="detail-prev1" ng-repeat="val in DTselection track by $index" set-connector>'
                                        +'{{val.name}}'
                                        +'<a ng-click="removeDT(val.name, val.id)" ng-class="{\'avoid-clicks\':$root.noEdit}">'
                                            +'<i class="fa fa-trash" aria-hidden="true"></i></a>'                                        
                                   +' </div></span></div> </div>',	
                                               							
		link:function(scope,element,attr){	
	
	    scope.campaignAudienceDTJSON = [];
        scope.demographicsArray = [];
        scope.interestsArray = [];
        scope.behaviorsArray = [];
        scope.moreArray = [];
		scope.DemographicLeafDetails =[];
		scope.InterestsLeafDetails=[];
		scope.BehaviorsLeafDetails=[];
		scope.MoreLeafDetails=[];
		scope.DTselection=[];
		scope.DTselectionkey=[];		
        scope.campaignAudienceMoreDTJSON = [];
        scope.MobileKey = [];
        var camR = {};
        scope.campaignDetailedTargetingArr = [];
        scope.searchDemo = [];		
		scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        scope.$root.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
		scope.DetailedTargetingArr = JSON.parse($window.localStorage.getItem("detailedTargetingArr"));
	
		scope.showDetailTargetingListing = function(){
			scope.detailtargetinglisting = false;
			scope.detailtargetingsearch = false;
		};
    

		
		scope.init = function(){
			
			
		     //DEMOGRAPHIC LEAF DETAILS
			var demographicsPromise = [];
            var querystr1 = "search" + "?type=adTargetingCategory&class=demographics" + "&access_token=" + scope.$root.networkAccessToken;
            demographicsPromise.push(facebookGetPost.getfacebookgraph(querystr1).then(function (response) {
                scope.demographicsResponse = response.data.data;
            }));
			$q.all(demographicsPromise).finally(function(){
				if(scope.demographicsResponse){
					scope.DemographicLeafDetails =    scope.demographicsResponse;	
				}
				
			})

            //INTEREST LEAF DETAILS
			var interestPromise = [];
            var querystr2 = "search" + "?type=adTargetingCategory&class=interests" + "&access_token=" + scope.$root.networkAccessToken;
            interestPromise.push(facebookGetPost.getfacebookgraph(querystr2).then(function (response) {
                scope.interestResponse = response.data.data;
            }));
				$q.all(interestPromise).finally(function(){
				if(scope.interestResponse){
					scope.InterestsLeafDetails = scope.interestResponse;	
				}
				
			})

            //BEHAVIOURS LEAF DETAILS
			var behaviourPromise = [];
            var querystr3 = "search" + "?type=adTargetingCategory&class=behaviors" + "&access_token=" + scope.$root.networkAccessToken;
            behaviourPromise.push(facebookGetPost.getfacebookgraph(querystr3).then(function (response) {
                scope.behaviourResponse = response.data.data;
            }));
			$q.all(behaviourPromise).finally(function(){
				if(scope.behaviourResponse){
					scope.BehaviorsLeafDetails = scope.behaviourResponse;	
				}
				
			})

            //MORE LEAF DETAILS
			var moreleafpromise =[];
            var querystr4 = "act_" + scope.networkAdAccountId + "/targetingbrowse?access_token=" + scope.$root.networkAccessToken;
            moreleafpromise.push(facebookGetPost.getfacebookgraph(querystr4).then(function (response) {
                var MArray = $filter('filter')(response.data.data, function (d) {
                    return d.type === "user_adclusters";
                }, true);
                scope.moreLeafResponse = MArray;
				 scope.$root.progressLoader = "none";

            }));
			$q.all(moreleafpromise).finally(function(){
				if(scope.moreLeafResponse){
					scope.MoreLeafDetails = scope.moreLeafResponse;
									
				}
				
			})
		}	
		

	
		var w = angular.element($window);
        w.bind('click', function (e) {
            if (this) {
                setTimeout(scope.showWindowDetailTargetingListing, 50);
            }
        });

        scope.showWindowDetailTargetingListing = function () {
            scope.$apply(function () {
                scope.detailtargetinglisting = false;
                scope.detailtargetingsearch = false;
            });
        };
        scope.sendDetailTargetingKey = function (val) {
            $('.drop-search').show();
            $('.drop-list').show();
            $("#collapseTargeting").addClass('dropdown-search');
           scope.detailtargetinglisting = true;
            scope.detailtargetingsearch = true;
            scope.SearchPlaceholder = val;
            scope.hdDetailedTargeting = val;
            scope.DemographicChildLeafDetails = '';
            scope.showSearchKeyword = 1;		
            if (scope.hdDetailedTargeting == 'demographics') {
                scope.DemographicChildLeafDetails = scope.DemographicLeafDetails;
            } else if (scope.hdDetailedTargeting == 'interests') {
                scope.DemographicChildLeafDetails = scope.InterestsLeafDetails;
            } else if (scope.hdDetailedTargeting == 'behaviors') {
                scope.DemographicChildLeafDetails = scope.BehaviorsLeafDetails;
            } else if (scope.hdDetailedTargeting == 'more') {
                angular.forEach(scope.DemographicLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                angular.forEach(scope.InterestsLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                angular.forEach(scope.BehaviorsLeafDetails, function (value1, key1) {
                    angular.forEach(scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = scope.MoreLeafDetails.indexOf(value1.id);
                            scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                scope.DemographicChildLeafDetails = scope.MoreLeafDetails;
            };
        
            scope.searchDemo = scope.DemographicChildLeafDetails;
        };

		 scope.searchDetailTargeting = function (searchElement) {         
            searchElement = searchElement.toLowerCase();
            var arrTargeting = angular.copy(scope.searchDemo);
            if (searchElement != undefined && searchElement != "" && searchElement != 'undefined')
            {
                if (searchElement.length != 0) {
                    var array = angular.copy(arrTargeting);
                    scope.DemographicChildLeafDetails = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].name.toLowerCase().includes(searchElement))
                            scope.DemographicChildLeafDetails.push(array[i]);
                    }
                } else {
                    scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
                }
            } else {
                scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
            }             
       }

        // Detail targeting Search Toggle selection    
     scope.DTtoggleSearchSelection = function (DTSearchId, DTSearchPath, DTSearchName, hiddenname) {

            var dt_val = '';

            angular.forEach(DTSearchPath, function (val) {
                dt_val += val + ' / ';
            });
            var lnk_dtl = '';
            if (hiddenname == 'more') {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val + DTSearchName, 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            } else {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val.substr(0, dt_val.length - 2), 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            }

            var idx = scope.DTselection.indexOf(DTSearchPath);
            var idxx = scope.DTselectionkey.indexOf(DTSearchId);

            if (idxx > -1) {
                scope.DTselection.splice(idxx, 1);
                scope.DTselectionkey.splice(idxx, 1);				
                //console.log('hiddenname : '+hiddenname);
                if (hiddenname == 'demographics') {
                    scope.demographicsArray.splice(idxx, 1);
                } else if (hiddenname == 'interests') {
                    scope.interestsArray.splice(idxx, 1);
                } else if (hiddenname == 'behaviors') {
                    scope.behaviorsArray.splice(idxx, 1);
                } else if (hiddenname == 'more') {
                    scope.demographicsArray.splice(idxx, 1);
                }
                ;
                scope.campaignAudienceDTJSON={
                    "user_adclusters": scope.demographicsArray,
                    "interests": scope.interestsArray,
                    "behaviors": scope.behaviorsArray
                };
            } else {
                scope.DTselection.push(DTSearchPath);
                scope.DTselectionkey.push(DTSearchId);				
                if (hiddenname == 'demographics') {
                    var DKey = {"id": DTSearchId};
                    scope.demographicsArray.push(DKey);
                } else if (hiddenname == 'interests') {
                    var IKey = {"id": DTSearchId};
                    scope.interestsArray.push(IKey);
                } else if (hiddenname == 'behaviors') {
                    var BKey = {"id": DTSearchId};
                    scope.behaviorsArray.push(BKey);
                } else if (hiddenname == 'more') {
                    var MKey = {"id": DTSearchId};
                    scope.demographicsArray.push(MKey);
                }
                ;

                scope.campaignAudienceDTJSON={
                    "user_adclusters": scope.demographicsArray,
                    "interests": scope.interestsArray,
                    "behaviors": scope.behaviorsArray
                };
            }
			scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
           // scope.setLine();
        };
				
		 scope.$on('DTtoggleSearchSelection', function (event,args) {
			 console.log(args);
		  	scope.DTtoggleSearchSelection(args.id,args.path,args.name,args.rootpath);
		})
		 scope.showDetailTargeting = function () {
            scope.showSearchKeyword = 0;
            scope.campaignAudienceDetailedTargetingSearch = "";
            scope.detailtargetinglisting = false;
            scope.detailtargetingsearch = true;
            $('.drop-search').hide();
            $('.drop-list').hide();
            $('dropdown-menu').hide();
            $("#collapseTargeting").removeClass('dropdown-search');
            
        };
		    scope.removeDT = function (name, id) {
            var idx = scope.DTselectionkey.indexOf(id);
            scope.DTselectionkey.splice(idx, 1);
            var idxx = scope.DTselection.indexOf(name);
            scope.DTselection.splice(idx, 1);

            angular.forEach(scope.demographicsArray, function (val, key) {
                if (val.id == id) {
                    scope.demographicsArray.splice(key, 1);
                }
            });
            angular.forEach(scope.interestsArray, function (val, key) {
                if (val.id == id) {
                    scope.interestsArray.splice(key, 1);
                }
            });
            angular.forEach(scope.behaviorsArray, function (val, key) {
                if (val.id == id) {
                    scope.behaviorsArray.splice(key, 1);
                }
            });
            scope.campaignAudienceDTJSON={
                "user_adclusters": scope.demographicsArray,
                "interests": scope.interestsArray,
                "behaviors": scope.behaviorsArray
            };
            scope.$root.freezeFlag = true;
            scope.$root.overLayAudience = true;
            //scope.setLine();
        };

		
		scope.init();
		}
		//controller:'',
		//bindToController:true,
	}
	
}])
 