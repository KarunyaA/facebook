dashboard.factory('facebookGetPost', ['$http', '$q','$timeout', 'catalyst', 'httpApi', '$rootScope','appSettings', 'transformData', function($http, $q, $timeout, catalyst, httpApi, $rootScope, appSettings, transformData) {
    var obj = {};
    var baseUrl = catalyst.serviceUrl1;
	var baseUrl2 = catalyst.serviceUrl2;
	var apiTPBase = appSettings.apiTPBase;
    var apiBase = appSettings.apiBase;
	var apiTwitterBase = appSettings.apiTwitterBase;
	
    obj.isLocal = false;
    var _config = {};
    _config.cache = 'false';
    _config.async = 'false';
	 
	 //----------------------------------------------get API----------------------------------------------------------------	 
	obj.readadcampaign = function(_queryStr, _parameters){
	    var url = apiTPBase+"/readadcampaign"+_queryStr;
        return httpApi.get(url, _parameters);
    }

	obj.getcampaignbycampaignid = function(_queryStr, _parameters){
		var url = apiTPBase+"/getcampaignbycampaignid"+_queryStr;
        return httpApi.get(url, _parameters);
    }
	
	obj.demographictargetingsearch = function(_queryStr, _parameters){
		var url = apiTPBase+"/demographictargetingsearch"+_queryStr;
        return httpApi.get(url, _parameters);
    }
		
	obj.fetchuserpromotablepages = function(_queryStr, _parameters){
		var url = apiTPBase+"/fetchuserpromotablepages"+_queryStr;
        return httpApi.get(url, _parameters);
    }
	obj.getaccounttargetingbrowse = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getaccounttargetingbrowse"+_queryStr; 
		return httpApi.get(url, _parameters);
	}
	obj.getadaccountadspixels = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadaccountadspixels"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.getoffersinpage = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getoffersinpage"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.getuserpromotedconnections = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getuserpromotedconnections"+_queryStr;
		return httpApi.get(url, _parameters);
	}	
	obj.readadset = function(_queryStr, _parameters){
		var url = apiTPBase+ "/readadset"+_queryStr;    
		return httpApi.get(url, _parameters);
	}		
	obj.targetingsearchadlocale = function(_queryStr, _parameters){
		var url = apiTPBase+ "/targetingsearchadlocale"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.getadset = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadset"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.getfbuserid = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getfbuserid"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.readadaccounts = function(_queryStr, _parameters){
		var url = apiTPBase+ "/readadaccounts"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.fetchuserpromotablepages = function(_queryStr, _parameters){
		var url = apiTPBase+ "/fetchuserpromotablepages"+_queryStr;    
		return httpApi.get(url, _parameters);
	}	
	obj.getad = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getad"+_queryStr;    
		return httpApi.get(url, _parameters);
	}

	obj.getadaccountsadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadaccountsadcreative"+_queryStr;   
		return httpApi.get(url, _parameters);
	}	
		
	obj.getadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadcreative"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	obj.getadimages = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadimages"+_queryStr;    
		return httpApi.get(url, _parameters);
	}
	
	obj.getadsetadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadsetadcreative"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
	
	obj.getadvideos = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getadvideos"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
	
	obj.getfbpreview = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getfbpreview"+_queryStr;   
		return httpApi.get(url, _parameters);
	}
        
	obj.getleadgenforms = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getleadgenforms"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.getoffersinpage = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getoffersinpage"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.getpagefeed = function(_queryStr, _parameters){
		var url = apiTPBase+ "/getpagefeed"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.readadadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/readadadcreative"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.readaddata = function(_queryStr, _parameters){
		var url = apiTPBase+ "/readaddata"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.saveadadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveadadcreative"+_queryStr;   
		return httpApi.get(url, _parameters);
	}

	obj.saveaddata = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveaddata"+_queryStr;   
		return httpApi.get(url, _parameters);
	}	
	obj.getfacebookgraph = function(_queryStr){
		//var url = "https://graph.facebook.com/v2.10/"+_queryStr;
        var url =  apiTPBase+ "/getaccounttargetingbrowse" +_queryStr; 
		return httpApi.get(url);
	}
	obj.getfacebookgraph1 = function(_queryStr){
		var url = "https://graph.facebook.com/v2.10/"+_queryStr;
        //var url =  apiTPBase+ "/getaccounttargetingbrowse" +_queryStr; 
		return httpApi.get(url);
	}
	obj.getdemographics = function(_queryStr){
		var url =  apiTPBase+ "/targetingsearchbehavior" +_queryStr; 
		//var url = "https://graph.facebook.com/v2.10/"+_queryStr;   
		return httpApi.get(url);
	} 
	obj.getcreativeid = function(_queryStr){
			var url = apiTPBase+ "/readaddata"+_queryStr; 
			return httpApi.get(url);
	} 
	obj.fetchpagetabs = function(_queryStr){
			var url = apiTPBase+ "/fetchpagetabs"+_queryStr;   
			return httpApi.get(url);
     }


	//----------------------------------------------post API----------------------------------------------------------------
	obj.createcampaign = function(_queryStr, _parameters){
		var url = apiTPBase+ "/createcampaign";    
		return httpApi.post(url, _parameters);
	}
	obj.savecampaigndata = function(_queryStr, _parameters){
		var url = apiTPBase+ "/savecampaigndata";    
		return httpApi.post(url, _parameters);
	}	
	obj.updatecampaign = function(_queryStr, _parameters){
		var url = apiTPBase+ "/updatecampaign";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.createadset = function(_queryStr, _parameters){
		var url = apiTPBase+ "/createadset";    
		return httpApi.post(url, _parameters);
	}
	
	obj.saveadsetdata = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveadsetdata";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.updateadset = function(_queryStr, _parameters){
		var url = apiTPBase+ "/updateadset";    
		return httpApi.post(url, _parameters);
	}	
	obj.createad = function(_queryStr, _parameters){
		var url = apiTPBase+ "/createad";    
		return httpApi.post(url, _parameters);
	}	
	obj.createadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/createadcreative";    
		return httpApi.post(url, _parameters);
	}
	
	obj.createadslideshow = function(_queryStr, _parameters){
		var url = apiTPBase+ "/createadslideshow";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.saveadadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveadadcreative";    
		return httpApi.post(url, _parameters);
	}	
	obj.saveaddata = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveaddata";    
		return httpApi.post(url, _parameters);
	}	
	
	obj.updatead = function(_queryStr, _parameters){
		var url = apiTPBase+ "/updatead";    
		return httpApi.post(url, _parameters);
	}
	
	obj.saveaddatapost = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveaddata";    
		return httpApi.post(url, _parameters);
	}              

	obj.saveadsetadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/saveadsetadcreative";    
		return httpApi.post(url, _parameters);
	} 
	
	  //----------------------------------POST API for Image/Video Upload ----------------------------------------
	obj.createadimage = function(_queryStr, _parameters,headers){
		var url = apiTPBase+ "/createadimage";    
		return transformData.uploadFileToUrl(url, _parameters,headers);
	} 
	
	obj.createadvideo = function(_queryStr, _parameters, headers){
		var url = apiTPBase+ "/createadvideo";    
		return transformData.uploadFileToUrl(url, _parameters, headers);
	}
        //----------------------------------------------Delete API----------------------------------------------------------------
	obj.deletead = function(_queryStr, _parameters){
		var url = apiTPBase+ "/deletead"+_queryStr;;    
		return httpApi.delete(url, _parameters);
	}

	obj.deleteadcreative = function(_queryStr, _parameters){
		var url = apiTPBase+ "/deleteadcreative"+_queryStr;;    
		return httpApi.delete(url, _parameters);
	}
	
    return obj;
}]); 
