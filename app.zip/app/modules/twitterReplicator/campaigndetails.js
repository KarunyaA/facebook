var replicatorApp = angular.module('replicator', ['app']);
replicatorApp.controller("twitterreplicatorcampaigndetailsController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'twitterGetPost', 'apiService', '$q', 'globalData', '$timeout', 'parser',
    function ($rootScope, $scope, $state, catalyst, $location, Flash, $window, $http, $filter, $compile, appSettings, twitterGetPost, apiService, $q, globalData, $timeout, parser) {
        var vm = this;
        vm.getData = {};
        vm.setSet = {};

        //FOR LEFT STEP LINE JOINING
        var wholedivheight = angular.element('#firstdiv').height() + angular.element('#seconddiv').height() + angular.element('#lastdiv').height();
        var bottomfinalval = angular.element('#lastdiv').height() - angular.element('#lasttopdiv').height();
        var reduceval = angular.element('#firsttopdiv').height() + bottomfinalval;
        $scope.dynamicheight = wholedivheight - reduceval;


        $scope.firstActiveDiv = 'yes';
        $scope.firstActiveDivImg = false;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.fundingSourceData = [];
        var apiTPBase = appSettings.apiTwitterBase;
        var apiTwitterBase = appSettings.apiTwitterBase
        vm.showDetails = true;
        $scope.campaignplan = [];
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.objective = ''; //Test variable, Not needed remove this decularation
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};

        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        $rootScope.replicationCycle = true;
        $scope.readTwLineItem = function () {
            var promises = [];
            var header = {
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            };
            queryStr = "campaignId=" + $window.localStorage.getItem('twCampaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId");
            var module = apiTwitterBase + "/readlineitems" + "?" + queryStr;
            promises.push(apiService.getTwitterPoint(module, header).then(function (response) {

                if (response.appStatus == '0') {
                    console.log(response);
                    //$rootScope.progressLoader = "none";
                    $rootScope.campaignSteps[1] = true;
                    $rootScope.campaignSteps[2] = true;
                    var jsonObj = response.lineItems;
                    console.log(jsonObj);
                    angular.forEach(jsonObj, function (value, key) {
                        var JsonObj = jsonObj[key];
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i)) {
                                array[+i] = JsonObj[i];
                                $window.localStorage.setItem("marketingObjective", array[+i].twLineItemDetails.objective);
                                $window.localStorage.setItem("lineItemid", array[+i].twLineItemId);
                                vm.getData.objective = array[+i].twLineItemDetails.objective
                            }
                        }
                    });
                } else {
                    /* if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                     $window.localStorage.setItem("TokenExpired", true);
                     $state.go('login');
                     } else {
                     $rootScope.progressLoader = "none";
                     $scope.editAdsetErrorMsg = 'block';
                     if (response.networkError != '' && response.networkError != undefined) {
                     if (response.networkError.message != '' && response.networkError.message != undefined) {
                     $scope.errorpopupHeading = 'Error';
                     $scope.errorMsg = response.networkError.message;
                     } else {
                     $scope.errorpopupHeading = response.networkError.error_user_title;
                     $scope.errorMsg = response.networkError.error_user_msg;
                     }
                     } else {
                     $scope.errorpopupHeading = 'Error';
                     $scope.errorMsg = response.errorMessage;
                     }
                     } */
                }
            }));
            $q.all(promises).finally(
                    function () {
                        console.log(promises);
                    }
            );

        }
        $scope.getCampaignDetails = function () {
            $scope.campaignData = JSON.parse($window.localStorage.getItem("twitterReplicatorData"));

            angular.forEach($scope.campaignData[0], function (value, key) {

                vm.getData.fundingInstrumentsId = $scope.campaignData[0][key].twFundingInstrumentId;
                vm.getData.campaignName = $scope.campaignData[0][key].twCampaignDetails.name + ' - Copy';

            });

            angular.forEach($scope.campaignData[1], function (value, key) {

                vm.getData.objective = $scope.campaignData[1][key].twLineItemDetails.objective;
                angular.element('.market-objective').css('pointer-events', 'none');

            });
        }
        $scope.readlineitems = function (readcampaignResponse) { //edit mode
            var promises = [];
            $rootScope.progressLoader = "block";
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "campaignId=" + $window.localStorage.getItem("twCampaignId");
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            promises.push(twitterGetPost.readlineitems(queryStr, data).then(function (response) {
                $rootScope.progressLoader = "none";
                if (response.data.appStatus == 0) {
                    $scope.readlineitemsResponse = response;
                    console.log($scope.readlineitemsResponse);
                    angular.forEach($scope.readlineitemsResponse.data.lineItems[0], function (value, key) {
                        vm.getData.objective = value.twLineItemDetails.objective;
                    });
                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
        }
        $scope.init = function () {
            $timeout(function () {
                angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            }, 1500);
            if ($window.localStorage.getItem("campaignState") != "edit" && $rootScope.sameNetwork == false) {
                console.log('Inside twitther replicator flow');
                $scope.progressLoader = "none";
                //console.log(objectiveMapping);
                console.log("************************** Final parsed data from facebook *******************************************************");
                console.log($rootScope.fieldMapping);

                console.log("*************************************************************************************");
                //vm.getData.objective = $rootScope.twcampaignObjective;
                //vm.getData.campaignName = $rootScope.twitterFieldMapping.campaign_name;
                vm.getData.objective = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'objective');
                vm.getData.campaignName = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'campaign_name') + ' - Copy';
                angular.element('#firstdiv').css("pointer-events", "none");

            } else {
                $scope.getCampaignDetails();
            }
            $rootScope.twitterFormData = vm.getData;
            $scope.todayDate = new Date();
            $scope.minDate = new Date();
            //$window.localStorage.setItem("campaignState", "edit");
            $scope.campaignState = $window.localStorage.getItem("campaignState");
//            if ($scope.campaignState == "edit") {
//                $scope.getCampaignDetails();
//			}

        }


        $scope.fundingSourceData = [];
        $scope.readAdFundingInstruments = function () {
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId");
            twitterGetPost.readadfundinginstruments(queryStr, data).then(function (response) {
                console.log(response);
                if (response.data.appStatus == '0') {
                    var jsonObj = response.data.fundingInstruments;
                    if (jsonObj) {
                        angular.forEach(jsonObj, function (value, key) {
                            var JsonObj = jsonObj[key];
                            var array = [];
                            for (var i in JsonObj) {
                                if (JsonObj.hasOwnProperty(i)) {
                                    array[+i] = JsonObj[i];
                                    //console.log(array[+i]);
                                    // $scope.fundingInstruments = array[+i];
                                    $scope.fundingSourceData.push(array[+i]);
                                    //  $window.localStorage.setItem("fundingInstrumentsId", $scope.fundingSourceData.twFundingInstrumentDetails.id);

                                }
                            }
                            //console.log($scope.fundingSourceData);
                        });
                    } else {
                        $scope.popupTitle = "Error";
                        $scope.popupMessage = "Funding instrument details are empty";
                        $scope.showPopup();
                    }
                } else {
                    $scope.popupTitle = "Error";
                    $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.error_user_msg;
                    $scope.showPopup();
                }
            })

        }

        $scope.readAdFundingInstruments();

        $scope.$watch('vm.getData.fundingInstrumentsId', function (newVal, oldVal) {

            if (newVal) {
                console.log('changed campaignName')
                $window.localStorage.setItem("tempfundingInstrumentsId", newVal);
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                angular.element('#step3').css('background-color', '#95D2B1');
            } else {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step3').css('background-color', '#C2C2C2');
            }
        }, true)

        $scope.$watch('vm.getData.objective', function (newVal, oldVal) {

            if (newVal) {
                console.log('changed objective')
                $window.localStorage.setItem("marketingObjective", newVal);
                angular.element('#step1').css('background-color', '#95D2B1');

                angular.element('.is-div-disabled').css('opacity', 1);
                angular.element('.is-div-disabled').css('pointer-events', 'auto');
            }
        }, true)


        $scope.$watch('vm.getData.campaignName', function (newVal, oldVal) {

            if (newVal) {
                console.log('changed campaignName')
                $window.localStorage.setItem("tempCampaignName", newVal);
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                angular.element('#step2').css('background-color', '#95D2B1');
            } else {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step2').css('background-color', '#C2C2C2');
            }
        }, true)

        $scope.objectiveChange = function () {
            if ($window.localStorage.getItem("campaignState") != "create") {
                $rootScope.freezeFlag = true;
            }
        }
        $scope.nameChange = function () {
            if ($window.localStorage.getItem("campaignState") != "create") {
                $rootScope.freezeFlag = true;
            }
        }
        $scope.fundInsChange = function () {
            if ($window.localStorage.getItem("campaignState") != "create") {
                $rootScope.freezeFlag = true;
            }
        }
        $scope.cancelButtonClicked = function () {
            $rootScope.stopReplication = "flex";
            $rootScope.stopReplicationFrom = "cancelButton";
        };
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }

        $scope.gototwitterCampaignaudience = function () {
            // $state.go('app.twittercampaignaudience');
        }

//        vm.createCampaignObjective = function(cData) {
//            $rootScope.progressLoader = "block";
//            $scope.isDirty = $scope.vm.createCampaignForm.$dirty;
//            console.log(cData);
//            if ($scope.isDirty) {
//                //---------------------------
//                $rootScope.freezeFlag = false;
//                //---------------------------
//
//                if (cData.objective == undefined) {
//                    alert('Please Select Marketing Objective');
//                    return true;
//                }
//                if ($window.localStorage.getItem("campaignState") != "create") {
//                    $scope.editAndUpdateCampaignDetails(cData);
//                } else {
//                    var data = {
//                        'userId': $window.localStorage.getItem("userId"),
//                        'accessToken': $window.localStorage.getItem("accessToken")
//                    };
//                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId");
//                    twitterGetPost.readadfundinginstruments(queryStr, data).then(function(response) {
//                        console.log(response);
//                        if (response.data.appStatus == '0') {
//                            var jsonObj = response.data.fundingInstruments;
//                            if (jsonObj) {
//                                angular.forEach(jsonObj, function(value, key) {
//                                    var JsonObj = jsonObj[key];
//                                    var array = [];
//                                    for (var i in JsonObj) {
//                                        if (JsonObj.hasOwnProperty(i)) {
//                                            array[+i] = JsonObj[i];
//                                            $scope.fundingInstruments = array[+i];
//                                            $window.localStorage.setItem("fundingInstrumentsId", $scope.fundingInstruments.twFundingInstrumentDetails.id);
//                                            $scope.createNewCampaign(cData, $scope.fundingInstruments.twFundingInstrumentDetails.id);
//                                           $scope.moveNextStep();
//                                        }
//                                    }
//                                });
//                            } else {
//                                $scope.popupTitle = "Error";
//                                $scope.popupMessage = "Funding instrument details are empty";
//                                $scope.showPopup();
//                            }
//                        } else {
//                            $scope.popupTitle = "Error";
//                            $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.error_user_msg;
//                            $scope.showPopup();
//                        }
//                    })
//                }
//            } else {
//                $scope.moveNextStep();
//            }
//        };

        $scope.createNewCampaign = function (data, _id) {
            console.log(data)
            //$scope.isDirty = $scope.vm.createCampaignForm.$dirty;
            $rootScope.progressLoader = "block";
            $scope.progressLoader = "block";

            //$scope.moveNextStep();

            //  var date = new Date();
            //var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
           

                $rootScope.freezeFlag = false;

                if ($window.localStorage.getItem("campaignState") == "create") {
                    $scope.editAndUpdateCampaignDetails(data);
                } else {
                    $scope.currentDate = new Date();
                    $scope.currentDateVal = $filter('date')(Date.parse($scope.currentDate), 'yyyy-MM-dd');
                    $scope.currentTimeVal = $filter('date')(Date.parse($scope.currentDate), 'HH:mm:ss');
                    $scope.scheduleDate = $scope.currentDateVal + " " + $scope.currentTimeVal;
                    $scope.startDateTime = new Date($scope.scheduleDate).toISOString();
                    $scope.startDateTime = $scope.startDateTime.replace(".000", '');


                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken"),
                        "userNetworkMapId": $window.localStorage.getItem("twUserNetworkMapId"),
                        "adAccountId": $window.localStorage.getItem("twNetworkAdAccountId"),
                        "name": data.campaignName,
                        "fundingInstrumentId": vm.getData.fundingInstrumentsId,
                        "startTime": $scope.startDateTime,
                        "entityStatus": "PAUSED"
                    };



                    twitterGetPost.createcampaign("", data).then(function (response) {
                        console.log(response);
                        if (response.data.appStatus == 0) {
                            //$rootScope.progressLoader = "none";
                            $window.localStorage.setItem("twCampaignId", response.data.campaign.id);
                            $rootScope.campaignSteps[0] = true;
                            getCampaignDetailsFromTW(response.data.campaign.id);
                            globalData.setLocal("campaign", response.data.campaign.id, response.data)
                        } else {
                            $scope.popupTitle = "Error";
                            if (response.data.networkError) {
                                $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError[0].message;
                                $scope.showPopup();
                            } else {
                                $scope.popupMessage = response.data.errorMessage;
                                $scope.showPopup();
                            }


                        }
                    })
                }
            
        };

        $scope.editAndUpdateCampaignDetails = function (data) {
            console.log(data)
            var date = new Date();
            var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": $window.localStorage.getItem("twUserNetworkMapId"),
                "adAccountId": $window.localStorage.getItem("twNetworkAdAccountId"),
                "name": data.campaignName,
                "campaignId": $window.localStorage.getItem("twCampaignId")
            };
            $scope.isDirty = $scope.vm.createCampaignForm.$dirty;
            //console.log(cData);                                    
            if ($scope.isDirty) {
                twitterGetPost.updatecampaign("", data).then(function (response) {
                    console.log(response);
                    if (response.data.appStatus == 0) {
                        $window.localStorage.setItem("twCampaignId", response.data.campaign.id);
                        $rootScope.campaignSteps[0] = true;
                        getCampaignDetailsFromTW(response.data.campaign.id);
                    } else {
                        $scope.popupTitle = "Error";
                        $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError[0].message;
                        $scope.showPopup();
                    }
                })
            } else {
                $scope.moveNextStep();
            }
        }

        function getCampaignDetailsFromTW(campaignId) {

            var queryStr = "?campaignIds=" + $window.localStorage.getItem('twCampaignId') + "&userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&adAccountId=" + $window.localStorage.getItem('twNetworkAdAccountId');
            twitterGetPost.getcampaignforaccount(queryStr, "").then(function (response) {
                if (response.data.appStatus == '0') {
                    saveCampaignDataToLocalDB(response.data.campaign, $window.localStorage.getItem('twCampaignId'));

                } else { // failed

                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.popupTitle = "Error";
                            $scope.popupMessage = response.data.errorMessage + '. ' + response.data.networkError.error_user_msg;
                            $scope.showPopup();
                        } else {
                            $scope.popupTitle = "Error";
                            $scope.popupMessage = response.data.errorMessage;
                            $scope.showPopup();
                        }
                    }
                }
            });
        }

        function saveCampaignDataToLocalDB(response, campaignId) {
            console.log(response[0][campaignId]);
            var networkMapId = $window.localStorage.getItem("twUserNetworkMapId");
            var sTime = response.start_time;

            var parameters = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken"),
                "userNetworkMapId": networkMapId,
                "parentCampaignId": $window.localStorage.getItem("parentCampaignId"),
                "adAccountId": response[0][campaignId].account_id,
                "campaignId": campaignId,
                "campaignDetails": response[0][campaignId]
            }
            twitterGetPost.savecampaign("", parameters).then(function (response) {
                angular.element($('body').css("overflow-y", "scroll"))
                if (response.data.appStatus == '0') {
                    $rootScope.progressLoader = "none";
                    $scope.progressLoader = "none";
                    $scope.moveNextStep();

                } else {
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    ;
                    $scope.popupTitle = "Save Failed";
                    $scope.popupMessage = "Save campaign failed";
                    $scope.showPopup();
                }
            });

        }

        $scope.moveNextStep = function () {
            $rootScope.campaignSteps = [true, false, false, false, false];
            if ($window.localStorage.getItem("marketingObjective") == "TWEET_ENGAGEMENTS") {
                $state.go('app.twReplicatorEngCampaignaudience');
            } else if ($window.localStorage.getItem("marketingObjective") == "WEBSITE_CLICKS") {
                $state.go('app.twReplicatorWebCampaignAudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "VIDEO_VIEWS") {
                $state.go('app.twReplicatorVideoViewsAudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "FOLLOWERS") {
                $state.go('app.twReplicatorFollowersCampaignAudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "AWARENESS") {
                $state.go('app.twReplicatorAwCampaignaudience');
            }
            else if ($window.localStorage.getItem("marketingObjective") == "APP_INSTALLS") {
                $state.go('app.twReplicatorAppCampaignaudience');
            }
        }
        $scope.init();
        $scope.showPopup = function () {
            $rootScope.progressLoader = "none";
            angular.element($('body').css("overflow-y", "scroll"))

            var modalApproveReq = $(".update_modalApprove"); // Get the modal Approve req
            modalApproveReq.show();
        }

        var modalSuccessPop = $(".success-popup"); // Get the modal Success req
        $scope.successPopup = function () {
            modalSuccessPop.show();
        }
        $scope.closeSuccessPopup = function () {
            modalSuccessPop.hide();
        }


    }
]);