var replicatorApp = angular.module('replicator', ['app']);
replicatorApp.controller("twReplicatorFollowersCampaignPlanController", ['$rootScope', '$scope', '$state', 'catalyst', '$location', 'accountDashBoardGetPost', 'Flash', '$window', '$http', '$filter', '$compile', 'appSettings', 'twitterGetPost', '$q', 'globalData', '$timeout', '$interval', 'parser',
    function ($rootScope, $scope, $state, catalyst, $location, accountDashBoardGetPost, Flash, $window, $http, $filter, $compile, appSettings, twitterGetPost, $q, globalData, $timeout, $interval, parser) {
        var baseUrl = catalyst.serviceUrl1;
        var baseUrl2 = catalyst.serviceUrl2;
        var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        $scope.thirdActiveDiv = 'yes';
        $scope.firstActiveDivImg = true;
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = true;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $rootScope.progressLoader = "block";
        var vm = this;
        vm.getData = {};
        vm.showDetails = true;
        $scope.campaignPlanForm = {}
        $scope.campaignplan = [];
        $scope.campaignplanObj = {}
        $scope.campaignPlanCurrency = {};
        $scope.campaignPlanBudget = {};
        $scope.campaignPlanSchedule = {};
        $scope.budgetValue = "";
        $scope.todayDate = new Date();
        $scope.startDate = new Date();
        $scope.endDate = new Date();
        vm.home = {};
        $scope.disabled = true;
        $scope.isDisable = true;
        $scope.showText = false;
        $scope.advancedOption = false;
        $scope.impressions = false;
        $scope.runAdverts = false;
        $scope.deliveryType = false;
        $scope.autoBid = false;
        $scope.setDate = false;
        $scope.localAwareness = false;
        $scope.showAdvanced = true;
        $scope.disableDIV = false;
        $scope.showChart = false;
        $scope.autoBid = false;
        $scope.targetcost = false;
        $scope.adv1 = false;
        $scope.pac = false;
        $scope.adv2 = false;
        $scope.normal = true;
        $scope.defaultpricing = "1";
        $scope.pacing = false;
        $scope.campaignPlanForm.budget = 1;
        $scope.date_time1 = true;
        $scope.date_time2 = true;
        $scope.date_time3 = true;
        $scope.date_time4 = true;
        $scope.date_time = true;
        $scope.sec1 = false;
        $scope.sec2 = true;
        //boolean for updated screen
        $scope.target_cost = false
        $scope.priceBidType = "1";
        $scope.defaultpricing2 = "1";
        $scope.defaultpricing1 = "1";
        $scope.defaultpricing = "1";
        $scope.defaultpricingforwebsite_conversions = "1";
        $scope.followers = false;
        $scope.tweet_engagements = false;
        $scope.awareness = false;
        $scope.dropdown_for_auto_bid = "1";
        $scope.video_views = false;
        $scope.per_3video = false;
        $scope.website_visits = false;
        $scope.lead_generation = false;
        $scope.app_installs = false;
        $scope.conversions = false;
        $scope.targetcostforconversions = true;
        $scope.dateLen = 200;
        $scope.plan_radio = 1;
        $scope.priceItemValue = 0;
        $scope.changedpricing = false;
        $scope.changedpricevalue = false;
        $scope.selectSchedule = {};

        $scope.checkMandatoryVal = function () {
            var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
            if ($scope.endDateValue == undefined || $scope.endDateValue == "" || $scope.endDateValue == null || (Date.parse(currentDate) >= Date.parse(parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'schedule_end')))) {
                angular.element('#endate').addClass("mandatory");
                angular.element('#endtime').addClass("mandatory");
            } else {
                angular.element('#endate').removeClass("mandatory");
                angular.element('#endtime').removeClass("mandatory");
            }
        };

        $scope.setLine = function () {
            var everythingLoaded = setInterval(function () {
                if (/loaded|complete/.test(document.readyState)) {
                    clearInterval(everythingLoaded);
                    $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                    $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                    var offsetHeight2 = document.getElementById('step1container').offsetHeight;
                    var fStep = $(".vr");
                    fStep.css('height', (($scope.lsValue - $scope.fsValue - 25)));

                }
            }, 10);
        };

        $scope.openAdvancedOption = function () {
            if ($scope.conversions)
            {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step1').css('background-color', '#C2C2C2');

            }
            $scope.advancedOption = true;
            $scope.adv1 = true;
            $scope.normal = false;
            $scope.advertSchedule = true;
            $scope.pacing = false;
            $scope.setLine();
        }

        //function for TWEET_ENGAGEEMNTS dropdown    
        $scope.selectPricing_for_tweetonload = function (value) {
            if (value == null) {
            } else {
                if (value == 1) {
                    if (vm.getData.dailyBudget) {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                    } else {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#C2C2C2');
                    }
                    $scope.target_cost = false;
                    $scope.max_bid_normal = false;
                    $scope.target_cost = false;
                    $scope.adv1 = true;
                    $scope.adv2 = false;
                    $scope.pac = false;
                    $scope.normal = false;
                    $scope.pacing = false;
                    $scope.plan_radio = 0;


                } else if (value == 2) {
                    // alert($scope.priceItemValue);
                    $scope.priceBidType = "2";
                    if ($scope.priceItemValue && vm.getData.dailyBudget) {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                    } else {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#C2C2C2');
                    }
                    $scope.target_cost = true;
                    $scope.max_bid_normal = false;
                    $scope.adv1 = false;
                    $scope.adv2 = true;
                    $scope.pac = false;
                    $scope.normal = false;
                    $scope.targetcost = false;
                    $scope.pacing = false;
                    $scope.plan_radio = 1;

                } else if (value == 3) {
                    // alert($scope.priceItemValue);
                    if ($scope.priceItemValue) {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                    } else {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#C2C2C2');
                    }
                    $scope.target_cost = false;
                    $scope.max_bid_normal = true;
                    $scope.adv1 = false;
                    $scope.adv2 = true;
                    $scope.pac = false;
                    $scope.normal = false;
                    $scope.targetcost = false;
                    $scope.pacing = false;
                    $scope.plan_radio = 1;
                }
                $scope.setLine();

            }

        }



        $scope.pacingOptions = function () {
            $scope.adv1 = false;
            $scope.adv2 = false;
            $scope.pac = true;
            $scope.normal = false;
            $scope.pacing = true;
            $scope.setLine();
        }

        $scope.readcampaign = function () {

            $scope.campaignData = JSON.parse($window.localStorage.getItem("twitterReplicatorData"));
            console.log($scope.campaignData[0]);

            angular.forEach($scope.campaignData[0], function (value, key) {
                vm.getData.dailyBudget = $scope.campaignData[0][key].twCampaignDetails.daily_budget_amount_local_micro;
                angular.element('#step1').css('background-color', '#95D2B1');
                if ($scope.campaignData[0][key].twCampaignDetails.total_budget_amount_local_micro != "" && $scope.campaignData[0][key].twCampaignDetails.total_budget_amount_local_micro != null && $scope.campaignData[0][key].twCampaignDetails.total_budget_amount_local_micro != undefined) {
                    vm.getData.totalBudget = $scope.campaignData[0][key].twCampaignDetails.total_budget_amount_local_micro;
                }

                if ($scope.campaignData[0][key].twCampaignDetails.start_time != "" && $scope.campaignData[0][key].twCampaignDetails.start_time != null && $scope.campaignData[0][key].twCampaignDetails.start_time != undefined && $scope.campaignData[0][key].twCampaignDetails.end_time != "" && $scope.campaignData[0][key].twCampaignDetails.end_time != null && $scope.campaignData[0][key].twCampaignDetails.end_time != undefined) {
                    // $scope.sDate = new Date($scope.campaignData[0][key].twCampaignDetails.start_time);
                    $scope.eDate = new Date($scope.campaignData[0][key].twCampaignDetails.end_time);
                    $scope.selectSchedule.isActive = "2";
                    $scope.showChart = true;
                } else {
                    $scope.selectSchedule.isActive = "1";
                    $scope.showChart = false;
                }


                console.log('into pacing');
                console.log($scope.campaignData[0][key].twCampaignDetails.standard_delivery);
                if ($scope.campaignData[0][key].twCampaignDetails.standard_delivery == true) {
                    $scope.plan_radio = '1';
                } else {
                    $scope.plan_radio = '2';
                    $scope.pacingOptions();
                }

            });



            angular.forEach($scope.campaignData[1], function (value, key) {

                if ($scope.campaignData[1][key].twLineItemDetails.bid_type == "AUTO") {
                    console.log('into auto');
                    $timeout(function () {
                        $scope.priceBidType = "1";
                        $scope.openAdvancedOption();
                    }, 100);
                } else if ($scope.campaignData[1][key].twLineItemDetails.bid_type == "TARGET") {
                    console.log('into max');
                    $timeout(function () {
                        $scope.priceBidType = "2";
                        console.log($scope.priceBidType);
                        $scope.selectPricing_for_tweetonload($scope.priceBidType);
                    }, 100);
                    $scope.priceItemValue = $scope.campaignData[1][key].twLineItemDetails.bid_amount_local_micro;
                    $scope.openAdvancedOption();
                }

                if ($scope.campaignData[1][key].twLineItemDetails.optimization == "DEFAULT")
                {
                    $scope.radioTarget = "1";
                } else if ($scope.campaignData[1][key].twLineItemDetails.optimization == "ENGAGEMENT")
                {
                    $scope.radioTarget = "2";
                }


            });
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            $scope.setLine();
        }
        $scope.readlineitems = function (readcampaignResponse) {//edit mode
            var promises = [];
            $rootScope.progressLoader = "block";
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "campaignId=" + $window.localStorage.getItem("twCampaignId");
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            promises.push(twitterGetPost.readlineitems(queryStr, data).then(function (response) {
                $scope.readlineitemsFlag;
                if (response.data.appStatus == 0) {
                    $scope.readlineitemsFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.readlineitemsResponse = response;
                    angular.forEach($scope.readlineitemsResponse.data.lineItems[0], function (value, key) {
                        if (value.twLineItemDetails.bid_type == 'AUTO') {
                            $scope.priceBidType = "1";
                        } else if (value.twLineItemDetails.bid_type == 'TARGET') {
                            $scope.priceBidType = "2";
                        }
                        if (value.twLineItemDetails.bid_type != 'AUTO') {
                            $scope.openAdvancedOption();
                            $scope.selectPricing_for_tweetonload($scope.priceBidType);
                            $scope.priceItemValue = value.twLineItemDetails.bid_amount_local_micro;
                        }
                        $window.localStorage.setItem("lineItemid", value.twLineItemId);
                    });
                    angular.forEach(readcampaignResponse.data.campaign[0], function (value, key) {
                        if (value.twCampaignDetails.standard_delivery) {
                            $scope.plan_radio = '1';
                        } else {
                            $scope.plan_radio = '2';
                            $scope.pacingOptions();
                        }
                    });
                    //console.log(response);

                } else {
                    $scope.readlineitemsFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.readlineitemsFlag == "0") {
                    if ($scope.readlineitemsFlag == "0") {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#95D2B1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element($('.cd-btnConfirm').prop('disabled', false));
                    } else {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                        angular.element('#step2').css('background-color', '#95D2B1');
                        angular.element($('.cd-btnConfirm').prop('disabled', true));
                    }
                }
            });
        }

        $scope.onDateChange2 = function (sdate, edate) {
            $scope.endDate = edate;

            //alert("edate : "+edate);
            //alert("edate : "+etime);

            if (edate == null || edate == "" || edate == "undefined" || sdate == null || sdate == "" || sdate == "undefined" || $scope.vm.getData.dailyBudget == "" || $scope.vm.getData.dailyBudget == undefined) {
                //$scope.date_time = false;
                // $scope.checkEnable();
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element($('.cd-btnConfirm').prop('disabled', true));
                angular.element('#endate').addClass("mandatory");
                angular.element('#endtime').addClass("mandatory");
                $scope.datetimevalidation(sdate, edate);
            } else {
                //$scope.datetimevalidation(edate, etime, sdate, stime);
                angular.element('.is-btn-disabled').css('opacity', 1);
                angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element($('.cd-btnConfirm').prop('disabled', false));
                angular.element('#endate').removeClass("mandatory");
                angular.element('#endtime').removeClass("mandatory");
                $scope.datetimevalidation(sdate, edate);
            }
        }
        $scope.checkEnable = function () {
            if ($scope.date_time == true)
            {
                $scope.sec2 = true;
                angular.element('.cd-btnConfirm').css('opacity', 1);
                angular.element('.cd-btnConfirm').css('pointer-events', 'auto');
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#endate').removeClass("mandatory");
                angular.element('#endtime').removeClass("mandatory");
                angular.element($('.cd-btnConfirm').prop('disabled', false));
            } else
            {
                $scope.sec2 = false;
                angular.element('#step2').css('background-color', '#C2C2C2');
                angular.element('#endate').addClass("mandatory");
                angular.element('#endtime').addClass("mandatory");
                angular.element($('.cd-btnConfirm').prop('disabled', true));
                angular.element('.cd-btnConfirm').css('opacity', 0.9);
                angular.element('.cd-btnConfirm').css('pointer-events', 'none');
            }
        }
        $scope.datetimevalidation = function (sdate, edate)
        {
            $scope.crcted = edate;
            $scope.crctst = sdate;
            if ($scope.crcted == "" || $scope.crcted == undefined || $scope.crcted == null) {
                $scope.eDate = "";
                $scope.date_time = false;
                $scope.checkEnable();
            } else {
                if ($scope.crcted > $scope.crctst)
                {
                    $window.localStorage.setItem("scheduleStartDate", $scope.crctst)
                    $window.localStorage.setItem("scheduleEndDate", $scope.crcted)
                    $scope.date_time = true;
                    $scope.checkEnable();
                } else
                {
                    $scope.date_time = false;
                    $scope.checkEnable();
                }
            }
        }

        $scope.init = function () {
            $rootScope.twitterFormData = vm.getData;
            $scope.todayDate = new Date();
            $scope.minDate = new Date();
            $scope.changedpricing = false;
            $scope.campaignplan.accountCountryName = "India"
            $scope.campaignplan.currency = "Indian Rupee"
            $scope.campaignplan.description = "Asia/Kolkata"
            $scope.campaignplan.adAccName = "Digi Live"
            $scope.campaignplan.advertSetName = "createAdsetTest1"
            $scope.marketingObjective = $window.localStorage.getItem("marketingObjective");
            if ($scope.marketingObjective == "FOLLOWERS") {
                $scope.followers = true;
            }
            if ($scope.marketingObjective == "TWEET ENGAGEMENTS") {
                $scope.tweet_engagements = true;
            }
            if ($scope.marketingObjective == "AWARENESS") {
                $scope.awareness = true;
            }
            if ($scope.marketingObjective == "VIDEO_VIEWS") {
                $scope.video_views = true;
            }
            if ($scope.marketingObjective == "WEBSITE_VISITS") {
                $scope.website_visits = true;
            }
            if ($scope.marketingObjective == "LEAD_GENERATION") {
                $scope.lead_generation = true;
            }
            if ($scope.marketingObjective == "CANVAS_APP_INSTALLS") {
                $scope.app_installs = true;
            }
            if ($scope.marketingObjective == "CONVERSIONS") {
                $scope.conversions = true;
            }
            var tdy = new Date();
            $scope.todaydate = tdy.getFullYear() + '-' + ('0' + (tdy.getMonth())).slice(-2) + '-' + ('0' + tdy.getDate()).slice(-2);
            $scope.formattedstartdate = $filter('date')(new Date($scope.todayDate), 'dd-mm-yyyy HH:mm:ss');
            var sttime = $scope.formattedstartdate.split(" ")[1];
            var stdy = $scope.todaydate.concat(" ");
            var std = stdy.concat(sttime);
            $window.localStorage.setItem("scheduleStartDate", std)
            $window.localStorage.setItem("scheduleEndDate", std)
            $rootScope.progressLoader = "none";
            angular.element('.cd-btnConfirm').prop('disabled', false);

            if ($window.localStorage.getItem("campaignState") == "edit") {
                angular.element('.is-btn-disabled').css('opacity', 0.9);
                angular.element('.is-btn-disabled').css('pointer-events', 'none');
                angular.element('#step1').css('background-color', '#95D2B1');
                angular.element('#step2').css('background-color', '#95D2B1');
                $scope.readcampaign();
            }

            if ($window.localStorage.getItem("campaignState") != "edit" && $rootScope.sameNetwork == false) {
                $scope.dailyBudgetValue = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'daily_budget');
                $scope.totalBudgetValue = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'lifetime_budget');

                $scope.startDateValue = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'schedule_start');
                $scope.endDateValue = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'schedule_end');
                console.log($scope.endDateValue);
                //$scope.endDateValue = "2017-10-04T11:56:33+0530";                
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.sDate = new Date(currentDate);
                if ($scope.endDateValue != "") {
                    $scope.eDate = new Date($scope.endDateValue);
                    $scope.selectSchedule.isActive = "2";
                    $scope.showChart = true;
                    if ($scope.eDate > $scope.sDate)
                    {
                        $scope.date_time = true;
                        $scope.checkEnable();
                    } else
                    {
                        $scope.date_time = false;
                        $scope.eDate = "";
                        $scope.checkEnable();
                    }
                } else {
                    $scope.selectSchedule.isActive = "1";
                    $scope.showChart = false;
                }
                console.log('inside replicator plan page');
                if ($scope.dailyBudgetValue != '' && $scope.dailyBudgetValue != undefined && $scope.dailyBudgetValue > 0) {
                    //vm.getData.dailyBudget = $scope.dailyBudgetValue;
                    vm.getData.dailyBudget = $scope.dailyBudgetValue;
                    console.log($scope.dailyBudgetValue);
                    angular.element('#step1').css('background-color', '#95D2B1');
                } else if ($scope.dailyBudgetValue == 0) {
                    $scope.userSuggestionDailyBudget = true;
                    //angular.element('#step1').css('background-color', '#95D2B1');
                    console.log($scope.dailyBudgetValue);
                }

                if ($scope.totalBudgetValue != '' && $scope.totalBudgetValue != undefined && $scope.totalBudgetValue > 0) {
                    vm.getData.totalBudget = $scope.totalBudgetValue;
                    //vm.getData.dailyBudget = $scope.dailyBudgetValue;
                    //$scope.userSuggestionTotalBudget = true;
                    //console.log($scope.totalBudgetValue);
                }
                /*else{
                 
                 console.log($scope.totalBudgetValue);
                 }*/

                /* if ($scope.endDateValue != '' && $scope.endDateValue != undefined) {
                 console.log($scope.endDateValue);			
                 $scope.eDate = new Date($scope.endDateValue);
                 console.log('converted value--'+$scope.eDate);
                 angular.element('#step2').css('background-color', '#95D2B1');
                 $scope.selectSchedule.isActive = "2";
                 $scope.selectSchedule($scope.selectSchedule.isActive);
                 
                 }  */

                $scope.checkMandatoryVal();
            } else {
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.sDate = new Date(currentDate);
                $scope.readcampaign();
            }


        }
        $scope.init();
        $scope.updateCampaign = function (cData) {
            angular.element('#step2').css('background-color', '#95D2B1');
            angular.element('#step1').css('background-color', '#95D2B1');
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            $scope.totalBudget = vm.getData.totalBudget ? vm.getData.totalBudget : 0;
            if ($scope.selectSchedule.isActive == "1") {
                $scope.currentDate = new Date();
                $scope.currentDateVal = $filter('date')(Date.parse($scope.currentDate), 'yyyy-MM-dd');
                $scope.currentTimeVal = $filter('date')(Date.parse($scope.currentDate), 'HH:mm:ss');
                $scope.scheduleDate = $scope.currentDateVal + " " + $scope.currentTimeVal;
                $scope.startDateTime = new Date($scope.scheduleDate).toISOString();
                $scope.startDateTime = $scope.startDateTime.replace(".000", '');
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    "dailyBudgetAmountLocalMicro": vm.getData.dailyBudget,
                    "totalBudgetAmountLocalMicro": $scope.totalBudget,
                    "endTime": "null"
                };
            } else {
                $scope.startDate = $filter('date')(Date.parse($scope.sDate), 'yyyy-MM-dd');
                $scope.endDate = $filter('date')(Date.parse($scope.eDate), 'yyyy-MM-dd');
                $scope.startTime = $filter('date')($scope.sDate, 'HH:mm:ss');
                $scope.endTime = $filter('date')($scope.eDate, 'HH:mm:ss');
                $scope.scheduleStart = $scope.startDate + " " + $scope.startTime;
                $scope.startDateTime = new Date($scope.scheduleStart).toISOString();
                $scope.startDateTime = $scope.startDateTime.replace(".000", '');
                $scope.scheduleEnd = $scope.endDate + " " + $scope.endTime;
                $scope.endDateTime = new Date($scope.scheduleEnd).toISOString();
                $scope.endDateTime = $scope.endDateTime.replace(".000", '');


                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    "dailyBudgetAmountLocalMicro": vm.getData.dailyBudget,
                    "totalBudgetAmountLocalMicro": $scope.totalBudget,
                    "endTime": $scope.endDateTime
                };
            }
            if ($scope.priceBidType == "2") {
                if ($scope.plan_radio == "1") {
                    data.standardDelivery = true;
                } else {
                    data.standardDelivery = false;
                }
            }
            promises.push(twitterGetPost.updatecampaign("", data).then(function (response) {
                $scope.updateCampaignFlag;
                if (response.data.appStatus == 0) {
                    $scope.updateCampaignFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.updateCampaignResponse = response;
                } else {
                    $scope.updateCampaignFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.updateCampaignFlag == "0") {
                    $scope.getCampaign($scope.updateCampaignResponse);
                }
            });

        }
        $scope.getCampaign = function (updateCampaignResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "campaignIds=" + $window.localStorage.getItem("twCampaignId");
            promises.push(twitterGetPost.getcampaignforaccount(queryStr, data).then(function (response) {
                $scope.getCampaignFlag;
                if (response.data.appStatus == 0) {
                    $scope.getCampaignFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.getCampaignDetailsResponse = response;
                } else {
                    $scope.getCampaignFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.getCampaignFlag == "0") {
                    $scope.saveCampaign($scope.getCampaignDetailsResponse.data.campaign);
                }
            });

        }

        $scope.saveCampaign = function (getCampaignDetailsResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'parentCampaignId': $window.localStorage.getItem("parentCampaignId"),
                'campaignId': $window.localStorage.getItem("twCampaignId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'campaignDetails': getCampaignDetailsResponse[0][$window.localStorage.getItem("twCampaignId")]
            };
            promises.push(twitterGetPost.savecampaign("", data).then(function (response) {
                $scope.saveCampaignFlag;
                if (response.data.appStatus == 0) {
                    $scope.saveCampaignFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.saveCampaignDetailsResponse = response;
                } else {
                    $scope.saveCampaignFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.saveCampaignFlag == "0") {
                    if ($window.localStorage.getItem("campaignState") == "edit") {
                        console.log($scope.changedpricing);
                        if ($scope.changedpricing || $scope.changedpricevalue)
                        {
                            $scope.updatelineitems($scope.saveCampaignDetailsResponse);
                        } else
                        {
                            //no line item changes has been made , so no need to call update line item 
                            if ($window.localStorage.getItem("campaignAudienceJSON") != "") {
                                console.log("##########" + $window.localStorage.getItem("existingTargetingCriteriaArray"));
                                $scope.campaignAudienceJSON = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
                                if ($window.localStorage.getItem("existingTargetingCriteriaArray") != "" && $window.localStorage.getItem("existingTargetingCriteriaArray") != null && $window.localStorage.getItem("existingTargetingCriteriaArray") != undefined) {
                                    console.log("@@@@@@@@@@@@");
                                    $scope.existingTargetingCriteriaArray = JSON.parse($window.localStorage.getItem("existingTargetingCriteriaArray"));
                                    $scope.deletetargetingcriteria($scope.existingTargetingCriteriaArray);
                                }
                                /*if ($window.localStorage.getItem("deleteLanguage") != "" && $window.localStorage.getItem("deleteLanguage") != null && $window.localStorage.getItem("deleteLanguage") != undefined) {
                                 console.log("@@@@@@@@@@@@");
                                 $scope.existingTargetingCriteriaArray = JSON.parse($window.localStorage.getItem("deleteLanguage"));
                                 console.log($scope.existingTargetingCriteriaArray);
                                 $scope.deletetargetingcriteria($scope.existingTargetingCriteriaArray);
                                 }*/
                                //alert($scope.campaignAudienceJSON.events);
                                if ($window.localStorage.getItem("campaignAudienceJSON") != '' && $window.localStorage.getItem("campaignAudienceJSON") != null && $window.localStorage.getItem("campaignAudienceJSON") != undefined)
                                {
                                    if ($scope.campaignAudienceJSON.events != "") {
                                        $scope.createaccounttargetingcriteria($scope.campaignAudienceJSON.events);
                                    }
                                    $scope.puttargetingcriteria();
                                } else {
                                    $scope.moveNextStep();
                                }

                            } else {
                                $scope.moveNextStep();
                            }
                        }

                    } else {
                        $scope.createlineitems($scope.saveCampaignDetailsResponse);
                    }
                }
            });

        }

        $scope.createlineitems = function (saveCampaignDetailsResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            $scope.campaignAudienceJSONPlacements = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
            if ($scope.priceBidType == "1") {
                $scope.paramBidType = "AUTO";
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    'productType': 'PROMOTED_ACCOUNT', //temp fixie
                    'entityStatus': "PAUSED",
                    'objective': $window.localStorage.getItem("marketingObjective"),
                    "placements": $scope.campaignAudienceJSONPlacements.placements,
                    "bidType": "AUTO"
                };
            } else if ($scope.priceBidType == "2") {
                $scope.paramBidType = "TARGET";
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    'productType': 'PROMOTED_ACCOUNT', //temp fixie
                    'entityStatus': "PAUSED",
                    'objective': $window.localStorage.getItem("marketingObjective"),
                    "placements": $scope.campaignAudienceJSONPlacements.placements,
                    "bidType": "TARGET",
                    "bidAmountLocalMicro": $scope.priceItemValue
                };
            }
            promises.push(twitterGetPost.createlineitems("", data).then(function (response) {
                $scope.createlineitemsFlag;
                if (response.data.appStatus == 0) {
                    $scope.createlineitemsFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.createlineitemsResponse = response;
                    $window.localStorage.setItem("lineItemid", response.data.lineItems.id);
                } else {
                    $scope.createlineitemsFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.createlineitemsFlag == "0") {
                    $scope.getlineitems($scope.createlineitemsResponse);
                }
            });

        }

        $scope.updatelineitems = function (saveCampaignDetailsResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            $scope.campaignAudienceJSONPlacements = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
            if ($scope.priceBidType == "1") {
                $scope.paramBidType = "AUTO";
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'lineItemId': $window.localStorage.getItem("lineItemid"),
                    //'productType' : 'PROMOTED_TWEETS',//temp fixie
                    'entityStatus': "PAUSED",
                    //'objective': $window.localStorage.getItem("marketingObjective"),
                    //"placements" : $scope.campaignAudienceJSONPlacements.placements,
                    "bidType": "AUTO",
                    "bidAmountLocalMicro": 0
                };
            } else if ($scope.priceBidType == "2") {
                $scope.paramBidType = "TARGET";
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                    'lineItemId': $window.localStorage.getItem("lineItemid"),
                    //'productType' : 'PROMOTED_TWEETS',//temp fixie
                    'entityStatus': "PAUSED",
                    //'objective': $window.localStorage.getItem("marketingObjective"),
                    // "placements" : $scope.campaignAudienceJSONPlacements.placements,
                    "bidType": "TARGET",
                    "bidAmountLocalMicro": $scope.priceItemValue
                };
            }
            promises.push(twitterGetPost.updatelineitems("", data).then(function (response) {
                $scope.updatelineitemsFlag;
                if (response.data.appStatus == 0) {
                    $scope.updatelineitemsFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.updatelineitemsResponse = response;
                    //$window.localStorage.setItem("lineItemid",response.data.lineItems.id);
                } else {
                    $scope.updatelineitemsFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.updatelineitemsFlag == "0") {
                    $scope.getlineitems($scope.updatelineitemsResponse);
                }
            });

        }

        $scope.getlineitems = function (createlineitemsResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "lineItemIds=" + $window.localStorage.getItem("lineItemid");
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            promises.push(twitterGetPost.getlineitems(queryStr, data).then(function (response) {
                $scope.getlineitemsFlag;
                if (response.data.appStatus == 0) {
                    $scope.getlineitemsFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.getlineitemsResponse = response;
                } else {
                    $scope.getlineitemsFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.getlineitemsFlag == "0") {
                    $scope.savelineitem($scope.getlineitemsResponse);
                }
            });

        }

        $scope.savelineitem = function (getlineitemsResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";


            $rootScope.freezeFlag = false;
            var data = {};
            angular.forEach(getlineitemsResponse.data.lineItems[0], function (value, key) {
                data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken"),
                    'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                    'campaignId': $window.localStorage.getItem("twCampaignId"),
                    'lineitemId': $window.localStorage.getItem("lineItemid"),
                    'lineitemDetails': value
                };
            });
            promises.push(twitterGetPost.savelineitem("", data).then(function (response) {
                $scope.savelineitemFlag;
                if (response.data.appStatus == 0) {
                    $scope.savelineitemFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.savelineitemResponse = response;
                } else {
                    $scope.savelineitemFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.savelineitemFlag == "0") {
                    if ($window.localStorage.getItem("campaignAudienceJSON") != "") {
                        $scope.campaignAudienceJSON = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
                        if ($window.localStorage.getItem("existingTargetingCriteriaArray") != "" && $window.localStorage.getItem("existingTargetingCriteriaArray") != null && $window.localStorage.getItem("existingTargetingCriteriaArray") != undefined) {
                            $scope.existingTargetingCriteriaArray = JSON.parse($window.localStorage.getItem("existingTargetingCriteriaArray"));
                            $scope.deletetargetingcriteria($scope.existingTargetingCriteriaArray);
                        }
                        //alert($scope.campaignAudienceJSON.events);
                        if ($window.localStorage.getItem("campaignAudienceJSON") != '' && $window.localStorage.getItem("campaignAudienceJSON") != null && $window.localStorage.getItem("campaignAudienceJSON") != undefined)
                        {
                            if ($scope.campaignAudienceJSON.events != "") {
                                $scope.createaccounttargetingcriteria($scope.campaignAudienceJSON.events);
                            }
                            $scope.puttargetingcriteria();
                        } else {
                            $scope.moveNextStep();
                        }
                    } else {
                        $scope.moveNextStep();
                    }
                }
            });

        }


        $scope.createaccounttargetingcriteria = function (events) {
            var promises = [];
            $rootScope.progressLoader = "block";


            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                'targetingType': "EVENT",
                'targetingValue': events
            };
            promises.push(twitterGetPost.createaccounttargetingcriteria("", data).then(function (response) {
                $scope.createaccounttargetingcriteriaFlag;
                if (response.data.appStatus == 0) {
                    $scope.createaccounttargetingcriteriaFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.createaccounttargetingcriteriaResponse = response;
                } else {
                    $scope.createaccounttargetingcriteriaFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.createaccounttargetingcriteriaFlag == "0") {
                    //$scope.puttargetingcriteria($scope.createaccounttargetingcriteriaResponse);
                }
            });


        }
        $scope.deletetargetingcriteria = function (existingTargetingCriteriaArray) {
            var promises = [];
            $rootScope.progressLoader = "block";
            $rootScope.freezeFlag = false;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            // $scope.existingTargettingCriteriaIDs = JSON.parse($window.localStorage.getItem("existingTargetingCriteriaArray"));

            //console.log($scope.existingTargettingCriteriaIDs);

            angular.forEach(existingTargetingCriteriaArray, function (val, key) {
                console.log(key);
                console.log(val);
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&" + "targetingCriteriaId=" + val;
                promises.push(twitterGetPost.deletetargetcriteria(queryStr, data).then(function (response) {
                    $scope.deletetargetcriteriaFlag;
                    if (response.data.appStatus == 0) {
                        $scope.deletetargetcriteriaFlag = "0";
                        $rootScope.progressLoader = "none";
                        $scope.deletetargetcriteriaResponse = response;
                    } else {
                        $scope.deletetargetcriteriaFlag = "1";
                        if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                    $scope.errorpopupHeading = 'Error';
                                    $scope.errorMsg = response.data.networkError.message;
                                } else {
                                    if (response.data.networkError.error_user_title) {
                                        $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                        $scope.errorMsg = response.data.networkError.error_user_msg;
                                    } else {
                                        $scope.errorpopupHeading = "Error";
                                        $scope.errorMsg = response.data.networkError[0].message;
                                    }
                                }
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                }));



            });
            $q.all(promises).finally(function () {
                if ($scope.deletetargetcriteriaFlag == "0") {
                    $scope.saveCampaign($scope.deletetargetcriteriaResponse);
                    $scope.campaignAudienceJSON = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
                    $scope.createaccounttargetingcriteria($scope.campaignAudienceJSON.events);
                    //$scope.puttargetingcriteria();
                }
            });
        }
        $scope.puttargetingcriteria = function () {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            $scope.campaignAudienceJSON = JSON.parse($window.localStorage.getItem("campaignAudienceJSON"));
            //console.log($scope.campaignAudienceJSON);
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'adAccountId': $window.localStorage.getItem("twNetworkAdAccountId"),
                'lineItemId': $window.localStorage.getItem("lineItemid"),
                "gender": $scope.campaignAudienceJSON.gender,
            };
            if ($scope.campaignAudienceJSON.interests != "") {
                data.interests = $scope.campaignAudienceJSON.interests;
            }
            if ($scope.campaignAudienceJSON.tvShows != "") {
                data.tvShows = $scope.campaignAudienceJSON.tvShows;
            }
            if ($scope.campaignAudienceJSON.behaviors != "") {
                data.behaviors = $scope.campaignAudienceJSON.behaviors;
            }
            if ($scope.campaignAudienceJSON.locations != "") {
                data.locations = $scope.campaignAudienceJSON.locations;
            }
            if ($scope.campaignAudienceJSON.ageBuckets != "") {
                data.ageBuckets = $scope.campaignAudienceJSON.ageBuckets;
            }
            if ($scope.campaignAudienceJSON.languages != "") {
                data.languages = $scope.campaignAudienceJSON.languages;
            }
            if ($scope.campaignAudienceJSON.devices != "") {
                data.devices = $scope.campaignAudienceJSON.devices;
            }
            if ($scope.campaignAudienceJSON.platforms != "") {
                data.platforms = $scope.campaignAudienceJSON.platforms;
            }
            if ($scope.campaignAudienceJSON.platformVersions != "") {
                data.platformVersions = $scope.campaignAudienceJSON.platformVersions;
            }
            if ($scope.campaignAudienceJSON.networkOperators != "") {
                data.networkOperators = $scope.campaignAudienceJSON.networkOperators;
            }
            if ($scope.campaignAudienceJSON.networkActivationDurationIt != "") {
                data.networkActivationDurationIt = $scope.campaignAudienceJSON.networkActivationDurationIt;
            }
            if ($scope.campaignAudienceJSON.networkActivationDurationGte != "") {
                data.networkActivationDurationGte = $scope.campaignAudienceJSON.networkActivationDurationGte;
            }
            if ($scope.campaignAudienceJSON.negativeBehaviors != "") {
                data.negativeBehaviors = $scope.campaignAudienceJSON.negativeBehaviors;
            }
            promises.push(twitterGetPost.puttargetingcriteria("", data).then(function (response) {
                $scope.puttargetingcriteriaFlag;
                if (response.data.appStatus == 0) {
                    $scope.puttargetingcriteriaFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.puttargetingcriteriaResponse = response;
                } else {
                    $scope.puttargetingcriteriaFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.puttargetingcriteriaFlag == "0") {
                    $scope.getaccounttargetingcriteria($scope.puttargetingcriteriaResponse);
                }
            });

        }

        $scope.getaccounttargetingcriteria = function (getaccounttargetingcriteria) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "lineItemId=" + $window.localStorage.getItem("lineItemid") + "&adAccountId=" + $window.localStorage.getItem("twNetworkAdAccountId") + "&withDeleted=true";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            promises.push(twitterGetPost.getaccounttargetingcriteria(queryStr, data).then(function (response) {
                $scope.getaccounttargetingcriteriaFlag;
                if (response.data.appStatus == 0) {
                    $scope.getaccounttargetingcriteriaFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.getaccounttargetingcriteriaResponse = response;
                } else {
                    $scope.getaccounttargetingcriteriaFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.getaccounttargetingcriteriaFlag == "0") {
                    $scope.savetargetingcriteria($scope.getaccounttargetingcriteriaResponse);
                }
            });

        }

        $scope.savetargetingcriteria = function (getaccounttargetingcriteriaResponse) {
            var promises = [];
            $rootScope.progressLoader = "block";

            $rootScope.freezeFlag = false;

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken"),
                'userNetworkMapId': $window.localStorage.getItem("twUserNetworkMapId"),
                'lineitemId': $window.localStorage.getItem("lineItemid"),
                'targetingCriteriaDetails': getaccounttargetingcriteriaResponse.data.accountTargetingCriteria
            };
            promises.push(twitterGetPost.savetargetingcriteria("", data).then(function (response) {
                $scope.savetargetingcriteriaFlag;
                if (response.data.appStatus == 0) {
                    $scope.savetargetingcriteriaFlag = "0";
                    $rootScope.progressLoader = "none";
                    $scope.savetargetingcriteriaResponse = response;
                } else {
                    $scope.savetargetingcriteriaFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                } else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }

            }));
            $q.all(promises).finally(function () {
                if ($scope.savetargetingcriteriaFlag == "0") {
                    $scope.moveNextStep();
                }
            });



        }

        $scope.readtargetingcriteria = function () {
            var promises = [];
            $rootScope.progressLoader = "block";
            $scope.isDirty = $scope.updateCampaign.$dirty;
            //if ($scope.isDirty) {
            if (!$scope.isDirty) {
                $rootScope.freezeFlag = false;
                if ($window.localStorage.getItem("campaignState") != "create") {
                    // $scope.editAndUpdateCampaignDetails();
                } else {
                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&" + "lineItemId=" + $window.localStorage.getItem("lineItemid");
                    var data = {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    };
                    promises.push(twitterGetPost.readtargetingcriteria(queryStr, data).then(function (response) {
                        //$scope.getlineitemsResponse = response;
                    }));
                    $q.all(promises).finally(function () {
                        //$scope.savelineitem($scope.getlineitemsResponse);
                        $scope.moveNextStep();
                    });
                }
            } else {
                $scope.moveNextStep();
            }
        }

        $scope.moveNextStep = function () {
            $window.localStorage.setItem("campaignState", "create");
            $rootScope.campaignSteps[1] = true;
            $rootScope.campaignSteps[2] = true;
            $window.localStorage.removeItem("existingTargetingCriteriaArray");
            $state.go('app.followersCampaigncreative');
        }
        $scope.resetPopup = function () {
            $scope.editAdsetErrorMsg = 'none';
        };

        $scope.closeAdvancedOption = function () {
            $scope.advancedOption = false;
            $scope.adv1 = false;
            $scope.pac = false;
            $scope.adv2 = false;
            $scope.normal = true;
            //$scope.targetcost = false;
            //$scope.defaultpricing = '1';
            $scope.setLine();
        }


        $scope.changeDailyBudget = function () {
            if ($scope.priceBidType == "2") {
                if (($scope.vm.getData.dailyBudget == "") || ($scope.priceItemValue == "0" || $scope.priceItemValue == undefined)) {
                    angular.element('.is-btn-disabled').css('opacity', 0.9);
                    angular.element('.is-btn-disabled').css('pointer-events', 'none');
                    angular.element('#step1').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                } else {
                    angular.element('.is-btn-disabled').css('opacity', 1);
                    angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element($('.cd-btnConfirm').prop('disabled', false));
                }
            } else {
                if ($scope.vm.getData.dailyBudget == "") {
                    angular.element('.is-btn-disabled').css('opacity', 0.9);
                    angular.element('.is-btn-disabled').css('pointer-events', 'none');
                    angular.element('#step1').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                } else {
                    angular.element('.is-btn-disabled').css('opacity', 1);
                    angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element($('.cd-btnConfirm').prop('disabled', false));
                }
            }
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.selectPricing_for_tweet = function (value) {
            $scope.changedpricing = true;
            if (value == null) {
            } else {
                if (value == 1) {
                    if (vm.getData.dailyBudget != null) {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                    } else
                    {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#C2C2C2');
                    }
                    $scope.target_cost = false;
                    $scope.target_cost = false;
                    $scope.adv1 = true;
                    $scope.adv2 = false;
                    $scope.pac = false;
                    $scope.normal = false;
                    $scope.pacing = false;
                    $scope.plan_radio = 0;


                } else if (value == 2) {
                    if ($scope.priceItemValue == 0 && vm.getData.dailyBudget != null) {
                        angular.element('.is-btn-disabled').css('opacity', 0.9);
                        angular.element('.is-btn-disabled').css('pointer-events', 'none');
                        angular.element('#step1').css('background-color', '#C2C2C2');
                    } else
                    {
                        angular.element('.is-btn-disabled').css('opacity', 1);
                        angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                        angular.element('#step1').css('background-color', '#95D2B1');
                    }
                    $scope.target_cost = true;
                    $scope.adv1 = false;
                    $scope.adv2 = true;
                    $scope.pac = false;
                    $scope.normal = false;
                    $scope.targetcost = false;
                    $scope.pacing = false;
                    $scope.plan_radio = 1;

                }
                $scope.setLine();
            }

        }

        $scope.changePriceItemValue = function (priceItemValue) {
            $scope.changedpricevalue = true;
            if ($scope.priceBidType == "2") {
                if (($scope.vm.getData.dailyBudget == "" || $scope.vm.getData.dailyBudget == undefined) || ($scope.priceItemValue == "0" || $scope.priceItemValue == undefined)) {
                    angular.element('.is-btn-disabled').css('opacity', 0.9);
                    angular.element('.is-btn-disabled').css('pointer-events', 'none');
                    angular.element('#step1').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                } else {
                    angular.element('.is-btn-disabled').css('opacity', 1);
                    angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element($('.cd-btnConfirm').prop('disabled', false));
                }
            } else {
                if ($scope.vm.getData.dailyBudget == "") {
                    angular.element('.is-btn-disabled').css('opacity', 0.9);
                    angular.element('.is-btn-disabled').css('pointer-events', 'none');
                    angular.element('#step1').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', false));
                } else {
                    angular.element('.is-btn-disabled').css('opacity', 1);
                    angular.element('.is-btn-disabled').css('pointer-events', 'auto');
                    angular.element('#step1').css('background-color', '#95D2B1');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                }
            }
        }




        $scope.plan_value_change = function (value) {
            $scope.plan_radio = value;
            $scope.priceBidType = "2";

        }



        $scope.getstartdateandtime = function (sdate)
        {
            var currDate1 = sdate.getFullYear() + '-' + ('0' + (sdate.getMonth())).slice(-2) + '-' + ('0' + sdate.getDate()).slice(-2);
            //$window.localStorage.setItem("scheduleStartDate", currDate1)
            $scope.formattedstarttime = $filter('date')(new Date(sdate), 'yyyy-mm-dd HH:mm:ss');
            var sttime = $scope.formattedstarttime.split(" ")[1];
            var tmp = currDate1.concat(" ");
            var st = tmp.concat(sttime);
            $scope.crctst = st;
            $scope.crctstdate = $scope.crctst.split(" ")[0];
            $scope.crctsttime = $scope.crctst.split(" ")[1];
        }
        $scope.getenddateandtime = function (edate)
        {
            $scope.formattedenddate = $filter('date')(new Date(edate), 'yyyy-mm-dd HH:mm:ss');
            $scope.formattedendtime = $filter('date')(new Date(edate), 'yyyy-mm-dd HH:mm:ss');
            //$window.localStorage.setItem("scheduleEndDate", $scope.formattedenddate)
            var edDate = $scope.formattedenddate.split(" ")[0];
            var edtime = $scope.formattedendtime.split(" ")[1];
            var tmp1 = edDate.concat(" ");
            var ed = tmp1.concat(edtime);
            $scope.crcted = ed;
            $scope.crcteddate = $scope.crcted.split(" ")[0];
            $scope.crctedtime = $scope.crcted.split(" ")[1];
        }


        $scope.selectScheduleValue = function (value) {
            console.log(value);
            if (value == 1) {
                if ((vm.getData.dailyBudget == "" || vm.getData.dailyBudget == undefined) || ($scope.priceBidType == "2" && $scope.priceItemValue == "0" && $scope.priceItemValue == "")) {
                    angular.element('.cd-btnConfirm').css('opacity', 0.9);
                    angular.element('.cd-btnConfirm').css('pointer-events', 'none');
                    angular.element('#step2').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                } else {
                    angular.element('.cd-btnConfirm').css('opacity', 1);
                    angular.element('.cd-btnConfirm').css('pointer-events', 'auto');
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element($('.cd-btnConfirm').prop('disabled', false));
                }
                $scope.dateLen = 200;
                $scope.showChart = false;
                var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                $scope.sDate = new Date(currentDate);

                //$scope.datetimevalidation($scope.sDate,$scope.eDate);
            } else {
                if ($scope.eDate == "" || $scope.eDate == null || $scope.eDate == undefined || vm.getData.dailyBudget == "" || vm.getData.dailyBudget == undefined) {
                    angular.element('.is-btn-disabled').css('opacity', 0.9);
                    angular.element('.is-btn-disabled').css('pointer-events', 'none');
                    angular.element('#step2').css('background-color', '#C2C2C2');
                    angular.element($('.cd-btnConfirm').prop('disabled', true));
                } else {
                    angular.element('.cd-btnConfirm').css('opacity', 1);
                    angular.element('.cd-btnConfirm').css('pointer-events', 'auto');
                    angular.element('#step2').css('background-color', '#95D2B1');

                }

                $scope.dateLen = 330;
                if ($window.localStorage.getItem("campaignState") != "edit") {
                    var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
                    $scope.sDate = new Date(currentDate);
                }
                $scope.showChart = true;
                $scope.datetimevalidation($scope.sDate, $scope.eDate);
            }
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        /* console.log($scope.endDateValue);
         if ($scope.endDateValue != '' && $scope.endDateValue != undefined) {		
         angular.element('#step2').css('background-color', '#95D2B1');
         var currentDate = $filter('date')($scope.todayDate, 'yyyy-M-d hh:mm a');
         if (Date.parse(currentDate) <= Date.parse(parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'schedule_end'))) {
         $scope.eDate = new Date($scope.endDateValue);
         }
         $scope.selectSchedule.isActive = "2";
         console.log($scope.selectSchedule.isActive);
         $scope.selectScheduleValue($scope.selectSchedule.isActive);
         }
         else{
         $scope.selectSchedule.isActive = "1";
         $scope.selectSchedule($scope.selectSchedule.isActive);
         }
         */



        $scope.formatDate = function (date) {
            var dateOut = new Date(date);
            dateOut.setDate(dateOut.getDate() + 1);
            return dateOut;
        };

        $scope.cancelButtonClicked = function () {
            $rootScope.stopReplication = "flex";
            $rootScope.stopReplicationFrom = "cancelButton";
        };



        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }

        $scope.getAdvertSetName = function (_value) {

            $scope.campaignPlanForm.advertSetNme = _value
        }

        $scope.defaultBudget = "1";


//json array dropdown  for objective TWEET ENGAGEMENTS,VIDEO VIEWS
        $scope.priceItemswitmax_bid = [
            {
                "id": 1,
                "name": "Automatic Bid",
                "description": null,
                "code": null
            }, {
                "id": 2,
                "name": "Target Cost",
                "description": null,
                "code": null
            }
        ];

    }]);


