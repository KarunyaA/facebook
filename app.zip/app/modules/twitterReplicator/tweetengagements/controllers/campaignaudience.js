var replicatorApp = angular.module('replicator', ['app']);
replicatorApp.controller("twReplicatorEngCampaignaudienceController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', 'netWorkData', 'twitterGetPost', '$timeout', 'parser',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData, twitterGetPost, $timeout, parser) {

        var vm = this;
        vm.getData = {};
        vm.setSet = {};

        $scope.secondActiveDiv = 'yes';
        $scope.androidCount = 0;
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.select_market = false;
        $scope.cancelbutton = true;
        $scope.behaviourCategory = false;
        $scope.limitbehaviourCategory = false;
        $scope.existingVersionID = [];
        $scope.existingDeviceID = [];
        $scope.existingPlatformID = [];
        $scope.selectPlatformData = [];
        $scope.existingPlatformID = [];
        $scope.platformResponse = [];
        $scope.existingNetworkJSON = [];
        $scope.showIOSSelection = [];
        $scope.showAndroidSelection = [];
        $scope.allDeviceData = [];
        $scope.androidPopupData = [];
        $scope.iOSPopupData = [];
        $scope.iosDeviceData = []
        $scope.androidDeviceData = [];
        $scope.manufacturerDetails = [];
        $scope.rightAndroidContent = [];
        $scope.mapLocation = false;
        $scope.allVersionData = [];
        $scope.iOSVersions = [];
        $scope.androidVersions = [];
        $scope.campaignAudienceLocationsArr = [];

        $scope.locationJSON = [];

        $scope.campaignAudienceLanguageKeyArr = [];
        $scope.campaignAudienceLanguageArr = [];
        $scope.iosDeviceData = [];
        $scope.browseIOS = true;
        $scope.modifyAllIOS = [];
        $scope.modifySelectedIOS = [];
        $scope.selectedIOSList = [];
        $scope.lst = [];
        $scope.selectedValue = [];
        $scope.checkAndroidVal = 0;
        $scope.checkAndroid = false;
        $scope.allAndroid = false;
        $scope.checkAndroidCount = 0;
        $scope.selectedList = [];

        $scope.browseAndroid = true;
        $scope.modifySelectedAndroid = [];
        $scope.selectedAndroidList = [];
        $scope.allCountryCode = [];
        $scope.countryCodeData = [];
        $scope.countryNameList = [];
        $scope.countryName = [];
        $scope.nameList = []
        $scope.countryList = [];
        $scope.mobileCarrierList = [];
        $scope.rightNetworkContent = [];
        $scope.networkDetails = [];

        $scope.networkJSON = [];
        $scope.mobileSearchData = [];
        $scope.browserSelectedData = [];
        $scope.combinedMobileData = [];

        //$rootScope.progressLoader = "none";
        $scope.DTInterestArray = [];
        $scope.DTEventArray = [];
        $scope.DTInterestNameArray = [];
        $scope.DTEventNameArray = [];

        $scope.DTBehaviourArray = [];
        $scope.DTBehaviourNameArray = [];
        $scope.DTlimitBehaviourArray = [];
        $scope.DTlimitBehaviourNameArray = [];

        $scope.disabletvTargetingMarket = true;
        $scope.disabletvTargetingShows = true;


        $scope.disabletvbehaviourMarket = true;
        $scope.disabletvbehaviourShows = true;

        //$scope.limitbehaviourMarket = 'US';
        $scope.disablelimitbehaviourMarket = true;
        $scope.disablelimitbehaviourShows = true;
        $scope.existingTargetingCriteriaArray = [];
        $scope.existingTargetingCriteriaDBArray = [];
        $window.localStorage.setItem("existingTargetingCriteriaArray", "");

        $scope.campaignAudienceGender = 'all';
        $scope.radio_selected1 = "";
        $scope.radio_selected2 = "";
        $scope.show = false;

        //User suggestion block
        $scope.userSuggestionLocationBlock = false;
        $scope.userSuggestionAgeBlock = false;
        $scope.userSuggestionLanguageBlock = false;
        $scope.userSuggestionTargetingBlock = false;

        $scope.locationFlag = false;
        $scope.ageFlag = false;
        $scope.languageFlag = false;
        $scope.targetingFlag = false;

        $scope.locationTruncate = false;
        $scope.locationComplete = false;
        $scope.languageTruncate = false;
        $scope.languageComplete = false;
        $scope.targetingTruncate = false;
        $scope.targetingComplete = false;

        $scope.limit_targeting = function ()
        {
            $scope.select_market = $scope.select_market ? false : true;
            $scope.setLine();
        };


        $scope.cancelButtonClicked = function () {
            $rootScope.stopReplication = "flex";
            $rootScope.stopReplicationFrom = "cancelButton";
        };
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
        }
        $scope.PlacementsArr = {
            "data":
                    [
                        {
                            "name": "User's timelines",
                            "id": "TWITTER_TIMELINE",
                            "pic": "fa fa-clock-o"
                        },
                        {
                            "name": "Profiles & Tweet Detail Pages",
                            "id": "TWITTER_PROFILE",
                            "pic": "fa fa-file-image-o"
                        }

                    ]
        };



        //INITIAL CALL

        $scope.init = function () {
            $rootScope.progressLoader = "block";
            $rootScope.overLayAudience = false;
            $rootScope.freezeFlag = false;
            $rootScope.step = 2;

            /*if ($rootScope.campaignSteps[1] == false) {
             $window.localStorage.setItem("campaignState", "create");
             }  */

            $scope.setFlag = false;
            $scope.getPlatformDetails();
            $scope.selectBrowseCarriers();
            $scope.getTVMarketDetails();

            $scope.matchedLocation = [];
            $scope.matchedLanguage = [];
            $scope.matchedInterest = [];
            $scope.uniqueInterest = [];
            $scope.unmatchedLocation = [];
            $scope.unmatchedLanguage = [];
            $scope.unmatchedInterest = [];

            //$window.localStorage.setItem("campaignState", "edit");              
            var campaignState = $window.localStorage.getItem("campaignState");
            // angular.element('#step1').css('background-color', '#C2C2C2');   
            $scope.getdefaultEventsDetails();
            if ($window.localStorage.getItem("campaignState") == "replication" && $rootScope.sameNetwork == false) {
                console.log("into diff network");
                //Data pre-population Replication mode
                console.log('Inside twitther replicator Audience page');
                // $scope.progressLoader = "none";
                angular.forEach($scope.PlacementsArr, function (value) {
                    angular.forEach(value, function (key) {
                        key.selected = true;
                        if ($scope.placementsJSON.indexOf(key.id) == -1) {
                            $scope.placementsJSON.push(key.id);
                        }
                    });
                });
                if ($scope.placementsJSON) {
                    angular.element('#step2').css('background-color', '#95D2B1');
                    $scope.setSelectedPlacements();
                }

                $scope.locationObjTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'Location');
                $scope.languageObjTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'Language');
                console.log($scope.languageObjTwitter);
                $scope.genderObjTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'Gender');
                $scope.ageMinObjTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'AgeMin');
                $scope.ageMaxObjTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'AgeMax');
                $scope.devicePlatformTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'device_platforms');
                $scope.userDeviceTwitter = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'user_device');
                $scope.targetingInterest = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'targeting_interest');
                console.log($scope.targetingInterest);
                $scope.targetingBehaviors = parser.getParsedObject($rootScope.fieldMapping[0].data[0], 'targeting_behaviors');
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };

                //Set location Values from service
                if ($scope.locationObjTwitter != '' && $scope.locationObjTwitter != undefined && $scope.locationObjTwitter != null && $scope.locationObjTwitter.length > 0) {
                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&targetingCriteria=locations" + "&locationType=COUNTRIES";
                    twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                        var twLocationDetails = response.data.targetingCriteria;
                        console.log(twLocationDetails);
                        angular.forEach($scope.locationObjTwitter, function (val) {
                            var sObj = $filter('filter')(twLocationDetails, function (d) {
                                return d.name == val;
                            })[0];
                            if (typeof (sObj) == 'object') {
                                $scope.mapLocation = true;
                                var locationObj = {"name": sObj.name, "value": sObj.targeting_value};
                                $scope.campaignAudienceLocationsArr.push(locationObj);
                                $scope.locationJSON.push(sObj.targeting_value);

                                $scope.matchedLocation.push(val);
                            }
                            else {
                                $scope.unmatchedLocation.push(val);
                            }
                        });

                        console.log($scope.matchedLocation);
                        console.log($scope.unmatchedLocation);
                        if ($scope.unmatchedLocation.length != $scope.locationObjTwitter.length) {
                            $scope.unmatchedLocationString = $scope.unmatchedLocation.join(", ");
                            $scope.unmatchedLocationLength = $scope.unmatchedLocationString.length;
                            $scope.unmatchedLocationtruncate = $scope.unmatchedLocationString.substring(0, 70);
                            if ($scope.unmatchedLocationLength <= 70) {
                                $scope.locationTruncate = false;
                                $scope.locationComplete = true;
                            }
                            else {
                                $scope.locationTruncate = true;
                                $scope.locationComplete = false;
                            }
                        }
                        else {
                            $scope.locationTruncate = false;
                            $scope.locationComplete = false;
                        }
                    })
                }


                //Set Age bucket
                if ($scope.ageMinObjTwitter != '' && $scope.ageMinObjTwitter != undefined && $scope.ageMaxObjTwitter != '' && $scope.ageMaxObjTwitter != '') {

                    $scope.ageFromArrValue = [];
                    $scope.ageToArrValue = [];
                    angular.forEach($scope.ageFromArr, function (val) {
                        $scope.ageFromArrValue.push(val.Value);
                    });
                    angular.forEach($scope.ageToArr, function (val) {
                        $scope.ageToArrValue.push(val.value);
                    });
                    if ($scope.ageFromArrValue.indexOf($scope.ageMinObjTwitter.toString()) > -1 && $scope.ageToArrValue.indexOf($scope.ageMaxObjTwitter.toString()) > -1) {
                        $scope.campaignAudienceAgeFrom = $scope.ageMinObjTwitter.toString();
                        $scope.campaignAudienceAgeTo = $scope.ageMaxObjTwitter.toString();
                    }
                    else {
                        $scope.campaignAudienceAgeFrom = "";
                        $scope.campaignAudienceAgeTo = "";
                    }
                }

                //Set Gender
                if ($scope.genderObjTwitter != '' && $scope.genderObjTwitter != undefined) {
                    $scope.campaignAudienceGender = $scope.genderObjTwitter;

                }


                //Set Language Value

                if ($scope.languageObjTwitter != '' && $scope.languageObjTwitter != undefined && $scope.languageObjTwitter != null && $scope.languageObjTwitter.length > 0) {

                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&targetingCriteria=languages";
                    twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                        var twLanguageDetails = response.data.targetingCriteria;
                        angular.forEach($scope.languageObjTwitter, function (val) {
                            var sObj = $filter('filter')(twLanguageDetails, function (d) {
                                return d.name == val;

                            })[0];
                            if (typeof (sObj) == 'object') {
                                var languageObj = {"name": sObj.name, "value": sObj.targeting_value};
                                $scope.campaignAudienceLanguageArr.push(languageObj);
                                $scope.campaignAudienceLanguageKeyArr.push(sObj.targeting_value);
                                $scope.matchedLanguage.push(val);
                            }
                            else {
                                $scope.unmatchedLanguage.push(val);
                            }


                        });

                        console.log($scope.matchedLanguage);
                        console.log($scope.unmatchedLanguage);
                        if ($scope.unmatchedLanguage.length != $scope.languageObjTwitter.length) {
                            $scope.unmatchedLanguageString = $scope.unmatchedLanguage.join(", ");
                            $scope.unmatchedLanguageLength = $scope.unmatchedLanguageString.length;
                            $scope.unmatchedLanguagetruncate = $scope.unmatchedLanguageString.substring(0, 70);
                            console.log($scope.unmatchedLanguageString);
                            console.log($scope.unmatchedLanguageLength);
                            console.log($scope.unmatchedLanguagetruncate);
                            if ($scope.unmatchedLanguageLength <= 70) {
                                $scope.languageTruncate = false;
                               $scope.languageComplete = true;
                            }
                            else {
                                $scope.languageTruncate = true;
                                $scope.languageComplete = false;
                            }
                        }
                        else {
                            $scope.languageTruncate = false;
                            $scope.languageComplete = false;
                        }

                        console.log('out of ' + $scope.languageObjTwitter.length + ' ,' + $scope.matchedLanguage.length + ' is matched. Unmatched values are ' + $scope.unmatchedLanguage + ' .Please add your preferred language');
                    })
                }

                //Set device platforms
                /*$timeout(function () {
                 if ($scope.userDeviceTwitter == undefined || $scope.userDeviceTwitter == '' ) {                
                 if($scope.devicePlatformTwitter.indexOf("mobile") > -1){                                                                           
                 angular.forEach($scope.selectPlatformData,function(platform){                                                                                              
                 if(platform.name == "iOS" || platform.name == "Android" || platform.name == "BlackBerry phones and tablets"){
                 console.log(platform.name);
                 platform.Selected = true;                                                                     
                 $scope.selectDeviceandPlatform(platform,platform.targeting_value,platform.Selected);                                                                                                                                                                                                                                               
                 }
                 })
                 }
                 if($scope.devicePlatformTwitter.indexOf("desktop") > -1){
                 //console.log('only desktop');
                 angular.forEach($scope.selectPlatformData,function(platform){                                                                                              
                 if(platform.name == "Desktop and laptop computers"){
                 //console.log(platform.name);
                 platform.Selected = true;                                                                     
                 $scope.selectDeviceandPlatform(platform,platform.targeting_value,platform.Selected);                                                                                                                                                                                                                                               
                 }
                 })
                 }
                 }
                 else{
                 //console.log($scope.userDeviceTwitter[0]);
                 if($scope.userDeviceTwitter[0] == "iOS"){
                 angular.forEach($scope.selectPlatformData,function(platform){                                                                                              
                 if(platform.name == "iOS"){
                 //console.log(platform.name);
                 platform.Selected = true;                                                                     
                 $scope.selectDeviceandPlatform(platform,platform.targeting_value,platform.Selected);                                                                                                                                                                                                                                               
                 }
                 })
                 }
                 else if($scope.userDeviceTwitter[0] == "Android"){
                 angular.forEach($scope.selectPlatformData,function(platform){                                                                                              
                 if(platform.name == "Android"){
                 //console.log(platform.name);
                 platform.Selected = true;                                                                     
                 $scope.selectDeviceandPlatform(platform,platform.targeting_value,platform.Selected);                                                                                                                                                                                                                                               
                 }
                 })
                }
                 
                 
                 }
                 }, 2000);  */



                //set detailed targeting value
                //Populate interest value
//                console.log($scope.targetingInterest.length);
                if ($scope.targetingInterest != '' && $scope.targetingInterest != undefined && $scope.targetingInterest.length > 0) {
                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&targetingCriteria=interests";
                    twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                        var twTargetingInterest = response.data.targetingCriteria;

                        angular.forEach($scope.targetingInterest, function (val, key) {
                            $scope.DTInterestNameArrayFlag = false;
                            console.log(val.name + '-----------------');
                            //targetingNames.push(val.name);

                            angular.forEach(twTargetingInterest, function (val1, key1) {
                                if (val1.name.includes(val.name)) {
                                    $scope.matchedInterest.push(val.name);
                                    $scope.DTInterestArray.push(val1.targeting_value);
                                    var m_Obj = {"id": val1.name, "targeting_value": val1.targeting_value};
                                    $scope.DTInterestNameArray.push(m_Obj);
                                    //console.log($scope.DTInterestNameArray);
                                    $scope.DTInterestNameArrayFlag = true;
                                }

                            });
                            console.log($scope.matchedInterest);
                            if ($scope.removeDuplicates($scope.matchedInterest, val.name) != "" && $scope.DTInterestNameArrayFlag == true) {
                                $scope.uniqueInterest.push($scope.removeDuplicates($scope.matchedInterest, val.name));
                            }
                            else {
                                $scope.unmatchedInterest.push(val.name);
                            }
                        });

                        console.log($scope.unmatchedInterest);
                        if ($scope.unmatchedInterest.length != $scope.targetingInterest.length) {
                            $scope.unmatchedTargetingString = $scope.unmatchedInterest.join(", ");
                            $scope.unmatchedTargetingLength = $scope.unmatchedTargetingString.length;
                            $scope.unmatchedTargetingtruncate = $scope.unmatchedTargetingString.substring(0, 70);
                            if ($scope.unmatchedTargetingLength <= 70) {
                                $scope.targetingTruncate = false;
                                $scope.targetingComplete = true;
                            }
                            else {
                                $scope.targetingTruncate = true;
                                $scope.targetingComplete = false;
                            }
                        }
                        else {
                            $scope.targetingTruncate = false;
                            $scope.targetingComplete = false;
                        }

                        console.log('out of ' + $scope.targetingInterest.length + ' ,' + $scope.uniqueInterest.length + ' is matched. Unmatched values are ' + $scope.unmatchedInterest + ' .Please add your preferred targeting');
                    })
                }


                //Populate behaviour values
                if ($scope.targetingBehaviors != '' && $scope.targetingBehaviors != undefined && $scope.targetingBehaviors.length > 0) {
                    console.log($scope.targetingBehaviors);
                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behavior_taxonomies&parentBehaviorTaxonomyIds=null';
                    twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                        var twTargetingBehaviour = response.data.targetingCriteria;
                        console.log(twTargetingBehaviour);
                        angular.forEach($scope.targetingBehaviors, function (val, key) {
                            console.log(val.name + '-----------------');
                            angular.forEach(twTargetingBehaviour, function (val1, key1) {
                                if (val1.name.includes(val.name)) {
                                    console.log(val1.name);
                                    $scope.DTBehaviourArray.push(val1.targeting_value);
                                    var m_Obj = {"id": val1.name, "targeting_value": val1.targeting_value};
                                    $scope.DTBehaviourNameArray.push(m_Obj);
                                    //console.log('true');
                                }
                            });

                        });
                    })
                }

                //$scope.progressLoader = "none";
            } 

            $scope.setLine();

        };

        $scope.$on('details-loaded', function () {
            $scope.setLine();
        });

        $scope.setLine = function () {
            var everythingLoaded = setInterval(function () {
                if (/loaded|complete/.test(document.readyState)) {
                    clearInterval(everythingLoaded);
                    $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                    $scope.lsValue = angular.element(document.getElementById('step2')).offset().top;
                    var offsetHeight2 = document.getElementById('step2container').offsetHeight;
                    var fStep = $(".vr");
                    fStep.css('height', (($scope.lsValue - $scope.fsValue)));

                }
            }, 10);
        };

        $scope.expandDetailedTargeting = function () {
            $scope.setLine();
        }

        $scope.placementsJSON = [];
        $scope.updateCampaignAudience = function () {
            $scope.campaignData = JSON.parse($window.localStorage.getItem("twitterReplicatorData"));
            console.log($scope.campaignData)
            $rootScope.progressLoader = "block";
            //PREFILLING FROM DB
            angular.forEach($scope.campaignData[1], function (value, key) {
                var JsonObj = $scope.campaignData[1][key];
                console.log(JsonObj);
                var array = [];
                
                    angular.forEach(JsonObj.twLineItemDetails.placements, function (placementsVal) {
                        angular.forEach($scope.PlacementsArr, function (value) {
                            angular.forEach(value, function (key) {
                                if (key.id == placementsVal)
                                {
                                    key.selected = true;
                                    if ($scope.placementsJSON.indexOf(key.id) == -1) {
                                        $scope.placementsJSON.push(key.id);
                                    }

                                }
                            });
                        });
                    });
                    //console.log(i);
                            $scope.targetingCriteriaResults = $scope.campaignData[2];
                            console.log($scope.targetingCriteriaResults);                            
                            if ($scope.targetingCriteriaResults != '' && $scope.targetingCriteriaResults != undefined && $scope.targetingCriteriaResults.length > 0) {

                                $scope.DTInterestNameArray = [];
                                $scope.DTInterestArray = [];
                                angular.forEach($scope.targetingCriteriaResults, function (v, k) {
                                    var s_obj = $scope.targetingCriteriaResults[k];
                                    //console.log(s_obj);
                                    for (var j in s_obj) {
                                        if (s_obj.hasOwnProperty(j)) {                                               
                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'LOCATION') {
                                                //$scope.campaignAudienceLocationsArr = [];
                                               
                                                var locationObj = {"name": s_obj[j].twTargetingCriteriaDetails.name, "value": s_obj[j].twTargetingCriteriaDetails.targeting_value};
                                                if ($scope.campaignAudienceLocationsArr.indexOf(locationObj) == -1) {
                                                    $scope.campaignAudienceLocationsArr.push(locationObj);
                                                }

                                                if ($scope.locationJSON.indexOf(s_obj[j].twTargetingCriteriaDetails.targeting_value) == -1) {
                                                    $scope.locationJSON.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                    //$scope.locationJSON = $scope.removeDuplicates($scope.locationJSON, s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                }
                                                if ($scope.campaignAudienceLocationsArr.length == 1) {
                                                    var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + "&targetingCriteria=locations" + "&q=" + s_obj[j].twTargetingCriteriaDetails.name.split(' ')[0];
                                                    twitterGetPost.gettargetingcriteria(queryStr, data).then(function (locres) {
                                                        angular.forEach(locres.data.targetingCriteria, function (lv, lk) {
                                                            if (lv.targeting_value == s_obj[j].twTargetingCriteriaDetails.targeting_value) {

                                                                if ($scope.campaignAudienceLocationsArr.length == 1) {

                                                                    if (lv.country_code == 'US' || lv.country_code == 'GB') {
                                                                        $scope.tvbehaviourMarket = lv.country_code;
                                                                        $scope.limitbehaviourMarket = lv.country_code;

                                                                        $scope.disabletvbehaviourMarket = true;
                                                                        $scope.disabletvbehaviourShows = false;

                                                                        $scope.disablelimitbehaviourMarket = true;
                                                                        $scope.disablelimitbehaviourShows = false;

                                                                        $scope.disabletvTargetingMarket = true;
                                                                        $scope.disabletvTargetingShows = false;

                                                                        $scope.getBehaviourChildDetails($scope.tvbehaviourMarket);

                                                                    } else {
                                                                        $scope.tvTargetingMarket = 'en-US';
                                                                        $scope.tvbehaviourMarket = 'US';
                                                                        $scope.limitbehaviourMarket = 'US';

                                                                        $scope.disabletvbehaviourMarket = true;
                                                                        $scope.disabletvbehaviourShows = true;

                                                                        $scope.disablelimitbehaviourMarket = true;
                                                                        $scope.disablelimitbehaviourShows = true;

                                                                        $scope.disabletvTargetingMarket = true;
                                                                        $scope.disabletvTargetingShows = false;

                                                                        $scope.DTBehaviourArray = [];
                                                                        $scope.DTBehaviourNameArray = [];

                                                                        $scope.DTlimitBehaviourArray = [];
                                                                        $scope.DTlimitBehaviourNameArray = [];

                                                                        $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                                                                        $window.localStorage.setItem("DTBehaviourNameArray", '');

                                                                    }
                                                                    //$scope.disabletvTargetingMarket = false;
                                                                    //$scope.disabletvTargetingShows = false;
                                                                    var results = $filter('filter')($scope.tvMarketData, {country_code: lv.country_code}, true);
                                                                    if (results.length > 0) {
                                                                        $scope.tvTargetingMarket = results[0].locale;
                                                                        $scope.disabletvTargetingMarket = true;
                                                                        $scope.disabletvTargetingShows = false;
                                                                    }
                                                                    /*angular.forEach($scope.tvMarketData, function(val, key){
                                                                     if(val.country_code==lv.country_code && val.name==$scope.campaignAudienceLocationsArr[0].name){
                                                                     //console.log(val.locale);
                                                                     $scope.tvTargetingMarket = val.locale;
                                                                     $scope.disabletvTargetingMarket = true;
                                                                     $scope.disabletvTargetingShows = false;
                                                                     }
                                                                     });*/
                                                                } else {
                                                                    $scope.disabletvbehaviourMarket = true;
                                                                    $scope.disabletvbehaviourShows = true;

                                                                    $scope.disablelimitbehaviourMarket = true;
                                                                    $scope.disablelimitbehaviourShows = true;

                                                                    $scope.disabletvTargetingMarket = true;
                                                                    $scope.disabletvTargetingShows = true;

                                                                    $scope.DTBehaviourArray = [];
                                                                    $scope.DTBehaviourNameArray = [];

                                                                    $scope.DTlimitBehaviourArray = [];
                                                                    $scope.DTlimitBehaviourNameArray = [];

                                                                    $scope.campaignAudienceTVShowArr = [];
                                                                    $scope.campaignAudienceTVShowKeyArr = [];

                                                                    $window.localStorage.setItem("campaignAudienceTVShowArr", '');
                                                                    $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                                                                    $window.localStorage.setItem("DTBehaviourNameArray", '');

                                                                }


                                                            }
                                                        });
                                                    });
                                                }
                                                $scope.mapLocation = true;
                                                $scope.campaignAudienceLocationsArr = $scope.removeDuplicates($scope.campaignAudienceLocationsArr, "value");
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'INTEREST') {

                                                if ($scope.DTInterestArray.indexOf(JSON.stringify(s_obj[j].twTargetingCriteriaDetails.targeting_value)) == -1) {
                                                    $scope.DTInterestArray.push(JSON.stringify(s_obj[j].twTargetingCriteriaDetails.targeting_value));
                                                }
                                                var m_Obj = {"id": s_obj[j].twTargetingCriteriaDetails.name, "targeting_value": JSON.stringify(s_obj[j].twTargetingCriteriaDetails.targeting_value), "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                if ($scope.DTInterestNameArray.indexOf(m_Obj) == -1) {
                                                    $scope.DTInterestNameArray.push(m_Obj);
                                                }
                                                $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'BEHAVIOR') {

                                                $scope.DTBehaviourArray.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                var m_Obj = {"id": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                $scope.DTBehaviourNameArray.push(m_Obj);
                                                $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'NEGATIVE_BEHAVIOR') {
                                                $scope.DTlimitBehaviourArray.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                var m_Obj = {"id": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                $scope.DTlimitBehaviourNameArray.push(m_Obj);
                                                $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'TV_SHOW') {
                                                $scope.campaignAudienceTVShowKeyArr.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                var m_Obj = {"id": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                $scope.campaignAudienceTVShowArr.push(m_Obj);
                                                $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'EVENT') {

                                                $scope.DTEventArray.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                var m_Obj = {"id": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                $scope.DTEventNameArray.push(m_Obj);
                                                $window.localStorage.setItem("existingEventId", s_obj[j].twTargetingCriteriaDetails.id);
                                                $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);

                                                $scope.existingDTEventId = s_obj[j].twTargetingCriteriaDetails.targeting_value;
                                                var results = $filter('filter')($scope.DefaultEventsArray, {id: $scope.DTEventNameArray[0].id}, true);
                                                var m_Obj = {"id": results[0].id, "name": results[0].name, "existingid": $scope.DTEventNameArray[0].existingid};
                                                $scope.DTEventNameArray = [];
                                                $scope.DTEventNameArray.push(m_Obj);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'GENDER') {
                                                $scope.campaignAudienceGenderJSON = s_obj[j].twTargetingCriteriaDetails.targeting_value;
                                                if (s_obj[j].twTargetingCriteriaDetails.targeting_value == '1') {
                                                    $scope.campaignAudienceGender = 'men';
                                                } else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == '2') {
                                                    $scope.campaignAudienceGender = 'women';
                                                } else {
                                                    $scope.campaignAudienceGender = 'all';
                                                }
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'AGE') {
                                                //(AGE_OVER_21)
                                                $scope.setAgeBucket = s_obj[j].twTargetingCriteriaDetails.targeting_value;
                                                if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_value.indexOf("AGE_OVER") > -1) {
                                                    if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_13") {
                                                        $scope.campaignAudienceAgeFrom = "13+";
                                                    }
                                                    else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_18") {
                                                        $scope.campaignAudienceAgeFrom = "18+";
                                                    }
                                                    else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_21") {
                                                        $scope.campaignAudienceAgeFrom = "21+";
                                                    }
                                                    else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_25") {
                                                        $scope.campaignAudienceAgeFrom = "25+";
                                                    }
                                                    else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_35") {
                                                        $scope.campaignAudienceAgeFrom = "35+";
                                                    }
                                                    else if (s_obj[j].twTargetingCriteriaDetails.targeting_value == "AGE_OVER_50") {
                                                        $scope.campaignAudienceAgeFrom = "50+";
                                                    }
                                                    $scope.disableAge = true;
                                                    $scope.campaignAudienceAgeTo = "";
                                                } else {
                                                    $scope.campaignAudienceAgeFrom = s_obj[j].twTargetingCriteriaDetails.targeting_value.split('_')[1];
                                                    $scope.campaignAudienceAgeTo = s_obj[j].twTargetingCriteriaDetails.targeting_value.split('_')[3];
                                                    var minAge = $scope.campaignAudienceAgeFrom;
                                                    if ($scope.campaignAudienceAgeTo != undefined) {

                                                        angular.forEach($scope.endingAge, function (maxage) {
                                                            if (minAge == maxage.id && $scope.campaignAudienceAgeTo == maxage.value) {
                                                                $scope.setMaxAge = maxage.target;
                                                            }
                                                        });
                                                    }
                                                }

                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'LANGUAGE') {
                                                //$scope.campaignAudienceLanguageArr = [];
                                                //       $scope.campaignAudienceLanguageKeyArr = [];
                                                $scope.campaignAudienceLanguageArr.push({"name": s_obj[j].twTargetingCriteriaDetails.name, "value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "country_code": s_obj[j].twTargetingCriteriaDetails.country_code});
                                                $scope.campaignAudienceLanguageKeyArr.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                $scope.campaignAudienceLanguageArr = $scope.removeDuplicates($scope.campaignAudienceLanguageArr, "value");
                                                $scope.campaignAudienceLanguageKeyArr = $scope.removeDuplicates($scope.campaignAudienceLanguageKeyArr, s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'NETWORK_OPERATOR') {
												console.log('into network operrator');
                                                var carrierObj = {"name": s_obj[j].twTargetingCriteriaDetails.name, "value": s_obj[j].twTargetingCriteriaDetails.targeting_value};
                                                if ($scope.mobileSearchData.indexOf(carrierObj) == -1) {
                                                    $scope.mobileSearchData.push(carrierObj);
                                                }
												
                                                for (var i = 0; i < $scope.countryList.length; i++) {
												//angular.forEach($scope.countryList, function(value, key) {
													
                                                    //var data = $scope.countryList[i];
													 var data = $scope.countryList[i];
													 angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                                                        if ((s_obj[j].twTargetingCriteriaDetails.name == network.name) && (s_obj[j].twTargetingCriteriaDetails.targeting_value == network.optargeting_value)) {														
                                                            network.Selected = true;
                                                            if (network.Selected) {
                                                                $scope.selectedNetwork.push(network);
                                                                //$scope.browserSelectedData = [];
                                                                console.log($scope.selectedNetwork);
                                                                var networkObj = {"name": network.name, "value": network.optargeting_value};
                                                                if ($scope.browserSelectedData.indexOf(networkObj == -1)) {
                                                                    $scope.browserSelectedData.push(networkObj);
                                                                }
                                                                if ($scope.combinedMobileData.indexOf(networkObj == -1)) {
                                                                    $scope.combinedMobileData.push(networkObj);
                                                                }

                                                                var nwVal = network.optargeting_value;
                                                                if ($scope.networkJSON.indexOf(nwVal) == -1) {

                                                                    $scope.networkJSON.push(s_obj[j].twTargetingCriteriaDetails.targeting_value);
                                                                    var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                                    $scope.existingNetworkJSON.push(m_Obj);
                                                                    if ($scope.existingTargetingCriteriaDBArray.indexOf(s_obj[j].twTargetingCriteriaDetails.id) == -1) {
                                                                        $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                                                   }
                                                                }
                                                            }

                                                        }

                                                    })
                                               // });
											   }
                                                $scope.combinedMobileData = $scope.removeDuplicates($scope.combinedMobileData, "value");
                                                $scope.networkJSON = $scope.removeDuplicates($scope.networkJSON, s_obj[j].twTargetingCriteriaDetails.targeting_value);
												console.log($scope.combinedMobileData);
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'NETWORK_ACTIVATION_DURATION_LT') {
                                                $scope.targetChecked = true;
                                                $scope.radioTarget = 1;
                                                $scope.radio_selected1 = s_obj[j].twTargetingCriteriaDetails.name.split(' ')[0];
                                                $scope.radio_selected2 = "";

                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'NETWORK_ACTIVATION_DURATION_GTE') {
                                                $scope.targetChecked = true;
                                                $scope.radioTarget = 2;
                                                $scope.radio_selected2 = s_obj[j].twTargetingCriteriaDetails.name.split(' ')[0];
                                                $scope.radio_selected1 = "";

                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'PLATFORM') {

                                                angular.forEach($scope.selectPlatformData, function (platform) {
                                                    if (s_obj[j].twTargetingCriteriaDetails.name == platform.name) {
                                                        platform.Selected = true;
                                                        $scope.selectDeviceandPlatform(platform, platform.targeting_value, platform.Selected);
                                                    }
                                                })
                                                var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};

                                                if ($scope.existingPlatformID.indexOf(m_Obj) == -1) {
                                                    $scope.existingPlatformID.push(m_Obj);
                                                    $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                                }
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'PLATFORM_VERSION') {

                                                angular.forEach($scope.iOSVersions, function (iosVersion) {
                                                    if (iosVersion.name.indexOf(s_obj[j].twTargetingCriteriaDetails.name) > -1) {
                                                        $scope.versionData = s_obj[j].twTargetingCriteriaDetails.name;
                                                        $scope.selectedVersion = $scope.versionData;
                                                        var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};

                                                        if ($scope.existingVersionID.indexOf(m_Obj) == -1) {
                                                            $scope.existingVersionID.push(m_Obj);
                                                            $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                                        }
                                                    }
                                                })
                                                angular.forEach($scope.androidVersions, function (androidVersion) {
                                                    if (androidVersion.name.indexOf(s_obj[j].twTargetingCriteriaDetails.name) > -1) {
                                                        $scope.versionAndroid = s_obj[j].twTargetingCriteriaDetails.name;
                                                        $scope.selectedVersionName = $scope.versionAndroid;
                                                        var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};

                                                        if ($scope.existingVersionID.indexOf(m_Obj) == -1) {
                                                            $scope.existingVersionID.push(m_Obj);
                                                            $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                                        }

                                                    }
                                                })
                                            }

                                            if (s_obj[j].twTargetingCriteriaStatus == 'ACTIVE' && s_obj[j].twTargetingCriteriaDetails.targeting_type == 'DEVICE') {
                                                if ($scope.manufacturerDetails) {
                                                    for (var i = 0; i <= $scope.manufacturerDetails.length; i++) {
                                                        var data = $scope.manufacturerDetails[i];
                                                        angular.forEach($scope.rightAndroidContent[data], function (deviceCheck) {
                                                            if (s_obj[j].twTargetingCriteriaDetails.name == deviceCheck.name)
                                                                deviceCheck.Selected = true;
                                                            if (deviceCheck.Selected) {
                                                                angular.forEach($scope.selectPlatformData, function (platform) {
                                                                    if (platform.name == deviceCheck.platform)
                                                                        platform.Selected = true;
                                                                })
                                                                $scope.setCheckedAndroid(deviceCheck);
                                                                $scope.submitSelectedAndroid();
                                                            }
                                                        })
                                                    }
                                                    var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                    $scope.existingDeviceID.push(m_Obj);
                                                    $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);

                                                }
                                                if ($scope.iosDeviceData) {
                                                    angular.forEach($scope.iosDeviceData, function (iosDevice) {
                                                        if (s_obj[j].twTargetingCriteriaDetails.name == iosDevice.name) {
                                                            iosDevice.Selected = true;
                                                            if (iosDevice.Selected) {
                                                                angular.forEach($scope.selectPlatformData, function (platform) {
                                                                    if (platform.name == iosDevice.platform)
                                                                        platform.Selected = true;
                                                                })
                                                                $scope.setCheckAll(iosDevice);
                                                                $scope.submitIOSDevice();
                                                            }
                                                        }
                                                    })
                                                    var m_Obj = {"targeting_value": s_obj[j].twTargetingCriteriaDetails.targeting_value, "name": s_obj[j].twTargetingCriteriaDetails.name, "existingid": s_obj[j].twTargetingCriteriaDetails.id};
                                                    $scope.existingDeviceID.push(m_Obj);
                                                    $scope.existingTargetingCriteriaDBArray.push(s_obj[j].twTargetingCriteriaDetails.id);
                                                }

                                            }

                                        }
                                    }
                                });
                                console.log($scope.existingTargetingCriteriaDBArray);
                                $scope.setLine();
                            } else {

                                //REFILLING FROM LOCALSTORAGE

                                if ($window.localStorage.getItem('campaignAudienceLocationsLocal')) {

                                    $scope.locationsLocal = JSON.parse($window.localStorage.getItem('campaignAudienceLocationsLocal'));
                                    $scope.mapLocation = true;
                                    angular.forEach($scope.locationsLocal, function (locationsVal) {
                                        $scope.campaignAudienceLocationsArr = [];
                                        $scope.campaignAudienceLocationsArr.push({"name": locationsVal.name, "value": locationsVal.value, "country_code": locationsVal.country_code});
                                        $scope.locationJSON.push(locationsVal.value);
                                        if ($scope.campaignAudienceLocationsArr.length == 1) {

                                            if ($scope.campaignAudienceLocationsArr[0].country_code == 'US' || $scope.campaignAudienceLocationsArr[0].country_code == 'GB') {
                                                $scope.tvbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;
                                                $scope.limitbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;

                                                $scope.disabletvbehaviourMarket = true;
                                                $scope.disabletvbehaviourShows = false;

                                                $scope.disablelimitbehaviourMarket = true;
                                                $scope.disablelimitbehaviourShows = false;

                                                $scope.disabletvTargetingMarket = true;
                                                $scope.disabletvTargetingShows = false;
                                            } else {
                                                $scope.tvTargetingMarket = 'en-US';
                                                $scope.tvbehaviourMarket = 'US';
                                                $scope.limitbehaviourMarket = 'US';

                                                $scope.disabletvbehaviourMarket = true;
                                                $scope.disabletvbehaviourShows = false;

                                                $scope.disablelimitbehaviourMarket = true;
                                                $scope.disablelimitbehaviourShows = false;

                                                $scope.disabletvTargetingMarket = true;
                                                $scope.disabletvTargetingShows = false;
                                            }
                                            //$scope.disabletvTargetingMarket = false;
                                            //$scope.disabletvTargetingShows = false;
                                            var results = $filter('filter')($scope.tvMarketData, {country_code: $scope.campaignAudienceLocationsArr[0].country_code}, true);
                                            $scope.tvTargetingMarket = results[0].locale;
                                            $scope.disabletvTargetingMarket = true;
                                            $scope.disabletvTargetingShows = false;

                                            /*angular.forEach($scope.tvMarketData, function(val, key){
                                             if(val.country_code==$scope.campaignAudienceLocationsArr[0].country_code && val.name==$scope.campaignAudienceLocationsArr[0].name){
                                             //console.log(val.locale);
                                             $scope.tvTargetingMarket = val.locale;
                                             $scope.disabletvTargetingMarket = true;
                                             $scope.disabletvTargetingShows = false;
                                             }
                                             });*/
                                        } else {
                                            $scope.disabletvbehaviourMarket = true;
                                            $scope.disabletvbehaviourShows = true;

                                            $scope.disablelimitbehaviourMarket = true;
                                            $scope.disablelimitbehaviourShows = true;

                                            $scope.disabletvTargetingMarket = true;
                                            $scope.disabletvTargetingShows = true;
                                        }


                                    })
                                }
                                if ($window.localStorage.getItem('DTInterestNameArray')) {


                                    $scope.localDTInterestNameArray = JSON.parse($window.localStorage.getItem('DTInterestNameArray'));
                                    $scope.DTInterestNameArray = [];
                                    $scope.DTInterestArray = [];
                                    angular.forEach($scope.localDTInterestNameArray, function (val, key) {
                                        $scope.DTInterestArray.push(val.targeting_value);
                                        var m_Obj = {"id": val.id, "targeting_value": val.targeting_value};
                                        $scope.DTInterestNameArray.push(m_Obj);
                                    });
                                }
                                if ($window.localStorage.getItem('campaignAudienceTVShowArr')) {

                                    $scope.localcampaignAudienceTVShowArr = JSON.parse($window.localStorage.getItem('campaignAudienceTVShowArr'));
                                    $scope.campaignAudienceTVShowArr = [];
                                    $scope.campaignAudienceTVShowKeyArr = [];
                                    angular.forEach($scope.localcampaignAudienceTVShowArr, function (val, key) {
                                        var m_Obj = {"id": val.id, "name": val.name};
                                        $scope.campaignAudienceTVShowArr.push(m_Obj);
                                        $scope.campaignAudienceTVShowKeyArr.push(val.id);
                                    });
                                }
                                if ($window.localStorage.getItem('DTBehaviourNameArray')) {

                                    $scope.localDTBehaviourNameArray = JSON.parse($window.localStorage.getItem('DTBehaviourNameArray'));
                                    $scope.DTBehaviourArray = [];
                                    $scope.DTBehaviourNameArray = [];
                                    angular.forEach($scope.localDTBehaviourNameArray, function (val, key) {
                                        $scope.DTBehaviourArray.push(val.id);
                                        var m_Obj = {"id": val.id, "name": val.name};
                                        $scope.DTBehaviourNameArray.push(m_Obj);
                                    });
                                }
                                if ($window.localStorage.getItem('DTEventNameArray')) {

                                    $scope.localDTEventNameArray = JSON.parse($window.localStorage.getItem('DTEventNameArray'));
                                    $scope.DTEventArray = [];
                                    $scope.DTEventNameArray = [];
                                    angular.forEach($scope.localDTEventNameArray, function (val, key) {
                                        $scope.DTEventArray.push(val.id);
                                        var m_Obj = {"id": val.id, "name": val.name};
                                        $scope.DTEventNameArray.push(m_Obj);
                                    });
                                }
                                if ($window.localStorage.getItem('DTlimitBehaviourNameArray')) {


                                    $scope.localDTlimitBehaviourNameArray = JSON.parse($window.localStorage.getItem('DTlimitBehaviourNameArray'));
                                    $scope.DTlimitBehaviourArray = [];
                                    $scope.DTlimitBehaviourNameArray = [];
                                    angular.forEach($scope.localDTlimitBehaviourNameArray, function (val, key) {
                                        $scope.DTlimitBehaviourArray.push(val.id);
                                        var m_Obj = {"id": val.id, "name": val.name};
                                        $scope.DTlimitBehaviourNameArray.push(m_Obj);
                                    });
                                }
                                if ($window.localStorage.getItem('campaignAudienceAgeFrom')) {
                                    $scope.campaignAudienceAgeFrom = $window.localStorage.getItem('campaignAudienceAgeFrom');
                                }
                               if ($window.localStorage.getItem('campaignAudienceAgeTo')) {

                                    $scope.campaignAudienceAgeTo = $window.localStorage.getItem('campaignAudienceAgeTo');
                                    var minAge = $scope.campaignAudienceAgeFrom;
                                    if ($scope.campaignAudienceAgeTo != undefined) {

                                        angular.forEach($scope.endingAge, function (maxage) {
                                            if (minAge == maxage.id && $scope.campaignAudienceAgeTo == maxage.value) {
                                                $scope.setMaxAge = maxage.target;
                                            }
                                        });
                                   }
                                }
                                if ($window.localStorage.getItem('campaignAudienceGender')) {
                                    $scope.campaignAudienceGender = $window.localStorage.getItem('campaignAudienceGender');
                                }

                                if ($window.localStorage.getItem('campaignAudienceAndroidLocal')) {
                                    $scope.localAndroidDevice = JSON.parse($window.localStorage.getItem('campaignAudienceAndroidLocal'));
                                    angular.forEach($scope.localAndroidDevice, function (localAndroid) {
                                        if ($scope.manufacturerDetails) {
                                            for (var i = 0; i <= $scope.manufacturerDetails.length; i++) {
                                                var data = $scope.manufacturerDetails[i];
                                                angular.forEach($scope.rightAndroidContent[data], function (deviceCheck) {
                                                    if (localAndroid.name == deviceCheck.name)
                                                        deviceCheck.Selected = true;
                                                    if (deviceCheck.Selected) {
                                                        $scope.setCheckedAndroid();
                                                        $scope.submitSelectedAndroid();

                                                        angular.forEach($scope.selectPlatformData, function (platform) {
                                                            if (platform.name == deviceCheck.platform)
                                                                platform.Selected = true;
                                                        })

                                                    }
                                                })
                                            }
                                        }
                                    })
                                }

                                if ($window.localStorage.getItem('campaignAudienceAndroidVerLocal')) {
                                    $scope.localAndroidVersion = $window.localStorage.getItem('campaignAudienceAndroidVerLocal');
                                    $scope.versionAndroid = $scope.localAndroidVersion;
                                    $scope.selectedVersionName = $scope.versionAndroid;
                                }


                                if ($window.localStorage.getItem('campaignAudienceIOSLocal')) {
                                    $scope.localiOSDevice = JSON.parse($window.localStorage.getItem('campaignAudienceIOSLocal'));

                                    angular.forEach($scope.localiOSDevice, function (iosDeviceLocal) {

                                        if ($scope.iosDeviceData) {
                                            angular.forEach($scope.iosDeviceData, function (iosDevice) {
                                                if (iosDeviceLocal.name == iosDevice.name) {
                                                    iosDevice.Selected = true;
                                                    if (iosDevice.Selected) {
                                                        $scope.setCheckAll(iosDeviceLocal);
                                                        $scope.submitIOSDevice();
                                                        angular.forEach($scope.selectPlatformData, function (platform) {
                                                            if (platform.name == iosDeviceLocal.platform)
                                                                platform.Selected = true;
                                                        })
                                                    }

                                                }
                                            })
                                        }

                                    })

                                }

                                if ($window.localStorage.getItem('campaignAudienceIOsVersion')) {
                                    $scope.versionData = $window.localStorage.getItem('campaignAudienceIOsVersion');
                                    $scope.selectedVersion = $scope.versionData;

                                }

                                if ($window.localStorage.getItem('campaignAudienceLanguageLocal')) {

                                    $scope.languageLocalArr = JSON.parse($window.localStorage.getItem('campaignAudienceLanguageLocal'));
                                    angular.forEach($scope.languageLocalArr, function (language) {
                                        //console.log(language);
                                        $scope.campaignAudienceLanguageArr.push({"name": language.name, "value": language.value});
                                        $scope.campaignAudienceLanguageKeyArr.push(language.value);
                                    })
                                }

                                if ($window.localStorage.getItem('campaignAudienceMobileCarrierLocal')) {

                                    $scope.mobileCarrierLocal = JSON.parse($window.localStorage.getItem('campaignAudienceMobileCarrierLocal'));
                                    angular.forEach($scope.mobileCarrierLocal, function (mobileLocal) {
                                        $scope.mobileSearchData.push({"name": mobileLocal.name, "value": mobileLocal.value});

                                        for (var i = 0; i < $scope.countryList.length; i++) {
                                            var data = $scope.countryList[i];
                                            angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                                                if (mobileLocal.name == network.name) {
                                                    network.Selected = true;
                                                    if (network.Selected) {
                                                        $scope.selectedNetwork.push(network);
                                                        var nwVal = network.optargeting_value;
                                                        if ($scope.networkJSON.indexOf(nwVal) == -1) {
                                                            $scope.networkJSON.push(mobileLocal.value);
                                                        }
                                                    }

                                                }

                                            })
                                        }

                                    })
                                }


                                if ($window.localStorage.getItem('campaignAudienceMobileLocal')) {

                                    $scope.browseSelectedLocal = JSON.parse($window.localStorage.getItem('campaignAudienceMobileLocal'));
                                    angular.forEach($scope.browseSelectedLocal, function (carrierLocal) {
                                        $scope.browserSelectedData.push({"name": carrierLocal.name, "value": carrierLocal.value});
                                        for (var i = 0; i < $scope.countryList.length; i++) {
                                            var data = $scope.countryList[i];
                                            angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                                                if (carrierLocal.name == network.name) {
                                                    network.Selected = true;
                                                    if (network.Selected) {
                                                        $scope.selectedNetwork.push(network);
                                                        var nwVal = network.optargeting_value;
                                                        if ($scope.networkJSON.indexOf(nwVal) == -1) {

                                                            $scope.networkJSON.push(carrierLocal.value);

                                                        }
                                                    }

                                                }

                                            })
                                        }
                                    })

                                }

                                if ($window.localStorage.getItem('campaignAudiencePlacementsLocal')) {
                                    $scope.placementsLocalArr = JSON.parse($window.localStorage.getItem('campaignAudiencePlacementsLocal'));
                                    angular.forEach($scope.placementsLocalArr, function (placements) {
                                        angular.forEach($scope.PlacementsArr, function (value) {
                                            angular.forEach(value, function (key) {
                                                if (key.id == placements)
                                                {
                                                    key.selected = true;
                                                    if ($scope.placementsJSON.indexOf(key.id) == -1) {
                                                        $scope.placementsJSON.push(key.id);
                                                    }

                                                }
                                            })
                                        })
                                    })
                                }

                                if ($window.localStorage.getItem('campaignAudiencePlatformLocal')) {

                                    $scope.platformSelected = JSON.parse($window.localStorage.getItem('campaignAudiencePlatformLocal'));
                                    angular.forEach($scope.platformSelected, function (selectedPlatform) {
                                        angular.forEach($scope.selectPlatformData, function (platform) {
                                            if (selectedPlatform.name == platform.name) {
                                                platform.Selected = true;
                                            }
                                        })

                                    })
                                }

                                if ($window.localStorage.getItem('campaignAudienceTargetLocal')) {
                                    $scope.targetChecked = true;
                                    if ($window.localStorage.getItem('campaignAudienceTargetInLocal')) {
                                        var radio1 = JSON.parse($window.localStorage.getItem('campaignAudienceTargetInLocal'));
                                        $scope.radioTarget = 1;
                                        $scope.radio_selected1 = $window.localStorage.getItem('campaignAudienceTargetInLocal');
                                        $scope.radio_selected2 = "";
                                    }
                                    else if ($window.localStorage.getItem('campaignAudienceTargetExLocal')) {
                                        var radio2 = JSON.parse($window.localStorage.getItem('campaignAudienceTargetExLocal'));
                                        $scope.radioTarget = 2;
                                        $scope.radio_selected1 = "";
                                        $scope.radio_selected2 = $window.localStorage.getItem('campaignAudienceTargetExLocal');
                                    }

                                }

                                $scope.setLine();
                            }
                        
                    

                
            });



angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');

            $rootScope.progressLoader = "none";

        }

        //FETCH PLATFORM DETAILS

        $scope.deviceSelection = false;
        $scope.getPlatformDetails = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            var promises = [];
            $scope.puttargetFlag;
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=platforms';
            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                $scope.puttargetingcriteriaFlag;
                if (response.data.appStatus == 0) {
                    $scope.puttargetFlag = "0";

                    $scope.platformResponse = response.data.targetingCriteria;

                    angular.forEach($scope.platformResponse, function (value) {
                        $scope.selectPlatformData.push({
                            "name": value.name,
                            "targeting_type": value.targeting_type,
                            "targeting_value": value.targeting_value,
                            "Selected": false
                        })
                    });
                    angular.forEach($scope.selectPlatformData, function (data, index) {
                        if (data.name == "iOS") {
                            $scope.showIOSSelection[data.targeting_value] = false;
                        }
                        if (data.name == "Android") {
                            $scope.showAndroidSelection[data.targeting_value] = false;
                        }

                    })
                }
                else {
                    $scope.puttargetFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.puttargetFlag == "0") {
                    if ($scope.selectPlatformData) {
                        $scope.getAllDeviceDetails();
                    }

                }
            });

        };

        //SELECT PLATFORMS AND DEVICES OPTION

        $scope.selectDeviceandPlatform = function (platform, index, checked) {
            if (checked == true) {
                if (platform.name == "iOS") {
                    $scope.showIOSSelection[index] = true;
                    $scope.modifySelectedIOS[index] = false;
                    $scope.modifyAllIOS[index] = false;
                    angular.forEach($scope.iosDeviceData, function (item) {
                        if (item) {
                            item.Selected = true;
                            $scope.checkIOS = true;
                            $scope.allIOS = true;
                            $scope.displayAll = true;
                            $scope.displayCount = false;
                            $scope.versionData = "4.0";
                        }
                    });
                    //console.log($scope.iosDeviceData);
                } else if (platform.name == "Android")
                {
                    $scope.showAndroidSelection[index] = true;
                    $scope.modifySelectedAndroid[index] = false;
                    $scope.modifyAllAndroid[index] = false;

                    if ($scope.manufacturerDetails) {

                        for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                            var data = $scope.manufacturerDetails[j];
                            angular.forEach($scope.rightAndroidContent[data], function (deviceBrand) {
                                if (deviceBrand) {
                                    deviceBrand.Selected = true;
                                    $scope.displayAllAndroid = true;
                                    $scope.displaySelectedAndroid = false;
                                    $scope.modifySelectedAndroid[index] = false;
                                    $scope.checkAndroid = true;
                                    $scope.allAndroid = true;
                                    $scope.versionAndroid = "Cupcake";
                                }
                            })
                        }
                    }
                }

            } else {
                $scope.deviceSelection = false;
                if (platform.name == "iOS") {
                    $scope.showIOSSelection[index] = false;
                    $scope.modifySelectedIOS[index] = false;
                    $scope.modifyAllIOS[index] = false;
                    angular.forEach($scope.iosDeviceData, function (item) {
                        if (item) {
                            item.Selected = false;
                            $scope.checkIOS = false;
                            $scope.allIOS = false;
                            $scope.displayAll = false;
                            $scope.displayCount = false;
                            $scope.versionData = "";
                        }
                    });

                    if ($scope.existingDeviceID) {
                        angular.forEach($scope.selectedIOSList, function (selectedVal) {
                            angular.forEach($scope.existingDeviceID, function (existingVal) {
                                if (selectedVal.targeting_value == existingVal.targeting_value) {
                                    if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                        $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                    }
                               }
                            })
                        })
                        $scope.selectedIOSList = [];
                    }
                    if ($scope.existingVersionID) {
                        angular.forEach($scope.existingVersionID, function (existingVal) {
                            if (existingVal.name) {
                                if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                    $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                }
                            }
                        })

                    }
                    if ($scope.existingPlatformID) {
                        angular.forEach($scope.existingPlatformID, function (existingVal) {
                            if (existingVal.name == platform.name) {
                                if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                    $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                }
                            }
                        })

                    }
                } else if (platform.name == "Android")
                {
                    $scope.showAndroidSelection[index] = false;
                    $scope.modifySelectedAndroid[index] = false;
                    $scope.modifyAllAndroid[index] = false;
                    if ($scope.manufacturerDetails) {

                        for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                            var data = $scope.manufacturerDetails[j];
                            angular.forEach($scope.rightAndroidContent[data], function (deviceBrand) {
                                if (deviceBrand) {
                                    deviceBrand.Selected = false;
                                    $scope.displayAllAndroid = false;
                                    $scope.displaySelectedAndroid = false;
                                    $scope.modifySelectedAndroid[index] = false;
                                    $scope.checkAndroid = false;
                                    $scope.allAndroid = false;
                                    $scope.versionAndroid = "";
                                }
                            })
                        }
                    }
                    if ($scope.existingDeviceID) {
                        angular.forEach($scope.selectedAndroidList, function (selectedVal) {
                            angular.forEach($scope.existingDeviceID, function (existingVal) {
                                if (selectedVal.targeting_value == existingVal.targeting_value) {
                                    if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                        $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                    }
                                }
                            })
                        })
                        $scope.selectedAndroidList = [];
                    }
                    if ($scope.existingVersionID) {
                        angular.forEach($scope.existingVersionID, function (existingVal) {
                            if (existingVal.name) {
                                if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                    $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                }
                            }
                        })

                    }
                    if ($scope.existingPlatformID) {
                        angular.forEach($scope.existingPlatformID, function (existingVal) {
                            if (existingVal.name == platform.name) {
                                if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                    $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                }
                            }
                        })

                    }

                }
            }
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $scope.setLine();
        }

        //FETCH ANDROID ADN IOS DEVICES 

       $scope.getAllDeviceDetails = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            var promises = [];
            $scope.allDeviceFlag;
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=devices';

            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.allDeviceFlag = "0";

                    if (response.data.targetingCriteria) {
                        $scope.allDeviceData = response.data.targetingCriteria;
                    }
                }
                else {
                    $scope.allDeviceFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                   $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            }));

            $q.all(promises).finally(function () {
                if ($scope.allDeviceFlag == "0") {
                    $scope.assignDeviceDetails($scope.allDeviceData);
                    $scope.getPlatformVersions();

                }
            });

        }

        //ASSIGN ANDROID & IOS DEVICE DATA

        $scope.assignDeviceDetails = function (allDeviceData) {

            for (i = 0; i < $scope.allDeviceData.length; i++) {

                if ($scope.allDeviceData[i].platform == "Android") {
                    $scope.androidPopupData.push($scope.allDeviceData[i]);
                } else if ($scope.allDeviceData[i].platform == "iOS") {
                    $scope.iOSPopupData.push($scope.allDeviceData[i]);
                }
            }

            //ios device list
            $scope.iosDeviceData = $scope.iOSPopupData;
            //android device list
            $scope.androidDeviceData = $scope.androidPopupData;

            for (var i = 0; i < $scope.androidDeviceData.length; i++)
            {
                var str = $scope.androidDeviceData[i].manufacturer;
                if ($scope.manufacturerDetails.indexOf(str) == -1)
                {
                    $scope.manufacturerDetails.push($scope.androidDeviceData[i].manufacturer);
                }
            }
            //console.log($scope.manufacturerDetails);

            //SPLITTING EACH DEVICE BASED ON BRAND
            $scope.devicelist = [];
            for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {

                var data = $scope.manufacturerDetails[j];
                angular.forEach($scope.androidDeviceData, function (deviceBrand) {

                    if (data == deviceBrand.manufacturer) {
                        $scope.devicelist.push({
                            'manufacturer': deviceBrand.manufacturer,
                            'name': deviceBrand.name,
                            'platform': deviceBrand.platform,
                            'targeting_type': deviceBrand.targeting_type,
                            'targeting_value': deviceBrand.targeting_value,
                            'Selected': false
                        });
                    }
                })
                $scope.rightAndroidContent[data] = $scope.devicelist;
                $scope.devicelist = [];
            }
            //console.log($scope.rightAndroidContent);

        }

//FETCH PLATFORM VERSIONS 

        $scope.getPlatformVersions = function () {
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var promises = [];

            $scope.getTargetCriteriaFlag;
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=platform_versions';
            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.getTargetCriteriaFlag = "0";
                    if (response.data.targetingCriteria) {
                        $scope.allVersionData = response.data.targetingCriteria;
                    }

                }
                else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            if (response.data.networkError.error_user_title) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                            else {
                                $scope.errorpopupHeading = "Error";
                                $scope.errorMsg = response.data.networkError[0].message;
                            }
                        }
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

            }));
            $q.all(promises).finally(function () {
                if ($scope.getTargetCriteriaFlag == "0") {
                    $scope.assignVersionDetails($scope.allDeviceData);
                }
            });


        }
        //ASSIGN PLATFORM VERSION DETAILS 

        $scope.assignVersionDetails = function () {



            angular.forEach($scope.allVersionData, function (version) {
                if (version.platform == "iOS") {
                    $scope.iOSVersions.push(version)
                } else if (version.platform == "Android") {
                    $scope.androidVersions.push(version)
                }
            });
            //console.log("VERSIONS");

        }

        //FETCH TV MARKET DATA 
        $scope.tvMarketResponse = [];
        $scope.getTVMarketDetails = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
           };

            var promises = [];
            $scope.tvMarketFlag;
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=tv_markets';

            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {


                if (response.data.appStatus == 0) {
                    $scope.tvMarketFlag = "0";
                    if (response.data.targetingCriteria) {
                        $scope.tvMarketResponse = response.data.targetingCriteria;


                    }

                } else {
                    $scope.tvMarketFlag = "1";
                    if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                }

            }));

            $q.all(promises).finally(function () {
                if ($scope.tvMarketFlag == "0") {
                    $scope.assignTVMarketDetails();
                }
                $scope.setFlag = true;
            });
        }

        $scope.tvMarketData = [];
        $scope.assignTVMarketDetails = function () {
            angular.forEach($scope.tvMarketResponse, function (data) {
                $scope.tvMarketData.push(data);
            });
            $scope.setLine();
        }


        //FETCH TV SHOWS DATA 
        $scope.tvShowsResponse = [];
        $scope.getTVShowsDetails = function () {

            $scope.ngTVShowLoader = true;
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&tvMarketLocale=' + $scope.tvTargetingMarket + '&q=' + $scope.tvTargetingSearch + '&targetingCriteria=tv_shows';

            twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.tvShowsResponse = response.data.targetingCriteria;
                    $scope.ngTVShowLoader = false;
                    $scope.setLine();
                }
                else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            if (response.data.networkError.error_user_title) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                            else {
                                $scope.errorpopupHeading = "Error";
                                $scope.errorMsg = response.data.networkError[0].message;
                            }
                        }
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            });

        }

        $scope.$watch('tvTargetingSearch', function () {
           if ($scope.tvShowsResponse != 'undefined' && $scope.tvShowsResponse != '' && $scope.tvShowsResponse != null) {
                $scope.addTVShows($scope.tvTargetingSearch);
            }
            ;
        });

        $scope.campaignAudienceTVShowKeyArr = [];
        $scope.campaignAudienceTVShowArr = [];
        $scope.addTVShows = function (val) {
            $scope.ngTVShowLoader = false;
            //console.log($scope.tvShowsResponse);
            if (val != '' && val.length > 2 && $scope.tvShowsResponse != '') {
                var Rdata = $scope.tvShowsResponse.find(function (ele) {
                    return (ele.name).trim() == val.trim();
                });

                var Edata = $scope.campaignAudienceLanguageArr.find(function (ele) {
                    return (ele.name).trim() == val.trim();
                });

                if (Rdata && !Edata) {
                    var m_Obj = {"id": Rdata.id, "name": Rdata.name};
                    $scope.campaignAudienceTVShowArr.push(m_Obj);
                    $scope.campaignAudienceTVShowKeyArr.push(Rdata.id);
                    $scope.tvTargetingSearch = '';
                }

            }
            ;
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("campaignAudienceTVShowArr", JSON.stringify($scope.campaignAudienceTVShowArr));
            $scope.setLine();
        };

        $scope.removeTVShows = function (item) {

            if ($window.localStorage.getItem("campaignState") == "edit" && item.existingid != '' && item.existingid != undefined) {
                var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                    return d === item.existingid;
                }, true);
                if (MArray[0] != '' && MArray[0] != undefined) {
                    $scope.existingTargetingCriteriaArray.push(MArray[0]);
                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));


            if ($scope.campaignAudienceTVShowKeyArr.indexOf(item.id) > -1) {
                $scope.campaignAudienceTVShowKeyArr.splice($scope.campaignAudienceTVShowKeyArr.indexOf(item.id), 1);
                var a = _.findWhere($scope.campaignAudienceTVShowArr, {id: item.id});
                var b = _.indexOf($scope.campaignAudienceTVShowArr, a);
                $scope.campaignAudienceTVShowArr.splice(b, 1);
                //$rootScope.freezeFlag = true;
                angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                //$rootScope.overLayAudience = true;
                $window.localStorage.setItem("campaignAudienceTVShowArr", JSON.stringify($scope.campaignAudienceTVShowArr));
            }
            $scope.setLine();
        }

        $scope.removeAllTVTargeting = function () {

            if ($window.localStorage.getItem("campaignState") == "edit") {
                for (var i = 0; i < $scope.campaignAudienceTVShowArr.length; i++) {
                    if ($scope.campaignAudienceTVShowArr[i].existingid != '' && $scope.campaignAudienceTVShowArr[i].existingid != undefined) {
                        var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                            return d === $scope.campaignAudienceTVShowArr[i].existingid;
                        }, true);
                        if (MArray[0] != '' && MArray[0] != undefined) {
                            $scope.existingTargetingCriteriaArray.push(MArray[0]);
                            $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                        }
                    }
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));

            $scope.campaignAudienceTVShowArr = [];
            $scope.campaignAudienceTVShowKeyArr = [];
            // $rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("campaignAudienceTVShowArr", '');
            $scope.setLine();
        }

        //FETCH LOCATION DETAILS
        $scope.getLocationDetails = function () {
            //GET LOCATION SEARCH RESULT BY LETTER

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };



            if ($scope.campaignAudienceLocations.length > 2 && $scope.campaignAudienceLocations != "" && $scope.campaignAudienceLocations != undefined) {
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=locations&q=' + $scope.campaignAudienceLocations;
                $scope.ngLocLoader = true;
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                    if (response.data.appStatus == 0) {
                        $scope.LocationDetails = response.data.targetingCriteria;
                        //$scope.campaignAudienceLocations="";  
                        $scope.mapLocation = true;
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    $scope.ngLocLoader = false;


                });
            }

        };


        $scope.addGeoLocation = function (val) {


            if (val != '' && val.length > 2) {
                var SVal = val.split("/")[0];

                var Rdata = $scope.LocationDetails.find(function (ele) {
                    if ((ele.name).trim() == SVal.trim()) {

                        return ele;
                    }
                    ;
                });
                if (Rdata) {

                    $scope.campaignAudienceLocationsArr.push({"name": Rdata.name, "value": Rdata.targeting_value, "country_code": Rdata.country_code});
                    $scope.campaignAudienceLocationsArr = $scope.removeDuplicates($scope.campaignAudienceLocationsArr, "value");
                    $scope.LocationDetails = [];
                    if ($scope.locationJSON.indexOf(Rdata.targeting_value) == -1) {
                        $scope.locationJSON.push(Rdata.targeting_value);
                        angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});

                    }
                    $window.localStorage.setItem("campaignAudienceLocationsLocal", JSON.stringify($scope.campaignAudienceLocationsArr));
                    if ($scope.campaignAudienceLocationsArr.length == 1) {

                        if ($scope.campaignAudienceLocationsArr[0].country_code == 'US' || $scope.campaignAudienceLocationsArr[0].country_code == 'GB') {
                            $scope.tvbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;
                            $scope.limitbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;

                            $scope.disabletvbehaviourMarket = true;
                            $scope.disabletvbehaviourShows = false;

                            $scope.disablelimitbehaviourMarket = true;
                            $scope.disablelimitbehaviourShows = false;

                            $scope.disabletvTargetingMarket = true;
                            $scope.disabletvTargetingShows = false;

                            $scope.getBehaviourChildDetails($scope.tvbehaviourMarket);


                        } else {
                            $scope.tvTargetingMarket = 'en-US';
                            $scope.tvbehaviourMarket = 'US';
                            $scope.limitbehaviourMarket = 'US';

                            $scope.disabletvbehaviourMarket = true;
                            $scope.disabletvbehaviourShows = true;

                            $scope.disablelimitbehaviourMarket = true;
                            $scope.disablelimitbehaviourShows = true;

                            $scope.disabletvTargetingMarket = true;
                            $scope.disabletvTargetingShows = false;

                            $scope.DTBehaviourArray = [];
                            $scope.DTBehaviourNameArray = [];

                            $scope.DTlimitBehaviourArray = [];
                            $scope.DTlimitBehaviourNameArray = [];

                            $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                            $window.localStorage.setItem("DTBehaviourNameArray", '');

                        }
                        //$scope.disabletvTargetingMarket = false;
                        //$scope.disabletvTargetingShows = false;
                        var results = $filter('filter')($scope.tvMarketData, {country_code: $scope.campaignAudienceLocationsArr[0].country_code}, true);

                        if (results.length > 0) {
                            $scope.tvTargetingMarket = results[0].locale;
                            $scope.disabletvTargetingMarket = true;
                            $scope.disabletvTargetingShows = false;
                        }

                        /*angular.forEach($scope.tvMarketData, function(val, key){
                         if(val.country_code==$scope.campaignAudienceLocationsArr[0].country_code && val.name==$scope.campaignAudienceLocationsArr[0].name){
                         //console.log(val.locale);
                         $scope.tvTargetingMarket = val.locale;
                         $scope.disabletvTargetingMarket = true;
                         $scope.disabletvTargetingShows = false;
                         }
                         });*/
                    } else {
                        $scope.disabletvbehaviourMarket = true;
                        $scope.disabletvbehaviourShows = true;

                        $scope.disablelimitbehaviourMarket = true;
                        $scope.disablelimitbehaviourShows = true;

                        $scope.disabletvTargetingMarket = true;
                        $scope.disabletvTargetingShows = true;

                        $scope.DTBehaviourArray = [];
                        $scope.DTBehaviourNameArray = [];

                        $scope.DTlimitBehaviourArray = [];
                        $scope.DTlimitBehaviourNameArray = [];

                        $scope.campaignAudienceTVShowArr = [];
                        $scope.campaignAudienceTVShowKeyArr = [];

                        $window.localStorage.setItem("campaignAudienceTVShowArr", '');
                        $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                        $window.localStorage.setItem("DTBehaviourNameArray", '');

                    }
                    $scope.campaignAudienceLocations = "";

                }


            }
            ;

            // $rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $scope.setLine();
            $scope.stepcheck();
        };


        $scope.$watch('campaignAudienceLocations', function () {
            if ($scope.LocationDetails != 'undefined' && $scope.LocationDetails != '' && $scope.LocationDetails != null) {
                //angular.element('#step1').css('background-color', '#95D2B1');                               
                $scope.addGeoLocation($scope.campaignAudienceLocations);
            }
            ;

        });
        $scope.stepcheck = function(){
            if($scope.campaignAudienceLocationsArr.length > 0){				
		if(($scope.radioTarget == 1 && $scope.radio_selected1 == '') ||($scope.radioTarget == 2 && $scope.radio_selected2 == '')){				
                    angular.element('#step1').css('background-color', '#C2C2C2');					
                }else{				
                    angular.element('#step1').css('background-color', '#95d2b1');					
		}
            }else{
                angular.element('#step1').css('background-color', '#C2C2C2');
            }
        };


        $scope.removeGeoLocation = function (item) {
            if ($scope.locationFlag == true && $scope.matchedLocation.indexOf(item.name) > -1) {
                $scope.matchedLocation.splice($scope.matchedLocation.indexOf(item.name), 1);

                $scope.userSuggestionLocationBlock = false;
                $scope.locationFlag = false;

            }
            $scope.campaignAudienceLocationsArr.splice($scope.campaignAudienceLocationsArr.indexOf(item), 1);
            $scope.locationJSON.splice($scope.locationJSON.indexOf(item), 1);
            if ($scope.campaignAudienceLocationsArr.length == 1) {

                if ($scope.campaignAudienceLocationsArr[0].country_code == 'US' || $scope.campaignAudienceLocationsArr[0].country_code == 'GB') {
                    $scope.tvbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;
                    $scope.limitbehaviourMarket = $scope.campaignAudienceLocationsArr[0].country_code;

                    $scope.disabletvbehaviourMarket = true;
                    $scope.disabletvbehaviourShows = false;

                    $scope.disablelimitbehaviourMarket = true;
                    $scope.disablelimitbehaviourShows = false;

                    $scope.disabletvTargetingMarket = true;
                    $scope.disabletvTargetingShows = false;

                    $scope.getBehaviourChildDetails($scope.tvbehaviourMarket);

                } else {
                    $scope.tvTargetingMarket = 'en-US';
                    $scope.tvbehaviourMarket = 'US';
                    $scope.limitbehaviourMarket = 'US';

                    $scope.disabletvbehaviourMarket = true;
                    $scope.disabletvbehaviourShows = true;

                    $scope.disablelimitbehaviourMarket = true;
                    $scope.disablelimitbehaviourShows = true;

                    $scope.disabletvTargetingMarket = true;
                    $scope.disabletvTargetingShows = false;

                    $scope.DTBehaviourArray = [];
                    $scope.DTBehaviourNameArray = [];

                    $scope.DTlimitBehaviourArray = [];
                    $scope.DTlimitBehaviourNameArray = [];

                    $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                    $window.localStorage.setItem("DTBehaviourNameArray", '');

                }
                //$scope.disabletvTargetingMarket = false;
                //$scope.disabletvTargetingShows = false;
                var results = $filter('filter')($scope.tvMarketData, {country_code: $scope.campaignAudienceLocationsArr[0].country_code}, true);
                if (results.length > 0) {
                    $scope.tvTargetingMarket = results[0].locale;
                    $scope.disabletvTargetingMarket = true;
                    $scope.disabletvTargetingShows = false;
                }
                /*angular.forEach($scope.tvMarketData, function(val, key){
                 if(val.country_code==$scope.campaignAudienceLocationsArr[0].country_code && val.name==$scope.campaignAudienceLocationsArr[0].name){
                 //console.log(val.locale);
                 $scope.tvTargetingMarket = val.locale;
                 $scope.disabletvTargetingMarket = true;
                 $scope.disabletvTargetingShows = false;
                 }
                 });*/
            } else {
                $scope.disabletvbehaviourMarket = true;
                $scope.disabletvbehaviourShows = true;

                $scope.disablelimitbehaviourMarket = true;
                $scope.disablelimitbehaviourShows = true;

                $scope.disabletvTargetingMarket = true;
                $scope.disabletvTargetingShows = true;

                $scope.DTBehaviourArray = [];
                $scope.DTBehaviourNameArray = [];

                $scope.DTlimitBehaviourArray = [];
                $scope.DTlimitBehaviourNameArray = [];
                // angular.element('#step1').css('background-color', '#C2C2C2'); 
                $window.localStorage.setItem("DTlimitBehaviourNameArray", '');
                $window.localStorage.setItem("DTBehaviourNameArray", '');

            }
            $scope.campaignAudienceTVShowArr = [];
            $scope.campaignAudienceTVShowKeyArr = [];
            $window.localStorage.setItem("campaignAudienceTVShowArr", '');
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $scope.stepcheck();
            $scope.setLine();

        };


        // FETCH LANGUAGE DETAILS 

        $scope.getLanguageDetails = function () {
            $scope.ngLanLoader = true
            if ($scope.campaignAudienceLanguage != '' && $scope.campaignAudienceLanguage != undefined) {


                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };

                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=languages&q=' + $scope.campaignAudienceLanguage;

                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.LanguageDetails = response.data.targetingCriteria

                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                        $scope.campaignAudienceLanguage = '';
                    } else {
                        $scope.campaignAudienceLanguage = '';
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    $scope.ngLanLoader = false;

                });

            }
        }

        $scope.$watch('campaignAudienceLanguage', function () {
            if ($scope.LanguageDetails != 'undefined' && $scope.LanguageDetails != '' && $scope.LanguageDetails != null) {
                $scope.addLanguage($scope.campaignAudienceLanguage);
            }
            ;
        });

        $scope.addLanguage = function (val) {

            if (val != '' && val.length > 2) {
                var Rdata = $scope.LanguageDetails.find(function (ele) {
                    if ((ele.name).trim() == val.trim()) {
                        return ele;

                    }
                });

                var Edata = $scope.campaignAudienceLanguageArr.find(function (ele) {
                    return (ele.name).trim() == val.trim();
                });

                if (Rdata && !Edata) {
                    $scope.campaignAudienceLanguageArr.push({"name": Rdata.name, "value": Rdata.targeting_value, "country_code": Rdata.country_code});
                    angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                    $window.localStorage.setItem("campaignAudienceLanguageLocal", JSON.stringify($scope.campaignAudienceLanguageArr));
                    var duplicateVal = Rdata.targeting_value;
                    if ($scope.campaignAudienceLanguageKeyArr.indexOf(duplicateVal) == -1) {
                        $scope.campaignAudienceLanguageKeyArr.push(Rdata.targeting_value);
                    }
                    $scope.campaignAudienceLanguage = '';
                }

            }
            ;
            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageKeyArr);
            $scope.LanguageKeyValues = {"languages": $scope.campaignAudienceLanguageKeyArr};

            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $scope.setLine();
        };

        $scope.removeLanguage = function (item) {

            if ($scope.languageFlag == true && $scope.matchedLanguage.indexOf(item.name) > -1) {
                $scope.matchedLanguage.splice($scope.matchedLanguage.indexOf(item), 1);
                //if($scope.matchedLanguage.length <= 0){
                $scope.userSuggestionLanguageBlock = false;
                $scope.languageFlag = false;
                //}
            }
            $scope.campaignAudienceLanguageKeyArr.splice($scope.campaignAudienceLanguageKeyArr.indexOf(item), 1);
            $scope.campaignAudienceLanguageArr.splice($scope.campaignAudienceLanguageArr.indexOf(item), 1);

            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);

            //$rootScope.freezeFlag = true;                   
            //$rootScope.overLayAudience = true;
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $scope.setLine();
        };


        //SET AGE

        $scope.campaignAudienceAgeFrom = '13';
        $scope.campaignAudienceAgeTo = '24';


        $scope.ageFromArr =
                [
                    {Key: "None", Value: "None"},
                    {Key: "13", Value: "13"},
                    {Key: ">13", Value: "13+"},
                    {Key: "18", Value: "18"},
                    {Key: ">18", Value: "18+"},
                    {Key: "21", Value: "21"},
                    {Key: ">21", Value: "21+"},
                    {Key: "25", Value: "25"},
                    {Key: ">25", Value: "25+"},
                    {Key: "35", Value: "35"},
                    {Key: ">35", Value: "35+"},
                    {Key: ">50", Value: "50+"}


                ];

        $scope.endingAge =
                [
                    {'id': "13", 'value': "24", 'target': "AGE_13_TO_24"},
                    {'id': "13", 'value': "34", 'target': "AGE_13_TO_34"},
                    {'id': "13", 'value': "49", 'target': "AGE_13_TO_49"},
                    {'id': "13", 'value': "54", 'target': "AGE_13_TO_54"},
                    {'id': "18", 'value': "34", 'target': "AGE_18_TO_34"},
                    {'id': "18", 'value': "49", 'target': "AGE_18_TO_49"},
                    {'id': "18", 'value': "54", 'target': "AGE_18_TO_54"},
                    {'id': "21", 'value': "34", 'target': "AGE_21_TO_34"},
                    {'id': "21", 'value': "49", 'target': "AGE_21_TO_49"},
                    {'id': "21", 'value': "54", 'target': "AGE_21_TO_54"},
                    {'id': "25", 'value': "49", 'target': "AGE_25_TO_49"},
                    {'id': "25", 'value': "54", 'target': "AGE_25_TO_54"},
                    {'id': "35", 'value': "49", 'target': "AGE_35_TO_49"},
                    {'id': "35", 'value': "54", 'target': "AGE_35_TO_54"}
                ]


        $scope.ageToArr = [
            {'id': "13", 'value': "24"},
            {'id': "13", 'value': "34"},
            {'id': "13", 'value': "49"},
            {'id': "13", 'value': "54"}];
        $scope.disableAge = false;
        $scope.sendcampaignAudienceAgeFrom = function (campaignAudienceAgeFrom) {
            if ($scope.campaignAudienceAgeFrom.indexOf("+") || $scope.campaignAudienceAgeFrom.indexOf("None")) {
                $scope.disableAge = false;
                $scope.campaignAudienceAgeFrom = campaignAudienceAgeFrom;
                $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);

                var ageList = [];
                for (i = 0; i < $scope.endingAge.length; i++) {
                    if ($scope.endingAge[i].id == $scope.campaignAudienceAgeFrom) {
                        ageList.push({'key': $scope.endingAge[i].id, 'value': $scope.endingAge[i].value, 'target': $scope.endingAge[i].target});
                    }
                }
                $scope.ageToArr = ageList;
                //$rootScope.freezeFlag = true;
                angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                //$rootScope.overLayAudience = true;                 
            } else {

                $scope.disableAge = true;

            }
            $scope.campaignAudienceAgeTo = $scope.ageToArr[0].value;
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.sendcampaignAudienceAgeTo = function (campaignAudienceAgeTo) {

            var minAge = $scope.campaignAudienceAgeFrom;

            $scope.campaignAudienceAgeTo = campaignAudienceAgeTo;

            if ($scope.campaignAudienceAgeTo != undefined) {

                angular.forEach($scope.endingAge, function (maxage) {
                    if (minAge == maxage.id && $scope.campaignAudienceAgeTo == maxage.value) {
                        $scope.setMaxAge = maxage.target;
                    }
                });
            }

            $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
            // $rootScope.freezeFlag = true;
            // angular.element('.stepfreeze').css({'opacity' : '0.9' , 'pointer-events' : 'none'});
            // $rootScope.overLayAudience = true;
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }


        $scope.$watch('campaignAudienceAgeTo', function (newVal, oldVal) {

            if (newVal != 'undefined' && newVal != '' && newVal != null) {
                if (newVal < $scope.campaignAudienceAgeFrom) {
                    $scope.campaignAudienceAgeTo = $scope.campaignAudienceAgeFrom;
                }
                ;
            }
        }, true);


        //SET GENDER 

        $scope.sendGender = function (campaignAudienceGender) {

            $scope.campaignAudienceGender = campaignAudienceGender;
            $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
            //$rootScope.freezeFlag = true;
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
        }


        // BROWSE IOS DEVICES


        $scope.indexValue = "";
        $scope.browseiOSDevices = function (index)
        {

            $scope.usernames = false;
            $scope.keywords = false;
            $scope.show = false;
            $scope.saveandexit = false;
            $scope.browseinterests = false;
            $scope.browseandselectevent = false;
            $scope.showBrowseAndriod = true;

            $scope.campaignaudience_verifyusernamebtn = false;
            $scope.campaignaudience_cancelbtn = false;
            $scope.campaignaudience_saveandexitbtn = false;
            $scope.campaignaudience_submitbtn = false;
            $scope.campaignaudience_verifyshowbtn = false;
            $scope.campaignaudience_donebtn = false;
            $scope.campaignaudienceCancelBtn = false;
            $scope.browseAndroidBtns = true;
            $scope.iosDeviceBrowser = true;
            $scope.browsemobilecarriers = false;
            $scope.indexValue = index;
            var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
            modalcampaignaudience.show();
            angular.element($('body').css("overflow-y", "hidden"));
        };

        // FOR ALL IOS DEVICE SELECTION    

        $scope.selectAlliOS = function () {

            if ($scope.checkIOS) {
                $scope.checkIOS = true;
            } else {
                $scope.checkIOS = false;
                $scope.allIOS = false;
            }
            angular.forEach($scope.iosDeviceData, function (item) {

                item.Selected = $scope.checkIOS;
                if (item.Selected)
                {
                    $scope.displayAll = true;
                    $scope.displayCount = false;
                } else {
                    $scope.displayAll = false;
                    $scope.displayCount = false;
                    $scope.checkCount = 0;
                }
            });
            //console.log($scope.selectPlatformData);
        };
        // EACH IOS DEVICE SELECTION         
        $scope.checkCount = 0;
        $scope.setCheckAll = function (item) {
            if ($scope.checkIOS && !item.Selected) {
                $scope.checkIOS = false;
                $scope.allIOS = false;

            }
            $scope.checkCount = 0;
            angular.forEach($scope.iosDeviceData, function (item) {
                if (item.Selected)
                    $scope.checkCount++;
            });
            $scope.checkIOS = ($scope.checkCount === $scope.iosDeviceData.length);
            if ($scope.checkCount == $scope.iosDeviceData.length) {
                $scope.displayAll = true;
                $scope.displayCount = false;
            } else {
                $scope.displayAll = false;
                $scope.displayCount = true;
            }
        };


        //INCLUDE ALL IOS DEVICE
        $scope.selectAllIOSDevices = function (allIOS) {
            var index = $scope.indexValue;
            if (index == undefined) {
                index = 0;
            }
            if (allIOS) {
                //console.log($scope.iosDeviceData);
                angular.forEach($scope.iosDeviceData, function (item) {
                    item.Selected = true;
                    $scope.checkIOS = true;
                    $scope.displayAll = true;
                    $scope.displayCount = false;
                    $scope.modifyAllIOS[index] = true;
                    $scope.showIOSSelection[index] = false;
                    //$scope.showIOSSelection[index] = true;
                    $scope.versionData = "4.0";
                });
            } else {
                angular.forEach($scope.iosDeviceData, function (item) {
                    item.Selected = false;
                    $scope.checkIOS = false;
                    $scope.displayAll = false;
                    $scope.showIOSSelection[index] = true;
                    $scope.versionData = "";
                });
            }
        }


        // SUBMIT IOS DEVICE SELECTION

        $scope.submitIOSDevice = function () {
            var index = $scope.indexValue;
            if (index == undefined || index == "") {
                index = 0;
            }
            $scope.browseIOS = false;
            $scope.showBrowseAndriod = false;
            $scope.selectedIOSList = [];
            angular.forEach($scope.iosDeviceData, function (item) {
                if (item.Selected) {
                    $scope.selectedIOSList.push(item);
                }

            })
            $window.localStorage.setItem("campaignAudienceIOSLocal", JSON.stringify($scope.selectedIOSList));
            //console.log($scope.selectedIOSList.length)

            if ($scope.selectedIOSList.length == 0 || $scope.selectedIOSList.length == undefined || $scope.selectedIOSList.length == "") {

                $scope.showIOSSelection[index] = true;
                $scope.modifyAllIOS[index] = false;
                $scope.modifySelectedIOS[index] = false;

            } else {
                if ($scope.displayAll == true) {
                    $scope.modifyAllIOS[index] = true;
                    $scope.showIOSSelection[index] = false;
                    $scope.modifySelectedIOS[index] = false;
                } else if ($scope.displayCount == true) {
                    $scope.modifyAllIOS[index] = false;
                    $scope.showIOSSelection[index] = false;
                    $scope.modifySelectedIOS[index] = true;
                }

            }
            angular.element($('body').css("overflow-y", "scroll"));

        }

        $scope.selectVersions = function (versionName) {
            $scope.selectedVersion = versionName;
            $window.localStorage.setItem("campaignAudienceIOsVersion", $scope.selectedVersion);
        };


        //BROWSE ANDROID DEVICE 

        $scope.browseAndroidDevices = function (index)
        {


            $scope.usernames = false;
            $scope.keywords = false;
            $scope.show = false;
            $scope.saveandexit = false;
            $scope.browseinterests = true;
            $scope.browseandselectevent = false;
            $scope.showBrowseAndriod = true;
            $scope.campaignaudience_verifyusernamebtn = false;
            $scope.campaignaudience_cancelbtn = false;
            $scope.campaignaudience_saveandexitbtn = false;
            $scope.campaignaudience_submitbtn = false;
            $scope.campaignaudience_verifyshowbtn = false;
            $scope.campaignaudience_donebtn = false;
            $scope.campaignaudienceCancelBtn = false;
            $scope.browseAndroidBtns = true;
            $scope.browsemobilecarriers = false;
            $scope.iosDeviceBrowser = false;
            var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
            modalcampaignaudience.show();
            $scope.androidIndex = index;
            $scope.toggleAndroidTab();
            angular.element($('body').css("overflow-y", "hidden"));
        };

        $scope.rightAndroidData = [];
        $scope.setInitAndroid = function (brandName) {
            $scope.rightAndroidData = $scope.rightAndroidContent[brandName];
            angular.forEach($scope.manufacturerDetails, function (value, key) {
                angular.element('#tabAndroid' + (key + 1)).css('outline', 'none')
            });
            angular.element('#tabAndroid' + 1).css('background', '#ffffff');
            angular.element('#tabAndroid' + 1).css('border-left-color', '#ffb75c');
        };


        $scope.toggleAndroidTab = function (_obj, _this) {
            if (_obj == undefined) {
                var _obj = 0;
            }
            //console.log($scope.rightAndroidContent);
            if (_this == undefined) {
                $scope.defaultDevice = $scope.manufacturerDetails[0];
                $scope.rightAndroidData = $scope.rightAndroidContent[$scope.defaultDevice];
                $scope.selectedBrand = $scope.defaultDevice;
            } else {

                $scope.rightAndroidData = $scope.rightAndroidContent[_this];
                //console.log($scope.rightAndroidData);
                $scope.selectedDevices = [];
                angular.forEach($scope.rightAndroidData, function (selectedList) {
                    if (selectedList.Selected) {
                        $scope.selectedDevices.push(selectedList);
                    }

                })
                if ($scope.selectedDevices.length != $scope.rightAndroidData.length) {
                    $scope.checkAndroid = false;
                } else {
                    $scope.checkAndroid = true;
                }
                $scope.selectedBrand = _this;

            }

            angular.forEach($scope.manufacturerDetails, function (value, key) {
                //console.log('#tab',key+1)
                angular.element('#tabAndroid' + (key + 1)).css('background', '#f0f0f0');
                angular.element('#tabAndroid' + (key + 1)).css('border-left', '5px solid #e4e4e4');
                angular.element('#tabAndroid' + (key + 1)).css('border-right', '4px solid #e4e4e4');
                angular.element('#tabAndroid' + (key + 1)).css('outline', 'none')
           });
            angular.element('#tabAndroid' + (_obj + 1)).css('background', '#ffffff');
            angular.element('#tabAndroid' + (_obj + 1)).css('border-left-color', '#ffb75c');
            angular.element('#tabAndroid' + (_obj + 1)).css('border-right', '4px solid #ffffff');

        }

        $scope.closeAndroidBrowser = function () {
            $scope.showBrowseAndriod = false;
            angular.element($('body').css("overflow-y", "scroll"));
        }


        //SELECT ALL DEVICES BRAND WISE                 

        $scope.selectAllAndroid = function (checkedValue) {

            $scope.lst = [];
            if (checkedValue) {
                $scope.checkAndroid = true;
                angular.forEach($scope.rightAndroidData, function (item) {
                    item.Selected = $scope.checkAndroid;
                });

            } else {

                $scope.checkAndroid = false;
                $scope.allAndroid = false;
                angular.forEach($scope.rightAndroidData, function (item) {
                    item.Selected = $scope.checkAndroid;

                });
            }

            for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                var data = $scope.manufacturerDetails[j];
                angular.forEach($scope.rightAndroidContent[data], function (value) {
                    if (value.Selected) {
                        $scope.lst.push(value);
                    }
                })
            }
            //console.log($scope.lst.length);
            $scope.checkAndroidCount = $scope.lst.length;
            if ($scope.checkAndroidCount > 0) {
                $scope.displayAllAndroid = false;
                $scope.displaySelectedAndroid = true;
            } else {
                $scope.displayAllAndroid = false;
                $scope.displaySelectedAndroid = false;
            }

        }

        //SELECT SINGLE DEVICE 

        $scope.setCheckedAndroid = function (item) {
            $scope.selectedList = [];
           if ($scope.checkAndroid && !item.Selected) {
                $scope.checkAndroid = false;
                $scope.allAndroid = false;
            }

            for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                var data = $scope.manufacturerDetails[j];
                angular.forEach($scope.rightAndroidContent[data], function (deviceBrand) {
                    if (deviceBrand.Selected) {
                        $scope.selectedList.push(deviceBrand);
                    }
                })
            }
            //console.log("SELECTED ANDROID");
            //console.log($scope.selectedList.length);
            $scope.checkAndroidCount = $scope.selectedList.length;
            if ($scope.checkAndroidCount > 0) {
                $scope.displayAllAndroid = false;
                $scope.displaySelectedAndroid = true;
            } else {
                $scope.displayAllAndroid = false;
                $scope.displaySelectedAndroid = false;

            }

        }

        $scope.selectAndroidVersion = function (versionName) {
            $scope.selectedVersionName = versionName;
            $window.localStorage.setItem("campaignAudienceAndroidVerLocal", $scope.selectedVersionName);
        }

// SUBMIT ANDROID DEVICE SELECTION                                                

        $scope.submitSelectedAndroid = function () {
            var indexVal = $scope.androidIndex;
            if (indexVal == undefined) {
                indexVal = 1;
            }
            $scope.browseAndroid = false;
            $scope.showBrowseAndriod = false;
            $scope.showAndroidSelection[indexVal] = false;
            $scope.selectedAndroidList = [];
            for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                var data = $scope.manufacturerDetails[j];
                angular.forEach($scope.rightAndroidContent[data], function (deviceBrand) {
                    if (deviceBrand.Selected) {
                        $scope.selectedAndroidList.push(deviceBrand);
                    }
                })
            }
            $window.localStorage.setItem("campaignAudienceAndroidLocal", JSON.stringify($scope.selectedAndroidList));
            //console.log($scope.selectedAndroidList.length);              

            if ($scope.selectedAndroidList.length > 0) {
                if ($scope.allAndroid) {
                    $scope.modifySelectedAndroid[indexVal] = false;
                    $scope.modifyAllAndroid[indexVal] = true;
                } else {
                    $scope.modifySelectedAndroid[indexVal] = true;
                    $scope.modifyAllAndroid[indexVal] = false;
                    $scope.showAndroidSelection[indexVal] = false;
                }

            } else {
                $scope.showAndroidSelection[indexVal] = true;
               $scope.modifyAllAndroid[indexVal] = false;
                $scope.modifySelectedAndroid[indexVal] = false;

            }
            angular.element($('body').css("overflow-y", "scroll"));

            if ($scope.allIOS) {

                if ($scope.existingDeviceID) {
                    angular.forEach($scope.selectedAndroidList, function (selectedVal) {
                        angular.forEach($scope.existingDeviceID, function (existingVal) {
                            if (selectedVal.targeting_value != existingVal.targeting_value) {
                                if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                    $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                                }
                            }
                        })
                    })
                }
                if ($scope.existingVersionID) {
                    angular.forEach($scope.existingVersionID, function (existingVal) {
                        if ($scope.versionAndroid == existingVal.name) {
                            if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                                $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                                $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                            }
                        }
                    })

                }
            }

        }

        //INCLUDE ALL ANDROID DEVICE
        $scope.modifyAllAndroid = [];
        $scope.includeAllAndroid = function (allAndroid) {

            var index = $scope.androidIndex;
            if (index == undefined) {

                index = 1;
            }
            //console.log($scope.allAndroid);
            if (allAndroid) {
                for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                    var data = $scope.manufacturerDetails[j];
                    angular.forEach($scope.rightAndroidContent[data], function (deviceCheck) {
                        deviceCheck.Selected = true;
                        $scope.displayAllAndroid = true;
                        $scope.checkAndroid = true;
                        $scope.displaySelectedAndroid = false;
                        $scope.versionAndroid = "Cupcake";
                    })
                }

            } else {

                for (var j = 0; j <= $scope.manufacturerDetails.length; j++) {
                    var data = $scope.manufacturerDetails[j];
                    angular.forEach($scope.rightAndroidContent[data], function (deviceCheck) {
                        deviceCheck.Selected = false;
                        $scope.displayAllAndroid = false;
                        $scope.checkAndroid = false;
                        $scope.versionAndroid = "";

                    })
                }

            }

        }


        //FETCH MOBILE CARRIERS DETAILS

        $scope.fetchMobileData = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=network_operators';
            var promises = [];

            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                if (response.data.appStatus == 0) {
                    $scope.countryCodeData = response.data.targetingCriteria;

                    for (var i = 0; i < $scope.countryCodeData.length; i++) {
                        var str = $scope.countryCodeData[i].country_code;
                        if ($scope.allCountryCode.indexOf(str) == -1) {
                            $scope.allCountryCode.push($scope.countryCodeData[i].country_code);
                        }
                    }
                }
                else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            if (response.data.networkError.error_user_title) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                            else {
                                $scope.errorpopupHeading = "Error";
                                $scope.errorMsg = response.data.networkError[0].message;
                            }
                        }
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            }));
            $q.all(promises).finally(function () {
                if ($scope.allCountryCode) {
                    $scope.fetchCountryName();

                }

            });

        }


//GET COUNTRY NAME FOR MOBILE CARRIERS


        $scope.fetchCountryName = function () {

            var promises = [];
            // $rootScope.progressLoader = "block";
            var data =
                    {
                        'userId': $window.localStorage.getItem("userId"),
                        'accessToken': $window.localStorage.getItem("accessToken")
                    };

            angular.forEach($scope.allCountryCode, function (code) {
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=locations&countryCode=' + code + '&locationType=COUNTRIES';
                promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.countryName.push(response.data.targetingCriteria);

                        if ($scope.countryName) {
                            angular.forEach($scope.countryName, function (cname, value) {
                                angular.forEach(cname, function (key) {
                                    if (code == key.country_code) {
                                        $scope.countryList.push(
                                                {
                                                    "countryCode": key.country_code,
                                                    "countryName": key.name,
                                                    "targeting_type": key.targeting_type,
                                                    "targeting_value": key.targeting_value
                                                })
                                        $scope.countryList = $filter('orderBy')($scope.countryList, "countryName", false);
										//console.log($scope.countryList);
                                    }
                                })

                            })

                        }
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');

                    } else {

                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }));


            });
            $q.all(promises).finally(function () {
			if ($scope.countryList) {
                    $scope.assignNetworkDetails();
                }
				$rootScope.progressLoader = "none";
				 if ($window.localStorage.getItem("campaignState") == "replication" && $rootScope.sameNetwork == false) {
                
                
//                $scope.setFlag = true;
//                if ($scope.setFlag) {
//                    $scope.updateCampaignAudience();
//                }
                console.log($scope.DTInterestNameArray.length);
                if ($scope.unmatchedLocation.length > 0 || ($scope.locationJSON.length < 1 && $scope.locationObjTwitter != undefined && $scope.locationObjTwitter != null && $scope.locationObjTwitter.length >= 1)) {
                    $scope.locationFlag = true;
                }
                if ($scope.ageFromArrValue.indexOf($scope.ageMinObjTwitter.toString()) == -1 || $scope.ageToArrValue.indexOf($scope.ageMaxObjTwitter.toString()) == -1) {
                    $scope.ageFlag = true;
                }
                console.log($scope.languageObjTwitter.length);
                console.log($scope.unmatchedLanguage);
                if ($scope.unmatchedLanguage.length > 0 || ($scope.campaignAudienceLanguageKeyArr.length < 1 && $scope.languageObjTwitter != undefined && $scope.languageObjTwitter != null && $scope.languageObjTwitter.length >= 1)) {
                    $scope.languageFlag = true;
                }
                console.log($scope.unmatchedInterest.length);
                if ($scope.unmatchedInterest.length > 0 || ($scope.DTInterestNameArray.length < 1 && $scope.targetingInterest != undefined && $scope.targetingInterest != null)) {
                    $scope.targetingFlag = true;
                }

                if ($scope.locationFlag == true) {
                    $scope.userSuggestionLocationBlock = true;
                    $scope.openUserSuggestion('userlocation');
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanguageBlock = false;
                    $scope.userSuggestionTargetingBlock = false;
                } else if ($scope.ageFlag == true) {
                    $scope.userSuggestionAgeBlock = true;
                    $scope.openUserSuggestion('userage');
                    $scope.userSuggestionLocationBlock = true;
                    $scope.userSuggestionLanguageBlock = false;
                    $scope.userSuggestionTargetingBlock = false;
                } else if ($scope.languageFlag == true) {
                    $scope.userSuggestionLanguageBlock = true;
                    $scope.openUserSuggestion('userlanguage');
                    $scope.userSuggestionLocationBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionTargetingBlock = false;
                } else if ($scope.targetingFlag == true) {
                    $scope.userSuggestionTargetingBlock = true;
                    $scope.openUserSuggestion('usertargeting');
                    $scope.userSuggestionLocationBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanguageBlock = false;
                }


                $scope.progressLoader = "none";
			}
			else{
				 $scope.updateCampaignAudience();
			}
            });

        };


        //ASSIGN MOBILE CARRIER  DETAILS 

        $scope.assignNetworkDetails = function () {


            $scope.operatorList = [];
            for (var i = 0; i < $scope.countryList.length; i++) {

                var data = $scope.countryList[i].countryCode;
                angular.forEach($scope.countryCodeData, function (network) {
                    if (data == network.country_code) {

                        $scope.operatorList.push({
                            'country_code': $scope.countryList[i].countryCode,
                            'country_name': $scope.countryList[i].countryName,
                            'name': network.name,
                            'optargeting_value': network.targeting_value,
                            'optargeting_type': network.targeting_type,
                            'ctargeting_value': $scope.countryList[i].targeting_value,
                            'ctargeting_type': $scope.countryList[i].targeting_type,
                            'Selected': false
                        });
                    }
                })
                $scope.mobileCarrierList[data] = $scope.operatorList;
                $scope.operatorList = [];
            }

        }

//SEARCH MOBILE CARRIERS

        $scope.getNetworkDetails = function () {


            if ($scope.campaignAudienceNetwork != '' && $scope.campaignAudienceNetwork != undefined && $scope.campaignAudienceNetwork.length > 2) {

                $scope.mobileCarrierSearchLoader = true;
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };


                //console.log($scope.campaignAudienceNetwork);

                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=network_operators&q=' + $scope.campaignAudienceNetwork;

                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.networkDetails = response.data.targetingCriteria;
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $scope.campaignAudienceNetwork = '';
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');

                    } else {

                        $rootScope.progressLoader = "none";
                        $scope.campaignAudienceNetwork = '';
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }


                    $scope.mobileCarrierSearchLoader = false;
                    //$rootScope.freezeFlag = true;
                    angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                    //$rootScope.overLayAudience = true;
                });

            }
        }

        $scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }

        $scope.addSearchedNetwork = function (val) {

            if (val != '' && val.length > 2) {
                var SVal = val.split("/")[0];
                var selectedNetwork = $scope.networkDetails.find(function (ele) {
                    if ((ele.name).trim() == SVal.trim()) {

                        return ele;
                    }
                    ;
                });
                if (selectedNetwork) {
                    //if($scope.mobileSearchData[name].indexOf(selectedNetwork.name) == -1){              
                    $scope.mobileSearchData.push({"name": selectedNetwork.name, "value": selectedNetwork.targeting_value});
                    $scope.networkJSON.push(selectedNetwork.targeting_value);
                    //$scope.combinedMobileData.push({"name":selectedNetwork.name,"value":selectedNetwork.targeting_value});
                    // }

                    //adding the searched item to the pop-up list 
                    for (var j = 0; j < $scope.countryList.length; j++) {
                        var data = $scope.countryList[j];
                        angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                            if (network.name == selectedNetwork.name)
                            {
                                network.Selected = true;
                            }
                        });
                    }
                }
                //combining browsed data and searched data
                if ($scope.combinedMobileData.length > 0)
                {
                    for (var j = 0; j < $scope.combinedMobileData.length; j++)
                    {
                        if ($scope.combinedMobileData[j].name == selectedNetwork.name) {
                            //searched data is already browsed one, so no need to push 
                        }
                        else
                        {
                            $scope.combinedMobileData.push({"name": selectedNetwork.name, "value": selectedNetwork.targeting_value});
                            break;
                        }
                    }
                }
                else
                {
                    $scope.combinedMobileData.push({"name": selectedNetwork.name, "value": selectedNetwork.targeting_value});

                }
                $scope.combinedMobileData = $scope.removeDuplicates($scope.combinedMobileData, "value");
                $scope.campaignAudienceNetwork = "";

            }
            ;

            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $scope.setLine();
        };
        $scope.$watch('campaignAudienceNetwork', function () {
            if ($scope.networkDetails != 'undefined' && $scope.networkDetails != '' && $scope.networkDetails != null) {
                $scope.addSearchedNetwork($scope.campaignAudienceNetwork);
            }
            ;
        });


        $scope.removeNetwork = function (item) {

            for (var j = 0; j < $scope.countryList.length; j++) {
                var data = $scope.countryList[j];
                angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                    if (network.name == item.name) {
                        network.Selected = false;
                    }
                })
            }

//                                            if($scope.mobileSearchData.length > 0){
//                            angular.forEach($scope.mobileSearchData,function(network){
//                                                                              if(network.name == item.name){ 
//                                                                                    $scope.mobileSearchData.splice($scope.mobileSearchData.indexOf(item), 1);
//                                                $scope.networkJSON.splice($scope.networkJSON.indexOf(item.targeting_value),1);                                                                                                 
//                                                                              }
//                                      });
//                                                            
//                                            }
            if ($scope.combinedMobileData.length > 0) {
                for (var i = 0; i < $scope.combinedMobileData.length; i++) {
                    if ($scope.combinedMobileData[i].name == item.name) {
                        $scope.combinedMobileData.splice($scope.combinedMobileData.indexOf(item), 1);
                        $scope.networkJSON.splice($scope.networkJSON.indexOf(item.targeting_value), 1);
                    }
                }

            }

            if ($scope.existingNetworkJSON) {
                angular.forEach($scope.existingNetworkJSON, function (existingVal) {
                    if (existingVal.name == item.name) {
                        if ($scope.existingTargetingCriteriaArray.indexOf(existingVal.existingid) == -1) {
                            $scope.existingTargetingCriteriaArray.push(existingVal.existingid);
                            $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                        }
                    }
                })

            }

//                                            if($scope.browserSelectedData.length > 0){
//                                                $scope.browserSelectedData.splice($scope.browserSelectedData.indexOf(item), 1);                                    
//                                                            $scope.networkJSON.splice($scope.networkJSON.indexOf(item.targeting_value),1);
//                                            }
            $window.localStorage.setItem("campaignAudienceMobileSearchLocal", JSON.stringify($scope.mobileSearchData));
            $window.localStorage.setItem("campaignAudienceMobileBrowseLocal", JSON.stringify($scope.browserSelectedData));
            $scope.setLine();
        };


        // SELECT MOBILE CARRIERS

        $scope.selectBrowseCarriers = function () {

            $scope.fetchMobileData();

        };
        $scope.enableBrowserCarrier = function () {

            $scope.usernames = false;
            $scope.keywords = false;
            $scope.show = false;
            $scope.saveandexit = false;
            $scope.browseinterests = false;
            $scope.browseandselectevent = false;
            $scope.showBrowseAndriod = true;

            $scope.campaignaudience_verifyusernamebtn = false;
            $scope.campaignaudience_cancelbtn = false;
            $scope.campaignaudience_saveandexitbtn = false;
            $scope.campaignaudience_submitbtn = false;
            $scope.campaignaudience_verifyshowbtn = false;
            $scope.campaignaudience_donebtn = false;
            $scope.campaignaudienceCancelBtn = false;
            $scope.browseAndroidBtns = true;
            $scope.browsemobilecarriers = true;
            $scope.iosDeviceBrowser = false;
            var modalcampaignaudience = $(".twittercampaignaudience-popup-add");
            modalcampaignaudience.show();
            $scope.toggleMobileCarrier();
            angular.element($('body').css("overflow-y", "hidden"));
        }

        //INIT MOBILE CARRIER DATA 

        $scope.rightMobileData = [];

        $scope.setInitMobileCarrier = function (countryName) {


            $scope.rightMobileData = $scope.mobileCarrierList[countryName];
            angular.forEach($scope.countryList, function (value, key) {
                angular.element('#tab' + (key + 1)).css('outline', 'none')
            });
            angular.element('#tab' + 1).css('background', '#ffffff');
            angular.element('#tab' + 1).css('border-left-color', '#ffb75c');
        };


        $scope.toggleMobileCarrier = function (_obj, _this) {
            if (_obj == undefined) {
                var _obj = 0;
            }

            if (_this == undefined) {
                $scope.defaultNetwork = $scope.countryList[0].countryCode;
                $scope.rightMobileData = $scope.mobileCarrierList[$scope.defaultNetwork];

            } else {
                $scope.rightMobileData = $scope.mobileCarrierList[_this];
            }

            angular.forEach($scope.countryList, function (value, key) {
                //console.log('#tabBrowse',key+1)         
                angular.element('#tabBrowse' + (key + 1)).css('background', '#f3f3f3');
                angular.element('#tabBrowse' + (key + 1)).css('border-left', '5px solid #e4e4e4');
                angular.element('#tabBrowse' + (key + 1)).css('border-right', '4px solid #e4e4e4');
                angular.element('#tabBrowse' + (key + 1)).css('outline', 'none')
            });
            //Active tabs                                                                         
            angular.element('#tabBrowse' + (_obj + 1)).css('background', '#ffffff');
            angular.element('#tabBrowse' + (_obj + 1)).css('border-left-color', '#ffb75c');
            angular.element('#tabBrowse' + (_obj + 1)).css('border-right', '4px solid #ffffff');

        }



        //SELECT MOBILE CARRIERS
        $scope.displaySelectedNetwork = [];
        $scope.cancelSelectedNet = [];
        $scope.checkAndroidCount = 0;
        $scope.selectedNetwork = [];
        $scope.checkedNetwork;
        $scope.setSelectedCarrier = function (item) {
            if (item.Selected) {

                $scope.selectedNetwork = [];
                $scope.browserSelectedData = [];
                for (var j = 0; j < $scope.countryList.length; j++) {
                    var data = $scope.countryList[j];
                    angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                        if (network.Selected) {
                            if ($scope.selectedNetwork.indexOf(network) == -1) {
                                $scope.selectedNetwork.push(network);
                            }

                        }
                    })
                }
            }
            {
                $scope.checkedNetwork = false;
            }

            $scope.checkNetworkCount = $scope.selectedNetwork.length;
            $scope.displaySelectedAndroid = true;
        }

        $scope.submitSelectedCarrier = function () {
            $scope.showBrowseAndriod = false;
            $scope.browserSelectedData = [];
            //$scope.combinedMobileData = [];
            if ($scope.combinedMobileData.length > 0) {
                var names = [];
                angular.forEach($scope.combinedMobileData, function (ne) {
                    names.push(ne);
                });
            }

            $scope.networkJSON = [];
            for (var j = 0; j < $scope.countryList.length; j++) {
                var data = $scope.countryList[j];
                angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                    if (network.Selected) {
                        var selectedCarrierObj = {"name": network.name, "value": network.optargeting_value};
                        if ($scope.browserSelectedData.indexOf(selectedCarrierObj) == -1) {
                            $scope.browserSelectedData.push(selectedCarrierObj);
                        }
                        if ($scope.combinedMobileData.length > 0)
                        {
                            var names = [];
                            angular.forEach($scope.combinedMobileData, function (ne) {
                                names.push(ne);
                            });
                            if (names.indexOf(selectedCarrierObj.name) == -1 && names.indexOf(selectedCarrierObj.value) == -1) {
                                $scope.combinedMobileData = angular.extend($scope.combinedMobileData, $scope.browserSelectedData)
                            }
                        } else {
                            $scope.combinedMobileData = angular.extend($scope.combinedMobileData, $scope.browserSelectedData);
                        }

                        var nwVal = network.optargeting_value;
                        if ($scope.networkJSON.indexOf(nwVal) == -1) {
                            $scope.networkJSON.push(network.optargeting_value);
                        }
                    }
                    else
                    {
                        angular.forEach($scope.combinedMobileData, function (ne1) {
                            if (ne1.name == network.name && ne1.value == network.optargeting_value) {
                                $scope.combinedMobileData.splice($scope.combinedMobileData.indexOf(ne1), 1);
                            }
                        });
                    }
                });

            }
            $scope.combinedMobileData = $scope.removeDuplicates($scope.combinedMobileData, "value");
            if ($scope.browserSelectedData) {
                $scope.displaySelectedNetwork = $scope.browserSelectedData;
            }
            angular.element($('body').css("overflow-y", "scroll"));
            $window.localStorage.setItem("campaignAudienceMobileCarrierLocal", JSON.stringify($scope.browserSelectedData));
            $window.localStorage.setItem("campaignAudienceMobileLocal", JSON.stringify($scope.mobileSearchData));
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $scope.setLine();
        }


        $scope.closeMobileCarriers = function () {
            $scope.showBrowseAndriod = false;
            $scope.browserSelectedData = [];
            $scope.cancelSelectedNet = [];
            if ($scope.displaySelectedNetwork.length > 0) {
                angular.forEach($scope.selectedNetwork, function (selectedNet) {
                    angular.forEach($scope.displaySelectedNetwork, function (displayNet) {
                        if (displayNet.name == selectedNet.name) {
                            if ($scope.cancelSelectedNet.indexOf(selectedNet == -1)) {
                                $scope.cancelSelectedNet.push(selectedNet);
                            }
                            console.log($scope.cancelSelectedNet);
                            angular.forEach($scope.cancelSelectedNet, function (net) {
                                var data = net.country_code;
                                angular.forEach($scope.mobileCarrierList[data], function (network) {
                                    if (network.name == net.name) {
                                        network.Selected = true;
                                        if (network.Selected) {
                                            $scope.browserSelectedData = $scope.displaySelectedNetwork;

                                        }
                                    }

                                })
                            })
                        } else {
                            var data = selectedNet.country_code;
                            angular.forEach($scope.mobileCarrierList[data], function (value) {
                                if (value.name == selectedNet.name) {
                                    value.Selected = false;
                                }
                            })
                        }
                    })
                })

            } else {

                for (var j = 0; j < $scope.countryList.length; j++) {
                    var data = $scope.countryList[j];
                    angular.forEach($scope.mobileCarrierList[data.countryCode], function (network) {
                        if (network) {
                            network.Selected = false;
                        }
                    })

                }

            }

            angular.element($('body').css("overflow-y", "scroll"));
        }


// TARGET NEW DEVICES



        $scope.selectTargetValue = function (targetMonth) {
//                                if(targetMonth!='')
//                                 {
//                                    angular.element('#step1').css('background-color', '#95D2B1'); 
//                                 }
//                                 else
//                                 {
//                                    angular.element('#step1').css('background-color', '#c2c2c2'); 
//                                 }
            if ($scope.radioTarget == 1) {
                $scope.selectedTargetMonth = targetMonth;
                $scope.networkActivationDurationIt = targetMonth;
                $scope.radioTarget = 1;
                $scope.radio_selected1 = targetMonth;
                $scope.radio_selected2 = "";

            }
            else if ($scope.radioTarget == 2) {
                $scope.selectedTargetMonth = targetMonth;
                $scope.networkActivationDurationGte = targetMonth;
                $scope.radioTarget = 2;
                $scope.radio_selected1 = "";
                $scope.radio_selected2 = targetMonth;
            }
            $window.localStorage.setItem("campaignAudienceTargetInLocal", $scope.radio_selected1);
            $window.localStorage.setItem("campaignAudienceTargetExLocal", $scope.radio_selected2);
            $scope.stepcheck();

        };


        $scope.setTargetValue = function (value) {
            if ($scope.radioTarget == 1) {
                $scope.radio_selected2 = "";
                $window.localStorage.setItem("campaignAudienceTargetInLocal", value);
                $window.localStorage.setItem("campaignAudienceTargetExLocal", "");
            } else {
                $scope.radio_selected1 = "";

                $window.localStorage.setItem("campaignAudienceTargetInLocal", "");
                $window.localStorage.setItem("campaignAudienceTargetExLocal", value);
            }
            $scope.stepcheck();
            //console.log($scope.radioTarget);
        };


        $scope.selectTarget = function (checked) {
            //console.log(checked);
            if (checked) {
                angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                //angular.element('#step1').css('background-color', '#c2c2c2');
                $scope.radioTarget = 1;

            } else {
                //angular.element('#step1').css('background-color', '#95D2B1');
                $scope.radioTarget = "";
                $scope.radio_selected1 = "";
                $scope.radio_selected2 = "";
                $scope.networkActivationDurationIt = "";
                $scope.networkActivationDurationGte = "";
            }
            $window.localStorage.setItem("campaignAudienceTargetLocal", $scope.targetChecked);
            $scope.stepcheck();
        };

        //SET PLACEMENTS 

        $scope.setSelectedPlacements = function (name, checkedVal) {

            angular.element('#step2').css('background-color', '#95D2B1');
            $scope.placementsJSON = [];
            console.log($scope.PlacementsArr);
           angular.forEach($scope.PlacementsArr, function (value) {
                angular.forEach(value, function (key) {
                    //console.log(key);
                    if (key.selected != "" && key.selected != undefined)
                    {
                        if ($scope.placementsJSON.indexOf(key.id) == -1) {
                            $scope.placementsJSON.push(key.id);
                        }

                    }
                    if ($scope.placementsJSON.length > 0) {
                        angular.element('#step2').css('background-color', '#95D2B1');
                    }
                    else {
                        angular.element('#step2').css('background-color', '#C2C2C2');
                    }

                })
            })

            $window.localStorage.setItem("campaignAudiencePlacementsLocal", JSON.stringify($scope.placementsJSON));
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //console.log($scope.placementsJSON);
        }


        //Detailed Targeting window close functionality
        var w = angular.element($window);
        w.bind('click', function (e) {
            if (this) {
                setTimeout($scope.showWindowDetailTargetingListing, 50);
                //$scope.showDetailTargetingListing();
            }

        });

        $scope.showWindowDetailTargetingListing = function () {
            $scope.$apply(function () {
                $scope.interestCategory = false;
                $scope.limitTargeting = false;
            });

        };

        $scope.showDetailTargetingListing = function () {
            $scope.detailtargetinglisting = false;
            $scope.detailtargetingsearch = false;
        };

        $scope.oneAtATime = true;
        $scope.displayCategory = false;

        $scope.array = [];
        $scope.subTitles = [];
        $scope.subTitlesList = [];
        // $scope.isOpen = false;

        $scope.displayDetailedCategory = function () {

            $scope.ngDTLoader = true;
            $scope.array = [];
            if ($scope.interestCategory == true) {
                $scope.interestCategory = false;
                $scope.ngDTLoader = false;
            } else {
                //GET DT SEARCH RESULT BY LETTER
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=interests';
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {


                    if (response.data.appStatus == 0) {
                        $scope.InterestDetails = response.data.targetingCriteria;
                        //console.log($scope.InterestDetails);
                        angular.forEach($scope.InterestDetails, function (value, key) {
                            $scope.array.push({
                                'name': value.name.split('/')[0],
                                'id': value.name.split('/')[1],
                                "targeting_value": value.targeting_value,
                               "Selected": false
                            });
                        });

                        for (var i = 0; i < $scope.array.length; i++) {
                            var str = $scope.array[i].name;
                            if ($scope.subTitles.indexOf(str) === -1) {
                                $scope.subTitles.push($scope.array[i].name);
                            }
                        }
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                    //console.log($scope.subTitles);
                    $scope.ngDTLoader = false;
                    $scope.setLine();
                });

                $scope.interestCategory = true;
            }

        }

        $scope.checkAll = [];
        $scope.checkedVal = false;
        $scope.checkedInterest = [];
        $scope.subTitlesList = [];
        $scope.getSubTitles = function (title, index) {

            var listVal = [];
            for (i = 0; i < $scope.array.length; i++) {
                if ($scope.array[i].name == title) {
                    listVal.push({
                        'name': $scope.array[i].name,
                        'id': $scope.array[i].id,
                        "targeting_value": $scope.array[i].targeting_value,
                        "Selected": false
                    });
                }
            }
            $scope.subTitlesList[index] = listVal;
            console.log($scope.subTitlesList[index].length);
            $scope.selectedInterests = [];
            if ($scope.DTInterestArray.length > 0) {
                angular.forEach($scope.DTInterestArray, function (value1) {
                    angular.forEach($scope.subTitlesList[index], function (key, value2) {
                        if (value1 == key.targeting_value) {
                            $scope.selectedInterests.push(value1);
                        }
                    })
                })
            }
            if ($scope.selectedInterests.length == $scope.subTitlesList[index].length) {
                $scope.checkedInterest[index] = true;
            } else {
                $scope.checkedInterest[index] = false;
            }
            $scope.setLine();

        }



        $scope.selectAllInterests = function (val, index, checked) {

            if (checked[index]) {
                angular.forEach($scope.subTitlesList[index], function (item) {
                    if (val == item.name) {
                        item.Selected = true;

                        $scope.checkedInterest[index] = true;
                        if ($scope.DTInterestArray.indexOf(item.targeting_value) == -1) {
                            $scope.DTInterestArray.push(item.targeting_value);
                            var m_Obj = {"id": item.id, "targeting_value": item.targeting_value};
                            $scope.DTInterestNameArray.push(m_Obj);
                        }
                    }
                })
            } else {
                angular.forEach($scope.subTitlesList[index], function (item) {
                    if (val == item.name) {
                        item.Selected = false;
                        $scope.checkedInterest[index] = false;
                        $scope.DTInterestArray.splice($scope.DTInterestArray.indexOf(item.targeting_value), 1);
                        var a = _.findWhere($scope.DTInterestNameArray, {"targeting_value": item.targeting_value});
                        if ($window.localStorage.getItem("campaignState") == "edit" && a.existingid != '' && a.existingid != undefined) {
                            var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                                return d === a.existingid;
                            }, true);
                            if (MArray[0] != '' && MArray[0] != undefined) {
                                $scope.existingTargetingCriteriaArray.push(MArray[0]);
                                $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                            }
                        }
                        //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));
                        var b = _.indexOf($scope.DTInterestNameArray, a);
                        $scope.DTInterestNameArray.splice(b, 1);
                    }
                })

            }

            //$rootScope.freezeFlag = true;
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTInterestNameArray", JSON.stringify($scope.DTInterestNameArray));
            $scope.setLine();
        }


        $scope.DTInterestSelection = function (menu) {
            //console.log(menu.targeting_value);
            //console.log($scope.DTInterestNameArray[0].targeting_value);
            if (menu.Selected) {
                if ($scope.DTInterestArray.indexOf(menu.targeting_value) == -1) {
                    $scope.DTInterestArray.push(menu.targeting_value);
                    var m_Obj = {"id": menu.id, "targeting_value": menu.targeting_value};
                    $scope.DTInterestNameArray.push(m_Obj);
                }
            } else {

                if ($window.localStorage.getItem("campaignState") == "edit") {
                    //console.log($scope.DTInterestNameArray);
                    var results = $filter('filter')($scope.DTInterestNameArray, {targeting_value: menu.targeting_value}, true);
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === results[0].existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
                //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));


                $scope.DTInterestArray.splice($scope.DTInterestArray.indexOf(menu.targeting_value), 1);
                var a = _.findWhere($scope.DTInterestNameArray, {"targeting_value": menu.targeting_value});
                var b = _.indexOf($scope.DTInterestNameArray, a);
                $scope.DTInterestNameArray.splice(b, 1);
                /*if($scope.targetingFlag == true){         
                 angular.forEach($scope.uniqueInterest, function(uniqueVal) {
                 var removeFromArr = false;
                 angular.forEach($scope.DTInterestNameArray, function(interestVal) {
                 if (interestVal.id.includes(uniqueVal)) {
                 removeFromArr = true;
                 }
                 });
                 if (removeFromArr) {
                 $scope.uniqueInterest.splice($scope.uniqueInterest.indexOf(uniqueVal), 1);
                 $scope.userSuggestionTargetingBlock = false;
                 $scope.targetingFlag = false;
                 }
                 });
                 
                 } */
                if ($scope.targetingFlag == true) {
                    angular.forEach($scope.uniqueInterest, function (uniqueVal) {
                        if (menu.id.includes(uniqueVal)) {
                            $scope.uniqueInterest.splice($scope.uniqueInterest.indexOf(uniqueVal), 1);
                            $scope.userSuggestionTargetingBlock = false;
                            $scope.targetingFlag = false;
                        }
                    });
                }


            }

            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTInterestNameArray", JSON.stringify($scope.DTInterestNameArray));
            $scope.setLine();

        }

        $scope.removeAllInterestTargeting = function () {

            if ($window.localStorage.getItem("campaignState") == "edit") {
                for (var i = 0; i < $scope.DTInterestNameArray.length; i++) {
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === $scope.DTInterestNameArray[i].existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));
            $scope.DTInterestArray = [];
            $scope.DTInterestNameArray = [];
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;                                     
            $window.localStorage.setItem("DTInterestNameArray", '');
            $scope.setLine();
        }




        $scope.eventsCategoryData = [];
        $scope.displayEventsCategory = function () {

            $scope.ngEventDTLoader = true;
            $scope.array = [];
            if ($scope.eventsCategory == true) {
                $scope.eventsCategory = false;
                $scope.ngEventDTLoader = false;
            } else {

                $scope.eventsCategory = true;
//                var data = {
//                    'userId': $window.localStorage.getItem("userId"),
//                    'accessToken': $window.localStorage.getItem("accessToken")
//                };
//                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=events';
//                twitterGetPost.gettargetingcriteria(queryStr, data).then(function(response) {
//                  $scope.EventsArray = response.data.targetingCriteria; 
//                });


                if ($scope.DefaultEventsArray.length > 0) {

                    angular.forEach($scope.DefaultEventsArray, function (value, key) {
                        $scope.array.push({
                            'event_type': value.event_type,
                            "name": value.name,
                            "id": value.id
                        });
                    });

                    for (var i = 0; i < $scope.array.length; i++) {
                        var str = $scope.array[i].event_type;
                        if ($scope.eventsCategoryData.indexOf(str) === -1) {
                            $scope.eventsCategoryData.push($scope.array[i].event_type);
                        }
                    }

                }
                $scope.ngEventDTLoader = false;
                $scope.setLine();
            }

        }

        $scope.EventSublist = [];
        $scope.geteventsSubTitles = function (title, index) {
            var listVal = [];
            for (i = 0; i < $scope.array.length; i++) {
                if ($scope.array[i].event_type == title) {
                    listVal.push({
                        'event_type': $scope.array[i].event_type,
                        'name': $scope.array[i].name,
                        "id": $scope.array[i].id
                    });
                }
            }
            $scope.EventSublist[index] = listVal;
            $scope.setLine();
        }

        $scope.DTEventSelection = function (menu, index) {
            if ($window.localStorage.getItem("campaignState") == "edit" && $scope.DTEventNameArray.length > 0) {
                var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                    return d === $scope.DTEventNameArray[0].existingid;
                }, true);
                if (MArray[0] != '' && MArray[0] != undefined) {
                    $scope.existingTargetingCriteriaArray.push(MArray[0]);
                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));

            $scope.DTEventArray = [];
            $scope.DTEventNameArray = [];
            if ($scope.DTEventArray.indexOf(menu.id) > -1) {
                $scope.DTEventArray.splice($scope.DTEventArray.indexOf(menu.id), 1);
                var a = _.findWhere($scope.DTEventNameArray, {id: menu.id});
                var b = _.indexOf($scope.DTEventNameArray, a);
                $scope.DTEventNameArray.splice(b, 1);
            } else {

                $scope.DTEventArray.push(menu.id);
                var m_Obj = {"id": menu.id, "name": menu.name};
                $scope.DTEventNameArray.push(m_Obj);
            }
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTEventNameArray", JSON.stringify($scope.DTEventNameArray));

            if (menu.id == $scope.existingDTEventId) {
                $window.localStorage.setItem("existingEventId", "");
            }
            $scope.setLine();
        }

        $scope.removeDTEventSelection = function (menu, index) {
            $scope.DTEventArray.splice($scope.DTEventArray.indexOf(menu.id), 1);
            var a = _.findWhere($scope.DTEventNameArray, {id: menu.id});
            var b = _.indexOf($scope.DTEventNameArray, a);
            $scope.DTEventNameArray.splice(b, 1);
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTEventNameArray", JSON.stringify($scope.DTEventNameArray));

            if ($window.localStorage.getItem("campaignState") == "edit" && menu.existingid != '' && menu.existingid != undefined) {
                var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                    return d === menu.existingid;
                }, true);
                if (MArray[0] != '' && MArray[0] != undefined) {
                    $scope.existingTargetingCriteriaArray.push(MArray[0]);
                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                }
            }
            $scope.setLine();
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));
        }

        $scope.removeAllEventsTargeting = function () {

            if ($window.localStorage.getItem("campaignState") == "edit") {
                for (var i = 0; i < $scope.DTEventNameArray.length; i++) {
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === $scope.DTEventNameArray[i].existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));

            $scope.DTEventArray = [];
            $scope.DTEventNameArray = [];
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTEventNameArray", '');
            $scope.setLine();
        }


        // SAVE & PROCEED NEXT STEP FUNCTIONALITY 
        $scope.campaignAudienceJSON = [];

        $scope.campaignAudienceLocationTargetValue = [];

        $scope.deviceList = [];
        $scope.selectedVersionList = [];
        $scope.selectedPlatformList = [];
        $scope.selectedNetworkOp = [];


        $scope.browseBehaviourData = [];
        $scope.displayBehaviours = function () {

            $scope.ngBehaviourLoader = true;

            if ($scope.behaviourCategory == false) {
                $scope.behaviourCategory = true;

                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behavior_taxonomies&parentBehaviorTaxonomyIds=null';
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.BehaviourArray = response.data.targetingCriteria;

                        angular.forEach($scope.BehaviourArray, function (value, key) {
                            $scope.browseBehaviourData.push({
                                'parent_id': value.parent_id,
                                "name": value.name,
                                "id": value.id
                            });
                        });
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                    $scope.ngBehaviourLoader = false;
                    $scope.setLine();
                });

            } else {
                $scope.behaviourCategory = false;
                $scope.ngBehaviourLoader = false;
            }

        };

        $scope.BehaviourFirstChildArray = [];
        $scope.getBehaviourSubTitles = function (val, index, isOpen) {

            if (isOpen) {
                $scope.BehaviourFirstChildArray = [];
                $scope.firstServiceReply = 'Loading...';
                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behavior_taxonomies&parentBehaviorTaxonomyIds=' + val.id;
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.BehaviourArray = response.data.targetingCriteria;
                        angular.forEach($scope.BehaviourArray, function (value, key) {
                            $scope.BehaviourFirstChildArray.push({
                                'parent_id': value.parent_id,
                                "name": value.name,
                                "id": value.id
                            });
                        });
                        //console.log("11111------------->"+$scope.BehaviourFirstChildArray.length);
                        if ($scope.BehaviourFirstChildArray.length > 0) {
                            $scope.firstServiceReply = '';

                        } else {
                            $scope.firstServiceReply = 'No Targeting Criteria Found';
                        }

                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    $scope.setLine();
                });
            }
        }

        $scope.BehaviourSecondChildArray = [];
        $scope.getBehaviourChildTitles = function (val, index, isOpen) {

            if (isOpen) {
                var promises = [];
                $scope.BehaviourSecondChildArray = [];
                $scope.secondServiceReply = 'Loading...';
//            var data = {
//                'userId': $window.localStorage.getItem("userId"),
//                'accessToken': $window.localStorage.getItem("accessToken")
//            };
//            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behaviors&countryCode='+$scope.tvbehaviourMarket;
//            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function(response) {
//                $scope.BehaviourArray = response.data.targetingCriteria;
//                //console.log($scope.BehaviourArray);
//            }));
                if ($scope.DefaultBehaviourArray.length > 0) {
                    console.log('*****');
                    console.log($scope.DefaultBehaviourArray);
                    angular.forEach($scope.DefaultBehaviourArray, function (value, key) {
                        if (val.id == value.behavior_taxonomy_id) {
                            $scope.BehaviourSecondChildArray.push({
                                "name": value.name,
                                "id": value.id
                            });
                        }
                    });
                    //console.log(JSON.stringify($scope.BehaviourSecondChildArray,null,1));
                    //console.log("222222------------->"+$scope.BehaviourSecondChildArray.length);
                    if ($scope.BehaviourSecondChildArray.length > 0) {
                        $scope.secondServiceReply = '';
                    } else {
                        $scope.secondServiceReply = 'No Targeting Criteria Found';
                    }
                    $scope.setLine();
                }
                ;
            }

        }

        $scope.DTBehaviourSelection = function (childmenu) {

            if ($scope.DTBehaviourArray.indexOf(childmenu.id) > -1) {
                $scope.DTBehaviourArray.splice($scope.DTBehaviourArray.indexOf(childmenu.id), 1);
                var a = _.findWhere($scope.DTBehaviourNameArray, {id: childmenu.id});
                var b = _.indexOf($scope.DTBehaviourNameArray, a);
                $scope.DTBehaviourNameArray.splice(b, 1);

                if ($scope.newDTBehaviourNameArray.length > 0) {
                    //$scope.DTBehaviourArray.splice($scope.DTBehaviourArray.indexOf(childmenu.id), 1);            
                    var a = _.findWhere($scope.newDTBehaviourNameArray, {id: childmenu.id});
                    var b = _.indexOf($scope.newDTBehaviourNameArray, a);
                    $scope.newDTBehaviourNameArray.splice(b, 1);
                }

                if ($window.localStorage.getItem("campaignState") == "edit") {
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === a.existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
                //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));

            } else {
                $scope.DTBehaviourArray.push(childmenu.id);
                var m_Obj = {"id": childmenu.id, "name": childmenu.name};
                $scope.DTBehaviourNameArray.push(m_Obj);
            }
            // $rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            // $rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTBehaviourNameArray", JSON.stringify($scope.DTBehaviourNameArray));
            $scope.setLine();

        }

        $scope.removeDTBehaviourSelection = function (menu, index) {

            $scope.DTBehaviourArray.splice($scope.DTBehaviourArray.indexOf(menu.id), 1);
            var a = _.findWhere($scope.DTBehaviourNameArray, {id: menu.id});
            var b = _.indexOf($scope.DTBehaviourNameArray, a);
            $scope.DTBehaviourNameArray.splice(b, 1);


            if ($scope.newDTBehaviourNameArray.length > 0) {
                //          $scope.DTBehaviourArray.splice($scope.DTBehaviourArray.indexOf(menu.id), 1);            
                var a = _.findWhere($scope.newDTBehaviourNameArray, {id: menu.id});
                var b = _.indexOf($scope.newDTBehaviourNameArray, a);
                $scope.newDTBehaviourNameArray.splice(b, 1);
            }

            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTBehaviourNameArray", JSON.stringify($scope.DTBehaviourNameArray));

            if ($window.localStorage.getItem("campaignState") == "edit") {
                var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                    return d === menu.existingid;
                }, true);
                if (MArray[0] != '' && MArray[0] != undefined) {
                    $scope.existingTargetingCriteriaArray.push(MArray[0]);
                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));
            $scope.setLine();
        }

        $scope.removeAllBehaviourTargeting = function () {

            if ($window.localStorage.getItem("campaignState") == "edit") {
                for (var i = 0; i < $scope.DTBehaviourNameArray.length; i++) {
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === $scope.DTBehaviourNameArray[i].existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
            }
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));

            $scope.DTBehaviourArray = [];
            $scope.DTBehaviourNameArray = [];
            $scope.newDTBehaviourNameArray = [];
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTBehaviourNameArray", '');
            $scope.setLine();
        }


        $scope.browselimitBehaviourData = [];
        $scope.displayLimitTargeting = function () {
            $scope.browselimitBehaviourData = [];
            $scope.ngLImitBehaviourLoader = true;

            if ($scope.limitbehaviourCategory == false) {
                $scope.limitbehaviourCategory = true;

                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behavior_taxonomies&parentBehaviorTaxonomyIds=null';
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                    if (response.data.appStatus == 0) {
                        $scope.BehaviourArray = response.data.targetingCriteria;

                        angular.forEach($scope.BehaviourArray, function (value, key) {
                            $scope.browselimitBehaviourData.push({
                                'parent_id': value.parent_id,
                                "name": value.name,
                                "id": value.id
                            });
                        });

                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                    $scope.setLine();
                    $scope.ngLImitBehaviourLoader = false;
                });

            } else {
                $scope.limitbehaviourCategory = false;
                $scope.ngLImitBehaviourLoader = false;
            }

        };

        $scope.limitBehaviourFirstChildArray = [];
        $scope.getlimitBehaviourSubTitles = function (val, index, isOpen) {

            if (isOpen) {
                $scope.limitBehaviourFirstChildArray = [];
                $scope.firstlimitServiceReply = 'Loading...';

                var data = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                };
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behavior_taxonomies&parentBehaviorTaxonomyIds=' + val.id;
                twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                    if (response.data.appStatus == 0) {
                        $scope.BehaviourArray = response.data.targetingCriteria;
                        angular.forEach($scope.BehaviourArray, function (value, key) {
                            $scope.limitBehaviourFirstChildArray.push({
                                'parent_id': value.parent_id,
                                "name": value.name,
                                "id": value.id
                            });
                        });
                        if ($scope.limitBehaviourFirstChildArray.length > 0) {
                            $scope.firstlimitServiceReply = '';
                        } else {
                            $scope.firstlimitServiceReply = 'No Targeting Criteria Found';
                        }
                    }
                    else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.networkError.message;
                            } else {
                                if (response.data.networkError.error_user_title) {
                                    $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                    $scope.errorMsg = response.data.networkError.error_user_msg;
                                }
                                else {
                                    $scope.errorpopupHeading = "Error";
                                    $scope.errorMsg = response.data.networkError[0].message;
                                }
                            }
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }

                    $scope.setLine();

                });
            }
        }

        $scope.limitBehaviourSecondChildArray = [];
        $scope.getlimitBehaviourChildTitles = function (val, index, isOpen) {

            if (isOpen) {
                var promises = [];
                $scope.limitBehaviourSecondChildArray = [];
                $scope.secondlimitServiceReply = 'Loading...';

//            var data = {
//                'userId': $window.localStorage.getItem("userId"),
//                'accessToken': $window.localStorage.getItem("accessToken")
//            };
//            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behaviors&countryCode='+$scope.limitbehaviourMarket;
//            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function(response) {
//                $scope.BehaviourArray = response.data.targetingCriteria;
//            }));

                if ($scope.DefaultBehaviourArray.length > 0) {
                    //$q.all(promises).finally(function(){
                    $scope.limitBehaviourSecondChildArray = [];
                    angular.forEach($scope.DefaultBehaviourArray, function (value, key) {
                        if (val.id == value.behavior_taxonomy_id) {
                            $scope.limitBehaviourSecondChildArray.push({
                                "name": value.name,
                                "id": value.id
                            });
                        }
                    });
                    if ($scope.limitBehaviourSecondChildArray.length > 0) {
                        $scope.secondlimitServiceReply = '';
                    } else {
                        $scope.secondlimitServiceReply = 'No Targeting Criteria Found';
                    }
                    $scope.setLine();
                    //});
                } else {
                    $scope.secondlimitServiceReply = "No Targeting Criteria Found";

                }
            }
        }

        $scope.DTlimitBehaviourSelection = function (childmenu) {

            if ($scope.DTlimitBehaviourArray.indexOf(childmenu.id) > -1) {
                $scope.DTlimitBehaviourArray.splice($scope.DTlimitBehaviourArray.indexOf(childmenu.id), 1);
                var a = _.findWhere($scope.DTlimitBehaviourNameArray, {name: childmenu.name});
                var b = _.indexOf($scope.DTlimitBehaviourNameArray, a);
                $scope.DTlimitBehaviourNameArray.splice(b, 1);

                if ($scope.newDTlimitBehaviourNameArray.length > 0) {
                    //$scope.DTBehaviourArray.splice($scope.DTBehaviourArray.indexOf(childmenu.id), 1);            
                    var a = _.findWhere($scope.newDTlimitBehaviourNameArray, {id: childmenu.id});
                    var b = _.indexOf($scope.newDTlimitBehaviourNameArray, a);
                    $scope.newDTlimitBehaviourNameArray.splice(b, 1);
                }

                if ($window.localStorage.getItem("campaignState") == "edit") {
                    var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                        return d === a.existingid;
                    }, true);
                    if (MArray[0] != '' && MArray[0] != undefined) {
                        $scope.existingTargetingCriteriaArray.push(MArray[0]);
                        $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                    }
                }
                //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));


            } else {
                $scope.DTlimitBehaviourArray.push(childmenu.id);
                var m_Obj = {"id": childmenu.id, "name": childmenu.name};
                $scope.DTlimitBehaviourNameArray.push(m_Obj);
            }
            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTlimitBehaviourNameArray", JSON.stringify($scope.DTlimitBehaviourNameArray));
            $scope.setLine();
        }

        $scope.removeDTlimitBehaviourSelection = function (menu, index) {

            $scope.DTlimitBehaviourArray.splice($scope.DTlimitBehaviourArray.indexOf(menu.id), 1);
            var a = _.findWhere($scope.DTlimitBehaviourNameArray, {id: menu.id});
            var b = _.indexOf($scope.DTlimitBehaviourNameArray, a);
            $scope.DTlimitBehaviourNameArray.splice(b, 1);

            if ($scope.newDTlimitBehaviourNameArray.length > 0) {
                //$scope.DTlimitBehaviourArray.splice($scope.DTlimitBehaviourArray.indexOf(menu.id), 1);            
                var a = _.findWhere($scope.newDTlimitBehaviourNameArray, {id: menu.id});
                var b = _.indexOf($scope.newDTlimitBehaviourNameArray, a);
                $scope.newDTlimitBehaviourNameArray.splice(b, 1);
            }

            //$rootScope.freezeFlag = true;
            angular.element('.stepfreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //$rootScope.overLayAudience = true;
            $window.localStorage.setItem("DTlimitBehaviourNameArray", JSON.stringify($scope.DTlimitBehaviourNameArray));

            if ($window.localStorage.getItem("campaignState") == "edit") {
                var MArray = $filter('filter')($scope.existingTargetingCriteriaDBArray, function (d) {
                    return d === menu.existingid;
                }, true);
                if (MArray[0] != '' && MArray[0] != undefined) {
                    $scope.existingTargetingCriteriaArray.push(MArray[0]);
                    $window.localStorage.setItem("existingTargetingCriteriaArray", JSON.stringify($scope.existingTargetingCriteriaArray));
                }
            }
            $scope.setLine();
            //console.log($window.localStorage.getItem("existingTargetingCriteriaArray"));
        }

        $scope.tweetPopup = function () {
            angular.element($('body').css("overflow-y", "hidden"));
            var createPopup = $(".tweetCreatePopup");// Get the modal Reject req
            createPopup.show();
            $scope.createBlock = true;
        }




        vm.createCampaignAudience = function () {

            $scope.progressLoader = "block";
            if ($scope.campaignAudienceAgeTo != "None" || $scope.campaignAudienceAgeTo != "") {
                if ($scope.campaignAudienceAgeFrom == "13+") {
                    $scope.setMinAge = "AGE_OVER_13";
                }
                else if ($scope.campaignAudienceAgeFrom == "18+") {
                    $scope.setMinAge = "AGE_OVER_18";
                }
                else if ($scope.campaignAudienceAgeFrom == "21+") {
                    $scope.setMinAge = "AGE_OVER_21";
                }
                else if ($scope.campaignAudienceAgeFrom == "25+") {
                    $scope.setMinAge = "AGE_OVER_25";
                }
                else if ($scope.campaignAudienceAgeFrom == "35+") {
                    $scope.setMinAge = "AGE_OVER_35";
                }
                else if ($scope.campaignAudienceAgeFrom == "50+") {
                    $scope.setMinAge = "AGE_OVER_50";
                }
            }

            if ($scope.setMinAge != undefined && $scope.setMinAge != "") {
                $scope.setAgeBucket = $scope.setMinAge;
                $scope.setMinAge = "";
            } else if ($scope.setMaxAge != undefined && $scope.setMaxAge != "") {
                $scope.setAgeBucket = $scope.setMaxAge;
                $scope.setMaxAge = "";
            }

            if ($scope.setAgeBucket == undefined || $scope.setAgeBucket == "")
            {
                $scope.setAgeBucket = "";
            }

            if ($scope.campaignAudienceGender == 'men') {
                $scope.campaignAudienceGenderJSON = "1";
            } else if ($scope.campaignAudienceGender == 'women') {
                $scope.campaignAudienceGenderJSON = "2";
            }

            if ($scope.allIOS && $scope.allAndroid) {
                if ($scope.selectPlatformData) {
                    angular.forEach($scope.selectPlatformData, function (platform) {
                        if (platform.Selected) {
                            $scope.selectedPlatformList.push(platform.targeting_value);
                        }
                    })
                }


            } else if (!$scope.allIOS && $scope.allAndroid) {
                if ($scope.selectPlatformData) {
                    angular.forEach($scope.selectPlatformData, function (platform) {
                        if (platform.Selected && platform.name != "iOS") {
                            $scope.selectedPlatformList.push(platform.targeting_value);
                        }
                    })
                }
                if ($scope.selectedIOSList) {
                    angular.forEach($scope.selectedIOSList, function (iosdevice) {
                        $scope.deviceList.push(iosdevice.targeting_value);
                    })
                }

                if ($scope.versionData) {
                    angular.forEach($scope.iOSVersions, function (version) {
                        if ($scope.versionData == version.name) {
                            $scope.selectedVersionList.push(version.targeting_value);
                        }
                    })
                }




            } else if ($scope.allIOS && !$scope.allAndroid) {
                if ($scope.selectPlatformData) {
                    angular.forEach($scope.selectPlatformData, function (platform) {
                        if (platform.Selected && platform.name != "Android") {
                            $scope.selectedPlatformList.push(platform.targeting_value);
                        }
                    })
                }
                if ($scope.selectedAndroidList) {
                    angular.forEach($scope.selectedAndroidList, function (androiddevice) {
                        $scope.deviceList.push(androiddevice.targeting_value);
                    })
                }
                if ($scope.versionAndroid) {
                    angular.forEach($scope.androidVersions, function (androidV) {
                        if ($scope.versionAndroid == androidV.name) {
                            $scope.selectedVersionList.push(androidV.targeting_value);
                        }
                    })
                }



            } else {
                if ($scope.selectPlatformData) {
                    angular.forEach($scope.selectPlatformData, function (platform) {
                        if (platform.Selected && platform.name != "iOS" && platform.name != "Android") {
                            $scope.selectedPlatformList.push(platform.targeting_value);
                        }
                    })
                }
                if ($scope.selectedIOSList) {
                    angular.forEach($scope.selectedIOSList, function (iosdevice) {
                        $scope.deviceList.push(iosdevice.targeting_value);
                    })
                }
                if ($scope.selectedAndroidList) {
                    angular.forEach($scope.selectedAndroidList, function (androiddevice) {
                        $scope.deviceList.push(androiddevice.targeting_value);
                    })
                }
                if ($scope.versionData) {
                    angular.forEach($scope.iOSVersions, function (version) {
                        if ($scope.versionData == version.name) {
                            $scope.selectedVersionList.push(version.targeting_value);
                        }
                    })
                }
                if ($scope.versionAndroid) {
                    angular.forEach($scope.androidVersions, function (androidV) {
                        if ($scope.versionAndroid == androidV.name) {
                            $scope.selectedVersionList.push(androidV.targeting_value);
                        }
                    })
                }
            }


            if ($scope.targetChecked) {
                if ($scope.radioTarget == 1) {
                    $scope.networkActivationDurationIt = $scope.radio_selected1.replace("months", "").trim();
                    $scope.DTTargetJSON = {"networkActivationDurationIt": $scope.networkActivationDurationIt};
                } else {
                    $scope.networkActivationDurationGte = $scope.radio_selected2.replace("months", "").trim();
                    $scope.DTTargetJSON = {"networkActivationDurationGte": $scope.networkActivationDurationGte};
                }
            }


            if ($scope.networkJSON) {
                angular.forEach($scope.networkJSON, function (networkOp) {

                    if ($scope.selectedNetworkOp.indexOf(networkOp) == -1) {
                        $scope.selectedNetworkOp.push(networkOp);
                    }
                });

            }

            if ($scope.DTEventArray[0] == $scope.existingDTEventId) {
                $window.localStorage.setItem("existingEventId", "");
            }

            $scope.DTEventJSON = {"events": $scope.DTEventArray.join(',')};
            $scope.DTInterestJSON = {"interests": $scope.DTInterestArray.join(',')};
            $scope.DTBehaviourJSON = {"behaviors": $scope.DTBehaviourArray.join(',')};
            $scope.DTLimitBehaviourJSON = {"negativeBehaviors": $scope.DTlimitBehaviourArray.join(',')};
            $scope.DTPlacementsJSON = {"placements": $scope.placementsJSON.join(',')};
            $scope.DTMobileCarriers = {"networkOperators": $scope.selectedNetworkOp.join(',')};
            $scope.TVShowsKeyValues = {"tvShows": $scope.campaignAudienceTVShowKeyArr.join(',')};

            if ($scope.campaignAudienceGender == "all" || $scope.campaignAudienceGender == undefined) {
                $scope.campaignAudienceJSON = {
                    "locations": $scope.locationJSON.join(','),
                    //"ageBuckets" :$scope.setAgeBucket,
                    "languages": $scope.campaignAudienceLanguageKeyArr.join(','),
                    "devices": $scope.deviceList.join(','),
                    "platforms": $scope.selectedPlatformList.join(','),
                    "platformVersions": $scope.selectedVersionList.join(',')
                };
            } else {
                $scope.campaignAudienceJSON = {
                    "locations": $scope.locationJSON.join(','),
                    //"ageBuckets" :$scope.setAgeBucket,
                    "gender": $scope.campaignAudienceGenderJSON,
                    "languages": $scope.campaignAudienceLanguageKeyArr.join(','),
                    "devices": $scope.deviceList.join(','),
                    "platforms": $scope.selectedPlatformList.join(','),
                    "platformVersions": $scope.selectedVersionList.join(',')
                };

            }


            var interestR = {};
            for (var key in $scope.campaignAudienceJSON) {
                interestR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTInterestJSON) {
                interestR[key] = $scope.DTInterestJSON[key];
            }
            $scope.campaignAudienceJSON = interestR;

            var behaviourR = {};
            for (var key in $scope.campaignAudienceJSON) {
                behaviourR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTBehaviourJSON) {
                behaviourR[key] = $scope.DTBehaviourJSON[key];
            }
            $scope.campaignAudienceJSON = behaviourR;

            var limitbehaviourR = {};
            for (var key in $scope.campaignAudienceJSON) {
                limitbehaviourR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTLimitBehaviourJSON) {
                limitbehaviourR[key] = $scope.DTLimitBehaviourJSON[key];
            }
            $scope.campaignAudienceJSON = limitbehaviourR;

            var eventsR = {};
            for (var key in $scope.campaignAudienceJSON) {
                eventsR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTEventJSON) {
                eventsR[key] = $scope.DTEventJSON[key];
            }
            $scope.campaignAudienceJSON = eventsR;

            //if($scope.campaignAudienceTVShowKeyArr.length > 0){
            var tvshowsR = {};
            for (var key in $scope.campaignAudienceJSON) {
                tvshowsR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.TVShowsKeyValues) {
                tvshowsR[key] = $scope.TVShowsKeyValues[key];
            }
            $scope.campaignAudienceJSON = tvshowsR;
            //}

            var placementsR = {};
            for (var key in $scope.campaignAudienceJSON) {
                placementsR[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTPlacementsJSON) {
                placementsR[key] = $scope.DTPlacementsJSON[key];
            }
            $scope.campaignAudienceJSON = placementsR;


            var networksArr = {};
            for (var key in $scope.campaignAudienceJSON) {
                networksArr[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTMobileCarriers) {
                networksArr[key] = $scope.DTMobileCarriers[key];
            }
            $scope.campaignAudienceJSON = networksArr;

            var targetsArr = {};
            for (var key in $scope.campaignAudienceJSON) {
                targetsArr[key] = $scope.campaignAudienceJSON[key];
            }
            for (var key in $scope.DTTargetJSON) {
                targetsArr[key] = $scope.DTTargetJSON[key];
            }
            $scope.campaignAudienceJSON = targetsArr;

            console.log($scope.campaignAudienceJSON);
            $window.localStorage.setItem("campaignAudienceJSON", JSON.stringify($scope.campaignAudienceJSON));

            $rootScope.freezeFlag = false;
            $rootScope.campaignSteps[1] = true;
            $rootScope.campaignSteps = [true, true, false, false, false];
            $state.go('app.twReplicatorEngCampaignplan');

        }

        $scope.getBehaviourChildDetails = function (tvbehaviourMarket) {
            //console.log(tvbehaviourMarket);
            var promises = [];
            $rootScope.progressLoader = "block";
            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=behaviors&countryCode=' + tvbehaviourMarket;
            promises.push(twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.DefaultBehaviourArray = response.data.targetingCriteria;

                }
                else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            if (response.data.networkError.error_user_title) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                            else {
                                $scope.errorpopupHeading = "Error";
                                $scope.errorMsg = response.data.networkError[0].message;
                            }
                        }
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }

                $scope.setLine();
            }));
            $q.all(promises).finally(function () {
                if ($window.localStorage.getItem("campaignState") == "edit") {
                    $scope.newDTBehaviourNameArray = [];
                    for (var i = 0; i < $scope.DTBehaviourNameArray.length; i++) {
                        var results = $filter('filter')($scope.DefaultBehaviourArray, {id: $scope.DTBehaviourNameArray[i].id}, true);
                        //var a = _.findWhere($scope.DefaultBehaviourArray,{id:$scope.DTBehaviourNameArray[i].id});
                        var m_Obj = {"id": results[0].id, "name": results[0].name, "existingid": $scope.DTBehaviourNameArray[i].existingid};
                        $scope.newDTBehaviourNameArray.push(m_Obj);
                    }
                    $scope.newDTlimitBehaviourNameArray = [];
                    for (var i = 0; i < $scope.DTlimitBehaviourNameArray.length; i++) {
                        var results = $filter('filter')($scope.DefaultBehaviourArray, {id: $scope.DTlimitBehaviourNameArray[i].id}, true);
                        var m_Obj = {"id": results[0].id, "name": results[0].name, "existingid": $scope.DTlimitBehaviourNameArray[i].existingid};
                        $scope.newDTlimitBehaviourNameArray.push(m_Obj);
                    }
                }
                $rootScope.progressLoader = "none";
            });

        };

        $scope.getdefaultEventsDetails = function () {

            var data = {
                'userId': $window.localStorage.getItem("userId"),
                'accessToken': $window.localStorage.getItem("accessToken")
            };
            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem("twUserNetworkMapId") + '&targetingCriteria=events';
            twitterGetPost.gettargetingcriteria(queryStr, data).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.DefaultEventsArray = response.data.targetingCriteria;

                }
                else if (response.data.appStatus > 0 && (response.data.errorMessage == 'Access token is invalid or expired' || response.data.errorMessage == 'Access Token is invalid or expired.')) {
                    $window.localStorage.setItem("TokenExpired", true);
                    $state.go('login');
                } else {
                    $rootScope.progressLoader = "none";
                    $scope.editErrorMsg = 'block';
                    if (response.data.networkError != '' && response.data.networkError != undefined) {
                        if (response.data.networkError.message != '' && response.data.networkError.message != undefined) {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.networkError.message;
                        } else {
                            if (response.data.networkError.error_user_title) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            }
                            else {
                                $scope.errorpopupHeading = "Error";
                                $scope.errorMsg = response.data.networkError[0].message;
                            }
                        }
                    } else {
                        $scope.errorpopupHeading = 'Error';
                        $scope.errorMsg = response.data.errorMessage;
                    }
                }
            });

        };

        $scope.closePopup = function () {
            $scope.editErrorMsg = 'none';
        }

        $scope.targetMonthValues = [
            {Key: "1", Value: "1 month"},
            {Key: "2", Value: "2 months"},
            {Key: "3", Value: "3 months"},
            {Key: "4", Value: "4 months"},
            {Key: "5", Value: "5 months"},
            {Key: "6", Value: "6 months"},
            {Key: "7", Value: "7 months"},
            {Key: "8", Value: "8 months"},
            {Key: "9", Value: "9 months"},
            {Key: "10", Value: "10 months"},
            {Key: "11", Value: "11 months"},
            {Key: "12", Value: "12 months"},
            {Key: "13", Value: "13 months"},
            {Key: "14", Value: "14 months"},
            {Key: "15", Value: "15 months"},
            {Key: "16", Value: "16 months"},
            {Key: "17", Value: "17 months"},
            {Key: "18", Value: "18 months"},
            {Key: "19", Value: "19 months"},
            {Key: "20", Value: "20 months"},
            {Key: "21", Value: "21 months"},
            {Key: "22", Value: "22 months"},
            {Key: "23", Value: "23 months"},
            {Key: "24", Value: "24 months"},
        ]

        $scope.closeUserSuggestion = function (value) {
            console.log('clicked close');
            if (value == "userlocation") {
                $scope.userSuggestionLocationText = false;
                $scope.userSuggestionLocationBlockBulb = true;
                angular.element('.bulb-img').css('pointer-events', 'auto');
                $timeout.cancel($scope.promise);
                $interval.cancel($scope.interval);
            }
            if (value == "userage") {
                $scope.userSuggestionAgeText = false;
                $scope.userSuggestionAgeBlockBulb = true;
                angular.element('.bulb-img').css('pointer-events', 'auto');
                $timeout.cancel($scope.promise);
                $interval.cancel($scope.interval);
            }
            if (value == "userlanguage") {
                $scope.userSuggestionLanguageText = false;
                $scope.userSuggestionLanguageBlockBulb = true;
                angular.element('.bulb-img').css('pointer-events', 'auto');
                $timeout.cancel($scope.promise);
                $interval.cancel($scope.interval);
            }
            if (value == "usertargeting") {
                $scope.userSuggestionTargetingText = false;
                $scope.userSuggestionTargetingBlockBulb = true;
                angular.element('.bulb-img').css('pointer-events', 'auto');
                $timeout.cancel($scope.promise);
                $interval.cancel($scope.interval);
            }
        }


        $scope.openUserSuggestion = function (value) {

            //User Location
            if (value == "userlocation") {
                $scope.counterTimeLoc = 10;
                $scope.interval = $interval(function () {
                    --$scope.counterTimeLoc;
                }, 1000);
                $scope.userSuggestionLocationText = true;
                $scope.userSuggestionLocationBlockBulb = false;
                if ($scope.unmatchedLocation.length == $scope.locationObjTwitter.length) {
                    $scope.locationTruncate = false;
                    $scope.locationComplete = false;
                }
                else {
                    if ($scope.unmatchedLocationLength <= 70) {
                        $scope.locationTruncate = false;
                        $scope.locationComplete = true;
                    }
                    else {
                        $scope.locationTruncate = true;
                        $scope.locationComplete = false;
                    }
                }

                angular.element('.bulb-img').css('pointer-events', 'none');
                $scope.promise = $timeout(function () {
                    $scope.userSuggestionLocationText = false;
                    $scope.userSuggestionLocationBlockBulb = true;
                    $interval.cancel($scope.interval);
                    angular.element('.bulb-img').css('pointer-events', 'auto');
                }, 10000);
            }

            //User Age
            if (value == "userage") {
                $scope.counterTimeAge = 10;
                $scope.interval = $interval(function () {
                    --$scope.counterTimeAge;
                }, 1000);
                $scope.userSuggestionAgeText = true;
                $scope.userSuggestionAgeBlockBulb = false;
                angular.element('.bulb-img').css('pointer-events', 'none');
                $scope.promise = $timeout(function () {
                    $scope.userSuggestionAgeText = false;
                    $scope.userSuggestionAgeBlockBulb = true;
                    $interval.cancel($scope.interval);
                    angular.element('.bulb-img').css('pointer-events', 'auto');
                }, 10000);
            }


            //User Language
            if (value == "userlanguage") {
                $scope.counterTimeLang = 10;
                $scope.interval = $interval(function () {
                    --$scope.counterTimeLang;
                }, 1000);
                $scope.userSuggestionLanguageText = true;
                $scope.userSuggestionLanguageBlockBulb = false;
                if ($scope.unmatchedLanguage.length == $scope.languageObjTwitter.length) {
                    $scope.languageTruncate = false;
                    $scope.languageComplete = false;
                }
                else {
                    if ($scope.unmatchedLanguageLength <= 70) {
                        $scope.languageTruncate = false;
                        $scope.languageComplete = true;
                    }
                    else {
                        $scope.languageTruncate = true;
                        $scope.languageComplete = false;
                    }
                }

                angular.element('.bulb-img').css('pointer-events', 'none');
                $scope.promise = $timeout(function () {
                    $scope.userSuggestionLanguageText = false;
                    $scope.userSuggestionLanguageBlockBulb = true;
                    $interval.cancel($scope.interval);
                    angular.element('.bulb-img').css('pointer-events', 'auto');
                }, 10000);

            }

            //User Targeting
            if (value == "usertargeting") {
                $scope.counterTimeTarg = 10;
                $scope.interval = $interval(function () {
                    --$scope.counterTimeTarg;
                }, 1000);
                $scope.userSuggestionTargetingText = true;
                $scope.userSuggestionTargetingBlockBulb = false;

                if ($scope.unmatchedInterest.length == $scope.targetingInterest.length) {
                    $scope.targetingTruncate = false;
                    $scope.targetingComplete = false;
                }
                else {
                    if ($scope.unmatchedTargetingLength <= 70) {
                        $scope.targetingTruncate = false;
                        $scope.targetingComplete = true;
                    }
                    else {
                        $scope.targetingTruncate = true;
                        $scope.targetingComplete = false;
                    }
                }

                angular.element('.bulb-img').css('pointer-events', 'none');
                $scope.promise = $timeout(function () {
                    $scope.userSuggestionTargetingText = false;
                    $scope.userSuggestionTargetingBlockBulb = true;
                    $interval.cancel($scope.interval);
                    angular.element('.bulb-img').css('pointer-events', 'auto');
                }, 10000);
            }

        }

        $scope.ideaFocus = function (value) {
            angular.element('.bulb-img').css('pointer-events', 'auto');
            $timeout.cancel($scope.promise);
            $interval.cancel($scope.interval);
            switch (value) {
                case 'userlocation':
                    if ($scope.locationFlag == true) {
                        $scope.userSuggestionLocationBlock = true;
                        $scope.userSuggestionLocationBlockBulb = true;
                        $scope.userSuggestionLocationText = false;
                        //$scope.openUserSuggestion('userlocation');                                                         
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionLanguageBlock = false;
                        $scope.userSuggestionTargetingBlock = false;

                    }
                    else {
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionLanguageBlock = false;
                        $scope.userSuggestionTargetingBlock = false;
                    }
                    break;
                case 'userage':
                    if ($scope.ageFlag == true) {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionAgeBlock = true;
                        $scope.userSuggestionAgeBlockBulb = true;
                        $scope.userSuggestionAgeText = false;
                        $scope.userSuggestionLanguageBlock = false;
                        $scope.userSuggestionTargetingBlock = false;

                    }
                    else {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionLanguageBlock = false;
                        $scope.userSuggestionTargetingBlock = false;
                    }
                    break;
                case 'userlanguage':
                    if ($scope.languageFlag == true) {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionLanguageBlock = true;
                        $scope.userSuggestionLanguageBlockBulb = true;
                        $scope.userSuggestionLanguageText = false;
                        //$scope.openUserSuggestion('userlanguage');
                        $scope.userSuggestionTargetingBlock = false;

                    }
                    else {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionTargetingBlock = false;
                    }
                    break;
                case 'usertargeting':
                    if ($scope.targetingFlag == true) {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionLanguageBlock = false;
                        $scope.userSuggestionTargetingBlock = true;
                        $scope.userSuggestionTargetingBlockBulb = true;
                        $scope.userSuggestionTargetingText = false;

                    }
                    else {
                        $scope.userSuggestionLocationBlock = false;
                        $scope.userSuggestionAgeBlock = false;
                        $scope.userSuggestionLanguageBlock = false;
                    }
                    break;
            }
        };

        $scope.moreSuggestion = function (value) {
            console.log('clicked close');
            if (value == "userlocation") {
                console.log('clicked location');
                $scope.locationTruncate = false;
                $scope.locationComplete = true;
            }
            if (value == "userlanguage") {
                $scope.languageTruncate = false;
                $scope.languageComplete = true;
            }
            if (value == "usertargeting") {
                $scope.targetingComplete = true;
                $scope.targetingTruncate = false;
            }
        }



    }]);

app.directive('stepConnector', function () {
    return {
        restrict: 'A',
        replace: false,
        template: '',
        link: function ($scope) {
            $scope.$emit('details-loaded');
        }
    }
});
