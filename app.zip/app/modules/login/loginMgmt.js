var login = angular.module('login', ['ui.router', 'ngResource', 'ngAnimate']);

login.config(["$stateProvider", function ($stateProvider) {

        //login page state
        $stateProvider.state('login', {
            url: '/login',
            templateUrl: 'app/modules/login/index.html',
            controller: 'loginCtrl',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Login'
            }
        });
        $stateProvider.state('register', {
            url: '/register',
            templateUrl: 'app/modules/login/register.html',
            controller: 'loginCtrl',
            controllerAs: 'vm',
            data: {
                pageTitle: 'Register'
            }
        });

    }]);
login.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]);