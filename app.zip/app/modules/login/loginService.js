
login.service('loginService', ['$rootScope','$http', '$q', 'Flash', 'apiService', '$window', 'appSettings', 'globalData','netWorkData', '$state', function ($http, $rootScope, $q, Flash, apiService, $window, appSettings, globalData, netWorkData, $state) {



        var loginService = {};
        
        var apiBase = appSettings.apiBase;


        //service to communicate with users model to verify login credentials
        var accessLogin = function (parameters) {
            $rootScope.progressLoader = "block";
            /**
             * Login Rest API Header
             **/
            var loginConfigHeader = {
                headers: {
                    'Content-Type': 'application/json;'
                }
            }
            var deferred = $q.defer();
            apiService.create("/user/checkuser", parameters, loginConfigHeader).then(function (response) {
                if (response.appStatus == "0") {
                   // $rootScope.progressLoader = "none";.
					$window.localStorage.setItem("role", response.userRole);
					if($window.localStorage.getItem("role") != 'Admin'){
						searchUserById(response.userId, response.accessToken);
					}else{
						$state.go('appAdmin.adminhomedashboard');
					}
                    deferred.resolve(response);
                } else {
                    $rootScope.progressLoader = "none";
                    deferred.reject(response.errorMessage);
                }
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;
        };
        var forgetLoginService = function (parameters) {
            $rootScope.progressLoader = "block";
            /**
             * Forget Rest API Header
             **/
            var forgetConfigHeader = {
                headers: {
                    'Content-Type': 'application/json;',
                    'async': 'false;',
                    'dataType': 'jsonp;'
                }
            }
            var deferred = $q.defer();
            apiService.create("/user/resetpasswordrequest", parameters, forgetConfigHeader).then(function (response) {
                if (response)
                    
                    deferred.resolve(response);
                else
                    deferred.reject("Something went wrong while processing your request. Please Contact Administrator.");
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;
        };
                function clearField() {
                    alert("inside sweerv");
             if(document.getElementById) {
             document.forgetForm.reset();
             }
             }
            
        var registerUser = function (parameters, fileData) {
            $rootScope.progressLoader = "block";
            var deferred = $q.defer();
            /**
             * Account Creation Rest API Header
             **/
            var configHeader = {
                headers: {
                    'Content-Type': 'application/json;',
                    'async': 'false;',
                    'dataType': 'jsonp;'
                }
            }
			
            apiService.create("/user/createaccountrequest", parameters, configHeader).then(function (response) {
				var fileError = false;
				if(fileData!=undefined){
					if(fileData.type.toUpperCase()!='IMAGE/PNG'||fileData.type.toUpperCase()!='IMAGE/JPEG'||fileData.type.toUpperCase()!='IMAGE/JPG'|| fileData.size > 25000){
						fileError = true;
					}else{
						fileError = false;
					}
				}
				
                if (response.appStatus == 0 && !fileError && fileData != undefined) {
                    $rootScope.progressLoader = "none";
                    /**
                     * Upload Logo File Header
                     **/
                    var fd = new FormData();
                    fd.append('file', fileData);
                    fd.append('role', 'Account');
                    fd.append('id', response.accountId);
                    var uploadConfigHeader = {
                        transformRequest: angular.identity,
                        headers: {
                            'Content-Type': undefined
                        }
                    };				
					apiService.uploadImage("/uploadimage", fd, uploadConfigHeader).then(function (uploadResponse) {
                        if (uploadResponse.appStatus == 0) {
                            $rootScope.progressLoader = "none";
                            //deferred.resolve(uploadResponse);
                            var updateParam = {
                                "accountId": response.accountId,
                                "logoUrl": uploadResponse.successMessage
                            };
                            /**
                             * Update Account Logo URL to System
                             **/
                            apiService.create("/user/updateaccountlogo", updateParam, configHeader).then(function (updateResponse) {
                                deferred.resolve(updateResponse);
                            },
                                    function (updateResponse) {
                                        deferred.reject(updateResponse);
                                    });
                            return deferred.promise;
                        } else {
                            deferred.resolve(uploadResponse);
                        }
                    },
                            function (uploadResponse) {
                                deferred.reject(uploadResponse);
                            });
                    return deferred.promise;
					
                } else {
                    deferred.resolve(response);
                }
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;
        };
        
        var searchUserById = function(searchUserId, accessToken){
            $rootScope.progressLoader = "block";
               /**
             * Search Rest API Header
             **/
            var configHeader = {
                headers: {
                    'userId': searchUserId,
                    'accessToken': accessToken
                }
            }
            /*var searchParam = {
             'searchedUserId': $window.localStorage.getItem("userId")
             }*/
            var url = "/user/searchuser" + "?searchedUserId=" + searchUserId;
            var deferred = $q.defer();
            apiService.get(url, configHeader).then(function (getResp) {
				console.log(getResp);
               /* if (getResp.appStatus == 0) {
                    $window.localStorage.setItem("userNetworkMapId", "300002");
                    $window.localStorage.setItem("accountId", getResp.accountId);
                    $window.localStorage.setItem("tempCampaignName", parameters.campaignName);*/
                 if (getResp.appStatus == "0") {
                     $rootScope.progressLoader = "none";
                    $window.localStorage.setItem("accountId", getResp.searchedUser.accountId);
					$window.localStorage.setItem("accountName", getResp.searchedUser.userGroup);
					if(getResp.advertiserId!='' && getResp.advertiserId!=undefined){
						$window.localStorage.setItem("advertiserId", getResp.advertiserId);
					}
                                        
					var obj1 = {"accountName":getResp.searchedUser.userGroup, "Id":getResp.searchedUser.accountId}
					/* var obj2 = {"campaignName":"Social Media 1","campaignaudienceDetailedTargeting":"Aviation"}
					var obj3 = {"adSetName":"Social Media Adset","campaignAudienceLocationType":"Include"}
					var obj4 = {"campaignName":"Social Media AdID","marketingObjective":"PAGE_LIKES"}
					var obj5 = {"adCreativeName":"Social Media AdCreativeID","impression":"IMPRESSIONS"} */
					console.log($window.localStorage.getItem("role"));
					if($window.localStorage.getItem("role") == 'Advertiser'){
						netWorkData.networkDataFetch();
					}
					else if ($window.localStorage.getItem("role") == 'Ops Team'){
						$window.localStorage.setItem("OpsTeamId", getResp.opsTeamId);
						netWorkData.networkDataFetch();
					}
					else if ($window.localStorage.getItem("role") == 'Account'){
						netWorkData.networkDataFetch();
					}
					
					globalData.initialUpdate();
					console.log(getResp.searchedUser.accountId)
				//	globalData.setLocal("account", getResp.searchedUser.accountId, obj1);
				//	globalData.setDraftLocal("account", getResp.searchedUser.accountId, obj1);
					/* globalData.setLocal("campaign", "23842550725310108", obj2);	
					globalData.setLocal("adset","138425310108", obj3);	
					globalData.setLocal("adId","1131010545788", obj4);	
					globalData.setLocal("adCreativeId","189655310108", obj5);
					
					var  getObj =globalData.getLocal("189655310108");
					//var  getObj =globalData.getLocal(getResp.searchedUser.accountId);
					console.log(getObj); */
					var role = $window.localStorage.getItem("role");
					$rootScope.progressLoader = "none";
					if (role == "Account") {
                        $state.go('app.accountdashboard');
                    } else if (role == "Advertiser") {
                        $state.go('app.advertiserdashboard');
                    }else if (role == "Ops Team") {
                        $state.go('app.opsteamdashboard');
                    }else {
                        
                        Flash.create('danger', 'Invalid Role. Please contact Administator', 'large-text');
                    }
					
                    deferred.resolve(getResp);
                } else {
                    deferred.reject(getResp.errorMessage);
                }
            },
                    function (getResp) {
                        deferred.reject(getResp);
                    });
            return deferred.promise;
                            
        };
        //get advertiser id from ops team data fetch
        
        var campService = function (parameters) {
            $rootScope.progressLoader = "block";
			console.log('getResp')
            /**
             * Search Rest API Header
             **/
            var configHeader = {
                headers: {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }
            }
            /*var searchParam = {
             'searchedUserId': $window.localStorage.getItem("userId")
             }*/
            // url: apiBase +'/user/fetchadvertisernetwork?accountId='+$scope.accountId,
            var url = "/user/fetchadvertisernetwork?accountId=" + $window.localStorage.getItem("accountId");
            var deferred = $q.defer();
            apiService.get(url, configHeader).then(function (getResp) {
				console.log(getResp);
                if (getResp.appStatus == 0) {
                    $rootScope.progressLoader = "none";
                    //var fetchurl = "/user/fetchadvertisernetwork" + "?accountId=" + getResp.accountId;
                    //apiService.get(fetchurl, configHeader).then(function (getAccountFetchResp) {
                        //if (getAccountFetchResp.appStatus == 0) {
                            //$window.localStorage.setItem("userNetworkMapId", getAccountFetchResp.advertiserNetworkList[0][0].userNetworkMapId);
                            //$window.localStorage.setItem("accountId", getResp.accountId);
                            $window.localStorage.setItem("userNetworkMapId", getResp.advertiserNetworkList[0].userNetworkMapId);
							//netWorkData.getAccessToken($window.localStorage.getItem("userNetworkMapId"));
                            //$window.localStorage.setItem("accountId", getResp.accountId);
                            $window.localStorage.setItem("tempCampaignName", parameters.campaignName);
                            var createCampParam = {
                                'userId': $window.localStorage.getItem("userId"),
                                'accessToken': $window.localStorage.getItem("accessToken"),
                                "userNetworkMapId": getResp.advertiserNetworkList[0].userNetworkMapId,
								"networkAdAccountId": $window.localStorage.getItem("networkAdAccountId"),
                               // "networkAccessToken": $window.localStorage.getItem("networkAccessToken"),
                                "campaignName": parameters.campaignName, // campaign name field
                                "objective": parameters.objective, //objective enum
                                "campaignStatus": "PAUSED",
                            };
                            /**
                             * Update Account Logo URL to System
                             **/
							 
							 
                            apiService.createthirdparty("/createcampaign", createCampParam, configHeader).then(function (campResponse) {
                                deferred.resolve(campResponse);
                            },
							function (updateResponse) {
								deferred.reject(updateResponse);
							});
                            return deferred.promise;
                        /*} else {
                            deferred.resolve(getAccountFetchResp);
                        }*/
                    //},
                            /*function (response) {
                                deferred.reject(response);
                            });*/
                    return deferred.promise;
                } else {
                    if(getResp.appStatus > 0 && (getResp.errorMessage=='Access token is invalid or expired' || getResp.errorMessage=='Access Token is invalid or expired.')){
                        $window.localStorage.setItem("TokenExpired",true);
                        $state.go('login');
                    }
                    deferred.resolve(getResp);
                }
            },
                    function (response) {
                        deferred.reject(response);
                    });
            return deferred.promise;
        };



        var campSummaryService = function (parameters) {
            /**
             * Search Rest API Header
             **/
            /*var configHeader = {
                headers: {'Content-Type': 'application/json'}
            };*/
            var fbAdId = $window.localStorage.getItem("adId");
            var fbSetId = $window.localStorage.getItem("adsetId");
            var fbCampaignId = $window.localStorage.getItem("campaignId");
            var fbAdUrl = "https://graph.facebook.com/v2.8/" + fbAdId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
            var fbSetUrl = "https://graph.facebook.com/v2.8/" + fbSetId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
            var fbCampUrl = "https://graph.facebook.com/v2.8/" + fbCampaignId + "?method=post&access_token=" + $window.localStorage.getItem("networkAccessToken") + "&status=ACTIVE";
            var deferred = $q.defer();
			
			apiService.urlget(fbAdUrl).then(function (getResp) {
               deferred.resolve(getResp);               
            },
			function (response) {
				deferred.reject(response);
			});
			
			apiService.urlget(fbSetUrl).then(function (fbSetResp) {
				deferred.resolve(fbSetResp);				
			},
			function (response) {
				deferred.reject(response);
			});
							
			apiService.urlget(fbCampUrl).then(function (campResponse) {
				deferred.resolve(campResponse);
			},
			function (campResponse) {
				deferred.reject(campResponse);
			});
			
			return deferred.promise;
							
            
        };

        loginService.accessLogin = accessLogin;
        loginService.registerUser = registerUser;
        loginService.forgetLoginService = forgetLoginService;
        loginService.campService = campService;
        loginService.campSummaryService = campSummaryService;

        return loginService;

    }]);