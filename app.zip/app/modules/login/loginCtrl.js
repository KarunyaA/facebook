login.controller("loginCtrl", ['$rootScope', '$scope', '$http', '$state', '$location', 'loginService', 'Flash', 'apiService', '$window','globalData',
    function ($rootScope, $scope, $http, $state, $location, loginService, Flash, apiService, $window, globalData) {
        var vm = this;
		$scope.onResetFailure = false;
		
        vm.getUser = {};
        vm.setUser = {};
        $rootScope.progressLoader = "none";
        $window.localStorage.clear();
        if($window.localStorage.getItem("TokenExpired")=='true'){
            $rootScope.progressLoader = "none";
            Flash.create('danger', 'Access token is invalid or expired', 'large-text');
            $window.localStorage.setItem("TokenExpired",false);
        }
        vm.signIn = true;
		$scope.connErr = false;
        $scope.acc_name = {red: false};
        $scope.acc_url = {red: false};
        $scope.acc_poc = {red: false};
        $scope.acc_contact = {red: false};
        $scope.acc_email = {red: false};
        $scope.acc_add = {red: false};
        $scope.acc_logo = {red: false};
       
        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */

        vm.login = function (data) {
            $window.localStorage.setItem("TokenExpired",false);
            $window.localStorage.setItem("PageRefreshed",false);
            $rootScope.progressLoader = "block";
            var xorKey = 2;
            userPassword = data.password;
            var encPassword = "";
			if(userPassword != undefined){
				for (i = 0; i < userPassword.length; ++i) {
					encPassword += String.fromCharCode(xorKey ^ userPassword.charCodeAt(i));
				}
			}	
            var logParam = {
                'userId': data.userId,
                'password': encPassword
            };
			
            loginService.accessLogin(logParam).then(function (response) {
                $rootScope.progressLoader = "none";
                if (response.appStatus != "0") {     
                   // $rootScope.progressLoader = "none";                    
                    Flash.create('danger', 'Password is invalid', 'large-text');
                } else {
                    $rootScope.progressLoader = "none";
                    $window.localStorage.setItem("userId", response.userId);
                    $window.localStorage.setItem("accessToken", response.accessToken);
                    var role = response.userRole; // response from api with role detail
                    $window.localStorage.setItem('role', role);// Set the stringified user data into local storage
                    $rootScope.role = role;// Putting the user's role on $rootScope for access by other controllers
                   /*  if (role == "Admin") {
                        $state.go('appAdmin.adminhomedashboard');
                    } else if (role == "Account") {
                        $state.go('app.accountdashboard');
                    } else if (role == "Advertiser") {
                        $state.go('app.advertiserdashboard');
                    }else if (role == "Ops Team") {
                        $state.go('app.opsteamdashboard');
                    }else {
                        
                        Flash.create('danger', 'Invalid Role. Please contact Administator', 'large-text');
                    } */
                }

            },
            function (response) {
                $rootScope.progressLoader = "none";
                console.log(response)
				if(logParam.userId==undefined || response=='userId is empty' || logParam.userId==''){
					$scope.errorMessage='Please enter your username';
					$scope.useridinvalid=true;
					$scope.pwdinvalid=false;
					$scope.useridnotfound=false;
				}
				if(response=='password is empty' && logParam.userId !=''){
					$scope.errorMessage='Please enter your password';
                    $scope.useridinvalid=false;
                    $scope.pwdinvalid=true;
                    $scope.useridnotfound=false;
				}
                if(response=="User id is invalid.")
                {
                   //Flash.create('danger', 'User id is invalid.', 'large-text');
                   $scope.errorMessage='Username is invalid';
                   $scope.useridinvalid=true;
                   $scope.pwdinvalid=false;
                   $scope.useridnotfound=false;
                }
                
                 if(response=="Password is invalid.")
                {
                    //Flash.create('danger', 'Password is invalid.', 'large-text');
                    $scope.errorMessage='Incorrect password. Kindly re-enter your password';
                    $scope.useridinvalid=false;					
                    $scope.pwdinvalid=true;
                    $scope.useridnotfound=false;
                }              
                if(response=="UserId not found.")
                {
                    $scope.errorMessage='Username and password does not match';
                    $scope.useridnotfound=true;
                    $scope.useridinvalid=false;
                    $scope.pwdinvalid=false;
                }
                //Flash.create('danger', 'Post Request Failed', 'large-text');
                //alert('hi')
            });
        };
        $scope.hide=function()
        {
            $scope.useridinvalid=false;
             $scope.pwdinvalid=false;
             $scope.useridnotfound=false;
            
        }
        vm.forgetLogin = function (data) {
            $rootScope.progressLoader = "block";
            loginService.forgetLoginService(data).then(function (response) {
                if (response.appStatus == 0) {
                    $rootScope.progressLoader = "none";
                    //Flash.create('danger', response.errorMessage, 'large-text');
                    $scope.closeForgetPopup();
                    $scope.showForgetSuccessPopup();
					//$scope.onResetFailure = false;
					vm.user.emailAddress = "";
                } else {
                    $rootScope.progressLoader = "none";
					if(response.errorId==5004){
						$scope.forgetFailureTxt = "Please enter valid email id";
						$scope.onResetFailure = true;	
						vm.user.emailAddress ="";					
						$scope.closeForgetPopup();
						$scope.showForgetFailurePopup();
					}else{
						$scope.forgetFailureTxt = response.errorMessage;
					    $scope.onResetFailure = false;
						vm.user.emailAddress ="";					
					    $scope.closeForgetPopup();
                        $scope.showForgetFailurePopup();
                    }
				   
                    //Flash.create('danger', response.successMessage, 'large-text');
                }

            },
                    function () {
                        Flash.create('danger', 'Post Request Failed', 'large-text');
                    });
        }
       
        /**
         * 
         * @param {type} data
         * @returns {undefined}
         */
        vm.registerAccount = function (data) {
            $rootScope.progressLoader = "block";
            var errorMessage;
            var file = $scope.getCompanyLogo;
            
            loginService.registerUser(data, file).then(function (response) {
                if (response.appStatus == 0) {
                    $rootScope.progressLoader = "none";
                    $scope.successPopup();
                    
                } else {
                    $rootScope.progressLoader = "none";
                    if(response.errorId==3056)
                    {
                       $scope.acc_name.red = true;
                       $scope.accnameempty = false;
                       $scope.nameexist=true;
					   $scope.failureMessageTxt = response.errorMessage;
                    }   
                    else if(response.errorId==3024)
                    {
                        $scope.acc_email.red = true;
                        $scope.accemailempty = false;
                       $scope.emailexist=true;
					   $scope.failureMessageTxt = response.errorMessage;
                    } 
                    else if(response.status==404 || response.status==500){
							$scope.failureMessageTxt ="  Due to some connectivity the issue task cannot be completed.";
							$scope.connErr = true;
					}else{
						$scope.failureMessageTxt = response.errorMessage;
						$scope.connErr = false;
					}
                    $scope.failurePopup();
                    }


            });

        };
        /**
         * 
         * @returns true
         */
        $scope.goToRegister = function () {
            $state.go('register');
        };

        /**
         * 
         * @returns true
         */
        $scope.forgetAccount = function () {
           
            $scope.showForgetPopup();
           
        };
                  
        /**
         * 
         * @param {type} element
         * @returns {filename}
         */
        $scope.getuploadfilename = function (element) {
            $scope.$apply(function ($scope) {
                
                if(element.files[0].size<25000)
                {
                    $scope.uploadedfilename = element.files[0];
                    $scope.maxSizeError = false;
                    $scope.acc_logo.red=false;
					if(element.files[0].type.toUpperCase()=='IMAGE/PNG'||element.files[0].type.toUpperCase()=='IMAGE/JPEG'||element.files[0].type.toUpperCase()=='IMAGE/JPG'){
						$scope.uploadedfilename = element.files[0];
						$scope.maxSizeError = false;
						$scope.acc_logo.red=false;
				}else{
					$scope.maxSizeError = true;
                    $scope.acc_logo.red=true;
					$scope.imageErrorMsg = '  Please upload supported file type (PNG,JPG,JPEG)'
					}
                }else{
                    $scope.maxSizeError = true;
                    $scope.acc_logo.red=true;
					$scope.imageErrorMsg = '  Max file size of 25KB';
                } 
				
            });
        };
        //Popup Reject
        var modalFailurePop = $(".failure-popup");// Get the modal Failure req
        var modalPop = $(".popup");// Get the modal Success req
        var modalForgetPop = $(".forget-popup");// Get the modal Failure req
        var modalForgetSuccessPop = $(".forget-success-popup");// Get the modal Failure req
        var modalForgetFailurePop = $(".forget-failure-popup");// Get the modal Failure req

        var btn = $(".adminApprove");// Get the button that opens the modal
        var span = document.getElementsByClassName("close")[0];// Get the <span> element that closes the modal

        $scope.failurePopup = function () {
                        $scope.popupTitle="Account request"
                        $scope.popupMessage=""
                        $scope.error=true;
                        $scope.success=false;
                        modalPop.show();
        }
        $scope.closeFailurePopup = function () {
            modalPop.hide();
        }
        $scope.successPopup = function () {
            
			$scope.popupMessage = "Your request has been successfully submitted to AdConcierge Support.Please check your registerd email ID for further information.";
                        $scope.popupTitle="Account request"
                        $scope.success=true;
                        $scope.error=false;
                        modalPop.show();
        }
        $scope.successpopup_close = function()
        {
            var modalApproveReq = $(".account_modalApprove");
            modalApproveReq.hide();
            $scope.edit_view = false;
        }
        $scope.closeSuccessPopup = function () {
            modalPop.hide();
			$state.go('login')
        }
        $scope.showForgetPopup = function () {
		//	vm.user.emailAddress = "";
            modalForgetPop.show();
        }
        $scope.closeForgetPopup = function () {
			//vm.user.emailAddress = "";
            modalForgetPop.hide();
			modalForgetFailurePop.hide();
        }
        $scope.showForgetSuccessPopup = function () {          
            modalForgetSuccessPop.show();
        }
        $scope.closeForgetSuccessPopup = function () {
             vm.user.emailAddress = "";
             modalForgetSuccessPop.hide();
        }
        $scope.showForgetFailurePopup = function () {
            modalForgetFailurePop.show();
        }
        $scope.closeForgetFailurePopup = function () {
            vm.user.emailAddress = "";
            modalForgetFailurePop.hide();
        }
        $scope.reset = function (getUser) {
            getUser.accountName = null;
            getUser.accountUrl = null;
            getUser.companyPoc = null;
            getUser.contact = null;
            getUser.email = null;
            getUser.address = null;
            getUser.tempfilename = null;
            $scope.uploadedfilename = null;
            $state.go('login');
        }


        $scope.acc_name_empty_check = function (val)
        {
            $scope.nameexist=false;
            $scope.accnameempty = false;	
			if(val==""||val== undefined||val.toLowerCase()==="null"){
				$scope.accMsg="  Please enter valid account name";					
				$scope.acc_name.red = true;
                $scope.accnameempty = true;
			}else{
				if(/[-~!@#$%^&<>.\/\\,:;"'?|+=_()\*]/.test(val)){
					$scope.accMsg="  Please enter only alpha numeric characters"
					$scope.acc_name.red = true;
					$scope.accnameempty = true;			
				}else{
					$scope.acc_name.red = false;
					$scope.accnameempty = false;
				}
			}			
        }
        $scope.acc_url_empty_check = function (val1)
        {
            $scope.accurlempty = false;
            if (val1 == "" || val1 == undefined || val1 === "null")
            {
                $scope.acc_url.red = true;
                $scope.accurlempty = true;
            }
            else
            {
                $scope.acc_url.red = false;
                $scope.accurlempty = false;
            }
			if(val1 !=""){
				if(/(^(https|http)(:\/\/www[.])[a-zA-Z0-9]+)(([.][a-zA-Z0-9]{2,})*)(([.][a-zA-Z]{2,})+)$/.test(val1)){
					$scope.acc_url.red = false;
					$scope.accurlempty = false;
				}else{
					$scope.acc_url.red = true;
					$scope.accurlempty = true;	
				}
			}
        }
        $scope.acc_poc_empty_check = function (val)
        {
			$scope.accpocempty = false;	
			if(val== undefined || val=="" ||val.toLowerCase()==="null"){
				$scope.pocMsg="  Please enter valid poc name";					
				$scope.acc_poc.red = true;
                $scope.accpocempty = true;
			}else{
				if(/[-~!@#$%^&<>.\/\\,:;"'?|+=_()\*]/.test(val) || !isNaN(val)){
					$scope.pocMsg="  Please enter only alpha numeric characters"
					$scope.acc_poc.red = true;
					$scope.accpocempty = true;			
				}else{
					$scope.acc_poc.red = false;
					$scope.accpocempty = false;
				}
			}	
        }
        $scope.acc_contact_empty_check = function (val)
        {
            $scope.acccontactempty = false;

            if (val == "" || val == undefined || val === "null")
            {
                $scope.acc_contact.red = true;
                $scope.acccontactempty = true;
            }
            else
            {
                $scope.acc_contact.red = false;
                $scope.acccontactempty = false;
            }
        }
        $scope.acc_email_empty_check = function (val)
        {
            $scope.emailexist=false;
            $scope.accemailempty = false;
            if (val === "" || val == undefined || val === "null")
            {
                $scope.acc_email.red = true;
                $scope.accemailempty = true;
            }
            else
            {
                $scope.acc_email.red = false;
                $scope.accemailempty = false;
            }
			
			if(val!=""){
				if(/(^[0-9]*[a-zA-Z]+[0-9]*[a-zA-Z]*[@])((((([a-z0-9])+(:|_))*)(([0-9]*[a-z]+[0-9]*)+)(((:|_)([a-z0-9])+)*))+)(([.][a-z]{2,5})+)$/.test(val)){
					$scope.acc_email.red = false;
					$scope.accemailempty = false;					
				}else{
					$scope.acc_email.red = true;
					$scope.accemailempty = true;				
				}	
			}
        }
        $scope.acc_add_empty_check = function (val)
        {		
			$scope.accaddempty = false;	
			if(val===""|| val== undefined || val.toLowerCase()==="null"){
				$scope.addMsg="  Please enter valid address";					
				$scope.acc_add.red = true;
                $scope.accaddempty = true;
			}else{
				
					$scope.acc_add.red = false;
					$scope.accaddempty = false;
				
			}
        }
       




    }]);

login.directive('validNumber', function () {
    return {
        require: '?ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }
            ngModelCtrl.$parsers.push(function (val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }
                var clean = val.replace(/[^0-9]+/g, '');
                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });
            element.bind('keypress', function (event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});

