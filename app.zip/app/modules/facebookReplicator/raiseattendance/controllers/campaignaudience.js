var replicatorFBApp = angular.module('replicator', ['app']);
replicatorFBApp.controller("replicatoreventscampaignaudienceController", ['$rootScope', '$scope', '$state', '$location', '$filter', '$interval', '$http', '$q', 'adminDash', 'Flash', 'apiService', '$window', 'appSettings', 'globalData', 'netWorkData', '$timeout', 'facebookGetPost', 'parser',
    function ($rootScope, $scope, $state, $location, $filter, $interval, $http, $q, adminDash, Flash, apiService, $window, appSettings, globalData, netWorkData, $timeout, facebookGetPost, parser) {

        var vm = this;
        var apiTPBase = appSettings.apiTPBase;
        var apiBase = appSettings.apiBase;
        $scope.networkAdAccountId = $window.localStorage.getItem("networkAdAccountId");
        $rootScope.networkAccessToken = $window.localStorage.getItem("networkAccessToken");
        $scope.selectedObjective = $window.localStorage.getItem("marketingObjective");
        $scope.campaignAudienceLanguageArr = [];
        $scope.campaignAudienceCampaignConversionPixelArr = [];
        $scope.campaignAudienceCampaignOfferArr = [];
        $scope.editAdsetErrorMsg = 'none';
        $scope.promotionObjective = 'no';
        $scope.PlacementsValues = [];
        $rootScope.progressLoader = "none";
        vm.showDetails = true;
        vm.home = {};
        $scope.secondActiveDiv = 'yes';
        $scope.campaignAudienceCampaignTargetLoader = false;
        $scope.campaignAudienceCampaignOfferLoader = false;
        $scope.campaignAudienceCampaignConversionPixelLoader = false;
        $scope.firstActiveDivImg = true;
        $scope.secondActiveDivImg = false;
        $scope.thirdActiveDivImg = false;
        $scope.fourthActiveDivImg = false;
        $scope.fifthActiveDivImg = false;
        $scope.ngLanLoader = false;
        $scope.ngLocLoader = false;
        $scope.reverse = true;
        $scope.currentPage = 1;
        $scope.campaignAudienceGender = 'all';
        $scope.campaignAudienceAgeFrom = '18';
        $scope.campaignAudienceAgeTo = '65';
        $scope.campaignAudienceLanguage = '';
        $scope.campaignAudienceLocationType = 'Include';
        $scope.FBName = '';
        $scope.selectedData = null;
        $scope.campaignAudienceCampaignTargetType = false;
        $scope.demographics = false;
        $scope.interests = false;
        $scope.behaviors = false;
        $scope.more = false;
        $scope.viewPromotion = true;
        $scope.audienceNum = 1;
        $scope.mobileView = false;
        $scope.adsetDetailsJSON = {}
        $scope.errLoc = 1;
        $scope.adminUserRole = false;
        $scope.offerobjective = false;
        $scope.searchDemo = [];
        $scope.mapLocation=false;
        $scope.campaignAudienceGender1 = "";
			$scope.userSuggestionLanBlock = false;
	$scope.userSuggestionLanText = false;	
	$scope.userSuggestionAgeText = false;	
	$scope.userSuggestionAgeBlock =false;
	$scope.userSuggestionLocBlock =false;
	$scope.userSuggestionLocText =false;	
	$scope.userSuggestionDTBlock =false;
	$scope.userSuggestionDTText =false;
        /*$scope.isNumber= function (n) {
         return !isNaN(parseFloat(n)) && isFinite(n);
         };*/

	$scope.locationTruncate = false;
	$scope.locationComplete = false;
	$scope.languageTruncate = false;
	$scope.languageComplete = false;
	$scope.targetingTruncate = false;
	$scope.targetingComplete = false;

        var w = angular.element($window);
        w.bind('click', function (e) {
            if (this) {
                setTimeout($scope.showWindowDetailTargetingListing, 50);
                //$scope.showDetailTargetingListing();
            }

        });


        $scope.showWindowDetailTargetingListing = function () {
            $scope.$apply(function () {
                $scope.detailtargetinglisting = false;
                $scope.detailtargetingsearch = false;
            });

        };

        $scope.showDetailTargetingListing = function () {
            $scope.detailtargetinglisting = false;
            $scope.detailtargetingsearch = false;
        };
		
		$scope.closeUserSuggestion = function(value){
        angular.element('.bulb-img').css('pointer-events', 'auto');
        if (value == "location") {
            $scope.userSuggestionLocText = false;
            $scope.userSuggestionLocBlockBulb = true;
            $timeout.cancel($scope.promiselocation);
            $interval.cancel($scope.intervallocation);
            $scope.counterTimeLocation=0;
        }
        if (value == "language") {
            $scope.userSuggestionLanText = false;
            $scope.userSuggestionLanBlockBulb = true;
            $timeout.cancel($scope.promiselanguage);
            $interval.cancel($scope.intervallanguage);
            $scope.counterTimeLanguage=0;
        }
        if (value == "targeting") {
            $scope.userSuggestionDTText = false;
            $scope.userSuggestionDTBlockBulb = true;
            $timeout.cancel($scope.promiseDT);
            $interval.cancel($scope.intervalDT);
            $scope.counterTimeTarget=0;
        }
        if (value == "age") {
            $scope.userSuggestionAgeText = false;
            $scope.userSuggestionAgeBlockBulb = true;
            $timeout.cancel($scope.promise);
            $interval.cancel($scope.interval);
            $scope.counterTimeAge=0;
        }
                               
                }
                
	$scope.openUserSuggestion = function(value){
        //User Location
        if (value == "location") {
            $scope.counterTimeLocation = 10;
            $scope.intervallocation = $interval(function () {
                --$scope.counterTimeLocation;
            }, 1000);
            $scope.userSuggestionLocText = true;
            $scope.userSuggestionLocBlockBulb = false;
            if ($scope.unmatchedLocation.length == $scope.locationDetails.length) {
                $scope.locationTruncate = false;
                $scope.locationComplete = false;
            } else {
                if($scope.unmatchedLocationLength <= 70) {
                    $scope.locationTruncate = false;
                    $scope.locationComplete = true;
                } else {
                    $scope.locationTruncate = true;
                    $scope.locationComplete = false;
                }
            }
            angular.element('.bulb-img').css('pointer-events', 'none');
            $scope.promiselocation = $timeout(function () {
                $scope.userSuggestionLocText = false;
                $scope.userSuggestionLocBlockBulb = true;
                $interval.cancel($scope.intervallocation);
                angular.element('.bulb-img').css('pointer-events', 'auto');
            }, 10000);
        } else if (value == "language") {
            $scope.counterTimeLanguage = 10;
            $scope.intervallanguage = $interval(function () {
                --$scope.counterTimeLanguage;
            }, 1000);
            $scope.userSuggestionLanText = true;
            $scope.userSuggestionLanBlockBulb = false;
            if ($scope.unmatchedLanguage.length == $scope.languageDetails.length) {
                $scope.languageTruncate = false;
                $scope.languageComplete = false;
            } else {
                if ($scope.unmatchedLanguageLength <= 70) {
                    $scope.languageTruncate = false;
                    $scope.languageComplete = true;
                } else {
                    $scope.languageTruncate = true;
                    $scope.languageComplete = false;
                }
            }
            angular.element('.bulb-img').css('pointer-events', 'none');
            $scope.promiselanguage = $timeout(function () {
                $scope.userSuggestionLanText = false;
                $scope.userSuggestionLanBlockBulb = true;
                $interval.cancel($scope.intervallanguage);
                angular.element('.bulb-img').css('pointer-events', 'auto');
            }, 10000);
        } else if (value == "targeting") {
            $scope.counterTimeTarget = 10;
            $scope.intervalDT = $interval(function () {
                --$scope.counterTimeTarget;
            }, 1000);
            $scope.userSuggestionDTText = true;
            $scope.userSuggestionDTBlockBulb = false;
            if ($scope.unmatchedInterest.length == $scope.interestArray.length) {
                $scope.targetingTruncate = false;
                $scope.targetingComplete = false;
            } else {
                if ($scope.unmatchedTargetingLength <= 70) {
                    $scope.targetingTruncate = false;
                    $scope.targetingComplete = true;
                } else {
                    $scope.targetingTruncate = true;
                    $scope.targetingComplete = false;
                }
            }
            angular.element('.bulb-img').css('pointer-events', 'none');
            $scope.promiseDT = $timeout(function () {
                $scope.userSuggestionDTText = false;
                $scope.userSuggestionDTBlockBulb = true;
                $interval.cancel($scope.intervalDT);
                angular.element('.bulb-img').css('pointer-events', 'auto');
            }, 10000);
        } else if (value == "age") {
            $scope.counterTimeAge = 10;
            $scope.interval = $interval(function () {
                --$scope.counterTimeAge;
            }, 1000);
            $scope.userSuggestionAgeText = true;
            $scope.userSuggestionAgeBlockBulb = false;
            $timeout(function () {
                $scope.userSuggestionAgeText = false;
                $scope.userSuggestionAgeBlockBulb = true;
                $interval.cancel($scope.interval);
                $scope.counterTimeAge = 0;
            }, 10000);
        }
				}
		$scope.ideaFocus = function (value) {
        angular.element('.bulb-img').css('pointer-events', 'auto');
        switch (value) {
            case 'location':
                if ($scope.locationflag == true) {
                    $scope.userSuggestionLocBlock = true;
                    $scope.userSuggestionLocBlockBulb = true;
                    $scope.userSuggestionLocText = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanBlock = false;
                    $scope.userSuggestionDTBlock = false;
                    $timeout.cancel($scope.promiselocation);
                    $interval.cancel($scope.intervallocation);
                } else {
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanBlock = false;
                    $scope.userSuggestionDTBlock = false;
                }
                break;
            case 'age':
                if ($scope.ageFlag == true) {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionAgeBlock = true;
                    $scope.userSuggestionAgeBlockBulb = true;
                    $scope.userSuggestionAgeText = false;
                    $scope.userSuggestionLanBlock = false;
                    $scope.userSuggestionDTBlock = false;
                    $timeout.cancel($scope.promise);
                    $interval.cancel($scope.interval);
                } else {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionLanBlock = false;
                    $scope.userSuggestionDTBlock = false;
                }
                break;
            case 'language':
                if ($scope.languageflag == true) {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanBlock = true;
                    $scope.userSuggestionLanBlockBulb = true;
                    $scope.userSuggestionLanText = false;
                    $scope.userSuggestionDTBlock = false;
                    $timeout.cancel($scope.promiselanguage);
                    $interval.cancel($scope.intervallanguage);
                } else {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionDTBlock = false;
                }
                break;
            case 'targeting':
                if ($scope.interestflag == true) {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanBlock = false;
                    $scope.userSuggestionDTBlock = true;
                    $scope.userSuggestionDTBlockBulb = true;
                    $scope.userSuggestionDTText = false;
                    $timeout.cancel($scope.promiseDT);
                    $interval.cancel($scope.intervalDT);
                } else {
                    $scope.userSuggestionLocBlock = false;
                    $scope.userSuggestionAgeBlock = false;
                    $scope.userSuggestionLanBlock = false;
                }
                break;
        }
        };	

        $scope.moreSuggestion = function (value) {
            if (value == "userlocation") {
                $scope.locationTruncate = false;
                $scope.locationComplete = true;
            }
            if (value == "userlanguage") {
                $scope.languageTruncate = false;
                $scope.languageComplete = true;
            }
            if (value == "usertargeting") {
                $scope.targetingComplete = true;
                $scope.targetingTruncate = false;
            }
        }

        $scope.showDetailTargeting= function(){
        $scope.detailtargetinglisting = false;
        $scope.detailtargetingsearch = true;
        $scope.showSearchKeyword = 0;
        $( "#collapseDetail" ).removeClass( "dropdown-search" );
        $('.drop-search').hide();
        $('.drop-list').hide();
    }
         

        $scope.charExist = function (n) {
            if (n.indexOf('Checkbox') !== -1) {
                return 'Checkbox';
            } else if (n.indexOf('Search') !== -1) {
                return 'Search';
            } else {
                return 'Dropdown';
            }
            //n.includes("Checkbox");
        };

        $scope.everyoneArr = [];
        $scope.LocationTargetArr = [
            {Key: "everyone", Value: "Everyone in this location"},
            {Key: "home", Value: "People who live in this location"},
            {Key: "recent", Value: "People recently in this location"},
            {Key: "travel_in", Value: "People travelling in this location"}
        ];
        //DEFAULT SELECTION

        $scope.DetailedTargetingArr = [
            {Key: "demographics", Value: "Demographics"},
            {Key: "interests", Value: "Interests"},
            {Key: "behaviors", Value: "Behaviours"},
            {Key: "more", Value: "More Categories"}
        ];

        $scope.DetailedTargetingSecondArr = [
            {Key: "Education", Value: "Education"},
            {Key: "EthnicAffinity", Value: "Ethnic Affinity"},
            {Key: "Generation", Value: "Generation"},
            {Key: "Home", Value: "Home"}
        ];

        $scope.locationStatusArr = [
            {Key: "Include", Value: "Include"}
        ];

        $scope.wifiArr = {
            "wireless_carrier": [
                "Wifi"
            ]
        }

        $scope.getCampaignTarget = function () {
            //alert($scope.promotionObjective);
            console.log($scope.promotionObjective);
            $scope.campaignAudienceCampaignTargetLoader = true;
            if ($scope.promotionObjective == 'page') {

                var querystr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                //FOR PAGE
                facebookGetPost.fetchuserpromotablepages(querystr, headers).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.pageCampaignTargetArr = response.data.fbUserPromotablePagesResponse;
                        $window.localStorage.setItem("pageCampaignTargetArr", JSON.stringify($scope.pageCampaignTargetArr));
                        $scope.campaignAudienceCampaignTargetArr = $scope.pageCampaignTargetArr;
                        $scope.campaignAudienceCampaignTargetLoader = false;                        
                    } else {
                        if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                })

                $scope.FBName = 'Page';

                $window.localStorage.setItem("campaignAudienceTargetType", "page");
            } else if ($scope.promotionObjective == 'app') {

                var querystr = "?networkAdAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                //FOR APP
                facebookGetPost.getuserpromotedconnections(querystr, headers).then(function (response) {
                    if (response.data.appStatus == 0) {
                        $scope.appCampaignTargetArr = response.data.apps;
                        $scope.campaignAudienceCampaignTargetArr = $scope.appCampaignTargetArr;
                        $scope.campaignAudienceCampaignTargetLoader = false;
$rootScope.progressLoader = "none";                        
                    } else {
                        if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                })

                $scope.FBName = 'App';

                $window.localStorage.setItem("campaignAudienceTargetType", "app");
            } else if ($scope.promotionObjective == 'event') {

                var querystr = "?networkAdAccountId=" + $scope.networkAdAccountId + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                //FOR EVENT
                facebookGetPost.getuserpromotedconnections(querystr, headers).then(function (response) {
                    if (response.data.appStatus == 0) {
                        var promises = [];
                        //CHECK IF EVENT IS CORRECT OR NOT

                        angular.forEach(response.data.events, function (value, key) {

                            var query = value.id + "?access_token=" + $rootScope.networkAccessToken + "&fields=is_page_owned";
                            facebookGetPost.getfacebookgraph(query).then(function (response) {
                                if (response.data.appStatus == 0) {
                                    if (eventstatusresponse.is_page_owned) {
                                        var M_Obj = {id: eventstatusresponse.id, name: value.name};
                                        promises.push(M_Obj);
                                        $scope.eventCampaignTargetArr = promises;
                                        $scope.campaignAudienceCampaignTargetArr = $scope.eventCampaignTargetArr;
										$rootScope.progressLoader = "none";
                                    }
                                } else {
                                    if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                                        $window.localStorage.setItem("TokenExpired", true);
                                        $state.go('login');
                                    } else {
                                        $rootScope.progressLoader = "none";
                                        $scope.editAdsetErrorMsg = 'block';
                                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                            $scope.errorMsg = response.data.networkError.error_user_msg;
                                        } else {
                                            $scope.errorpopupHeading = 'Error';
                                            $scope.errorMsg = response.data.errorMessage;
                                        }
                                    }
                                }

                            })

                        });
                        $scope.campaignAudienceCampaignTargetLoader = false;                        
                    } else {
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }
                })

                $scope.FBName = 'Event';
                $window.localStorage.setItem("campaignAudienceTargetType", "event");
            }
            ;

        };

		$scope.locationflag = false;
    $scope.languageflag = false;
    $scope.intrestflag = false;
    $scope.unmatchedLocation = [];
    $scope.unmatchedLanguage = [];
    $scope.unmatchedInterest = [];
    $scope.uniqueInterest = [];
    $scope.matchedLocation=[];
    $scope.matchedLanguage=[];
    $scope.matchedInterest=[];
        $scope.init = function () {

            //$window.localStorage.setItem("campaignState",'edit');
            $rootScope.overLayAudience = false;
            $rootScope.freezeFlag = false;

            $scope.viewConversion = false;
            $rootScope.step = 2;
           /* if ($rootScope.campaignSteps[1] == false) {
                $window.localStorage.setItem("campaignState", "create");
            }  */

            var campaignState = $window.localStorage.getItem("campaignState");
            $scope.campstate = $window.localStorage.getItem("campaignState");
            angular.element('#step1').css('background-color', '#C2C2C2');

          if($scope.campaignAudienceLocationTarget){
				$window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
		  }
		  
           if ($window.localStorage.getItem("marketingObjective") == 'EVENT_RESPONSES') {
                $scope.promotionObjective = 'no';
                $scope.viewPromotion = false;
            }


            //default placement selection
            if(campaignState == "create")
            {
                $scope.campaignAudiencePlacementsWiFi = "1";
        $scope.campaignAudienceLocationTarget = 'everyone';
                $scope.PlacementsValues.push('desktoprightcolumn');
                $scope.PlacementsValues.push('desktopnewsfeed');
                $window.localStorage.setItem("campaignAudiencePlacementsValues", $scope.PlacementsValues);
                angular.element('#step3').css('background-color', '#95D2B1');
            } 

            if ($scope.viewPromotion) {
                $scope.audienceNum = 2;
            } else if ($scope.viewConversion) {
                $scope.audienceNum = 2;
            } else {
                $scope.audienceNum = 1;
            }
            //DEMOGRAPHIC LEAF DETAILS
            var querystr1 ="?type=adTargetingCategory&class=demographics" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
             //var querystr1 = "search" + "?type=adTargetingCategory&class=demographics" + "&access_token=" + $rootScope.networkAccessToken;
                                                facebookGetPost.demographictargetingsearch(querystr1).then(function (response) {
                //$scope.DemographicLeafDetails = response.data.data;
                                                                $scope.DemographicLeafDetails = response.data.fbDemographicTargetingSearchResponse.data;
            });



            //INTEREST LEAF DETAILS
                      var querystr2 ="?type=adTargetingCategory&class=interests" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            //var querystr2 = "search" + "?type=adTargetingCategory&class=interests" + "&access_token=" + $rootScope.networkAccessToken;
                                                facebookGetPost.demographictargetingsearch(querystr2).then(function (response) {
                $scope.InterestsLeafDetails = response.data.fbDemographicTargetingSearchResponse.data;
                                                                //$scope.InterestsLeafDetails = response.data.fbTargetingBrowseResponse;
            });




            //BEHAVIOURS LEAF DETAILS
                        var querystr3 ="?type=adTargetingCategory&class=behaviors" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
           // var querystr3 = "search" + "?type=adTargetingCategory&class=behaviors" + "&access_token=" + $rootScope.networkAccessToken;
                                                facebookGetPost.demographictargetingsearch(querystr3).then(function (response) {
                                                console.log(response.fbTargetingSearchBehaviorResponse);
                //$scope.BehaviorsLeafDetails =response.data.data;
                                                                $scope.BehaviorsLeafDetails = response.data.fbDemographicTargetingSearchResponse.data;
            });


            //MORE LEAF DETAILS
                       //var querystr4 ="?type=adTargetingCategory&class=user_adclusters" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                                                var querystr4 =  "?userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId') +"&adAccountId=" + $window.localStorage.getItem('networkAdAccountId') + "&limitType=user_adclusters";
            //var querystr4 = "act_" + $scope.networkAdAccountId + "/targetingbrowse?access_token=" + $rootScope.networkAccessToken;
            facebookGetPost.getfacebookgraph(querystr4).then(function (response) {
                /*var MArray = $filter('filter')(response.data.data, function (d) {
                    return d.type === "user_adclusters";
                }, true);
                $scope.MoreLeafDetails = MArray;*/
                                                                $scope.MoreLeafDetails = response.data.fbTargetingBrowseResponse;

            });


            //DEFAULT LANGUANGE DETAILS LOADING
                        var querystr5 ="?type=adLocale" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
            facebookGetPost.demographictargetingsearch(querystr5).then(function (response) {
                $scope.DefaultLanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
            });



            //console.log("campaignState : "+campaignState);        
            if (campaignState == "edit") {
                if ($window.localStorage.getItem("role") == "Account") {
                    $scope.adminUserRole = true;
                } else {
                    $scope.adminUserRole = false;
                }
                var campaignDetails = globalData.getLocal($window.localStorage.getItem("campaignId"))
                $scope.getEditAdsetDetails(campaignDetails);
            }
            

            $scope.setLine = function () {
                var everythingLoaded = setInterval(function () {
                    if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                        if ($scope.audienceNum == "2") {
                            $scope.fsValue = angular.element(document.getElementById('step1')).offset().top;
                            $scope.ssValue = angular.element(document.getElementById('step2')).offset().top;
                            $scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                            var offsetHeight3 = document.getElementById('step3container').offsetHeight;
                            var fStep = $(".vr");
                            fStep.css('height', (($scope.lsValue - $scope.fsValue)));
                        } else if ($scope.audienceNum == "1") {
                            $scope.fsValue = angular.element(document.getElementById('step2')).offset().top;
                            $scope.lsValue = angular.element(document.getElementById('step3')).offset().top;
                            var offsetHeight2 = document.getElementById('step3container').offsetHeight;
                            var fStep = $(".vr");
                            fStep.css('height', (($scope.lsValue - $scope.fsValue) - 20));
                        }
                    }
                }, 10);
            }
			if (campaignState == "replication" && $rootScope.sameNetwork == false)
            {
				
				   //$rootScope.progressLoader = "block";	   		  									 
				   console.log("************************** Final parsed data from Twitter - Step 2 ****************");
				   console.log($rootScope.fieldMapping[1].data[0]);		
				   console.log(JSON.stringify($rootScope.fieldMapping[1].data[0]));				   			  		   									   
				   console.log("**************************************************************************");									 

                //GET LOCATION DETAILS
                $scope.locationDetails = [];
                $scope.locationDetails = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'Location');
                if ($scope.locationDetails.length != 0) {
                    $scope.hasLocation = true;
                    var locationpromises = [];
                    angular.forEach($scope.locationDetails, function (locKey) {
                        $scope.ngLocLoader = true;
                        var headers = {
                            "userId": $window.localStorage.getItem("userId"),
                            "accessToken": $window.localStorage.getItem("accessToken")
                        }
                        var querystr = "search?type=adgeolocation&q=" + locKey + "&access_token=" + $rootScope.networkAccessToken;
                        locationpromises.push(facebookGetPost.getfacebookgraph(querystr, headers).then(function (response) {
                            $scope.LocationDetails = response.data.data;
                            $scope.addGeoLocation(locKey);
                        }));
                    });
                    $q.all(locationpromises).finally(function () {
                        $scope.mapLocation = true;
                        $scope.ngLocLoader = false;
                        $scope.errorMsgLoc = "";
                        $scope.setLine();
                        angular.forEach($scope.locationDetails, function (val) {
                            var sObj = $filter('filter')($scope.campaignAudienceLocationsArr, function (d) {
                                return d == val;
                            })[0];
                            if (typeof (sObj) == 'string') {
                                $scope.matchedLocation.push(val);
                            } else {
                                $scope.unmatchedLocation.push(val);
                            }
                        });
                        if ($scope.unmatchedLocation.length != $scope.locationDetails.length) {
                            $scope.unmatchedLocationString = $scope.unmatchedLocation.join(", ");
                            $scope.unmatchedLocationLength = $scope.unmatchedLocationString.length;
                            $scope.unmatchedLocationtruncate = $scope.unmatchedLocationString.substring(0,70);
                            if($scope.unmatchedLocationLength <= 70){
                                $scope.locationTruncate = false;
                                $scope.locationComplete = true;
                            } else {
                                $scope.locationTruncate = true;
                                $scope.locationComplete = false;
                            }
                        } else {
                            $scope.locationTruncate = false;
                            $scope.locationComplete = false;
                        }
                        $scope.getLanguages();
                    });
                } else {
                    $scope.getLanguages();
                }
                //GET BEHAVIOUR DETAILS
                /*$scope.behaviourArray = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'targeting_behaviors');
                if ($scope.behaviourArray.length > 0) {
                    $scope.hasDTselection = true;
                    var promiseBehaviour = [];
                    var querystr3 = "search" + "?type=adTargetingCategory&class=behaviors" + "&access_token=" + $rootScope.networkAccessToken;
                    promiseBehaviour.push(facebookGetPost.getfacebookgraph(querystr2).then(function (response) {
                        $scope.behaviourSearchResponse = response.data.data;
                    }));
                    $q.all(promiseBehaviour).finally(function () {
                        if ($scope.behaviourSearchResponse) {
                            $scope.behaviourTDArray = $scope.behaviourSearchResponse;
                            for (var i = 0; i < $scope.behaviourArray.length; i++) {
                                angular.forEach($scope.behaviourTDArray, function (key, value) {
                                    if (key.name == $scope.behaviourArray[i]) {
                                        $scope.DTtoggleSearchSelection(key.id, key.path, $scope.behaviourArray[i], "behaviors");

                                    }
                                })
                            }
                        }
                        angular.forEach($scope.DTselection, function(val, key){
                            $scope.duplicateDTselection.push(val);
                        });
                        if ($scope.DTselection.length == 0) {
                            $scope.interestflag = true;
                            $scope.userSuggestionLocBlock = false;
                            $scope.userSuggestionLocText = false;
                            $scope.userSuggestionAgeBlock = false;
                            $scope.userSuggestionAgeText = false;
                            $scope.userSuggestionLanBlock = false;
                            $scope.userSuggestionLanText = false;
                            $scope.userSuggestionDTBlock = true;
                            $scope.userSuggestionDTBlockBulb = true;
                            $scope.userSuggestionDTText = true;
                            $scope.openUserSuggestion('targeting');
                        } else {
                            $scope.userSuggestionDTBlock = false;
                        }

                    })
                }*/

                //GET MOBILE DEVICES
                $scope.devicesValue = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'targeting_platform');

                $scope.campaignAudiencePlacementsWiFi = "1";
                $scope.campaignAudienceLocationTarget = 'everyone';
                $scope.PlacementsValues.push('desktoprightcolumn');
                $scope.PlacementsValues.push('desktopnewsfeed');
                $window.localStorage.setItem("campaignAudiencePlacementsValues", $scope.PlacementsValues);
                angular.element('#step3').css('background-color', '#95D2B1');
            
			
			} else
                        {
                            $scope.getEditAdsetDetails();
                        }
			
			
			
			
			
			
			
			
			
            $scope.setLine();
            $scope.getCampaignTarget();
        }

        //GET LANGUAGE DETAILS
        $scope.getLanguages = function () {
            $scope.languageDetails = [];
            $scope.languageDetails = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'Language');
            if ($scope.languageDetails.length != 0) {
                $scope.allLanguageDetails = [];
                $scope.ngLanLoader = true;
                $scope.campaignAudienceLanguageKeyArr = [];
                $scope.campaignAudienceLanguageArr = [];
                var lanpromises = [];
                var querystr = "search?access_token=" + $rootScope.networkAccessToken + "&type=adlocale";
                lanpromises.push(facebookGetPost.getfacebookgraph(querystr).then(function (response) {
                    $scope.allLanguageDetails = response.data.data;
                    angular.forEach($scope.languageDetails, function (val) {
                        var sObj = $filter('filter')($scope.allLanguageDetails, function (d) {
                            return d.name == val;
                        })[0];
                        if (typeof (sObj) == 'object') {
                            $scope.campaignAudienceLanguageKeyArr.push(sObj.key);
                            $scope.campaignAudienceLanguageArr.push(sObj.name);
                            $scope.matchedLanguage.push(val);
                        } else {
                            $scope.unmatchedLanguage.push(val);
                        }
                    });
                    $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
                    $scope.LanguageKeyValues = {
                        "locales": $scope.campaignAudienceLanguageKeyArr
                    }
                }))
                $q.all(lanpromises).finally(function () {
                    if ($scope.unmatchedLanguage.length != $scope.languageDetails.length) {
                        $scope.unmatchedLanguageString = $scope.unmatchedLanguage.join(", ");
                        $scope.unmatchedLanguageLength = $scope.unmatchedLanguageString.length;
                        $scope.unmatchedLanguagetruncate = $scope.unmatchedLanguageString.substring(0,70);
                        if ($scope.unmatchedLanguageLength <= 70) {
                            $scope.languageTruncate = false;
                            $scope.languageComplete = true;
                        } else {
                            $scope.languageTruncate = true;
                            $scope.languageComplete = false;
                        }
                    } else {
                        $scope.languageTruncate = false;
                        $scope.languageComplete = false;
                    }
                    $scope.ngLanLoader = false;
                    $scope.setLine();
                    $scope.getAgeAndGender();
                })
            } else {
                $scope.getAgeAndGender();
            }
        }

        //GET AGE AND GENDER DETAILS
        $scope.getAgeAndGender = function () {
            $scope.ageminValue = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'AgeMin');
            if ($scope.ageminValue != undefined) {
                $scope.campaignAudienceAgeFrom = $scope.ageminValue;
                $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
            }
            $scope.agemaxValue = parser.getParsedObject($rootScope.fieldMapping, 'AgeMax');
            if ($scope.agemaxValue != undefined) {
                $scope.campaignAudienceAgeTo = $scope.agemaxValue;
                $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
            }

            $scope.campaignAudienceGenderVal = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'Gender');
            if ($scope.campaignAudienceGenderVal) {
                $scope.campaignAudienceGender = $scope.campaignAudienceGenderVal;
                $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
            }
            $scope.getInterestTargeting();
        }

        //GET INTEREST DETAILS
        $scope.getInterestTargeting = function () {
            $scope.interestArray = parser.getParsedObject($rootScope.fieldMapping[1].data[0], 'targeting_interest');
            if ($scope.interestArray.length > 0) {
                var interestPromise = [];
                var querystr2 = "search" + "?type=adTargetingCategory&class=interests" + "&access_token=" + $rootScope.networkAccessToken;
                interestPromise.push(facebookGetPost.getfacebookgraph(querystr2).then(function (response) {
                    $scope.interestSearchResponse = response.data.data;
                }));
                $q.all(interestPromise).finally(function () {
                    if ($scope.interestSearchResponse) {
                        $scope.interestTDArray = $scope.interestSearchResponse;
                        for (var i = 0; i < $scope.interestArray.length; i++) {
                            $scope.DTInterestNameArrayFlag = false;
                            angular.forEach($scope.interestTDArray, function (key, value) {
                                if (key.name == $scope.interestArray[i]) {
                                    $scope.DTtoggleSearchSelection(key.id, key.path, $scope.interestArray[i], "interests");
                                    $scope.matchedInterest.push(key.name);
                                    $scope.DTInterestNameArrayFlag = true;
                                }
                            })
                            if ($scope.removeDuplicates($scope.matchedInterest, $scope.interestArray[i]) != "" && $scope.DTInterestNameArrayFlag == true) {
                                $scope.uniqueInterest.push($scope.removeDuplicates($scope.matchedInterest, $scope.interestArray[i]));
                            } else {
                                $scope.unmatchedInterest.push($scope.interestArray[i]);
                            }
                        }
                        if ($scope.unmatchedInterest.length != $scope.interestArray.length) {
                            $scope.unmatchedTargetingString = $scope.unmatchedInterest.join(", ");
                            $scope.unmatchedTargetingLength = $scope.unmatchedTargetingString.length;
                            $scope.unmatchedTargetingtruncate = $scope.unmatchedTargetingString.substring(0,70);
                            if($scope.unmatchedTargetingLength <= 70){
                                $scope.targetingTruncate = false;
                                $scope.targetingComplete = true;
                            } else {
                                $scope.targetingTruncate = true;
                                $scope.targetingComplete = false;
                            }
                        } else {
                            $scope.targetingTruncate = false;
                            $scope.targetingComplete = false;
                        }

                    }
                    $scope.enableBulb();
                })
            } else {
                $scope.enableBulb();
            }
        }

        $scope.enableBulb = function () {
            if ($scope.unmatchedLocation.length > 0 || ($scope.campaignAudienceLocationsArr.length < 1 && $scope.locationDetails != undefined && $scope.locationDetails != null && $scope.locationDetails.length >= 1)) {
                $scope.locationflag = true;
            }

            if ($scope.unmatchedLanguage.length > 0 || ($scope.campaignAudienceLanguageArr.length < 1 && $scope.languageDetails != undefined && $scope.languageDetails != null && $scope.languageDetails.length >= 1)) {
                $scope.languageflag = true;
            }

            if ($scope.unmatchedInterest.length > 0 || ($scope.DTselection.length < 1 && $scope.interestArray != undefined && $scope.interestArray != null && $scope.interestArray.length >= 1)) {
                $scope.interestflag = true;
            }

            if ($scope.locationflag == true) {
                $scope.userSuggestionLocBlock = true;
                $scope.userSuggestionLocText = true;
                $scope.userSuggestionLocBlockBulb = true;
                $scope.userSuggestionAgeBlock = false;
                $scope.userSuggestionAgeText = false;
                $scope.userSuggestionLanBlock = false;
                $scope.userSuggestionLanText = false;
                $scope.userSuggestionDTBlock = false;
                $scope.userSuggestionDTText = false;
                $scope.openUserSuggestion('location');
            } else if ($scope.languageflag == true) {
                $scope.userSuggestionLanBlock = true;
                $scope.userSuggestionLanText = true;
                $scope.userSuggestionLanBlockBulb = true;
                $scope.userSuggestionLocBlock = false;
                $scope.userSuggestionLocText = false;
                $scope.userSuggestionAgeBlock = false;
                $scope.userSuggestionAgeText = false;
                $scope.userSuggestionDTBlock = false;
                $scope.userSuggestionDTText = false;
                $scope.openUserSuggestion('language');
            } else if ($scope.interestflag == true) {
                $scope.userSuggestionLocBlock = false;
                $scope.userSuggestionLocText = false;
                $scope.userSuggestionAgeBlock = false;
                $scope.userSuggestionAgeText = false;
                $scope.userSuggestionLanBlock = false;
                $scope.userSuggestionLanText = false;
                $scope.userSuggestionDTBlock = true;
                $scope.userSuggestionDTBlockBulb = true;
                $scope.userSuggestionDTText = true;
                $scope.openUserSuggestion('targeting');
            }
        }

        $scope.removeDuplicates = function (originalArray, prop) {
            var newArray = [];
            var lookupObject = {};
            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }
            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        }

        $scope.$on('details-loaded', function () {
            $scope.setLine();
        });

        $scope.getAdCreativeForEdit = function () {
            //GET TARGET TYPE [PAGE,APP,EVENT]
            var adCreativeId = $window.localStorage.getItem("adCreativeId");
            if (trim(adCreativeId) != '' && trim(adCreativeId) != undefined && trim(adCreativeId) != null) {
                var queryStr = "?adCreativeId=" + adCreativeId + "&networkMapId=" + $window.localStorage.getItem("userNetworkMapId");
                var headers = {
                    'userId': $window.localStorage.getItem("userId"),
                    'accessToken': $window.localStorage.getItem("accessToken")
                }


                facebookGetPost.getadcreative(queryStr, headers).then(function (response) {

                    if (response.data.appStatus == 0) {
                        $scope.adCreativeDetails = response.data.fbAdCreativeResponse;

                        if ($scope.adCreativeDetails.object_story_spec) {

                            if ($scope.adCreativeDetails.object_story_spec.link_data) {
                                $scope.campaignAudienceCampaignTargetLoader = false;
                                if ($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.application != '' && $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.application != undefined && $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.application != null) {
                                    $scope.campaignAudienceCampaignTargetType = 'app';
                                    $window.localStorage.setItem("campaignAudienceTargetType", "app");
                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.application;
                                    $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
                                }
                            } else if ($scope.adCreativeDetails.object_story_spec.video_data) {
                                $scope.campaignAudienceCampaignTargetLoader = false;
                                if ($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.application != '' && $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.application != undefined && $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.application != null) {
                                    console.log('true video');
                                    $scope.campaignAudienceCampaignTargetType = 'app';
                                    $window.localStorage.setItem("campaignAudienceTargetType", "app");
                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.application;
                                    $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
                                }
                            } else if ($scope.adCreativeDetails.object_story_spec.page_id) {

                                $scope.campaignAudienceCampaignTargetLoader = false;
                                //console.log('if i am here');
                                //console.log($scope.adCreativeDetails);
                                if ($scope.adCreativeDetails.object_story_spec.page_id != '' && $scope.adCreativeDetails.object_story_spec.page_id != undefined && $scope.adCreativeDetails.object_story_spec.page_id != null) {
                                    $scope.campaignAudienceCampaignTargetType = 'page';
                                    $window.localStorage.setItem("campaignAudienceTargetType", "page");
                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.page_id;
                                    $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
                                }
                                $scope.campaignAudienceCampaignTargetLoader = false;

                            } else if ($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.event_id) {
                                $scope.campaignAudienceCampaignTargetLoader = false;
                                if ($scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.event_id != '' && $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.event_id != undefined && $scope.adCreativeDetails.object_story_spec.link_data.call_to_action.value.event_id != null) {
                                    $scope.campaignAudienceCampaignTargetType = 'event';
                                    $window.localStorage.setItem("campaignAudienceTargetType", "event");
                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.link_data.event_id;
                                    $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
                                }
                            } else if ($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.event_id) {
                                $scope.campaignAudienceCampaignTargetLoader = false;
                                if ($scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.event_id != '' && $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.event_id != undefined && $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.event_id != null) {
                                    $scope.campaignAudienceCampaignTargetType = 'event';
                                    $window.localStorage.setItem("campaignAudienceTargetType", "event");
                                    $scope.campaignAudienceCampaignTarget = $scope.adCreativeDetails.object_story_spec.video_data.call_to_action.value.event_id;
                                    $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
                                }
                            }
                        } else {
                            $scope.campaignAudienceCampaignTargetLoader = false;
                        }

                    } else {
                        //console.log("failed");
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                        // Flash.create('danger', response.errorMessage, 'large-text');
                    }
                });
            }
        }

        $scope.getPageOffers = function () {

            if ($scope.campaignAudienceCampaignTarget != '' && $scope.campaignAudienceCampaignTarget != undefined && $scope.campaignAudienceCampaignTarget != null) {
                $scope.campaignAudienceCampaignOfferLoader = true;
                //console.log($scope.campaignAudienceCampaignTargetArr);
                var pageObj = $filter('filter')($scope.campaignAudienceCampaignTargetArr, function (d) {
                    return d.id == $scope.campaignAudienceCampaignTarget;
                })[0];

                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&pageId=" + $window.localStorage.getItem('campaignAudienceTarget') + "&pageAccessToken=" + pageObj.access_token;

                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                facebookGetPost.getoffersinpage(queryStr, headers).then(function (response) {

                    if (response.data.appStatus == 0) {

                        angular.forEach(response.offersInPage, function (value, key) {
                            var JsonObj = response.offersInPage[key];
                            var array = [];
                            for (var i in JsonObj) {
                                if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                    var OfferDetails = array[+i] = JsonObj[i];
                                    var newOfferArr = {
                                        "id": OfferDetails.id,
                                        "name": OfferDetails.title,
                                        "redemptionlink": OfferDetails.redemption_link
                                    }
                                    $scope.campaignAudienceCampaignOfferArr.push(newOfferArr);
                                }
                            }
                        });

                    } else {

                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }

                    }
                    $rootScope.progressLoader = "none";
                    $scope.campaignAudienceCampaignOfferLoader = false;
                })

            }
        }

        $scope.getConversionPixels = function () {
            $scope.campaignAudienceCampaignConversionPixelLoader = true;

            var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&networkAdAccountId=" + $window.localStorage.getItem('networkAdAccountId');

            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            facebookGetPost.getadaccountadspixels(queryStr, headers).then(function (response) {

                if (response.appStatus == '0') {
                    angular.forEach(response.adAccountAdsPixels, function (value, key) {
                        var JsonObj = response.adAccountAdsPixels[key];
                        var array = [];
                        for (var i in JsonObj) {
                            if (JsonObj.hasOwnProperty(i) && !isNaN(+i)) {
                                var ConversionPixelDetails = array[+i] = JsonObj[i];
                                var newArr = {
                                    "id": ConversionPixelDetails.id,
                                    "name": ConversionPixelDetails.name
                                }
                                $scope.campaignAudienceCampaignConversionPixelArr.push(newArr);
                            }
                        }
                    });
                } else {
                    if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.networkError != '' && response.networkError != undefined) {
                            $scope.errorpopupHeading = response.networkError.error_user_title;
                            $scope.errorMsg = response.networkError.error_user_msg;

                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.networkError.message;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.errorMessage;
                        }
                    }
                }
                $rootScope.progressLoader = "none";
                $scope.campaignAudienceCampaignConversionPixelLoader = false;
            })
        }

        $scope.setCheckedVal = function (val, condition) {
            //$scope.setPlacements(val);
            //console.log('location before : '+val);
            //console.log($scope.PlacementsValues);
            var idxx = $scope.PlacementsValues.indexOf(val);
            if (idxx > -1 && condition == 'insert') {
                //console.log("splice idxx here ::: "+idxx);
                $scope.PlacementsValues.splice(idxx, 1);
            } else {
                $scope.PlacementsValues.push(val);
            }
            
            if($scope.PlacementsValues.length > 0){
               angular.element('#step3').css('background-color', '#95D2B1'); 
          }
          else{
                angular.element('#step3').css('background-color', '#C2C2C2'); 	   
          }

            //REMOVE DUPLICATION
            var count = 0;
            var unique = function (origArr) {
                var newArr = [],
                        origLen = origArr.length,
                        found, x, y;
                for (x = 0; x < origLen; x++) {
                    found = undefined;
                    for (y = 0; y < newArr.length; y++) {
                        if (origArr[x] === newArr[y]) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        newArr.push(origArr[x]);
                        if (newArr[x] == "mobilenewsfeed") {
                            $scope.campaignAudienceMobileDevice = "All mobile devices"
                            count = 1;
                        }
                    }
                }
                return newArr;
            }

            $scope.PlacementsValues = unique($scope.PlacementsValues);

            if (count == 1) {
                $scope.mobileView = true;
            } else {
                $scope.mobileView = false;
                $scope.campaignAudienceMobileDevice = '';
            }
            //console.log('location after : '+val);
            //console.log($scope.PlacementsValues);

            if (condition == 'insert') {
                $rootScope.freezeFlag = true;
                $rootScope.overLayAudience = true;
            }
            ;
            //alert($scope.PlacementsValues);
			angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $window.localStorage.setItem("campaignAudiencePlacementsValues", $scope.PlacementsValues);
        };


        $scope.emptycheckforMandatoryfields = function ()
        {
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            console.log($scope.campaignAudienceCampaignTarget);
            if ($scope.campaignAudienceCampaignTarget == "" || $scope.campaignAudienceCampaignTarget == undefined || $scope.campaignAudienceCampaignTarget == null)
            {
                angular.element('#mandatory').addClass("mandatory");
            } else
            {
                angular.element('#mandatory').removeClass("mandatory");
            }
            console.log($scope.campaignAudienceLocationsArr.length)
            if ($scope.campaignAudienceLocationsArr.length == 0)
            {

                angular.element('#campaignAudienceLocations').addClass("required");
            } else
            {
                angular.element('#campaignAudienceLocations').removeClass("required");
            }
        };

        $scope.prePopulateValues = function (campaignData) {
            //$rootScope.progressLoader = "block";
            $scope.campaignAudienceLocationsArr = [];
            var campaignId = $window.localStorage.getItem('campaignId');
            
            //GET LOCATIONS                    
                                    if (campaignData[1].adsetDetails.targeting.geo_locations.countries != '' && campaignData[1].adsetDetails.targeting.geo_locations.countries != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(campaignData[1].adsetDetails.targeting.geo_locations.countries, function (val, key) {

                                //var querystr = 'search?type=adgeolocationmeta&countries=["' + val + '"]&access_token=' + $rootScope.networkAccessToken;
                                //var querystr1 ='?type=adgeolocation&q=["' + val + '"] + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                                var querystr = '?type=adgeolocationmeta&countries=["' + val + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    $scope.mapLocation = true;
                                    $scope.countryArray.push(val);
                                    $scope.campaignAudienceLocationsArr.push($scope.FBCountryDetails.countries[val].name);
                                    $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.setLine();
                                })

                            });
                            $scope.setLine();
                        }

                        if (campaignData[1].adsetDetails.targeting.geo_locations.regions != '' && campaignData[1].adsetDetails.targeting.geo_locations.regions != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(campaignData[1].adsetDetails.targeting.geo_locations.regions, function (val, key) {

                                //var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + $rootScope.networkAccessToken;
                                var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    var r_obj = {"key": val.key};
                                    $scope.regionArray.push(r_obj);
                                    $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
                                    $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.emptycheckforMandatoryfields();
                                })
                            });
                        }
                        if (campaignData[1].adsetDetails.targeting.geo_locations.cities != '' && campaignData[1].adsetDetails.targeting.geo_locations.cities != undefined) {
                            $scope.ngLocLoader = true;
                            angular.forEach(campaignData[1].adsetDetails.targeting.geo_locations.cities, function (val, key) {

                                //var querystr = 'search?type=adgeolocationmeta&countries=["' + val.country + '"]&access_token=' + $rootScope.networkAccessToken;
                                var querystr = '?type=adgeolocationmeta&countries=["' + val.country + '"]&userNetworkMapId=' +  $window.localStorage.getItem('userNetworkMapId');
                                facebookGetPost.targetingsearchadlocale(querystr).then(function (response) {

                                    $scope.FBCountryDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                                    var c_obj = {"key": val.key};
                                    //alert(c_obj);
                                    $scope.cityArray.push(c_obj);
                                    $scope.mapLocation = true;
                                    $scope.campaignAudienceLocationsArr.push(val.name + ' / ' + val.region + ' / ' + $scope.FBCountryDetails.countries[val.country].name);
                                    $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
                                    $scope.ngLocLoader = false;
                                    $scope.emptycheckforMandatoryfields();
                                })
                            });
                        }
                        $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);



            //GET CONNECTION
            if (campaignData[1].adsetDetails.targeting.wireless_carrier != '') {
                $scope.campaignAudiencePlacementsWiFi = 1;
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", $scope.campaignAudiencePlacementsWiFi);
            } else {
                $scope.campaignAudiencePlacementsWiFi = 0;
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", $scope.campaignAudiencePlacementsWiFi);
            }

            //GET AGE
            $scope.campaignAudienceAgeFrom = campaignData[1].adsetDetails.targeting.age_min;
            $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
            $scope.campaignAudienceAgeTo = campaignData[1].adsetDetails.targeting.age_max;
            $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);


            //GET GENDER
            $scope.campaignAudienceGender1 = campaignData[1].adsetDetails.targeting.genders;
            if ($scope.campaignAudienceGender1 == '1') {
                $scope.campaignAudienceGender = 'men';
            } else if ($scope.campaignAudienceGender1 == '2') {
                $scope.campaignAudienceGender = 'women';
            } else {
                $scope.campaignAudienceGender = 'all';
            }
            $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);

            //GET LANGUANGE
            $scope.campaignAudienceLanguageKey = campaignData[1].adsetDetails.targeting.locales;
            $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);

            //GET LANGUANGE
            $scope.campaignAudienceLanguageKey = campaignData[1].adsetDetails.targeting.locales;
            $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);

            //LANGUAGE FB SERVICE DETAILS
                                   $scope.ngLanLoader = true;
                        $scope.campaignAudienceLanguageKeyArr = [];
                        $scope.campaignAudienceLanguageArr = [];
                        //var querystr = "?access_token=" + $rootScope.networkAccessToken + "&type=adlocale";
                        var querystr ="?type=adLocale" + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                        facebookGetPost.demographictargetingsearch(querystr).then(function (response) {

                            $scope.FBLanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
                            angular.forEach(campaignData[1].adsetDetails.targeting.locales, function (val) {
                                var sObj = $filter('filter')($scope.FBLanguageDetails, function (d) {
                                    return d.key == val;
                                })[0];
                                $scope.campaignAudienceLanguageKeyArr.push(sObj.key);
                                $scope.campaignAudienceLanguageArr.push(sObj.name);
                            });
                            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
                            $scope.LanguageKeyValues = {
                                "locales": $scope.campaignAudienceLanguageKeyArr
                            }
                            $scope.ngLanLoader = false;

                        })

		   
            $scope.demographicsArray = [];
            $scope.interestsArray = [];
            $scope.behaviorsArray = [];

            //GET DETAIL TARGETING                    
            if (campaignData[1].adsetDetails.targeting.user_adclusters != '' && campaignData[1].adsetDetails.targeting.user_adclusters != undefined) {
                angular.forEach(campaignData[1].adsetDetails.targeting.user_adclusters, function (val, key) {
                    var s_obj = {"id": val.id};
                    $scope.demographicsArray.push(s_obj);
                    $scope.DTselection.push(val);
                    $scope.DTselectionkey.push(val.id);
                });
            }
            if (campaignData[1].adsetDetails.targeting.interests != '' && campaignData[1].adsetDetails.targeting.interests != undefined) {
                angular.forEach(campaignData[1].adsetDetails.targeting.interests, function (val, key) {
                    $scope.DTselection.push(val);
                    var s_obj = {"id": val.id};
                    $scope.interestsArray.push(s_obj);
                    $scope.DTselectionkey.push(val.id);
                });
            }
            if (campaignData[1].adsetDetails.targeting.behaviors != '' && campaignData[1].adsetDetails.targeting.behaviors != undefined) {
                angular.forEach(campaignData[1].adsetDetails.targeting.behaviors, function (val, key) {
                    $scope.DTselection.push(val);
                    var s_obj = {"id": val.id};
                    $scope.behaviorsArray.push(s_obj);
                    $scope.DTselectionkey.push(val.id);
                });
            }

            //GET LOCATION TYPE [EVERY-ONE etc..]
            if (campaignData[1].adsetDetails.targeting.geo_locations.location_types == '') {
                $scope.campaignAudienceLocationTarget = 'everyone';
            } else {
                $scope.campaignAudienceLocationTarget = campaignData[1].adsetDetails.targeting.geo_locations.location_types;
            }
            $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);


            //GET PLACEMENTS
            angular.forEach(campaignData[1].adsetDetails.targeting.publisher_platforms, function (val, key) {
                if (val == 'facebook') {
                    angular.forEach(campaignData[1].adsetDetails.targeting.facebook_positions, function (value1, key1) {
                        angular.forEach(campaignData[1].adsetDetails.targeting.device_platforms, function (value2, key2) {
                            if (value2 == 'desktop') {
                                if (value1 == "feed") {
                                    $scope.setCheckedVal('desktopnewsfeed', 'prefill');
                                } else {
                                    $scope.setCheckedVal('desktoprightcolumn', 'prefill');
                                }
                            } else if (value2 == 'mobile') {
                                $scope.setCheckedVal('mobilenewsfeed', 'prefill');
                            }
                        });
                    });
                }
                if (val == 'audience_network') {
                    $scope.setCheckedVal('audiencenetwork', 'prefill');
                }
            });

            if (campaignData[1].adsetDetails.targeting.instagram_positions == 'stream') {
                $scope.setCheckedVal('instagram', 'prefill');
            }
            $window.localStorage.setItem("campaignAudiencePlacementsValues", $scope.PlacementsValues);



            //GET MOBILE DEVICE DATAS
            if ($window.localStorage.getItem("marketingObjective") != 'CANVAS_APP_INSTALLS' || $window.localStorage.getItem("marketingObjective") != 'CANVAS_APP_ENGAGEMENT') {
                $scope.campaignAudienceMobileDevice = 'All mobile devices';
                $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);
            }
            if ($scope.MobileDeviceArr != undefined && (campaignData[1].adsetDetails.targeting.user_os != '' && campaignData[1].adsetDetails.targeting.user_os != undefined) || (campaignData[1].adsetDetails.targeting.user_device != '' && campaignData[1].adsetDetails.targeting.user_device != undefined)) {
                //console.log(campaignData[1].adsetDetails.targeting.user_device);
                if (campaignData[1].adsetDetails.targeting.user_os == 'Android' || campaignData[1].adsetDetails.targeting.user_os == 'iOS') {
                    var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                        return d.id == campaignData[1].adsetDetails.targeting.user_os;
                    })[0];
                    $scope.campaignAudienceMobileDevice = sobject.name;
                } else if (campaignData[1].adsetDetails.targeting.user_device == 'Feature_Phone') {
                    var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                        return d.id == campaignData[1].adsetDetails.targeting.user_device;
                    })[0];
                    $scope.campaignAudienceMobileDevice = sobject.name;
                } else {
                    $scope.campaignAudienceMobileDevice = 'All mobile devices';
                }
                $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);
            }

            // }
            //}
            // });

            if ($scope.campaignAudienceGender1 == '' || $scope.campaignAudienceGender1 == undefined || $scope.campaignAudienceGender1 == null) {
                if ($scope.campaignAudienceGender == '1') {
                    $scope.campaignAudienceGender = 'men';
                } else if ($scope.campaignAudienceGender == '2') {
                    $scope.campaignAudienceGender = 'women';
                } else {
                    $scope.campaignAudienceGender = 'all';
                }
            }

            $scope.campaignPlacementsArray1 = $window.localStorage.getItem("campaignAudiencePlacementsValues");
            $scope.splitPlacements = $scope.campaignPlacementsArray1.split(",");
            $scope.array1 = [];

            for (var i = 0; i < $scope.splitPlacements.length; i++) {
                $scope.array1.push($scope.splitPlacements[i]);

            }
            console.log(JSON.stringify($scope.array1, null, 2));

            for (var i = 0; i < $scope.array1.length; i++) {
                if ($scope.array1[i] == 'desktopnewsfeed') {
                    $scope.PlacementsValues.push('desktopnewsfeed')
                }
                if ($scope.array1[i] == 'desktoprightcolumn') {
                    $scope.PlacementsValues.push('desktoprightcolumn')
                }

                if ($scope.array1[i] == 'mobilenewsfeed') {
                    $scope.PlacementsValues.push('mobilenewsfeed')
                    $scope.mobileView = true;
                }


            }

            $scope.campaignAudienceCampaignTargetType = $window.localStorage.getItem("campaignAudienceTargetType");
            console.log("promotionObjective :::: " + $scope.promotionObjective);
            if ($scope.promotionObjective != 'no' && $scope.promotionObjective != '' && $scope.promotionObjective != 'false' && $scope.promotionObjective != undefined && $scope.promotionObjective != null) {
                $scope.getCampaignTarget();
            } else {
                $scope.campaignAudienceCampaignTargetType = '';
            }


            $scope.campaignAudienceLocationType = $window.localStorage.getItem("campaignAudienceLocationType");
            $scope.campaignAudienceAgeFrom = $window.localStorage.getItem("campaignAudienceAgeFrom");
            $scope.campaignAudienceAgeTo = $window.localStorage.getItem("campaignAudienceAgeTo");
            $scope.campaignAudienceGender = $window.localStorage.getItem("campaignAudienceGender");
            $scope.campaignAudienceLanguageKey = $window.localStorage.getItem("campaignAudienceLanguageKey");
            $scope.campaignAudienceLanguage = $window.localStorage.getItem("campaignAudienceLanguage");
            $scope.campaignAudienceDTJSON = $window.localStorage.getItem("campaignAudienceDTJSON");
            $scope.campaignAudienceDTselection = JSON.parse($window.localStorage.getItem("campaignAudienceDTselection"));
            $scope.campaignAudiencePlacementsWiFi = $window.localStorage.getItem("campaignAudiencePlacementsWiFi");
            $scope.campaignAudienceCampaignOffer = $window.localStorage.getItem("campaignAudienceCampaignOffer");
            $scope.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget");
            $scope.campaignAudienceCampaignConversionPixel = $window.localStorage.getItem("campaignAudienceCampaignConversionPixel");
            if ($scope.campaignAudiencePlacementsWiFi == 1) {
                $scope.campaignAudiencePlacementsWiFi = 1;
            } else {
                $scope.campaignAudiencePlacementsWiFi = 0;
            }
            $scope.campaignAudienceDTJSON = JSON.parse($scope.campaignAudienceDTJSON);
            if (response.adsets.length == '0') {
                angular.forEach($scope.campaignAudienceDTselection, function (value, key) {
                    $scope.DTtoggleSearchSelection(value.id, value.path, value.rname, value.rootpath);
                });
                if ($window.localStorage.getItem("campaignAudiencePlacementsValues")) {
                    if ($window.localStorage.getItem("campaignAudiencePlacementsValues").length > 0) {
                        $scope.PlacementsValues = $window.localStorage.getItem("campaignAudiencePlacementsValues").split(',');
                        $window.localStorage.setItem("campaignAudiencePlacementsValues", $scope.PlacementsValues);
                    }
                }

                if ($window.localStorage.getItem("campaignAudienceLocationsArr")) {
                    if ($window.localStorage.getItem("campaignAudienceLocationsArr").length > 0) {
                        $scope.mapLocation = true;
                        $scope.campaignAudienceLocationsArr = $window.localStorage.getItem("campaignAudienceLocationsArr").split(',');
                        $scope.regionArray = JSON.parse($window.localStorage.getItem("regionArray"));
                        $scope.countryArray = JSON.parse($window.localStorage.getItem("countryArray"));
                        $scope.cityArray = JSON.parse($window.localStorage.getItem("cityArray"));
                    }
                }
                if ($window.localStorage.getItem("campaignAudienceLanguageArr")) {
                    if ($window.localStorage.getItem("campaignAudienceLanguageArr").length > 0) {
                        $scope.campaignAudienceLanguageArr = $window.localStorage.getItem("campaignAudienceLanguageArr").split(',');
                        $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
                    }
                }
                if ($window.localStorage.getItem("campaignAudienceLocationTarget")) {
                    $scope.campaignAudienceLocationTarget = $window.localStorage.getItem("campaignAudienceLocationTarget")
                    $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
                }

            }
            if ($window.localStorage.getItem("campaignAudienceMobileDevice")) {
                $scope.campaignAudienceMobileDevice = $window.localStorage.getItem("campaignAudienceMobileDevice");
            }
            angular.element('#step1').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            angular.element('#step3').css('background-color', '#95D2B1');
            $rootScope.progressLoader = "none";

        };

        $scope.getEditAdsetDetails = function () {
            angular.element('#step3').css('background-color', '#95D2B1');
            angular.element('#step2').css('background-color', '#95D2B1');
            //GET TARGET TYPE [PAGE,APP,EVENT]
            //console.log("promotionObjective ::: "+$scope.promotionObjective);
            if ($scope.promotionObjective != 'no') {
                try {
                    $scope.getAdCreativeForEdit();
                } catch (err) {
                    console.log('error on promotive objective' + err);
                }
            }
            ;
            var headers = {
                "userId": $window.localStorage.getItem("userId"),
                "accessToken": $window.localStorage.getItem("accessToken")
            }
            var querystr = "?adCampaignId=" + $window.localStorage.getItem("campaignId") + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');
            facebookGetPost.readadset(querystr, headers).then(function (response) {

                if (response.data.appStatus == 0) {
                    $scope.mapLocation=true;
                    if (response.data.adsets.length > 1) {
                        $scope.editAdsetErrorMsg = 'block';
                        $scope.errorpopupHeading = 'Adset Error';
                        $scope.errorMsg = 'Please try again as there has been an error in AdSet Creation. If the error persists, please contact CAdConciergeSupport@cognizant.com';
                    } else {
                         var campaignData = JSON.parse($window.localStorage.getItem("facebookReplicatorData"));
                        $rootScope.progressLoader = "none";
                        $scope.prePopulateValues(campaignData);
                    }
                } else {
                    if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    } else {
                        $rootScope.progressLoader = "none";
                        $scope.editAdsetErrorMsg = 'block';
                        if (response.data.networkError != '' && response.data.networkError != undefined) {
                            $scope.errorpopupHeading = response.data.networkError.error_user_title;
                            $scope.errorMsg = response.data.networkError.error_user_msg;
                        } else {
                            $scope.errorpopupHeading = 'Error';
                            $scope.errorMsg = response.data.errorMessage;
                        }
                    }
                }
            });

        };

        $scope.init();

        $scope.countryArray = [];
        $scope.regionArray = [];
        $scope.cityArray = [];

        $scope.DTselectionkey = [];
        $scope.DTselection = [];


        //var arrayVal=[];
        $scope.device_platforms = [];
        $scope.facebook_positions = [];
        $scope.publisher_platforms = [];
        $scope.instagram_positions = [];

        $scope.setPlacements = function (val) {
            //console.log(val);

            if (val == 'mobilenewsfeed') {

                $scope.device_platforms.push("mobile");
                $scope.facebook_positions.push("feed");
                $scope.publisher_platforms.push("facebook");

            } else if (val == 'desktopnewsfeed') {

                $scope.device_platforms.push("desktop");
                $scope.facebook_positions.push("feed");
                $scope.publisher_platforms.push("facebook");

            } else if (val == 'desktoprightcolumn') {

                $scope.device_platforms.push("desktop");
                $scope.publisher_platforms.push("facebook");
                $scope.facebook_positions.push("right_hand_column");

            } else if (val == 'instagram') {

                $scope.publisher_platforms.push("instagram");
                $scope.instagram_positions.push("stream");
                $scope.device_platforms.push("mobile", "desktop");

            } else if (val == 'audiencenetwork') {

                $scope.publisher_platforms.push("facebook", "audience_network");
                $scope.facebook_positions.push("feed");
                $scope.device_platforms.push("mobile", "desktop");

            }
            //REMOVE DUPLICATION
            var unique = function (origArr) {
                var newArr = [],
                        origLen = origArr.length,
                        found, x, y;
                for (x = 0; x < origLen; x++) {
                    found = undefined;
                    for (y = 0; y < newArr.length; y++) {
                        if (origArr[x] === newArr[y]) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        newArr.push(origArr[x]);
                    }
                }
                return newArr;
            }

            $scope.device_platforms = unique($scope.device_platforms);
            $scope.facebook_positions = unique($scope.facebook_positions);
            $scope.publisher_platforms = unique($scope.publisher_platforms);
            $scope.instagram_positions = unique($scope.instagram_positions);


            $scope.PlacementsKeyValues = {
                "device_platforms": $scope.device_platforms,
                "facebook_positions": $scope.facebook_positions,
                "publisher_platforms": $scope.publisher_platforms,
                "instagram_positions": $scope.instagram_positions
            }

            //console.log('PlacementsKeyValues : $$$$$');
            //console.log($scope.PlacementsKeyValues);
        };

        $scope.$watch('campaignAudienceCampaignTarget', function (newVal, oldVal) {
            //alert(newVal);
            if (newVal != 'undefined' && newVal != '' && newVal != 'null' && newVal != undefined && newVal != null) {
                // angular.element('#step2').css('background-color', '#95D2B1');
                //$rootScope.freezeFlag = true;
                //$rootScope.overLayAudience = true;
            } else {
                // angular.element('#step2').css('background-color', '#C2C2C2');
            }
        }, true);

        $scope.$watch('campaignAudienceDetailedTargeting', function (newVal, oldVal) {
            $window.localStorage.setItem("campaignaudienceDetailedTargeting", newVal);
//        if(newVal != 'undefined' && newVal != '' && newVal != null){
//            angular.element('#step3').css('background-color', '#95D2B1');
//        }else{
//            angular.element('#step3').css('background-color', '#C2C2C2');
//        }
        }, true);


        $scope.$watch('campaignAudienceAgeTo', function (newVal, oldVal) {

            if (newVal != 'undefined' && newVal != '' && newVal != null) {
                if (newVal < $scope.campaignAudienceAgeFrom) {
                    $scope.campaignAudienceAgeTo = $scope.campaignAudienceAgeFrom;
                }
                ;
            }
        }, true);


        //FETCH LOCATION DETAILS
        $scope.getLocationDetails = function () {

            if ($scope.campaignAudienceLocations != "" && $scope.campaignAudienceLocations != undefined)
            {
                $scope.ngLocLoader = true;
                //GET LOCATION SEARCH RESULT BY LETTER
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                //var querystr = "search?type=adgeolocation&q=" + $scope.campaignAudienceLocations + "&access_token=" + $rootScope.networkAccessToken;
                var querystr = "?type=adgeolocation&q=" + $scope.campaignAudienceLocations + "&userNetworkMapId=" +  $window.localStorage.getItem('userNetworkMapId');
                facebookGetPost.targetingsearchadlocale(querystr, headers).then(function (response) {
                    if (JSON.stringify(response.data.fbTargetingSearchAdLocaleResponse.data) == "[]") {
                        $scope.errLoc = 0;
                    } else {
                        $scope.errLoc = 1;
                        $scope.LocationDetails = response.data.fbTargetingSearchAdLocaleResponse.data;
                        $scope.mapLocation = true;
                    }
                    $scope.ngLocLoader = false;
                    $scope.setLine();

                })

            } else {
                $scope.errLoc = 1;
            }

        };

        $scope.$watch('campaignAudienceLocations', function () {
            if ($scope.LocationDetails != 'undefined' && $scope.LocationDetails != '' && $scope.LocationDetails != null) {
                $scope.addGeoLocation($scope.campaignAudienceLocations);
            }
            ;
        });

        $scope.campaignAudienceLocationsArr = [];
        /*$scope.countryArray = [];
         $scope.regionArray = [];
         $scope.cityArray = [];*/
        $scope.addGeoLocation = function (val) {
            //$scope.campaignAudienceLocations = '';
            if (val != '' && val.length > 2) {
                var SVal = val.split("/")[0];
                var Rdata = $scope.LocationDetails.find(function (ele) {
                    return trim(ele.name) === trim(SVal);
                });
                var Edata = $scope.campaignAudienceLocationsArr.find(function (ele) {
                    if (trim(ele.split("/")[0]) == trim(SVal)) {
                        return true;
                    } else {
                        return false;
                    }
                });
                if (Rdata && !Edata) {
                    $scope.campaignAudienceLocationsArr.push(val);
                    if (Rdata.type == 'country') {
                        $scope.countryArray.push(Rdata.country_code);
                    } else if (Rdata.type == 'region') {
                        var r_obj = {"key": Rdata.key};
                        $scope.regionArray.push(r_obj);
                    } else if (Rdata.type == 'city') {
                        var c_obj = {"key": Rdata.key};
                        $scope.cityArray.push(c_obj);
                    }
                    $scope.campaignAudienceLocations = '';
					$window.localStorage.setItem("regionArray",JSON.stringify($scope.regionArray));
				$window.localStorage.setItem("countryArray",JSON.stringify($scope.countryArray));
				$window.localStorage.setItem("cityArray",JSON.stringify($scope.cityArray));	
                } else {
                    $scope.errorMsgLoc = "Invalid location";
                }

            }
            if ($scope.campaignAudienceLocationsArr.length == 0)
            {
                angular.element('#step2').css('background-color', '#c2c2c2');
                angular.element('#campaignAudienceLocations').addClass("required");

            } else
            {
                angular.element('#step2').css('background-color', '#95D2B1');
                angular.element('#campaignAudienceLocations').removeClass("required");
            }
			/*for (var i = 0; i < $scope.secondlocationArray.length; i++) {
                for (var j = 0; j < $scope.campaignAudienceLocationsArr.length; j++) {
                    if ($scope.secondlocationArray[i] != $scope.campaignAudienceLocationsArr[j]) {
                        angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                    }
                }
            }*/
            
            $scope.setLine();
        };
        function isString(value) {
            return typeof value == 'string';
        }
        ;

        function trim(value) {
            return isString(value) ? value.replace(/^\s*/, '').replace(/\s*$/, '') : value;
        }
        ;

        $scope.removeGeoLocation = function (item) {
            if ($scope.locationflag == true && $scope.matchedLocation.indexOf(item) > -1) {
                $scope.matchedLocation.splice($scope.matchedLocation.indexOf(item), 1);
                $scope.userSuggestionLocBlock = false;
                $scope.locationflag = false;
            }
            var SVal = item.split("/")[0];

            var headers = {
                "userId": $scope.userId,
                "accessToken": $scope.accessToken
            }
            var queryStr = "search?type=adgeolocation&q=" + SVal + "&access_token=" + $rootScope.networkAccessToken;
            facebookGetPost.getfacebookgraph(queryStr, headers).then(function (response) {

                $scope.SingleLocationDetails = response.data.data;
                var Rdata = $scope.SingleLocationDetails.find(function (ele) {
                    return trim(ele.name) === trim(SVal);
                });
                $scope.campaignAudienceLocationsArr.splice($scope.campaignAudienceLocationsArr.indexOf(item), 1);
                if (Rdata) {
                    if (Rdata.type == 'country') {
                        $scope.countryArray.splice($scope.countryArray.indexOf(Rdata.country_code), 1);
                    } else if (Rdata.type == 'region') {
                        $scope.regionArray.splice($scope.regionArray.indexOf(Rdata.key), 1);
                    } else if (Rdata.type == 'city') {
                        $scope.cityArray.splice($scope.cityArray.indexOf(Rdata.key), 1);
                    }
					$window.localStorage.setItem("regionArray",JSON.stringify($scope.regionArray));
				$window.localStorage.setItem("countryArray",JSON.stringify($scope.countryArray));
				$window.localStorage.setItem("cityArray",JSON.stringify($scope.cityArray));	
                }
                if ($scope.campaignAudienceLocationsArr.length == 0)
                {
                    angular.element('#step2').css('background-color', '#c2c2c2');
                    angular.element('#campaignAudienceLocations').addClass("required");
                    $scope.setLine();

                } else
                {
                    angular.element('#step2').css('background-color', '#95D2B1');
                    angular.element('#campaignAudienceLocations').removeClass("required");
                    $scope.setLine();
                }

            })
			for (var i = 0; i < $scope.secondlocationArray.length; i++) {
                for (var j = 0; j < $scope.campaignAudienceLocationsArr.length; j++) {
                    if ($scope.secondlocationArray[i] != $scope.campaignAudienceLocationsArr[j]) {
                        angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                    }
                }
            }
            
            $scope.setLine();
        };

        $scope.searchBy = function (item) {
            if ($scope.campaignAudienceDetailedTargetingSearch == undefined) {
                return true;
            } else {
                if (item.name.toLowerCase().indexOf($scope.campaignAudienceDetailedTargetingSearch.toLowerCase()) != -1) {
                    return true;
                }
            }
            return false;
        };
        
        $scope.searchDetailTargeting = function (searchElement) {
            console.log(searchElement);
            var arrTargeting = angular.copy($scope.searchDemo);

            if (searchElement.toLowerCase() != undefined && searchElement.toLowerCase() != "" && searchElement.toLowerCase() != 'undefined')
            {
                if (searchElement.toLowerCase().length != 0) {
                    var array = angular.copy(arrTargeting);
                    $scope.DemographicChildLeafDetails = [];
                    for (i = 0; i < array.length; i++)
                    {
                        if (array[i].name.toLowerCase().includes(searchElement.toLowerCase()))
                            $scope.DemographicChildLeafDetails.push(array[i]);
                    }
                } else {
                    $scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
                }
            } else {
                $scope.DemographicChildLeafDetails = angular.copy(arrTargeting);
            }
        }


        $scope.campaignDetailedTargetingArr = [];
        $scope.sendDetailTargetingKey = function (val) {
            $( "#collapseDetail" ).addClass( "dropdown-search" );
            $('.drop-search').show();
            $('.drop-list').show();
            $scope.detailtargetinglisting = true;
            $scope.detailtargetingsearch = true;
            $scope.SearchPlaceholder = val;
            $scope.hdDetailedTargeting = val;
            $scope.showSearchKeyword = 1;
            //$scope.campaignAudienceDetailedTargetingSearch = '';
            $scope.DemographicChildLeafDetails = '';

            if ($scope.hdDetailedTargeting == 'demographics') {
                $scope.DemographicChildLeafDetails = $scope.DemographicLeafDetails;
            } else if ($scope.hdDetailedTargeting == 'interests') {
                $scope.DemographicChildLeafDetails = $scope.InterestsLeafDetails;
            } else if ($scope.hdDetailedTargeting == 'behaviors') {
                $scope.DemographicChildLeafDetails = $scope.BehaviorsLeafDetails;
            } else if ($scope.hdDetailedTargeting == 'more') {
                //console.log($scope.MoreLeafDetails.length);    
                angular.forEach($scope.DemographicLeafDetails, function (value1, key1) {
                    angular.forEach($scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = $scope.MoreLeafDetails.indexOf(value1.id);
                            $scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                //console.log("demographics : "+$scope.MoreLeafDetails.length);  



                angular.forEach($scope.InterestsLeafDetails, function (value1, key1) {
                    angular.forEach($scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = $scope.MoreLeafDetails.indexOf(value1.id);
                            $scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                //console.log("interest : "+$scope.MoreLeafDetails.length);  


                angular.forEach($scope.BehaviorsLeafDetails, function (value1, key1) {
                    angular.forEach($scope.MoreLeafDetails, function (value2, key2) {
                        if (value1.id === value2.id) {
                            var idxx = $scope.MoreLeafDetails.indexOf(value1.id);
                            $scope.MoreLeafDetails.splice(idxx, 1);
                        }
                    });
                });
                //console.log("behaviours : "+$scope.MoreLeafDetails.length);

                $scope.DemographicChildLeafDetails = $scope.MoreLeafDetails;
            }
            ;

        $scope.searchDemo = $scope.DemographicChildLeafDetails;
        };


        //FETCH LANGUAGE DETAILS
        $scope.getLanguageDetails = function () {
                        if ($scope.campaignAudienceLanguage != '' && $scope.campaignAudienceLanguage != undefined) {
                $scope.ngLanLoader = true;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                var querystr = "?type=adlocale&q=" + $scope.campaignAudienceLanguage + "&userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId');

                facebookGetPost.demographictargetingsearch(querystr, headers).then(function (response) {

                    if (response.data.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                        $window.localStorage.setItem("TokenExpired", true);
                        $state.go('login');
                    }
                    ;
                    if (response.data.appStatus > 0 && $scope.campaignAudienceLanguage != '') {
                        $scope.errLan = 0;
                    } else if (response.data.appStatus == 0 && $scope.campaignAudienceLanguage != '') {
                        $scope.errLan = 1;
                        $scope.LanguageDetails = response.data.fbDemographicTargetingSearchResponse.data;
                    }
                    $scope.ngLanLoader = false;
                    $rootScope.freezeFlag = true;
                    $rootScope.overLayAudience = true;
                })

            } else {
                $scope.LanguageDetails = undefined;
                $scope.errLan = 1;
            }

        }

        $scope.$watch('campaignAudienceLanguage', function () {
            if ($scope.LanguageDetails != 'undefined' && $scope.LanguageDetails != '' && $scope.LanguageDetails != null) {
                $scope.addLanguage($scope.campaignAudienceLanguage);
            }
        });

        $scope.campaignAudienceLanguageKeyArr = [];
        $scope.addLanguage = function (val) {

            //console.log("addLanguage : "+val.length);
            if (val != '' && val.length > 2) {
                var Rdata = $scope.LanguageDetails.find(function (ele) {
                    return trim(ele.name) === trim(val);
                });
                var Edata = $scope.campaignAudienceLanguageArr.find(function (ele) {
                    return trim(ele) === trim(val);
                });
                if (Rdata && !Edata) {
                    $scope.campaignAudienceLanguageArr.push(val);
                    $scope.campaignAudienceLanguageKeyArr.push(Rdata.key);
                    $scope.campaignAudienceLanguage = '';
                } else {
                    console.log('language already exist!');
                }
            }
            ;
            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
            $scope.LanguageKeyValues = {
                "locales": $scope.campaignAudienceLanguageKeyArr
            }
            for (var i = 0; i < $scope.languageDetailsSecondArray.length; i++) {
                for (var j = 0; j < $scope.campaignAudienceLanguageArr.length; j++) {
                    if ($scope.languageDetailsSecondArray[i] != $scope.campaignAudienceLanguageArr[j]) {
                        angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
                    }
                }
            }
            $scope.setLine();
        };

        $scope.removeLanguage = function (item) {
			var Rdata = $scope.DefaultLanguageDetails.find(function (ele) {
                return trim(ele.name) === trim(item);
            });
            $scope.campaignAudienceLanguageKeyArr.splice($scope.campaignAudienceLanguageKeyArr.indexOf(Rdata.key), 1);
            $scope.campaignAudienceLanguageArr.splice($scope.campaignAudienceLanguageArr.indexOf(item), 1);

            console.log('campaignAudienceLanguageKeyArr ::: ');
            console.log($scope.campaignAudienceLanguageKeyArr);
            $window.localStorage.setItem("campaignAudienceLanguageArr", $scope.campaignAudienceLanguageArr);
            $scope.LanguageKeyValues = {
                "locales": $scope.campaignAudienceLanguageKeyArr
            };
            console.log($scope.LanguageKeyValues);

            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
            $scope.setLine();
        };


        //$scope.DTselection = [];
        //$scope.DTselectionkey = [];
        $scope.campaignAudienceDTJSON = [];
        $scope.demographicsArray = [];
        $scope.interestsArray = [];
        $scope.behaviorsArray = [];
        $scope.moreArray = [];

        $scope.campaignAudienceMoreDTJSON = [];
        $scope.MobileKey = [];
        var camR = {};


        // Detail targeting Search Toggle selection    
        $scope.DTtoggleSearchSelection = function (DTSearchId, DTSearchPath, DTSearchName, hiddenname) {

            var dt_val = '';

            angular.forEach(DTSearchPath, function (val) {
                dt_val += val + ' / ';
            });
            var lnk_dtl = '';
            if (hiddenname == 'more') {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val + DTSearchName, 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            } else {
                lnk_dtl = {'id': DTSearchId, 'name': dt_val.substr(0, dt_val.length - 2), 'rname': DTSearchName, 'path': DTSearchPath, 'rootpath': hiddenname}
                DTSearchPath = lnk_dtl;
            }

            var idx = $scope.DTselection.indexOf(DTSearchPath);
            var idxx = $scope.DTselectionkey.indexOf(DTSearchId);

            if (idxx > -1) {
                $scope.DTselection.splice(idxx, 1);
                $scope.DTselectionkey.splice(idxx, 1);
                //console.log('hiddenname : '+hiddenname);
                if (hiddenname == 'demographics') {
                    $scope.demographicsArray.splice(idxx, 1);
                } else if (hiddenname == 'interests') {
                    $scope.interestsArray.splice(idxx, 1);
                } else if (hiddenname == 'behaviors') {
                    $scope.behaviorsArray.splice(idxx, 1);
                } else if (hiddenname == 'more') {
                    $scope.demographicsArray.splice(idxx, 1);
                }
                ;
                $scope.campaignAudienceDTJSON = {
                    "user_adclusters": $scope.demographicsArray,
                    "interests": $scope.interestsArray,
                    "behaviors": $scope.behaviorsArray
                };

                //angular.element('#step2').css('background-color', '#C2C2C@');
                // angular.element('#step3').css('background-color', '#95D2B1');

            } else {
                $scope.DTselection.push(DTSearchPath);
                $scope.DTselectionkey.push(DTSearchId);


                if (hiddenname == 'demographics') {
                    var DKey = {"id": DTSearchId};
                    $scope.demographicsArray.push(DKey);
                } else if (hiddenname == 'interests') {
                    var IKey = {"id": DTSearchId};
                    $scope.interestsArray.push(IKey);
                } else if (hiddenname == 'behaviors') {
                    var BKey = {"id": DTSearchId};
                    $scope.behaviorsArray.push(BKey);
                } else if (hiddenname == 'more') {
                    //var sobject = $filter('filter')($scope.MoreLeafDetails,function(d){return d.id === DTSearchId;},true)[0];
                    var MKey = {"id": DTSearchId};
                    $scope.demographicsArray.push(MKey);

                    /*var moreParameter = {};
                     $scope.MobileKey.push(MKey);
                     moreParameter = sobject.type;
                     
                     $scope.campaignAudienceMoreDTJSON = {
                     [moreParameter] : $scope.MobileKey
                     };*/
                }
                ;

                $scope.campaignAudienceDTJSON = {
                    "user_adclusters": $scope.demographicsArray,
                    "interests": $scope.interestsArray,
                    "behaviors": $scope.behaviorsArray
                };

                // angular.element('#step2').css('background-color', '#95D2B1');
                // angular.element('#step3').css('background-color', '#C2C2C2');


            }
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            //console.log($scope.DTselection);
            $scope.setLine();
        };

        $scope.removeDT = function (name, id) {
            if ($scope.interestflag == true) {
                angular.forEach($scope.uniqueInterest, function(uniqueVal) {
                    if (name.includes(uniqueVal)) {
                        $scope.uniqueInterest.splice($scope.uniqueInterest.indexOf(uniqueVal), 1);
                        $scope.userSuggestionDTBlock = false;
                        $scope.interestflag = false;
                    }
                });
            }
            var idx = $scope.DTselectionkey.indexOf(id);
            $scope.DTselectionkey.splice(idx, 1);

            var idxx = $scope.DTselection.indexOf(name);
            $scope.DTselection.splice(idx, 1);

            angular.forEach($scope.demographicsArray, function (val, key) {
                if (val.id == id) {
                    $scope.demographicsArray.splice(key, 1);
                }
            });
            angular.forEach($scope.interestsArray, function (val, key) {
                if (val.id == id) {
                    $scope.interestsArray.splice(key, 1);
                }
            });
            angular.forEach($scope.behaviorsArray, function (val, key) {
                if (val.id == id) {
                    $scope.behaviorsArray.splice(key, 1);
                }
            });

            /*if($scope.hdDetailedTargeting=='demographics'){
             $scope.demographicsArray.splice(idx, 1);
             }else if($scope.hdDetailedTargeting=='interests'){
             $scope.interestsArray.splice(idx, 1);
             }else if($scope.hdDetailedTargeting=='behaviors'){
             $scope.behaviorsArray.splice(idx, 1);
             }else if($scope.hdDetailedTargeting=='more'){
             $scope.demographicsArray.splice(idx, 1);
             };*/

            $scope.campaignAudienceDTJSON = {
                "user_adclusters": $scope.demographicsArray,
                "interests": $scope.interestsArray,
                "behaviors": $scope.behaviorsArray
            };
            //console.log($scope.campaignAudienceDTJSON);
            //console.log($scope.DTselection);  

            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
            $scope.setLine();
        };

        function capitalizeString(inputString) {
            return inputString.substring(0, 1).toUpperCase() + inputString.substring(1);
        }
        $scope.gotoParentCampaign = function () {
            $state.go('app.parentcampaign');
            $rootScope.freezeFlag = false;
        }
        $scope.moveNextStep = function () {
            //rootScope.campaignSteps[1] = true;
			$rootScope.campaignSteps = [true,true,false,false,false]; 
            $state.go('app.fbEVENTSReplicatorPlan');
            //console.log($rootScope.step);
            //$rootScope.step = 2;
        }

        $scope.sendcampaignAudienceConnection = function (campaignAudienceConnection) {
            $scope.campaignAudienceConnection = campaignAudienceConnection;
            $window.localStorage.setItem("campaignAudienceConnection", $scope.campaignAudienceConnection);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.sendcampaignAudienceCampaignOffer = function (campaignAudienceCampaignOffer) {
            $scope.campaignAudienceCampaignOffer = campaignAudienceCampaignOffer;
            $window.localStorage.setItem("campaignAudienceCampaignOffer", $scope.campaignAudienceCampaignOffer);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.sendcampaignAudienceCampaignConversionPixel = function (campaignAudienceCampaignConversionPixel) {
            $scope.campaignAudienceCampaignConversionPixel = campaignAudienceCampaignConversionPixel;
            $window.localStorage.setItem("campaignAudienceCampaignConversionPixel", $scope.campaignAudienceCampaignConversionPixel);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.sendcampaignAudienceCampaignTarget = function (campaignAudienceCampaignTarget) {
            $scope.campaignAudienceCampaignTarget = campaignAudienceCampaignTarget;
            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $rootScope.freezeFlag = true;
            $rootScope.overLayAudience = true;
            if ($window.localStorage.getItem("marketingObjective") == 'OFFER_CLAIMS') {
                $scope.campaignAudienceCampaignOfferArr = [];
                $scope.campaignAudienceCampaignOffer = '';
                $scope.getPageOffers();
            }

            if ($scope.campaignAudienceCampaignTarget == "")
            {
                angular.element('#step1').css('background-color', '#c2c2c2');
                angular.element('#mandatory').addClass("mandatory");
            } else
            {
                angular.element('#step1').css('background-color', '#95D2B1');
                angular.element('#mandatory').removeClass("mandatory");
            }
			angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});

        }

//    $scope.CampaignTargetemptycheck = function(campaignAudienceCampaignTarget)
//    {
//        if(campaignAudienceCampaignTarget == "" || campaignAudienceCampaignTarget == undefined || campaignAudienceCampaignTarget == null)
//        {
//            angular.element('#step1').css('background-color', '#c2c2c2');
//            angular.element('#mandatory').addClass("mandatory");
//        }
//        else
//        {
//            angular.element('#step1').css('background-color', '#95D2B1');
//            angular.element('#mandatory').removeClass("mandatory");
//        }
//    };
//    $scope.locationemptycheck = function(val)
//    {
//        $timeout(function(){
//            console.log("locationemptycheck");
//            console.log(val)
//            if($scope.campaignAudienceLocationsArr.length==0)
//            {
//                angular.element('#step2').css('background-color', '#c2c2c2');
//                angular.element('#campaignAudienceLocations').addClass("required");
//            }
//            else
//            {
//                angular.element('#step2').css('background-color', '#95D2B1');
//                angular.element('#campaignAudienceLocations').removeClass("required");
//            } 
//        },1000);
//      
//    };
        $scope.sendGender = function (campaignAudienceGender) {
            $scope.campaignAudienceGender = campaignAudienceGender;
            $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGender);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }
        $scope.sendcampaignAudienceLocationTarget = function (campaignAudienceLocationTarget) {
            $scope.campaignAudienceLocationTarget = campaignAudienceLocationTarget;
            $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
           angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
//        if($scope.campaignAudienceLocationTarget==)
        }
        $scope.sendcampaignAudienceLocationType = function (campaignAudienceLocationType) {
            $scope.campaignAudienceLocationType = campaignAudienceLocationType;
            $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }
        $scope.sendcampaignAudienceAgeFrom = function (campaignAudienceAgeFrom) {
            if(campaignAudienceAgeFrom < $scope.campaignAudienceAgeTo){
                $scope.campaignAudienceAgeFrom = campaignAudienceAgeFrom;
            }else{
                $scope.campaignAudienceAgeFrom = $scope.campaignAudienceAgeTo;
            }
            $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }

        $scope.sendcampaignAudienceAgeTo = function (campaignAudienceAgeTo) {
            $scope.campaignAudienceAgeTo = campaignAudienceAgeTo;
            $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }
        $scope.sendcampaignAudienceMobileDevice = function (campaignAudienceMobileDevice) {
            $scope.campaignAudienceMobileDevice = campaignAudienceMobileDevice;
            $window.localStorage.setItem("campaignAudienceMobileDevice", $scope.campaignAudienceMobileDevice);
            angular.element('#step3').css('background-color', '#95D2B1');
            angular.element('.stepFreeze').css({'opacity': '0.9', 'pointer-events': 'none'});
        }


        $scope.campaignAudienceLocationsJSON = [];
        $scope.campaignAudienceGenderValue = [];
        $scope.campaignAudienceLocationTargetValue = [];

        function hasSubjectID(object, key) {
            return object ? hasOwnProperty.call(object, key) : false;
        }

        vm.createCampaignAudience = function () {

            if ($window.localStorage.getItem("campaignAudienceGender") == 'all') {
                $scope.campaignAudienceGenderValue.push();
            } else if ($window.localStorage.getItem("campaignAudienceGender") == 'men') {
                $scope.campaignAudienceGenderValue.push('1');
            } else if ($window.localStorage.getItem("campaignAudienceGender") == 'women') {
                $scope.campaignAudienceGenderValue.push('2');
            }
            $window.localStorage.setItem("campaignAudienceGender", $scope.campaignAudienceGenderValue);
            if ($scope.campaignAudienceLocationTarget != '') {
                if ($scope.campaignAudienceLocationTarget == 'everyone') {
                    $scope.campaignAudienceLocationTargetValue.push();
                } else {
                    $scope.campaignAudienceLocationTargetValue.push($scope.campaignAudienceLocationTarget);
                }
            }

            var mobileParameter = '';
            $scope.MobileTypes = [];
            if ($scope.campaignAudienceMobileDevice != '' && $scope.campaignAudienceMobileDevice != null && $scope.campaignAudienceMobileDevice != undefined) {
                var sobject = $filter('filter')($scope.MobileDeviceArr.data, function (d) {
                    return d.name === $scope.campaignAudienceMobileDevice;
                })[0];
                var isSubjectId = hasSubjectID(sobject, 'id');
                if (isSubjectId == true) {
                    if (sobject.id == 'Android' || sobject.id == 'iOS') {
                        mobileParameter = 'user_os';
                        $scope.MobileTypes.push(sobject.id);
                    } else if (sobject.id == 'Feature_Phone') {
                        mobileParameter = 'user_device';
                        $scope.MobileTypes.push(sobject.id);
                    } else {
                        mobileParameter = 'user_device';
                        $scope.MobileTypes.push();
                    }
                }
            }

            if (mobileParameter != '' && mobileParameter != null && mobileParameter != undefined) {

                $scope.campaignAudienceLocationsJSON = {
                    "age_min": $scope.campaignAudienceAgeFrom,
                    "age_max": $scope.campaignAudienceAgeTo,
                    "geo_locations": {
                        "countries": $scope.countryArray,
                        "regions": $scope.regionArray,
                        "cities": $scope.cityArray,
                        "location_types": $scope.campaignAudienceLocationTargetValue
                    },
                    "genders": $scope.campaignAudienceGenderValue
                    
                };
                 $scope.campaignAudienceLocationsJSON[mobileParameter] = $scope.MobileTypes;
                   
            } else {
                $scope.campaignAudienceLocationsJSON = {
                    "age_min": $scope.campaignAudienceAgeFrom,
                    "age_max": $scope.campaignAudienceAgeTo,
                    "geo_locations": {
                        "countries": $scope.countryArray,
                        "regions": $scope.regionArray,
                        "cities": $scope.cityArray,
                        "location_types": $scope.campaignAudienceLocationTargetValue
                    },
                    "genders": $scope.campaignAudienceGenderValue
                };
            }




            //LOOPING FOR DETAIL TARGETING
            var camR = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camR[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in $scope.campaignAudienceDTJSON) {
                camR[key] = $scope.campaignAudienceDTJSON[key];
            }
            $scope.campaignAudienceLocationsJSON = camR;


            $scope.device_platforms = [];
            $scope.facebook_positions = [];
            $scope.publisher_platforms = [];
            $scope.instagram_positions = [];


            angular.forEach($scope.PlacementsValues, function (val, key) {
                $scope.setPlacements(val);
            });


            //LOOPING FOR PLACEMENT
            var camP = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camP[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in $scope.PlacementsKeyValues) {
                camP[key] = $scope.PlacementsKeyValues[key];
            }
            $scope.campaignAudienceLocationsJSON = camP;
            //LOOPING FOR LANGUAGE
            var camL = {};
            for (var key in $scope.campaignAudienceLocationsJSON) {
                camL[key] = $scope.campaignAudienceLocationsJSON[key];
            }
            for (var key in $scope.LanguageKeyValues) {
                camL[key] = $scope.LanguageKeyValues[key];
            }
            $scope.campaignAudienceLocationsJSON = camL;

            if ($scope.campaignAudiencePlacementsWiFi) {
                var wifiL = {};
                for (var key in $scope.campaignAudienceLocationsJSON) {
                    wifiL[key] = $scope.campaignAudienceLocationsJSON[key];
                }
                for (var key in $scope.wifiArr) {
                    wifiL[key] = $scope.wifiArr[key];
                }
                $scope.campaignAudienceLocationsJSON = wifiL;
            }

            //console.log($scope.PlacementsValues); 
            console.log($scope.campaignAudienceLocationsJSON);
            $scope.getAndSaveCampaignData();

        };

        $scope.getAndSaveCampaignData = function () {
            var campaignDetails = $window.localStorage.getItem("campaignId");
            //console.log("campaignDetails1 : "+campaignDetails);
            if (campaignDetails == undefined) {
                var campaignId = $rootScope.campaignId;
                var headers = {
                    "userId": $window.localStorage.getItem("userId"),
                    "accessToken": $window.localStorage.getItem("accessToken")
                }
                var queryStr = "?userNetworkMapId=" + $window.localStorage.getItem('userNetworkMapId') + "&adCampaignId=" + campaignId;
                facebookGetPost.readadcampaign(queryStr, headers).then(function (response) {
                    if (response.data.appStatus == '0') {
                        campaignDetails = response.data.adcampaigns;
                        console.log("campaignDetails2 : "+campaignDetails);
                        $scope.appendAudienceData();
                    } else {
                        //console.log('campaign fetch failed');
                        if (response.appStatus > 0 && (response.errorMessage == 'Access token is invalid or expired' || response.errorMessage == 'Access Token is invalid or expired.')) {
                            $window.localStorage.setItem("TokenExpired", true);
                            $state.go('login');
                        } else {
                            $rootScope.progressLoader = "none";
                            $scope.editAdsetErrorMsg = 'block';
                            if (response.data.networkError != '' && response.data.networkError != undefined) {
                                $scope.errorpopupHeading = response.data.networkError.error_user_title;
                                $scope.errorMsg = response.data.networkError.error_user_msg;
                            } else {
                                $scope.errorpopupHeading = 'Error';
                                $scope.errorMsg = response.data.errorMessage;
                            }
                        }
                    }

                })

            } else {
                $scope.appendAudienceData();
            }

        }

        $scope.setWiFi = function (val) {
            if (val) {
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", val);
            } else {
                $window.localStorage.setItem("campaignAudiencePlacementsWiFi", val);
            }
        }

        $scope.appendAudienceData = function () {


            var campaignDetails = $window.localStorage.getItem("campaignId");
            if ($scope.campaignAudienceCampaignTarget != 'undefined' && $scope.campaignAudienceCampaignTarget != '' && $scope.campaignAudienceCampaignTarget != null && $scope.campaignAudienceCampaignTarget != 'null') {
                if ($scope.campaignAudienceCampaignTargetArr != 'undefined' && $scope.campaignAudienceCampaignTargetArr != '' && $scope.campaignAudienceCampaignTargetArr != null && $scope.campaignAudienceCampaignTargetArr != 'null') {
                    var sobj = $filter('filter')($scope.campaignAudienceCampaignTargetArr, function (d) {
                        return d.id === $scope.campaignAudienceCampaignTarget;
                    }, true)[0];
                    $scope.hdcampaignAudienceCampaignTargetName = sobj.name;
                }
            }
            $window.localStorage.setItem("campaignAudienceLanguageKey", $scope.campaignAudienceLanguageKey);
            $window.localStorage.setItem("campaignAudienceLanguage", $scope.campaignAudienceLanguage);
            /*if($scope.campaignAudienceLocationTarget=='everyone'){
             $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.everyoneArr);
             }else{
             $window.localStorage.setItem("campaignAudienceLocationTarget", $scope.campaignAudienceLocationTarget);
             }*/

            $window.localStorage.setItem("campaignAudienceTarget", $scope.campaignAudienceCampaignTarget);
            $window.localStorage.setItem("hdcampaignAudienceCampaignTargetName", $scope.hdcampaignAudienceCampaignTargetName);
            //$window.localStorage.setItem("campaignAudienceTargetType", $scope.campaignAudienceCampaignTargetType);
            $window.localStorage.setItem("campaignAudienceLocationsArr", $scope.campaignAudienceLocationsArr);
            $window.localStorage.setItem("campaignAudienceLocationsJSON", JSON.stringify($scope.campaignAudienceLocationsJSON));
            $window.localStorage.setItem("campaignAudienceLocationType", $scope.campaignAudienceLocationType);
            $window.localStorage.setItem("campaignAudienceAgeFrom", $scope.campaignAudienceAgeFrom);
            $window.localStorage.setItem("campaignAudienceAgeTo", $scope.campaignAudienceAgeTo);

            $window.localStorage.setItem("campaignAudienceDTJSON", JSON.stringify($scope.campaignAudienceDTJSON));
            $window.localStorage.setItem("campaignAudienceDTselection", JSON.stringify($scope.DTselection));

            var obj = {
                "campaignAudienceLanguageKey": $scope.campaignAudienceLanguageKey,
                "campaignAudienceLocationTarget": $window.localStorage.getItem("campaignAudienceLocationTarget"),
                "campaignAudienceTarget": $scope.campaignAudienceCampaignTarget,
                "campaignAudienceTargetType": $window.localStorage.getItem("campaignAudienceTargetType"),
                "campaignAudienceLocationsArr": $scope.campaignAudienceLocationsArr,
                "campaignAudienceLocationsJSON": JSON.stringify($scope.campaignAudienceLocationsJSON),
                "campaignAudienceLocationType": $scope.campaignAudienceLocationType,
                "campaignAudienceAgeFrom": $scope.campaignAudienceAgeFrom,
                "campaignAudienceAgeTo": $scope.campaignAudienceAgeTo,
                "campaignAudienceGender": $scope.campaignAudienceGender,
                "campaignAudienceLanguage": $scope.campaignAudienceLanguage,
                "campaignAudiencePlacementsValues": $window.localStorage.getItem("campaignAudiencePlacementsValues"),
                "campaignAudienceDTJSON": JSON.stringify($scope.campaignAudienceDTJSON),
                "campaignAudienceMobileDevice": $window.localStorage.getItem("campaignAudienceMobileDevice")
           
 }
            if(campaignDetails){
            var campaignResult = {};
            
            
            for (var key in campaignDetails.data) {
                campaignResult[key] = campaignDetails.data[key]
            }
            for (var key in obj) {
                campaignResult[key] = obj[key];
            }
      }
            globalData.setLocal("campaign", $window.localStorage.getItem("campaignId"), campaignResult);
            //console.log(globalData.getLocal("campaign"));
            //$window.localStorage.setItem("campaignState", 'edit');
            $rootScope.freezeFlag = false;
            $scope.moveNextStep();

        }

        $scope.ageFromArr = function (min, max, step) {
            step = step || 1;
            var input = [];
            for (var i = min; i <= max; i += step) {
                input.push(i);
            }
            return input;
        };


        //MOBILE CAMPAIGN PLACEMENTS ARRAY DETAILS
       if ($window.localStorage.getItem("marketingObjective") == 'EVENT_RESPONSES') {
            $scope.PlacementsArr = {
                "data":
                        [
                            {
                                "name": "Mobile News Feed",
                                "id": "mobilenewsfeed",
                                "pic": "fa fa-mobile"
                            },
                            {
                                "name": "Desktop News Feed",
                                "id": "desktopnewsfeed",
                                "pic": "fa fa-desktop"
                            },
                            {
                                "name": "Desktop Right Column",
                                "id": "desktoprightcolumn",
                                "pic": "fa fa-desktop"
                            }
                        ]
            };
            $scope.MobileDeviceArr = {
                "data":
                        [
                            {
                                "name": "All mobile devices",
                                "id": "allmobiledevices"
                            },
                            {
                                "name": "Android devices only",
                                "id": "Android"
                            },
                            {
                                "name": "IOS devices only",
                                "id": "iOS"
                            },
                            {
                                "name": "Feature phones only",
                                "id": "Feature_Phone"
                            }
                        ]
            };
            $scope.campaignAudienceMobileDevice = 'All mobile devices';
        }
        $('.with-access').keyup(function (e) {
            var code = (e.keyCode ? e.keyCode : e.which);
            console.log(code);
            switch (code) {
                case 65: // a
                    $('#all').prop('checked', true);
                    break;
                case 77: // m
                    $('#men').prop('checked', true);
                    break;
                case 87: // w
                    $('#women').prop('checked', true);
                    break;
            }
        });
		
		$scope.cancelButtonClicked = function() {
            $rootScope.stopReplication = "flex";
            $rootScope.stopReplicationFrom = "cancelButton";
        };

		
    }]);

app.directive('setConnector', function () {
    return {
        restrict: 'A',
        replace: false,
        template: '',
        link: function ($scope) {
            $scope.$emit('details-loaded');
        }
    }
});