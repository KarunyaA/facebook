app.service('apiService', ['$http', '$q', 'appSettings', function ($http, $q, appSettings) {

var apiService = {};
        var apiBase = appSettings.apiBase;
        var apiImageServer = appSettings.apiImageServer;
        var apiThirdPartyServer = appSettings.apiTPBase;
        var apiTwitterBase = appSettings.apiTwitterBase;
        var fbNetwork = appSettings.fbNetwork;
        var twNetwork = appSettings.twNetwork;
        //===========================GET RESOURCE==============================
        var get = function (module, header) {
        var deferred = $q.defer();
                $http.get(apiBase + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //=========================GET RESOURCE FACEBOOK========================
        var getTp = function (module, header) {
        var deferred = $q.defer();
//		console.log(apiThirdPartyServer + module);
                $http.get(apiThirdPartyServer + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                /* } else {
                 console.log(apiTwitterBase + module)
                 $http.get(apiTwitterBase + module, header).success(function (response) {
                 deferred.resolve(response);
                 }).catch(function (data, status, headers, config) { // <--- catch instead error
                 deferred.reject(response);
                 });
                 } */

                return deferred.promise;
        };
        //=========================GET RESOURCE THIRD PARTY========================
        var getTwitterPoint = function (module, header) {
        var deferred = $q.defer();
                $http.get(module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //=========================GET TWITTER========================
        var getTwr = function (module, header) {
        var deferred = $q.defer();
                $http.get(apiTwitterBase + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
    };
        var getTw = function (module, header, network) {
        var deferred = $q.defer();
                console.log(network);
                if (network == fbNetwork) {
        $http.get(apiThirdPartyServer + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
        } else {
        console.log(apiTwitterBase + module)
                $http.get(apiTwitterBase + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
        }

        return deferred.promise;
    };
        //=========================DELETE THIRD PARTY RESOURCE=====================

        var thirdpartydelete = function (module, header) {

        var deferred = $q.defer();
                $http.delete(apiThirdPartyServer + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
    };
        var thirdpartyTWdelete = function (module, header) {

        var deferred = $q.defer();
                $http.delete(apiTwitterBase + module, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //===========================CREATE RESOURCE==============================
        var create = function (module, parameter, header) {
//        console.log("hitting Service=============");

        var deferred = $q.defer();
                $http.post(apiBase + module, parameter, header).success(function (response) {

        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //===========================CREATE RESOURCE==============================
        var createthirdparty = function (module, parameter, header) {
//        console.log("hitting Service=============");

        var deferred = $q.defer();
                $http.post(apiThirdPartyServer + module, parameter, header).success(function (response) {

        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //===========================POST TWITTER RESOURCE========================
        var createTwitter = function(module, parameter, header) {
        var deferred = $q.defer();
                $http.post(apiTwitterBase + module, parameter, header).success(function (response) {
        deferred.resolve(response);
        }).catch(function(data, status, headers, config) {
        deferred.reject(response);
        });
                return deferred.promise;
        };
        //===========================UPDATE RESOURCE==============================
        var update = function (module, parameter) {
//        console.log("hitting Service=============");

        var deferred = $q.defer();
                $http.post(apiBase + module + '/' + parameter.id, parameter, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {

        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(data.statusText);
        });
                return deferred.promise;
        };
        //===========================uploadImage RESOURCE==============================
        var uploadImage = function (module, parameter, header = { headers: { 'Content-Type': 'application/json' } }) {
//        console.log("hitting Service=============");

        var deferred = $q.defer();
                $http.post(apiImageServer + module, parameter, header).success(function (response) {

        deferred.resolve(response);
        }).catch(function (data, status, headers, config) { // <--- catch instead error
        deferred.reject(data.statusText);
        });
                return deferred.promise;
        };
                //===========================downloadImage RESOURCE==============================
                var downloadImage = function (module, parameter, header) {
//        console.log("hitting Service=============");
                var deferred = $q.defer();
                        $http.post(apiImageServer + module, parameter, header).success(function (response) {
                deferred.resolve(response);
                }).catch(function (data, status, headers, config){
                deferred.reject(data.statusText);
                });
                        return deferred.promise;
                };
                var uploadVideo = function (module, parameter, header = { headers: { 'Content-Type': undefined } }) {
//        console.log("hitting Service=============");

                var deferred = $q.defer();
                        $http.post(module, parameter, header).success(function (response) {

                deferred.resolve(response);
                }).catch(function (data, status, headers, config) { // <--- catch instead error
                deferred.reject(data.statusText);
                });
                        return deferred.promise;
                };
                        //===========================DELETE RESOURCE==============================
                        var delet = function (module, parameter) {
//        console.log("hitting Service=============");

                        var deferred = $q.defer();
                                $http.post(apiBase + module + '/' + parameter.id, parameter, { headers: { 'Content-Type': 'application/json' } }).success(function (response) {

                        deferred.resolve(response);
                        }).catch(function (data, status, headers, config) { // <--- catch instead error
                        deferred.reject(data.statusText);
                        });
                                return deferred.promise;
                        };
                        //===========================GET RESOURCE==============================
                        var urlget = function (url) {
                        var deferred = $q.defer();
                                $http.get(url).success(function (response) {
                        deferred.resolve(response);
                        }).catch(function (data, status, headers, config) { // <--- catch instead error
                        deferred.reject(response);
                        });
                                return deferred.promise;
                        };
                        apiService.get = get;
                        apiService.thirdpartydelete = thirdpartydelete;
                        apiService.thirdpartyTWdelete = thirdpartyTWdelete;
                        apiService.getTp = getTp;
                        apiService.getTwitterPoint = getTwitterPoint;
                        apiService.getTw = getTw;
                        apiService.getTwr = getTwr;
                        apiService.urlget = urlget;
                        apiService.create = create;
                        apiService.update = update;
                        apiService.delet = delet;
                        apiService.uploadImage = uploadImage;
                        apiService.downloadImage = downloadImage;
                        apiService.uploadVideo = uploadVideo;
                        apiService.createthirdparty = createthirdparty;
                        apiService.createTwitter = createTwitter;
                        return apiService;
                }]);
