var dynform = angular.module('dynform', []);
dynform.directive('dynamicForm', ['$rootScope', 'facebookGetPost', '$q', '$parse', '$http', '$templateCache', '$compile', '$document', '$timeout', function ($rootScope, facebookGetPost, $q, $parse, $http, $templateCache, $compile, $document, $timeout) {

        var supported = {
            //  Text-based elements
            'text': {element: 'input', type: 'text', editable: true, textBased: true},
            'date': {element: 'input', type: 'date', editable: true, textBased: true},
            'datetime': {element: 'input', type: 'datetime', editable: true, textBased: true},
            'datetime-local': {element: 'input', type: 'datetime-local', editable: true, textBased: true},
            'email': {element: 'input', type: 'email', editable: true, textBased: true},
            'month': {element: 'input', type: 'month', editable: true, textBased: true},
            'number': {element: 'input', type: 'number', editable: true, textBased: true},
            'password': {element: 'input', type: 'password', editable: true, textBased: true},
            'search': {element: 'input', type: 'search', editable: true, textBased: true},
            'tel': {element: 'input', type: 'tel', editable: true, textBased: true},
            'textarea': {element: 'textarea', editable: true, textBased: true},
            'time': {element: 'input', type: 'time', editable: true, textBased: true},
            'url': {element: 'input', type: 'url', editable: true, textBased: true},
            'week': {element: 'input', type: 'week', editable: true, textBased: true},
            'checkbox': {element: 'input', type: 'checkbox', editable: true, textBased: false},
            'color': {element: 'input', type: 'color', editable: true, textBased: false},
            'file': {element: 'input', type: 'file', editable: true, textBased: false},
            'range': {element: 'input', type: 'range', editable: true, textBased: false},
            'select': {element: 'select', editable: true, textBased: false},
            'checklist': {element: 'div', editable: false, textBased: false},
            'fieldset': {element: 'fieldset', editable: false, textBased: false},
            'radio': {element: 'div', editable: false, textBased: false},
            //  Non-editables
            'button': {element: 'button', type: 'button', editable: false, textBased: false},
            'hidden': {element: 'input', type: 'hidden', editable: false, textBased: false},
            'image': {element: 'input', type: 'image', editable: false, textBased: false},
            'legend': {element: 'legend', editable: false, textBased: false},
            'reset': {element: 'button', type: 'reset', editable: false, textBased: false},
            'submit': {element: 'button', type: 'submit', editable: false, textBased: false},
            //custom elements----------------start


            'stepTitle': {element: 'div', type: 'stepTitle', editable: true, textBased: true},
            'step2': {element: 'div', type: 'step2', editable: true, textBased: true},
            'step1': {element: 'div', type: 'step1', editable: true, textBased: true},
            'location': {element: 'div', type: 'location', editable: true, textBased: true},
            'language': {element: 'div', type: 'language', editable: true, textBased: true},
            'age': {element: 'div', type: 'age', editable: true, textBased: true},
            'gender': {element: 'div', type: 'gender', editable: true, textBased: true},
            'detailedTargeting': {element: 'div', type: 'detailedTargeting', editable: true, textBased: true},
            'placements': {element: 'div', type: 'placements', editable: true, textBased: true},
            'selectBox': {element: 'div', type: 'selectBox', editable: true, textBased: true},
            'campaignPlacement': {element: 'div', type: 'campaignPlacement', editable: true, textBased: true},
            'dropDown': {element: 'div', type: 'dropDown', editable: true, textBased: true},
            'stepTitle2': {element: 'div', type: 'stepTitle2', editable: true, textBased: true},
            'budgetDropdown': {element: 'div', type: 'budgetDropdown', editable: true, textBased: true},
            'dateSchedule': {element: 'div', type: 'dateSchedule', editable: true, textBased: true},
            'advertName': {element: 'div', type: 'advertName', editable: true, textBased: true},
            'advancedOption': {element: 'div', type: 'advancedOption', editable: true, textBased: true},
            'optimizationGoal': {element: 'div', type: 'optimizationGoal', editable: true, textBased: true},
            'horizontalLine': {element: 'div', type: 'horizontalLine', editable: true, textBased: true},
            'bidAmount': {element: 'div', type: 'bidAmount', editable: true, textBased: true},
            'chargedOption': {element: 'div', type: 'chargedOption', editable: true, textBased: true},
            'advertScheduling': {element: 'div', type: 'advertScheduling', editable: true, textBased: true},
            'lineChart': {element: 'div', type: 'lineChart', editable: true, textBased: true},
            'deliveryType': {element: 'div', type: 'deliveryType', editable: true, textBased: true},
            'hideadvancedOption': {element: 'div', type: 'hideadvancedOption', editable: true, textBased: true},
            'advanceSchedule': {element: 'div', type: 'advanceSchedule', editable: true, textBased: true},
            'advertFormat': {element: 'div', type: 'advertFormat', editable: true, textBased: true},
            'advertContent': {element: 'div', type: 'advertContent', editable: true, textBased: true},
            'advertUpload': {element: 'div', type: 'advertUpload', editable: true, textBased: true},
            'advertPreview': {element: 'div', type: 'advertPreview', editable: true, textBased: true},
            'creativeImage': {element: 'div', type: 'creativeImage', editable: true, textBased: true},
            'creativeVideo': {element: 'div', type: 'creativeVideo', editable: true, textBased: true},
            'creativeSlideshow': {element: 'div', type: 'creativeSlideshow', editable: true, textBased: true},
            'creativeUpload': {element: 'div', type: 'creativeUpload', editable: true, textBased: true},
            'promotedObject' : {element: 'div', type: 'promotedObject', editable: true, textBased: true},
            'successPopup': {element: 'div', type: 'successPopup', editable: true, textBased: true},
            'errorPopup': {element: 'div', type: 'errorPopup', editable: true, textBased: true},
            'progressLoader': {element: 'div', type: 'progressLoader', editable: true, textBased: true},
            'creativePreview': {element: 'div', type: 'creativePreview', editable: true, textBased: true},
            'creativePreview': {element: 'div', type: 'creativePreview', editable: true, textBased: true},
            'frequencyCap': {element: 'div', type: 'frequencyCap', editable: true, textBased: true}

            //custom elements-----------------end

        };

        return {
            restrict: 'E', // supports using directive as element only
            link: function ($scope, element, attrs) {
                //  Basic initialization
                var newElement = null,
                        newChild = null,
                        optGroups = {},
                        cbAtt = '',
                        foundOne = false,
                        iterElem = element,
                        model = null;


                if (angular.isDefined(attrs.ngModel) && (angular.isDefined(attrs.template) || angular.isDefined(attrs.templateUrl)) && !element.hasClass('dynamic-form')) {
                    model = $parse(attrs.ngModel)($scope);


                    (attrs.template ? $q.when($parse(attrs.template)($scope)) :
                            $http.get(attrs.templateUrl, {cache: $templateCache}).then(function (result) {
                        return result.data;
                    })
                            ).then(function (template) {
                        var setProperty = function (obj, props, value, lastProp, buildParent) {
                            props = props.split('.');
                            lastProp = lastProp || props.pop();

                            for (var i = 0; i < props.length; i++) {
                                obj = obj[props[i]] = obj[props[i]] || {};
                            }

                            if (!buildParent) {
                                obj[lastProp] = value;
                            }
                        },
                                bracket = function (model, base) {
                                    props = model.split('.');
                                    return (base || props.shift()) + (props.length ? "['" + props.join("']['") + "']" : '');
                                },
                                buildFields = function (field, id) {
                                    //console.log(field);
                                    //console.log(id);
                                    if (String(id).charAt(0) == '$') {

                                        return;
                                    }
                                    else if (!angular.isDefined(supported[field.type]) || supported[field.type] === false) {

                                        newElement = angular.element('<span></span>');
                                        if (angular.isDefined(field.label)) {
                                            angular.element(newElement).html(field.label);
                                        }
                                        angular.forEach(field, function (val, attr) {
                                            if (["label", "type"].indexOf(attr) > -1) {
                                                return;
                                            }
                                            newElement.attr(attr, val);
                                        });

                                        this.append(newElement);
                                        newElement = null;
                                    }
                                    else {

                                        if (!angular.isDefined(field.model)) {
                                            field.model = id;
                                        }
//				console.log(field.model)
                                        if (field.type == "location") {
                                            newElement = angular.element('<location-search data="locationData"></location-search>');
                                        } else if (field.type == "language") {
                                            newElement = angular.element('<language-search data="languageData"></language-search>');
                                        } else if (field.type == "age") {
                                            newElement = angular.element('<age-content data="ageData"></age-content>');
                                        } else if (field.type == "gender") {
                                            newElement = angular.element('<gender data="genderData"></gender>');
                                        } else if (field.type == "detailedTargeting") {
                                            newElement = angular.element('<fbdetailed-targeting data="detaileddata"></fbdetailed-targeting>');
                                        } else if (field.type == "placements") {
                                            newElement = angular.element('<campaign-placements data="placementsData"></campaign-placements>');
                                        } else if (field.type == "step1") {
                                            newElement = angular.element('<step1 data="data"></step1>');
                                        } else if (field.type == "step2") {
                                            newElement = angular.element('<step2></step2>');
                                            if (angular.isDefined(field.visibility)) {
                                                newElement.visibility = 'hide';
                                            }
                                        } else if (field.type == "stepTitle") {
                                            newElement = angular.element('<step-title></step-title>');
                                        } else if (field.type == "selectBox") {
                                            newElement = angular.element('<select-box></select-box>');
                                        } else if (field.type == "campaignPlacement") {
                                            newElement = angular.element('<campaign-placement></campaign-placement>');
                                        } else if (field.type == "dropDown") {
                                            newElement = angular.element('<drop-down></drop-down>');
                                        }

                                        else if (field.type == "stepTitle2") {
                                            newElement = angular.element('<step-title2></step-title2>');
                                        }
                                        else if (field.type == "budgetDropdown") {
                                            newElement = angular.element('<budget-dropdown fielddata=fielddata validation=checkMandatoryField()></budget-dropdown>');
                                        } else if (field.type == "dateSchedule") {
                                            newElement = angular.element('<date-schedule fielddata=fielddata validation=checkMandatoryField()></date-schedule>');
                                        } else if (field.type == "advertName") {
                                            newElement = angular.element('<advert-name fielddata=fielddata validation=checkMandatoryField()></advert-name>');
                                        } else if (field.type == "advancedOption") {
                                            newElement = angular.element('<advanced-option></advanced-option>');
                                        } else if (field.type == "optimizationGoal") {
                                            newElement = angular.element('<optimization-goal></optimization-goal>');
                                        } else if (field.type == "horizontalLine") {
                                            newElement = angular.element('<horizontal-line></horizontal-line>');
                                        } else if (field.type == "bidAmount") {
                                            newElement = angular.element('<bid-amount fielddata=fielddata validation=checkMandatoryField()></bid-amount>');
                                        } else if (field.type == "chargedOption") {
                                            newElement = angular.element('<charged-option fielddata=fielddata validation=checkMandatoryField()></charged-option>');
                                        } else if (field.type == "lineChart") {
                                            newElement = angular.element('<line-chart></line-chart>');
                                        } else if (field.type == "deliveryType") {
                                            newElement = angular.element('<delivery-type fielddata=fielddata validation=checkMandatoryField()></delivery-type>');
                                        } else if (field.type == "hideadvancedOption") {
                                            newElement = angular.element('<hideadvanced-option></hideadvanced-option>');
                                        } else if (field.type == "advertScheduling") {
                                            newElement = angular.element('<advert-scheduling fielddata=fielddata></advert-scheduling>');
                                        } else if (field.type == "advertFormat") {
                                            newElement = angular.element('<advert-format></advert-format>');
                                        } else if (field.type == "advertContent") {
                                            newElement = angular.element('<advert-content></advert-content>');
                                        } else if (field.type == "advertUpload") {
                                            newElement = angular.element('<advert-upload></advert-upload>');
                                        } else if (field.type == "advertPreview") {
                                            newElement = angular.element('<advert-preview></advert-preview>');
                                        } else if (field.type == "creativeImage") {
                                            newElement = angular.element('<creative-image fielddata="fielddata"></creative-image>');
                                        } else if (field.type == "creativeVideo") {
                                            newElement = angular.element('<creative-video fielddata="fielddata"></creative-video>');
                                        } else if (field.type == "creativeSlideshow") {
                                            newElement = angular.element('<creative-slideshow fielddata="fielddata"></creative-slideshow>');
                                        } else if (field.type == "creativeUpload") {
                                            newElement = angular.element('<creative-upload></creative-upload>');
                                        } else if (field.type == "creativePreview") {
                                            newElement = angular.element('<creative-preview></creative-preview>');
                                        } else if (field.type == "promotedObject") {
                                            newElement = angular.element('<promoted-object data="promotedobjectdata"></promoted-object>');
                                        } else if (field.type == "successPopup") {
                                            newElement = angular.element('<success-popup data="successpopupdata"></success-popup>');
                                        } else if (field.type == "progressLoader") {
                                            newElement = angular.element('<progress-popup data="progressloaderdata"></progress-popup>');
                                        }else if (field.type == "errorPopup") {
                                            newElement = angular.element('<error-popup data="errorpopupdata"></error-popup>');
                                        } else if(field.type=="frequencyCap") {
					newElement = angular.element('<frequency-cap fielddata="fielddata"></frequency-cap>');
                                        } else {
                                            newElement = angular.element($document[0].createElement(supported[field.type].element));
                                        }


                                        if (angular.isDefined(supported[field.type].type)) {
                                            newElement.attr('type', supported[field.type].type);
                                        }


                                        if (angular.isDefined(supported[field.type].editable) && supported[field.type].editable) {

                                            newElement.attr('name', bracket(field.model));
                                            newElement.attr('ng-model', bracket(field.model, attrs.ngModel));

                                            setProperty(model, field.model, {}, null, true);

                                            if (angular.isDefined(field.readonly)) {
                                                newElement.attr('ng-readonly', field.readonly);
                                            }
                                            if (angular.isDefined(field.required)) {
                                                newElement.attr('ng-required', field.required);
                                            }
                                            if (angular.isDefined(field.val)) {
                                                setProperty(model, field.model, angular.copy(field.val));
                                                newElement.attr('value', field.val);
                                            }
                                        }


                                        if (angular.isDefined(supported[field.type].textBased) && supported[field.type].textBased) {
                                            if (angular.isDefined(field.minLength)) {
                                                newElement.attr('ng-minlength', field.minLength);
                                            }
                                            if (angular.isDefined(field.maxLength)) {
                                                newElement.attr('ng-maxlength', field.maxLength);
                                            }
                                            if (angular.isDefined(field.validate)) {
                                                newElement.attr('ng-pattern', field.validate);
                                            }
                                            if (angular.isDefined(field.placeholder)) {
                                                newElement.attr('placeholder', field.placeholder);
                                            }
                                        }


                                        if (field.type === 'number' || field.type === 'range') {
                                            if (angular.isDefined(field.minValue)) {
                                                newElement.attr('min', field.minValue);
                                            }
                                            if (angular.isDefined(field.maxValue)) {
                                                newElement.attr('max', field.maxValue);
                                            }
                                            if (angular.isDefined(field.step)) {
                                                newElement.attr('step', field.step);
                                            }
                                        }
                                        else if (['text', 'textarea'].indexOf(field.type) > -1) {

                                            if (angular.isDefined(field.splitBy)) {
                                                newElement.attr('ng-list', field.splitBy)

                                            }
                                            newElement.attr('class', field.class);

                                        }
                                        else if (field.type === 'search') {

                                            if (angular.isDefined(field.class)) {
                                                newElement.attr('class', field.class);
                                                //console.log(field.type);
                                            }

                                            if (angular.isDefined(field.list)) {
                                                newElement.attr('list', field.list);
                                            }
                                            /*if (angular.isDefined(field.source)) {newElement.attr('src', field.source);} */
                                        }
                                        else if (field.type === 'checkbox') {
                                            if (angular.isDefined(field.isOn)) {
                                                newElement.attr('ng-true-value', field.isOn);
                                            }
                                            if (angular.isDefined(field.isOff)) {
                                                newElement.attr('ng-false-value', field.isOff);
                                            }
                                            if (angular.isDefined(field.slaveTo)) {
                                                newElement.attr('ng-checked', field.slaveTo);
                                            }
                                        }
                                        else if (field.type === 'checklist') {
                                            if (angular.isDefined(field.val)) {
                                                setProperty(model, field.model, angular.copy(field.val));
                                            }
                                            if (angular.isDefined(field.options)) {
                                                if (!(angular.isDefined(model[field.model]) && angular.isObject(model[field.model]))) {
                                                    setProperty(model, field.model, {});
                                                }
                                                angular.forEach(field.options, function (option, childId) {
                                                    newChild = angular.element('<input type="checkbox" />');
                                                    newChild.attr('name', bracket(field.model + '.' + childId));
                                                    newChild.attr('ng-model', bracket(field.model + "." + childId, attrs.ngModel));
                                                    if (angular.isDefined(option['class'])) {
                                                        newChild.attr('ng-class', option['class']);
                                                    }
                                                    if (angular.isDefined(field.disabled)) {
                                                        newChild.attr('ng-disabled', field.disabled);
                                                    }
                                                    if (angular.isDefined(field.readonly)) {
                                                        newChild.attr('ng-readonly', field.readonly);
                                                    }
                                                    if (angular.isDefined(field.required)) {
                                                        newChild.attr('ng-required', field.required);
                                                    }
                                                    if (angular.isDefined(field.callback)) {
                                                        newChild.attr('ng-change', field.callback);
                                                    }
                                                    if (angular.isDefined(option.isOn)) {
                                                        newChild.attr('ng-true-value', option.isOn);
                                                    }
                                                    if (angular.isDefined(option.isOff)) {
                                                        newChild.attr('ng-false-value', option.isOff);
                                                    }
                                                    if (angular.isDefined(option.slaveTo)) {
                                                        newChild.attr('ng-checked', option.slaveTo);
                                                    }
                                                    if (angular.isDefined(option.val)) {
                                                        setProperty(model, field.model, angular.copy(option.val), childId);
                                                        newChild.attr('value', option.val);
                                                    }

                                                    if (angular.isDefined(option.label)) {
                                                        newChild = newChild.wrap('<label></label>').parent();
                                                        newChild.append(document.createTextNode(' ' + option.label));
                                                    }
                                                    newElement.append(newChild);
                                                });
                                            }
                                        }
                                        else if (field.type === 'radio') {
                                            if (angular.isDefined(field.val)) {
                                                setProperty(model, field.model, angular.copy(field.val));
                                            }
                                            if (angular.isDefined(field.values)) {
                                                angular.forEach(field.values, function (label, val) {
                                                    newChild = angular.element('<input type="radio" />');
                                                    newChild.attr('name', bracket(field.model));
                                                    newChild.attr('ng-model', bracket(field.model, attrs.ngModel));
                                                    if (angular.isDefined(field['class'])) {
                                                        newChild.attr('ng-class', field['class']);
                                                    }
                                                    if (angular.isDefined(field.disabled)) {
                                                        newChild.attr('ng-disabled', field.disabled);
                                                    }
                                                    if (angular.isDefined(field.callback)) {
                                                        newChild.attr('ng-change', field.callback);
                                                    }
                                                    if (angular.isDefined(field.readonly)) {
                                                        newChild.attr('ng-readonly', field.readonly);
                                                    }
                                                    if (angular.isDefined(field.required)) {
                                                        newChild.attr('ng-required', field.required);
                                                    }
                                                    newChild.attr('value', val);
                                                    if (angular.isDefined(field.val) && field.val === val) {
                                                        newChild.attr('checked', 'checked');
                                                    }

                                                    if (label) {
                                                        newChild = newChild.wrap('<label></label>').parent();
                                                        newChild.append(document.createTextNode(' ' + label));
                                                    }
                                                    newElement.append(newChild);
                                                });
                                            }
                                        }
                                        else if (field.type === 'select') {
                                            if (angular.isDefined(field.multiple) && field.multiple !== false) {
                                                newElement.attr('multiple', 'multiple');
                                            }
                                            if (angular.isDefined(field.empty) && field.empty !== false) {
                                                newElement.append(angular.element($document[0].createElement('option')).attr('value', '').html(field.empty));
                                            }

                                            if (angular.isDefined(field.autoOptions)) {
                                                newElement.attr('ng-options', field.autoOptions);
                                            }
                                            else if (angular.isDefined(field.options)) {
                                                angular.forEach(field.options, function (option, childId) {
                                                    newChild = angular.element($document[0].createElement('option'));
                                                    newChild.attr('value', childId);
                                                    if (angular.isDefined(option.disabled)) {
                                                        newChild.attr('ng-disabled', option.disabled);
                                                    }
                                                    if (angular.isDefined(option.slaveTo)) {
                                                        newChild.attr('ng-selected', option.slaveTo);
                                                    }
                                                    if (angular.isDefined(option.label)) {
                                                        newChild.html(option.label);
                                                    }
                                                    if (angular.isDefined(option.group)) {
                                                        if (!angular.isDefined(optGroups[option.group])) {
                                                            optGroups[option.group] = angular.element($document[0].createElement('optgroup'));
                                                            optGroups[option.group].attr('label', option.group);
                                                        }
                                                        optGroups[option.group].append(newChild);
                                                    }
                                                    else {
                                                        newElement.append(newChild);
                                                    }
                                                });

                                                if (!angular.equals(optGroups, {})) {
                                                    angular.forEach(optGroups, function (optGroup) {
                                                        newElement.append(optGroup);
                                                    });
                                                    optGroups = {};
                                                }
                                            }
                                        }
                                        else if (field.type === 'image') {
                                            if (angular.isDefined(field.label)) {
                                                newElement.attr('alt', field.label);
                                            }
                                            if (angular.isDefined(field.source)) {
                                                newElement.attr('src', field.source);
                                            }
                                        }

                                        else if (field.type === 'hidden') {
                                            newElement.attr('name', bracket(field.model));
                                            newElement.attr('ng-model', bracket(field.model, attrs.ngModel));
                                            if (angular.isDefined(field.val)) {
                                                setProperty(model, field.model, angular.copy(field.val));
                                                newElement.attr('value', field.val);
                                            }
                                        }
                                        else if (field.type === 'file') {
                                            if (angular.isDefined(field.multiple)) {
                                                newElement.attr('multiple', field.multiple);
                                            }
                                        }
                                        else if (field.type === 'fieldset') {
                                            //	console.log(field.fields)
                                            if (angular.isDefined(field.fields)) {
                                                var workingElement = newElement;
                                                angular.forEach(field.fields, buildFields, newElement);
                                                newElement = workingElement;
                                            }
                                        }


                                        if (field.type !== "radio") {
                                            if (angular.isDefined(field['class'])) {
                                                newElement.attr('ng-class', field['class']);
                                            }

                                            if (field.type !== "checklist") {
                                                if (angular.isDefined(field.disabled)) {
                                                    newElement.attr('ng-disabled', field.disabled);
                                                }
                                                if (angular.isDefined(field.callback)) {

                                                    if (["button", "fieldset", "image", "legend", "reset", "submit", "advertScheduling"].indexOf(field.type) > -1) {
                                                        cbAtt = 'ng-click';
                                                    }

                                                    else {
                                                        cbAtt = 'ng-change';
                                                    }
                                                    newElement.attr(cbAtt, field.callback);
                                                }
                                            }
                                        }


                                        if (angular.isDefined(field.label)) {

                                            if (["image", "hidden"].indexOf(field.type) > -1) {
                                                angular.noop();
                                            }

                                            else if (["fieldset"].indexOf(field.type) > -1) {
                                                newElement.prepend(angular.element($document[0].createElement('legend')).html(field.label));
                                            }

                                            else if (["button", "legend", "reset", "submit"].indexOf(field.type) > -1) {
                                                newElement.html(field.label);
//					console.log(field.class);
                                                if (angular.isDefined(field.class)) {
                                                    newElement.attr('class', field.class);
                                                }
                                            }

                                            else {
                                                newElement = newElement.wrap('<label></label>').parent();
                                                newElement.prepend(document.createTextNode(field.label + ' '));
                                            }
                                        }


                                        if (angular.isDefined(field.attributes)) {
                                            angular.forEach(field.attributes, function (val, attr) {
                                                newElement.attr(attr, val);
                                            });
                                        }


                                        this.append(newElement);
                                        newElement = null;
                                    }


                                };

                        angular.forEach(template, buildFields, element);


                        while (!angular.equals(iterElem.parent(), $document) && !angular.equals(iterElem[0], $document[0].documentElement)) {
                            if (['form', 'ngForm', 'dynamicForm'].indexOf(attrs.$normalize(angular.lowercase(iterElem.parent()[0].nodeName))) > -1) {
                                foundOne = true;
                                break;
                            }
                            iterElem = iterElem.parent();
                        }

                        if (foundOne) {
                            newElement = angular.element($document[0].createElement('ng-form'));
                        }
                        else {
                            newElement = angular.element("<form></form>");
                        }


                        angular.forEach(attrs.$attr, function (attName, attIndex) {
                            newElement.attr(attName, attrs[attIndex]);
                        });
                        newElement.attr('model', attrs.ngModel);
                        newElement.removeAttr('ng-model');
                        angular.forEach(element[0].classList, function (clsName) {
                            newElement[0].classList.add(clsName);
                        });
                        newElement.addClass('dynamic-form');
                        newElement.append(element.contents());


                        newElement.data('$_cleanModel', angular.copy(model));
                        newElement.bind('reset', function () {
                            $timeout(function () {
                                $scope.$broadcast('reset', arguments);
                            }, 0);
                        });
                        $scope.$on('reset', function () {
                            $scope.$apply(function () {
                                $scope[attrs.ngModel] = {};
                            });
                            $scope.$apply(function () {
                                $scope[attrs.ngModel] = angular.copy(newElement.data('$_cleanModel'));
                            });
                        });


                        $compile(newElement)($scope);
                        element.replaceWith(newElement);
                    });
                }
            }
        };
    }])

        .directive('ngList', [function () {
                return {
                    require: '?ngModel',
                    link: function (scope, element, attr, ctrl) {
                        var match = /\/(.*)\//.exec(element.attr(attr.$attr.ngList)),
                                separator = match && new RegExp(match[1]) || element.attr(attr.$attr.ngList) || ',';

                        if (element[0].form !== null && !angular.element(element[0].form).hasClass('dynamic-form')) {
                            return;
                        }

                        ctrl.$parsers.splice(0, 1);
                        ctrl.$formatters.splice(0, 1);

                        ctrl.$parsers.push(function (viewValue) {
                            var list = [];

                            if (angular.isString(viewValue)) {

                                if (String.prototype.trim) {
                                    angular.forEach(viewValue.split(separator), function (value) {
                                        if (value)
                                            list.push(value.trim());
                                    });
                                }
                                else {
                                    angular.forEach(viewValue.split(separator), function (value) {
                                        if (value)
                                            list.push(value.replace(/^\s*/, '').replace(/\s*$/, ''));
                                    });
                                }
                            }

                            return list;
                        });

                        ctrl.$formatters.push(function (val) {
                            var joinBy = angular.isString(separator) && separator || ', ';

                            if (angular.isArray(val)) {
                                return val.join(joinBy);
                            }

                            return undefined;
                        });
                    }
                };
            }])

        .directive('search', [function () {
                return {
                    require: '?ngModel',
                    link: function (scope, element, attr, ctrl) {
                        var match = /\/(.*)\//.exec(element.attr(attr.$attr.ngList)),
                                separator = match && new RegExp(match[1]) || element.attr(attr.$attr.ngList) || ',';

                        if (element[0].form !== null && !angular.element(element[0].form).hasClass('dynamic-form')) {
                            return;
                        }

                        ctrl.$parsers.splice(0, 1);
                        ctrl.$formatters.splice(0, 1);




                    }
                };
            }])

        .directive('input', ['$parse', function ($parse) {
                return {
                    restrict: 'E',
                    require: '?ngModel',
                    link: function (scope, element, attrs, ctrl) {
                        if (!ctrl) {

                            return;
                        }

                        if (attrs.type === 'file') {
                            var modelGet = $parse(attrs.ngModel),
                                    modelSet = modelGet.assign,
                                    onChange = $parse(attrs.onChange),
                                    updateModel = function () {
                                        scope.$apply(function () {
                                            modelSet(scope, element[0].files);
                                            onChange(scope);
                                        });
                                    };

                            ctrl.$render = function () {
                                element[0].files = this.$viewValue;
                            };
                            element.bind('change', updateModel);
                        }
                        else if (attrs.type === 'range') {
                            ctrl.$parsers.push(function (val) {
                                if (val) {
                                    return parseFloat(val);
                                }
                            });
                        }
                    }
                };
            }])
        .directive("stepTitle", [function () {
                return {
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/stepTitle.html',
                    link: function (scope, elem, attrs, sharedService) {
                        console.log(scope.$parent.pageContent);
                        scope[this.name] = scope.$parent.pageContent[this.name].content;

                    }
                }
            }])
        .directive("step1", [function () {
                return {
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/step1.html',
                    link: function (scope, elem, attrs) {
                        scope[this.name] = scope.$parent.pageContent[this.name].content;

                        scope.$watch(function () {
                            return scope.$parent.vm.getData.objective
                        }, function (newVal) {
                            console.log(newVal);
                        }, true)
                    }

                };
            }])
        .directive("step2", [function () {
                return {
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/step2.html',
                    link: function (scope, elem, attrs) {
                        scope[this.name] = scope.$parent.pageContent[this.name].content;

                        if (scope.$parent.pageContent[this.name].required == 'yes') {
                            scope.isRequired = 'required';
                        } else {
                            scope.isRequired = 'no';
                        }

                        scope.$watch(function () {
                            return scope.$parent.vm.getData.objective
                        }, function (newVal) {
                            //console.log(newVal);
                        }, true)
                    }

                };
            }])

//Plan page custom directives

        .directive("stepTitle2", [function () {
                return {
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/directive/stepTitle2.html',
                    link: function (scope, elem, attrs, sharedService) {
                        console.log(scope.$parent.pageContent);
                        scope[this.name] = scope.$parent.pageContent[this.name].content;

                    }
                }
            }])

        .directive('budgetDropdown', ['$rootScope', 'facebookGetPost', '$window', '$filter', '$q', function ($rootScope, facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/budgetDropdownTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr) {
                        scope.fielddata = {
                            campaignPlanFormBudget: "",
                            campaignPlanFormBudgetValue: "",
                            budgetEditValue: "",
                            budget: "",
                            campaignPlanFormSchedule: "",
                            scheduleStartDate: "",
                            scheduleEndDate: "",
                            advertSetName: "",
                            bidAmountVal: "",
                            bidAmount: "",
                            manualbidtxt: "",
                            chargedoptions: "",
                            impressions: "",
                            radioimpressions: "",
                            moreimpressions: "",
                            deliverType: "",
                            deliveryText: "",
                            runAdvert: "",
                            AdvertText: "",
                            startDateToday: "",
                        }
                        scope.campaignState = $window.localStorage.getItem("campaignState");
                        scope.campaignPlanFormBudget = "dailyBudget";
                        scope.budgetItems = [{
                                "id": 1,
                                "name": "dailyBudget",
                                "description": "Daily Budget",
                                "code": null
                            }, {
                                "id": 2,
                                "name": "lifetimeBudget",
                                "description": "Lifetime Budget",
                                "code": null
                            }]
                        scope.selectBudget = function (budgetvalue) {
                            console.log(budgetvalue);
                            //scope.$emit('budgetselection',{value:budgetvalue});
                            if (budgetvalue == "dailyBudget") {
                                scope.budget = true;
                                scope.startDateToday = false;
                                console.log(scope.budget);
                                scope.$emit('budgetselection', {value: budgetvalue, value1: scope.budget, value2: scope.startDateToday});
                            }
                            else {
                                scope.budget = false;
                                scope.startDateToday = true;
                                console.log(scope.budget);
                                scope.$emit('budgetselection', {value: budgetvalue, value1: scope.budget, value2: scope.startDateToday});
                            }
                        }
                        //scope.init = function () {
                        if (scope.campaignState == "create") {
                            scope.selectBudget("dailyBudget");
                            //scope.selectBudget();
                            scope.budget = true;

                        }
                        else {
                            console.log(scope.campaignPlanFormBudgetValue);
                            angular.element('#step2').css('background-color', '#95D2B1');
                            angular.element('#step1').css('background-color', '#95D2B1');

                            scope.$on('addetails', function (event, args) {
                                console.log(args);
                                console.log(args.value);
                                scope.budgetEditValue = args.value.adsetDetails.lifetime_budget;
                                console.log(scope.budgetEditValue);

                                if (scope.budgetEditValue != 0) {
                                    console.log(scope.budgetEditValue);
                                    scope.campaignPlanFormBudget = "lifetimeBudget"
                                    scope.campaignPlanFormBudgetValue = args.value.adsetDetails.lifetime_budget;
                                    var adserArr = args.value.adsetDetails.adset_schedule;
                                    scope.selectBudget("lifetimeBudget");
                                    //scope.prePopulateChart(adserArr);
                                } else {
                                    scope.campaignPlanFormBudget = "dailyBudget"
                                    scope.campaignPlanFormBudgetValue = args.value.adsetDetails.daily_budget
                                    console.log(scope.campaignPlanFormBudgetValue);
                                    scope.selectBudget("dailyBudget");
                                }
                            });

                        }

                        scope.$watch('campaignPlanFormBudgetValue', function (newVal, oldVal) {
                            console.log(newVal);
                            scope.$emit('campaignPlanFormBudgetValue', {value: scope.campaignPlanFormBudgetValue});
                            scope.validation();
                            if (newVal) {
                                angular.element('#step1').css('background-color', '#95D2B1');
                            } else
                            {
                                angular.element('#step1').css('background-color', '#c2c2c2');
                            }
                        }, true);

                        scope.setBudgetValue = function (value) {
                            scope.campaignPlanFormBudgetValue = value;
                            console.log(scope.campaignPlanFormBudgetValue);
                        }



                        //}

                    }
                    //controller:'',
                    //bindToController:true,
                }

            }])

        .directive('dateSchedule', ['facebookGetPost', '$window', '$filter', '$q', function (facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/dateScheduleTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr) {
                        scope.fielddata = {
                            campaignPlanFormSchedule: "",
                            scheduleStartDate: "",
                            scheduleEndDate: "",
                        }
                        scope.campaignState = $window.localStorage.getItem("campaignState");


                        scope.selectSchedule = function (value) {
                          //  console.log(value);
                            console.log(value);
                            if (value == "1") {
                               scope.campaignPlanFormSchedule = 1;
                                scope.setDate = false;
                                scope.enddateselected = false;
                                scope.todayDate = new Date();
                                var currentDate = $filter('date')(scope.todayDate, 'yyyy-M-d hh:mm a');
                                scope.scheduleStartDate = new Date(currentDate);
                                scope.scheduleEndDate = 0; //$filter('date')(new Date($scope.todayDate), 'yyyy-mm-dd HH:mm:');
                                scope.$emit('scheduleone', {value: scope.campaignPlanFormSchedule});
                            } else {
                             scope.campaignPlanFormSchedule = 2;
                                scope.setDate = true;
                                scope.enddateselected = false;
                                scope.todayDate = new Date();
                                scope.scheduleEndDate = scope.endDate;
                                var currentDate = $filter('date')(scope.todayDate, 'yyyy-M-d hh:mm a');
                                scope.scheduleStartDate = new Date(currentDate);
                                scope.scheduleEndDate = 0;
                                scope.$emit('scheduletwo', {value: scope.campaignPlanFormSchedule});



                            }

                            $window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
                            $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);
                            //scope.checkMandatoryField();
                            scope.validation();
                        }

                        scope.onDateChange1 = function (selectedDate) {
                            console.log(selectedDate);
                            scope.scheduleStartDate = selectedDate;
                            console.log(scope.scheduleStartDate)
                            $window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
                            scope.$emit('scheduleStartDate', {value: scope.scheduleStartDate});
                        }
                        scope.onDateChange2 = function (selectedDate) {
                            console.log(selectedDate);
                            scope.scheduleEndDate = selectedDate;
                            console.log(scope.scheduleEndDate)
                            $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);
                            scope.diffDate(scope.scheduleStartDate, scope.scheduleEndDate);
                            scope.$emit('scheduleEndDate', {value: scope.scheduleEndDate});
                        //    scope.checkMandatoryField();
                          //     console.log("gets in");
                            scope.validation();
                            
                        }

                        scope.diffDate = function (date1, date2) {
                            console.log(date2);
                            var dateOut1 = new Date(date1); // it will work if date1 is in ISO format
                            var dateOut2 = new Date(date2);
                            var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                            console.log(timeDiff);
                            scope.diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                            if (Date.parse(scope.scheduleEndDate) >= Date.parse(scope.scheduleStartDate)) {
                                scope.enddateselected = true;
                                scope.$emit('enddateselected', {value: scope.enddateselected, value1: scope.diffDays});
                                console.log('true');
                            } else
                            {
                                console.log('false');
                                scope.enddateselected = false;
                                scope.$emit('enddateselected', {value: scope.enddateselected});
                            }
                        };

                        scope.onTimeChange1 = function (selectedTime) {
                            console.log(selectedTime);
                            scope.scheduleStartDate = selectedTime;
                            console.log(scope.scheduleStartDate)
                            $window.localStorage.setItem("scheduleStartDate", scope.scheduleStartDate);
                            console.log(scope.enddateselected);
                        }
                        scope.onTimeChange2 = function (selectedTime) {
                            console.log(selectedTime);
                            //$scope.checkMandatoryField();
                            scope.validation();
                            scope.scheduleEndDate = selectedTime;
                            console.log(scope.scheduleEndDate);
                            $window.localStorage.setItem("scheduleEndDate", scope.scheduleEndDate);

                        }

                      
                        if (scope.campaignState == "create") {
                            console.log(scope.campaignPlanFormSchedule);
                            scope.campaignPlanFormSchedule = 1;
                            scope.selectSchedule(scope.campaignPlanFormSchedule);
                            scope.campaignPlanFormBudget = "dailyBudget";
                            scope.$emit('campaignPlanFormSchedule', {value: scope.campaignPlanFormSchedule});

                        }

                        scope.$on('schedulingdetails', function (event, args) {
                            console.log(args.value);
                            scope.selectSchedule(args.value);
                        });
                         
                        
                 
                        scope.$on('datediff', function (event, args) {
                            console.log(args.value);
                            console.log(args.value1);
                            scope.campaignPlanFormSchedule = 2;
                            scope.setDate = true;
                            scope.scheduleStartDate = args.value;
                            scope.scheduleEndDate = args.value1;
                            scope.diffDate(args.value, args.value1);

                        });

                        scope.$on('campaignPlanFormBudgetValue', function (events, args) {
                            scope.campaignPlanFormBudgetValue = args.value;
                            console.log(scope.campaignPlanFormBudgetValue);
                        });

                        scope.$on('budgetselect', function (events, args) {
                            scope.campaignPlanFormBudget = args.value;
                            console.log(scope.campaignPlanFormBudget);
                        });

                    }

                }

            }])

        .directive('advertName', ['facebookGetPost', '$window', '$filter', '$q', function (facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/advertNameTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr) {
                        scope.fielddata = {
                            advertSetName: "",
                            advancedOption: "",
                            showAdvanced: "",
                            localAwareness: "",
                            advertSchedule: "",
                        }
                        scope.campaignState = $window.localStorage.getItem("campaignState");
                        scope.advancedOption = false;
                        scope.showAdvanced = true;
                        scope.localAwareness = false;

                        scope.getAdvertSetName = function (_value) {
                            console.log(_value);
                            scope.advertSetName = _value;
                            //$scope.checkMandatoryField();
                            scope.$emit('advertname', {value: scope.advertSetName});
                            scope.validation();
                            console.log(scope.advancedOption);
                            console.log(scope.showAdvanced);
                            console.log(scope.localAwareness);
                        }

                        scope.openAdvancedOption = function () {
                            console.log('adv open');
                            scope.advancedOption = true;
                            scope.advertSchedule = true;
                            scope.$emit('openadvanced', {value: scope.advancedOption, value1: scope.advertSchedule});
                        }

                        scope.$on('closeadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                            scope.showAdvanced = args.value1;
                            scope.localAwareness = args.value2;
                        });


                        //scope.init = function () {
                        if (scope.campaignState == "create") {
                            console.log(scope.advertSetName);

                        }
                        else {
                            scope.$on('advertname', function (event, args) {
                                console.log(args.value);
                                scope.advertSetName = args.value;
                            });

                        }

                    }
                }

            }])

        .directive('bidAmount', ['facebookGetPost', '$window', '$filter', '$q', function (facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/bidAmountTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr) {
                        scope.fielddata = {
                            bidAmountVal: "",
                            bidAmount: "",
                            manualbidtxt: "",
                            advancedOption: "",
                            showAdvanced: "",
                            localAwareness: "",
                            advertSchedule: ""
                        }
                        scope.campaignState = $window.localStorage.getItem("campaignState");

                        scope.manualbidtxt = "per post engagement";
                        scope.MarkettingObjective = $window.localStorage.getItem("marketingObjective");
          //           console.log("*******************************************************************************");
          //           console.log("************************************"+scope.MarkettingObjective +"********************************************");
           //          console.log("*******************************************************************************");
                     if(scope.MarkettingObjective=="REACH")
                     {
                          scope.manualbidtxt = "per 1000 impressions";
                     }
                        scope.selectBidAmount = function (bidvalue) {
                      //      console.log("ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                           // console.log(bidvalue);
                            if (bidvalue == 1) {
                                scope.showText = false;
                            }
                            else {
                                scope.showText = true;
                            }
                            scope.$emit('selectbid', {value: bidvalue});
                        }

                        scope.saveBidAmount = function (value) {
                            scope.bidAmount = value;
                            scope.$emit('bidAmount', {value: scope.bidAmount});
                            scope.validation();
                        }

                        if (scope.campaignState == "create") {
                            console.log('bid amount directive');
                            scope.bidAmountVal = 1;

                        }
                        scope.$on('manualbidtxt', function (event, args) {
                            console.log(args.value);
                            scope.manualbidtxt = args.value;
                        });

                        scope.$on('bidauto', function (event, args) {
                            console.log(args.value);
                            scope.bidAmountVal = args.value;
                        });

                        scope.$on('bidmanual', function (event, args) {
                            console.log(args.value);
                            scope.bidAmountVal = args.value;
                            scope.showText = true;
                            scope.autoBid = false;
                            scope.bidAmount = args.value1;
                        });

                        scope.$on('openadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                        });

                        scope.$on('closeadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                            scope.showAdvanced = args.value1;
                            scope.localAwareness = args.value2;
                        });

                      scope.init =function(){
                             
                          scope.autoBid = true;
                          scope.selectBidAmount(1);
                             
                         }   
                        scope.init();


                    }
                    //controller:'',
                    //bindToController:true,
                }

            }])

 
        .directive('chargedOption',['facebookGetPost','$window','$filter','$q',function(facebookGetPost,$window,$filter,$q){	
                return{
                        restrict:'E',		
                        templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/chargedOptionTemplate.html',
                        transclude:true,			
                        scope:{		
                        fielddata:"=",
                        validation:"&",			
                },                          							
                        link:function(scope,element,attr){
                        scope.fielddata = {
                                chargedoptions:"",
                                impressions:"",
                                radioimpressions:"",
                                moreimpressions:"",
                                advancedOption:"",
                                showAdvanced:"",
                                localAwareness:"",
                                advertSchedule:"",

                        }

                        scope.impressions = false;
                        scope.radioimpressions = false;
                scope.moreimpressions = false;
                        scope.chargedoptions = "POST_ENGAGEMENT";
                        scope.chargedOption = [
                        {
                        "id": "POST_ENGAGEMENT",
                                "name": "Post engagement",
                                "disabled": "false"
                        },
                        {
                        "id": "IMPRESSIONS",
                                "name": "Impressions",
                                "disabled": "false"
                        }
                ]

                         scope.init = function () {
                               scope.MarkettingObjective = $window.localStorage.getItem("marketingObjective");
                  //           console.log("*******************************************************************************");
                  //           console.log("************************************"+scope.MarkettingObjective +"********************************************");
                   //          console.log("*******************************************************************************");
                             if(scope.MarkettingObjective=="REACH")
                             {
                                 scope.chargedoptions = "IMPRESSIONS";
                                 scope.chargedOption = [  {
                                    "id": "IMPRESSIONS",
                                            "name": "Impressions",
                                            "disabled": "false"
                                    }]

                                 scope.impressions = true;
                                scope.radioimpressions = false;
                                scope.moreimpressions = false;


                                scope.selectOption(scope.chargedoptions);
                             }


                         }
                        scope.openImpression = function () {
                                scope.impressions = true;
                                scope.radioimpressions = true;
                                scope.moreimpressions = true;
                }

                        scope.campaignState = $window.localStorage.getItem("campaignState");


                                        if (scope.campaignState == "create") {		

                                        }

                        scope.$on('chargedoptionone', function (event,args) {
                        console.log(args.value);
                        scope.chargedoptions = args.value;		
                        scope.chargedOption = [
                        {
                        "id": "POST_ENGAGEMENT",
                                "name": "Post engagement",
                                "disabled": "false"
                        },
                        {
                        "id": "IMPRESSIONS",
                                "name": "Impressions",
                                "disabled": "false"
                        }
                        ]
                        });

                        scope.$on('chargedoptiontwo', function (event,args) {
                        console.log(args.value);
                        scope.chargedoptions = args.value;
                        scope.chargedOption = [
                        {
                        "id": "IMPRESSIONS",
                                "name": "Impressions",
                                "disabled": "false"
                        }
                        ]		
                        });

                                                scope.$on('openadvancedchild', function (event,args) {
                                                console.log(args.value);
                                                scope.advancedOption = args.value;
                                                });

                                                scope.$on('closeadvancedchild', function (event,args) {
                                                console.log(args.value);
                                                scope.advancedOption = args.value;
                                                scope.showAdvanced = args.value1;
                                                scope.localAwareness = args.value2;
                                                });

                        scope.selectOption = function (value) {
                                scope.chargedoptions = value;
                                scope.$emit('selectoption',{value:scope.chargedoptions});
                }




                        scope.init();
                        }
                        //controller:'',
                        //bindToController:true,
                }

        }])


        .directive('advertScheduling', ['$rootScope', 'facebookGetPost', '$window', '$filter', '$q', function ($rootScope, facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/advertSchedulingTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr, fbbudgetPlanCtrl) {
                        scope.fielddata = {
                            campaignPlanFormBudget: "",
                            campaignPlanFormBudgetValue: "",
                            budgetEditValue: "",
                            budget: "",
                            campaignPlanFormSchedule: "",
                            scheduleStartDate: "",
                            scheduleEndDate: "",
                            advertSetName: "",
                            bidAmountVal: "",
                            bidAmount: "",
                            manualbidtxt: "",
                            chargedoptions: "",
                            impressions: "",
                            radioimpressions: "",
                            moreimpressions: "",
                            deliverType: "",
                            deliveryText: "",
                            runAdvert: "",
                            AdvertText: "",
                            showChart: "",
                        }
                        scope.runAdvert = 1;
                        scope.AdvertText = "Run adverts all the time";
                        //scope.showChart = true;

                        scope.openRunAdverts = function () {
                            scope.runAdverts = true;
                            //scope.showChart = true;
                        }

                        scope.graphClicked = function ($event) {
                            console.log(scope.runAdvert);
                            $event.stopPropagation();
                            $event.preventDefault();
                            //$rootScope.graphAccess = true;
                        }
                        scope.selectRunAdvert = function (value, event) {
                            //console.log("$rootScope.graphAccess " +$rootScope.graphAccess);
                            console.log(value);
                            if (value == 1) {
                                scope.AdvertText = "Run adverts all the time";
                                scope.showChart = false;
                                scope.$emit('advertone', {value: scope.showChart});
                                //$rootScope.graphAccess = false;
                            } else {
                                scope.AdvertText = "Run adverts on a schedule";
                                scope.showChart = true;

                                scope.$emit('adverttwo', {value: scope.showChart});
                            }


                        }


                        scope.$on('schedulingone', function (event, args) {
                            console.log(args.value);
                            scope.runAdvert = 1;
                            scope.AdvertText = "Run adverts all the time";
                            scope.showChart = false;

                        });

                        scope.$on('schedulingtwo', function (event, args) {
                            console.log(args.value);
                            scope.showChart = true;
                            scope.runAdvert = 2;
                            scope.AdvertText = "Run adverts on a schedule";

                        });

                        scope.$on('openadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                        });

                        scope.$on('closeadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                            scope.showAdvanced = args.value1;
                            scope.localAwareness = args.value2;
                        });

                        scope.campaignState = $window.localStorage.getItem("campaignState");
                        if (scope.campaignState == "create") {
                            scope.AdvertText = "Run adverts all the time";
                            scope.showChart = false;
                        }

                    }


                }

            }])


        .directive('deliveryType', ['facebookGetPost', '$window', '$filter', '$q', function (facebookGetPost, $window, $filter, $q) {
                return{
                    restrict: 'E',
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/deliveryTypeTemplate.html',
                    transclude: true,
                    scope: {
                        fielddata: "=",
                        validation: "&",
                    },
                    link: function (scope, element, attr) {
                        scope.fielddata = {
                            deliverType: "",
                            deliveryText: "",
                            advancedOption: "",
                            showAdvanced: "",
                            localAwareness: "",
                            advertSchedule: "",
                        }



                        scope.selectDeliveryType = function (value) {
                            console.log(value);
                            if (value == 1) {
                                scope.deliverType = 1;
                                scope.$emit('deliverytype', {value: scope.deliverType});
                            } else {
                                scope.deliverType = 2;
                                scope.$emit('deliverytype', {value: scope.deliverType});
                            }
                        };

                        scope.opendeliveryType = function () {
                            scope.deliveryType = true;
                        }

                        scope.campaignState = $window.localStorage.getItem("campaignState");
                        if (scope.campaignState == "create") {
                            scope.deliveryType = false;
                            scope.deliverType = 1;
                            scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";

                        }
                        else {
                            scope.deliverType = 1;
                            scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";
                        }

                        scope.$on('bidmanual', function (event, args) {
                            console.log(args.value);
                            scope.bidAmountVal = args.value;
                            scope.showText = true;
                            scope.autoBid = false;
                        });

                        scope.$on('deliverytypeone', function (event, args) {
                            console.log(args.value);
                            scope.deliverType = 1;
                            scope.deliveryText = "Standard - Show your adverts throughout the day - Recommended";

                        });

                        scope.$on('deliverytypetwo', function (event, args) {
                            console.log(args.value);
                            scope.deliverType = 2;
                            scope.deliveryText = "Accelerated - Show your adverts as quickly as possible";

                        });

                        scope.$on('openadvancedchild', function (event, args) {
                            console.log(args.value);
                            scope.advancedOption = args.value;
                        });

                        scope.closeAdvancedOption = function () {
                            scope.advancedOption = false;

                            scope.showAdvanced = true;
                            scope.localAwareness = false;
                            scope.$emit('closeadvanced', {value: scope.advancedOption, value1: scope.showAdvanced, value2: scope.localAwareness});
                        }

                    }
                    //controller:'',
                    //bindToController:true,
                }

            }])


        .directive('optimizationGoal', ['facebookGetPost', '$window', '$filter', '$q', function (facebookGetPost, $window, $filter, $q) {
                return{
                    templateUrl: '../CNAP_UI_Repo/app/modules/dynamicforms/optimizationGoalTemplate.html',
                    link: function () {

                    }
                    //controller:'',
                    //bindToController:true,
                }

            }])
     
        
        
        .directive('frequencyCap',['facebookGetPost','$window','$filter','$timeout','$state','appSettings','$q','$animate','apiService','$sce','globalData',function(facebookGetPost,$window,$filter,$timeout,$state,appSettings,$q,$animate,apiService,$sce,globalData){	
            return{

                    restrict:'E',
                    templateUrl:'../CNAP_UI_Repo/app/modules/dynamicforms/directive/frequencyCap.html',	
                    transclude:true,
                    scope:{		
                            fielddata:"="		
                    },     
                    link:function(scope,element,attr){

                            scope.fielddata = {			
                                    deliverType:"",
                                    deliveryText:"",
                                    advancedOption:"",
                                    showAdvanced:"",
                                    localAwareness:"",
                                    advertSchedule:"",
                                    frequencyCap :"",
                            }

                        scope.getFrequencyCap = function(frequencyCap){    
                            console.log("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                            console.log(frequencyCap);
                        scope.frequencyCap = frequencyCap;         
                        scope.$root.freezeFlag = true;
                     //   scope.checkMandatoryField();
                        $window.localStorage.setItem("frequencyCap", scope.frequencyCap);            
                    }
                         scope.init = function () {
                             
                             if($window.localStorage.getItem("campaignState")=="create")
                             {
                              scope.frequencyCap="7";
                          $window.localStorage.setItem("frequencyCap", "7");    
                                 scope.$emit('frequencyCap',{value: scope.frequencyCap});
                             }
                             }
                          scope.init();
                            scope.$on('openadvancedchild', function (event,args) {
                                                    console.log(args.value);
                                                    scope.advancedOption = args.value;
                                                    });
                        scope.$on('frequencyCap', function (event,args) {
                                                    console.log(args.value);
                                                   scope.frequencyCap = args.value;
                                                    });
                                                    scope.$on('closeadvancedchild', function (event,args) {
                                                    console.log(args.value);
                                                    scope.advancedOption = args.value;
                                                    scope.showAdvanced = args.value1;
                                                    scope.localAwareness = args.value2;
                                                    });

               }
            }
            }])



        .factory('fileReader', ['$q', function ($q) {
                var onLoad = function (reader, deferred, scope) {
                    return function () {
                        scope.$apply(function () {
                            deferred.resolve(reader.result);
                        });
                    };
                },
                        onError = function (reader, deferred, scope) {
                            return function () {
                                scope.$apply(function () {
                                    deferred.reject(reader.error);
                                });
                            };
                        },
                        onProgress = function (reader, scope) {
                            return function (event) {
                                scope.$broadcast('fileProgress',
                                        {
                                            total: event.total,
                                            loaded: event.loaded,
                                            status: reader.readyState
                                        });
                            };
                        },
                        getReader = function (deferred, scope) {
                            var reader = new FileReader();
                            reader.onload = onLoad(reader, deferred, scope);
                            reader.onerror = onError(reader, deferred, scope);
                            reader.onprogress = onProgress(reader, scope);
                            return reader;
                        };

                return {
                    readAsArrayBuffer: function (file, scope) {
                        var deferred = $q.defer(),
                                reader = getReader(deferred, scope);
                        reader.readAsArrayBuffer(file);
                        return deferred.promise;
                    },
                    readAsBinaryString: function (file, scope) {
                        var deferred = $q.defer(),
                                reader = getReader(deferred, scope);
                        reader.readAsBinaryString(file);
                        return deferred.promise;
                    },
                    readAsDataURL: function (file, scope) {
                        var deferred = $q.defer(),
                                reader = getReader(deferred, scope);
                        reader.readAsDataURL(file);
                        return deferred.promise;
                    },
                    readAsText: function (file, scope) {
                        var deferred = $q.defer(),
                                reader = getReader(deferred, scope);
                        reader.readAsText(file);
                        return deferred.promise;
                    }
                };
            }])



/*  End of dynamic-forms.js */
